# -*- coding: utf-8 -*-
"""4.39, tercera vuelta de los arreglos de la comanda automática al cobrar (16 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py: destinoDe e impresoraDe reales, la Cocina como única impresora de comanda y cada comanda anotada).

- T1 con la ventana de la habitación abierta, F9, F10, F8 y F4 no hacen nada; abrirPago no abre con ella; abrirCargoHab no abre con un
  cobro abierto o en curso; «Cargar» con un cobro en curso no carga (avisa) y el cobro emite una vez; el segundo toque en «Cargar»
  mientras reclamarHab trae la lista ya no se salta la revisión R7.
- T2 reclamarHab y T3 emitirCobro: si un plato que aquí estaba sin enviar llegó «enviado» al juntar (otro equipo tocó «Comanda» y allá
  se está revisando su comanda), se espera 4 s y se junta otra vez: la comanda sale de un solo equipo. Sin nada de otro equipo no se
  espera. T3: sin el aviso falso «No hay platos nuevos por enviar» en un cobro que sale bien.
- T4 cobroCambiado con `cargo`: «aquí no se cargó nada… antes de cargar».
- T5 comandaRevisada y comandaNumerada: si al guardar la cuenta resultó cobrada o cerrada en otro equipo, lo que ya estaba guardado en
  ella no sale en la comanda ni pasa a la cuenta nueva (con el servidor sin responder, comoPedidoNuevo lo rehacía: cobro y cocina dobles).
- T6 revisarComanda: un plato que en el servidor figura enviado con otra marca (otro equipo lo mandó a cocina) no sale otra vez.
- T7 soltarCuentaCanceladaWeb: el envío a domicilio guardado en la cuenta del pedido se va con el pedido; lo agregado aquí sin guardar
  queda como venta rápida y su comanda sale al cobrarlo.
- T8 volverAMesas: el aviso cuenta los platos sin enviar después de guardar.
- T9 persistirCuenta: la cuenta que ya está guardada conserva su nombre (la venta rápida pasaba de «Cuenta 1» a «Cuenta 2»…).
Cada caso corre también con los métodos de ANTES de esta vuelta: se rehacen desde caja.js deshaciendo cada cambio con un reemplazo de
texto exacto (ANTES, abajo; comprobado contra la copia de caja.js de antes de la vuelta) y ahí se ve el defecto que el cambio arregla.
4.39 (cuarta vuelta): esos reemplazos se aplican sobre caja.js con la cuarta vuelta deshecha (CUARTA y _caja_sin_cuarta, abajo): la cuarta
cambió algunas de las líneas que buscan. Las pruebas de la cuarta vuelta están en tests/test_439_cuarta_vuelta.py.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

from tests.test_431_misma_mesa_pantallas import _linea, _metodo
from tests.test_439_revision_arreglos import CASADO, COMANDA, EMITIR, LIMONADA, POSTRE, RECLAMAR, SOLTAR, _caja, _cambiar, _correr_rev

CAMBIO = "La cuenta cambió en otro equipo y aquí no se cobró nada. Revise el total antes de cobrar."
CAMBIO_HAB = "La cuenta cambió en otro equipo y aquí no se cargó nada. Revise el total antes de cargar."
NO_HAY = "No hay platos nuevos por enviar"
EN_CURSO = "Hay un cobro en curso en esta caja: espere a que termine"
TERMINE = "Termine o cierre el cobro antes de cargar a la habitación"
TRES = CASADO + LIMONADA + POSTRE
AMBOS, LOS_TRES = ["Casado×1", "Postre×1"], ["Casado×1", "Limonada×1", "Postre×1"]
FOLIOS = ["Casado (Cuenta 1)", "Postre (Cuenta 1)"]


# ================================================================================================================ los métodos de antes
def _lineas(m: str, desde: str, hasta: str) -> str:
    """Las líneas enteras de m desde la que contiene `desde` hasta la que contiene el final de `hasta` (sin el salto de línea final)."""
    assert m.count(desde) == 1, desde
    i = m.rindex("\n", 0, m.index(desde)) + 1
    j = m.find("\n", m.index(hasta, i) + len(hasta) - 1)
    return m[i:j if j >= 0 else len(m)]


def _volver(m: str, desde: str, hasta: str, viejo: str) -> str:
    return _cambiar(m, _lineas(m, desde, hasta), viejo)


def _sin_linea(m: str, texto: str) -> str:
    return _cambiar(m, _lineas(m, texto, texto) + "\n", "")


# ================================================================================================================ la quinta vuelta, deshecha
# 4.39 (quinta vuelta): la quinta vuelta cambió líneas que CUARTA y ANTES buscan (el bucle de reclamarHab y de emitirCobro, la marca de
# fusionarAbierta y persistirCuenta, abrirCargoHab, abrirPago, alDiaCuentaNueva...). Cada tripleta (lo de antes, lo de ahora, cuántas veces
# está) se deshace con un reemplazo exacto, en orden inverso (comprobado byte a byte contra la copia de caja.js de antes de la quinta vuelta);
# _caja_sin_cuarta parte de caja.js sin la quinta vuelta. tests/test_439_quinta_vuelta.py usa _caja_sin_quinta para sus versiones «de antes».
# RECIENTE: el plato va a cocina y su marca de envío es de hace menos de 10 s; REFRESCAR15: trae la lista de cuentas (1,5 s como mucho)
# plato que va a cocina y cuya marca de envío es de hace poco (la revisión de la comanda del otro equipo dura 3 s como mucho; 10 s da margen a relojes desfasados)
RECIENTE = "this.destinoDe(l) && !(Date.now() - Date.parse(l.enviado) > 10000)"
REFRESCAR15 = "try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 1500))]); } catch { /* sigue con la copia */ }"
QUINTA = [
# V1: la marca y el bucle, solo por platos que van a cocina y con una comanda reciente
("""          if (this.lineas.some(l => l.enviado && sinEnviar0.has(l.lid))) this._marcaAjena = { id, t: Date.now() };   /* 4.39 (cuarta vuelta): como en fusionarAbierta */""",
"""          if (this.lineas.some(l => l.enviado && sinEnviar0.has(l.lid) && """ + RECIENTE + """)) this._marcaAjena = { id, t: Date.now() };   /* 4.39 (cuarta vuelta): como en fusionarAbierta */""", 1),
("""      if (this.lineas.some(l => l.enviado && sinEnviar0.has(l.lid))) this._marcaAjena = { id: this.esperaId, t: Date.now() };   /* 4.39 (cuarta vuelta): llegaron platos que otro equipo acaba de mandar a cocina (ver emitirCobro) */""",
"""      if (this.lineas.some(l => l.enviado && sinEnviar0.has(l.lid) && """ + RECIENTE + """)) this._marcaAjena = { id: this.esperaId, t: Date.now() };   /* 4.39 (cuarta vuelta): llegaron platos que otro equipo acaba de mandar a cocina (ver emitirCobro). Quinta vuelta: solo los que van a cocina, con una comanda de hace menos de 10 s */""", 1),
("""            if (vuelta || !this.lineas.some(l => l.enviado && sin0.has(l.lid))) break;""",
"""            if (vuelta || !this.lineas.some(l => l.enviado && sin0.has(l.lid) && """ + RECIENTE + """)) break;""", 2),
# V2: en una mesa (o cualquier cuenta guardada sin la revisión de la venta rápida), con el cobro ya pedido
("""      if (reclamar && !rcPedido) { try { rc = await this.reclamarCobro(lineasCobradas); } catch { rc = null; } if (rc && rc.ocupada) return this.cobroOcupado(rc); }""",
"""      if (reclamar && !rcPedido) { try { rc = await this.reclamarCobro(lineasCobradas); } catch { rc = null; } if (rc && rc.ocupada) return this.cobroOcupado(rc); }
      /* 4.39 (quinta vuelta): en una mesa con platos sin enviar, con el cobro ya pedido, se mira la cuenta en el servidor: si otro equipo acaba de mandar */
      /* alguno a cocina («Comanda», con la ventana de cobro ya abierta aquí), se espera a que su comanda salga antes de cerrar la cuenta */
      if (reclamar && !rcPedido && rc && rc.clave && this.esRestaurante && !this.cobroParcial && esperaId !== null && esperaId !== undefined && this.esperaId === esperaId) {
        const sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid));
        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === esperaId); if (c1 && (c1.lineas || []).some(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """)) await new Promise(r => setTimeout(r, 4000)); }
      }""", 1),
# V3: lo mismo al cargar una mesa a la habitación
("""        this._habSigue = true; this.cargarAHabitacion();""",
"""        /* 4.39 (quinta vuelta): en una mesa (sin la revisión de arriba), como al cobrarla: si otro equipo acaba de mandar a cocina un plato que aquí está sin enviar, se espera su comanda */
        if (this.esRestaurante && !this.cobroParcial && !(this.esVentaRapida || this.cuentaRapidaGuardada)) {
          const idM = this.esperaId, sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid));
          if (idM !== null && idM !== undefined && sin1.size) {
            """ + REFRESCAR15 + """
            if (this.habCargo !== hc || this.esperaId !== idM) return;
            const c1 = enEspera().find(v => v.id === idM);
            if (c1 && (c1.lineas || []).some(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """)) { for (let i = 0; i < 20 && this.habCargo === hc && this.esperaId === idM; i++) await new Promise(r => setTimeout(r, 200)); if (this.habCargo !== hc || this.esperaId !== idM) return; }
          }
        }
        this._habSigue = true; this.cargarAHabitacion();""", 1),
# V4: «Cobrar parte»: espera la comanda de otro equipo antes de partir la cuenta y vuelve a juntar
("""      this._seguirCobro = null; await this.alDiaParaCobrar();   /* 4.31: la cuenta como está ahora en el servidor (1,5 s como mucho) */""",
"""      this._seguirCobro = null; await this.alDiaParaCobrar();   /* 4.31: la cuenta como está ahora en el servidor (1,5 s como mucho) */
      /* 4.39 (quinta vuelta): si otro equipo acaba de mandar a cocina platos de esta cuenta (la marca, o la cuenta del servidor), se espera a que salga su comanda */
      /* antes de partirla (al partir, sus platos cambian de identificador y la revisión del otro equipo ya no los encontraba) y se junta otra vez */
      if (this.esRestaurante && id0 !== null && id0 !== undefined) {
        const sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid)), ma = this._marcaAjena; let hasta = ma && ma.id === id0 ? ma.t + 4000 : 0;
        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === id0); if (c1 && (c1.lineas || []).some(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """)) hasta = Date.now() + 4000; }
        if (Date.now() < hasta) { for (let i = 0; i < 20 && Date.now() < hasta && this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo; i++) await new Promise(r => setTimeout(r, 200)); this._alDia = 0; await this.alDiaParaCobrar(true); }
      }""", 1),
# V4b: «Dividir» → «Cobrar estos platos»: si otro equipo acaba de mandar platos a cocina, no se divide todavía
("""      if (d.destino === 'cobrar' && d.modo !== 'partes') { if (this.cfg.pedir_apertura && !this.caja) {""",
"""      if (d.destino === 'cobrar' && d.modo !== 'partes' && this.esRestaurante && this.esperaId !== null && this.esperaId !== undefined) {   /* 4.39 (quinta vuelta): como en cobrarParte; la selección va por posición, así que no se junta aquí: se vuelve a dividir */
        const id1 = this.esperaId, sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid));
        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === id1); if (c1 && (c1.lineas || []).some(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """)) { this._marcaAjena = { id: id1, t: Date.now() }; if (this.dividir === d) this.dividir = null; return toast('Otro equipo acaba de mandar a cocina platos de esta cuenta. Espere unos segundos y vuelva a dividir.', 'err'); } }
        const ma = this._marcaAjena; for (let i = 0; i < 20 && ma && ma.id === id1 && Date.now() < ma.t + 4000 && this.dividir === d && this.esperaId === id1; i++) await new Promise(r => setTimeout(r, 200));
        if (this.dividir !== d || this.esperaId !== id1) return;
      }
      if (d.destino === 'cobrar' && d.modo !== 'partes') { if (this.cfg.pedir_apertura && !this.caja) {""", 1),
# V5: abrirPago con la ventana de la habitación: la parte vuelve a la cuenta
("""      if (this.habCargo) return;   /* 4.39 (tercera vuelta): no se abre debajo de la ventana de la habitación */""",
"""      if (this.habCargo) { if (this.cobroParcial) this.cerrarPago(); return; }   /* 4.39 (tercera vuelta): no se abre debajo de la ventana de la habitación (quinta vuelta: la parte vuelve a la cuenta) */""", 1),
# V6: «Dividir» no se abre sobre el cobro o la habitación; la habitación no se abre con «Dividir»
("""    async abrirDividir() { if (!this.lineas.length) return; await this.alDiaParaCobrar(); if (!this.lineas.length || this.dividir) return;""",
"""    async abrirDividir() { if (!this.lineas.length) return; await this.alDiaParaCobrar(); if (!this.lineas.length || this.dividir || this.pago || this.habCargo || this.cobroParcial) return;""", 1),
("""      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial) return toast('Termine o cierre el cobro antes de cargar a la habitación', 'err');   /* 4.39 (tercera vuelta) */""",
"""      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial || this.dividir) return toast('Termine o cierre el cobro antes de cargar a la habitación', 'err');   /* 4.39 (tercera vuelta; quinta: ni con «Dividir» abierto) */""", 1),
("""      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial) return;   /* 4.39 (cuarta vuelta): mientras se esperaba se abrió el cobro (F9 o «Cobrar parte») */""",
"""      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial || this.dividir) return;   /* 4.39 (cuarta vuelta): mientras se esperaba se abrió el cobro (F9 o «Cobrar parte») o «Dividir» */""", 1),
# V7: F9 no abre el cobro completo con «Dividir» abierto
("""if (e.key === 'F9') { e.preventDefault(); if (this.pago) this.cobrar(); else if (this.vista === 'venta') this.abrirPago(); }""",
"""if (e.key === 'F9') { e.preventDefault(); if (this.pago) this.cobrar(); else if (this.vista === 'venta' && !this.dividir) this.abrirPago(); }   /* 4.39 (quinta vuelta): con «Dividir» abierto, F9 no abre el cobro completo debajo */""", 1),
# V8: modo cajero: si se cerró el cobro mientras se tomaba el turno, no se sigue (quedaba «cobrando» y la caja trabada)
("""      if (!(await this.cobroPermitido('cobrar'))) { this.cerrarPago(); return; }   // 4.6: por si la caja cambió de turno con el cobro abierto (la parte vuelve a la cuenta)""",
"""      if (!(await this.cobroPermitido('cobrar'))) { this.cerrarPago(); return; }   // 4.6: por si la caja cambió de turno con el cobro abierto (la parte vuelve a la cuenta)
      if (!this.pago) return;   /* 4.39 (quinta vuelta): se cerró el cobro mientras se esperaba (antes quedaba «cobrando» y la caja trabada hasta recargar) */""", 1),
# V9: U6 también con la cuenta abierta desde «Para llevar en espera» (su nombre es el automático)
("""(this.esperaId !== id || !(this.nombreEspera || '').trim()) && this.espera.some(""",
"""(this.esperaId !== id || !(this.nombreEspera || '').trim() || this.nombreEspera === cn.nombre) && this.espera.some(""", 1),
("""this.actualizarCuenta(id, x => ({ ...x, nombre })); this.espera = enEspera(); }""",
"""if (this.esperaId === id && this.nombreEspera === cn.nombre) this.nombreEspera = nombre; this.actualizarCuenta(id, x => ({ ...x, nombre })); this.espera = enEspera(); }""", 1),
# V10: el aviso de cuenta rehecha con el nombre de la cuenta (decía «La cuenta de la cuenta»)
("""        const m = (viejo === abierta ? this.nombreEspera : enviadas.get(viejo)) || 'la cuenta'; enviadas.delete(viejo);""",
"""        const m = (viejo === abierta ? this.nombreEspera || enviadas.get(viejo) : enviadas.get(viejo)) || 'la cuenta'; enviadas.delete(viejo);   /* 4.39 (quinta vuelta): la venta rápida guardada no tiene nombre en pantalla */""", 1),
]


def _sin_quinta(texto: str) -> str:
    """caja.js con lo de la quinta vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(QUINTA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_quinta() -> str:
    # 4.39 (sexta vuelta): parte de caja.js sin la sexta vuelta (la sexta cambió líneas que QUINTA busca: la marca, el bucle de emitirCobro,
    # V2, V3, V4, V4b, abrirPago, emitirCobro después de cobroPermitido, alDiaCuentaNueva...)
    return _sin_quinta(_caja_sin_sexta())


# ================================================================================================================ la sexta vuelta, deshecha
# 4.39 (sexta vuelta): los 20 cambios de la sexta vuelta (W1 a W11), tal como se aplicaron a caja.js: cada tripleta (lo de antes, lo de ahora,
# cuántas veces está) se deshace con un reemplazo exacto, en orden inverso (comprobado byte a byte contra la copia de caja.js de antes de la
# sexta vuelta); _caja_sin_quinta parte de caja.js sin la sexta vuelta. tests/test_439_sexta_vuelta.py usa _caja_sin_sexta para sus versiones
# «de antes». REFRESCAR3: trae la lista de cuentas (3 s como mucho); GUARDAR3: guarda la cuenta y sube lo pendiente (3 s como mucho)
REFRESCAR3 = "try { await Promise.race([mock.refrescar(['pos_espera']), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con lo que hay */ }"
GUARDAR3 = "try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* lo decide cobroCambiado */ }"


def MARCA(i):
    """La marca de otro equipo con la hora de su comanda (env; t = fin - 4000, con fin = min(ahora + 4 s, comanda + 8 s)); la misma comanda no
    la renueva. `i`: la expresión del id de la cuenta en cada método."""
    return ("const te = Math.max(0, ...ls.map(l => Date.parse(l.enviado) || 0)), m1 = this._marcaAjena; if (!(m1 && m1.id === " + i + " && m1.env >= te)) "
            "this._marcaAjena = { id: " + i + ", t: te > 0 ? Math.min(Date.now(), te + 4000) : Date.now(), env: te };")


SEXTA = [
# W2: enviarComanda y comandaNumerada no guardan la parte de un cobro como cuenta
("""      if (this.esRestaurante) this.persistirCuenta();   // 4.6: también sin mesa (para llevar): la primera comanda deja la cuenta guardada y visible en los otros equipos""",
"""      /* 4.39 (sexta vuelta): la parte de un cobro («Dividir → Cobrar estos platos» en la venta rápida, ver emitirCobro) no es una cuenta: no se guarda */
      if (this.esRestaurante && !this.cobroParcial) this.persistirCuenta();   // 4.6: también sin mesa (para llevar): la primera comanda deja la cuenta guardada y visible en los otros equipos""", 1),
("""      const id0 = this.esperaId; if (this.esRestaurante) this.persistirCuenta();
      /* 4.39 (tercera vuelta): al guardar se supo""",
"""      const id0 = this.esperaId; if (this.esRestaurante && !this.cobroParcial) this.persistirCuenta();   /* 4.39 (sexta vuelta): como en enviarComanda */
      /* 4.39 (tercera vuelta): al guardar se supo""", 1),
# W4: cobrarParte no sigue si «Dividir» se canceló o se abrió mientras esperaba
("""      const id0 = this.esperaId;   /* 4.31: un segundo toque mientras se espera a la red no vuelve a partir la parte que ya se está cobrando */""",
"""      const id0 = this.esperaId, div0 = this.dividir;   /* 4.31: un segundo toque mientras se espera a la red no vuelve a partir la parte que ya se está cobrando */
      /* 4.39 (sexta vuelta): div0, «Dividir» como estaba al tocar (abierto si se llega desde ahí): si se cancela o se abre mientras se espera, no se parte */""", 1),
# W6 en V4: la marca con la hora de la comanda (la espera es solo lo que falta y el juntar de después no la renueva)
("""        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === id0); if (c1 && (c1.lineas || []).some(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """)) hasta = Date.now() + 4000; }""",
"""        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === id0), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : []; if (ls.length) { """ + MARCA('id0') + """ hasta = Math.max(hasta, this._marcaAjena.t + 4000); } }   /* 4.39 (sexta vuelta): la marca, con la hora de esa comanda */""", 1),
("""        if (Date.now() < hasta) { for (let i = 0; i < 20 && Date.now() < hasta && this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo; i++) await new Promise(r => setTimeout(r, 200)); this._alDia = 0; await this.alDiaParaCobrar(true); }""",
"""        if (Date.now() < hasta) { for (let i = 0; i < 20 && Date.now() < hasta && this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo && this.dividir === div0; i++) await new Promise(r => setTimeout(r, 200)); if (this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo && this.dividir === div0) { this._alDia = 0; await this.alDiaParaCobrar(); } }   /* 4.39 (sexta vuelta): con el aviso si la cuenta cambió */""", 1),
("""      if (this.cobroParcial || this.esperaId !== id0 || this.habCargo || this.pago) return;   /* 4.39 (cuarta vuelta): ni con la ventana de la habitación o la de cobro abiertas mientras tanto */""",
"""      if (this.cobroParcial || this.esperaId !== id0 || this.habCargo || this.pago || this.dividir !== div0) return;   /* 4.39 (cuarta vuelta): ni con la ventana de la habitación o la de cobro abiertas mientras tanto. Sexta vuelta: ni si «Dividir» cambió */""", 1),
# W5: V4b en toda salida de confirmarDividir que parte la cuenta (las partes de una mesa van por cobrarParte)
("""      if (d.destino === 'cobrar' && d.modo !== 'partes' && this.esRestaurante && this.esperaId !== null && this.esperaId !== undefined) {   /* 4.39 (quinta vuelta): como en cobrarParte; la selección va por posición, así que no se junta aquí: se vuelve a dividir */""",
"""      if (!(d.modo === 'partes' && this.mesaActual) && this.esRestaurante && this.esperaId !== null && this.esperaId !== undefined) {   /* 4.39 (quinta vuelta): como en cobrarParte; la selección va por posición, así que no se junta aquí: se vuelve a dividir */
        /* 4.39 (sexta vuelta): también al separar, pasar a una mesa o partir sin mesa (las partes de una mesa van por cobrarParte). La marca lleva la hora de esa */
        /* comanda y la próxima vez que se abra «Dividir» se junta (antes repetía el aviso) */""", 1),
# W6 + W10 en V4b
("""        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === id1); if (c1 && (c1.lineas || []).some(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """)) { this._marcaAjena = { id: id1, t: Date.now() }; if (this.dividir === d) this.dividir = null; return toast('Otro equipo acaba de mandar a cocina platos de esta cuenta. Espere unos segundos y vuelva a dividir.', 'err'); } }""",
"""        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === id1), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : []; if (ls.length) { """ + MARCA('id1') + """ this._alDia = 0; if (this.dividir === d) this.dividir = null; return toast('Otro equipo acaba de mandar a cocina platos de esta cuenta. Espere unos segundos y vuelva a dividir.', 'err'); } }""", 1),
# W2: la parte de la venta rápida recuerda que lo es
("""        this.lineas = resto; const id = this.persistirCuenta(true);""",
"""        const rapida0 = this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada);   /* 4.39 (sexta vuelta): antes de partir: la parte de la venta rápida manda su comanda al cobrarla (emitirCobro) */
        this.lineas = resto; const id = this.persistirCuenta(true);""", 1),
("""this.cobroParcial = { cuentaId: id, parte: null, de: null };""",
"""this.cobroParcial = { cuentaId: id, parte: null, de: null, ...(rapida0 ? { rapida: true } : {}) };""", 1),
# W6: la marca en persistirCuenta y fusionarAbierta
("""          if (this.lineas.some(l => l.enviado && sinEnviar0.has(l.lid) && """ + RECIENTE + """)) this._marcaAjena = { id, t: Date.now() };   /* 4.39 (cuarta vuelta): como en fusionarAbierta */""",
"""          { const ls = this.lineas.filter(l => l.enviado && sinEnviar0.has(l.lid) && """ + RECIENTE + """); if (ls.length) { """ + MARCA('id') + """ } }   /* 4.39 (cuarta vuelta): como en fusionarAbierta */""", 1),
("""      if (this.lineas.some(l => l.enviado && sinEnviar0.has(l.lid) && """ + RECIENTE + """)) this._marcaAjena = { id: this.esperaId, t: Date.now() };   /* 4.39 (cuarta vuelta): llegaron platos que otro equipo acaba de mandar a cocina (ver emitirCobro). Quinta vuelta: solo los que van a cocina, con una comanda de hace menos de 10 s */""",
"""      /* 4.39 (sexta vuelta): la marca lleva la hora de esa comanda (env). Se espera hasta 4 s después de verla y nunca más de 8 s después de la comanda (la revisión del */
      /* otro equipo dura 3 s como mucho; lo demás es margen para relojes desfasados). La misma comanda, vista otra vez al juntar, no renueva la marca */
      { const ls = this.lineas.filter(l => l.enviado && sinEnviar0.has(l.lid) && """ + RECIENTE + """); if (ls.length) { """ + MARCA('this.esperaId') + """ } }   /* 4.39 (cuarta vuelta): llegaron platos que otro equipo acaba de mandar a cocina (ver emitirCobro). Quinta vuelta: solo los que van a cocina, con una comanda de hace menos de 10 s */""", 1),
# W7: el aviso con el nombre nuevo
("""this.actualizarCuenta(id, x => ({ ...x, nombre })); this.espera = enEspera(); }""",
"""this.actualizarCuenta(id, x => ({ ...x, nombre })); this.espera = enEspera(); toast('Ya había otra «' + cn.nombre + '» abierta: lo que agregó quedó en «' + nombre + '».', 'ok'); }   /* 4.39 (sexta vuelta): el aviso de seguirIds la nombró con el nombre de antes */""", 1),
# W6 en el bucle de la habitación (R7)
("""            for (let i = 0; i < 20 && this.habCargo === hc && this.esperaId === id0; i++) await new Promise(r => setTimeout(r, 200));   /* 4.39 (cuarta vuelta): en tramos: al cerrar la ventana se deja de esperar */""",
"""            { const ma = this._marcaAjena, fin = ma && ma.id === this.esperaId ? ma.t + 4000 : Date.now() + 4000; for (let i = 0; i < 20 && Date.now() < fin && this.habCargo === hc && this.esperaId === id0; i++) await new Promise(r => setTimeout(r, 200)); }   /* 4.39 (cuarta vuelta): en tramos: al cerrar la ventana se deja de esperar. Sexta vuelta: solo lo que falta (la marca que dejó persistirCuenta al juntar) */""", 1),
# W6 + W11 en V3 (la mesa a la habitación)
("""            const c1 = enEspera().find(v => v.id === idM);
            if (c1 && (c1.lineas || []).some(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """)) { for (let i = 0; i < 20 && this.habCargo === hc && this.esperaId === idM; i++) await new Promise(r => setTimeout(r, 200)); if (this.habCargo !== hc || this.esperaId !== idM) return; }""",
"""            const c1 = enEspera().find(v => v.id === idM), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : [];
            if (ls.length) {
              /* 4.39 (sexta vuelta): solo lo que falta (la marca, con la hora de esa comanda: al volver a tocar «Cargar» no se espera otra vez) y después se junta lo */
              /* que otro equipo guardó: si la cuenta ya no está o cambió (un plato quitado durante la espera), no se carga nada (el finally suelta el cobro) */
              """ + MARCA('idM') + """ const fin = this._marcaAjena.t + 4000;
              for (let i = 0; i < 20 && Date.now() < fin && this.habCargo === hc && this.esperaId === idM; i++) await new Promise(r => setTimeout(r, 200));
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              const lineas0 = this.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), total0 = this.totales.total;
              """ + REFRESCAR3 + """
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              if (!enEspera().some(v => v.id === idM)) { this.habCargo = null; return this.cobroOcupado({ resultado: 'cobrada', comunes: [] }); }
              """ + GUARDAR3 + """
              if (this.habCargo !== hc) return;
              if (this.cobroCambiado(idM, lineas0, total0, false, true)) return;   /* la ventana sigue abierta con el total nuevo */
            }""", 1),
# W1: abrirPago no abre el cobro encima de «Dividir»
("""      if (this.habCargo) { if (this.cobroParcial) this.cerrarPago(); return; }   /* 4.39 (cuarta vuelta): mientras se esperaba se abrió la ventana de la habitación */""",
"""      if (this.habCargo || this.dividir) { if (this.cobroParcial) this.cerrarPago(); return; }   /* 4.39 (cuarta vuelta): mientras se esperaba se abrió la ventana de la habitación. Sexta vuelta: o «Dividir» */""", 1),
# W3: el cobro que se cierra (o se está cerrando) mientras se espera el turno no se emite
("""      if (!(await this.cobroPermitido('cobrar'))) { this.cerrarPago(); return; }   // 4.6: por si la caja cambió de turno con el cobro abierto (la parte vuelve a la cuenta)
      if (!this.pago) return;   /* 4.39 (quinta vuelta): se cerró el cobro mientras se esperaba (antes quedaba «cobrando» y la caja trabada hasta recargar) */""",
"""      const pagoAbierto = this.pago;
      if (!(await this.cobroPermitido('cobrar'))) { this.cerrarPago(); return; }   // 4.6: por si la caja cambió de turno con el cobro abierto (la parte vuelve a la cuenta)
      if (this.pago !== pagoAbierto || this.cobrando) return;   /* 4.39 (quinta vuelta): se cerró el cobro mientras se esperaba (antes quedaba «cobrando» y la caja trabada hasta recargar). Sexta vuelta: o se está cerrando (la parte vuelve a la cuenta) o es otro cobro */""", 1),
# W6 en el bucle de la venta rápida (R2)
("""> 10000))) break;
            await new Promise(r => setTimeout(r, 4000));""",
"""> 10000))) break;
            { const ma = this._marcaAjena, falta = ma && ma.id === this.esperaId ? ma.t + 4000 - Date.now() : 4000; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }   /* 4.39 (sexta vuelta): solo lo que falta (la marca que dejó persistirCuenta al juntar) */""", 1),
# W6 + W11 en V2 (la mesa con el cobro abierto)
("""        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === esperaId); if (c1 && (c1.lineas || []).some(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """)) await new Promise(r => setTimeout(r, 4000)); }""",
"""        if (sin1.size) {
          """ + REFRESCAR15 + """
          const c1 = enEspera().find(v => v.id === esperaId), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : [];
          if (ls.length) {
            /* 4.39 (sexta vuelta): se espera solo lo que falta (la marca, con la hora de esa comanda) y después se junta lo que otro equipo guardó, como en la */
            /* venta rápida: si la cuenta ya no está o cambió (un plato quitado durante la espera), no se cobra nada y el cobro pedido queda libre */
            """ + MARCA('esperaId') + """ const falta = this._marcaAjena.t + 4000 - Date.now(); if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000)));
            """ + REFRESCAR3 + """
            if (!enEspera().some(v => v.id === esperaId)) { this.soltarCobro(rc, false); return this.cobroOcupado({ resultado: 'cobrada', comunes: [] }); }
            """ + GUARDAR3 + """
            const cambio2 = this.cobroCambiado(esperaId, lineasCobradas, total, false); if (cambio2) { this.soltarCobro(rc, false); return cambio2; }
          }
        }""", 1),
# W2: la parte de la venta rápida manda su comanda al cobrarla
("""      let doc = null, body = null;""",
"""      /* 4.39 (sexta vuelta): «Dividir → Cobrar estos platos» en la venta rápida: los platos de la parte que no se habían enviado salen a cocina al cobrarla, como */
      /* el resto de la venta rápida (antes se cobraban y nunca llegaban). Después de pedir el cobro y sin guardar nada (la parte no es una cuenta) */
      if (this.esRestaurante && this.cobroParcial && this.cobroParcial.rapida && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))) { try { this.enviarComanda(); } catch { /* la comanda no detiene el cobro */ } }
      let doc = null, body = null;""", 1),
]


def _sin_sexta(texto: str) -> str:
    """caja.js con lo de la sexta vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(SEXTA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_sexta() -> str:
    # 4.39 (séptima vuelta): parte de caja.js sin la séptima vuelta (la séptima cambió líneas que SEXTA busca: W2, la marca de V4 y V4b, V2, V3...)
    return _sin_sexta(_caja_sin_septima())


# ================================================================================================================ la séptima vuelta, deshecha
# 4.39 (séptima vuelta): los cambios de la séptima vuelta (X0 a X7 y D0), tal como se aplicaron a caja.js: cada tripleta (lo de antes, lo de
# ahora, cuántas veces está) se deshace con un reemplazo exacto, en orden inverso (comprobado byte a byte contra la copia de caja.js de antes de
# la séptima vuelta); _caja_sin_sexta parte de caja.js sin la séptima vuelta. tests/test_439_septima_vuelta.py usa _caja_sin_septima para sus
# versiones «de antes». Los dos últimos son bloques enteros: el de la mesa en reclamarHab (V3) y el de la mesa en emitirCobro (V2, con lo de W2)
def VIGENTE(i):
    """La marca de otro equipo sobre la cuenta `i` todavía no venció (se espera hasta t + 4 s)."""
    return "!!(this._marcaAjena && this._marcaAjena.id === " + i + " && Date.now() < this._marcaAjena.t + 4000)"


SEPTIMA = [
# X0: fuera W2 (la opción «Cobrar estos platos» solo se ofrece con mesa: era código que nunca corría)
("""      /* 4.39 (sexta vuelta): la parte de un cobro («Dividir → Cobrar estos platos» en la venta rápida, ver emitirCobro) no es una cuenta: no se guarda */
      if (this.esRestaurante && !this.cobroParcial) this.persistirCuenta();   // 4.6: también sin mesa (para llevar): la primera comanda deja la cuenta guardada y visible en los otros equipos""",
"""      if (this.esRestaurante) this.persistirCuenta();   // 4.6: también sin mesa (para llevar): la primera comanda deja la cuenta guardada y visible en los otros equipos""", 1),
("""      const id0 = this.esperaId; if (this.esRestaurante && !this.cobroParcial) this.persistirCuenta();   /* 4.39 (sexta vuelta): como en enviarComanda */
      /* 4.39 (tercera vuelta): al guardar se supo""",
"""      const id0 = this.esperaId; if (this.esRestaurante) this.persistirCuenta();
      /* 4.39 (tercera vuelta): al guardar se supo""", 1),
("""        const rapida0 = this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada);   /* 4.39 (sexta vuelta): antes de partir: la parte de la venta rápida manda su comanda al cobrarla (emitirCobro) */
        this.lineas = resto; const id = this.persistirCuenta(true);""",
"""        this.lineas = resto; const id = this.persistirCuenta(true);""", 1),
("""this.cobroParcial = { cuentaId: id, parte: null, de: null, ...(rapida0 ? { rapida: true } : {}) };""",
"""this.cobroParcial = { cuentaId: id, parte: null, de: null };""", 1),
# X5 y X7 en cobrarParte: junta también con una comanda vieja (vistos) y espera la comanda más nueva que llegue al juntar
("""ma = this._marcaAjena; let hasta = ma && ma.id === id0 ? ma.t + 4000 : 0;""",
"""ma = this._marcaAjena; let hasta = ma && ma.id === id0 ? ma.t + 4000 : 0, junta = false;""", 1),
("""const c1 = enEspera().find(v => v.id === id0), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : []; if (ls.length) {""",
"""const c1 = enEspera().find(v => v.id === id0), vistos = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && this.destinoDe(l)) : [], ls = vistos.filter(l => !(Date.now() - Date.parse(l.enviado) > 10000)); if (vistos.length) junta = true; if (ls.length) {""", 1),
("""} }   /* 4.39 (sexta vuelta): la marca, con la hora de esa comanda */""",
"""} }   /* 4.39 (sexta vuelta): la marca, con la hora de esa comanda. Séptima vuelta: y se junta aunque esa comanda sea vieja (la pantalla está atrasada: lo que quedaba se guardaba «sin enviar» y volvía a salir a cocina) */""", 1),
("""        if (Date.now() < hasta) { for (let i = 0; i < 20 && Date.now() < hasta && this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo && this.dividir === div0; i++) await new Promise(r => setTimeout(r, 200)); if (this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo && this.dividir === div0) { this._alDia = 0; await this.alDiaParaCobrar(); } }   /* 4.39 (sexta vuelta): con el aviso si la cuenta cambió */""",
"""        /* 4.39 (séptima vuelta): si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó), se espera también esa y se junta otra vez */
        for (let k = 0; k < 2 && (Date.now() < hasta || junta); k++) { junta = false; for (let i = 0; i < 20 && Date.now() < hasta && this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo && this.dividir === div0; i++) await new Promise(r => setTimeout(r, 200)); if (!(this.esperaId === id0 && !this.cobroParcial && !this.pago && !this.habCargo && this.dividir === div0)) break; this._alDia = 0; await this.alDiaParaCobrar(); const m2 = this._marcaAjena; if (m2 && m2.id === id0) hasta = Math.max(hasta, m2.t + 4000); }   /* 4.39 (sexta vuelta): con el aviso si la cuenta cambió */""", 1),
# X6, X2 y D0 en confirmarDividir
("""        const id1 = this.esperaId, sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid));
        if (sin1.size) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === id1), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : []; if (ls.length) { """ + MARCA('id1') + """ this._alDia = 0; if (this.dividir === d) this.dividir = null; return toast('Otro equipo acaba de mandar a cocina platos de esta cuenta. Espere unos segundos y vuelva a dividir.', 'err'); } }
        const ma = this._marcaAjena; for (let i = 0; i < 20 && ma && ma.id === id1 && Date.now() < ma.t + 4000 && this.dividir === d && this.esperaId === id1; i++) await new Promise(r => setTimeout(r, 200));
        if (this.dividir !== d || this.esperaId !== id1) return;
      }
""",
"""        /* 4.39 (séptima vuelta): el aviso sale también con una comanda vieja que la pantalla todavía no tiene (con «Dividir» abierto no se junta: lo partido se */
        /* guardaba «sin enviar» y volvía a salir a cocina); la marca, solo con una reciente. Al separar, pasar a una mesa o partir, la lista se trae aunque todo */
        /* esté enviado (abajo: si otro equipo cobró la cuenta, sus platos no se pasan a otra). Después de esperar la marca se mira otra vez la cuenta: si otro */
        /* equipo la cambió mientras tanto, no se parte y se vuelve a dividir (la selección va por posición) */
        const id1 = this.esperaId, sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid)), b1 = this._base, ex1 = !!(b1 && b1.id === id1 && b1.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', id1));
        if (sin1.size || (ex1 && (d.modo === 'partes' || d.destino !== 'cobrar'))) { """ + REFRESCAR15 + """ const c1 = enEspera().find(v => v.id === id1), vistos = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && this.destinoDe(l)) : [], ls = vistos.filter(l => !(Date.now() - Date.parse(l.enviado) > 10000)); if (vistos.length) { if (ls.length) { """ + MARCA('id1') + """ } this._alDia = 0; if (this.dividir === d) this.dividir = null; return toast('Otro equipo mandó a cocina platos de esta cuenta. Vuelva a abrir «Dividir» para verla al día.', 'err'); } }
        const espero = """ + VIGENTE('id1') + """;
        const ma = this._marcaAjena; for (let i = 0; i < 20 && ma && ma.id === id1 && Date.now() < ma.t + 4000 && this.dividir === d && this.esperaId === id1; i++) await new Promise(r => setTimeout(r, 200));
        if (this.dividir !== d || this.esperaId !== id1) return;
        if (espero) {
          """ + REFRESCAR15 + """
          if (this.dividir !== d || this.esperaId !== id1) return;
          const firma = ls => (ls || []).map(l => String(l && l.lid) + ':' + (+(l && l.cantidad) || 0)).sort().join('|'), c2 = enEspera().find(v => v.id === id1);
          if (!c2 && ex1) { this.dividir = null; this.sincronizar(); return; }
          if (!c2 || firma(ponerLids(JSON.parse(JSON.stringify(c2))).lineas) !== firma(this._base && this._base.id === id1 ? this._base.lineas : [])) { this._alDia = 0; this.dividir = null; return toast('La cuenta cambió en otro equipo mientras se esperaba. Vuelva a dividir.', 'err'); }
        }
      }
      /* 4.39 (séptima vuelta): como en «Cobrar estos platos» (más abajo): si la cuenta ya estaba guardada y no está en la lista, otro equipo la cobró o la cerró. */
      /* Separar, pasar a una mesa o partir no se hacen: antes sus platos quedaban en una cuenta nueva, por cobrar otra vez */
      { const idx = this.esperaId, bx = this._base; if ((d.modo === 'partes' || d.destino !== 'cobrar') && idx !== null && idx !== undefined && (!!(bx && bx.id === idx && bx.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', idx))) && !enEspera().some(v => v.id === idx)) { this.dividir = null; this.sincronizar(); return; } }
""", 1),
# X3: cobroOcupado con «cerrada» (la cuenta ya no está después de esperar la comanda de otro equipo)
("""      toast(res === 'ocupada' ? 'Esta cuenta se está cobrando en otro equipo.""",
"""      /* 4.39 (séptima vuelta): «cerrada», la cuenta ya no está después de esperar la comanda de otro equipo (borrada, pasada a otra mesa o cobrada): sin este */
      /* aviso, que decía «ya se cobró»; sincronizar, más abajo, da el de siempre («fue cobrada o cerrada en otro equipo») */
      if (res !== 'cerrada') toast(res === 'ocupada' ? 'Esta cuenta se está cobrando en otro equipo.""", 1),
("""      else this.seguirCobroAjeno(this.esperaId);   /* 4.31 (cuarta vuelta): y se pone al día cuando el otro equipo termine */""",
"""      else { if (res === 'cerrada') toast('Aquí no se cobró ni se cargó nada: la cuenta cambió en otro equipo. Revísela antes de cobrar.', 'err'); this.seguirCobroAjeno(this.esperaId); }   /* 4.31 (cuarta vuelta): y se pone al día cuando el otro equipo termine. 4.39 (séptima vuelta): con «cerrada», el aviso si la cuenta sigue en la lista */""", 1),
# X7 en los bucles de la venta rápida (R7 en reclamarHab y R2 en emitirCobro): otra vuelta si al juntar llegó una comanda más nueva
("""            if (vuelta || !this.lineas.some(l => l.enviado && sin0.has(l.lid) && """ + RECIENTE + """)) break;""",
"""            if (vuelta > 1 || (vuelta ? !""" + VIGENTE('this.esperaId')[2:] + """ : !this.lineas.some(l => l.enviado && sin0.has(l.lid) && """ + RECIENTE + """))) break;   /* 4.39 (séptima vuelta): otra vuelta solo si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó) */""", 2),
# X1 en reclamarHab: si va a esperar la marca (después se junta) y la condición de la revisión de la venta rápida
("""        { const ma = this._marcaAjena, id1 = this.esperaId; if (ma && ma.id === id1) {""",
"""        const esperoHab = """ + VIGENTE('this.esperaId') + """;   /* 4.39 (séptima vuelta): si aquí se espera la comanda de otro equipo, después se junta lo que guardó (abajo) */
        { const ma = this._marcaAjena, id1 = this.esperaId; if (ma && ma.id === id1) {""", 1),
("""        if (this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))) {
          const id0 = this.esperaId, lineas0""",
"""        const rapHab = this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l));   /* 4.39 (séptima vuelta): la revisión de aquí abajo; lo demás va por la de la mesa */
        if (this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))) {
          const id0 = this.esperaId, lineas0""", 1),
# X1 en emitirCobro: si va a esperar la marca (después se junta, en la mesa)
("""      { const ma = this._marcaAjena, falta = ma && esperaId !== null && esperaId !== undefined && ma.id === esperaId ? ma.t + 4000 - Date.now() : 0;""",
"""      const esperoMarca = esperaId !== null && esperaId !== undefined && """ + VIGENTE('esperaId') + """;   /* 4.39 (séptima vuelta): si aquí se espera la comanda de otro equipo, después se junta lo que guardó (abajo) */
      { const ma = this._marcaAjena, falta = ma && esperaId !== null && esperaId !== undefined && ma.id === esperaId ? ma.t + 4000 - Date.now() : 0;""", 1),
# X1 y X7 en V3 (reclamarHab): el bloque de la mesa entero (hasta antes de «this._habSigue = true; this.cargarAHabitacion();»)
("""        if (this.esRestaurante && !this.cobroParcial && !(this.esVentaRapida || this.cuentaRapidaGuardada)) {
          const idM = this.esperaId, sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid));
          if (idM !== null && idM !== undefined && sin1.size) {
            """ + REFRESCAR15 + """
            if (this.habCargo !== hc || this.esperaId !== idM) return;
            const c1 = enEspera().find(v => v.id === idM), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : [];
            if (ls.length) {
              /* 4.39 (sexta vuelta): solo lo que falta (la marca, con la hora de esa comanda: al volver a tocar «Cargar» no se espera otra vez) y después se junta lo */
              /* que otro equipo guardó: si la cuenta ya no está o cambió (un plato quitado durante la espera), no se carga nada (el finally suelta el cobro) */
              """ + MARCA('idM') + """ const fin = this._marcaAjena.t + 4000;
              for (let i = 0; i < 20 && Date.now() < fin && this.habCargo === hc && this.esperaId === idM; i++) await new Promise(r => setTimeout(r, 200));
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              const lineas0 = this.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), total0 = this.totales.total;
              """ + REFRESCAR3 + """
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              if (!enEspera().some(v => v.id === idM)) { this.habCargo = null; return this.cobroOcupado({ resultado: 'cobrada', comunes: [] }); }
              """ + GUARDAR3 + """
              if (this.habCargo !== hc) return;
              if (this.cobroCambiado(idM, lineas0, total0, false, true)) return;   /* la ventana sigue abierta con el total nuevo */
            }
          }
        }
""",
"""        /* 4.39 (séptima vuelta): también la venta rápida o la cuenta guardada sin platos por enviar, si arriba se esperó la comanda de otro equipo (esperoHab): */
        /* después de esperar se junta lo que ese equipo guardó. Y si al juntar llegó una comanda más nueva suya (la marca se renovó), se espera y se junta otra vez */
        if (this.esRestaurante && !this.cobroParcial && !rapHab) {
          const idM = this.esperaId, sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid));
          if (idM !== null && idM !== undefined && (sin1.size || esperoHab)) {
            let junta = esperoHab;
            if (sin1.size) {
              """ + REFRESCAR15 + """
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              const c1 = enEspera().find(v => v.id === idM), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : [];
              /* 4.39 (sexta vuelta): solo lo que falta (la marca, con la hora de esa comanda: al volver a tocar «Cargar» no se espera otra vez) y después se junta lo */
              /* que otro equipo guardó: si la cuenta ya no está o cambió (un plato quitado durante la espera), no se carga nada (el finally suelta el cobro) */
              if (ls.length) { """ + MARCA('idM') + """ junta = true; }
            }
            const lineas0 = this.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), total0 = this.totales.total;
            for (let k = 0; junta && k < 2; k++) {
              { const m2 = this._marcaAjena, fin = m2 && m2.id === idM ? m2.t + 4000 : 0; for (let i = 0; i < 20 && Date.now() < fin && this.habCargo === hc && this.esperaId === idM; i++) await new Promise(r => setTimeout(r, 200)); }
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              """ + REFRESCAR3 + """
              if (this.habCargo !== hc || this.esperaId !== idM) return;
              if (!enEspera().some(v => v.id === idM)) { this.habCargo = null; return this.cobroOcupado({ resultado: 'cerrada', comunes: [] }); }
              """ + GUARDAR3 + """
              if (this.habCargo !== hc) return;
              if (this.cobroCambiado(idM, lineas0, total0, false, true)) return;   /* la ventana sigue abierta con el total nuevo */
              junta = """ + VIGENTE('idM') + """;
            }
          }
        }
""", 1),
# X1, X7 y X3 en V2 (emitirCobro): el bloque de la mesa entero, con lo de W2 que se fue (hasta antes de «let doc = null, body = null;»)
("""      if (reclamar && !rcPedido && rc && rc.clave && this.esRestaurante && !this.cobroParcial && esperaId !== null && esperaId !== undefined && this.esperaId === esperaId) {
        const sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid));
        if (sin1.size) {
          """ + REFRESCAR15 + """
          const c1 = enEspera().find(v => v.id === esperaId), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : [];
          if (ls.length) {
            /* 4.39 (sexta vuelta): se espera solo lo que falta (la marca, con la hora de esa comanda) y después se junta lo que otro equipo guardó, como en la */
            /* venta rápida: si la cuenta ya no está o cambió (un plato quitado durante la espera), no se cobra nada y el cobro pedido queda libre */
            """ + MARCA('esperaId') + """ const falta = this._marcaAjena.t + 4000 - Date.now(); if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000)));
            """ + REFRESCAR3 + """
            if (!enEspera().some(v => v.id === esperaId)) { this.soltarCobro(rc, false); return this.cobroOcupado({ resultado: 'cobrada', comunes: [] }); }
            """ + GUARDAR3 + """
            const cambio2 = this.cobroCambiado(esperaId, lineasCobradas, total, false); if (cambio2) { this.soltarCobro(rc, false); return cambio2; }
          }
        }
      }
      /* 4.39 (sexta vuelta): «Dividir → Cobrar estos platos» en la venta rápida: los platos de la parte que no se habían enviado salen a cocina al cobrarla, como */
      /* el resto de la venta rápida (antes se cobraban y nunca llegaban). Después de pedir el cobro y sin guardar nada (la parte no es una cuenta) */
      if (this.esRestaurante && this.cobroParcial && this.cobroParcial.rapida && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))) { try { this.enviarComanda(); } catch { /* la comanda no detiene el cobro */ } }
""",
"""      if (reclamar && !rcPedido && rc && rc.clave && this.esRestaurante && !this.cobroParcial && esperaId !== null && esperaId !== undefined && this.esperaId === esperaId) {
        /* 4.39 (séptima vuelta): también si arriba se esperó la comanda de otro equipo (esperoMarca): después de esperar se junta lo que ese equipo guardó */
        /* (también la cuenta guardada sin platos por enviar). Y si al juntar llegó una comanda más nueva suya (la marca se renovó), se espera y se junta otra vez */
        const sin1 = new Set(this.lineas.filter(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l)).map(l => l.lid)); let junta = esperoMarca;
        if (sin1.size) {
          """ + REFRESCAR15 + """
          const c1 = enEspera().find(v => v.id === esperaId), ls = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && """ + RECIENTE + """) : [];
          /* 4.39 (sexta vuelta): se espera solo lo que falta (la marca, con la hora de esa comanda) y después se junta lo que otro equipo guardó, como en la */
          /* venta rápida: si la cuenta ya no está o cambió (un plato quitado durante la espera), no se cobra nada y el cobro pedido queda libre */
          if (ls.length) { """ + MARCA('esperaId') + """ junta = true; }
        }
        for (let k = 0; junta && k < 2; k++) {
          { const m2 = this._marcaAjena, falta = m2 && m2.id === esperaId ? m2.t + 4000 - Date.now() : 0; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }
          """ + REFRESCAR3 + """
          if (!enEspera().some(v => v.id === esperaId)) { this.soltarCobro(rc, false); return this.cobroOcupado({ resultado: 'cerrada', comunes: [] }); }
          """ + GUARDAR3 + """
          const cambio2 = this.cobroCambiado(esperaId, lineasCobradas, total, false); if (cambio2) { this.soltarCobro(rc, false); return cambio2; }
          junta = """ + VIGENTE('esperaId') + """;
        }
      }
""", 1),
]


def _sin_septima(texto: str) -> str:
    """caja.js con lo de la séptima vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(SEPTIMA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_septima() -> str:
    # 4.39 (octava vuelta): parte de caja.js sin la octava vuelta (la octava cambió líneas que SEPTIMA busca: la revisión «vistos» de cobrarParte y
    # de confirmarDividir, la firma de X2, D0 y el aviso de «cerrada» en cobroOcupado)
    return _sin_septima(_caja_sin_octava())


# ================================================================================================================ la octava vuelta, deshecha
# 4.39 (octava vuelta): los cambios de la octava vuelta (Y1 a Y5), tal como se aplicaron a caja.js: cada tripleta (lo de antes, lo de ahora,
# cuántas veces está) se deshace con un reemplazo exacto, en orden inverso (comprobado byte a byte contra la copia de caja.js de antes de la
# octava vuelta); _caja_sin_septima parte de caja.js sin la octava vuelta. tests/test_439_octava_vuelta.py usa _caja_sin_octava para sus
# versiones «de antes». FIRMA_ENV: la firma de las líneas de una cuenta con lid, cantidad y marca de envío (Y3 y Y5)
FIRMA_ENV = "(ls || []).map(l => String(l && l.lid) + ':' + (+(l && l.cantidad) || 0) + ':' + String((l && l.enviado) || '')).sort().join('|')"
OCTAVA = [
# Y2: una línea del servidor sin lid nunca se guardó: no cuenta como mandada por otro equipo (pedido en línea con un plato agregado aquí); en
# cobrarParte y en confirmarDividir
("""vistos = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && this.destinoDe(l)) : []""",
"""vistos = c1 ? (c1.lineas || []).filter(l => l && l.lid && l.enviado && sin1.has(l.lid) && this.destinoDe(l)) : []""", 2),
# Y5 (y sin base no se compara): la firma de X2 lleva la marca de envío (una segunda «Comanda» del otro equipo durante la espera)
("""          const firma = ls => (ls || []).map(l => String(l && l.lid) + ':' + (+(l && l.cantidad) || 0)).sort().join('|'), c2 = enEspera().find(v => v.id === id1);""",
"""          /* 4.39 (octava vuelta): la firma lleva también la marca de envío: una segunda «Comanda» del otro equipo durante la espera hace volver a dividir */
          const firma = ls => """ + FIRMA_ENV + """, c2 = enEspera().find(v => v.id === id1);""", 1),
("""          if (!c2 || firma(ponerLids(JSON.parse(JSON.stringify(c2))).lineas) !== firma(this._base && this._base.id === id1 ? this._base.lineas : [])) {""",
"""          if (!c2 || (this._base && this._base.id === id1 && firma(ponerLids(JSON.parse(JSON.stringify(c2))).lineas) !== firma(this._base.lineas))) {""", 1),
# Y3 + Y4: la cuenta cobrada en parte o cambiada mientras «Dividir» estaba abierto, y en la caja de comercio con la lista traída aquí
("""      { const idx = this.esperaId, bx = this._base; if ((d.modo === 'partes' || d.destino !== 'cobrar') && idx !== null && idx !== undefined && (!!(bx && bx.id === idx && bx.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', idx))) && !enEspera().some(v => v.id === idx)) { this.dividir = null; this.sincronizar(); return; } }""",
"""      /* 4.39 (octava vuelta): también si otro equipo cobró una parte, quitó o cambió un plato mientras «Dividir» estaba abierto (lo partido se llevaba lo ya */
      /* cobrado a otra cuenta, por cobrar otra vez): la cuenta del servidor se compara con la que esta pantalla conoce (su base) y, si cambió, se vuelve a */
      /* abrir «Dividir». En la caja de comercio la lista se trae aquí (en el restaurante ya se trajo arriba) */
      { const idx = this.esperaId, bx = this._base;
        if ((d.modo === 'partes' || d.destino !== 'cobrar') && idx !== null && idx !== undefined && (!!(bx && bx.id === idx && bx.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', idx)))) {
          if (!this.esRestaurante) { """ + REFRESCAR15 + """ if (this.dividir !== d || this.esperaId !== idx) return; }
          const cx = enEspera().find(v => v.id === idx); if (!cx) { this.dividir = null; this.sincronizar(); return; }
          const fm = ls => """ + FIRMA_ENV + """;
          if (this._base && this._base.id === idx && fm(ponerLids(JSON.parse(JSON.stringify(cx))).lineas) !== fm(this._base.lineas)) { this._alDia = 0; this.dividir = null; return toast('La cuenta cambió en otro equipo. Vuelva a abrir «Dividir» para verla al día.', 'err'); }
        } }""", 1),
# Y1: el aviso neutro de «cerrada» solo si la cuenta sigue en pantalla (si una sincronización ya la cerró, queda solo el aviso de sincronizar)
("""      else { if (res === 'cerrada') toast(""",
"""      else { if (res === 'cerrada' && this.esperaId) toast(""", 1),
]


def _sin_octava(texto: str) -> str:
    """caja.js con lo de la octava vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(OCTAVA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_octava() -> str:
    # 4.39 (novena vuelta): parte de caja.js sin la novena vuelta (la novena cambió líneas que OCTAVA busca: la firma de X2 y su comparación, la firma
    # de Y3 y el comentario de arriba del bloque de Y3/Y4)
    return _sin_octava(_caja_sin_novena())


# ================================================================================================================ la novena vuelta, deshecha
# 4.39 (novena vuelta): los cambios de la novena vuelta (Z1 y Z3 en X2 y en Y3, el comentario del bloque de Y3/Y4 y Z2), tal como se aplicaron a
# caja.js: cada tripleta (lo de antes, lo de ahora, cuántas veces está) se deshace con un reemplazo exacto, en orden inverso (comprobado byte a byte
# contra la copia de caja.js de antes de la novena vuelta); _caja_sin_octava parte de caja.js sin la novena vuelta. tests/test_439_novena_vuelta.py
# usa _caja_sin_novena para sus versiones «de antes». FIRMA_LINEA: la firma de UNA línea con lid, cantidad, marca de envío, precio, descuento y nota
FIRMA_LINEA = ("String(l && l.lid) + ':' + (+(l && l.cantidad) || 0) + ':' + String((l && l.enviado) || '') + ':' + (+(l && l.precio_unitario) || 0) + ':' + "
               "(+(l && l.descuento_pct) || 0) + ':' + (+(l && l.descuento) || 0) + ':' + String((l && l.nota) || '')")
NOVENA = [
# Z1 + Z3 en X2 (después de esperar la marca): cada línea de la base sigue igual en el servidor y el mismo servicio; las agregadas no cuentan
("""          const firma = ls => """ + FIRMA_ENV + """, c2 = enEspera().find(v => v.id === id1);
          if (!c2 && ex1) { this.dividir = null; this.sincronizar(); return; }
          if (!c2 || (this._base && this._base.id === id1 && firma(ponerLids(JSON.parse(JSON.stringify(c2))).lineas) !== firma(this._base.lineas))) {""",
"""          /* 4.39 (novena vuelta): como abajo, cada plato que esta pantalla conoce (su base) tiene que seguir igual en el servidor (cantidad, envío, precio, */
          /* descuento y nota) y también el servicio; un plato que otro equipo solo agregó no detiene la división (queda en la cuenta de origen) */
          const firma = l => """ + FIRMA_LINEA + """, c2 = enEspera().find(v => v.id === id1);
          if (!c2 && ex1) { this.dividir = null; this.sincronizar(); return; }
          const s2 = c2 ? new Set((ponerLids(JSON.parse(JSON.stringify(c2))).lineas || []).map(firma)) : null;
          if (!c2 || (this._base && this._base.id === id1 && ((this._base.lineas || []).some(l => !s2.has(firma(l))) || !!c2.servicio !== !!(this._base.cuenta || {}).servicio))) {""", 1),
# Z1 + Z3 en Y3 (al separar, pasar o partir una cuenta guardada)
("""          const fm = ls => """ + FIRMA_ENV + """;
          if (this._base && this._base.id === idx && fm(ponerLids(JSON.parse(JSON.stringify(cx))).lineas) !== fm(this._base.lineas)) {""",
"""          /* 4.39 (novena vuelta): cada plato que esta pantalla conoce (su base) tiene que seguir igual en el servidor: cantidad, envío, precio, descuento y nota, */
          /* y también el servicio de la cuenta (antes un descuento o un precio cambiado en otro equipo se perdía al dividir). Un plato que otro equipo solo */
          /* agregó no detiene la división: queda en la cuenta de origen y, si lo mandó a cocina, su comanda la encuentra */
          const fm = l => """ + FIRMA_LINEA + """, sv = new Set((ponerLids(JSON.parse(JSON.stringify(cx))).lineas || []).map(fm));
          if (this._base && this._base.id === idx && ((this._base.lineas || []).some(l => !sv.has(fm(l))) || !!cx.servicio !== !!(this._base.cuenta || {}).servicio)) {""", 1),
# el comentario de arriba del bloque de Y3/Y4: las partes de una mesa traen la lista después (en cobrarParte)
("""      /* abrir «Dividir». En la caja de comercio la lista se trae aquí (en el restaurante ya se trajo arriba) */""",
"""      /* abrir «Dividir». En la caja de comercio la lista se trae aquí (en el restaurante ya se trajo arriba, salvo en las partes de una mesa, que la traen */
      /* después, en cobrarParte) */""", 1),
# Z2: las partes de una mesa se calculan con la cuenta traída en el acto (_alDia = 0 antes de cobrarParte)
("""        if (this.esRestaurante && this.mesaActual) { if (pre0 > 0) return toast(yaPago + ': el cobro en partes iguales no lo descuenta; cobre la cuenta completa o pase platos a una cuenta aparte', 'err'); return this.cobrarParte(n); }""",
"""        /* 4.39 (novena vuelta): las partes de una mesa se calculan con la cuenta traída en el acto (alDiaParaCobrar en cobrarParte), aunque «Dividir» se haya */
        /* abierto hace menos de 3 s: antes se podía cobrar la parte de un plato que otro equipo acababa de quitar o bajar */
        if (this.esRestaurante && this.mesaActual) { if (pre0 > 0) return toast(yaPago + ': el cobro en partes iguales no lo descuenta; cobre la cuenta completa o pase platos a una cuenta aparte', 'err'); this._alDia = 0; return this.cobrarParte(n); }""", 1),
]


def _sin_novena(texto: str) -> str:
    """caja.js con lo de la novena vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(NOVENA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_novena() -> str:
    # 4.39 (décima vuelta): parte de caja.js sin la décima vuelta (la décima cambió dos consultas de confirmarDividir que cuentan como REFRESCAR15 y
    # agregó la revisión P1; así el resultado es, byte a byte, el caja.js de antes de la novena vuelta)
    return _sin_novena(_caja_sin_decima())


# ================================================================================================================ la décima vuelta, deshecha
# 4.39 (décima vuelta): los cambios de la décima vuelta (R1 en las dos consultas del restaurante de confirmarDividir y P1 al pasar todo un pedido en
# línea o con prepago a una cuenta aparte), tal como se aplicaron a caja.js: cada tripleta (lo de antes, lo de ahora, cuántas veces está) se deshace
# con un reemplazo exacto, en orden inverso (comprobado byte a byte contra la copia de caja.js de antes de la décima vuelta); _caja_sin_novena parte
# de caja.js sin la décima vuelta. tests/test_439_decima_vuelta.py usa _caja_sin_decima para sus versiones «de antes». ESPERA_R1: el tope de espera
# de esas dos consultas (3 s con platos por enviar al separar, pasar o partir; si no, 1,5 s como antes)
ESPERA_R1 = "sin1.size && (d.modo === 'partes' || d.destino !== 'cobrar') ? 3000 : 1500"
DECIMA = [
# R1: con platos por enviar, al separar, pasar o partir, la consulta antes de partir espera la lista hasta 3 s (como el cobro)
("""        if (sin1.size || (ex1 && (d.modo === 'partes' || d.destino !== 'cobrar'))) { try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 1500))]); }""",
"""        /* 4.39 (décima vuelta): con platos por enviar, al separar, pasar o partir, las dos consultas de aquí esperan la lista hasta 3 s (como el cobro): con la */
        /* red lenta se partía con la copia vieja y lo que otro equipo acababa de mandar a cocina quedaba «sin enviar» en la otra cuenta y volvía a salir */
        if (sin1.size || (ex1 && (d.modo === 'partes' || d.destino !== 'cobrar'))) { try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, sin1.size && (d.modo === 'partes' || d.destino !== 'cobrar') ? 3000 : 1500))]); }""", 1),
# R1 en X2 (después de esperar la marca)
("""        if (espero) {
          try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 1500))]); } catch { /* sigue con la copia */ }""",
"""        if (espero) {
          try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, sin1.size && (d.modo === 'partes' || d.destino !== 'cobrar') ? 3000 : 1500))]); } catch { /* sigue con la copia */ }""", 1),
# P1: pasar TODO un pedido en línea (o ya pagado) a una cuenta aparte con un plato que otro equipo le agregó
("""        const ex = this.datosCredito(c0), todo = !resto.length && c0 && (c0.canal === 'online' || (c0.prepago && +c0.prepago.monto > 0));
""",
"""        const ex = this.datosCredito(c0), todo = !resto.length && c0 && (c0.canal === 'online' || (c0.prepago && +c0.prepago.monto > 0));
        /* 4.39 (décima vuelta): si el servidor tiene un plato que esta pantalla no conoce (lo agregó otro equipo), no se pasa todo: la cuenta del pedido seguía */
        /* con ese plato, con lo ya pagado en línea y con el enlace del pedido, y la cuenta aparte también (se descontaba dos veces) */
        { const ib = this.esperaId, bb = this._base; if (todo && ib !== null && ib !== undefined && bb && bb.id === ib) { const cs = enEspera().find(v => v.id === ib), bl = new Set((bb.lineas || []).map(l => l.lid)); if (cs && (ponerLids(JSON.parse(JSON.stringify(cs))).lineas || []).some(l => !bl.has(l.lid))) { this._alDia = 0; this.dividir = null; return toast('La cuenta cambió en otro equipo. Vuelva a abrir «Dividir» para verla al día.', 'err'); } } }
""", 1),
]


def _sin_decima(texto: str) -> str:
    """caja.js con lo de la décima vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(DECIMA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_decima() -> str:
    # 4.39 (undécima vuelta): parte de caja.js sin la undécima vuelta (la undécima cambió las dos consultas de R1, que DECIMA busca con ESPERA_R1, y su
    # comentario; así el resultado es, byte a byte, el caja.js de antes de la décima vuelta)
    return _sin_decima(_caja_sin_undecima())


# ================================================================================================================ la undécima vuelta, deshecha
# 4.39 (undécima vuelta): los cambios de la undécima vuelta (Q1 y Q2 en las tres consultas de confirmarDividir, Q3 y Q4 en confirmarDividir y Q5 en
# imprimirComandaWeb), tal como se aplicaron a caja.js: cada tripleta (lo de antes, lo de ahora, cuántas veces está) se deshace con un reemplazo exacto,
# en orden inverso (comprobado byte a byte contra la copia de caja.js de antes de la undécima vuelta); _caja_sin_decima parte de caja.js sin la undécima
# vuelta. tests/test_439_undecima_vuelta.py usa _caja_sin_undecima para sus versiones «de antes». Los textos van armados tal cual (el guion de la vuelta
# armaba los de las consultas de R1 con el tope de antes, que es ESPERA_R1)
UNDECIMA = [
# Q1 + Q2: el comentario de las consultas de «Dividir»
("""        /* 4.39 (décima vuelta): con platos por enviar, al separar, pasar o partir, las dos consultas de aquí esperan la lista hasta 3 s (como el cobro): con la */
        /* red lenta se partía con la copia vieja y lo que otro equipo acababa de mandar a cocina quedaba «sin enviar» en la otra cuenta y volvía a salir */
""",
"""        /* 4.39 (undécima vuelta): las consultas de «Dividir» (estas dos y la de la caja de comercio) esperan la lista hasta 3 s, como el cobro: con la red lenta */
        /* se partía con la copia vieja (lo que otro equipo acababa de mandar a cocina volvía a salir, y lo que ya había cobrado o quitado pasaba a la otra */
        /* cuenta). Si mientras tanto «Dividir» se canceló o se volvió a tocar, no se avisa (el aviso salía falso, o dos veces) */
""", 1),
# Q1 + Q2: la consulta de antes de partir espera hasta 3 s siempre; después, si «Dividir» se canceló o se volvió a tocar, sale sin revisar «vistos»
("""new Promise(r => setTimeout(r, sin1.size && (d.modo === 'partes' || d.destino !== 'cobrar') ? 3000 : 1500))]); } catch { /* sigue con la copia */ } const c1 = enEspera().find(v => v.id === id1),""",
"""new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con la copia */ } if (this.dividir !== d || this.esperaId !== id1) return; const c1 = enEspera().find(v => v.id === id1),""", 1),
# Q1 en X2 (después de esperar la marca)
("""        if (espero) {
          try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, sin1.size && (d.modo === 'partes' || d.destino !== 'cobrar') ? 3000 : 1500))]); } catch { /* sigue con la copia */ }""",
"""        if (espero) {
          try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con la copia */ }""", 1),
# Q1 en la caja de comercio (Y3/Y4)
("""          if (!this.esRestaurante) { try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 1500))]); } catch { /* sigue con la copia */ } if (this.dividir !== d || this.esperaId !== idx) return; }""",
"""          if (!this.esRestaurante) { try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con la copia */ } if (this.dividir !== d || this.esperaId !== idx) return; }""", 1),
# Q3: un pedido en línea no se pasa entero a una mesa
("""      // cobrar ahora solo esos platos (3.46): el resto sigue en la mesa; el cobro queda anotado en la cuenta
""",
"""      /* 4.39 (undécima vuelta): un pedido en línea tampoco se pasa entero a una mesa: la cuenta de la mesa no lleva el enlace con el pedido (no quedaba ligado */
      /* a su comprobante, el cliente no recibía sus puntos y el pedido a crédito se cobraba de contado) */
      if (!resto.length && d.destino !== 'cobrar' && d.destino !== 'nueva' && c0 && c0.canal === 'online') return toast('Este pedido en línea no se puede pasar entero a una mesa: páselo a una cuenta aparte o cóbrelo aquí', 'err');
      // cobrar ahora solo esos platos (3.46): el resto sigue en la mesa; el cobro queda anotado en la cuenta
""", 1),
# Q4: pasar todo con prepago a una cuenta aparte: la baja de la cuenta de origen va como la de un cobro
("""      this.lineas = resto; this.dividir = null;
      if (!this.lineas.length) { if (this.esperaId) { const id = this.esperaId; if (mock.condicionBaja) this.bajaCuenta(id, (this.baseDe(id, c0) || { lineas: [] }).lineas, this.nombreEspera); else""",
"""      this.lineas = resto; this.dividir = null;
      /* 4.39 (undécima vuelta): si lo ya pagado en línea se fue con todo a la cuenta aparte, la baja de esta va como la de un cobro: si otro equipo le agregó un */
      /* plato en esos segundos, la cuenta que queda con él no conserva lo ya pagado (antes se descontaba dos veces) */
      if (!this.lineas.length) { if (this.esperaId) { const id = this.esperaId; if (mock.condicionBaja) this.bajaCuenta(id, (this.baseDe(id, c0) || { lineas: [] }).lineas, this.nombreEspera, d.destino === 'nueva' && pre0 > 0); else""", 1),
# Q5: en el programa, el pedido aceptado aquí no vuelve a sonar ni a contarse cuando su cuenta entra a la caja
("""      if (this.enProgWeb) { const ok = await this.aceptarWeb(p); if (ok && eraNuevo""",
"""      /* 4.39 (undécima vuelta): en el programa, el pedido aceptado aquí queda como ya avisado: cuando su cuenta entra a la caja no vuelve a sonar ni a contarse */
      if (this.enProgWeb) { const ok = await this.aceptarWeb(p); if (ok) (this._entAvisados || (this._entAvisados = new Set())).add(+p.id); if (ok && eraNuevo""", 1),
]


def _sin_undecima(texto: str) -> str:
    """caja.js con lo de la undécima vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(UNDECIMA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_undecima() -> str:
    # 4.39 (duodécima vuelta): parte de caja.js sin la duodécima vuelta (la duodécima cambió la línea de Q5 en imprimirComandaWeb; así el resultado
    # es, byte a byte, el caja.js de antes de la undécima vuelta)
    return _sin_undecima(_caja_sin_duodecima())


# ================================================================================================================ la duodécima vuelta, deshecha
# 4.39 (duodécima vuelta): los cambios de la duodécima vuelta (W1 en aceptarWeb, W2 en imprimirComandaWeb, en el programa y en la página web, y en
# cancelarWeb, W3 en avisarEntrados), tal como se aplicaron a caja.js: cada tripleta (lo de antes, lo de ahora, cuántas veces está) se deshace con un
# reemplazo exacto, en orden inverso (comprobado byte a byte contra la copia de caja.js de antes de la duodécima vuelta); _caja_sin_undecima parte de
# caja.js sin la duodécima vuelta. tests/test_439_duodecima_vuelta.py usa _caja_sin_duodecima para sus versiones «de antes». Los textos van armados tal
# cual (el guion de la vuelta armaba los de W2 con la línea que baja el número del botón «Pedidos web»)
DUODECIMA = [
# W1: en el programa, «Aceptar pedido» (no sale comanda) no dice que la comanda sale sola
("""        toast(r && r.mensaje ? r.mensaje : 'Pedido #' + ((r && r.numero) || p.numero) + ' aceptado: ya está en la caja y su comanda sale sola en unos segundos.', 'ok');
""",
"""        /* 4.39 (duodécima vuelta): si se sabe que no sale comanda («Aceptar pedido»), el aviso no dice que sale sola */
        toast(pw.imprime === false ? 'Pedido #' + ((r && r.numero) || p.numero) + ' aceptado: ya está en la caja.' : r && r.mensaje ? r.mensaje : 'Pedido #' + ((r && r.numero) || p.numero) + ' aceptado: ya está en la caja y su comanda sale sola en unos segundos.', 'ok');
""", 1),
# W2 en el programa (imprimirComandaWeb): si la consulta de pedidos llegó mientras se aceptaba, se vuelve a leer
("""      /* 4.39 (undécima vuelta): en el programa, el pedido aceptado aquí queda como ya avisado: cuando su cuenta entra a la caja no vuelve a sonar ni a contarse */
      if (this.enProgWeb) { const ok = await this.aceptarWeb(p); if (ok) (this._entAvisados || (this._entAvisados = new Set())).add(+p.id); if (ok && eraNuevo && this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) }; if (ok && this.panelWeb === pw && +pw.ver === +p.id) pw.ver = null; return; }""",
"""      /* 4.39 (undécima vuelta): en el programa, el pedido aceptado aquí queda como ya avisado: cuando su cuenta entra a la caja no vuelve a sonar ni a contarse */
      /* 4.39 (duodécima vuelta): si la consulta de pedidos llegó mientras se aceptaba, contaba todavía este pedido: se vuelve a leer (no se espera) */
      if (this.enProgWeb) { const ok = await this.aceptarWeb(p); if (ok) (this._entAvisados || (this._entAvisados = new Set())).add(+p.id); if (ok && eraNuevo) { if (this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) }; else this.revisarOnline(); } if (ok && this.panelWeb === pw && +pw.ver === +p.id) pw.ver = null; return; }""", 1),
# W2 en la página web (imprimirComandaWeb)
("""        const ok = await a.aceptarComo(p, null);
        if (ok && eraNuevo && this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) };""",
"""        const ok = await a.aceptarComo(p, null);
        if (ok && eraNuevo) { if (this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) }; else this.revisarOnline(); }""", 1),
# W2 en cancelarWeb
("""        if (eraNuevo && this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) };   /* 4.39 (prueba de punta a punta): el botón «Pedidos web» deja de contarlo ya */""",
"""        /* 4.39 (duodécima vuelta): si la consulta de pedidos llegó mientras se cancelaba, se vuelve a leer */
        if (eraNuevo) { if (this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) }; else this.revisarOnline(); }   /* 4.39 (prueba de punta a punta): el botón «Pedidos web» deja de contarlo ya */""", 1),
# W3: avisarEntrados: la primera respuesta no olvida lo ya aceptado aquí
("""        if (this._entPiso === undefined || this._entPiso === null) { this._entPiso = ent; this._entTope = ent; this._entIntentos = 0; this._entAvisados = new Set(); return; }""",
"""        if (this._entPiso === undefined || this._entPiso === null) { this._entPiso = ent; this._entTope = ent; this._entIntentos = 0; this._entAvisados = this._entAvisados || new Set(); return; }""", 1),
# W3: el piso sube solo cuando la cuenta del tope está en la lista traída (o a los 6 intentos), como en la 4.38
("""        if (this._entAvisados.has(tope) || ++this._entIntentos >= 6) this._entPiso = tope;""",
"""        /* 4.39 (duodécima vuelta): el piso sube cuando la cuenta del tope está en la lista traída (como antes): el pedido aceptado aquí ya figura como avisado */
        /* antes de llegar, y si el piso subía con la lista atrasada, otro pedido que entró en esos segundos se quedaba sin aviso. La primera respuesta no */
        /* olvida lo aceptado aquí */
        if (enEspera().some(v => v && v.canal === 'online' && +v.pedido_id === tope) || ++this._entIntentos >= 6) this._entPiso = tope;""", 1),
]


def _sin_duodecima(texto: str) -> str:
    """caja.js con lo de la duodécima vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(DUODECIMA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_duodecima() -> str:
    # 4.39 (decimotercera vuelta): parte de caja.js sin la decimotercera vuelta (la decimotercera metió su línea en aceptarWeb justo antes del comentario
    # de W1; así el resultado es, byte a byte, el caja.js de antes de la duodécima vuelta)
    return _sin_duodecima(_caja_sin_decimotercera())


# ================================================================================================================ la decimotercera vuelta, deshecha
# 4.39 (decimotercera vuelta): los cambios de la decimotercera vuelta (V1 en aceptarWeb, V2 en la casilla de la cantidad de la plantilla y en quitar,
# V3 en cobrarParte, V4 en sincronizar, V5 y V6 en confirmarDividir), tal como se aplicaron a caja.js (los siete del guion y, al final, el comentario
# de V6 en su propia línea): cada tripleta (lo de antes, lo de ahora, cuántas veces está) se deshace con un reemplazo exacto, en orden inverso
# (comprobado byte a byte contra la copia de caja.js de antes de la decimotercera vuelta); _caja_sin_duodecima parte de caja.js sin la decimotercera
# vuelta. tests/test_439_decimotercera_vuelta.py usa _caja_sin_decimotercera para sus versiones «de antes». Los textos van armados tal cual
DECIMOTERCERA = [
# V1 aceptarWeb (programa): el pedido queda como ya avisado en cuanto el PUT sale bien (antes de recargar la ventana)
("""        catch (e) { toast(e.message, 'err'); return; }
        /* 4.39 (duodécima vuelta): si se sabe que no sale comanda («Aceptar pedido»), el aviso no dice que sale sola */""",
"""        catch (e) { toast(e.message, 'err'); return; }
        /* 4.39 (decimotercera vuelta): el pedido queda como ya avisado en cuanto se acepta, antes de recargar la ventana: si la consulta de pedidos llegaba */
        /* mientras tanto, su cuenta ya estaba en la caja y volvía a sonar «Entró a la caja…» */
        (this._entAvisados || (this._entAvisados = new Set())).add(+p.id);
        /* 4.39 (duodécima vuelta): si se sabe que no sale comanda («Aceptar pedido»), el aviso no dice que sale sola */""", 1),
# V2 la casilla de la cantidad (plantilla): 0 o vacío quita el plato, como ✕
("""v-model.number="l.cantidad" @change="aplicarPromos(l)" style="width:58px;text-align:center">""",
"""v-model.number="l.cantidad" @change="+l.cantidad > 0 ? aplicarPromos(l) : quitar(l)" style="width:58px;text-align:center">""", 1),
# V2 quitar: también con 0 en la casilla; si no se da la clave de anular, la línea vuelve a la cantidad guardada
("""    async quitar(l) { if (l.enviado && this.cfg.clave_anular && !(await this.autorizar('Quitar ' + l.detalle + ' ya enviado a cocina'))) return; this.lineas""",
"""    /* 4.39 (decimotercera vuelta): también con 0 en la casilla de la cantidad (antes la pantalla escondía el plato pero la cuenta guardada lo conservaba y se */
    /* cobraba después); si no se da la clave, la línea vuelve a la cantidad guardada */
    async quitar(l) { if (l.enviado && this.cfg.clave_anular && !(await this.autorizar('Quitar ' + l.detalle + ' ya enviado a cocina'))) { if (!(+l.cantidad > 0)) { const b = ((this._base && this._base.id === this.esperaId && this._base.lineas) || []).find(x => x.lid === l.lid); l.cantidad = b && +b.cantidad > 0 ? +b.cantidad : 1; } return; } this.lineas""", 1),
# V3 cobrarParte: lo que queda de cada línea sale de su propia parte (no de la parte de la lista ya filtrada)
("""      const resto = ultima ? [] : this.lineas.map((l, i) => restoDe(l, Math.round((+l.cantidad - (parte[i] ? parte[i].cantidad : 0)) * 1000) / 1000)).filter(l => l.cantidad > 0);""",
"""      /* 4.39 (decimotercera vuelta): lo que queda de cada línea sale de su propia parte: con una línea en 0 la parte filtrada se corría de posición y se cobraba de más */
      const resto = ultima ? [] : this.lineas.map(l => restoDe(l, Math.round(((+l.cantidad || 0) - Math.round(((+l.cantidad || 0) / faltan) * 1000) / 1000) * 1000) / 1000)).filter(l => l.cantidad > 0);""", 1),
# V4 sincronizar: la cuenta abierta cobrada o cerrada en otro equipo cierra «Dividir»
("""        if (nuevas.length) { this.lineas = nuevas; this.esperaId = null; if (this.esRestaurante && !this.mesaActual && this.vista === 'venta') this.rapida = true; }""",
"""        /* 4.39 (decimotercera vuelta): «Dividir» se cierra, como en cerradaAfuera: si no, quedaba encima y su selección (por posición) se llevaba otro plato */
        this.dividir = null;
        if (nuevas.length) { this.lineas = nuevas; this.esperaId = null; if (this.esRestaurante && !this.mesaActual && this.vista === 'venta') this.rapida = true; }""", 1),
# V5 confirmarDividir (paso 4): las partes iguales de una mesa no se comparan aquí (cobrarParte trae y junta)
("""        if ((d.modo === 'partes' || d.destino !== 'cobrar') && idx !== null && idx !== undefined && (!!(bx && bx.id === idx && bx.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', idx)))) {""",
"""        /* 4.39 (decimotercera vuelta): las partes de una mesa no se comparan aquí: cobrarParte trae y junta la cuenta y calcula con ella (si la sincronización */
        /* de siempre ya había traído el cambio, aquí pedía volver a abrir «Dividir») */
        if ((d.modo === 'partes' || d.destino !== 'cobrar') && !(d.modo === 'partes' && this.esRestaurante && this.mesaActual) && idx !== null && idx !== undefined && (!!(bx && bx.id === idx && bx.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', idx)))) {""", 1),
# V6 confirmarDividir (rama de la mesa): una mesa unida a esta misma cuenta avisa y no cambia nada
("""const cu = cuentaDeMesa(m.id, this.cfg.id); if (cu) {""",
"""const cu = cuentaDeMesa(m.id, this.cfg.id); if (cu && cu.id === this.esperaId) return toast(m.nombre + ' ya está unida a esta cuenta', 'err'); if (cu) {""", 1),
# V6: su comentario, en una línea aparte antes de la rama de la mesa (se aplicó al final)
("""      else { const m = this.mesas.find(x => x.id === d.destino); if (!m) return toast('Elija la mesa', 'err'); const cu = cuentaDeMesa(m.id, this.cfg.id); if (cu && cu.id === this.esperaId)""",
"""      /* 4.39 (decimotercera vuelta): una mesa unida a esta misma cuenta no es otra cuenta: antes se duplicaba el plato y, al pasar todos, la cuenta se borraba sin cobrar */
      else { const m = this.mesas.find(x => x.id === d.destino); if (!m) return toast('Elija la mesa', 'err'); const cu = cuentaDeMesa(m.id, this.cfg.id); if (cu && cu.id === this.esperaId)""", 1),
]


def _sin_decimotercera(texto: str) -> str:
    """caja.js con lo de la decimotercera vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(DECIMOTERCERA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_decimotercera() -> str:
    # 4.39 (decimocuarta vuelta): parte de caja.js sin la decimocuarta vuelta (la decimocuarta cambió la línea de quitar que V2 busca y el comentario de V6;
    # así el resultado es, byte a byte, el caja.js de antes de la decimotercera vuelta)
    return _sin_decimotercera(_caja_sin_decimocuarta())


# ================================================================================================================ la decimocuarta vuelta, deshecha
# 4.39 (decimocuarta vuelta): los cambios de la decimocuarta vuelta (U1 en quitar, U2 en tecla, U3 en fusionarAbierta, U4 en confirmarDividir, U5 en «A
# dónde» de la plantilla y U6, el comentario de V6 en confirmarDividir), tal como se aplicaron a caja.js: cada tripleta (lo de antes, lo de ahora, cuántas
# veces está) se deshace con un reemplazo exacto, en orden inverso (comprobado byte a byte contra la copia de caja.js de antes de la decimocuarta vuelta);
# _caja_sin_decimotercera parte de caja.js sin la decimocuarta vuelta. tests/test_439_decimocuarta_vuelta.py usa _caja_sin_decimocuarta para sus versiones
# «de antes». Los textos van tal cual los aplicó el guion de la vuelta (U2 se metió entre la línea de la habitación y su comentario de la tercera vuelta).
# 4.39 (decimoquinta vuelta): la decimoquinta devolvió ese comentario al final de la línea de la habitación y cambió la línea de U2; las tripletas de aquí
# no cambian porque se deshacen sobre caja.js sin la decimoquinta (_caja_sin_decimocuarta parte de _caja_sin_decimoquinta), donde U2 sigue como lo dejó
# el guion de la decimocuarta
DECIMOCUARTA = [
# U1: quitar devuelve la cantidad guardada (y el 2x1 de la base) ANTES de pedir la clave
("""    async quitar(l) { if (l.enviado && this.cfg.clave_anular && !(await this.autorizar('Quitar ' + l.detalle + ' ya enviado a cocina'))) { if (!(+l.cantidad > 0)) { const b = ((this._base && this._base.id === this.esperaId && this._base.lineas) || []).find(x => x.lid === l.lid); l.cantidad = b && +b.cantidad > 0 ? +b.cantidad : 1; } return; } this.lineas""",
"""    /* 4.39 (decimocuarta vuelta): la cantidad guardada (y el 2x1 de la base en una línea partida o marcada) vuelve ANTES de pedir la clave: mientras se esperaba, */
    /* la sincronización o el reloj de las promociones veían el plato en 0 (se lo llevaban, o le dejaban el descuento de otra cantidad) */
    async quitar(l) { if (l.enviado && this.cfg.clave_anular) { if (!(+l.cantidad > 0)) { const b = ((this._base && this._base.id === this.esperaId && this._base.lineas) || []).find(x => x.lid === l.lid); l.cantidad = b && +b.cantidad > 0 ? +b.cantidad : 1; if (b && ((typeof l.de === 'string' && l.de !== '') || l.promo_fija || l.promo_fija_de)) for (const k of ['descuento_pct', 'descuento', 'promo', 'promo_fija', 'promo_fija_de']) { if (b[k] === undefined) delete l[k]; else l[k] = JSON.parse(JSON.stringify(b[k])); } this.aplicarPromos(); } if (!(await this.autorizar('Quitar ' + l.detalle + ' ya enviado a cocina'))) return; } this.lineas""", 1),
# U2: F9, F8 y F4 con el cursor en una casilla numérica
("""      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }""",
"""      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }
      /* 4.39 (decimocuarta vuelta): con el cursor en una casilla numérica, F9, F8 y F4 la dejan primero (corre su cambio: el 0 quita el plato o pide la clave) y, si */
      /* tenía 0 o queda un plato en 0, no siguen en esa pulsación: antes se guardaba o se cobraba con el plato en 0 (la cuenta lo conservaba, o salía sin la clave) */
      if (['F9', 'F8', 'F4'].includes(e.key) && !this.pago && e.target && e.target.type === 'number' && typeof e.target.blur === 'function') { const v = e.target.value; e.target.blur(); if (!(+v > 0) || this.lineas.some(l => !(+l.cantidad > 0))) { e.preventDefault(); return; } }""", 1),
# U3: la sincronización no junta mientras se escribe una cantidad (casilla con foco y un plato en 0 o vacío)
("""      if (!this.esperaId || this.pago || this.cobrando || (this.cobroParcial && !cobro) || (this.dividir && !cobro) || this.unir || this.mover || this.lineaNota || this.modSel || this.pedido || this.habCargo) return nada;""",
"""      /* 4.39 (decimocuarta vuelta): tampoco mientras se escribe una cantidad (casilla con el cursor y un plato en 0 o vacío): la línea salía de la pantalla con un */
      /* aviso falso y el plato se borraba de la cuenta guardada sin la clave; la próxima sincronización, o el cobro, juntan */
      if (!this.esperaId || this.pago || this.cobrando || (this.cobroParcial && !cobro) || (this.dividir && !cobro) || this.unir || this.mover || this.lineaNota || this.modSel || this.pedido || this.habCargo || (!cobro && typeof document !== 'undefined' && document.activeElement && document.activeElement.type === 'number' && this.lineas.some(l => !(+l.cantidad > 0)))) return nada;""", 1),
# U4: las partes iguales sin mesa no pasan líneas en 0 a las cuentas nuevas
("""        for (let k = 2; k <= n; k++) this.nuevaCuentaEspera(base + ' · parte ' + k + ' de ' + n, parte.map(x => ({ ...x })), null,""",
"""        /* 4.39 (decimocuarta vuelta): a las cuentas nuevas no pasan líneas cuya parte redondea a 0 (al cobrarlas salía «cambió en otro equipo») */
        for (let k = 2; k <= n; k++) this.nuevaCuentaEspera(base + ' · parte ' + k + ' de ' + n, parte.filter(x => x.cantidad > 0).map(x => ({ ...x })), null,""", 1),
# U5: «A dónde» dice que la mesa unida es de esta misma cuenta
("""{{cuentaDeMesaId(m.id) ? ' (tiene cuenta abierta: se juntan)' : ''}}""",
"""{{cuentaDeMesaId(m.id) ? (cuentaDeMesaId(m.id).id === esperaId ? ' (unida a esta cuenta)' : ' (tiene cuenta abierta: se juntan)') : ''}}""", 1),
# U6: el comentario de V6 describe bien lo de antes
("""una mesa unida a esta misma cuenta no es otra cuenta: antes se duplicaba el plato y, al pasar todos, la cuenta se borraba sin cobrar */""",
"""una mesa unida a esta misma cuenta no es otra cuenta: antes avisaba en falso que los pasó y, al pasar todos, la cuenta se borraba sin cobrar */""", 1),
]


def _sin_decimocuarta(texto: str) -> str:
    """caja.js con lo de la decimocuarta vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(DECIMOCUARTA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_decimocuarta() -> str:
    # 4.39 (decimoquinta vuelta): parte de caja.js sin la decimoquinta vuelta (la decimoquinta cambió la línea de U2 y movió el comentario de la tercera
    # vuelta que la seguía; así el resultado es, byte a byte, el caja.js de antes de la decimocuarta vuelta)
    return _sin_decimocuarta(_caja_sin_decimoquinta())


# ================================================================================================================ la decimoquinta vuelta, deshecha
# 4.39 (decimoquinta vuelta): los dos cambios de la decimoquinta vuelta (T1 en la fila del carrito de la plantilla: :key="l" en vez de :key="i"; T2 en tecla:
# el valor de la casilla solo frena si es la de la cantidad, y el comentario de la tercera vuelta vuelve al final de la línea de la habitación), tal como se
# aplicaron a caja.js: cada tripleta (lo de antes, lo de ahora, cuántas veces está) se deshace con un reemplazo exacto, en orden inverso (comprobado byte a
# byte contra la copia de caja.js de antes de la decimoquinta vuelta); _caja_sin_decimocuarta parte de caja.js sin la decimoquinta vuelta.
# tests/test_439_decimoquinta_vuelta.py usa _caja_sin_decimoquinta para sus versiones «de antes». Los textos van armados como en el guion de la vuelta:
# COM3, el comentario de la tercera vuelta de la línea de la habitación (con sus tres espacios delante); VIEJA_U2 y NUEVA_U2, la línea de U2 antes y ahora
COM3 = "   /* 4.39 (tercera vuelta): con la ventana de la habitación abierta no se cobra, no se manda comanda ni se guarda por debajo (se cobraba o se cargaba dos veces) */"
VIEJA_U2 = "      if (['F9', 'F8', 'F4'].includes(e.key) && !this.pago && e.target && e.target.type === 'number' && typeof e.target.blur === 'function') { const v = e.target.value; e.target.blur(); if (!(+v > 0) || this.lineas.some(l => !(+l.cantidad > 0))) { e.preventDefault(); return; } }"
NUEVA_U2 = "      if (['F9', 'F8', 'F4'].includes(e.key) && !this.pago && e.target && e.target.type === 'number' && typeof e.target.blur === 'function') { const v = e.target.value, cant = typeof e.target.closest !== 'function' || !!e.target.closest('.pos-linea .c'); e.target.blur(); if ((cant && !(+v > 0)) || this.lineas.some(l => !(+l.cantidad > 0))) { e.preventDefault(); return; } }"
DECIMOQUINTA = [
# T1: la fila del carrito se identifica por su línea (no por su posición): con 0 en la casilla, el clic siguiente caía en otro plato
("""          <div v-for="(l,i) in lineas" :key="i" class="pos-linea">""",
"""          <div v-for="(l,i) in lineas" :key="l" class="pos-linea">""", 1),
# T2: F9/F8/F4 solo frenan por el valor de la casilla si es la de la cantidad (el precio a mano en 0 no frena), y el comentario de la habitación vuelve a su línea
("""      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }
      /* 4.39 (decimocuarta vuelta): con el cursor en una casilla numérica, F9, F8 y F4 la dejan primero (corre su cambio: el 0 quita el plato o pide la clave) y, si */
      /* tenía 0 o queda un plato en 0, no siguen en esa pulsación: antes se guardaba o se cobraba con el plato en 0 (la cuenta lo conservaba, o salía sin la clave) */
""" + VIEJA_U2 + COM3,
"""      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }""" + COM3 + """
      /* 4.39 (decimocuarta vuelta): con el cursor en una casilla numérica, F9, F8 y F4 la dejan primero (corre su cambio: el 0 quita el plato o pide la clave) y, si */
      /* tenía 0 o queda un plato en 0, no siguen en esa pulsación: antes se guardaba o se cobraba con el plato en 0 (la cuenta lo conservaba, o salía sin la clave) */
      /* 4.39 (decimoquinta vuelta): el valor propio solo frena si es la casilla de la cantidad (con el precio a mano en 0, la tecla pedía dos pulsaciones) */
""" + NUEVA_U2, 1),
]


def _sin_decimoquinta(texto: str) -> str:
    """caja.js con lo de la decimoquinta vuelta deshecho: cada «lo de ahora» tiene que estar justo las veces anotadas (si no, falla)."""
    for viejo, nuevo, veces in reversed(DECIMOQUINTA):
        assert texto.count(nuevo) == veces, (texto.count(nuevo), veces, nuevo[:140])
        texto = texto.replace(nuevo, viejo)
    return texto


def _caja_sin_decimoquinta() -> str:
    return _sin_decimoquinta(_caja())


# ================================================================================================================ la cuarta vuelta, deshecha
# 4.39 (cuarta vuelta): la cuarta vuelta cambió varias líneas que ANTES busca (la primera de emitirCobro, abrirCargoHab y cargarAHabitacion, el
# bucle de reclamarHab...). Los métodos «de antes» de esta vuelta se rehacen sobre caja.js SIN la cuarta vuelta: cada par (lo de antes, lo de
# ahora) se deshace con un reemplazo exacto (comprobado byte a byte contra la copia de caja.js de antes de la cuarta vuelta) y encima van los
# reemplazos de ANTES, como hasta ahora (el resultado es, método por método, el caja.js de antes de esta vuelta). tests/test_439_cuarta_vuelta.py
# usa _caja_sin_cuarta para sus versiones «de antes»
CUARTA = [
# U1 fusionarAbierta: anota cuándo llegaron «enviados» platos que aquí estaban sin enviar (otro equipo tocó «Comanda»)
("""      if (JSON.stringify(res.lineas) !== JSON.stringify(this.lineas)) this.lineas = aplicarEnLugar(this.lineas, res.lineas);
      const antes = base.cuenta || {}, nombreBase = antes.nombre;""",
"""      const sinEnviar0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));
      if (JSON.stringify(res.lineas) !== JSON.stringify(this.lineas)) this.lineas = aplicarEnLugar(this.lineas, res.lineas);
      if (this.lineas.some(l => l.enviado && sinEnviar0.has(l.lid))) this._marcaAjena = { id: this.esperaId, t: Date.now() };   /* 4.39 (cuarta vuelta): llegaron platos que otro equipo acaba de mandar a cocina (ver emitirCobro) */
      const antes = base.cuenta || {}, nombreBase = antes.nombre;"""),
# U1 persistirCuenta: lo mismo al juntar
("""          if (JSON.stringify(res.lineas) !== JSON.stringify(this.lineas)) { this.lineas = aplicarEnLugar(this.lineas, res.lineas); this.ponerImportes(); }""",
"""          const sinEnviar0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));
          if (JSON.stringify(res.lineas) !== JSON.stringify(this.lineas)) { this.lineas = aplicarEnLugar(this.lineas, res.lineas); this.ponerImportes(); }
          if (this.lineas.some(l => l.enviado && sinEnviar0.has(l.lid))) this._marcaAjena = { id, t: Date.now() };   /* 4.39 (cuarta vuelta): como en fusionarAbierta */"""),
# U2 emitirCobro: espera lo que falta de los 4 s si hace poco llegaron esos platos (toda cuenta guardada, también de mesa)
("""      let rc = null, rcPedido = false;""",
"""      /* 4.39 (cuarta vuelta): si hace menos de 4 s esta pantalla juntó platos de esta cuenta que otro equipo acaba de mandar a cocina («Comanda»), allá se */
      /* está revisando esa comanda (3 s como mucho) y sale si la cuenta sigue abierta: se espera lo que falta antes de cobrar. Si no, este cobro podía */
      /* cerrar la cuenta primero y la comanda no salía de ningún equipo (también en una mesa) */
      { const ma = this._marcaAjena, falta = ma && esperaId !== null && esperaId !== undefined && ma.id === esperaId ? ma.t + 4000 - Date.now() : 0; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }
      let rc = null, rcPedido = false;"""),
# U3 emitirCobro: con la habitación revisando, avisa en vez de callar
("""      if (this.cobrando || this._habEnCurso) return;   /* 4.39 (revisión de los arreglos): mientras «Cargar a la habitación» pide su cobro, F9 no cobra lo mismo en la caja */""",
"""      if (this.cobrando) return;
      if (this._habEnCurso) return toast('Se está revisando el cargo a la habitación: espere un momento', 'err');   /* 4.39 (revisión de los arreglos): mientras «Cargar a la habitación» pide su cobro, F9 no cobra lo mismo en la caja. Cuarta vuelta: con aviso */"""),
# U2 reclamarHab: la misma espera antes de pedir el cobro, en tramos de 200 ms; y la espera de 4 s del bucle, también en tramos
("""      try {
        lidsPantalla(this.lineas, this.cuentaActual);
        let rc = null; try { rc = await this.reclamarCobro(this.lineas); } catch { rc = null; }
        if (rc && rc.ocupada) { this.habCargo = null; return this.cobroOcupado(rc); }""",
"""      try {
        { const ma = this._marcaAjena, id1 = this.esperaId; if (ma && ma.id === id1) { for (let i = 0; i < 20 && Date.now() < ma.t + 4000 && this.habCargo === hc && this.esperaId === id1; i++) await new Promise(r => setTimeout(r, 200)); if (this.habCargo !== hc || this.esperaId !== id1) return; } }   /* 4.39 (cuarta vuelta): como al cobrar (emitirCobro) */
        lidsPantalla(this.lineas, this.cuentaActual);
        let rc = null; try { rc = await this.reclamarCobro(this.lineas); } catch { rc = null; }
        if (rc && rc.ocupada) { this.habCargo = null; return this.cobroOcupado(rc); }"""),
("""            if (vuelta || !this.lineas.some(l => l.enviado && sin0.has(l.lid))) break;
            await new Promise(r => setTimeout(r, 4000));
          }
          if (this.cobroCambiado(id0, lineas0, total0, false, true)) return;""",
"""            if (vuelta || !this.lineas.some(l => l.enviado && sin0.has(l.lid))) break;
            for (let i = 0; i < 20 && this.habCargo === hc && this.esperaId === id0; i++) await new Promise(r => setTimeout(r, 200));   /* 4.39 (cuarta vuelta): en tramos: al cerrar la ventana se deja de esperar */
          }
          if (this.cobroCambiado(id0, lineas0, total0, false, true)) return;"""),
# U3 cargarAHabitacion: aviso en el segundo toque; tampoco carga con una parte en cobro
("""      if (this._habEnCurso && !this._habSigue) return;   /* 4.39 (tercera vuelta): mientras se pide y se revisa el cobro, otro toque no hace nada (se saltaba la revisión) */
      if (this.cobrando || this._cobroEnCurso) return toast('Hay un cobro en curso en esta caja: espere a que termine', 'err');   /* 4.39 (tercera vuelta): ni se carga lo que se está cobrando */""",
"""      if (this._habEnCurso && !this._habSigue) return toast('Se está revisando la cuenta para cargarla: espere un momento', 'ok');   /* 4.39 (tercera vuelta): mientras se pide y se revisa el cobro, otro toque no hace nada (se saltaba la revisión) */
      if (this.cobrando || this._cobroEnCurso || this.cobroParcial) return toast('Hay un cobro en curso en esta caja: espere a que termine', 'err');   /* 4.39 (tercera vuelta): ni se carga lo que se está cobrando (cuarta vuelta: ni una parte) */"""),
# U4 abrirCargoHab: tampoco con una parte en cobro, y otra vez después de esperar cobroPermitido
("""      if (this.pago || this.cobrando || this._cobroEnCurso) return toast('Termine o cierre el cobro antes de cargar a la habitación', 'err');   /* 4.39 (tercera vuelta) */""",
"""      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial) return toast('Termine o cierre el cobro antes de cargar a la habitación', 'err');   /* 4.39 (tercera vuelta) */"""),
("""      if (!(await this.cobroPermitido('cargar a la habitación'))) return;   // 4.6""",
"""      if (!(await this.cobroPermitido('cargar a la habitación'))) return;   // 4.6
      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial) return;   /* 4.39 (cuarta vuelta): mientras se esperaba se abrió el cobro (F9 o «Cobrar parte») */"""),
# U4 abrirPago: después de las esperas, si se abrió la habitación no se abre el cobro (la parte vuelve a la cuenta)
("""      const c0 = this.cuentaActual; this.prepago = c0""",
"""      if (this.habCargo) { if (this.cobroParcial) this.cerrarPago(); return; }   /* 4.39 (cuarta vuelta): mientras se esperaba se abrió la ventana de la habitación */
      const c0 = this.cuentaActual; this.prepago = c0"""),
# U4 cobrarParte: no parte la cuenta si mientras tanto se abrió la habitación o el cobro
("""      if (this.cobroParcial || this.esperaId !== id0) return;""",
"""      if (this.cobroParcial || this.esperaId !== id0 || this.habCargo || this.pago) return;   /* 4.39 (cuarta vuelta): ni con la ventana de la habitación o la de cobro abiertas mientras tanto */"""),
# U5 revisarComanda: la comanda lleva la cantidad y la nota de la cuenta en el servidor
("""      const fuera = dudosas.filter(l => !siguen.has(l.lid) || ajenas.has(l.lid)), yaSalio = fuera.every(l => siguen.has(l.lid));""",
"""      const fuera = dudosas.filter(l => !siguen.has(l.lid) || ajenas.has(l.lid)), yaSalio = fuera.every(l => siguen.has(l.lid));
      /* 4.39 (cuarta vuelta): de los platos que siguen, la comanda lleva la cantidad y la nota de la cuenta en el servidor (otro equipo pudo cambiarlas): */
      /* la cocina hace lo que se cobra. Son copias para imprimir; la pantalla se pone al día al sincronizar */
      const srv = new Map(c ? (c.lineas || []).filter(l => l && l.lid).map(l => [l.lid, l]) : []);
      for (const g of Object.values(e.grupos)) g.ls = g.ls.map(l => { const s = dudosas.includes(l) && !fuera.includes(l) ? srv.get(l.lid) : null; return s ? { ...l, cantidad: s.cantidad, nota: s.nota } : l; });"""),
# U6 alDiaCuentaNueva: la cuenta rehecha sin nombre propio no repite una «Cuenta N» abierta
("""      this.espera = enEspera();
      if (this.esperaId === id) this.fusionarAbierta('sinc');""",
"""      this.espera = enEspera();
      /* 4.39 (cuarta vuelta): la cuenta rehecha que se llama «Cuenta N» y que ya usa otra cuenta abierta (otro equipo la creó mientras tanto) pasa al número siguiente */
      const cn = (this.espera || []).find(v => v && v.id === id), mismo = cn && /^Cuenta \\d+$/.test(cn.nombre || '') && (this.esperaId !== id || !(this.nombreEspera || '').trim()) && this.espera.some(v => v && v.id !== id && v.nombre === cn.nombre);
      if (mismo) { const nombre = 'Cuenta ' + (Math.max(this.espera.length, ...this.espera.map(v => +((/^Cuenta (\\d+)$/.exec((v && v.nombre) || '') || [])[1] || 0))) + 1); this.actualizarCuenta(id, x => ({ ...x, nombre })); this.espera = enEspera(); }
      if (this.esperaId === id) this.fusionarAbierta('sinc');"""),
]


def _sin_cuarta(texto: str) -> str:
    """caja.js con lo de la cuarta vuelta deshecho (en caja.js entera cada cambio está una sola vez; si no, _cambiar falla)."""
    for viejo, nuevo in reversed(CUARTA):
        texto = _cambiar(texto, nuevo, viejo)
    return texto


def _caja_sin_cuarta() -> str:
    # 4.39 (quinta vuelta): parte de caja.js sin la quinta vuelta (la quinta cambió líneas que CUARTA busca)
    return _sin_cuarta(_caja_sin_quinta())


# lo que cada método tenía antes de esta vuelta (tal cual, con sus comentarios), y cómo se deshace cada cambio
V_NUMERADA = ("      const dudosas = this.esRestaurante && !this.cobrando ? this.platosDudosos(nuevas) : [];   /* 4.31: antes de guardar (después la base ya "
              "los tiene como enviados); al cobrar la venta rápida sale lo que se cobra */\n      if (this.esRestaurante) this.persistirCuenta();")
V_MESAS = ("        const pend = this.lineas.filter(l => !l.enviado).length, nombre = this.nombreEspera || (this.mesaActual ? this.mesaActual.nombre : 'La cuenta');\n"
           "        this.persistirCuenta();")
V_NOMBRE = (r"      const nombre = (this.nombreEspera || '').trim() || ('Cuenta ' + (Math.max(this.espera.length, ...this.espera.map(v => +((/^Cuenta (\d+)$/.exec(v.nombre || '') || [])[1] || 0))) + 1));"
            "   /* 4.38: sin repetir el número de una «Cuenta N» que sigue abierta */")
V_REVISADA = "      const dudosas = this.platosDudosos(nuevas);\n      if (this.esRestaurante) this.persistirCuenta();"
V_FUERA = "      const fuera = dudosas.filter(l => !siguen.has(l.lid));"
V_AVISO = ("      toast(fuera.length === 1 ? 'No salió en la comanda: ' + nombres + '. En otro equipo ya se había quitado o cobrado de ' + m + '.' : 'No salieron en la "
           "comanda: ' + nombres + '. En otro equipo ya se habían quitado o cobrado de ' + m + '.', 'err');\n"
           "      if (this.esperaId === e.cuentaId) { this.espera = enEspera(); const cc = this.fusionarAbierta('comanda'); this.avisarCambio({ agregadas: cc.agregadas, "
           "quitadas: Math.max(0, cc.quitadas - fuera.length) }, m); }")
V_HAB = ("          const id0 = this.esperaId, lineas0 = this.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), total0 = this.totales.total;\n"
         "          try { await Promise.race([mock.refrescar(['pos_espera']), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con lo que hay */ }\n"
         "          if (this.habCargo !== hc) return;\n"
         "          if (!enEspera().some(v => v.id === id0)) { this.habCargo = null; return this.cobroDeCuentaCerrada(); }\n"
         "          try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* lo decide cobroCambiado */ }\n"
         "          if (this.habCargo !== hc) return;\n"
         "          if (this.cobroCambiado(id0, lineas0, total0, false)) return;   /* la ventana sigue abierta con el total nuevo */")
V_WEB = ("      const resto = (this.lineas || []).filter(l => l && !l.enviado);\n"
         "      if (resto.length) { this.lineas = resto; this.esperaId = null; this.nombreEspera = ''; toast('Lo que no se había enviado a cocina sigue en pantalla como una cuenta nueva.', 'ok'); }")
V_COBRO = ("          try { await Promise.race([mock.refrescar(['pos_espera']), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con lo que hay */ }\n"
           "          if (!enEspera().some(v => v.id === esperaId)) { if (rc && rc.clave) this.soltarCobro(rc, false); return this.cobroDeCuentaCerrada(); }\n"
           "          try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* lo decide cobroCambiado */ }")
V_COMANDA = "        try { this.enviarComanda(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); } catch { /* la comanda no detiene el cobro */ }"

ANTES = {
    "comandaNumerada(modo,": lambda m: _volver(m, "      let dudosas = this.esRestaurante && !this.cobrando", "if (!nuevas.length) return Promise.resolve(null); }", V_NUMERADA),
    "volverAMesas(sinPreguntar) {": lambda m: _volver(m, "        const nombre = this.nombreEspera || (this.mesaActual", "this.persistirCuenta(); const pend = this.lineas.filter(l => !l.enviado).length;", V_MESAS),
    "persistirCuenta(devolverId) {": lambda m: _volver(m, "      const nombre = (this.nombreEspera || '').trim() ||", "la que ya está guardada conserva su nombre (cambiaba en cada guardado) */", V_NOMBRE),
    "comandaRevisada(nuevas, grupos, ronda, ahora) {": lambda m: _volver(m, "      let dudosas = this.platosDudosos(nuevas);", "if (!nuevas.length) return Promise.resolve(); }", V_REVISADA),
    "async revisarComanda(e, dudosas) {": lambda m: _volver(_volver(
        m, "/* 4.39 (tercera vuelta): tampoco lo que en el servidor ya figura enviado", "yaSalio = fuera.every(l => siguen.has(l.lid));", V_FUERA),
        "      if (yaSalio) toast(", "quitadas: Math.max(0, cc.quitadas - fuera.filter(l => !siguen.has(l.lid)).length) }, m); }", V_AVISO),
    "cobroCambiado(id0, lineas0, total0, alta0": lambda m: _volver(
        _cambiar(m, "cobroCambiado(id0, lineas0, total0, alta0, cargo) {", "cobroCambiado(id0, lineas0, total0, alta0) {"),
        "      toast(cargo ? 'La cuenta cambió", "«cargo», desde la ventana de la habitación */",
        "      toast('La cuenta cambió en otro equipo y aquí no se cobró nada. Revise el total antes de cobrar.', 'err');"),
    "async reclamarHab() {": lambda m: _cambiar(_volver(_volver(
        m, "          const id0 = this.esperaId, lineas0 = ", "if (this.cobroCambiado(id0, lineas0, total0, false, true)) return;   /* la ventana sigue abierta con el total nuevo */", V_HAB),
        "        this._habSigue = true; this.cargarAHabitacion();", "mientras se revisa */", "        this.cargarAHabitacion();"),
        "this._habEnCurso = false; this._habSigue = false;", "this._habEnCurso = false;"),
    "soltarCuentaCanceladaWeb(p, cuentaAntes) {": lambda m: _volver(m, "      const g = lidsDeBase(this._base, id), resto = ", "sigue en pantalla como una cuenta nueva.', 'ok'); }", V_WEB),
    "async abrirPago() {": lambda m: _sin_linea(m, "      if (this.habCargo) return;   /* 4.39 (tercera vuelta)"),
    "async emitirCobro(otra) {": lambda m: _volver(_volver(_sin_linea(
        m, "          const sin0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));"),
        "          /* 4.39 (tercera vuelta): si un plato que aquí estaba sin enviar", "await new Promise(r => setTimeout(r, 4000));\n          }", V_COBRO),
        "        try { if (this.lineas.some(l => !l.enviado && +l.cantidad > 0)) this.enviarComanda();", "sin el aviso «No hay platos nuevos» */", V_COMANDA),
    "async abrirCargoHab() {": lambda m: _sin_linea(m, "      if (this.pago || this.cobrando || this._cobroEnCurso) return toast('" + TERMINE + "', 'err');"),
    "cargarAHabitacion() {": lambda m: _sin_linea(_sin_linea(
        m, "      if (this._habEnCurso && !this._habSigue) return;"), "      if (this.cobrando || this._cobroEnCurso) return toast('" + EN_CURSO + "', 'err');"),
    "tecla(e) {": lambda m: _sin_linea(m, "      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }"),
}


def _antes(*cabezas):
    """Los métodos de antes de esta vuelta (todos, sin `cabezas`): van al final de la fuente y pisan a los de ahora.
    4.39 (cuarta vuelta): se sacan de caja.js con la cuarta vuelta deshecha (los reemplazos de ANTES buscan las líneas de antes de la cuarta)."""
    k = _caja_sin_cuarta()
    return tuple(ANTES[c](_metodo(k, c)) for c in (cabezas or ANTES))


def _extra():
    """Los métodos de la caja que estas pruebas usan además de los del arnés (los de ahora)."""
    k = _caja()
    return (_metodo(k, "tecla(e) {"), _metodo(k, "async abrirCargoHab() {"), _metodo(k, "soltarCuentaCanceladaWeb(p, cuentaAntes) {"), _linea(k, "cobrarOtro() {"))


AYUDAS = r"""
const CAMBIO = @CAMBIO@, CAMBIO_HAB = @CAMBIO_HAB@, NO_HAY = @NO_HAY@, EN_CURSO = @EN_CURSO@, TERMINE = @TERMINE@;
const conTexto = (vm, t) => avisos(vm).filter(x => x === t);
const noSalio = vm => avisos(vm).filter(t => t.startsWith('No salió') || t.startsWith('No salieron'));
const folios = () => C.folios.map(x => x.detalle).sort();
// una tecla con un evento falso (lo que hace la caja con keydown); devuelve si se llamó a preventDefault
const tecla = (vm, key) => { const ev = { key, pd: false, preventDefault() { this.pd = true; } }; vm.tecla(ev); return ev.pd; };
// la lista de cuentas de ESE equipo llega `ms` más tarde (su revisión de la comanda o su cobro, lentos); devuelve con qué se deshace
const lento = (vm, ms) => { const r0 = vm.A.mock.refrescar; vm.A.mock.refrescar = async function (...x) { await espera(ms); return r0.apply(this, x); }; return () => { vm.A.mock.refrescar = r0; }; };
// la cuenta del servidor: todos sus platos ya marcados como enviados; y esas marcas
const enviadaEnServidor = id => { const c = S.items.find(x => x.id === id); return !!c && (c.lineas || []).length > 0 && c.lineas.every(l => l.enviado); };
const marcas = id => { const c = S.items.find(x => x.id === id); return c ? [...new Set(c.lineas.map(l => l.enviado))] : null; };
"""


def _correr(tmp_path, casos, antes=()):
    guion = (AYUDAS.replace("@CAMBIO@", json.dumps(CAMBIO)).replace("@CAMBIO_HAB@", json.dumps(CAMBIO_HAB)).replace("@NO_HAY@", json.dumps(NO_HAY))
             .replace("@EN_CURSO@", json.dumps(EN_CURSO)).replace("@TERMINE@", json.dumps(TERMINE)) + casos)
    return _correr_rev(tmp_path, guion, antes=_extra() + tuple(antes))


# ================================================================================================================ T1: las puertas
CASOS_T1 = r"""
// (teclas) la cuenta guardada sin mesa (Casado y Postre sin enviar) con la ventana de la habitación abierta. F10, con la ventana de cobro
// abierta desde antes (como quedaba con el F9 de antes de T1)
for (const k of ['F9', 'F10', 'F8', 'F4']) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  if (k === 'F10') await a.abrirPago();
  a.habCargo = HAB(); const cuerpos0 = S.cuerpos.length, pago0 = !!a.pago;
  const pd = tecla(a, k); await espera(200); await hastaLibre(); await a.A.mock.guardarTodo();
  out['tecla_' + k] = { pd, pago0, pago: !!a.pago, hechos: hechos().length, impresos: impresos(), guardados: S.cuerpos.length - cuerpos0, platos: detalles(a), cuenta: a.esperaId === id,
    hab: !!a.habCargo, orden: orden(a.nEq), servidor: servidor().map(x => x.platos) };
}
// (abrir) abrirCargoHab con la ventana de cobro abierta, con un cobro en curso (_cobroEnCurso) y cobrando; sin nada de eso, abre
{ nuevo(); const v = venta(await equipo()); v.lineas.push(CASADO());
  const r = {};
  await v.abrirPago(); await v.abrirCargoHab(); r.conPago = !!v.habCargo; v.habCargo = null; v.pago = null;
  v._cobroEnCurso = true; await v.abrirCargoHab(); r.enCurso = !!v.habCargo; v.habCargo = null; v._cobroEnCurso = false;
  v.cobrando = true; await v.abrirCargoHab(); r.cobrando = !!v.habCargo; v.habCargo = null; v.cobrando = false;
  await v.abrirCargoHab(); r.libre = !!v.habCargo;
  out.abrir = { ...r, avisos: conTexto(v, TERMINE).length }; }
// (abrir_pago) abrirPago con la ventana de la habitación abierta (el botón o F9 de antes)
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id); a.habCargo = HAB(); await a.abrirPago();
  out.abrir_pago = { pago: !!a.pago, hab: !!a.habCargo }; }
// (cargar_en_cobro) la ventana de cobro abierta y emitirCobro esperando al servidor: el cobro pedido o el comprobante tardan; en ese momento «Cargar»
for (const espera_ of ['reclamando', 'emitiendo']) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  await a.abrirPago();
  if (espera_ === 'reclamando') C.reclamoLento = 120; else C.emitirLento = 300;
  const pc = a.cobrar();
  if (espera_ === 'reclamando') await espera(30); else await hasta(() => C.llamadas.some(x => x[1] === '/api/comprobantes'));
  const enCurso = !!a._cobroEnCurso; a.habCargo = HAB(); const ph = a.cargarAHabitacion();
  await Promise.all([pc, ph]); C.reclamoLento = 0; C.emitirLento = 0; await hastaLibre(); await espera(50); await hastaLibre(); await a.A.mock.guardarTodo();
  out['cargar_' + espera_] = { enCurso, hechos: hechos().map(h => [h[1], h[2]]), folios: folios(), impresos: impresos(), avisos: conTexto(a, EN_CURSO), reclamos: reclamos(a.nEq),
    ajeno: avisos(a).filter(t => t.includes('en otro equipo')), orden: orden(a.nEq), servidor: servidor(), libre: libre() };
}
// (doble) B quita el Postre (A no lo sabe) y A toca dos veces «Cargar»: el segundo toque, mientras reclamarHab trae la lista (lenta)
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  a.habCargo = HAB();
  b.lineas = b.lineas.filter(l => l.detalle !== 'Postre'); b.persistirCuenta(); await b.A.mock.guardarTodo();
  C.lentoGet = 300;
  const p1 = a.cargarAHabitacion(); await hasta(() => !!a._rcHab); const segundo = !!a.habCargo && !!a._habEnCurso; const p2 = a.cargarAHabitacion();
  await Promise.all([p1, p2]); C.lentoGet = 0; await hastaLibre(); await a.A.mock.guardarTodo();
  const o = out.doble = { segundo, folios: folios(), impresos: impresos(), hab: !!a.habCargo, platos: detalles(a), cambio: conTexto(a, CAMBIO_HAB), cambioCobro: conTexto(a, CAMBIO),
    reclamos: reclamos(a.nEq), orden: orden(a.nEq), servidor: servidor().map(x => x.platos), libre: libre() };
  if (a.habCargo) await a.cargarAHabitacion(); await hastaLibre(); await a.A.mock.guardarTodo();   // (la ventana sigue abierta: otro toque)
  o.luego = { folios: folios(), impresos: impresos(), hab: a.habCargo, servidor: servidor() }; }
"""


def test_t1_con_la_ventana_de_la_habitacion_no_se_cobra_ni_se_carga_dos_veces_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_T1)
    for k in ("F9", "F10", "F8", "F4"):
        x = r["tecla_" + k]
        # la tecla no hace nada: ni abre el cobro, ni emite, ni manda comanda, ni guarda, ni pide el cobro al servidor
        assert x["pd"] is True and x["pago"] is x["pago0"] and x["hechos"] == 0 and x["impresos"] == [] and x["guardados"] == 0, (k, x)
        assert x["platos"] == AMBOS and x["cuenta"] is True and x["hab"] is True and x["orden"] == [] and x["servidor"] == [AMBOS], (k, x)
    assert r["tecla_F10"]["pago0"] is True and r["tecla_F9"]["pago0"] is False, r
    assert r["abrir"] == {"conPago": False, "enCurso": False, "cobrando": False, "libre": True, "avisos": 3}, r["abrir"]
    assert r["abrir_pago"] == {"pago": False, "hab": True}, r["abrir_pago"]
    for k in ("cargar_reclamando", "cargar_emitiendo"):
        c = r[k]
        # «Cargar» no carga, no pide el cobro y avisa; el cobro sigue y emite una vez (con una comanda)
        assert c["enCurso"] is True and c["avisos"] == [EN_CURSO] and c["folios"] == [] and c["ajeno"] == [], (k, c)
        assert c["hechos"] == [[CASADO + POSTRE, AMBOS]] and c["impresos"] == [AMBOS] and c["servidor"] == [] and c["libre"] is True, (k, c)
        assert c["reclamos"] == 1 and c["orden"] == [RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR], (k, c)   # un solo cobro pedido
    d = r["doble"]
    # un solo intento (el segundo toque no hace nada): la revisión ve que B quitó el Postre, avisa y no carga ni manda comanda
    assert d["segundo"] is True and d["reclamos"] == 1 and d["orden"] == [RECLAMAR, SOLTAR] and d["libre"] is True, d
    assert d["folios"] == [] and d["impresos"] == [] and d["cambio"] == [CAMBIO_HAB] and d["hab"] is True and d["platos"] == ["Casado×1"], d
    assert d["cambioCobro"] == [], d                                                                    # T4: el aviso de la habitación, no el de cobrar
    assert d["servidor"] == [["Casado×1"]], d
    assert d["luego"] == {"folios": ["Casado (Cuenta 1)"], "impresos": [["Casado×1"]], "hab": None, "servidor": []}, d   # al tocar otra vez: lo que quedó, una vez

    # antes de esta vuelta: las teclas cobraban, mandaban comanda o guardaban por debajo de la ventana de la habitación; abrirCargoHab y
    # abrirPago abrían una ventana sobre la otra; «Cargar» con el cobro en curso cargaba lo mismo que se cobraba; y el segundo toque se
    # saltaba la revisión: Casado y Postre cargados y la comanda del Postre que B ya había quitado
    v = _correr(tmp_path / "antes", CASOS_T1, antes=_antes())
    assert v["tecla_F9"]["pago"] is True, v["tecla_F9"]                                               # el cobro abierto debajo
    assert v["tecla_F10"]["hechos"] == 1 and v["tecla_F10"]["impresos"] == [AMBOS], v["tecla_F10"]   # cobrado con la ventana abierta
    assert v["tecla_F8"]["impresos"] == [AMBOS] and v["tecla_F8"]["guardados"] >= 1, v["tecla_F8"]
    assert v["tecla_F4"]["platos"] == [] and v["tecla_F4"]["hab"] is True and v["tecla_F4"]["guardados"] >= 1, v["tecla_F4"]
    assert v["abrir"] == {"conPago": True, "enCurso": True, "cobrando": True, "libre": True, "avisos": 0}, v["abrir"]
    assert v["abrir_pago"]["pago"] is True, v["abrir_pago"]
    ve = v["cargar_emitiendo"]                                                                          # con el comprobante en camino: cobrado Y cargado
    assert ve["avisos"] == [] and ve["hechos"] == [[CASADO + POSTRE, AMBOS]] and ve["folios"] == FOLIOS, ve
    vr = v["cargar_reclamando"]                                                                         # con el cobro pedido: la habitación lo pedía otra vez
    assert vr["avisos"] == [] and vr["reclamos"] == 2 and len(vr["hechos"]) == 1, vr
    vd = v["doble"]
    assert vd["folios"] == FOLIOS and vd["impresos"] == [AMBOS] and vd["cambio"] == [], vd


# ================================================================================================================ T2 y T3: la comanda de otro equipo
CASOS_T23 = r"""
// A y B recuperaron la cuenta guardada sin mesa (Casado y Postre sin enviar). B toca «Comanda» y su revisión es lenta (su lista llega 800 ms
// después); A cobra (o carga a la habitación) apenas el guardado de B llegó al servidor, mientras B todavía revisa
async function carrera(cargo) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  if (cargo) a.habCargo = HAB(); else await a.abrirPago();
  const suelta = lento(b, 800);
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  const t0 = Date.now(); const pa = cargo ? a.cargarAHabitacion() : a.cobrar();
  await Promise.all([pb, pa]); const ms = Date.now() - t0; suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { ms, impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), folios: folios(), noHay: conTexto(a, NO_HAY),
    noSalioB: noSalio(b), comandasB: comandas(b), servidor: servidor(), pago: !!a.pago, hab: !!a.habCargo, orden: orden(a.nEq), libre: libre() };
}
// (ya_salio) B mandó la comanda (y salió) con la ventana de cobro de A abierta; A cobra después
async function yaSalio() {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  await a.abrirPago();
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), noHay: conTexto(a, NO_HAY), comandasA: comandas(a), servidor: servidor(), orden: orden(a.nEq) };
}
// (solo) sin nada de otro equipo: el cobro y el cargo no esperan
async function solo(cargo) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  if (cargo) a.habCargo = HAB(); else await a.abrirPago();
  const t0 = Date.now(); if (cargo) await a.cargarAHabitacion(); else await a.cobrar(); const ms = Date.now() - t0;
  await hastaLibre(); await a.A.mock.guardarTodo();
  return { ms, impresos: impresos(), hechos: hechos().map(h => [h[1], h[2]]), folios: folios(), servidor: servidor(), orden: orden(a.nEq) };
}
"""

UNA_COMANDA_B = [["B", AMBOS]]
HECHO_A = [["A", CASADO + POSTRE, AMBOS]]


def test_t3_al_cobrar_la_comanda_de_otro_equipo_sale_una_vez_en_node(tmp_path):
    casos = CASOS_T23 + "\nout.carrera = await carrera(false);\nout.ya_salio = await yaSalio();\nout.solo = await solo(false);\n"
    r = _correr(tmp_path / "ahora", casos)
    c = r["carrera"]
    # A esperó a que B terminara su revisión (la cuenta seguía abierta): una comanda (la de B, con los dos platos) y un comprobante (el de A)
    assert c["impresos"] == UNA_COMANDA_B and c["comandasB"] == ["Comanda 1 enviada a Cocina"] and c["noSalioB"] == [], c
    assert c["hechos"] == HECHO_A and c["servidor"] == [] and c["pago"] is False and c["libre"] is True, c
    assert c["noHay"] == [] and c["orden"] == [RECLAMAR, EMITIR, SOLTAR, SOLTAR], c                   # A no manda comanda ni avisa «No hay platos nuevos»
    assert 4000 <= c["ms"] < 7000, c                                                                     # la espera de 4 s (una vez)
    y = r["ya_salio"]
    assert y["impresos"] == UNA_COMANDA_B and y["hechos"] == HECHO_A and y["noHay"] == [] and y["comandasA"] == [] and y["servidor"] == [], y
    s = r["solo"]
    assert s["ms"] < 2000 and s["impresos"] == [AMBOS] and s["hechos"] == [[CASADO + POSTRE, AMBOS]] and s["servidor"] == [], s   # sin otro equipo: no espera
    assert s["orden"] == [RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR], s

    # emitirCobro de antes de esta vuelta: A cobraba sin esperar y cerraba la cuenta; la revisión de B ya no la encontraba y el plato no salía
    # de ninguno de los dos (cobrado y nunca en cocina). Y en el cobro que sale bien, el aviso falso «No hay platos nuevos por enviar»
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    vc = v["carrera"]
    assert vc["impresos"] == [] and vc["hechos"] == HECHO_A and vc["noHay"] == [NO_HAY], vc
    assert vc["noSalioB"] == ["No salieron en la comanda: Casado, Postre. En otro equipo ya se habían quitado o cobrado de Cuenta 1."], vc
    assert v["ya_salio"]["noHay"] == [NO_HAY] and v["ya_salio"]["impresos"] == UNA_COMANDA_B, v["ya_salio"]
    assert v["solo"]["impresos"] == [AMBOS] and v["solo"]["ms"] < 2000, v["solo"]


def test_t2_al_cargar_a_la_habitacion_la_comanda_de_otro_equipo_sale_una_vez_en_node(tmp_path):
    casos = CASOS_T23 + "\nout.carrera = await carrera(true);\nout.solo = await solo(true);\n"
    r = _correr(tmp_path / "ahora", casos)
    c = r["carrera"]
    # una comanda (la de B) y un cargo (el de A), sin «No hay platos nuevos»
    assert c["impresos"] == UNA_COMANDA_B and c["comandasB"] == ["Comanda 1 enviada a Cocina"] and c["noSalioB"] == [], c
    assert c["folios"] == FOLIOS and c["hechos"] == [] and c["hab"] is False and c["servidor"] == [] and c["libre"] is True, c
    assert c["noHay"] == [] and c["orden"] == [RECLAMAR, SOLTAR] and 4000 <= c["ms"] < 7000, c
    s = r["solo"]
    assert s["ms"] < 2000 and s["impresos"] == [AMBOS] and s["folios"] == FOLIOS and s["servidor"] == [] and s["orden"] == [RECLAMAR, COMANDA, SOLTAR], s

    # reclamarHab de antes de esta vuelta: A cargaba y cerraba la cuenta antes de que B terminara de revisar: la comanda no salía de ninguno
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    vc = v["carrera"]
    assert vc["impresos"] == [] and vc["folios"] == FOLIOS, vc
    assert vc["noSalioB"] == ["No salieron en la comanda: Casado, Postre. En otro equipo ya se habían quitado o cobrado de Cuenta 1."], vc


# ================================================================================================================ T5: la cuenta ya cobrada al guardar
CASOS_T5 = r"""
// A y B recuperaron la cuenta guardada sin mesa (Casado y Postre sin enviar); A le agrega la Limonada sin guardar y abre el cobro; B la
// cobra; A sincroniza con la ventana abierta (la pantalla no cambia), cancela el cobro y toca «Comanda» con el servidor sin responder
// (más de 3 s): sin numerar (comandaRevisada) y numerada (comandaNumerada)
for (const numerada of [false, true]) {
  const id = await guardada([CASADO(), POSTRE()]);
  const a = await abierta(id), b = await abierta(id);
  if (numerada) a.numerarComanda = 'diaria';
  a.lineas.push(LIMONADA()); await a.abrirPago();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  await a.sincronizar(); a.cerrarPago();
  const enPantalla = detalles(a);
  S.lento = true; await a.enviarComanda(); S.lento = false; await a.A.mock.esperarRefrescos(); await a.A.mock.guardarTodo();
  const o = out[numerada ? 'numerada' : 'revisada'] = { enPantalla, platos: detalles(a), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), servidor: servidor().map(x => x.platos.slice().sort()),
    cerradas: cerradas(a) };
  for (const c of S.items.slice()) { const v = await abierta(c.id); await v.abrirPago(); await v.cobrar(); await hastaLibre(); await v.A.mock.guardarTodo(); }   // lo que quedó se cobra
  o.luego = { hechos: hechos().map(h => [h[1], h[2]]), suma: suma(), servidor: servidor() };
}
"""


def test_t5_lo_cobrado_en_otro_equipo_no_sale_en_la_comanda_ni_se_rehace_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_T5)
    aviso = "La cuenta «Cuenta 1» fue cobrada o cerrada en otro equipo; lo que acaba de agregar queda como cuenta nueva"
    for k in ("revisada", "numerada"):
        x = r[k]
        assert x["enPantalla"] == LOS_TRES and x["cerradas"] == [aviso] and x["platos"] == ["Limonada×1"], (k, x)
        # la comanda de A trae solo la Limonada y la cuenta nueva tiene solo la Limonada
        assert x["impresos"] == [["B", AMBOS], ["A", ["Limonada×1"]]] and x["servidor"] == [["Limonada×1"]], (k, x)
        lu = x["luego"]
        assert lu["hechos"] == [[CASADO + POSTRE, AMBOS], [LIMONADA, ["Limonada×1"]]] and lu["suma"] == TRES and lu["servidor"] == [], (k, x)   # cada plato una vez

    # comandaRevisada y comandaNumerada de antes: Casado y Postre (ya cobrados por B) salían otra vez a cocina y comoPedidoNuevo los metía
    # en la cuenta nueva: se cobraban dos veces
    v = _correr(tmp_path / "antes", CASOS_T5, antes=_antes())
    for k in ("revisada", "numerada"):
        x = v[k]
        assert x["impresos"] == [["B", AMBOS], ["A", LOS_TRES]] and x["servidor"] == [LOS_TRES], (k, x)
        assert x["luego"]["suma"] == TRES + CASADO + POSTRE, (k, x)


# ================================================================================================================ T6: dos «Comanda» a la vez
CASOS_T6 = r"""
// A y B recuperaron la cuenta guardada sin mesa (Casado y Postre sin enviar) y los dos tocan «Comanda» sobre los mismos platos. El primero
// guarda primero y su revisión es lenta (lee después del guardado del otro); el último guarda después y su revisión lee enseguida
for (const ultimo of ['B', 'A']) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  const [p, s] = ultimo === 'B' ? [a, b] : [b, a];
  const suelta = lento(p, 400);
  const pp = p.enviarComanda(); await hasta(() => enviadaEnServidor(id)); const m1 = marcas(id); await espera(5);
  const ps = s.enviarComanda(); await Promise.all([pp, ps]); suelta();
  await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  out['ultimo_' + ultimo] = { m1, m2: marcas(id), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), noSalioA: noSalio(a), noSalioB: noSalio(b),
    comandasA: comandas(a), comandasB: comandas(b), quitadosA: avisos(a).filter(t => t.startsWith('En otro equipo se quit')), quitadosB: avisos(b).filter(t => t.startsWith('En otro equipo se quit')),
    servidor: servidor().map(x => x.platos), platosA: detalles(a), platosB: detalles(b) };
}
"""


def test_t6_dos_comandas_a_la_vez_sobre_los_mismos_platos_salen_una_vez_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_T6)
    otra_vez = "No salieron otra vez en la comanda: Casado, Postre. Ya se habían mandado a cocina desde otro equipo."
    for ultimo, primero in (("B", "A"), ("A", "B")):
        x = r["ultimo_" + ultimo]
        assert len(x["m1"]) == 1 and len(x["m2"]) == 1 and x["m1"] != x["m2"], x                       # el servidor guarda la última marca
        # una sola comanda, la del último; el primero recibe el aviso (sin quitar nada de la cuenta)
        assert x["impresos"] == [[ultimo, AMBOS]], (ultimo, x)
        assert x["noSalio" + primero] == [otra_vez] and x["noSalio" + ultimo] == [] and x["comandas" + primero] == [], (ultimo, x)
        assert x["comandas" + ultimo] == ["Comanda 1 enviada a Cocina"] and x["quitadosA"] == [] and x["quitadosB"] == [], (ultimo, x)
        assert x["servidor"] == [AMBOS] and x["platosA"] == AMBOS and x["platosB"] == AMBOS, (ultimo, x)   # los platos siguen en la cuenta para cobrarse

    # revisarComanda de antes: los dos equipos imprimían la comanda (Casado y Postre dos veces en cocina)
    v = _correr(tmp_path / "antes", CASOS_T6, antes=_antes())
    for ultimo in ("B", "A"):
        assert sorted(x[0] for x in v["ultimo_" + ultimo]["impresos"]) == ["A", "B"], v["ultimo_" + ultimo]
        assert all(x[1] == AMBOS for x in v["ultimo_" + ultimo]["impresos"]), v["ultimo_" + ultimo]


# ================================================================================================================ T7: pedido en línea cancelado
CASOS_T7 = r"""
// el pedido en línea (Casado enviado, envío sin enviar) abierto en esta caja; la cajera le agrega un Postre (sin guardar) y cancela el
// pedido aquí: el servidor quita su cuenta (pedidos: cancelar) y la caja suelta la cuenta. Después se cobra lo que quedó en pantalla
{ nuevo(); pedidoEnServidor([CASADO()]);
  const a = venta(await equipo()); a.recuperar(a.espera.find(x => x.id === 1)); a.lineas.push(POSTRE());
  S.items = S.items.filter(x => x.id !== 1); S.version++;
  const solto = a.soltarCuentaCanceladaWeb({ id: 9, numero: 41, estado: 'cancelado', cuenta_espera_id: null }, 1);
  await a.sincronizar();
  const o = out.cancela = { solto, ...pantalla(a), esVentaRapida: a.esVentaRapida, avisos: avisos(a) };
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  o.luego = { hechos: hechos().map(h => h[2]), impresos: impresos(), comandas: comandas(a), servidor: servidor(), pago: !!a.pago }; }
"""


def test_t7_el_envio_del_pedido_cancelado_se_va_con_el_pedido_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_T7)
    c = r["cancela"]
    assert c["solto"] is True and c["platos"] == ["Postre×1"] and c["cuenta"] is None and c["rapida"] is True and c["esVentaRapida"] is True, c
    assert c["avisos"] == ["Lo que no se había enviado a cocina sigue en pantalla como una cuenta nueva."], c
    lu = c["luego"]
    # el Postre se cobra una vez y su comanda sale al cobrarlo, una vez; el envío del pedido cancelado no se cobra
    assert lu["hechos"] == [["Postre×1"]] and lu["impresos"] == [["Postre×1"]] and lu["comandas"] == ["Comanda 1 enviada a Cocina"], lu
    assert lu["servidor"] == [] and lu["pago"] is False, lu

    # soltarCuentaCanceladaWeb de antes: el envío quedaba en pantalla y se cobraba; sin rapida, el Postre se cobraba sin llegar a cocina
    v = _correr(tmp_path / "antes", CASOS_T7, antes=_antes())
    vc = v["cancela"]
    assert vc["platos"] == ["Envío a domicilio×1", "Postre×1"] and vc["rapida"] is False, vc
    assert vc["luego"]["hechos"] == [["Envío a domicilio×1", "Postre×1"]] and vc["luego"]["impresos"] == [], vc


# ================================================================================================================ T8: el aviso de «Mesas»
CASOS_T8 = r"""
// (cobrada) A y B recuperaron la cuenta guardada sin mesa (Casado y Postre sin enviar); A agrega la Limonada y abre el cobro; B la cobra; A
// sincroniza con la ventana abierta, cancela el cobro y toca «Mesas»
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  a.lineas.push(LIMONADA()); await a.abrirPago();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  await a.sincronizar(); a.cerrarPago();
  const enPantalla = detalles(a);
  a.volverAMesas(false); await a.A.mock.guardarTodo();
  out.cobrada = { enPantalla, guardadas: avisos(a).filter(t => t.includes('quedó guardada con')), cerradas: cerradas(a), servidor: servidor().map(x => x.platos) }; }
// (normal) sin otro equipo: la cuenta con el Casado sin enviar y el Postre agregado
{ const id = await guardada([CASADO()]); const a = await abierta(id); a.lineas.push(POSTRE());
  a.volverAMesas(false); await a.A.mock.guardarTodo();
  out.normal = { guardadas: avisos(a).filter(t => t.includes('quedó guardada con')), servidor: servidor().map(x => x.platos) }; }
"""


def test_t8_el_aviso_de_mesas_cuenta_lo_que_quedo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_T8)
    c = r["cobrada"]
    assert c["enPantalla"] == LOS_TRES and c["servidor"] == [["Limonada×1"]], c
    assert c["guardadas"] == ["Cuenta 1 quedó guardada con 1 plato sin enviar a cocina: use «Comanda» para enviarlo"], c   # lo que quedó: la Limonada
    assert c["cerradas"] == ["La cuenta «Cuenta 1» fue cobrada o cerrada en otro equipo; lo que acaba de agregar queda como cuenta nueva"], c
    assert r["normal"]["guardadas"] == ["Cuenta 1 quedó guardada con 2 platos sin enviar a cocina: use «Comanda» para enviarlos"], r["normal"]

    # volverAMesas de antes: contaba antes de guardar (los tres, aunque Casado y Postre ya se habían cobrado)
    v = _correr(tmp_path / "antes", CASOS_T8, antes=_antes())
    assert v["cobrada"]["guardadas"] == ["Cuenta 1 quedó guardada con 3 platos sin enviar a cocina: use «Comanda» para enviarlos"], v["cobrada"]
    assert v["cobrada"]["servidor"] == [["Limonada×1"]] and v["normal"]["guardadas"] == r["normal"]["guardadas"], v


# ================================================================================================================ T9: el nombre de la cuenta
CASOS_T9 = r"""
// la venta rápida manda tres comandas (queda guardada como «Cuenta 1», sin nombre en pantalla); B la ve y la abre; después otra venta
// rápida en un tercer equipo manda la suya mientras «Cuenta 1» sigue abierta
{ nuevo(); const v = venta(await equipo()); const b = venta(await equipo());
  const nombres = [], enB = [];
  for (const p of [CASADO, POSTRE, LIMONADA]) { v.lineas.push(p()); await v.enviarComanda(); await v.A.mock.guardarTodo(); nombres.push(S.items.map(x => x.nombre)); await b.sincronizar(); enB.push(b.espera.map(x => x.nombre)); }
  const id = S.items[0].id; b.recuperar(b.espera.find(x => x.id === id)); const nombreB = b.nombreEspera;
  b.lineas.push(POSTRE()); b.persistirCuenta(); await b.A.mock.guardarTodo();
  const w = venta(await equipo()); w.lineas.push(CASADO()); await w.enviarComanda(); await w.A.mock.guardarTodo();
  out.nombres = { nombres, enB, nombreB, nombreV: v.nombreEspera, tras: S.items.map(x => x.nombre), comandas: comandas(v) }; }
"""


def test_t9_la_cuenta_guardada_conserva_su_nombre_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_T9)
    n = r["nombres"]
    assert n["nombres"] == [["Cuenta 1"]] * 3 and n["enB"] == [["Cuenta 1"]] * 3 and n["nombreB"] == "Cuenta 1" and n["nombreV"] == "", n
    assert n["tras"] == ["Cuenta 1", "Cuenta 2"], n                                                     # la nueva sigue sin repetir el número (4.38)
    assert n["comandas"] == ["Comanda 1 enviada a Cocina", "Comanda 2 enviada a Cocina", "Comanda 3 enviada a Cocina"], n

    # persistirCuenta de antes: el nombre cambiaba en cada guardado («Cuenta 1», «Cuenta 2», «Cuenta 3») y así lo veía el otro equipo
    v = _correr(tmp_path / "antes", CASOS_T9, antes=_antes())
    assert v["nombres"]["nombres"] == [["Cuenta 1"], ["Cuenta 2"], ["Cuenta 3"]] and v["nombres"]["enB"][-1] == ["Cuenta 3"], v["nombres"]


# ================================================================================================================ contrato
def test_contrato_de_la_tercera_vuelta():
    k = _caja()
    # cada cambio está una sola vez donde se espera (si no, el reemplazo de ANTES no calza)
    assert len(_antes()) == 13
    # T1: las puertas van primero
    assert _metodo(k, "tecla(e) {").split("\n")[1].startswith("      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }")
    # 4.39 (quinta vuelta, V5): la puerta de abrirPago sigue siendo la primera línea; con una parte en cobro, la devuelve a la cuenta
    assert _metodo(k, "async abrirPago() {").split("\n")[1].startswith("      if (this.habCargo) { if (this.cobroParcial) this.cerrarPago(); return; }")
    # 4.39 (cuarta vuelta, U4): abrirCargoHab tampoco abre con una parte en cobro (cobroParcial); U3: el segundo toque en «Cargar» avisa
    # que se está revisando (ya no calla) y tampoco se carga con una parte en cobro. Las puertas siguen siendo las primeras líneas
    # 4.39 (quinta vuelta, V6): ni con «Dividir» abierto
    assert _metodo(k, "async abrirCargoHab() {").split("\n")[1].startswith("      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial || this.dividir) return toast('" + TERMINE + "', 'err');")
    h = _metodo(k, "cargarAHabitacion() {").split("\n")
    assert h[1].startswith("      if (this._habEnCurso && !this._habSigue) return toast('Se está revisando la cuenta para cargarla: espere un momento', 'ok');"), h[1]
    assert h[2].startswith("      if (this.cobrando || this._cobroEnCurso || this.cobroParcial) return toast('" + EN_CURSO + "', 'err');"), h[2]
    rh = _metodo(k, "async reclamarHab() {")
    assert rh.index("this._habSigue = true; this.cargarAHabitacion();") < rh.index("} finally {") < rh.index("this._habSigue = false;")
    # T2 y T3: la misma espera en reclamarHab y en emitirCobro (dos vueltas como mucho, 4 s solo si un plato de sin0 llegó enviado).
    # 4.39 (cuarta vuelta, U2): en reclamarHab los 4 s van en tramos de 200 ms que se cortan si se cierra la ventana o cambia la cuenta
    # 4.39 (quinta vuelta, V1): la espera solo por un plato que va a cocina con una marca de envío de hace menos de 10 s (RECIENTE)
    # 4.39 (sexta vuelta, W6): en los dos bucles se espera solo lo que falta hasta la marca que dejó persistirCuenta al juntar (4 s si la marca no
    # es de esa cuenta); en reclamarHab, en tramos de 200 ms como antes
    # 4.39 (séptima vuelta, X7): el corte del bucle deja una tercera vuelta como mucho, solo si al juntar llegó una comanda más nueva del otro
    # equipo (la marca se renovó); las esperas siguen iguales
    corte = ("if (vuelta > 1 || (vuelta ? !" + VIGENTE("this.esperaId")[2:] + " : !this.lineas.some(l => l.enviado && sin0.has(l.lid) && " + RECIENTE + "))) break;   "
             "/* 4.39 (séptima vuelta): otra vuelta solo si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó) */\n")
    espera = (corte +
              "            { const ma = this._marcaAjena, falta = ma && ma.id === this.esperaId ? ma.t + 4000 - Date.now() : 4000; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }")
    espera_hab = (corte +
                  "            { const ma = this._marcaAjena, fin = ma && ma.id === this.esperaId ? ma.t + 4000 : Date.now() + 4000; for (let i = 0; i < 20 && Date.now() < fin && this.habCargo === hc && this.esperaId === id0; i++) await new Promise(r => setTimeout(r, 200)); }")
    e = _metodo(k, "async emitirCobro(otra) {")
    assert rh.count(espera_hab) == 1 and rh.count(espera) == 0 and e.count(espera) == 1
    assert e.index("const sin0 = ") < e.index("rcPedido = true;") < e.index("for (let vuelta = 0; ; vuelta++) {") < e.index(espera) < e.index("const cambio0 = ")
    # T4: solo reclamarHab pasa `cargo`
    assert rh.count("this.cobroCambiado(id0, lineas0, total0, false, true)") == 1 and e.count(", true)) return") == 0
    # T5: en las dos comandas con revisión, el guardado se compara con la cuenta de antes (id0) y lo que se fue no sale
    # 4.39 (sexta vuelta, W2): comandaNumerada no guarda la parte de un cobro («Dividir → Cobrar estos platos» en la venta rápida); fuera de eso, igual
    # 4.39 (séptima vuelta, X0): esa guarda se quitó con la comanda de la parte (la opción solo existe con mesa): la línea vuelve a ser la de antes
    for cab, guarda in (("comandaNumerada(modo,", "const id0 = this.esperaId; if (this.esRestaurante) this.persistirCuenta();\n"),
                        ("comandaRevisada(nuevas, grupos, ronda, ahora) {", "const id0 = this.esperaId; if (this.esRestaurante) this.persistirCuenta();")):
        m = _metodo(k, cab)
        assert m.index(guarda) < m.index("const idas = dudosas.length && this.esperaId !== id0 ? dudosas.filter(l => !this.lineas.some(x => x.lid === l.lid)) : [];") < m.index("revisarComanda("), cab
    # T6: lo enviado por otro equipo (otra marca) también queda fuera
    rc = _metodo(k, "async revisarComanda(e, dudosas) {")
    assert "const ajenas = new Set(c ? (c.lineas || []).filter(l => l && l.enviado && l.enviado !== e.ahora).map(l => l.lid) : []);" in rc
    assert "const fuera = dudosas.filter(l => !siguen.has(l.lid) || ajenas.has(l.lid)), yaSalio = fuera.every(l => siguen.has(l.lid));" in rc
