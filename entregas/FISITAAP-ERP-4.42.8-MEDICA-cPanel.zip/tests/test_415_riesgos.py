# -*- coding: utf-8 -*-
"""4.15: código de vinculación largo con tope persistente, https al vincular, el cobro del comprobante rechazado y las migraciones que no corrían en cPanel."""
import json
import pathlib
import re
from types import SimpleNamespace

from sqlmodel import Session, select

from app import auth, main as M, modulos, sinc
from app.db import Documento, Empresa, engine, engine_empresa
from test_49_local_sinc import H, PW, _admin_empresa, c
from test_412_etapa1 import _doc

FECHA = "2026-11-08T08:00:00-06:00"


def _id(eid, n):
    with Session(engine_empresa(eid)) as s:
        return s.exec(select(Documento).where(Documento.clave == f"506{n:047d}")).one().id


def _banco(eid):
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, "bancos", [{"id": 1, "nombre": "Caja QA", "tipo": "Efectivo", "moneda": "CRC", "saldo_inicial": 0}], None)
        s.commit()


def _cobro(eid, facturas, monto, numero, **extra):
    with Session(engine_empresa(eid)) as s:
        p = modulos.Pago(empresa_id=eid, numero=numero, fecha="2026-11-08", cuenta="Caja QA", monto=monto, facturas=json.dumps(facturas), moneda="CRC", **extra)
        s.add(p); s.commit(); s.refresh(p)
        modulos.aplicar_pago(s, eid, facturas, 1); s.commit()
        modulos.registrar_movimiento_banco(s, eid, "Caja QA", monto, "2026-11-08", f"Recibo de caja #{numero}", M._ref_pago(p), moneda="CRC", tipo_cambio=1)
        return p.id


def _rechazar(monkeypatch, eid, did):
    monkeypatch.setattr(M, "_cliente_hacienda", lambda e: SimpleNamespace(consultar=lambda clave: {"estado": "rechazado", "detalle": "Rechazado (QA)"}))
    with Session(engine) as sc, Session(engine_empresa(eid)) as s:
        M.consultar_documento(s, sc.get(Empresa, eid), s.get(Documento, did), sincrono=True)


def _movs(eid):
    with Session(engine_empresa(eid)) as s:
        return modulos.leer(s, eid, "movimientos", []) or []


def test_rechazo_revierte_el_cobro_y_el_banco(monkeypatch):
    eid, _ = _admin_empresa("-r3a", "3101415001")
    _banco(eid)
    _doc(eid, 1, FECHA, estado="enviado")
    did = _id(eid, 1)
    pid = _cobro(eid, [{"id": did, "monto": 1000}], 1000, 7)
    assert len(_movs(eid)) == 1
    _rechazar(monkeypatch, eid, did)
    with Session(engine_empresa(eid)) as s:
        d = s.get(Documento, did)
        assert d.estado == "rechazado" and not d.pagado and "Se revirtió el cobro #7" in d.mensaje_hacienda
        assert s.get(modulos.Pago, pid) is None
    assert _movs(eid) == []


def test_rechazo_de_una_de_varias_facturas_solo_rebaja_su_parte(monkeypatch):
    eid, _ = _admin_empresa("-r3b", "3101415002")
    _banco(eid)
    _doc(eid, 2, FECHA, estado="enviado"); _doc(eid, 3, FECHA, estado="aceptado")
    a, b = _id(eid, 2), _id(eid, 3)
    pid = _cobro(eid, [{"id": a, "monto": 300}, {"id": b, "monto": 700}], 1000, 8)
    _rechazar(monkeypatch, eid, a)
    with Session(engine_empresa(eid)) as s:
        p = s.get(modulos.Pago, pid)
        assert p.monto == 700 and [f["id"] for f in json.loads(p.facturas)] == [b]
        assert not s.get(Documento, a).pagado and s.get(Documento, b).pagado == 700
    m = _movs(eid)
    assert len(m) == 1 and m[0]["monto"] == 700


def test_rechazo_no_toca_un_cobro_conciliado(monkeypatch):
    eid, _ = _admin_empresa("-r3c", "3101415003")
    _banco(eid)
    _doc(eid, 4, FECHA, estado="enviado")
    did = _id(eid, 4)
    pid = _cobro(eid, [{"id": did, "monto": 500}], 500, 9, estado="Conciliado")
    _rechazar(monkeypatch, eid, did)
    with Session(engine_empresa(eid)) as s:
        assert s.get(modulos.Pago, pid) is not None
        assert "conciliado y no se tocó" in s.get(Documento, did).mensaje_hacienda
    assert len(_movs(eid)) == 1


def test_anulacion_y_repeticion_no_revierten():
    eid, _ = _admin_empresa("-r3d", "3101415004")
    _banco(eid)
    _doc(eid, 5, FECHA, estado="rechazado", mensaje_hacienda="Anulado por el usuario: no fue aceptado por Hacienda")
    _doc(eid, 6, FECHA, estado="rechazado", mensaje_hacienda="Rechazado (QA)")
    a, b = _id(eid, 5), _id(eid, 6)
    pa = _cobro(eid, [{"id": a, "monto": 100}], 100, 10); pb = _cobro(eid, [{"id": b, "monto": 100}], 100, 11)
    with Session(engine_empresa(eid)) as s:
        assert M.revertir_cobros_rechazado(s, eid, s.get(Documento, a), "error") == 0          # la caja ya devolvió el dinero
        assert M.revertir_cobros_rechazado(s, eid, s.get(Documento, b), "rechazado") == 0      # ya estaba rechazado
        assert s.get(modulos.Pago, pa) and s.get(modulos.Pago, pb)


def test_la_nube_revierte_al_recibir_el_rechazo():
    eid, _ = _admin_empresa("-r3e", "3101415005")
    _banco(eid)
    _doc(eid, 12, FECHA, estado="enviado")
    did = _id(eid, 12)
    pid = _cobro(eid, [{"id": did, "monto": 400}], 400, 12)
    with Session(engine_empresa(eid)) as s:
        ok, err = sinc._guardar_documentos(s, eid, [{"clave": f"506{12:047d}", "estado": "rechazado", "mensaje_hacienda": "Rechazado (QA)"}], "2")
    assert len(ok) == 1 and not err
    with Session(engine_empresa(eid)) as s:
        assert s.get(modulos.Pago, pid) is None and s.get(Documento, did).estado == "rechazado"
    assert _movs(eid) == []


def _limpiar_intentos():
    with Session(engine) as sc:
        for x in sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "sinc")).all():
            sc.delete(x)
        sc.commit()


def test_codigo_largo_y_tope_persistente():
    eid, t = _admin_empresa("-r1a", "3101415006")
    _limpiar_intentos()
    try:
        codigo = c.post("/api/sinc/codigo", headers=H(t), json={"nombre": "Caja"}).json()["codigo"]
        assert re.fullmatch(rf"L{eid}-([2-9A-HJ-NP-Z]{{4}}-){{3}}[2-9A-HJ-NP-Z]{{4}}", codigo)
        assert c.post("/api/sinc/canje", json={"codigo": codigo, "nombre": "Caja"}).status_code == 200   # lo bueno no gasta intentos
        for _ in range(10):
            assert c.post("/api/sinc/canje", json={"codigo": f"L{eid}-AAAA-AAAA-AAAA-AAAA"}).status_code == 400
        with Session(engine) as sc:
            assert len(sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "sinc")).all()) == 10   # en la base: vale para todos los procesos
        assert c.post("/api/sinc/canje", json={"codigo": codigo}).status_code == 429
    finally:
        _limpiar_intentos()


def test_vincular_solo_por_conexion_segura(monkeypatch):
    monkeypatch.delenv("FE_SINC_HTTP", raising=False)
    assert sinc._url_nube_segura("https://fisitaap.com")
    assert sinc._url_nube_segura("http://127.0.0.1:8055")
    assert not sinc._url_nube_segura("http://fisitaap.com")
    assert not sinc._url_nube_segura("httpx://fisitaap.com")
    assert not sinc._url_nube_segura("fisitaap.com")
    monkeypatch.setenv("FE_SINC_HTTP", "1")
    assert sinc._url_nube_segura("http://nube")


def test_migraciones_corren_una_vez_y_reintentan_si_fallan(monkeypatch):
    marca = M.DATA_DIR / "migraciones_unicas.json"
    marca.unlink(missing_ok=True)
    llamadas = {"hotel": 0}

    def hotel(sc):
        llamadas["hotel"] += 1
        if llamadas["hotel"] == 1:
            raise RuntimeError("falla QA")
        return {}
    monkeypatch.setattr(M.auth, "migrar_roles_hotel", hotel)
    M._migraciones_unicas()
    assert llamadas == {"hotel": 1} and not marca.exists()                     # falló: se reintenta en el próximo arranque
    M._migraciones_unicas(); M._migraciones_unicas()
    assert llamadas == {"hotel": 2} and json.loads(marca.read_text(encoding="utf-8")) == ["roles_hotel_3_20"]


def test_arranque_incluye_las_migraciones_y_no_la_de_moneda():
    t = (pathlib.Path(__file__).resolve().parents[1] / "app" / "main.py").read_text(encoding="utf-8")
    i = t.index("def arranque():")
    assert "_migraciones_unicas()" in t[i:t.index("def _migraciones_unicas", i)]
    assert "def _migrar_moneda_items" not in t
    assert "def migrar_rol_avanzado" not in (pathlib.Path(__file__).resolve().parents[1] / "app" / "auth.py").read_text(encoding="utf-8")


def test_consultar_otra_vez_no_borra_la_nota_y_la_nota_va_primero(monkeypatch):
    eid, _ = _admin_empresa("-r3f", "3101415007")
    _banco(eid)
    _doc(eid, 20, FECHA, estado="enviado")
    did = _id(eid, 20)
    _cobro(eid, [{"id": did, "monto": 500}], 500, 20)
    _rechazar(monkeypatch, eid, did)
    with Session(engine_empresa(eid)) as s:
        m1 = s.get(Documento, did).mensaje_hacienda
    assert m1.startswith("Se revirtió el cobro #20") and m1.endswith("Rechazado (QA)")
    _rechazar(monkeypatch, eid, did)
    with Session(engine_empresa(eid)) as s:
        assert s.get(Documento, did).mensaje_hacienda == m1


def test_un_cobro_que_falla_no_corta_los_demas(monkeypatch):
    eid, _ = _admin_empresa("-r3g", "3101415008")
    _banco(eid)
    _doc(eid, 21, FECHA, estado="enviado")
    did = _id(eid, 21)
    a = _cobro(eid, [{"id": did, "monto": 100}], 100, 21); b = _cobro(eid, [{"id": did, "monto": 200}], 200, 22)
    original = modulos.aplicar_cambios
    llamadas = []

    def falla_una(*x, **k):
        llamadas.append(1)
        if len(llamadas) == 1:
            raise RuntimeError("base ocupada (QA)")
        return original(*x, **k)
    monkeypatch.setattr(modulos, "aplicar_cambios", falla_una)
    _rechazar(monkeypatch, eid, did)
    with Session(engine_empresa(eid)) as s:
        assert s.get(modulos.Pago, a) is not None and s.get(modulos.Pago, b) is None
        m = s.get(Documento, did).mensaje_hacienda
    assert "no se pudo revertir" in m and "Se revirtió el cobro #22" in m


def test_la_nota_de_debito_tambien_revierte(monkeypatch):
    eid, _ = _admin_empresa("-r3h", "3101415009")
    _banco(eid)
    _doc(eid, 22, FECHA, estado="enviado")
    did = _id(eid, 22)
    with Session(engine_empresa(eid)) as s:
        d = s.get(Documento, did); d.tipo_documento = "02"; s.add(d); s.commit()
    pid = _cobro(eid, [{"id": did, "monto": 50}], 50, 23)
    _rechazar(monkeypatch, eid, did)
    with Session(engine_empresa(eid)) as s:
        assert s.get(modulos.Pago, pid) is None


def test_la_caja_puede_anular_lo_rechazado_sin_sacar_otra_vez_el_dinero():
    t = (pathlib.Path(__file__).resolve().parents[1] / "app" / "static" / "js" / "pages" / "pos" / "caja.js").read_text(encoding="utf-8")
    assert "} else if (d.estado !== 'rechazado') { this.cobrando = false;" in t and "for (const m of (rechazado ? [] : (v.medios || [])))" in t
    assert not sinc._url_nube_segura("https://[fisitaap.com")
