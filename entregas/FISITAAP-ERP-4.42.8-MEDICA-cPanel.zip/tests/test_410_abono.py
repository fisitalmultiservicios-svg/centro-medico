# -*- coding: utf-8 -*-
"""4.10: abono desde el estado de cuenta (cancelar todo o ciertas facturas, parciales, sin duplicar con la misma clave)."""
import json
import pathlib
import re
import shutil
import subprocess

import pytest

from test_387_r6_privacidad import ent, LINEAS  # noqa: F401  (empresa @example.test que se borra al final)

JS = pathlib.Path(__file__).resolve().parents[1] / "app" / "static" / "js"
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")


def _fiado(ent, cid, precio):
    lin = [{**LINEAS[0], "precio_unitario": precio}]
    r = ent.c.post("/api/comprobantes", json={"tipo_documento": "04", "condicion_venta": "02", "plazo_credito": 30, "medio_pago": "01", "cliente_id": cid, "lineas": lin}, headers=ent.h("admin"))
    assert r.status_code == 200, r.text
    return r.json()


def test_abono_a_varias_facturas_y_parcial_sin_duplicar(ent):
    ent.usuario("admin", "Administrador")
    from app import main as M
    c = ent.c.post("/api/clientes", json={"nombre": "Revendedora Abono QA", "tipo": "Cliente", "tipo_id": "", "numero_id": "", "celular": "88112233", "limite_credito": 200000, "activo": True}, headers=ent.h("admin"))
    assert c.status_code == 200, c.text
    cid = c.json()["id"]
    d1, d2, d3 = _fiado(ent, cid, 10000), _fiado(ent, cid, 20000), _fiado(ent, cid, 5000)   # 11.300, 22.600 y 5.650 con IVA
    hoy = M.ahora_cr().date().isoformat()
    # «cancelar todo» de dos y abono parcial a la tercera, en un solo recibo, como lo manda el modal
    cuerpo = {"tipo": "caja", "cliente_id": cid, "detalles": "Abono a 3 documentos", "fecha": hoy, "cuenta": "", "condicion_venta": "01", "medio_pago": "01",
              "moneda": "CRC", "tipo_cambio": 1, "monto": round(d1["total"] + d2["total"] + 2000, 2),
              "facturas": [{"id": d1["id"], "monto": d1["total"]}, {"id": d2["id"], "monto": d2["total"]}, {"id": d3["id"], "monto": 2000}], "idempotencia": "abono:qa410"}
    r1 = ent.c.post("/api/pagos", json=cuerpo, headers=ent.h("admin"))
    assert r1.status_code == 200, r1.text
    r2 = ent.c.post("/api/pagos", json=cuerpo, headers=ent.h("admin"))          # doble clic / respuesta perdida: el mismo recibo
    assert r2.status_code == 200 and r2.json().get("repetido") is True and r2.json()["id"] == r1.json()["id"]
    ec = ent.get("admin", f"/api/revendedoras/{cid}/estado-cuenta").json()
    pend = {x["consecutivo"]: x["saldo"] for x in ec["credito"]["documentos"]}
    assert list(pend.values()) == [round(d3["total"] - 2000, 2)] and d3["consecutivo"] in pend   # solo queda el resto de la tercera
    assert abs(ec["credito"]["saldo"] - round(d3["total"] - 2000, 2)) < 0.01
    abonos = [m for m in ec["movimientos"] if m["tipo"] == "abono"]
    assert len(abonos) == 1 and abs(abonos[0]["abono"] - cuerpo["monto"]) < 0.01     # un solo abono en el estado de cuenta
    # más de lo que debe una factura: el servidor lo rechaza (el modal tampoco lo deja)
    malo = {**cuerpo, "idempotencia": "abono:qa410b", "monto": 99999, "facturas": [{"id": d3["id"], "monto": 99999}]}
    assert ent.c.post("/api/pagos", json=malo, headers=ent.h("admin")).status_code == 400


def test_modal_y_pagina_del_abono():
    a = (JS / "pages" / "reportes" / "_abono.js").read_text(encoding="utf-8")
    assert "export const AbonoRevendedora" in a and "cancelarTodo()" in a and "repartirMonto()" in a and "export function repartir(" in a
    assert "api('/api/comprobantes?cliente_id='" in a and "api('/api/pagos', { method: 'POST'" in a and "idempotencia: this.idem" in a
    assert "CREDITO.includes(d.condicion_venta || '01')" in a and "['aceptado', 'interno'].includes(d.estado)" in a   # REP: no se abona aquí
    assert "if (e.status >= 400 && e.status < 500) this.idem = clave();" in a                                      # solo un 4xx renueva la clave
    assert "Math.round(Math.abs(f) * 100) % 2" in a and "x.toFixed(20)" in a                                       # céntimos como Python round()
    assert "{ headers: { 'X-Sucursal': '0' } }" in a and "@close=\"guardando || $emit('close')\"" in a             # todas las sucursales; no se cierra guardando
    assert "this.tcManual" in a and "cuentasMoneda.length) return toast(" in a
    assert "app.js" not in a                                                                                       # sin importar app.js
    r = (JS / "pages" / "reportes" / "revendedora.js").read_text(encoding="utf-8")
    assert "import { AbonoRevendedora } from './_abono.js';" in r and "components: { AbonoRevendedora }," in r
    assert "puedeCobrar() { return sesion.puede('cobros'); }" in r and "abono = { solo: null }" in r and "abono = { solo: row.doc_id }" in r
    assert "@guardado=\"alGuardar\"" in r and "alGuardar() { this.abono = null; this.cargar(true); }" in r


def test_centimos_como_el_servidor():
    """4.10 (revisión): el modal redondea los saldos como Python round(x, 2) (crear_pago); con Math.round, 113,565 daba 113,57 y el
    servidor rechazaba «Cancelar todo»."""
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    a = (JS / "pages" / "reportes" / "_abono.js").read_text(encoding="utf-8")
    linea = re.search(r"^const r2 = .*$", a, re.M).group(0)
    valores = [113.565, 1394.985, 56.785, 226.005, 10.125, 10.625, 10.135, 27000, 0.1 + 0.2, 4520, 11356.5 / 100, 2.675]
    codigo = linea + "\nconsole.log(JSON.stringify(" + json.dumps(valores) + ".map(r2)));"
    out = subprocess.run([node, "--input-type=module", "-e", codigo], capture_output=True, text=True, timeout=30)
    assert out.returncode == 0, out.stderr
    assert json.loads(out.stdout) == [round(x, 2) for x in valores]
