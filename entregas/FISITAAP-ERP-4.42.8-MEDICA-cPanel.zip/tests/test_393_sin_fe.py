# -*- coding: utf-8 -*-
"""3.93: con la facturación electrónica apagada (comprobantes internos, p. ej. régimen simplificado) el CABYS es opcional en el
ítem, en la importación y en la línea escrita a mano; con la facturación electrónica encendida sigue obligatorio."""
from sqlmodel import Session

from app.db import Empresa, engine
from tests.test_361_sin_hacienda import api  # noqa: F401  (empresa de comercio con la facturación electrónica apagada)


def test_cabys_opcional_sin_facturacion_electronica(api):  # noqa: F811
    c, e, ctx = api
    r = c.post("/api/productos", json={"nombre": "Perfume sin CABYS 393", "precio": 5000, "tipo": "Producto", "inventariable": False})
    assert r.status_code == 200, r.text
    pid = r.json()["id"]
    cli = c.post("/api/clientes", json={"nombre": "Cliente 393", "tipo": "Cliente", "tipo_id": "01", "numero_id": "101110393"}).json()
    r = c.post("/api/comprobantes", json={"tipo_documento": "01", "cliente_id": cli["id"], "lineas": [{"producto_id": pid, "cantidad": 1}]})
    assert r.status_code == 200 and r.json()["estado"] == "interno", r.text
    r = c.post("/api/comprobantes", json={"tipo_documento": "01", "cliente_id": cli["id"], "lineas": [
        {"detalle": "Envoltura de regalo", "cantidad": 1, "precio_unitario": 1000, "tarifa": 13, "codigo_tarifa": "08"}]})
    assert r.status_code == 200 and r.json()["estado"] == "interno", r.text
    # con un CABYS mal escrito se sigue rechazando
    assert c.post("/api/productos", json={"nombre": "Perfume CABYS malo 393", "precio": 5000, "tipo": "Producto", "cabys": "123"}).status_code == 400
    # con la facturación electrónica encendida, el CABYS vuelve a ser obligatorio
    with Session(engine) as s:
        em = s.get(Empresa, e.id); em.factura_electronica = True; s.add(em); s.commit()
    ctx.empresa.factura_electronica = True
    try:
        assert c.post("/api/productos", json={"nombre": "Perfume con FE 393", "precio": 5000, "tipo": "Producto"}).status_code == 400
    finally:
        with Session(engine) as s:
            em = s.get(Empresa, e.id); em.factura_electronica = False; s.add(em); s.commit()
        ctx.empresa.factura_electronica = False


def test_pantallas_piden_cabys_solo_con_facturacion_electronica():
    import pathlib
    js = pathlib.Path(__file__).resolve().parent.parent / "app" / "static" / "js" / "pages" / "inventario"
    assert "f.es_venta !== false && sesion.electronica" in (js / "item-form.js").read_text(encoding="utf-8")
    assert "(!cabys && sesion.electronica)" in (js / "gestion.js").read_text(encoding="utf-8")
