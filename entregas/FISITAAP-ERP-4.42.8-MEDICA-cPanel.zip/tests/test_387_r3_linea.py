"""3.87 (segunda ronda, r3_linea): Ventas en línea y sitio público.
- comercio-r8 / restaurante-r2  El modo cajero (Cajero, Mesero) solo abre Pedidos, el detalle y Express pendientes en Ventas en línea:
                                otra pantalla escrita a mano vuelve a Pedidos sin pedir datos.
- restaurante-r3                Express pendientes, Zonas de envío y Entregas sin el extra Entregas: «No incluido en su plan».
- publico-n1                    La 404 del portal de soporte (/soporte/<portal>) es la variante neutra, sin la venta del sistema.
- publico-n2                    La tienda ofrece «Cerrar sesión» al cliente y a la revendedora fuera de la tarjeta lateral oculta.
- publico-n3                    /terminos.html declara su ícono (el navegador ya no pide /favicon.ico).
- restaurante-r6                «Publicar express» y el detalle del pedido traen el PIN de entrega; el motorizado sigue sin recibirlo.
- publico-c2                    Los puntos ganados por un pedido hecho con sesión van a esa cuenta (al entregar, al cerrar la entrega el
                                negocio o el motorizado, y al cobrarlo en la caja); el pedido de invitado sigue con el teléfono del pedido."""
import pathlib
import re
import types
import uuid

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, entregas, modulos, pedidos
from app.db import Empresa, engine, engine_empresa, init_db
from app.main import app

init_db()
RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
NAV = {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
LIB = (10.0, -84.0)
ROLES = {"Administrador": None, "Cajero": None, "Mesero": {"ver", "pos"}}


def _static(*partes) -> str:
    return (RAIZ / "static").joinpath(*partes).read_text(encoding="utf-8")


# ------------------------------------------------------------------------------------------------ comercio-r8 / restaurante-r2
def test_ventas_en_linea_modo_cajero_solo_abre_pedidos():
    app_js = _static("js", "fis", "app.js")
    cuerpo = app_js.split("async function cargarRuta() {", 1)[1].split("\n}\n", 1)[0]
    m = re.search(r"if \(sesion\.listo && sesion\.modoCajero && !\[([^\]]*)\]\.includes\(ruta\)\) \{ location\.replace\('#/pedidos'\); return; \}", cuerpo)
    assert m, "cargarRuta no revisa el modo cajero"
    permitidas = set(re.findall(r"'([^']+)'", m.group(1)))
    claves_caja = re.search(r"const CLAVES_CAJA = \[([^\]]*)\]", _static("js", "menu.js")).group(1)
    assert set(re.findall(r"'([^']+)'", claves_caja)) | {"pedido"} == permitidas   # lo que el menú le muestra a la caja, y el detalle
    # la guarda va antes de importar la pantalla (no se piden sus datos)
    assert cuerpo.index("sesion.modoCajero") < cuerpo.index("await import(")
    # la miga «Ventas en línea» del cajero lleva a sus pedidos
    assert """<a :href="sesion.modoCajero ? '#/pedidos' : '#/resumen'">Ventas en línea</a>""" in app_js


# ------------------------------------------------------------------------------------------------ restaurante-r3
def test_pantallas_del_extra_entregas_no_cargan_sin_el_extra():
    app_js = _static("js", "fis", "app.js")
    cuerpo = app_js.split("async function cargarRuta() {", 1)[1].split("\n}\n", 1)[0]
    assert "if (def.modulo && sesion.listo && !sesion.tieneModulo(def.modulo)) { estado.comp = null; estado.titulo = 'No incluido en su plan';" in cuerpo
    assert cuerpo.index("def.modulo") < cuerpo.index("await import(")
    for clave in ("'express-pendientes'", "delivery", "afiliados", "invitaciones", "'entregas-historial'"):
        assert re.search(r"(?<![\w'-])" + re.escape(clave) + r": \{[^}]*modulo: 'entregas'", app_js), clave
    for clave in ("pedidos", "pedido", "resumen", "configuracion", "kpis"):           # el resto de Ventas en línea no depende del extra
        assert not re.search(r"(?<![\w'-])" + clave + r": \{[^}]*modulo:", app_js), clave
    # el menú declara el mismo extra para esas entradas
    menu = _static("js", "menu.js")
    assert "fis('express-pendientes', 'Express pendientes'), tipos: ['restaurante'], modulo: 'entregas' }" in menu
    assert "{ ...fis('delivery', 'Zonas de envío'), modulo: 'entregas' }" in menu and "{ label: 'Entregas', permiso: 'pos', modulo: 'entregas'" in menu
    # la tarjeta dice qué falta, no «Esa pantalla no existe»
    assert "<p v-if=\"estado.titulo === 'No incluido en su plan'\">Esta pantalla es parte del extra Ventas en línea · Entregas" in app_js


# ------------------------------------------------------------------------------------------------ publico-n1
def test_404_del_portal_de_soporte_sin_la_marca_del_sistema():
    c = TestClient(app)
    ruta = "/soporte/portal-que-no-existe-387"
    r = c.get(ruta, headers=NAV)
    assert r.status_code == 404 and r.headers["content-type"].startswith("text/html")
    assert "Portal no encontrado" in r.text and "noindex" in r.text
    assert "/precios" not in r.text and "Prueba gratis" not in r.text and "Brillante" not in r.text and "wa.me" not in r.text
    assert 'href="/"' not in r.text                                         # fuera del dominio de un negocio, sin «Ir al inicio» del sistema
    assert c.head(ruta, headers=NAV).status_code == 404
    # la API del portal y los programas que no piden HTML siguen en JSON
    assert c.get(ruta).headers["content-type"].startswith("application/json") and c.get(ruta).json()["detail"] == "Portal no encontrado"
    assert c.get("/api/soporte/portal-que-no-existe-387", headers=NAV).json()["detail"] == "Portal no encontrado"
    # el resto del sitio conserva la 404 con la marca
    otra = c.get("/no-existe-387", headers=NAV)
    assert otra.status_code == 404 and "/precios" in otra.text
    assert "/precios" in c.get("/soporte", headers=NAV).text                    # /soporte sin portal no es del cliente de un negocio


def test_404_del_portal_de_soporte_apagado_sin_la_marca_del_sistema():
    from app import tike
    with Session(engine) as s:
        e = Empresa(nombre="Soporte Apagado QA 387", numero_id="3101387412", actividad="620100", otras_senas="QA 387", correo="soporte387@example.test",
                    ambiente="sandbox", tipo_negocio="servicios")
        s.add(e); s.commit(); s.refresh(e)
    try:
        with Session(engine) as s:
            s.add(tike.TikeSlug(slug="portal-apagado-387", empresa_id=e.id)); s.commit()
        with Session(engine_empresa(e.id)) as s:
            cfg = tike._config(s, e.id); cfg.slug = "portal-apagado-387"; cfg.portal_activo = False; s.add(cfg); s.commit()
        c = TestClient(app)
        r = c.get("/soporte/portal-apagado-387", headers=NAV)
        assert r.status_code == 404 and "Portal no encontrado" in r.text and "/precios" not in r.text and "Brillante" not in r.text
        with Session(engine_empresa(e.id)) as s:
            cfg = tike._config(s, e.id); cfg.portal_activo = True; s.add(cfg); s.commit()
        assert c.get("/soporte/portal-apagado-387", headers=NAV).status_code == 200             # encendido, el portal abre igual que antes
    finally:
        with Session(engine) as s:
            for f in s.exec(select(tike.TikeSlug).where(tike.TikeSlug.empresa_id == e.id)).all():
                s.delete(f)
            x = s.get(Empresa, e.id)
            if x:
                s.delete(x)
            s.commit()


# ------------------------------------------------------------------------------------------------ publico-n2
def test_tienda_ofrece_cerrar_sesion_fuera_de_la_tarjeta_oculta():
    js = _static("js", "tienda.js")
    cuenta = js[js.index("<template v-else-if=\"vista === 'cuenta'\">"):]
    cuenta = cuenta[:cuenta.index("</template>")]
    sin_tarjeta = re.sub(r'<aside class="card admin-card account-nav">.*?</aside>', "", cuenta, flags=re.S)
    assert re.search(r'<form @submit\.prevent="salir"[^>]*><button[^>]*>Cerrar sesión</button></form>', sin_tarjeta)
    # también en el menú ☰ (solo con sesión)
    menu = re.search(r'<div class="mobile-menu-panel".*?</div></div></header>', js, flags=re.S).group(0)
    assert re.search(r'<form v-if="cliente" @submit\.prevent="menu = false; salir\(\)"><button class="mobile-menu-action"[^>]*>Cerrar sesión</button></form>', menu)
    # las hojas de FISITAAP siguen ocultando la tarjeta lateral: por eso el botón va fuera de ella
    assert ".account-nav{display:none!important}" in _static("fisitaap", "assets", "interface-r15.css")


# ------------------------------------------------------------------------------------------------ publico-n3
def test_terminos_declara_su_icono():
    html = _static("terminos.html")
    cab = html[:html.index("</head>")]
    m = re.search(r'<link rel="icon"[^>]*href="([^"]+)"', cab)
    assert m, 'terminos.html sin <link rel="icon">: el navegador pide /favicon.ico (404)'
    assert (RAIZ / "static" / m.group(1).lstrip("/")).exists()
    assert TestClient(app).get(m.group(1)).status_code == 200


# ------------------------------------------------------------------------------------------------ servidor: empresa con Entregas
@pytest.fixture
def soda():
    """Restaurante sin plan (todo encendido, también Entregas), con caja, zona y un motorizado; el rol se cambia con c.como(rol)."""
    with Session(engine) as s:
        e = Empresa(nombre="Soda Linea QA 387", numero_id="3101387413", actividad="561001", otras_senas="Frente al parque", correo="sodalinea387@example.test",
                    ambiente="sandbox", tipo_negocio="restaurante")
        s.add(e); s.commit(); s.refresh(e)
    with Session(engine_empresa(e.id)) as s:
        modulos.reemplazar(s, e.id, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja QA 387", "modo": "restaurante", "mesas": []}]})
    estado = {"rol": "Administrador"}
    usuario = types.SimpleNamespace(id=None, correo="dueno.linea387@example.test", es_superadmin=False, nombre="QA 387")
    app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(usuario, e, estado["rol"], permisos=ROLES.get(estado["rol"]))
    c = TestClient(app)

    def como(rol):
        estado["rol"] = rol
        return c
    c.como = como
    c.eid = e.id
    c.slug = "soda-linea-387-" + uuid.uuid4().hex[:6]
    c.base = "/api/publico/" + c.slug
    try:
        adm = c.como("Administrador")
        c.prod = adm.post("/api/productos", json={"nombre": "Casado Linea 387", "cabys": "2111100000000", "precio": 10000, "tarifa": 13, "codigo_tarifa": "08",
                                                  "visible_catalogo": True, "categoria": "Platos"}).json()
        assert adm.put("/api/pedidos/negocio", json={"slug": c.slug, "activo": True, "nombre": "Soda Linea 387", "acepta_recoger": True, "acepta_domicilio": True,
                                                     "costo_envio": 1000, "minimo_pedido": 0, "horarios": [], "redes": {}, "abierto_manual": True}).status_code == 200
        assert adm.put("/api/entregas/ubicacion", json={"lat": LIB[0], "lng": LIB[1]}).status_code == 200
        assert adm.post("/api/entregas/zonas", json={"nombre": "Centro", "lat": LIB[0], "lng": LIB[1], "radio_km": 3, "precio": 1200}).status_code == 200
        assert adm.post("/api/entregas/motorizados", json={"nombre": "Moto Linea", "telefono": "87001413", "vehiculo": "moto", "pago_entrega": 1000, "clave": "2580"}).status_code == 200
        yield c
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            for f in s.exec(select(pedidos.SlugPublico).where(pedidos.SlugPublico.empresa_id == e.id)).all():
                s.delete(f)
            x = s.get(Empresa, e.id)
            if x:
                s.delete(x)
            s.commit()
        pedidos._cache_slugs.clear()


def _pedido(c, telefono, tipo="domicilio", headers=None, nombre="Cliente QA"):
    cuerpo = {"nombre": nombre, "telefono": telefono, "tipo": tipo, "lineas": [{"producto_id": c.prod["id"], "cantidad": 1}]}   # 11 300 sin envío
    if tipo == "domicilio":
        cuerpo |= {"direccion": "Casa azul QA", "lat": LIB[0] + 0.01, "lng": LIB[1]}
    r = c.post(c.base + "/pedido", json=cuerpo, headers=headers or {})
    assert r.status_code == 200, r.text
    return r.json()


def _moto(c):
    acc = c.post(c.base + "/motorizado/acceso", json={"telefono": "87001413", "clave": "2580"})
    assert acc.status_code == 200, acc.text
    return {"X-Motorizado": acc.json()["token"]}


# ------------------------------------------------------------------------------------------------ restaurante-r6
def test_publicar_express_devuelve_el_pin_a_la_caja_y_no_al_motorizado(soda):
    c = soda
    for n, rol in enumerate(("Cajero", "Mesero", "Administrador")):
        ped = _pedido(c, f"8888141{n}", nombre="Cliente " + rol)
        c.como(rol)
        conf = c.put(f"/api/pedidos/{ped['id']}/estado", json={"estado": "confirmado"})
        assert conf.status_code == 200 and conf.json().get("entrega"), (rol, conf.text)
        en = conf.json()["entrega"]
        r = c.put(f"/api/entregas/{en['id']}/asignar", json={"motorizado_id": None})
        assert r.status_code == 200 and r.json()["estado"] == "liberada", r.text
        with Session(engine_empresa(c.eid)) as s:
            pin = s.get(entregas.Entrega, en["id"]).pin
        assert r.json().get("pin") == pin and len(pin) == 4, (rol, r.json())
        # el detalle del pedido (lista de Pedidos) trae el mismo PIN para el recuadro «PIN para recibir el pedido»
        det = next(x for x in c.get("/api/pedidos").json() if x["id"] == ped["id"])
        assert det["entrega"]["pin"] == pin, (rol, det["entrega"])
    # el motorizado no lo recibe en ninguna lista ni al aceptar
    H = _moto(c)
    lista = c.get(c.base + "/motorizado/entregas", headers=H).json()
    assert len(lista["libres"]) == 3 and all("pin" not in x for x in lista["libres"] + lista.get("mias", []) + lista.get("cerradas", []))
    ac = c.put(f"{c.base}/motorizado/entregas/{lista['libres'][0]['id']}/aceptar", headers=H)
    assert ac.status_code == 200 and "pin" not in ac.json()


# ------------------------------------------------------------------------------------------------ publico-c2
def _saldo(c, telefono):
    """Saldo de puntos de un teléfono (lo lee el Administrador; el rol del cliente queda en Administrador)."""
    return c.como("Administrador").get(f"/api/fidelizacion/saldo?telefono={telefono}").json()["saldo"]


def test_puntos_ganados_van_a_la_cuenta_con_que_se_pidio(soda):
    c = soda
    adm = c.como("Administrador")
    assert adm.put("/api/fidelizacion/config", json={"activo": True, "puntos_por_mil": 10, "valor_punto": 5, "minimo_canje": 50, "maximo_pct": 50}).status_code == 200
    cli = c.post(c.base + "/cliente/acceso", json={"telefono": "87651111", "pin": "4321", "nombre": "Clienta QA"}).json()
    H = {"X-Cliente": cli["token"]}
    pts = lambda: c.get(c.base + "/puntos", headers=H).json()["saldo"]   # noqa: E731

    # 1) la clienta pide para su mamá (otro teléfono) y el negocio lo marca entregado
    p1 = _pedido(c, "88651111", tipo="recoger", headers=H, nombre="Para mi mamá")
    assert p1["cliente_final_id"]
    assert adm.put(f"/api/pedidos/{p1['id']}/estado", json={"estado": "entregado"}).status_code == 200
    assert pts() == 113 and _saldo(c, "88651111") == 0

    # 2) a domicilio: el negocio cierra la entrega desde Express pendientes (también con la caja)
    p2 = _pedido(c, "88652222", headers=H)
    en2 = c.como("Cajero").put(f"/api/pedidos/{p2['id']}/estado", json={"estado": "confirmado"}).json()["entrega"]
    assert c.put(f"/api/entregas/{en2['id']}/entregada").status_code == 200
    assert pts() == 226 and _saldo(c, "88652222") == 0

    # 3) a domicilio: lo cierra el motorizado con el PIN del cliente
    p3 = _pedido(c, "88653333", headers=H)
    en3 = c.como("Administrador").put(f"/api/pedidos/{p3['id']}/estado", json={"estado": "confirmado"}).json()["entrega"]
    pin = c.put(f"/api/entregas/{en3['id']}/asignar", json={"motorizado_id": None}).json()["pin"]
    HM = _moto(c)
    for paso in ("aceptar", "recogida", "en-camino"):
        assert c.put(f"{c.base}/motorizado/entregas/{en3['id']}/{paso}", headers=HM).status_code == 200, paso
    assert c.put(f"{c.base}/motorizado/entregas/{en3['id']}/entregada", json={"pin": pin}, headers=HM).status_code == 200
    assert pts() == 339 and _saldo(c, "88653333") == 0

    # 4) la caja cobra el pedido (manda el teléfono de la cuenta en espera, el del formulario): a la cuenta; después, al entregar, no se duplica
    p4 = _pedido(c, "88654444", tipo="recoger", headers=H)
    caja = c.como("Cajero")
    assert caja.put(f"/api/pedidos/{p4['id']}/estado", json={"estado": "confirmado"}).status_code == 200
    with Session(engine_empresa(c.eid)) as s:
        cuenta = next(x for x in modulos.leer(s, c.eid, "pos_espera", []) if x.get("pedido_id") == p4["id"])
    assert cuenta["telefono"] == "88654444"
    r = caja.post("/api/fidelizacion/acreditar", json={"telefono": cuenta["telefono"], "monto": 11300, "referencia": f"pedido:{p4['id']}", "nombre": cuenta["nombre"]})
    assert r.status_code == 200 and r.json()["puntos"] == 113, r.text
    assert pts() == 452 and _saldo(c, "88654444") == 0
    assert c.como("Cajero").put(f"/api/pedidos/{p4['id']}/estado", json={"estado": "entregado"}).status_code == 200
    assert pts() == 452
    # la caja sigue sin poder pasar los puntos de ese pedido a un teléfono cualquiera
    assert c.como("Cajero").post("/api/fidelizacion/acreditar", json={"telefono": "87776655", "monto": 11300, "referencia": f"pedido:{p4['id']}"}).status_code == 400

    # 5) el pedido de invitado sigue acreditando al teléfono del pedido (al entregar y al cobrar en la caja)
    g1 = _pedido(c, "88655555", tipo="recoger", nombre="Invitado QA")
    assert g1["cliente_final_id"] is None
    assert c.como("Administrador").put(f"/api/pedidos/{g1['id']}/estado", json={"estado": "entregado"}).status_code == 200
    assert _saldo(c, "88655555") == 113
    g2 = _pedido(c, "88656666", tipo="recoger", nombre="Invitado QA 2")
    assert c.como("Cajero").put(f"/api/pedidos/{g2['id']}/estado", json={"estado": "confirmado"}).status_code == 200
    assert c.post("/api/fidelizacion/acreditar", json={"telefono": "88656666", "monto": 11300, "referencia": f"pedido:{g2['id']}"}).json()["puntos"] == 113
    assert _saldo(c, "88656666") == 113 and pts() == 452

    # 6) un acceso que el negocio restableció: sus pedidos vuelven al teléfono del pedido
    p6 = _pedido(c, "88657777", tipo="recoger", headers=H)
    assert c.como("Administrador").delete(f"/api/pedidos/clientes/{p1['cliente_final_id']}").status_code == 200
    with Session(engine_empresa(c.eid)) as s:
        assert pedidos.telefono_puntos(s, s.get(pedidos.Pedido, p6["id"])) == "88657777"
    assert c.put(f"/api/pedidos/{p6['id']}/estado", json={"estado": "entregado"}).status_code == 200
    assert _saldo(c, "88657777") == 113 and _saldo(c, "87651111") == 452
