"""3.61: interruptor «Facturación electrónica» por empresa. Apagado: los comprobantes quedan «interno» (sin firma, sin cola, sin
envío a Hacienda), el PDF dice «Comprobante de venta» sin clave ni leyenda, se anulan directo, se mandan por correo solo en PDF
y la nota de crédito puede referirse a ellos. Encendido: todo como antes. Además, reabrir el día del hotel (DELETE del paquete)."""
import io
import types

from fastapi.testclient import TestClient
from pypdf import PdfReader
from sqlmodel import Session, select

import pytest

from app import auth
from app.db import Empresa, engine, init_db

LINEAS = [{"cabys": "8399000009900", "detalle": "Casado", "cantidad": 1, "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]


@pytest.fixture()
def api():
    from app.main import app
    init_db()
    with Session(engine) as s:
        e = s.exec(select(Empresa).where(Empresa.nombre == "Pulpería Sin Hacienda QA")).first()
        if not e:
            e = Empresa(nombre="Pulpería Sin Hacienda QA", numero_id="3101361361", actividad="471101", otras_senas="Frente a la escuela",
                        correo="pulpe361@example.test", ambiente="sandbox", tipo_negocio="comercio")
            s.add(e)
        e.factura_electronica = False
        s.add(e); s.commit(); s.refresh(e); s.expunge(e)
    usuario = types.SimpleNamespace(id=None, correo="qa-361@example.test", es_superadmin=False, nombre="QA")
    ctx = auth.Contexto(usuario, e, "Administrador")
    app.dependency_overrides[auth.contexto] = lambda: ctx
    try:
        yield TestClient(app), e, ctx
    finally:
        app.dependency_overrides.clear()


def _texto_pdf(contenido: bytes) -> str:
    return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(contenido)).pages)


def test_comprobante_interno_sin_hacienda(api):
    c, e, ctx = api
    assert c.get("/api/empresa").json()["factura_electronica"] is False
    cli = c.post("/api/clientes", json={"nombre": "Doña Marta", "tipo": "Cliente", "tipo_id": "01", "numero_id": "101110111", "correo": "marta@example.test"}).json()
    r = c.post("/api/comprobantes", json={"tipo_documento": "01", "cliente_id": cli["id"], "lineas": LINEAS})
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["estado"] == "interno" and d["consecutivo"]

    # no se envía a Hacienda ni por el botón ni por la cola
    r = c.post(f"/api/comprobantes/{d['id']}/enviar")
    assert r.status_code == 400 and "interno" in r.json()["detail"]

    # PDF: comprobante de venta, sin clave ni leyenda de Hacienda
    p = c.get(f"/api/comprobantes/{d['id']}/pdf")
    assert p.status_code == 200 and p.content[:4] == b"%PDF"
    txt = _texto_pdf(p.content)
    assert "Comprobante de venta" in txt
    assert "electrónica" not in txt.lower() and "Clave" not in txt and "MH-DGT-RES" not in txt
    t = c.get(f"/api/comprobantes/{d['id']}/tiquete")
    if t.status_code == 200:
        assert "Clave:" not in _texto_pdf(t.content)

    # tiquete (04) también interno; nota de crédito sobre un interno: permitida
    tq = c.post("/api/comprobantes", json={"tipo_documento": "04", "cliente_id": cli["id"], "lineas": LINEAS}).json()
    assert tq["estado"] == "interno"
    nc = c.post("/api/comprobantes", json={"tipo_documento": "03", "cliente_id": cli["id"], "lineas": LINEAS, "condicion_venta": "01",
                                           "referencia_clave": d["clave"], "referencia_fecha": d["fecha_emision"], "referencia_codigo": "01", "referencia_razon": "Devolución"})
    assert nc.status_code == 200, nc.text
    assert nc.json()["estado"] == "interno" and "Nota de crédito" in _texto_pdf(c.get(f"/api/comprobantes/{nc.json()['id']}/pdf").content)

    # anular directo (nunca fue a Hacienda)
    assert c.post(f"/api/comprobantes/{tq['id']}/anular").status_code == 200
    assert c.get(f"/api/comprobantes/{tq['id']}").json()["estado"] == "rechazado"      # así marca el sistema lo anulado


def test_encendido_vuelve_a_firmar_o_generar(api):
    c, e, ctx = api
    with Session(engine) as s:
        em = s.get(Empresa, e.id); em.factura_electronica = True; s.add(em); s.commit()
    ctx.empresa.factura_electronica = True
    assert c.get("/api/empresa").json()["factura_electronica"] is True
    cli = c.post("/api/clientes", json={"nombre": "Don Juan", "tipo": "Cliente", "tipo_id": "01", "numero_id": "202220222"}).json()
    d = c.post("/api/comprobantes", json={"tipo_documento": "04", "cliente_id": cli["id"], "lineas": LINEAS}).json()
    assert d["estado"] == "generado"                      # sin certificado queda generado (como siempre), ya no interno
    txt = _texto_pdf(c.get(f"/api/comprobantes/{d['id']}/pdf").content)
    assert "Tiquete electrónico" in txt


def test_reabrir_dia_del_hotel(api):
    c, e, ctx = api
    cuerpo = {"fecha": "2026-11-03", "usuario": "qa", "notas": "", "resumen": {"ocupadas": 1, "total": 2, "pct": 50, "cargos": 10, "pagos": 5}, "pendientes": [], "kpis": [], "secciones": []}
    assert c.post("/api/hotel/cierre-paquete", json=cuerpo).status_code == 200
    assert c.delete("/api/hotel/cierre-paquete/2026-11-03").status_code == 400                     # sin motivo
    r = c.delete("/api/hotel/cierre-paquete/2026-11-03?motivo=Faltaba%20una%20salida")
    assert r.status_code == 200 and r.json()["pdf_borrado"] is True
    assert "2026-11-03" not in c.get("/api/hotel/cierre-paquete").json()["fechas"]
    r = c.delete("/api/hotel/cierre-paquete/2026-11-03?motivo=Otra%20vez")
    assert r.status_code == 200 and r.json()["pdf_borrado"] is False                                 # reabrir sin PDF también vale
    assert c.delete("/api/hotel/cierre-paquete/ayer?motivo=xxxxx").status_code == 404
