"""3.80: varios administradores del sistema y un super administrador. El super administrador (el de la instalación) agrega a otros
(cuenta nueva con contraseña temporal o un usuario que ya existe), los quita y elige qué empresas NO ve cada uno; por defecto ven
todas, también las nuevas. Los demás administradores no administran administradores. Todo queda auditado. Al terminar se borran los
administradores de prueba (otras pruebas esperan una instalación sin administrador)."""
import json

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth
from app.db import Empresa, engine, init_db
from app.main import app

CORREOS = ("admin1.380@example.test", "companero.380@example.test", "usuario.380@example.test", "limitado.380@example.test")


def _usuario(correo):
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
        if u:
            s.expunge(u)
        return u


def _como(u):
    """La consola con este usuario: se reemplaza solo la sesión (solo_usuario); la dependencia superadmin real se ejecuta."""
    app.dependency_overrides[auth.solo_usuario] = lambda: _usuario(u.correo)


@pytest.fixture
def consola():
    init_db()
    with Session(engine) as s:
        yo = auth.Usuario(correo=CORREOS[0], nombre="Admin Uno QA", password_hash=auth.hash_password("Clave-larga-380-qa"), es_superadmin=True,
                          admin_principal=True, mfa_activo=True)
        s.add(yo); s.commit(); s.refresh(yo); s.expunge(yo)
    _como(yo)
    try:
        yield TestClient(app), yo
    finally:
        app.dependency_overrides.pop(auth.solo_usuario, None)
        with Session(engine) as s:
            for x in s.exec(select(auth.Usuario).where(auth.Usuario.correo.in_(CORREOS))).all():  # type: ignore[attr-defined]
                s.delete(x)
            s.commit()


def test_agregar_listar_y_quitar_administradores(consola):
    c, yo = consola
    lista = c.get("/api/admin/administradores").json()
    assert any(x["correo"] == yo.correo and x["yo"] and x["principal"] for x in lista)
    r = c.post("/api/admin/administradores", json={"nombre": "  Compañero   QA ", "correo": "Companero.380@Example.test", "enviar_correo": False}); assert r.status_code == 200, r.text
    j = r.json(); assert j["password_temporal"] and j["correo_enviado"] is False and j["administrador"]["nombre"] == "Compañero QA" and not j["administrador"]["principal"]
    nuevo = _usuario("companero.380@example.test")
    assert nuevo.es_superadmin and not nuevo.admin_principal and nuevo.debe_cambiar_password and auth.verificar_password(j["password_temporal"], nuevo.password_hash)
    assert c.post("/api/admin/administradores", json={"nombre": "Otra vez", "correo": "companero.380@example.test"}).status_code == 400
    with Session(engine) as s:
        s.add(auth.Usuario(correo="usuario.380@example.test", nombre="Usuario QA", password_hash=auth.hash_password("Otra-clave-380-qa"))); s.commit()
    r = c.post("/api/admin/administradores", json={"nombre": "Usuario QA", "correo": "usuario.380@example.test", "enviar_correo": False}); assert r.status_code == 200, r.text
    assert r.json()["password_temporal"] is None and _usuario("usuario.380@example.test").es_superadmin
    assert {"companero.380@example.test", "usuario.380@example.test", yo.correo} <= {x["correo"] for x in c.get("/api/admin/administradores").json()}
    assert c.delete(f"/api/admin/administradores/{yo.id}").status_code == 400
    r = c.delete(f"/api/admin/administradores/{nuevo.id}"); assert r.status_code == 200, r.text
    assert r.json()["bloqueado"] is True
    q = _usuario("companero.380@example.test"); assert not q.es_superadmin and q.bloqueado
    assert c.delete(f"/api/admin/administradores/{nuevo.id}").status_code == 404
    acciones = [x["accion"] for x in c.get("/api/admin/auditoria").json()]
    assert "admin_sistema_agregado" in acciones and "admin_sistema_quitado" in acciones


def test_empresas_ocultas_y_solo_el_super_administrador_administra(consola):
    c, yo = consola
    with Session(engine) as s:
        oculta = auth.crear_empresa(s, "Empresa Oculta 380 QA", "oculta.380@example.test", "3101380380")
        visible = auth.crear_empresa(s, "Empresa Visible 380 QA", "visible.380@example.test", "3101380381")
        eo, ev = oculta.id, visible.id
    r = c.post("/api/admin/administradores", json={"nombre": "Limitado QA", "correo": "limitado.380@example.test", "enviar_correo": False}); assert r.status_code == 200, r.text
    lid = r.json()["administrador"]["id"]
    with Session(engine) as s:
        lim = s.get(auth.Usuario, lid); lim.mfa_activo = True; lim.debe_cambiar_password = False; s.add(lim); s.commit()
    assert c.put(f"/api/admin/administradores/{yo.id}/empresas", json={"ocultas": [eo]}).status_code == 400      # al super administrador no se le ocultan
    r = c.put(f"/api/admin/administradores/{lid}/empresas", json={"ocultas": [eo, 999999]}); assert r.status_code == 200, r.text
    assert r.json()["empresas_ocultas"] == [eo]
    assert next(x for x in c.get("/api/admin/administradores").json() if x["id"] == lid)["empresas_ocultas"] == [eo]
    # el administrador limitado: no ve la empresa oculta en ningún lado de la consola, sí la visible y las nuevas
    _como(_usuario("limitado.380@example.test"))
    ids = {x["id"] for x in c.get("/api/admin/cuentas").json()}
    assert eo not in ids and ev in ids
    assert c.get(f"/api/admin/cuentas/{eo}/pagos").status_code == 404 and c.get(f"/api/admin/cuentas/{ev}/pagos").status_code == 200
    with Session(engine) as s:
        nueva = auth.crear_empresa(s, "Empresa Nueva 380 QA", "nueva.380@example.test", "3101380382"); en = nueva.id
    assert en in {x["id"] for x in c.get("/api/admin/cuentas").json()}
    lim = _usuario("limitado.380@example.test")
    assert not auth.admin_ve_empresa(lim, eo) and auth.admin_ve_empresa(lim, ev) and auth.admin_ve_empresa(lim, en)
    assert all(x["empresa_id"] != eo for x in c.get("/api/admin/auditoria").json())
    # y no administra administradores ni bloquea al super administrador
    assert c.post("/api/admin/administradores", json={"nombre": "Otro", "correo": "otro.380@example.test"}).status_code == 403
    assert c.delete(f"/api/admin/administradores/{yo.id}").status_code == 403
    assert c.put(f"/api/admin/administradores/{lid}/empresas", json={"ocultas": []}).status_code == 403
    assert c.post(f"/api/admin/usuarios/{yo.id}/bloqueo", json={"bloquear": True}).status_code == 403
    assert not any(x["yo"] and x["principal"] for x in c.get("/api/admin/administradores").json())
    # el super administrador sigue viendo todo
    _como(yo)
    assert eo in {x["id"] for x in c.get("/api/admin/cuentas").json()}
    assert json.loads(_usuario("limitado.380@example.test").empresas_ocultas) == [eo]


def test_sin_sesion_no_hay_acceso_y_consola_trae_la_tarjeta():
    c = TestClient(app)
    assert c.get("/api/admin/administradores").status_code == 401
    assert c.post("/api/admin/administradores", json={"nombre": "Intruso", "correo": "intruso@example.test"}).status_code == 401
    js = c.get("/js/pages/admin.js").text
    assert "Administradores del sistema" in js and "/api/admin/administradores" in js and "quitarAdmin(x)" in js and "Super administrador" in js and "guardarOcultas" in js
