# -*- coding: utf-8 -*-
"""4.32, segunda pasada del arnés (S12): restaurar el respaldo de una empresa fallaba en Windows con «WinError 32» cuando, mientras se
copiaba el zip, una llamada de la sincronización volvía a abrir la base (su conexión queda abierta en el grupo del motor). En la 4.32 el
programa llama cada 5 s, así que pasa más seguido. Ahora la restauración suelta otra vez el motor y reintenta unos segundos.
Nada sale a la red: empresas de prueba con correos @example.test."""
import sqlite3
import sys
import threading

import pytest
from sqlmodel import Session, select

from app import respaldo
from app.db import EMPRESAS_DIR, Empresa, _engines, engine, engine_empresa
from tests.test_429_comanda_numero_servidor import _borrar, _nueva


def _empresa_obj(eid):
    with Session(engine) as sc:
        e = sc.get(Empresa, eid); sc.expunge(e)
    return e


def _limpiar(eid, correos):
    for x in respaldo.listar_empresa(eid):
        respaldo.eliminar_empresa(eid, x["nombre"])
    _borrar(eid, correos)


@pytest.mark.skipif(sys.platform != "win32", reason="el bloqueo de archivos abiertos es de Windows")
def test_restaurar_con_el_motor_abierto_otra_vez_mientras_se_copia_el_zip(monkeypatch):
    """Lo que pasó en S12: después de soltar el motor, una llamada lo vuelve a crear y deja su conexión en el grupo. Antes: 500 con WinError 32."""
    import shutil
    eid, tok, correos = _nueva("rw1")
    try:
        e = _empresa_obj(eid)
        zipf = respaldo.ejecutar_empresa(e, forzar=True)
        original = shutil.copyfileobj
        abiertos = []

        def copiar_y_abrir(src, dst, *a, **k):
            original(src, dst, *a, **k)
            if str(getattr(dst, "name", "")).endswith(".restaurando"):
                with Session(engine_empresa(eid)) as s:                     # como una llamada de la sincronización: crea el motor otra vez
                    s.exec(select(1)).all()
                abiertos.append(_engines.get(eid))
        monkeypatch.setattr(shutil, "copyfileobj", copiar_y_abrir)
        r = respaldo.restaurar_empresa(e, zipf)
        monkeypatch.setattr(shutil, "copyfileobj", original)
        assert abiertos and abiertos[0] is not None                       # de verdad había un motor nuevo con la base abierta
        assert r["copiados"]["base"] == 1
        with Session(engine_empresa(eid)) as s:                            # la base restaurada abre bien
            assert s.exec(select(1)).all()
    finally:
        _limpiar(eid, correos)


@pytest.mark.skipif(sys.platform != "win32", reason="el bloqueo de archivos abiertos es de Windows")
def test_restaurar_espera_a_que_otra_conexion_suelte_la_base():
    """Una conexión que no es del motor (otro hilo con la base abierta) la suelta al segundo: la restauración espera y termina."""
    import shutil
    eid, tok, correos = _nueva("rw2")
    try:
        e = _empresa_obj(eid)
        zipf = respaldo.ejecutar_empresa(e, forzar=True)
        original = shutil.copyfileobj
        cx_holder = {}

        def copiar_y_tomar(src, dst, *a, **k):
            original(src, dst, *a, **k)
            if str(getattr(dst, "name", "")).endswith(".restaurando") and "cx" not in cx_holder:
                cx = sqlite3.connect(str(EMPRESAS_DIR / f"empresa_{eid}.db"), timeout=30, check_same_thread=False)
                cx.execute("SELECT count(*) FROM sqlite_master").fetchall()
                cx_holder["cx"] = cx
                threading.Timer(1.0, cx.close).start()
        shutil_mod = shutil
        shutil_mod.copyfileobj = copiar_y_tomar
        try:
            r = respaldo.restaurar_empresa(e, zipf)
        finally:
            shutil_mod.copyfileobj = original
        assert "cx" in cx_holder and r["copiados"]["base"] == 1
    finally:
        _limpiar(eid, correos)


def test_reemplazar_base_reintenta_y_suelta_el_motor_cada_vez(tmp_path, monkeypatch):
    """Sin Windows: el borrado del -wal niega el archivo dos veces; al tercer intento se reemplaza. Cada intento suelta el motor."""
    import pathlib
    eid = 987654
    destino = EMPRESAS_DIR / f"empresa_{eid}.db"
    tmp_db = EMPRESAS_DIR / f"empresa_{eid}.db.restaurando"
    sqlite3.connect(str(destino)).close()
    sqlite3.connect(str(tmp_db)).close()
    (EMPRESAS_DIR / f"empresa_{eid}.db-wal").write_bytes(b"")
    soltados = []

    class _Motor:
        def dispose(self):
            soltados.append(1)
    negar = {"n": 2}
    real = pathlib.Path.unlink

    def unlink(self, missing_ok=False):
        if self.name == f"empresa_{eid}.db-wal" and negar["n"] > 0:
            negar["n"] -= 1
            _engines[eid] = (_Motor(), None)                                 # otra llamada volvió a crear el motor
            raise PermissionError(32, "El proceso no tiene acceso al archivo porque está siendo utilizado por otro proceso")
        return real(self, missing_ok=missing_ok)
    monkeypatch.setattr(pathlib.Path, "unlink", unlink)
    try:
        _engines[eid] = (_Motor(), None)
        n = respaldo.reemplazar_base(eid, tmp_db, destino, intentos=5, espera=0.01)
        assert n == 3 and len(soltados) == 3 and eid not in _engines
        assert destino.exists() and not tmp_db.exists() and not (EMPRESAS_DIR / f"empresa_{eid}.db-wal").exists()
    finally:
        monkeypatch.setattr(pathlib.Path, "unlink", real)
        _engines.pop(eid, None)
        for f in (destino, tmp_db, EMPRESAS_DIR / f"empresa_{eid}.db-wal"):
            f.unlink(missing_ok=True)


def test_reemplazar_base_se_rinde_sin_tocar_la_base_en_uso(tmp_path, monkeypatch):
    """Si nunca se suelta: sale el error de siempre y la base en uso y su -wal siguen ahí (la restaurada no la reemplaza)."""
    import pathlib
    eid = 987655
    destino = EMPRESAS_DIR / f"empresa_{eid}.db"
    tmp_db = EMPRESAS_DIR / f"empresa_{eid}.db.restaurando"
    sqlite3.connect(str(destino)).close()
    tmp_db.write_bytes(b"nueva")
    wal = EMPRESAS_DIR / f"empresa_{eid}.db-wal"
    wal.write_bytes(b"wal")
    real = pathlib.Path.unlink

    def unlink(self, missing_ok=False):
        if self.name == wal.name:
            raise PermissionError(32, "en uso")
        return real(self, missing_ok=missing_ok)
    monkeypatch.setattr(pathlib.Path, "unlink", unlink)
    try:
        with pytest.raises(PermissionError):
            respaldo.reemplazar_base(eid, tmp_db, destino, intentos=3, espera=0.01)
        assert wal.exists() and destino.read_bytes() != b"nueva"
    finally:
        monkeypatch.setattr(pathlib.Path, "unlink", real)
        for f in (destino, tmp_db, wal):
            f.unlink(missing_ok=True)
