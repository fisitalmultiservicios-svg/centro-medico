# -*- coding: utf-8 -*-
"""4.32 · arreglos de la validación, bloque «dinero, pedidos y base» (f2). Copias de las pruebas de reproducción de
proyecto432_val/tests (test_val_*.py) con su mismo contenido, más lo mínimo propio (marcado «f2»):
  (A) marcha atrás: test_val_pedidos_dinero_r1, test_val_dia_del_cliente_r4 (con la señal real de la web apagada) y el contraste de
      test_val_marcha_atras_y_pruebas_3; f2: sin dato, el cobro del pedido se retiene.
  (B) pedido pagado que atiende la web: test_val_dia_del_cliente_r2.
  (C) promociones con respuesta perdida: test_val_primera_subida_r1 y test_val_primera_subida_3::test_d1 (arnés de test_val_primera_subida_1).
  (D) pedido_parcial con valor por omisión en la base: test_val_marcha_atras_y_pruebas_r1.
  (E) aceptar a mano un pedido viejo: f2, con la edad que calcula la web (edad_en_la_web) y el control de test_val_dia_del_cliente_4.
Solo correos @example.test; nada sale a la red."""
import contextlib
import json
import pathlib
import random
import re
import secrets as _secrets
import types
import uuid
from datetime import timedelta

import httpx
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import MetaData, Table, create_engine, text
from sqlmodel import Session, select

from app import auth, comandas, db, fisitaap, inventario, modulos, pagos_online, pedidos, pedidos_programa, secretos, sinc
from app import sinc_datos as _sdw
from app import sinc_datos_decl  # noqa: F401
from app import sinc_datos_programa as sdp
from app import sinc_completar as sc
from app.db import Cliente, Documento, DocumentoLinea, Producto, engine, engine_empresa, init_db
from tests.test_exoneraciones import api  # noqa: F401  (fixture)
from tests.test_429_pedido_web_comanda import _montar_negocio, _pedido
from tests.test_432_pedidos import (_ctx, _cuentas, _cuentas_de, _doc as _doc_ped, _estado, _fila_pedido, _llega,  # noqa: F401
                                    _negocio_con_programa, _p, _set, _sin_limite_por_ip, prog, sd)
from tests.test_432_programa import _Respuesta, _Web, _empresa as _empresa_prog
from tests.test_432_mecanismo import _empresa as _empresa_mec

# ==================================================================================================== arnés de test_val_primera_subida_1.py (para C)
init_db()
_app = FastAPI()
_app.include_router(_sdw.router)
cli = TestClient(_app)
NUBE = "http://nube-val-ps"
T = 3
R = modulos.RANGO
VINCULADA = "2026-11-05T12:00:00+00:00"


@pytest.fixture
def _encendido(monkeypatch):
    monkeypatch.setenv("FE_SINC_DATOS", "1")
    yield


class Puente:
    """httpx.post del programa -> la ruta de verdad de la web (TestClient), cambiando MODO_LOCAL mientras atiende la web."""
    def __init__(self):
        self.llamadas = []
        self.cortar = None            # fn(ruta, cuerpo) -> Exception | None
        self.despues = None           # fn(ruta, cuerpo, respuesta) -> respuesta

    def post(self, url, headers=None, json=None, timeout=None):  # noqa: A002
        assert url.startswith(NUBE), url
        ruta = url[len(NUBE):]
        self.llamadas.append((ruta, json))
        if self.cortar is not None:
            ex = self.cortar(ruta, json)
            if ex is not None:
                raise ex
        previo = sinc.MODO_LOCAL
        sinc.MODO_LOCAL = False
        try:
            r = cli.post(ruta, json=json, headers=headers)
        finally:
            sinc.MODO_LOCAL = previo
        if self.despues is not None:
            r = self.despues(ruta, json, r)
        return r


def _empresa_mundo(nombre: str):
    with Session(engine) as s0:
        e = auth.crear_empresa(s0, nombre, f"val-{random.randint(1, 10**9)}@example.test", "31017" + str(random.randint(10**4, 10**5 - 1)))
        return e.id, e.clave_cifrada


def _token_web(eid: int, terminal: int = T) -> str:
    token = "fcr_" + _secrets.token_urlsafe(32)
    with Session(engine) as s0:
        t = auth.TokenApi(empresa_id=eid, usuario_id=auth.TOKEN_EMPRESA, nombre="Instalación local · Caja QA", prefijo=token[:12],
                          hash=auth._hash_token_api(token), permisos=json.dumps([p for p in auth.PERMISOS_API if p != "ver_todo"]))
        s0.add(t); s0.commit(); s0.refresh(t)
        tid, pref = t.id, t.prefijo
    with Session(engine_empresa(eid)) as s:
        v = sinc._leer(s, eid, sinc.CLAVE_VINC, {})
        v.setdefault("instalaciones", []).append({"terminal": terminal, "nombre": "Caja QA", "token_id": tid, "prefijo": pref, "creado": "2026-11-05T12:00:00+00:00"})
        sinc._escribir(s, eid, sinc.CLAVE_VINC, v); s.commit()
    return token


def _clave() -> str:
    return "506" + "".join(random.choice("0123456789") for _ in range(47))


def _prod(s, eid, iid, nombre, **k):
    p = Producto(id=iid, empresa_id=eid, nombre=nombre, cabys="1234567890123", precio=1000, **k)
    s.add(p); s.commit()
    return iid


def _cliente(s, eid, iid, nombre, **k):
    c = Cliente(id=iid, empresa_id=eid, nombre=nombre, tipo_id=k.pop("tipo_id", ""), numero_id=k.pop("numero_id", ""), **k)
    s.add(c); s.commit()
    return iid


def _doc_mundo(s, eid, lineas, *, fecha, cliente_id=None, receptor=None, sinc_en=None, mover=False):
    d = Documento(empresa_id=eid, tipo_documento="04", clave=_clave(), consecutivo="0010000104" + str(random.randint(10**9, 10**10 - 1)), fecha_emision=fecha,
                  estado="interno", cliente_id=cliente_id, receptor_nombre=receptor, sinc_en=sinc_en, sinc_estado="interno" if sinc_en else None)
    s.add(d); s.flush()
    for i, (pid, det, cant) in enumerate(lineas, 1):
        s.add(DocumentoLinea(documento_id=d.id, numero=i, producto_id=pid, cabys="1234567890123", detalle=det, cantidad=cant, unidad_medida="Unid", precio_unitario=1000))
    s.flush()
    if mover:
        inventario.descontar_por_venta(s, eid, d.id, d.consecutivo, None, [{"producto_id": pid, "cantidad": cant} for pid, _, cant in lineas if pid], fecha[:10], permitir_negativo=True)
    s.commit(); s.refresh(d)
    return d


def _copiar_fila(sw, sp, modelo, iid, eid_p):
    """Como dejó el _bajar 4.31: la fila de la web copiada en el programa con su mismo id."""
    o = sw.get(modelo, iid)
    datos = {k: v for k, v in o.model_dump().items() if k not in ("empresa_id",)}
    sp.add(modelo(**datos, empresa_id=eid_p)); sp.commit()


class Mundo:
    """La web W y el programa P del cliente real, ya conectado con la 4.31 (terminal 3)."""
    def __init__(self, monkeypatch):
        self.W, _ = _empresa_mundo("VAL web")
        self.P, clave_p = _empresa_mundo("VAL programa")
        self.token = _token_web(self.W)
        self.puente = Puente()
        monkeypatch.setattr(httpx, "post", self.puente.post)
        with Session(engine_empresa(self.P)) as s:
            sinc._escribir(s, self.P, sinc.CLAVE_LOCAL, {"vinculado": True, "url": NUBE, "token": secretos.cifrar(clave_p, self.token), "terminal": T,
                                                         "vinculada_en": VINCULADA, "nombre": "Caja QA"})
            s.commit()
        sdp.olvidar(self.P)

    # ---- el programa ----
    @contextlib.contextmanager
    def local(self):
        previo = sinc.MODO_LOCAL
        sinc.MODO_LOCAL = True
        try:
            yield
        finally:
            sinc.MODO_LOCAL = previo

    def pasar_a_2(self):
        modulos.fijar_rango(self.P, T)
        with self.local():
            sdp.pasar_a_protocolo_2(self.P)

    def ciclo(self, n=1):
        out = []
        with self.local():
            for _ in range(n):
                sdp._filas_despues.pop(self.P, None)
                out.append(sdp._ciclo(self.P))
        return out

    def estado(self):
        sdp._cache.pop(self.P, None)
        with self.local():
            return sdp.estado(self.P)

    def cola(self):
        with Session(engine_empresa(self.P)) as s:
            return [tuple(r) for r in s.connection().execute(text("SELECT tipo, ref, op, estado FROM sinc_cambio ORDER BY id")).all()]

    def choques(self):
        with Session(engine_empresa(self.P)) as s:
            return [(x["clase"], x["tipo"], x["ref"], x["nombre"], x["detalle"]) for x in sc.lista_choques(s, self.P)]

    def pisados(self):
        with Session(engine_empresa(self.P)) as s:
            return [tuple(r) for r in s.connection().execute(text("SELECT tipo, ref, nombre, campo, motivo, perdio FROM sinc_pisado ORDER BY id")).all()]

    # ---- el ciclo viejo (app/sinc.py), a mano ----
    def subir_documentos(self):
        """Como sinc._subir_documentos: lo pendiente menos lo retenido; la web lo guarda con sinc._guardar_documentos."""
        with self.local(), Session(engine_empresa(self.P)) as s:
            pend = s.exec(select(Documento).where((Documento.sinc_en == None) | (Documento.sinc_estado != Documento.estado))).all()  # noqa: E711
            espera = sdp.documentos_en_espera(s, self.P, pend)
            van = [d for d in pend if d.id not in espera]
            paquetes = [(d.id, sinc._doc_a_dict(s, d)) for d in van]
        subidos = []
        for did, dd in paquetes:
            with Session(engine_empresa(self.W)) as sw:
                rec, err = sinc._guardar_documentos(sw, self.W, [json.loads(json.dumps(dd, default=str))], "Caja QA", terminal_ficha=T)
                assert not err, err
            with Session(engine_empresa(self.P)) as s:
                d = s.get(Documento, did)
                d.sinc_en = sinc._ahora(); d.sinc_estado = d.estado; s.add(d); s.commit()
            subidos.append(did)
        return subidos, sorted(espera)

    def bajar_existencias(self):
        with Session(engine_empresa(self.W)) as sw:
            bodegas = sw.exec(select(inventario.Bodega).where(inventario.Bodega.empresa_id == self.W)).all()
            bids = {b.id for b in bodegas}
            j = {"bodegas": [{**b.model_dump(), "empresa_id": self.P} for b in bodegas],
                 "existencias": [{"producto_id": x.producto_id, "bodega_id": x.bodega_id, "cantidad": x.cantidad, "costo_promedio": x.costo_promedio}
                                 for x in sw.exec(select(inventario.Existencia)).all() if x.bodega_id in bids],
                 "productos": [{"id": p.id} for p in sw.exec(select(Producto)).all()]}
        with self.local(), Session(engine_empresa(self.P)) as s:
            return sinc._bajar_existencias(s, self.P, j, T)

    def existencia(self, eid, pid):
        with Session(engine_empresa(eid)) as s:
            return {int(x.bodega_id): float(x.cantidad) for x in s.exec(select(inventario.Existencia).where(inventario.Existencia.producto_id == pid)).all()}

    def cerrar(self):
        modulos._rangos.pop(self.P, None)
        sdp.olvidar(self.P)


def armar(m: Mundo):
    """El cliente: la web tiene sus ítems 1,2,3 y 5 (creó y eliminó hasta el 10); el programa tiene esas copias y lo suyo de antes de conectar."""
    W, P = m.W, m.P
    with Session(engine_empresa(W)) as sw:
        inventario.bodega_principal(sw, W)
        for i, n in ((1, "Café"), (2, "Té"), (3, "Pastel"), (5, "Jugo")):
            _prod(sw, W, i, n, inventariable=True)
        sw.execute(text("CREATE TABLE IF NOT EXISTS sinc_id_propio (tabla TEXT NOT NULL, rango INTEGER NOT NULL, ultimo INTEGER NOT NULL, PRIMARY KEY (tabla, rango))"))
        sw.execute(text("INSERT OR REPLACE INTO sinc_id_propio (tabla, rango, ultimo) VALUES ('producto', 0, 10)"))
        _cliente(sw, W, 1, "Ana Web"); _cliente(sw, W, 2, "Luis Web")
        sw.execute(text("INSERT OR REPLACE INTO sinc_id_propio (tabla, rango, ultimo) VALUES ('cliente', 0, 2)"))
        sw.commit()
        modulos.aplicar_cambios(sw, W, "fis_promociones", [{"id": 1, "producto_id": 1, "tipo": "bogo", "valor": 0, "activa": True, "creada": "2026-10-01T10:00:00"}], [], [1])
    with Session(engine_empresa(P)) as sp, Session(engine_empresa(W)) as sw:
        bp = inventario.bodega_principal(sp, P)
        for i in (1, 2, 3, 5):
            _copiar_fila(sw, sp, Producto, i, P)
        for i in (1, 2):
            _copiar_fila(sw, sp, Cliente, i, P)
        _prod(sp, P, 4, "Casado", inventariable=True)                # de antes de conectar, vendido antes: prueba (1)
        _prod(sp, P, 6, "Olla de carne", inventariable=True)         # de antes de conectar, nunca vendido antes, id <= max_dado
        _prod(sp, P, 11, "Pinto", inventariable=True)                # id > max_dado: prueba (2)
        _prod(sp, P, 12, "Refresco natural", inventariable=True)     # se llamaba «Fresco» cuando se vendió
        _cliente(sp, P, 3, "Don Carlos")                             # sin cédula, de antes de conectar
        _cliente(sp, P, 4, "Doña Marta", tipo_id="01", numero_id="101110111")
        for pid, q in ((4, 20), (6, 10), (11, 8), (12, 30)):
            inventario.registrar_movimiento(sp, producto=sp.get(Producto, pid), bodega_id=bp.id, tipo="inicial", cantidad=q, fecha="2026-10-01", costo_unitario=500)
        sp.commit()
        modulos.aplicar_cambios(sp, P, "fis_promociones", [{"id": 1, "producto_id": 4, "tipo": "bogo", "valor": 0, "activa": True, "creada": "2026-10-02T09:00:00"},
                                                           {"id": 2, "producto_id": 11, "tipo": "special", "valor": 900, "activa": True, "creada": "2026-10-03T09:00:00"}], [], [1, 2])
    # ventas viejas (ya subieron con la 4.31: en la web quedaron sin ítem y sin cliente)
    with Session(engine_empresa(P)) as sp:
        d1 = _doc_mundo(sp, P, [(4, "Casado", 2), (12, "Fresco", 1), (1, "Café", 1)], fecha="2026-11-01T10:00:00-06:00", cliente_id=3, receptor="Don Carlos", mover=True)
        d2 = _doc_mundo(sp, P, [(11, "Pinto (con huevo)", 1), (4, "Casado (sin arroz (alergia))", 1)], fecha="2026-11-08T10:00:00-06:00", cliente_id=4, receptor="Doña Marta", mover=True)
        viejos = [(d.id, sinc._doc_a_dict(sp, d)) for d in (d1, d2)]
        claves = [d1.clave, d2.clave]
    for did, dd in viejos:
        with Session(engine_empresa(W)) as sw:
            rec, err = sinc._guardar_documentos(sw, W, [json.loads(json.dumps(dd, default=str))], "Caja QA", terminal_ficha=T)
            assert not err, err
        with Session(engine_empresa(P)) as sp:
            d = sp.get(Documento, did); d.sinc_en = "2026-11-09T00:00:00+00:00"; d.sinc_estado = d.estado; sp.add(d); sp.commit()
    return claves


def lineas_web(m, clave):
    with Session(engine_empresa(m.W)) as sw:
        doc = sw.exec(select(Documento).where(Documento.clave == clave)).first()
        if doc is None:
            return None
        return doc.cliente_id, [(ln.numero, ln.producto_id, ln.detalle) for ln in sw.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == doc.id).order_by(DocumentoLinea.numero)).all()]



# ==================================================================================================== (A) marcha atrás con comprobantes retenidos
def _el_programa_sube_el_cobro_en_pausa(monkeypatch, codigo, datos_v2) -> bool:
    """LADO PROGRAMA (una computadora con el protocolo 2 y su web simulada). El canal entra en pausa como en la vida real (`codigo` en /datos y
    la señal `datos_v2` del catálogo), la caja cobra la cuenta del pedido 981 y corre la subida de comprobantes de siempre.
    Devuelve True si ese comprobante salió hacia la web."""
    with monkeypatch.context() as m:
        w = _Web()
        m.setattr(sinc, "MODO_LOCAL", True)
        m.setattr(sdp, "httpx", w)
        eid = _empresa_prog()
        try:
            assert _llega(eid, _fila_pedido(eid, 981))                    # el pedido aceptado: su cuenta ya está en la caja del programa
            d = _doc_ped(eid, 981)                                            # la caja la cobra: comprobante de aquí con su pedido
            with Session(engine_empresa(eid)) as s:
                x = s.get(Documento, d.id); x.origen_sinc = None; x.sinc_en = None; s.add(x); s.commit()
            w.forzar = _Respuesta(codigo, {"detail": "Not Found"} if codigo == 404 else None)
            sdp._ciclo(eid)                                               # /api/sinc/datos contesta 404 (interruptor) o 405 (web 4.31)
            sdp.senal_catalogo(eid, datos_v2)                             # /api/sinc/catalogo: datos_v2 false (4.32 apagada) o sin la llave (4.31)
            assert sdp.en_pausa(eid)
            enviados = []
            m.setattr(sinc, "_post", lambda url, cab, ruta, cuerpo, **k: enviados.extend(x["clave"] for x in cuerpo.get("documentos") or []) or {"recibidos": []})
            with Session(engine_empresa(eid)) as s:
                cfg = sinc._cfg_local(s, eid)
                sinc._subir_documentos(s, eid, cfg, cfg["url"], {})
            return d.clave in enviados
        finally:
            modulos._rangos.pop(eid, None); sdp.olvidar(eid); sdp._reintentar.pop(eid, None)


def _pedido_pagado_que_atiende_el_programa(api, monkeypatch):  # noqa: F811
    """LADO WEB: un pedido pagado con tarjeta que atiende la computadora 3, y Tilopay reemplazado (anota los reembolsos que se piden)."""
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3, pago_estado="aprobado", pago_medio="tarjeta", pago_orden="GF-QA-R1", pago_monto=p["total"])
    reembolsos = []
    monkeypatch.setattr(pagos_online, "credenciales", lambda e, n: {"qa": True})
    monkeypatch.setattr(pagos_online, "reembolsar", lambda *a, **k: reembolsos.append(a) or (True, "Reembolsado"))
    monkeypatch.setattr(pedidos, "avisar_cliente_id", lambda *a, **k: None)
    monkeypatch.setenv("FE_SINC_DATOS", "0")                              # la marcha atrás: el interruptor apagado en la web 4.32
    return eid, p, reembolsos


def _llega_a_la_web(eid, pid):
    """El comprobante del programa entra por /api/sinc/documentos (la misma función), con el pedido que cobró."""
    clave = "".join(str((i * 3 + 1) % 10) for i in range(50))
    doc = {"clave": clave, "tipo_documento": "04", "consecutivo": "00100001040000000981", "fecha_emision": pedidos.ahora_cr().isoformat(timespec="seconds"),
           "estado": "interno", "total": 4520, "moneda": "CRC", "pedido": {"id": pid, "parcial": False}, "lineas": []}
    with Session(engine_empresa(eid)) as s:
        recibidos, errores = sinc._guardar_documentos(s, eid, [doc], "Caja del local QA", terminal_ficha=3)
    assert recibidos == [clave] and not errores


def test_r1_marcha_atras_el_cobro_del_programa_llega_a_la_web_y_no_se_reembolsa_lo_ya_cobrado(api, monkeypatch):  # noqa: F811
    subio = _el_programa_sube_el_cobro_en_pausa(monkeypatch, 404, False)  # web 4.32 con FE_SINC_DATOS=0
    eid, p, reembolsos = _pedido_pagado_que_atiende_el_programa(api, monkeypatch)
    if subio:
        _llega_a_la_web(eid, p["id"])
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "cancelado", "motivo": "Se ve pegado en la web"})
    x = _p(eid, p["id"])
    assert subio and r.status_code in (400, 409) and not reembolsos and x.estado != "cancelado", (
        f"El programa cobró el pedido en pausa y su comprobante {'subió' if subio else 'NO subió'}; la web contestó {r.status_code} al cancelar, "
        f"el pedido quedó «{x.estado}» con pago «{x.pago_estado}» y pidió {len(reembolsos)} reembolso(s) a Tilopay")


def test_r1_control_con_la_web_431_el_cobro_del_pedido_si_espera(monkeypatch):
    """Arreglo n.º 10, que debe quedar: contra una web 4.31 (405 y catálogo sin la llave datos_v2) el cobro de un pedido espera."""
    assert _el_programa_sube_el_cobro_en_pausa(monkeypatch, 405, None) is False


def test_r1_control_si_el_comprobante_llega_la_web_apagada_no_cancela_ni_rescata(api, monkeypatch):  # noqa: F811
    eid, p, reembolsos = _pedido_pagado_que_atiende_el_programa(api, monkeypatch)
    _llega_a_la_web(eid, p["id"])
    r = api.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "cancelado", "motivo": "Se ve pegado en la web"})
    assert r.status_code in (400, 409), r.text
    assert api.post(f"/api/pedidos/{p['id']}/atender-aqui", json={"confirmo": True}).status_code in (400, 409)
    assert not reembolsos and _p(eid, p["id"]).estado == "entregado"


def test_r4_con_el_canal_apagado_la_web_no_devuelve_el_pago_de_un_pedido_que_el_programa_ya_cobro(prog, api, monkeypatch):  # noqa: F811
    # ---------- A. el programa, en pausa, cobra el pedido que ya tenía en su caja
    eid_p, _w = prog
    _llega(eid_p, _fila_pedido(eid_p, 981, pago_estado="aprobado", pago_medio="tarjeta", pago_monto=5650))
    assert len(_cuentas_de(eid_p, 981)) == 1                              # la cuenta estaba en la caja del programa (comanda ya impresa)
    sdp._guardar_estado(eid_p, pausa_desde=sdp._ahora())                  # la web puso FE_SINC_DATOS=0: /datos contesta 404 y el programa queda en pausa
    sdp.senal_catalogo(eid_p, False)                                      # f2: lo que dice esa web 4.32 apagada (datos_v2 = false); sin dato se retiene
    try:
        cobro = _doc_ped(eid_p, pid=981)                                     # 15:10, el cajero entrega y cobra el pedido en el programa
        with Session(engine_empresa(eid_p)) as s:
            retenido = cobro.id in sdp.documentos_en_espera(s, eid_p, [s.get(Documento, cobro.id)])
            viaja = sinc._doc_a_dict(s, s.get(Documento, cobro.id), con_xml=False)   # lo que subiría si no se retuviera
    finally:
        sdp._guardar_estado(eid_p, pausa_desde=None)
    assert viaja["pedido"] == {"id": 981, "parcial": False}

    # ---------- B. la página web 4.32 con el interruptor apagado
    monkeypatch.setattr(sinc, "MODO_LOCAL", False)
    monkeypatch.setenv("FE_SINC_DATOS", "0")
    monkeypatch.setattr(pedidos, "avisar_cliente_id", lambda *a, **k: None)
    monkeypatch.setattr(pedidos, "avisar_cliente", lambda *a, **k: None)
    reembolsos = []
    monkeypatch.setattr(pagos_online, "credenciales", lambda e, n: {"key": "k", "user": "u", "password": "x"})
    monkeypatch.setattr(pagos_online, "reembolsar", lambda *a, **k: reembolsos.append(a[1:]) or (True, "Reembolsado"))
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    # contraste: un pedido cuyo cobro SÍ subió con el canal apagado: queda enlazado y la web ya no lo deja cancelar
    p0 = _pedido(api, slug, a, b, tel="88881111")
    _set(eid, p0["id"], estado="confirmado", atiende=3, pago_estado="aprobado", pago_medio="tarjeta", pago_orden="GF-R4-0", pago_monto=p0["total"])
    doc0 = {**viaja, "pedido": {"id": p0["id"], "parcial": False}, "lineas": []}
    with Session(engine_empresa(eid)) as s:
        recibidos, errores = sinc._guardar_documentos(s, eid, [doc0], "Caja del local QA")
    assert recibidos == [doc0["clave"]] and not errores
    assert _p(eid, p0["id"]).estado == "entregado"                        # enlazado y entregado aunque FE_SINC_DATOS=0
    assert api.put(f"/api/pedidos/{p0['id']}/estado", json={"estado": "cancelado", "motivo": "Lo veo pegado en la lista"}).status_code == 400
    assert reembolsos == []
    # lo que pasa hoy: el cobro del programa está retenido; en la web el pedido sigue «Confirmado · Lo atiende Caja del local QA»
    p1 = _pedido(api, slug, a, b, tel="88882222")
    _set(eid, p1["id"], estado="confirmado", atiende=3, pago_estado="aprobado", pago_medio="tarjeta", pago_orden="GF-R4-1", pago_monto=p1["total"])
    r = api.put(f"/api/pedidos/{p1['id']}/estado", json={"estado": "cancelado", "motivo": "Lo veo pegado en la lista"})
    salio = r.json() if r.status_code == 200 else {}
    assert not (retenido and r.status_code == 200 and reembolsos), (
        "En pausa el programa RETIENE el cobro del pedido (retenido = %s), así que la web no puede saber que ya se entregó y se cobró; y con "
        "FE_SINC_DATOS=0 «Cancelar con justificación» contestó %s, dejó el pedido «%s» con el pago «%s» y pidió %s reembolso(s) a Tilopay."
        % (retenido, r.status_code, salio.get("estado"), salio.get("pago_estado"), len(reembolsos)))


def test_f2_sin_dato_de_la_web_el_cobro_del_pedido_se_retiene(prog):  # noqa: F811
    """f2: recién abierto el programa en pausa, sin saber todavía si la web es 4.31 o 4.32, el cobro de un pedido espera (lo seguro);
    con la señal de una web 4.31 también; con la de una 4.32 apagada, sube."""
    eid_p, _w = prog
    _llega(eid_p, _fila_pedido(eid_p, 982, pago_estado="aprobado", pago_medio="tarjeta", pago_monto=5650))
    sdp._guardar_estado(eid_p, pausa_desde=sdp._ahora())
    try:
        cobro = _doc_ped(eid_p, pid=982)
        with Session(engine_empresa(eid_p)) as s:
            assert cobro.id in sdp.documentos_en_espera(s, eid_p, [s.get(Documento, cobro.id)])
        sdp.senal_catalogo(eid_p, None)                                   # catálogo sin la llave datos_v2: web 4.31
        with Session(engine_empresa(eid_p)) as s:
            assert cobro.id in sdp.documentos_en_espera(s, eid_p, [s.get(Documento, cobro.id)])
        sdp.senal_catalogo(eid_p, False)                                  # web 4.32 apagada: ya sube
        with Session(engine_empresa(eid_p)) as s:
            assert cobro.id not in sdp.documentos_en_espera(s, eid_p, [s.get(Documento, cobro.id)])
    finally:
        sdp._guardar_estado(eid_p, pausa_desde=None)


LINEAS = [{"cabys": "8399000009900", "detalle": "Casado", "cantidad": 1, "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]


def _doc_del_programa(p):
    clave = "".join(str((i * 3 + p["id"]) % 10) for i in range(50))
    return clave, {"clave": clave, "tipo_documento": "04", "consecutivo": "0010000104000000%04d" % (700 + p["id"]), "fecha_emision": pedidos.ahora_cr().isoformat(timespec="seconds"),
                   "estado": "interno", "total": 4520, "moneda": "CRC", "pedido": {"id": p["id"], "parcial": False}, "lineas": []}


def test_val_con_el_interruptor_apagado_la_web_432_si_enlaza_el_cobro_del_programa(api, sd, monkeypatch):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    _negocio_con_programa(eid)
    p = _pedido(api, slug, a, b)
    _set(eid, p["id"], estado="confirmado", atiende=3)
    monkeypatch.setattr(pedidos, "avisar_cliente_id", lambda e, pid, ev: None)
    monkeypatch.setenv("FE_SINC_DATOS", "0")                        # soporte apaga el canal; la web sigue en la 4.32
    clave, doc = _doc_del_programa(p)
    with Session(engine_empresa(eid)) as s:
        recibidos, errores = sinc._guardar_documentos(s, eid, [doc], "Caja del local QA", terminal_ficha=3)
    assert recibidos == [clave] and not errores
    x = _p(eid, p["id"])
    assert x.estado == "entregado" and x.documento_id                # la web 4.32 lo entrega y lo enlaza aunque el interruptor esté apagado
    r = api.post(f"/api/pedidos/{p['id']}/atender-aqui", json={"confirmo": True})
    assert r.status_code == 400                                      # y ya no se puede rescatar ni cobrar otra vez


# ==================================================================================================== (B) pedido pagado que atiende la web
JS = pathlib.Path(__file__).resolve().parent.parent / "app" / "static" / "js"
CONOCIDAS = ("nuevos", "ultimo_id", "hace", "ultimo_entrado_id", "comandas_pendientes", "comanda_espera_s")


def test_r2_un_pedido_pagado_que_atiende_la_web_deja_alguna_senal_en_el_programa(prog):  # noqa: F811
    eid, _w = prog
    fila = _fila_pedido(eid, 995, estado="confirmado", atiende=0, pago_estado="aprobado", pago_medio="tarjeta", pago_monto=5650)
    fila["datos"]["edad_s"] = 20 * 60                                     # se pagó hace 20 minutos (la hora sin internet)
    assert _llega(eid, fila) is True                                      # la copia llega bien al programa
    senales = []
    if _cuentas_de(eid, 995):
        senales.append("cuenta en la caja del programa")
    with Session(engine_empresa(eid)) as s:
        if comandas._copia(s, eid, 995) is not None:
            senales.append("comanda para la estación del programa")
        r = pedidos.resumen(_ctx(eid), s)                                 # lo que piden la Caja (cada 10 s), la franja y los avisos
        if r["nuevos"] or r["ultimo_id"] or r["ultimo_entrado_id"] or r["comandas_pendientes"]:
            senales.append("sonido o aviso de la caja (resumen)")
        otras = {k: v for k, v in r.items() if k not in CONOCIDAS and v}   # una llave nueva del resumen que avise de este pedido
        if otras:
            senales.append("llave nueva en el resumen: %s" % sorted(otras))
        p = s.get(pedidos.Pedido, 995)
        en_lista = pedidos._con_atiende(s, eid, pedidos._salida_pedido(p, pedidos.estado_efectivo(s, eid, [p])[p.id]), p)
    # la fila de Ventas en línea › Pedidos en el programa: ¿dice en algún lado que lo atiende la página web?
    ped = (JS / "fis" / "pages" / "pedidos.js").read_text(encoding="utf-8")
    if re.search(r"enProg[^\n]{0,300}atiende[^\n]{0,300}p[aá]gina web", ped) or re.search(r"atiende_web|atiendeWeb|lo atiende la p[aá]gina web", ped, re.I):
        senales.append("texto en la fila de Pedidos del programa")
    assert senales, ("El pedido #995 ya está pagado con tarjeta y lo atiende la página web, pero en el programa no hay NINGUNA señal: "
                     "cuentas = %s, resumen = %s, fila de Pedidos = estado «%s», atiende %s «%s» (la pantalla le pone «Abrir monitor», "
                     "y el monitor del programa no tiene nada de ese pedido)"
                     % (_cuentas_de(eid, 995), {k: r.get(k) for k in CONOCIDAS}, en_lista["estado"], en_lista["atiende"], en_lista["atiende_nombre"]))


# ==================================================================================================== (C) promociones con respuesta perdida
def _hasta_el_final(m, vueltas=10):
    for _ in range(vueltas):
        m.ciclo()
        _, retenidos = m.subir_documentos()
        m.bajar_existencias()
        if m.estado().get("carga") == "hecha" and not retenidos and all(c[3] not in ("abierta", "enviada") for c in m.cola()):
            return True
    return False


def _promos(eid):
    with Session(engine_empresa(eid)) as s:
        return sorted((int(x["id"]), int(x["producto_id"]), x["tipo"]) for x in modulos.leer(s, eid, "fis_promociones", []))


AHORA = "2026-11-14T12:00"


def _vigentes(m):
    """Las promociones vigentes en la caja del programa ({producto_id: promoción}): la misma función que usan la caja y el catálogo."""
    with m.local(), Session(engine_empresa(m.P)) as sp:
        return fisitaap.promociones_vigentes(sp, m.P, AHORA)


def _apagar_en_la_web_y_bajar(m, producto_id):
    """El dueño desactiva en la página web la promoción de ese ítem; el programa hace sus vueltas."""
    with Session(engine_empresa(m.W)) as sw:
        x = next(p for p in modulos.leer(sw, m.W, "fis_promociones", []) if int(p["producto_id"]) == producto_id and p.get("activa", True))
        x["activa"] = False
        modulos.aplicar_cambios(sw, m.W, "fis_promociones", [x], [], [])
        sw.commit()
    for _ in range(4):
        m.ciclo()
    return _vigentes(m)


def test_r1_control_sin_respuesta_perdida(monkeypatch, _encendido):
    m = Mundo(monkeypatch)
    try:
        armar(m)
        m.pasar_a_2()
        assert _hasta_el_final(m)
        assert _promos(m.P) == _promos(m.W)
        assert 11 in _vigentes(m)
        vig = _apagar_en_la_web_y_bajar(m, 11)
        assert 11 not in vig, vig                                         # apagada en la web, deja de aplicarse en la caja del programa
    finally:
        m.cerrar()


def test_r1_respuesta_perdida_la_promocion_queda_dos_veces_y_sigue_activa_en_la_caja(monkeypatch, _encendido):
    m = Mundo(monkeypatch)
    try:
        armar(m)
        m.pasar_a_2()
        veces = {"n": 0}

        def despues(ruta, cuerpo, r):
            if ruta == "/api/sinc/datos" and cuerpo.get("ops"):
                veces["n"] += 1
                if veces["n"] == 1:
                    raise httpx.ReadTimeout("perdida")                    # la web SÍ aplicó las altas; el programa no vio la respuesta
            return r
        m.puente.despues = despues
        assert _hasta_el_final(m)
        web, prog = _promos(m.W), _promos(m.P)
        vig = _apagar_en_la_web_y_bajar(m, 11)                           # el dueño apaga en la web la promoción de «Pinto» (ítem 11)
        assert prog == web and 11 not in vig, (
            f"programa {prog} / web {web}; apagada en la web, en la caja del programa sigue vigente: {vig.get(11)}")
    finally:
        m.cerrar()


def test_d1_respuesta_perdida_no_duplica_las_promociones_del_cliente(monkeypatch, _encendido):
    """La llamada que lleva las altas de la primera subida llega a la web pero su respuesta se pierde (tiempo agotado). El programa las reenvía,
    la web contesta «repetido» con lo que guardó (la promoción quedó con OTRO número: «renumerar»). El programa debe quedar con UNA copia de
    cada promoción, con el número de la web."""
    m = Mundo(monkeypatch)
    try:
        armar(m)
        m.pasar_a_2()
        veces = {"n": 0}

        def despues(ruta, cuerpo, r):
            if ruta == "/api/sinc/datos" and cuerpo.get("ops"):
                veces["n"] += 1
                if veces["n"] == 1:
                    raise httpx.ReadTimeout("perdida")
            return r
        m.puente.despues = despues
        assert _hasta_el_final(m)
        web, prog = _promos(m.W), _promos(m.P)
        assert len(web) == 3, web                                       # la de la web y las dos del cliente
        assert prog == web, f"programa {prog} / web {web}"              # falla: en el programa la promoción del ítem 11 queda dos veces (id 2 y el nuevo)
    finally:
        m.cerrar()


# ==================================================================================================== (D) pedido_parcial con valor por omisión en la base
NUEVAS_432 = ("pedido_id", "pedido_parcial")          # las columnas de «documento» que el código 4.31 no conoce


def _tabla_431() -> Table:
    """La tabla «documento» como la ve el código 4.31: la de hoy sin las columnas nuevas (con sus mismos valores por omisión de Python)."""
    return Table("documento", MetaData(), *[c.copy() for c in Documento.__table__.columns if c.name not in NUEVAS_432])


def _insert_del_codigo_431(eng):
    """Devuelve None si el comprobante se guarda, o la primera línea del error."""
    t = _tabla_431()
    try:
        with eng.begin() as conn:
            conn.execute(t.insert().values(empresa_id=1, tipo_documento="04", clave=(uuid.uuid4().hex * 2)[:50], consecutivo=uuid.uuid4().hex[:20],
                                           fecha_emision="2026-11-13T10:00:00-06:00", estado="interno"))
        return None
    except Exception as ex:  # noqa: BLE001
        return str(ex).splitlines()[0][:160]


def _columna(eng):
    with eng.connect() as conn:
        info = {r[1]: (r[3], r[4]) for r in conn.execute(text("PRAGMA table_info(documento)")).all()}     # nombre -> (notnull, valor por omisión)
    return info["pedido_parcial"]


def test_val_r1_base_nacida_en_la_432_no_acepta_la_venta_del_codigo_431():
    eid = _empresa_mec()                                   # empresa nueva: su tabla «documento» la crea el código 4.32 (create_all)
    eng = engine_empresa(eid)
    notnull, omision = _columna(eng)
    error = _insert_del_codigo_431(eng)
    print("base NUEVA   · pedido_parcial: notnull =", notnull, "| por omisión =", omision, "| INSERT del código 4.31:", error or "ok")
    assert error is None, f"una base creada por la 4.32 no acepta un comprobante del código 4.31: {error}"


def test_val_r1_base_que_ya_existia_si_acepta_la_venta_del_codigo_431(tmp_path):
    eng = create_engine(f"sqlite:///{(tmp_path / 'vieja.db').as_posix()}")
    try:
        _tabla_431().create(eng)                           # la base del restaurante: nació con la 4.31 (o antes), sin las columnas nuevas
        db._agregar_columnas_faltantes(eng, [Documento.__table__])     # lo que hace la 4.32 al abrirla
        notnull, omision = _columna(eng)
        error = _insert_del_codigo_431(eng)
        print("base DE ANTES · pedido_parcial: notnull =", notnull, "| por omisión =", omision, "| INSERT del código 4.31:", error or "ok")
        assert (notnull, str(omision)) == (0, "0") and error is None
    finally:
        eng.dispose()


# ==================================================================================================== (E) aceptar a mano un pedido viejo
def test_f2_aceptar_ahora_un_pedido_de_hace_4_horas_si_saca_la_comanda(prog):  # noqa: F811
    """f2: la web mide la edad desde que se aceptó (Pedido.confirmado): el pedido de hace 4 horas que se acepta AHORA saca su comanda; el que
    se aceptó hace 4 horas y llega tarde sigue la regla de las 3 horas."""
    eid, w = prog
    ahora = pedidos.ahora_cr()
    hace4 = (ahora - timedelta(hours=4)).isoformat(timespec="seconds")
    assert pedidos_programa.edad_en_la_web(None, eid, types.SimpleNamespace(creado=hace4, confirmado=hace4)) >= 4 * 3600 - 5
    en_la_web = types.SimpleNamespace(creado=hace4, confirmado=ahora.isoformat(timespec="seconds"))
    _llega(eid, _fila_pedido(eid, 991, estado="nuevo", atiende=0))
    aceptado = _fila_pedido(eid, 991)
    aceptado["datos"]["edad_s"] = pedidos_programa.edad_en_la_web(None, eid, en_la_web)   # lo que manda la web al aceptarlo ahora
    assert aceptado["datos"]["edad_s"] < 60
    w.accion = lambda c: _Respuesta(200, {"resultado": {"id": 991, "estado": "confirmado"}, "filas": [aceptado]})
    out = _estado(eid, 991, "confirmado", reclama=True)
    assert out["mensaje"] == "Pedido #991 aceptado: ya está en la caja y su comanda sale sola en unos segundos."
    assert len(_cuentas_de(eid, 991)) == 1
    with Session(engine_empresa(eid)) as s:
        copia = comandas._copia(s, eid, 991)
        assert copia is not None and copia["estado"] == "pendiente" and not comandas._vieja(copia, pedidos.ahora_cr())
        assert [c["pedido_id"] for c in comandas.pendientes(s, eid)["copias"]] == [991]


def test_val_el_mismo_pedido_aceptado_a_tiempo_si_sale(prog):  # noqa: F811
    eid, w = prog
    _llega(eid, _fila_pedido(eid, 992, estado="nuevo", atiende=0))
    aceptado = _fila_pedido(eid, 992)
    aceptado["datos"]["edad_s"] = 10 * 60                                 # hecho hace 10 minutos
    w.accion = lambda c: _Respuesta(200, {"resultado": {"id": 992, "estado": "confirmado"}, "filas": [aceptado]})
    _estado(eid, 992, "confirmado", reclama=True)
    with Session(engine_empresa(eid)) as s:
        assert [c["pedido_id"] for c in comandas.pendientes(s, eid)["copias"]] == [992]
