# -*- coding: utf-8 -*-
"""4.29, segunda parte, encargo A: botones de cobro con tecla (K-1 a K-7) y dos retoques (K-8, K-9).

- La ventana de cobro de pos/caja.js tiene tres botones: «Cancelar (F7)», el de la otra forma (F10) y el principal (F9).
- Una función pura (`formaCobro` en caja.js) decide los textos y si el comprobante de ESA venta se abre o imprime solo.
- `cobrar()` (F9, Enter, botón principal) y `cobrarOtro()` (F10, segundo botón) pasan por la misma puerta (`cobrarVenta`).
- K-8: aviso arriba de Punto de venta › Configuración en el programa conectado a la página web.
- K-9: el encabezado de la caja dice «1 venta»."""
import json
import pathlib
import re
import subprocess

import pytest

from test_425_ultimos_pantallas import _node, _nodo

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def _caja() -> str:
    return _js("pages/pos/caja.js")


def _funcion_forma(k: str) -> str:
    return _tramo(k, "export function formaCobro(", "\n}\n").replace("export function", "function") + "\n}\n"


AVISO = ("Esta computadora está conectada a la página web: la configuración de las cajas, impresoras de la empresa, promociones y "
         "modificadores se cambia en la página web y baja sola al sincronizar. Lo que cambie aquí se pierde en la siguiente "
         "sincronización. Aquí solo queda guardado lo de la tarjeta «En esta computadora».")


# ------------------------------------------------------------------------------------------------ 1) la función pura (K-2, K-3)
def test_forma_de_cobro_en_node(tmp_path):
    """Las cuatro combinaciones (caja que imprime o no × F9 o F10) y las cajas sin el dato."""
    r = _node(tmp_path, _funcion_forma(_caja()) + """
const out = {};
for (const [n, cfg] of [['imprime', { imprimir_auto: true }], ['no_imprime', { imprimir_auto: false }]]) {
  out[n] = { f9: formaCobro(cfg, false), f10: formaCobro(cfg, true) };
}
out.evento = formaCobro({ imprimir_auto: true }, { type: 'click' }).imprime;   // un evento no cuenta como «la otra forma»
out.nula = formaCobro(null, false); out.vacia = formaCobro({}, true);
console.log(JSON.stringify(out));
""", archivos=(), falsos={})
    si, no = r["imprime"], r["no_imprime"]
    assert si["f9"] == {"imprime": True, "principal": "Cobrar e imprimir (F9)", "otra": "Cobrar sin imprimir (F10)"}, r
    assert si["f10"]["imprime"] is False and si["f10"]["principal"] == "Cobrar e imprimir (F9)", r
    assert no["f9"] == {"imprime": False, "principal": "Cobrar sin imprimir (F9)", "otra": "Cobrar e imprimir (F10)"}, r
    assert no["f10"]["imprime"] is True and no["f10"]["otra"] == "Cobrar e imprimir (F10)", r
    assert r["evento"] is True                                                             # el clic del botón principal no invierte nada
    assert r["nula"]["imprime"] is False and r["vacia"]["imprime"] is True, r               # la misma prueba de siempre (if (cfg.imprimir_auto))


# ------------------------------------------------------------------------------------------------ 2) caja.js: botones, teclas, impresión
def test_tres_botones_al_pie_del_cobro():
    k = _caja()
    pie = _tramo(k, '<Modal v-if="pago"', "</Modal>")
    pie = pie[pie.index("<template #foot>"):]
    pie = pie[:pie.index("</template>")]
    botones = re.findall(r"<button [^>]*>[^<]*</button>", pie)
    assert len(botones) == 3, pie
    assert botones[0].endswith(">Cancelar (F7)</button>") and '@click="cerrarPago"' in botones[0] and ':disabled="cobrando"' in botones[0]
    assert '@click="cobrarOtro"' in botones[1] and "{{cobrando ? 'Emitiendo…' : botonesCobro.otra}}" in botones[1]
    assert '@click="cobrar"' in botones[2] and "{{cobrando ? 'Emitiendo…' : botonesCobro.principal}}" in botones[2]
    for b in botones[1:]:
        assert ':disabled="cobrando || !pagoTot.ok"' in b and "pos-cobrar" in b
    # el pie del modal baja de línea en el teléfono (sin taparse): .m-foot con flex-wrap
    css = (RAIZ / "app" / "static" / "ui.css").read_text(encoding="utf-8")
    assert ".modal .m-foot{display:flex;gap:8px;justify-content:flex-end;" in css and "flex-wrap:wrap}" in css
    # Enter en lo recibido sigue cobrando como el botón principal
    assert k.count('@keyup.enter="cobrar"') == 2


def test_teclas_f7_f9_f10():
    k = _caja()
    t = _tramo(k, "    tecla(e) {", "\n    },\n")
    # 4.39 (quinta vuelta, V7): con «Dividir» abierto, F9 no abre el cobro completo debajo (con la ventana de cobro abierta sigue cobrando)
    assert "if (e.key === 'F9') { e.preventDefault(); if (this.pago) this.cobrar(); else if (this.vista === 'venta' && !this.dividir) this.abrirPago(); }" in t
    assert "else if (e.key === 'F10' && this.pago) { e.preventDefault(); this.cobrarOtro(); }" in t
    assert "else if (e.key === 'F7' && this.pago) { e.preventDefault(); if (!this.cobrando) this.cerrarPago(); }" in t
    # las de siempre no cambian
    assert "else if (e.key === 'F2') { e.preventDefault(); this.$refs.buscar && this.$refs.buscar.focus(); }" in t
    assert "else if (e.key === 'F8') { e.preventDefault(); if (this.esRestaurante && this.vista === 'venta' && !this.pago) this.enviarComanda(); }" in t
    assert "else if (e.key === 'Escape') { if (this.pago) { if (!this.cobrando) this.cerrarPago(); }" in t


def test_teclas_en_node(tmp_path):
    """F10 y F7 solo actúan con la ventana de cobro abierta (y ahí con preventDefault); fuera de ella no hacen nada ni se les quita
    su función del navegador. F7 no cierra mientras está cobrando."""
    k = _caja()
    metodo = _tramo(k, "    tecla(e) {", "\n    },\n").strip() + "\n    }"
    r = _node(tmp_path, """
const M = { %s };
function prueba(clave, estado) {
  const vm = Object.assign({ pago: null, cobrando: false, vista: 'venta', esRestaurante: false, llamadas: [], $refs: {} }, estado);
  for (const n of ['cobrar', 'cobrarOtro', 'cerrarPago', 'abrirPago', 'enviarComanda', 'guardarCuenta']) vm[n] = () => vm.llamadas.push(n);
  let evitado = false; M.tecla.call(vm, { key: clave, preventDefault() { evitado = true; } });
  return [vm.llamadas, evitado];
}
console.log(JSON.stringify({
  f10_abierto: prueba('F10', { pago: {} }), f10_cerrado: prueba('F10', {}),
  f7_abierto: prueba('F7', { pago: {} }), f7_cobrando: prueba('F7', { pago: {}, cobrando: true }), f7_cerrado: prueba('F7', {}),
  f9_abierto: prueba('F9', { pago: {} }), f9_cerrado: prueba('F9', {}),
  f9_dividir: prueba('F9', { dividir: {} }), f9_dividir_pago: prueba('F9', { dividir: {}, pago: {} }),
  esc_abierto: prueba('Escape', { pago: {} }),
}));
""" % metodo, archivos=(), falsos={})
    assert r["f10_abierto"] == [["cobrarOtro"], True] and r["f10_cerrado"] == [[], False], r
    assert r["f7_abierto"] == [["cerrarPago"], True] and r["f7_cobrando"] == [[], True] and r["f7_cerrado"] == [[], False], r
    assert r["f9_abierto"] == [["cobrar"], True] and r["f9_cerrado"] == [["abrirPago"], True], r
    # 4.39 (quinta vuelta, V7): con «Dividir» abierto F9 no abre el cobro completo (sí se le quita al navegador); con el cobro abierto, cobra
    assert r["f9_dividir"] == [[], True] and r["f9_dividir_pago"] == [["cobrar"], True], r
    assert r["esc_abierto"] == [["cerrarPago"], False], r


def test_la_impresion_sigue_la_eleccion_en_todos_los_caminos():
    k = _caja()
    cobrar = _tramo(k, "    async cobrar() {", "    async abrirCargoHab() {")
    emitir = _tramo(cobrar, "    async emitirCobro(otra) {", "\n    },\n")
    # se decide al empezar el cobro (antes de esperar al servidor), con la elección de esta venta
    i = emitir.index("this.cobrando = true;")
    j = emitir.index("const imprime = formaCobro(this.cfg, otra).imprime;")
    assert i < j < emitir.index("doc = await api('/api/comprobantes'") and j < emitir.index("this.ventaSinConexion({ body,")
    # comprobante normal y provisional (sin conexión): la elección viaja; la gaveta y el resto siguen igual
    assert "if (imprime) this.imprimir(this.ultima);" in emitir and "this.cfg.imprimir_auto" not in emitir
    assert "salonero, imprime, fiado, regalos, rapida })" in emitir
    assert "if (this.cfg.abrir_gaveta && medios.some(m => m.medio === '01')) {" in emitir
    sin = _tramo(k, "    ventaSinConexion(c) {", "    docProvisional(v) {")
    assert "if (c.imprime !== undefined ? c.imprime : this.cfg.imprimir_auto) this.imprimirProvisional(v);" in sin
    assert "if (this.cfg.abrir_gaveta && c.medios.some(m => m.medio === '01')) {" in sin
    # nada más lee imprimir_auto en la caja (solo la función pura)
    assert "if (this.cfg.imprimir_auto) this.imprimir" not in k and "const siempre = !!(cfg && cfg.imprimir_auto);" in k
    # la venta rápida, el cobro por partes y la comanda numerada usan el mismo cobro (abrirPago → cobrar / cobrarOtro)
    assert "this.dividir = null; this.idem = uuid(); this.abrirPago();" in k
    assert "if (modo) return this.comandaNumerada(modo, nuevas, grupos, ronda, ahora);" in k


# ------------------------------------------------------------------------------------------------ 3) K-6: no cobrar dos veces
def test_una_sola_puerta_para_cobrar():
    k = _caja()
    assert "    async cobrar() { return this.cobrarVenta(false); }," in k
    assert "    cobrarOtro() { return this.cobrarVenta(true); }," in k
    puerta = _tramo(k, "    async cobrarVenta(otra) {", "\n    },\n")
    assert "if (this.cobrando || this._cobroEnCurso) return;" in puerta and "finally { this._cobroEnCurso = false; }" in puerta
    # 4.39 (segunda vuelta): la guarda de emitirCobro también corta mientras «Cargar a la habitación» pide su cobro (_habEnCurso, R3):
    # F9 o F10 no cobran en la caja la misma cuenta que se está cargando. Sigue siendo la primera línea y sigue cortando con «cobrando»
    # 4.39 (cuarta vuelta): la primera línea es «if (this.cobrando) return;» y la segunda corta con _habEnCurso, ahora con aviso
    assert ("    async emitirCobro(otra) {\n      if (this.cobrando) return;\n"
            "      if (this._habEnCurso) return toast('Se está revisando el cargo a la habitación: espere un momento', 'err');") in k
    assert k.count("this.emitirCobro(") == 1 and k.count("this.cobrarVenta(") == 2


def test_no_cobra_dos_veces_y_la_eleccion_no_queda_pegada_en_node(tmp_path):
    """Con los métodos reales: mientras un cobro está en curso, F9, F10, Enter o un clic no hacen nada; al terminar, el cobro
    siguiente sale con lo de la caja (la elección de F10 no queda pegada). También si el cobro anterior falló."""
    k = _caja()
    metodos = [_tramo(k, "    async cobrar() {", "\n").strip().rstrip(","), _tramo(k, "    cobrarOtro() {", "\n").strip().rstrip(","),
               _tramo(k, "    async cobrarVenta(otra) {", "\n    },\n").strip() + "\n    }"]
    r = _node(tmp_path, _funcion_forma(k) + """
const M = { %s };
const vm = { cobrando: false, cfg: { imprimir_auto: true }, emitidos: [], pendientes: [] };
for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
// emitirCobro de prueba: marca «cobrando» como el real (después de revisar el turno) y espera al «servidor»
vm.emitirCobro = function (otra) {
  return new Promise((ok, mal) => { vm.pendientes.push(() => { vm.cobrando = true; vm.emitidos.push(formaCobro(vm.cfg, otra).imprime); vm.cobrando = false; ok(); }); vm.pendientes.push(mal); });
};
const out = {};
const p1 = vm.cobrarOtro({ type: 'keydown' });           // F10
vm.cobrar(); vm.cobrar({ type: 'keyup' }); vm.cobrarOtro(); // F9, Enter y otro F10 mientras se revisa
out.llamadas_en_curso = vm.pendientes.length / 2;
vm.pendientes[0](); await p1; vm.pendientes = [];
out.primero = vm.emitidos.slice();
const p2 = vm.cobrar({ type: 'click' }); vm.pendientes[0](); await p2; vm.pendientes = [];
out.segundo = vm.emitidos.slice();
// un cobro que falla también suelta la puerta
const p3 = vm.cobrarOtro(); vm.pendientes[1](new Error('x')); await p3.catch(() => {}); vm.pendientes = [];
const p4 = vm.cobrar(); vm.pendientes[0](); await p4; vm.pendientes = [];
out.tras_falla = vm.emitidos.slice(); out.puerta = vm._cobroEnCurso;
vm.cobrando = true; out.cobrando = [await vm.cobrar(), await vm.cobrarOtro(), vm.pendientes.length];
console.log(JSON.stringify(out));
""" % ",\n".join(metodos), archivos=(), falsos={})
    assert r["llamadas_en_curso"] == 1, r                                                  # una sola emisión
    assert r["primero"] == [False], r                                                      # F10 en caja que imprime: sin imprimir
    assert r["segundo"] == [False, True], r                                                # la siguiente, con lo de la caja
    assert r["tras_falla"] == [False, True, True] and r["puerta"] is False, r              # el F10 que falló no deja nada pegado
    assert r["cobrando"] == [None, None, 0], r


# ------------------------------------------------------------------------------------------------ 4) K-9: «1 venta»
def test_una_venta_en_singular(tmp_path):
    k = _caja()
    assert "{{resumenCaja.ventas}} ventas" not in k and k.count("{{textoVentas(resumenCaja.ventas)}}") == 2
    metodo = _tramo(k, "    textoVentas(n) {", "\n").strip().split("   /*")[0].strip().rstrip(",")
    r = _node(tmp_path, "const M = { %s };\nconsole.log(JSON.stringify([0, 1, 2, 15, undefined, '1'].map(n => M.textoVentas(n))));" % metodo, archivos=(), falsos={})
    assert r == ["0 ventas", "1 venta", "2 ventas", "15 ventas", "0 ventas", "1 venta"], r


# ------------------------------------------------------------------------------------------------ 5) K-8: aviso en Configuración
def test_aviso_de_la_computadora_conectada():
    c = _js("pages/pos/configuracion.js")
    assert "export const AVISO_CONECTADA_WEB = '" + AVISO + "';" in c
    assert '<div class="alert warn" v-if="avisoWeb">{{AVISO_CONECTADA_WEB}}</div>' in c
    # arriba de la pantalla: justo después del encabezado
    assert c.index("</PageHead>") < c.index('v-if="avisoWeb"') < c.index('<div class="alert warn" v-if="!puedeConfigurar">')
    assert "avisoWeb() { return this.esPrograma && (this.conectadaWeb || this.eqWeb); }," in _tramo(c, "  computed: {", "  methods: {")
    assert "eq: null, eqWeb: false, conectadaWeb: false, AVISO_CONECTADA_WEB, guardandoEq: false," in _tramo(c, "  data() {", "  computed: {")
    # solo el programa pregunta; en la página web no hay petición nueva
    assert "    if (this.esPrograma) this.revisarConexionWeb();" in c
    rev = _tramo(c, "    async revisarConexionWeb() {", "\n")
    assert "api('/api/sinc/local/estado')" in rev and "e.vinculado && !e.revocada_en && !e.descartada" in rev and "catch { this.conectadaWeb = false; }" in rev
    # no bloquea el guardado
    guardar = _tramo(c, "    async guardar() {", "\n    },\n")
    assert "avisoWeb" not in guardar and "conectadaWeb" not in guardar
    # lo que dice el aviso es lo que baja de la web (sinc.CLAVES_CATALOGO) y lo que no (la impresión de esta computadora)
    from app import sinc
    for clave in ("pos_config", "pos_impresoras", "pos_promos", "pos_modificadores"):
        assert clave in sinc.CLAVES_CATALOGO, clave
    assert "equipo_impresion" in sinc.CLAVES_DEL_EQUIPO and "equipo_impresion" not in sinc.CLAVES_CATALOGO


def test_aviso_solo_en_el_programa_conectado_en_node(tmp_path):
    c = _js("pages/pos/configuracion.js")
    linea = lambda nombre: _tramo(c, "    " + nombre, "\n").strip().split("   /*")[0].split("   //")[0].strip().rstrip(",")
    r = _node(tmp_path, """
const C = { %s, %s };
const M = { %s };
function vm(local, conectada, eqWeb) {
  const v = { conectadaWeb: conectada, eqWeb };
  globalThis.sesion = { empresaInfo: { es_local: local } };
  for (const [n, f] of Object.entries(C)) Object.defineProperty(v, n, { get: f.bind(v) });
  return v.avisoWeb;
}
const out = { web: vm(false, true, true), suelto: vm(true, false, false), conectado: vm(true, true, false), impresoras: vm(true, false, true) };
const estados = [{ modo_local: true, vinculado: true }, { modo_local: true, vinculado: false }, { modo_local: true, vinculado: true, revocada_en: '2026-11-01' },
                 { modo_local: true, vinculado: true, descartada: true }, null, 'falla'];
out.estado = [];
for (const e of estados) {
  globalThis.api = async () => { if (e === 'falla') throw new Error('403'); return e; };
  const v = { conectadaWeb: null }; await M.revisarConexionWeb.call(v); out.estado.push(v.conectadaWeb);
}
console.log(JSON.stringify(out));
""" % (linea("esPrograma() {"), linea("avisoWeb() {"), linea("async revisarConexionWeb() {")), archivos=(), falsos={})
    assert r["web"] is False and r["suelto"] is False and r["conectado"] is True and r["impresoras"] is True, r
    assert r["estado"] == [True, False, False, False, False, False], r


# ------------------------------------------------------------------------------------------------ 6) nombres de la plantilla y sintaxis
def test_nombres_de_las_plantillas_existen():
    k = _caja()
    computed = _tramo(k, "  computed: {", "  methods: {")
    methods = k[k.index("  methods: {"):]
    assert "    botonesCobro() {" in computed
    for m in ("    async cobrar() {", "    cobrarOtro() {", "    cerrarPago() {", "    textoVentas(n) {", "    async cobrarVenta(otra) {", "    async emitirCobro(otra) {"):
        assert m in methods, m
    c = _js("pages/pos/configuracion.js")
    assert "    avisoWeb() {" in _tramo(c, "  computed: {", "  methods: {") and "    async revisarConexionWeb() {" in c[c.index("  methods: {"):]
    for txt in (k, c):
        assert re.search(r"@click=\"[^\"]*\bif\b", txt) is None                              # ningún manejador en línea con «if»


def test_sintaxis_y_plantillas(tmp_path):
    """node --check de los dos archivos tocados y el compilador de Vue del proyecto sobre sus plantillas."""
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    tocados = ("pages/pos/caja.js", "pages/pos/configuracion.js")
    for rel in tocados:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    rutas = json.dumps([str(JS / r) for r in tocados])
    guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const malos = [];
let n = 0, saltadas = 0;
for (const a of %s) {
  const txt = fs.readFileSync(a, 'utf8'); const re = /template:\\s*`([\\s\\S]*?)`/g; let m;
  while ((m = re.exec(txt))) {
    if (m[1].includes('${')) { saltadas++; continue; }
    n++;
    const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); }
    if (err.length) malos.push([a, err.slice(0, 2)]);
  }
}
console.log(JSON.stringify({ n, saltadas, malos }));
""" % (json.dumps(vue), rutas)
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    r = json.loads(out.stdout)
    assert r["n"] == 2 and r["saltadas"] == 0 and r["malos"] == [], r


def test_finales_de_linea_sin_mezclar():
    for rel in ("pages/pos/caja.js", "pages/pos/configuracion.js"):
        b = (JS / rel).read_bytes()
        assert b.count(b"\r\n") == 0, rel                                                   # los dos son LF
