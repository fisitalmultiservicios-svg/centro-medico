"""3.87: escrituras de registros revisadas por contenido y lecturas sin montos para los roles operativos.
- hospitalidad:1  El Técnico (solo «mantenimiento») crea, cambia y quita SUS bloqueos de fechas; no toca reservas de huéspedes,
                  bloqueos de iCal ni reemplaza la lista completa.
- hospitalidad:2  La Camarera (solo «limpieza») cambia el estado de limpieza de las habitaciones y nada más.
- hospitalidad:3  Desde la caja (solo «pos») a la cuenta del huésped solo entran cargos nuevos de la caja; nunca se borran pagos.
- hospitalidad:4  Camarera, Técnico y Seguridad no reciben montos por la API (reservas, tarifas, cotizaciones, eventos,
                  comprobantes, pagos, costos ni valor del inventario).
- hospitalidad:5  El Cajero no genera, no lee ni reescribe el paquete PDF del cierre del día del hotel.
- hospitalidad:9  Un rol de solo caja sin el punto de venta activo no hereda la lectura general («ver»).
- hospitalidad:13 Los enlaces públicos del calendario (iCal) solo los ve quien configura.
- comercio:2      El Cajero abre, vende y cierra su caja, pero no reabre, maquilla ni borra cierres ya hechos.
- extras:7        El servidor respeta el periodo contable cerrado (asientos)."""
import json
import pathlib
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, modulos
from app.db import Empresa, Producto, engine, engine_empresa, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
PW = "Clave-larga-387-registros-QA"
c = TestClient(app)
H = lambda t: {"Authorization": "Bearer " + t}   # noqa: E731

ROLES_HOTEL = {"Camarera": ["limpieza"], "Técnico": ["mantenimiento"], "Seguridad": ["seguridad"],
               "Recepcionista": ["escribir", "facturar", "catalogos", "cobros", "pos"]}
ROLES_COMERCIO = {"Supervisor de caja": ["escribir", "facturar", "catalogos", "inventario", "cobros", "pos"]}


def _empresa(nombre, tipo, roles, usuarios, sufijo):
    """Empresa de prueba con roles propios y usuarios @example.test con sesión lista ({rol: token})."""
    init_db()
    tokens = {}
    with Session(engine) as s:
        e = Empresa(nombre=nombre, numero_id="3101387" + sufijo, actividad="551001", otras_senas="QA 387", correo=f"emp{sufijo}@example.test",
                    ambiente="sandbox", tipo_negocio=tipo)
        s.add(e); s.commit(); s.refresh(e)
        for n, p in roles.items():
            s.add(auth.RolEmpresa(empresa_id=e.id, nombre=n, permisos=json.dumps(p)))
        s.commit()
        for rol, correo in usuarios.items():
            u = auth.Usuario(correo=correo, nombre=rol + " QA", password_hash=auth.hash_password(PW), mfa_activo=True,
                             terminos_version=auth.TERMINOS_VERSION, terminos_fecha=datetime.now(timezone.utc), consiente_factura=True, paleta="turquesa")
            s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol=rol)); s.commit()
            tokens[rol] = auth._respuesta(s, u, e.id)["token"]
        eid = e.id
    return eid, tokens


def _borrar(eid, correos):
    with Session(engine) as s:
        for correo in correos:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            if not u:
                continue
            for x in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                s.delete(x)
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == u.id)).all():
                s.delete(x)
            s.delete(u)
        for r in s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == eid)).all():
            s.delete(r)
        e = s.get(Empresa, eid)
        if e:
            s.delete(e)
        s.commit()


def _sembrar(eid, datos):
    with Session(engine_empresa(eid)) as s:
        for clave, valor in datos.items():
            r = modulos._registro(s, eid, clave)
            modulos.reemplazar(s, eid, clave, valor, (r.version or 0) if r else None)


def _leer(eid, clave):
    with Session(engine_empresa(eid)) as s:
        return modulos.leer(s, eid, clave, None)


def _cambios(t, clave, upserts=(), deletes=(), nuevos=()):
    return c.post(f"/api/registros/{clave}/cambios", headers=H(t), json={"upserts": list(upserts), "deletes": list(deletes), "nuevos": list(nuevos)})


def _put(t, clave, datos):
    v = c.get(f"/api/registros/{clave}", headers=H(t))
    version = v.json().get("version", 0) if v.status_code == 200 else 0
    return c.put(f"/api/registros/{clave}", headers=H(t), json={"datos": datos, "version": version})


RESERVA_1 = {"id": 1, "numero": "R-0001", "tipo": "reserva", "estado": "en_casa", "habitacion_id": 1, "llegada": "2026-11-04", "salida": "2026-11-07",
             "huesped_nombre": "Ana QA", "moneda": "USD", "total": 300, "tarifa_noche": 100, "neto": 265.49, "iva": 34.51, "adelanto_requerido": 150,
             "precio_manual": None, "historial": [{"fecha": "2026-11-01T10:00:00", "usuario": "recepcion", "texto": "Reserva creada · total $300"}]}
RESERVA_2 = {"id": 2, "numero": "R-0002", "tipo": "reserva", "estado": "confirmada", "habitacion_id": 2, "llegada": "2026-12-01", "salida": "2026-12-03",
             "huesped_nombre": "Luis QA", "moneda": "USD", "total": 200, "tarifa_noche": 100, "neto": 177, "iva": 23, "adelanto_requerido": 100}
ICAL_3 = {"id": 3, "tipo": "bloqueo", "estado": "bloqueo", "origen": "ical", "habitacion_id": 3, "llegada": "2026-12-10", "salida": "2026-12-12", "motivo": "Booking"}
BLOQUEO_4 = {"id": 4, "tipo": "bloqueo", "estado": "bloqueo", "numero": "BLQ", "habitacion_id": 3, "llegada": "2026-11-20", "salida": "2026-11-22",
             "motivo": "Pintura", "historial": [{"texto": "Bloqueo creado por recepción"}]}
HABS = [{"id": i, "numero": str(100 + i), "categoria_id": 1, "activa": True, "estado": "limpia", "personas": 2,
         "ical_urls": ["https://calendario.example.test/privado.ics"] if i == 1 else []} for i in (1, 2, 3)]
CONFIG = {"activo": True, "nombre": "Hotel 387 QA", "moneda": "USD", "tarifas": {"1": {"base": 100}}, "planes": [{"id": 1, "nombre": "Solo habitación", "pct": 0}],
          "temporadas": [{"nombre": "Alta", "desde": "2026-12-15", "hasta": "2027-01-15", "pct": 20}], "adelanto_pct": 50, "persona_extra": 15,
          "cargos_auto": [{"detalle": "Desayuno", "precio": 10}], "minibar_categoria": "Minibar", "hora_entrada": "15:00"}
FOLIOS = [{"id": 1, "reserva_id": 1, "tipo": "cargo", "origen": "hospedaje", "detalle": "Hospedaje", "cantidad": 1, "precio": 100, "moneda": "USD"},
          {"id": 2, "reserva_id": 1, "tipo": "pago", "medio": "02", "detalle": "Adelanto", "monto": 150, "moneda": "USD", "en_banco": True}]


@pytest.fixture(scope="module")
def hotel():
    correos = {r: f"{r.lower().replace('é', 'e')}.reg387@example.test" for r in ["Administrador", "Cajero", *ROLES_HOTEL]}
    eid, tok = _empresa("Hotel Registros 387 QA", "hospitalidad", ROLES_HOTEL, correos, "01")
    _sembrar(eid, {"hotel_config": CONFIG, "hotel_habitaciones": HABS, "hotel_folios": FOLIOS,
                   "hotel_cotizaciones": [{"id": 1, "numero": "COT-0001", "nombre": "Grupo QA", "total": 500, "promedio": 125}],
                   "hotel_eventos": [{"id": 1, "numero": "EV-0001", "nombre": "Boda QA", "lineas": [{"concepto": "Salón", "precio": 300}]}],
                   "hotel_tipos_problema": [{"id": 1, "nombre": "Fuga", "modulo": "mantenimiento", "activo": True}]})
    with Session(engine_empresa(eid)) as s:
        s.add(Producto(empresa_id=eid, nombre="Lavado QA", cabys="9811000000000", precio=5000, costo=1800, unidad_medida="Sp", es_servicio=True,
                       codigo_tarifa="08", tarifa=13))
        s.commit()
    yield eid, tok
    _borrar(eid, correos.values())


def _reservas_base(eid):
    _sembrar(eid, {"hotel_reservas": [RESERVA_1, RESERVA_2, ICAL_3, BLOQUEO_4]})


# ----------------------------------------------------------------------------- hospitalidad:1
def test_tecnico_solo_crea_cambia_y_quita_sus_bloqueos(hotel):
    eid, tok = hotel
    _reservas_base(eid)
    t = tok["Técnico"]
    nuevo = {"id": 10, "tipo": "bloqueo", "estado": "bloqueo", "numero": "BLQ", "habitacion_id": 2, "llegada": "2026-11-10", "salida": "2026-11-12", "motivo": "Mantenimiento"}
    assert _cambios(t, "hotel_reservas", [nuevo], nuevos=[10]).status_code == 200                       # crea su bloqueo
    assert _cambios(t, "hotel_reservas", [{**nuevo, "motivo": "Aire acondicionado"}]).status_code == 200  # le cambia el motivo
    assert _cambios(t, "hotel_reservas", deletes=[10]).status_code == 200                               # lo quita
    # lo que no es suyo: 403 y todo queda igual
    assert _cambios(t, "hotel_reservas", [{**RESERVA_1, "total": 1, "tarifa_noche": 0.33, "estado": "cancelada"}]).status_code == 403
    assert _cambios(t, "hotel_reservas", [{**RESERVA_2, "tipo": "bloqueo", "estado": "bloqueo"}]).status_code == 403   # convertirla en bloqueo
    falsa = {"id": 11, "numero": "R-9999", "tipo": "reserva", "estado": "confirmada", "habitacion_id": 2, "llegada": "2027-01-10", "salida": "2027-01-12", "total": 1}
    assert _cambios(t, "hotel_reservas", [falsa], nuevos=[11]).status_code == 403
    assert _cambios(t, "hotel_reservas", deletes=[1]).status_code == 403
    assert _cambios(t, "hotel_reservas", deletes=[3]).status_code == 403                                # bloqueo de iCal
    otro = {**nuevo, "id": 12, "llegada": "2027-02-01", "salida": "2027-02-03"}
    assert _cambios(t, "hotel_reservas", [otro], deletes=[2], nuevos=[12]).status_code == 403            # lote mixto
    assert _put(t, "hotel_reservas", []).status_code == 403
    guardadas = {r["id"]: r for r in _leer(eid, "hotel_reservas")}
    assert set(guardadas) == {1, 2, 3, 4} and guardadas[1]["total"] == 300 and guardadas[1]["estado"] == "en_casa" and guardadas[2]["tipo"] == "reserva"
    # un alta con un id ya ocupado no pisa la reserva: el servidor le da otro id
    r = _cambios(t, "hotel_reservas", [{**nuevo, "id": 1}], nuevos=[1])
    assert r.status_code == 200 and r.json()["remap"].get("1")
    assert {x["id"]: x for x in _leer(eid, "hotel_reservas")}[1]["total"] == 300
    # recepción sigue cambiando reservas
    assert _cambios(tok["Recepcionista"], "hotel_reservas", [{**RESERVA_2, "notas": "Llega tarde"}]).status_code == 200


# ----------------------------------------------------------------------------- hospitalidad:2
def test_camarera_solo_cambia_el_estado_de_las_habitaciones(hotel):
    eid, tok = hotel
    _sembrar(eid, {"hotel_habitaciones": HABS})
    t = tok["Camarera"]
    assert _cambios(t, "hotel_habitaciones", [{**HABS[1], "estado": "limpiando", "estado_usuario": "camarera"}]).status_code == 200
    # número, categoría y activa no cambian aunque vengan en el mismo envío (el estado sí)
    assert _cambios(t, "hotel_habitaciones", [{**HABS[2], "numero": "103-X", "categoria_id": 9, "activa": False, "estado": "sucia"}]).status_code == 200
    assert _cambios(t, "hotel_habitaciones", [{**HABS[0], "id": "1", "numero": "101-X"}]).status_code == 200      # id como texto
    habs = {h["id"]: h for h in _leer(eid, "hotel_habitaciones")}
    assert habs[2]["estado"] == "limpiando" and habs[3]["estado"] == "sucia"
    assert habs[3]["numero"] == "103" and habs[3]["categoria_id"] == 1 and habs[3]["activa"] is True and habs[1]["numero"] == "101"
    assert habs[1]["ical_urls"]                                                     # lo que no se le envió a la camarera no se pierde
    assert _cambios(t, "hotel_habitaciones", deletes=[3]).status_code == 403
    assert _cambios(t, "hotel_habitaciones", [{"id": 9, "numero": "999", "categoria_id": 1}], nuevos=[9]).status_code == 403
    assert _put(t, "hotel_habitaciones", []).status_code == 403
    assert len(_leer(eid, "hotel_habitaciones")) == 3
    # el Técnico marca mantenimiento pero no borra
    assert _cambios(tok["Técnico"], "hotel_habitaciones", [{**HABS[0], "estado": "mantenimiento"}]).status_code == 200
    assert _cambios(tok["Técnico"], "hotel_habitaciones", deletes=[1]).status_code == 403
    # tipos de problema: agregan uno, pero no vacían la lista
    assert _cambios(t, "hotel_tipos_problema", [{"id": 2, "nombre": "Toallas", "modulo": "limpieza", "activo": True}], nuevos=[2]).status_code == 200
    assert _put(t, "hotel_tipos_problema", []).status_code == 403
    assert len(_leer(eid, "hotel_tipos_problema")) == 2
    # quien configura sigue renombrando
    assert _cambios(tok["Administrador"], "hotel_habitaciones", [{**HABS[2], "numero": "103-A"}]).status_code == 200
    assert {h["id"]: h for h in _leer(eid, "hotel_habitaciones")}[3]["numero"] == "103-A"


# ----------------------------------------------------------------------------- hospitalidad:3
def test_cajero_solo_agrega_cargos_de_caja_a_cuentas_abiertas(hotel):
    eid, tok = hotel
    _reservas_base(eid)
    _sembrar(eid, {"hotel_folios": FOLIOS})
    t = tok["Cajero"]
    cargo = {"id": 20, "reserva_id": 1, "tipo": "cargo", "origen": "pos", "detalle": "Cena", "cantidad": 2, "precio": 12.5, "moneda": "USD", "caja": "Restaurante"}
    assert _cambios(t, "hotel_folios", [cargo], nuevos=[20]).status_code == 200
    assert _cambios(t, "hotel_folios", [{**cargo, "id": 21, "reserva_id": 2}], nuevos=[21]).status_code == 403     # la reserva no está en casa
    assert _cambios(t, "hotel_folios", [{**cargo, "id": 22, "precio": -50}], nuevos=[22]).status_code == 403       # un «cargo» negativo es un pago
    assert _cambios(t, "hotel_folios", [{**FOLIOS[1], "id": 23, "monto": 999}], nuevos=[23]).status_code == 403    # pago falso
    assert _cambios(t, "hotel_folios", [{**FOLIOS[1], "monto": 1500}]).status_code == 403                          # cambia el adelanto
    assert _cambios(t, "hotel_folios", [{**FOLIOS[0], "precio": 0}]).status_code == 403                            # cambia el hospedaje
    assert _cambios(t, "hotel_folios", deletes=[2]).status_code == 403                                             # borra el adelanto
    assert _cambios(t, "hotel_folios", deletes=[20]).status_code == 403                                            # ni su propio cargo
    assert _put(t, "hotel_folios", []).status_code == 403
    folios = {f["id"]: f for f in _leer(eid, "hotel_folios")}
    assert set(folios) == {1, 2, 20} and folios[2]["monto"] == 150 and folios[1]["precio"] == 100
    # recepción quita el cargo desde la cuenta del huésped
    assert _cambios(tok["Recepcionista"], "hotel_folios", deletes=[20]).status_code == 200


# ----------------------------------------------------------------------------- hospitalidad:4
CAMPOS_DINERO = ("total", "tarifa_noche", "neto", "iva", "adelanto_requerido", "precio_manual")


def test_roles_operativos_no_reciben_montos(hotel):
    eid, tok = hotel
    _reservas_base(eid)
    _sembrar(eid, {"hotel_config": CONFIG})
    for rol in ("Camarera", "Técnico", "Seguridad"):
        t = tok[rol]
        r = c.get("/api/registros/hotel_reservas", headers=H(t))
        assert r.status_code == 200, (rol, r.text)
        reservas = {x["id"]: x for x in r.json()["datos"]}
        assert reservas[1]["huesped_nombre"] == "Ana QA" and reservas[1]["llegada"] == "2026-11-04"          # lo que usa su tablero
        assert not any(k in x for x in reservas.values() for k in CAMPOS_DINERO + ("historial",)), rol
        cfg = c.get("/api/registros/hotel_config", headers=H(t)).json()["datos"]
        assert cfg["nombre"] == "Hotel 387 QA" and cfg["minibar_categoria"] == "Minibar"
        assert not any(k in cfg for k in ("tarifas", "temporadas", "planes", "persona_extra", "cargos_auto", "adelanto_pct")), rol
        for clave in ("hotel_cotizaciones", "hotel_folios"):
            assert c.get(f"/api/registros/{clave}", headers=H(t)).status_code == 403, (rol, clave)
        ev = c.get("/api/registros/hotel_eventos", headers=H(t)).json()["datos"]
        assert ev[0]["nombre"] == "Boda QA" and "lineas" not in ev[0]
        a = c.get("/api/arranque", headers=H(t))
        assert a.status_code == 200
        regs = a.json()["registros"]["datos"]
        assert "hotel_cotizaciones" not in regs and "lineas" not in regs["hotel_eventos"][0] and "tarifas" not in regs["hotel_config"]
        assert regs["hotel_reservas"] and not any("total" in x for x in regs["hotel_reservas"])
        assert not any("costo" in p for p in a.json()["productos"]) and a.json()["productos"][0]["precio"] == 5000   # precio sí (lavandería)
        v2 = c.get("/api/registros?v=2", headers=H(t)).json()["datos"]
        assert not any("total" in x for x in v2["hotel_reservas"])
        viejo = c.get("/api/registros", headers=H(t)).json()
        assert not any("total" in x for x in viejo["hotel_reservas"])
        assert not any("costo" in p for p in c.get("/api/productos", headers=H(t)).json())
        for ruta in ("/api/comprobantes", "/api/pagos", "/api/comprobantes/999999", "/api/comprobantes/999999/pdf", "/api/comprobantes/999999/xml",
                     "/api/comprobantes/999999/tiquete", "/api/inventario/valor", "/api/inventario/existencias"):
            assert c.get(ruta, headers=H(t)).status_code == 403, (rol, ruta)
    # quien opera recepción, la caja o administra sigue con todo
    for rol in ("Administrador", "Recepcionista", "Cajero"):
        reservas = {x["id"]: x for x in c.get("/api/registros/hotel_reservas", headers=H(tok[rol])).json()["datos"]}
        assert reservas[1]["total"] == 300, rol
    assert "tarifas" in c.get("/api/registros/hotel_config", headers=H(tok["Recepcionista"])).json()["datos"]
    assert c.get("/api/comprobantes", headers=H(tok["Recepcionista"])).status_code == 200
    assert any("costo" in p for p in c.get("/api/productos", headers=H(tok["Administrador"])).json())
    # el Técnico cambia su bloqueo sin enterarse de lo que no recibe, y no se pierde
    assert _cambios(tok["Técnico"], "hotel_reservas", [{k: v for k, v in BLOQUEO_4.items() if k != "historial"} | {"motivo": "Pintura y cielo"}]).status_code == 200
    b = {x["id"]: x for x in _leer(eid, "hotel_reservas")}[4]
    assert b["motivo"] == "Pintura y cielo" and b["historial"] == BLOQUEO_4["historial"]


def test_token_de_api_sigue_leyendo_comprobantes(hotel):
    eid, tok = hotel
    r = c.post("/api/auth/tokens-api", headers=H(tok["Administrador"]), json={"nombre": "Catalogo 387", "permisos": ["catalogos"]})
    assert r.status_code == 200, r.text
    assert c.get("/api/comprobantes", headers=H(r.json()["token"])).status_code == 200


# ----------------------------------------------------------------------------- hospitalidad:5
CIERRE = {"fecha": "2026-11-04", "usuario": "Recepcionista QA", "notas": "Normal", "resumen": {"ocupadas": 1, "total": 3, "cargos": 100, "pagos": 150},
          "pendientes": [], "kpis": [{"t": "Cargos del día", "v": "$100,00"}], "secciones": []}


def test_cajero_no_genera_ni_lee_el_cierre_del_hotel(hotel):
    eid, tok = hotel
    r = c.post("/api/hotel/cierre-paquete", headers=H(tok["Recepcionista"]), json=CIERRE)
    assert r.status_code == 200, r.text
    t = tok["Cajero"]
    assert c.post("/api/hotel/cierre-paquete", headers=H(t), json={**CIERRE, "notas": "ALTERADO", "resumen": {"cargos": 1}}).status_code == 403
    assert c.post("/api/hotel/cierre-correo", headers=H(t), json=CIERRE).status_code == 403
    assert c.get("/api/hotel/cierre-paquete", headers=H(t)).status_code == 403
    assert c.get("/api/hotel/cierre-paquete/2026-11-04", headers=H(t)).status_code == 403
    assert c.get("/api/registros/hotel_cierres", headers=H(t)).status_code == 403          # la misma regla que el registro
    assert c.get("/api/hotel/cierre-paquete", headers=H(tok["Recepcionista"])).json()["fechas"] == ["2026-11-04"]
    assert c.get("/api/hotel/cierre-paquete", headers=H(tok["Camarera"])).status_code == 403
    # quien vuelve a generar el paquete de un día que cerró otra persona queda escrito en el PDF
    from pypdf import PdfReader
    import io
    assert c.post("/api/hotel/cierre-paquete", headers=H(tok["Recepcionista"]), json={**CIERRE, "usuario": "Otra Recepción"}).status_code == 200
    pdf = c.get("/api/hotel/cierre-paquete/2026-11-04", headers=H(tok["Recepcionista"])).content
    texto = " ".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(pdf)).pages)
    assert "Otra Recepción" in texto and "generado por recepcionista.reg387@example.test" in " ".join(texto.split())
    js = (RAIZ / "static/js/pages/hotel/cierre.js").read_text(encoding="utf-8")
    assert "puedeEscribir() { return sesion.puede('escribir'); }" in js


# ----------------------------------------------------------------------------- hospitalidad:13
def test_enlaces_ical_solo_para_quien_configura(hotel):
    eid, tok = hotel
    for rol in ("Camarera", "Técnico", "Cajero", "Recepcionista", "Seguridad"):
        assert c.get("/api/hotel/ical/enlaces", headers=H(tok[rol])).status_code == 403, rol
    r = c.get("/api/hotel/ical/enlaces", headers=H(tok["Administrador"]))
    assert r.status_code == 200 and len(r.json()) == 3


# ----------------------------------------------------------------------------- hospitalidad:9
def test_cajero_sin_punto_de_venta_no_hereda_la_lectura_general(hotel):
    eid, tok = hotel
    t = tok["Cajero"]
    assert c.get("/api/comprobantes", headers=H(t)).status_code == 200                     # con la caja: solo lo de hoy
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "cajero.reg387@example.test")).one()
        m = s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id, auth.UsuarioEmpresa.empresa_id == eid)).one()
        m.modulos_ocultos = json.dumps(["pos"]); s.add(m); s.commit()                     # el punto de venta se apaga para él
    try:
        for ruta in ("/api/comprobantes", "/api/pagos", "/api/borradores", "/api/registros/hotel_reservas", "/api/registros/cotizaciones", "/api/clientes"):
            r = c.get(ruta, headers=H(t))
            assert r.status_code == 403, (ruta, r.text)
        d = c.get("/api/comprobantes", headers=H(t)).json()["detail"]
        assert d["codigo"] == "sin_caja" and "punto de venta" in d["mensaje"]
        a = c.get("/api/arranque", headers=H(t))                                            # entra, pero sin datos de la empresa
        assert a.status_code == 200 and "registros" not in a.json() and a.json()["yo"]["empresa_id"] == eid
    finally:
        with Session(engine) as s:
            m = s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == eid, auth.UsuarioEmpresa.rol == "Cajero")).one()
            m.modulos_ocultos = None; s.add(m); s.commit()
    assert c.get("/api/comprobantes", headers=H(t)).status_code == 200


# ----------------------------------------------------------------------------- comercio:2
def test_cajero_no_reabre_maquilla_ni_borra_cierres():
    correos = {"Administrador": "admin.caja387@example.test", "Cajero": "cajero.caja387@example.test", "Supervisor de caja": "super.caja387@example.test"}
    eid, tok = _empresa("Comercio Cierres 387 QA", "comercio", ROLES_COMERCIO, correos, "02")
    try:
        t = tok["Cajero"]
        _sembrar(eid, {"pos_cajas": [{"id": 1, "caja": "Caja 2", "estado": "Abierta", "usuario": "otro", "monto_inicial": 0, "fecha": "2026-11-04"}],
                       "pos_ventas": [{"id": 1, "caja_id": 3, "total": 2017, "medios": [{"medio": "01", "monto": 2017}]}]})
        ses = {"id": 3, "caja": "Caja 1", "estado": "Abierta", "usuario": "cajero", "monto_inicial": 1000, "fecha": "2026-11-05", "conteo": None, "diferencia": None}
        assert _cambios(t, "pos_cajas", [ses], nuevos=[3]).status_code == 200                                   # abre su caja
        ses = {**ses, "retiros": [{"monto": 500, "motivo": "Depósito"}]}
        assert _cambios(t, "pos_cajas", [ses]).status_code == 200                                                # retiro en su sesión abierta
        cerrada = {**ses, "estado": "Cerrada", "cerrada_en": "2026-11-05T20:00:00", "conteo": 500, "diferencia": -2017}
        assert _cambios(t, "pos_cajas", [cerrada]).status_code == 200                                            # la cierra (con faltante)
        assert _cambios(t, "pos_cajas", [{**cerrada, "conteo": 2517, "diferencia": 0}]).status_code == 403       # maquillar
        assert _cambios(t, "pos_cajas", [{**cerrada, "estado": "Abierta", "conteo": None, "diferencia": None}]).status_code == 403   # reabrir
        assert _cambios(t, "pos_cajas", deletes=[3]).status_code == 403                                          # borrar el cierre con ventas
        assert _put(t, "pos_cajas", []).status_code == 403
        assert _cambios(t, "pos_cajas", [{"id": 1, "caja": "Caja 2", "estado": "Cerrada", "usuario": "otro", "monto_inicial": 0, "fecha": "2026-11-04",
                                          "conteo": 0, "diferencia": 0}]).status_code == 200                   # cierra la sesión abierta de otro turno
        guardada = {x["id"]: x for x in _leer(eid, "pos_cajas")}[3]
        assert guardada["estado"] == "Cerrada" and guardada["diferencia"] == -2017
        # una sesión abierta sin ventas sí se puede quitar
        assert _cambios(t, "pos_cajas", [{"id": 5, "caja": "Caja 3", "estado": "Abierta", "usuario": "cajero", "monto_inicial": 0}], nuevos=[5]).status_code == 200
        assert _cambios(t, "pos_cajas", deletes=[5]).status_code == 200
        # el supervisor reabre y queda en la auditoría
        assert _cambios(tok["Supervisor de caja"], "pos_cajas", [{**cerrada, "estado": "Abierta", "conteo": None, "diferencia": None}]).status_code == 200
        with Session(engine) as s:
            aud = s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid, auth.Auditoria.accion == "pos_cierre_cambiado")).all()
        assert aud and "-2017" in aud[-1].detalle
        # 4.41 (cierre ciego): esa fila (lo contado y la diferencia) solo la ve en el historial quien ve el corte (ver_todo o configurar)
        ve = lambda rol: [a["accion"] for a in c.get("/api/auth/auditoria?limite=500", headers=H(tok[rol])).json()]   # noqa: E731
        assert "pos_cierre_cambiado" in ve("Administrador")
        assert "pos_cierre_cambiado" not in ve("Cajero") and "pos_cierre_cambiado" not in ve("Supervisor de caja")
        assert "-2017" not in c.get("/api/auth/auditoria?limite=500", headers=H(tok["Supervisor de caja"])).text
        js = (RAIZ / "static/js/pages/pos/cierres.js").read_text(encoding="utf-8")
        assert "v-else-if=\"puedeCorregir\" @click=\"reabrir(ver)\"" in js and "reaperturas:" in js
    finally:
        _borrar(eid, correos.values())


# ----------------------------------------------------------------------------- extras:7
def test_periodo_contable_cerrado_en_el_servidor():
    correos = {"Administrador": "admin.periodo387@example.test", "Contador": "contador.periodo387@example.test"}
    eid, tok = _empresa("Contable Periodos 387 QA", "facturacion", {}, correos, "03")
    try:
        t = tok["Contador"]
        lineas = [{"cuenta": "1.1.01", "debito": 100, "credito": 0}, {"cuenta": "4.1.01", "debito": 0, "credito": 100}]
        viejo = {"id": 1, "codigo": "AS-1", "fecha": "2026-10-05", "tipo": "Diario", "lineas": lineas}
        assert _cambios(t, "asientos", [viejo], nuevos=[1]).status_code == 200                               # antes de cerrar octubre
        meses = [{"n": i, "mes": m, "estado": "Cerrado" if i == 10 else "Abierto"} for i, m in enumerate(
            ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"], start=1)]
        assert _put(t, "periodos_2026", meses).status_code == 200
        r = _cambios(t, "asientos", [{**viejo, "id": 2, "codigo": "AS-2", "fecha": "2026-10-20"}], nuevos=[2])
        assert r.status_code == 403 and "Octubre 2026" in r.json()["detail"]
        nov = {**viejo, "id": 3, "codigo": "AS-3", "fecha": "2026-11-05"}
        assert _cambios(t, "asientos", [nov], nuevos=[3]).status_code == 200
        assert _cambios(t, "asientos", [{**nov, "fecha": "2026-10-15"}]).status_code == 403                 # moverlo hacia el mes cerrado
        assert _cambios(t, "asientos", [{**viejo, "fecha": "2026-11-01"}]).status_code == 403              # sacarlo del mes cerrado
        assert _cambios(t, "asientos", [{**viejo, "lineas": lineas[::-1]}]).status_code == 403             # cambiarlo
        assert _cambios(t, "asientos", deletes=[1]).status_code == 403
        assert _put(t, "asientos", [nov]).status_code == 403                                                # reemplazar la lista
        assert sorted(x["id"] for x in _leer(eid, "asientos")) == [1, 3]
        assert _cambios(tok["Administrador"], "asientos", deletes=[1]).status_code == 403                  # tampoco el administrador
        # reabierto el mes, se puede
        assert _put(t, "periodos_2026", [{**x, "estado": "Abierto"} for x in meses]).status_code == 200
        assert _cambios(t, "asientos", deletes=[1]).status_code == 200
    finally:
        _borrar(eid, correos.values())


# ----------------------------------------------------------------------------- interfaz
def test_menu_inventario_solo_para_quien_maneja_montos():
    js = (RAIZ / "static/js/menu.js").read_text(encoding="utf-8")
    assert "{ label: 'Inventario', ico: '▦', permisos: [" in js



# ============================================================================= revisión independiente (segunda vuelta)
# ----------------------------------------------------------------------------- asientos automáticos con un mes cerrado
def test_automaticos_van_al_primer_mes_abierto():
    """Un documento fechado en un mes cerrado (factura aceptada tarde, cobro con fecha atrasada) no puede trabar la sincronización:
    el servidor rechaza el lote completo (403) y no entraría ningún automático, tampoco los del mes abierto."""
    js = (RAIZ / "static/js/pages/contabilidad/automaticos.js").read_text(encoding="utf-8")
    assert "for (const f of fuentes) f.fecha = fechaAbierta(f.fecha);" in js
    assert "if (vistos.has(a.origen) && !a.ajustado && !periodoCerrado(a.fecha))" in js
    i, j = js.index("for (const f of fuentes) f.fecha = fechaAbierta(f.fecha);"), js.index("let asientos = asientosMock();")
    assert js.index("fuentesActivo(ac, param, nombres)") < i < j          # después de armar TODAS las fuentes y antes de compararlas


# ----------------------------------------------------------------------------- montos: quien configura y lo que no se ve
def test_quien_configura_sin_montos_conserva_las_tarifas(hotel):
    eid, tok = hotel
    _sembrar(eid, {"hotel_config": CONFIG})
    correo = "configura.reg387@example.test"
    with Session(engine) as s:
        s.add(auth.RolEmpresa(empresa_id=eid, nombre="Configura QA", permisos=json.dumps(["configurar"]))); s.commit()
        u = auth.Usuario(correo=correo, nombre="Configura QA", password_hash=auth.hash_password(PW), mfa_activo=True,
                         terminos_version=auth.TERMINOS_VERSION, terminos_fecha=datetime.now(timezone.utc), consiente_factura=True, paleta="turquesa")
        s.add(u); s.commit(); s.refresh(u)
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol="Configura QA")); s.commit()
        t = auth._respuesta(s, u, eid)["token"]
    try:
        cfg = c.get("/api/registros/hotel_config", headers=H(t)).json()["datos"]
        assert cfg["tarifas"] == CONFIG["tarifas"] and cfg["temporadas"] and cfg["cargos_auto"]   # quien configura el hotel ve sus tarifas
        regs = c.get("/api/arranque", headers=H(t)).json()["registros"]["datos"]
        assert regs["hotel_config"]["tarifas"] == CONFIG["tarifas"]
        assert _put(t, "hotel_config", {**cfg, "nombre": "Hotel 387 QA", "persona_extra": 20}).status_code == 200
        g = _leer(eid, "hotel_config")
        assert g["tarifas"] == CONFIG["tarifas"] and g["temporadas"] == CONFIG["temporadas"] and g["cargos_auto"] == CONFIG["cargos_auto"] and g["persona_extra"] == 20
    finally:
        with Session(engine) as s:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            for x in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                s.delete(x)
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == u.id)).all():
                s.delete(x)
            s.delete(u)
            for r in s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == eid, auth.RolEmpresa.nombre == "Configura QA")).all():
                s.delete(r)
            s.commit()


def test_quien_no_ve_los_montos_tampoco_los_cambia(hotel):
    """El historial que arma la pantalla sobre una copia sin historial ([nuevo]) no reemplaza el guardado, ni entra un total."""
    eid, tok = hotel
    _reservas_base(eid)
    r = _cambios(tok["Técnico"], "hotel_reservas", [{**{k: v for k, v in BLOQUEO_4.items() if k != "historial"}, "motivo": "Pintura",
                                                    "historial": [{"texto": "Cambiado por mantenimiento"}], "total": 5}])
    assert r.status_code == 200, r.text
    b = {x["id"]: x for x in _leer(eid, "hotel_reservas")}[4]
    assert b["historial"] == BLOQUEO_4["historial"] and "total" not in b
    nuevo = {"id": 30, "tipo": "bloqueo", "estado": "bloqueo", "habitacion_id": 1, "llegada": "2027-03-01", "salida": "2027-03-02", "historial": [{"texto": "Creado"}]}
    assert _cambios(tok["Técnico"], "hotel_reservas", [nuevo], nuevos=[30]).status_code == 200
    assert {x["id"]: x for x in _leer(eid, "hotel_reservas")}[30]["historial"] == [{"texto": "Creado"}]   # en un alta queda lo enviado


# ----------------------------------------------------------------------------- comercio:2 por pos_ventas
def test_cajero_no_cambia_ni_borra_las_ventas_de_un_cierre():
    correos = {"Administrador": "admin.ventas387@example.test", "Cajero": "cajero.ventas387@example.test", "Supervisor de caja": "super.ventas387@example.test"}
    eid, tok = _empresa("Comercio Ventas 387 QA", "comercio", ROLES_COMERCIO, correos, "04")
    try:
        t = tok["Cajero"]
        ses = {"id": 1, "caja": "Caja 1", "estado": "Abierta", "usuario": "cajero", "monto_inicial": 0, "fecha": "2026-11-05", "conteo": None, "diferencia": None}
        assert _cambios(t, "pos_cajas", [ses], nuevos=[1]).status_code == 200
        v1 = {"id": 1, "caja_id": 1, "doc_id": 501, "consecutivo": "T-0001", "total": 2017, "medios": [{"medio": "01", "monto": 2017}], "hora": "2026-11-05T10:00:00"}
        v2 = {"id": 2, "caja_id": 1, "doc_id": 502, "consecutivo": "T-0002", "total": 300, "medios": [{"medio": "01", "monto": 300}], "hora": "2026-11-05T11:00:00"}
        p3 = {"id": 3, "caja_id": 1, "doc_id": None, "consecutivo": "PENDIENTE AB12", "total": 150, "medios": [{"medio": "01", "monto": 150}], "pendiente_id": "ab12"}
        p4 = {"id": 4, "caja_id": 1, "doc_id": None, "consecutivo": "PENDIENTE CD34", "total": 80, "medios": [{"medio": "01", "monto": 80}], "pendiente_id": "cd34"}
        assert _cambios(t, "pos_ventas", [v1, v2, p3, p4], nuevos=[1, 2, 3, 4]).status_code == 200          # vende
        anulacion = {"anulada": True, "anulada_hora": "2026-11-05T12:00:00", "anulada_por": "cajero", "motivo_anulacion": "Devolución", "nc_id": 601, "nc_consecutivo": "NC-1"}
        assert _cambios(t, "pos_ventas", [{**v2, **anulacion}]).status_code == 200                           # anula en su caja abierta
        assert _cambios(t, "pos_ventas", deletes=[4]).status_code == 200                                     # descarta una pendiente
        assert _cambios(t, "pos_ventas", deletes=[1]).status_code == 403                                     # una venta emitida no se borra
        assert _cambios(t, "pos_ventas", [{**v1, "total": 0, "medios": [{"medio": "01", "monto": 0}]}]).status_code == 403   # ni se maquilla
        assert _cambios(t, "pos_cajas", [{**ses, "estado": "Cerrada", "cerrada_en": "2026-11-05T20:00:00", "conteo": 0, "diferencia": -2167}]).status_code == 200
        # cerrada la caja, sus ventas quedan como se cerraron
        assert _cambios(t, "pos_ventas", [{**v1, "total": 0, "medios": [{"medio": "01", "monto": 0}]}]).status_code == 403
        assert _cambios(t, "pos_ventas", [{**v1, **anulacion, "nc_id": None}]).status_code == 403            # anular después del cierre
        assert _cambios(t, "pos_ventas", [{**v2, **anulacion, "anulada": False}]).status_code == 403
        assert _cambios(t, "pos_ventas", deletes=[2]).status_code == 403
        assert _cambios(t, "pos_ventas", deletes=[3]).status_code == 403                                     # ni la pendiente de un cierre hecho
        assert _put(t, "pos_ventas", []).status_code == 403
        assert _put(t, "pos_ventas", [v1]).status_code == 403
        # la venta pendiente que se emite al volver la red sí se completa, aunque la caja ya cerró
        assert _cambios(t, "pos_ventas", [{**p3, "doc_id": 503, "consecutivo": "T-0003", "pendiente_id": None}]).status_code == 200
        assert _cambios(t, "pos_ventas", [{**v1, "doc_id": 999}]).status_code == 403                         # pero no se cambia el comprobante de otra
        guardadas = {x["id"]: x for x in _leer(eid, "pos_ventas")}
        assert set(guardadas) == {1, 2, 3} and guardadas[1]["total"] == 2017 and guardadas[2]["anulada"] is True and guardadas[3]["doc_id"] == 503
        # una venta nueva siempre entra (la que se hizo sin red llega después del cierre)
        assert _cambios(t, "pos_ventas", [{**v1, "id": 5, "consecutivo": "T-0005", "doc_id": 505}], nuevos=[5]).status_code == 200
        # el supervisor sí corrige
        assert _cambios(tok["Supervisor de caja"], "pos_ventas", [{**v1, "total": 2000}]).status_code == 200
        assert _cambios(tok["Supervisor de caja"], "pos_ventas", deletes=[5]).status_code == 200
    finally:
        _borrar(eid, correos.values())


# ----------------------------------------------------------------------------- hospitalidad:3: montos de un cargo de caja
def test_cargo_de_caja_no_rebaja_la_cuenta(hotel):
    eid, tok = hotel
    _reservas_base(eid)
    _sembrar(eid, {"hotel_folios": FOLIOS})
    t = tok["Cajero"]
    cargo = {"id": 40, "reserva_id": 1, "tipo": "cargo", "origen": "pos", "detalle": "Cena", "cantidad": 1, "precio": 100, "tarifa": 13, "codigo_tarifa": "08",
             "moneda": "USD", "monto_crc": 56500, "otro_impuesto": None}
    for malo in ({"tarifa": -250}, {"tarifa": 300}, {"monto_crc": -1}, {"otro_impuesto": {"codigo": "02", "tarifa": -90}}, {"cantidad": "x"}):
        assert _cambios(t, "hotel_folios", [{**cargo, **malo}], nuevos=[40]).status_code == 403, malo
    assert _cambios(t, "hotel_folios", [cargo], nuevos=[40]).status_code == 200
    assert _cambios(t, "hotel_folios", [{**cargo, "id": 41, "otro_impuesto": {"codigo": "02", "tarifa": 10}}], nuevos=[41]).status_code == 200
    assert {f["id"] for f in _leer(eid, "hotel_folios")} == {1, 2, 40, 41}


# ----------------------------------------------------------------------------- hospitalidad:2: tipos de problema por /cambios
def test_tipos_de_problema_no_se_vacian_por_cambios(hotel):
    eid, tok = hotel
    tipos = [{"id": 1, "nombre": "Toallas", "modulo": "limpieza", "activo": True}, {"id": 2, "nombre": "Baño sucio", "modulo": "limpieza", "activo": True},
             {"id": 3, "nombre": "Fuga", "modulo": "mantenimiento", "activo": True}]
    _sembrar(eid, {"hotel_tipos_problema": tipos})
    t = tok["Camarera"]
    assert _cambios(t, "hotel_tipos_problema", deletes=[3]).status_code == 403                               # el de mantenimiento no es suyo
    assert _cambios(t, "hotel_tipos_problema", [{**tipos[2], "activo": False}]).status_code == 403
    assert _cambios(t, "hotel_tipos_problema", [{**tipos[0], "modulo": "mantenimiento"}]).status_code == 403
    assert _cambios(t, "hotel_tipos_problema", [{**tipos[0], "nombre": "Toallas o sábanas"}]).status_code == 200   # renombra el suyo
    assert _cambios(t, "hotel_tipos_problema", deletes=[2]).status_code == 200                               # y quita el suyo
    _sembrar(eid, {"hotel_tipos_problema": tipos[:2]})
    assert _cambios(t, "hotel_tipos_problema", deletes=[1, 2]).status_code == 403                            # sin vaciar la lista
    assert len(_leer(eid, "hotel_tipos_problema")) == 2
    assert _cambios(tok["Técnico"], "hotel_tipos_problema", [{"id": 9, "nombre": "Wifi", "modulo": "mantenimiento", "activo": True}], nuevos=[9]).status_code == 200
    assert _cambios(tok["Recepcionista"], "hotel_tipos_problema", deletes=[1, 2, 9]).status_code == 200      # quien escribe, todo


# ----------------------------------------------------------------------------- hospitalidad:4: documentos de venta
def test_roles_operativos_no_leen_documentos_de_venta(hotel):
    eid, tok = hotel
    _sembrar(eid, {"cotizaciones": [{"id": 1, "numero": "COT-0001", "cliente": "Cliente QA", "total": 123456}],
                   "remisiones": [{"id": 1, "numero": "REM-0001", "total": 50}]})
    for rol in ("Camarera", "Técnico", "Seguridad"):
        for clave in ("cotizaciones", "remisiones", "notas-credito", "notas-debito"):
            assert c.get(f"/api/registros/{clave}", headers=H(tok[rol])).status_code == 403, (rol, clave)
        regs = c.get("/api/arranque", headers=H(tok[rol])).json()["registros"]["datos"]
        assert "cotizaciones" not in regs and "remisiones" not in regs, rol
    assert c.get("/api/registros/cotizaciones", headers=H(tok["Recepcionista"])).json()["datos"][0]["total"] == 123456


# ----------------------------------------------------------------------------- extras:7: borrar la clave completa
def test_borrar_asientos_respeta_el_periodo_cerrado():
    correos = {"Administrador": "admin.borrar387@example.test"}
    eid, tok = _empresa("Contable Borrar 387 QA", "facturacion", {}, correos, "05")
    try:
        t = tok["Administrador"]
        lineas = [{"cuenta": "1.1.01", "debito": 100, "credito": 0}, {"cuenta": "4.1.01", "debito": 0, "credito": 100}]
        assert _cambios(t, "asientos", [{"id": 1, "codigo": "AS-1", "fecha": "2026-10-10", "tipo": "Diario", "lineas": lineas}], nuevos=[1]).status_code == 200
        meses = [{"n": i, "mes": m, "estado": "Cerrado" if i == 10 else "Abierto"} for i, m in enumerate(
            ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"], start=1)]
        assert _put(t, "periodos_2026", meses).status_code == 200
        r = c.delete("/api/registros/asientos", headers=H(t))
        assert r.status_code == 403 and "Octubre 2026" in r.json()["detail"]
        assert [x["id"] for x in _leer(eid, "asientos")] == [1]
        assert c.delete("/api/registros/periodos_2026", headers=H(t)).status_code == 200
        with Session(engine) as s:
            aud = s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid, auth.Auditoria.accion == "registro_borrado")).all()
        assert any("periodos_2026" in a.detalle for a in aud)
        assert c.delete("/api/registros/asientos", headers=H(t)).status_code == 200                         # sin periodos cerrados, sí
        assert _leer(eid, "asientos") is None
    finally:
        _borrar(eid, correos.values())


# ----------------------------------------------------------------------------- PUT de una lista vacía que la pestaña no tenía
def test_lista_vacia_sin_version_da_conflicto_y_no_403(hotel):
    """El navegador sube [] con versión 0 cuando no tenía la clave: si ya existe, el servidor responde 409 con lo guardado (no se
    pisa nada) y la pantalla sigue; un 403 la hacía mostrar un error y descartar su copia."""
    eid, tok = hotel
    _sembrar(eid, {"hotel_habitaciones": HABS})
    r = c.put("/api/registros/hotel_habitaciones", headers=H(tok["Camarera"]), json={"datos": [], "version": 0})
    assert r.status_code == 409 and len(r.json()["detail"]["datos"]) == 3
    assert len(_leer(eid, "hotel_habitaciones")) == 3
