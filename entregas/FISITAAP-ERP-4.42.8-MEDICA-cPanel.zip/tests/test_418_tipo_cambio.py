# -*- coding: utf-8 -*-
"""4.18: registro propio del dólar del BCCR, tipo de cambio del día del documento, y columna, totales y pie en colones en los reportes."""
import io
import pathlib
from types import SimpleNamespace

from openpyxl import load_workbook
from sqlmodel import Session

from app import reportes, resumen, tipo_cambio as T
from app.db import Empresa, engine
from test_49_local_sinc import H, _admin_empresa, c

JS = pathlib.Path(__file__).resolve().parents[1] / "app" / "static" / "js" / "pages"


def test_semilla_del_bccr_y_consulta_por_dia():
    T._sembrado = False; T._memoria["t"] = -1e9
    assert T.dia("2026-10-01") == {"fecha": "2026-10-01", "compra": 454.78, "venta": 460.73, "exacto": True}
    assert T.venta_en("2026-10-21") == 457.54 and T.venta_en("2026-11-09") == 452.13 and T.venta_en("2026-09-30") is None
    assert len([f for f in T.mapa() if "2026-10-01" <= f <= "2026-11-09"]) == 40


def test_si_falta_un_dia_usa_el_ultimo_anterior_cercano():
    T.guardar_dia("2031-01-10", 500, 510, "QA")
    d = T.dia("2031-01-12")
    assert d["fecha"] == "2031-01-10" and d["exacto"] is False and d["venta"] == 510
    assert T.dia("2031-01-30") is None                                          # demasiado lejos: no inventa


def test_el_registro_guarda_por_anio_y_lo_nuevo_no_duplica():
    T.guardar_dia("2030-03-01", 480, 490, "QA"); T.guardar_dia("2030-03-01", 481, 491, "QA")
    h = T.historico(2030)
    assert h["anio"] == 2030 and 2026 in h["anios"] and 2030 in h["anios"]
    assert [(f["fecha"], f["compra"], f["venta"]) for f in h["filas"]] == [("2030-03-01", 481, 491)]
    with Session(engine) as s:
        x = s.get(T.TipoCambioDia, "2030-03-01"); s.delete(x); s.commit()
    T._memoria["t"] = -1e9


def test_api_del_historico():
    _, t = _admin_empresa("-tc1", "3101418001")
    r = c.get("/api/tipo-cambio/historico?anio=2026", headers=H(t)).json()
    assert r["anio"] == 2026 and r["filas"][-1]["fecha"] == "2026-10-01" and r["filas"][-1]["venta"] == 460.73
    assert c.get("/api/tipo-cambio/dia?fecha=2026-10-21", headers=H(t)).json()["venta"] == 457.54
    assert c.get("/api/tipo-cambio/mapa", headers=H(t)).json()["2026-10-21"] == 457.54
    assert c.get("/api/tipo-cambio/dia?fecha=malo", headers=H(t)).json() == {}


def test_obtener_anota_el_dia(monkeypatch):
    r = SimpleNamespace(raise_for_status=lambda: None, json=lambda: {"venta": {"fecha": "2032-02-02", "valor": 500.5}, "compra": {"fecha": "2032-02-02", "valor": 490.5}})
    monkeypatch.setattr(T.httpx, "get", lambda *a, **k: r)
    T.obtener(forzar=True)
    assert T.venta_en("2032-02-02") == 500.5
    with Session(engine) as s:
        s.delete(s.get(T.TipoCambioDia, "2032-02-02")); s.commit()
    T.ARCHIVO.unlink(missing_ok=True); T._memoria["t"] = -1e9


def test_completar_llena_huecos_y_tolera_el_servicio_caido(monkeypatch):
    monkeypatch.setattr(T, "obtener", lambda *a, **k: {})
    monkeypatch.setattr(T, "INICIO", "2033-05-01")
    monkeypatch.setattr(T, "ahora_cr", lambda: SimpleNamespace(date=lambda: __import__("datetime").date(2033, 5, 2)))
    T._ultimo_historico[0] = -1e9

    def caido(*a, **k):
        raise T.httpx.ConnectError("503")
    monkeypatch.setattr(T.httpx, "get", caido)
    assert T.completar() == 0
    T._ultimo_historico[0] = -1e9
    r = SimpleNamespace(raise_for_status=lambda: None, json=lambda: [{"fecha": "2033-05-01 00:00:00", "compra": 470, "venta": 480}, {"fecha": "raro"}, {"fecha": "2033-05-02 00:00:00", "compra": 471, "venta": 481}])
    monkeypatch.setattr(T.httpx, "get", lambda *a, **k: r)
    assert T.completar() == 2 and T.venta_en("2033-05-02") == 481
    with Session(engine) as s:
        for f in ("2033-05-01", "2033-05-02"):
            s.delete(s.get(T.TipoCambioDia, f))
        s.commit()
    T._memoria["t"] = -1e9


def test_cada_documento_usa_su_tipo_de_cambio_y_si_no_el_de_su_dia():
    con = {"moneda": "USD", "tipo_cambio": 500, "fecha_emision": "2026-10-21"}
    sin = {"moneda": "USD", "tipo_cambio": 1, "fecha_emision": "2026-10-21T10:00:00-06:00"}
    manual = {"moneda": "USD", "creacion": "2026-10-02"}
    crc = {"moneda": "CRC", "tipo_cambio": 1, "fecha_emision": "2026-10-21"}
    assert resumen.tc_doc(con) == 500 and resumen.tc_doc(sin) == 457.54 and resumen.tc_doc(manual) == 462.29 and resumen.tc_doc(crc) == 1
    assert resumen._a_crc("USD", 100, resumen.tc_doc(sin), 400) == 45754


def test_montos_separa_lo_hecho_en_dolares_en_colones():
    m = resumen.Montos(450).sumar("USD", 10, 500).sumar("CRC", 1000).sumar("USD", 10, 460)
    assert m.usd_crc == 9600 and m.dict() == {"CRC": 10600.0, "USD": round(20 + 1000 / 450, 2), "nativo": {"USD": 20.0, "CRC": 1000.0}, "USD_CRC": 9600.0}
    assert resumen.Montos(450).sumar("CRC", 1000).dict().get("USD_CRC") is None
    assert m.menos(resumen.Montos(450).sumar("USD", 1, 500)).usd_crc == 9100


def _d(**k):
    return reportes.ExcelIn(titulo="Compras", columnas=[{"key": "a", "label": "A", "num": True}], filas=[{"a": 1}], **k)


def test_pie_con_la_venta_en_negrita_en_excel():
    wb = load_workbook(io.BytesIO(reportes._xlsx(_d(tipo_cambio={"fecha": "2026-11-09", "compra": 446.56, "venta": 452.13}), SimpleNamespace(nombre="QA", nombre_comercial=None))))
    ws = wb.active
    filas = {str(ws.cell(row=i, column=1).value): i for i in range(1, ws.max_row + 1)}
    v = filas["Venta (la que se usa)"]
    assert ws.cell(row=v, column=2).value == 452.13 and ws.cell(row=v, column=2).font.bold and ws.cell(row=v, column=1).font.bold
    assert ws.cell(row=filas["Compra"], column=2).value == 446.56 and not ws.cell(row=filas["Compra"], column=2).font.bold
    assert any("Banco Central de Costa Rica al 09/11/2026" in k for k in filas)


def test_pie_en_pdf_y_word_con_la_venta_en_negrita():
    a, b, _c = reportes._pie_tc(reportes.TipoCambioPie(fecha="2026-11-09", compra=446.56, venta=452.13))
    assert "al 09/11/2026: compra ₡446,56" in a and b == "venta ₡452,13"
    t = pathlib.Path(reportes.__file__).read_text(encoding="utf-8")
    assert '"<b>" + _esc(b.replace(' + chr(34) + '₡' + chr(34) + ', ' + chr(34) + '¢' + chr(34) + ')) + "</b>"' in t and '_run(b, True, 8, "111111")' in t
    d = reportes.ReporteIn(titulo="QA", columnas=[{"key": "a", "label": "A"}], filas=[{"a": "1"}], tipo_cambio={"fecha": "2026-11-09", "compra": 446.56, "venta": 452.13})
    eid, _ = _admin_empresa("-tc2", "3101418002")
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
        assert reportes._pdf(d, e, None)[:4] == b"%PDF" and reportes._docx(d, e, None)[:2] == b"PK"


def test_la_pantalla_trae_columna_totales_pie_e_historico():
    r = (JS / "reportes" / "reporte.js").read_text(encoding="utf-8")
    assert "function agregarColones(r, p, sombra, bases)" in r and "<b>venta {{money(tcMostrar.venta, 'CRC')}}</b>" in r
    s = (JS / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    assert "Histórico del dólar" in s and "exportarTabla('tipo_cambio_dolar_'" in s
    assert "@change=\"tcDelDia\"" in (JS / "gastos" / "compra-form.js").read_text(encoding="utf-8")


def test_los_reportes_que_faltaban_llevan_colones():
    r = (JS / "reportes" / "reporte.js").read_text(encoding="utf-8")
    assert "const CON_SOMBRA = new Set([...ASIENTOS_MON, 'ingresos-gastos', 'reporte-anual', 'flujo-caja'" in r
    for k in ("'libro-diario': ['debito', 'credito']", "'ingresos-gastos': ['ingresos', 'gastos', 'neto']", "'estado-cuenta-cliente': ['cargo', 'abono']", "'retenciones': ['monto']"):
        assert k in r
    assert "this.res = agregarColones(r, this.p, sombra, COL_BASE[this.slug])" in r and "colColones('saldo_c', 'Saldo en colones')" in r
    assert "if (MODO.sombra) {" in r and "m.USD_CRC" in r
