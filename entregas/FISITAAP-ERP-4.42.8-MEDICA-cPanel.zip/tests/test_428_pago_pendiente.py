"""4.28: día fijo de vencimiento del plan, días de gracia (el sistema funciona completo) y aviso de pago pendiente.

P-1 sin configurar nada todo queda como antes; P-2 configuración general (solo el administrador del sistema) y propia de cada empresa;
P-3 planes.estado_pago decide; P-4 planes.siguiente_vencimiento corre la fecha en todos los caminos de pago; P-5 franja de pago
pendiente; P-6 consola; P-7 programa de escritorio; P-9 correos."""
import json
import pathlib
import subprocess
import types
from datetime import date, datetime, timedelta, timezone

import pytest
from sqlalchemy import create_engine, text
from sqlmodel import Session, select

from app import auth, planes, sinc, sistema, suscripcion
from app.config import TZ_CR, ahora_cr
from app.db import Empresa, _agregar_columnas_faltantes, engine, engine_empresa
from app.main import app
from tests.test_sinc import H, _admin_empresa, c

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _e(**kw):
    base = {"id": None, "plan": "fac_emprendedor", "vence": None, "prueba_hasta": None, "es_demo": False, "plan_dia_vence": None, "plan_dias_gracia": None}
    base.update(kw)
    return types.SimpleNamespace(**base)


@pytest.fixture()
def general(monkeypatch, tmp_path):
    """Configuración general en un sistema.json de la prueba (sin tocar la de la instalación)."""
    monkeypatch.setattr(sistema, "ARCHIVO", tmp_path / "sistema.json")
    sistema._cache_cobro.clear()
    yield lambda dia, gracia: sistema.guardar_cobro_plan(dia, gracia)
    sistema._cache_cobro.clear()


def _superadmin():
    app.dependency_overrides[auth.superadmin] = lambda: types.SimpleNamespace(id=None, correo="admin-428@example.test", es_superadmin=True, nombre="Admin")


# ------------------------------------------------------------------------------------------------ funciones puras
def test_estado_dia_1_y_15_de_gracia(general):
    general(1, 15)
    e = _e(vence="2026-12-01")
    assert planes.dias_gracia(e) == 15 and planes.gracia_hasta(e) == "2026-12-16"
    assert planes.estado_pago(e, "2026-11-20") == "al_dia"
    assert planes.estado_pago(e, "2026-11-28") == "por_vencer"
    assert planes.estado_pago(e, "2026-12-01") == "por_vencer"          # el 1: al día (todavía no vence)
    for d in range(2, 17):                                              # del 2 al 16: en gracia y funcionando
        assert planes.estado_pago(e, f"2026-12-{d:02d}") == "en_gracia", d
    assert planes.estado_pago(e, "2026-12-17") == "vencido"              # el 17: solo lectura
    assert planes.aviso_pago(e, "en_gracia") == ("Tiene un pago pendiente de su plan: venció el 01/12/2026. Puede seguir trabajando hasta el "
                                                 "16/12/2026; después el sistema queda solo para consultar.")
    assert planes.aviso_pago(e, "vencido") is None and planes.aviso_pago(e, "al_dia") is None


def test_sin_configurar_nada_es_como_antes(general):
    e = _e(vence="2026-12-01")
    assert sistema.cobro_plan() == {"dia_vence": None, "dias_gracia": 0}
    assert planes.dias_gracia(e) == 0 and planes.dia_fijo(e) is None and planes.gracia_hasta(e) == "2026-12-01"
    assert planes.estado_pago(e, "2026-12-01") == "por_vencer" and planes.estado_pago(e, "2026-12-02") == "vencido"
    for va, hoy in (("2026-11-20", "2026-11-18"), ("2026-11-01", "2026-11-10"), ("2026-08-01", "2026-11-20"), (None, "2026-11-12"), ("2027-01-31", "2027-01-15")):
        esperado = planes.sumar_meses(max(hoy, va) if va else hoy, 1)
        assert planes.siguiente_vencimiento(va, 1, hoy, None, 0) == esperado
    assert planes.siguiente_vencimiento("2026-11-01", 3, "2026-11-10") == "2027-02-10"   # como siempre: desde hoy si ya venció


def test_ejemplos_de_la_regla_p4():
    sv = planes.siguiente_vencimiento
    assert sv("2026-11-01", 1, "2026-10-28", 1, 15) == "2026-12-01"
    assert sv("2026-11-01", 1, "2026-11-10", 1, 15) == "2026-12-01"     # en gracia: la fecha no se corre cada mes
    assert sv("2026-11-01", 1, "2026-11-20", 1, 15) == "2026-12-01"     # ya vencido
    assert sv("2026-08-01", 1, "2026-11-20", 1, 15) == "2027-01-01"     # atrasado más de un periodo: desde hoy, al día fijo
    assert sv("2026-11-20", 1, "2026-11-18", 1, 15) == "2027-01-01"     # se alinea una sola vez, sin quitarle días
    assert sv("2026-11-01", 12, "2026-11-05", 1, 15) == "2027-11-01"    # anual
    assert sv(None, 1, "2026-11-12", 1, 15) == "2027-01-01"             # sin vencimiento anterior: desde hoy (12 dic → 1 ene)
    # sin día fijo pero con gracia: la gracia es crédito (se cuenta desde el vencimiento anterior)
    assert sv("2026-11-01", 1, "2026-11-10", None, 15) == "2026-12-01"
    assert sv("2026-11-01", 1, "2026-12-05", None, 15) == "2027-01-05"  # atrasado más de un periodo
    # con día fijo y 0 de gracia también corre la regla b
    assert sv("2026-11-01", 1, "2026-11-03", 1, 0) == "2026-12-01"


def test_fin_de_mes_y_febrero(general):
    sv = planes.siguiente_vencimiento
    assert planes.al_dia_fijo("2027-02-15", 28) == "2027-02-28" and planes.al_dia_fijo("2027-02-28", 1) == "2027-03-01"
    assert planes.al_dia_fijo("2026-12-20", 1) == "2027-01-01"
    assert sv("2027-01-31", 1, "2027-01-20", None, 5) == "2027-02-28"   # el 31 no existe en febrero: el último del mes
    assert sv("2027-01-31", 1, "2027-01-20", 1, 5) == "2027-03-01"      # al día fijo igual o posterior
    assert sv("2028-01-31", 1, "2028-01-20", None, 5) == "2028-02-29"   # bisiesto
    assert sv("2028-01-28", 1, "2028-01-20", 28, 5) == "2028-02-28"     # el 28 existe siempre
    assert sv("2028-01-31", 1, "2028-01-20", 28, 5) == "2028-03-28"     # 29 feb corrido al 28 siguiente: nunca antes (no se quitan días)
    general(None, 15)
    e = _e(vence="2027-02-20")
    assert planes.gracia_hasta(e) == "2027-03-07"
    assert planes.gracia_hasta(_e(vence="2028-02-20")) == "2028-03-06"
    assert planes.estado_pago(e, "2027-03-07") == "en_gracia" and planes.estado_pago(e, "2027-03-08") == "vencido"


def test_lo_de_la_empresa_manda_sobre_lo_general(general):
    general(1, 15)
    assert planes.dia_fijo(_e()) == 1 and planes.dias_gracia(_e()) == 15
    assert planes.dias_gracia(_e(plan_dias_gracia=0)) == 0 and planes.dias_gracia(_e(plan_dias_gracia=30)) == 30
    assert planes.dia_fijo(_e(plan_dia_vence=0)) is None and planes.dia_fijo(_e(plan_dia_vence=10)) == 10
    e = _e(vence="2026-12-01", plan_dias_gracia=0)
    assert planes.estado_pago(e, "2026-12-02") == "vencido"
    general(None, 0)
    assert planes.dias_gracia(_e(plan_dias_gracia=5)) == 5 and planes.dia_fijo(_e(plan_dia_vence=15)) == 15
    assert planes.dias_gracia(_e(plan_dias_gracia=999)) == 60            # tope


def test_prueba_gratis_y_demo_sin_gracia(general):
    general(1, 15)
    hoy = ahora_cr().date()
    prueba = _e(vence=(hoy - timedelta(days=3)).isoformat(), prueba_hasta=(hoy + timedelta(days=5)).isoformat())
    assert planes.dias_gracia(prueba) == 0 and planes.estado_pago(prueba) == "al_dia"   # en prueba: todo encendido, como hoy
    terminada = _e(vence=(hoy - timedelta(days=3)).isoformat(), prueba_hasta=(hoy - timedelta(days=1)).isoformat())
    assert planes.dias_gracia(terminada) == 0 and planes.estado_pago(terminada) == "vencido"
    assert planes.estado_pago(_e(vence="2020-01-01", es_demo=True)) == "al_dia"
    assert planes.estado_pago(_e(plan=None, vence="2020-01-01")) == "al_dia"


def test_fecha_de_costa_rica_cerca_de_la_medianoche(general, monkeypatch):
    general(None, 2)
    e = _e(vence="2026-12-01")                                          # gracia hasta el 3 de diciembre
    # 3 dic 23:30 en Costa Rica = 4 dic 05:30 UTC: sigue en gracia (la fecha que manda es la de Costa Rica)
    monkeypatch.setattr(planes, "ahora_cr", lambda: datetime(2026, 12, 4, 5, 30, tzinfo=timezone.utc).astimezone(TZ_CR))
    assert planes._hoy() == "2026-12-03" and planes.estado_pago(e) == "en_gracia"
    monkeypatch.setattr(planes, "ahora_cr", lambda: datetime(2026, 12, 4, 6, 0, 1, tzinfo=timezone.utc).astimezone(TZ_CR))
    assert planes._hoy() == "2026-12-04" and planes.estado_pago(e) == "vencido"


def test_columnas_nuevas_en_una_base_de_antes(tmp_path, general):
    """Una base creada por una versión anterior (sin las columnas) abre sin error y con los valores por omisión."""
    eng = create_engine(f"sqlite:///{tmp_path / 'vieja.db'}")
    nuevas = ("plan_dia_vence", "plan_dias_gracia")
    cols = ", ".join(f"{x.name} {x.type.compile(eng.dialect)}" + (" PRIMARY KEY" if x.primary_key else "") for x in Empresa.__table__.columns if x.name not in nuevas)
    with eng.begin() as x:
        x.execute(text(f"CREATE TABLE empresa ({cols})"))
        x.execute(text("INSERT INTO empresa (id, nombre, plan, vence) VALUES (1, 'Vieja', 'fac_emprendedor', '2026-12-01')"))
    _agregar_columnas_faltantes(eng, [Empresa.__table__])
    with eng.connect() as x:
        fila = x.execute(text("SELECT nombre, plan_dia_vence, plan_dias_gracia FROM empresa WHERE id = 1")).one()
    assert tuple(fila) == ("Vieja", None, None)
    e = _e(vence="2026-12-01", plan_dia_vence=fila[1], plan_dias_gracia=fila[2])
    assert planes.dias_gracia(e) == 0 and planes.estado_pago(e, "2026-12-02") == "vencido"     # como antes
    eng.dispose()


# ------------------------------------------------------------------------------------------------ servidor
def test_en_gracia_se_escribe_y_vencido_da_403(general):
    eid, t = _admin_empresa("-428g")
    _superadmin()
    try:
        hoy = ahora_cr().date()
        base = {"plan": "fac_emprendedor", "extras": [], "docs_extra": 0, "habitaciones": 0, "cajas": 0, "limite_usuarios": 0}
        # sin configurar nada: vencido ayer = solo lectura, como hoy
        r = c.post(f"/api/admin/cuentas/{eid}/plan", json={**base, "vence": (hoy - timedelta(days=1)).isoformat()})
        assert r.status_code == 200, r.text
        assert r.json()["plan"]["estado_pago"] == "vencido" and r.json()["plan"]["dias_gracia"] == 0
        r = c.post("/api/clientes", headers=H(t), json={"nombre": "Cliente 428", "tipo_id": "01", "numero_id": "101230428"})
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "plan_vencido", r.text
        # 15 días de gracia propios: funciona completo
        r = c.post(f"/api/admin/cuentas/{eid}/plan", json={**base, "vence": (hoy - timedelta(days=3)).isoformat(), "plan_dias_gracia": 15})
        p = r.json()["plan"]
        assert p["estado_pago"] == "en_gracia" and p["vencido"] is False and p["gracia_hasta"] == (hoy + timedelta(days=12)).isoformat() and p["plan_dias_gracia"] == 15
        r = c.post("/api/clientes", headers=H(t), json={"nombre": "Cliente 428", "tipo_id": "01", "numero_id": "101230428"})
        assert r.status_code != 403, r.text
        # una consola anterior que no manda los campos nuevos no borra lo guardado
        assert c.post(f"/api/admin/cuentas/{eid}/plan", json={**base, "vence": (hoy - timedelta(days=3)).isoformat()}).json()["plan"]["plan_dias_gracia"] == 15
        # pasada la gracia: 403 plan_vencido
        p = c.post(f"/api/admin/cuentas/{eid}/plan", json={**base, "vence": (hoy - timedelta(days=3)).isoformat(), "plan_dias_gracia": 2}).json()["plan"]
        assert p["estado_pago"] == "vencido" and p["vencido"] is True
        r = c.post("/api/clientes", headers=H(t), json={"nombre": "Otro 428", "tipo_id": "01", "numero_id": "101230429"})
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "plan_vencido", r.text
        # lo general también cuenta (vacío en la empresa = el general)
        general(None, 10)
        p = c.post(f"/api/admin/cuentas/{eid}/plan", json={**base, "vence": (hoy - timedelta(days=3)).isoformat(), "plan_dias_gracia": None}).json()["plan"]
        assert p["estado_pago"] == "en_gracia" and p["dias_gracia"] == 10 and p["plan_dias_gracia"] is None
        assert c.post(f"/api/admin/cuentas/{eid}/plan", json={**base, "plan_dias_gracia": 61}).status_code == 400
        assert c.post(f"/api/admin/cuentas/{eid}/plan", json={**base, "plan_dia_vence": 29}).status_code == 400
        with Session(engine) as s:
            aud = s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid, auth.Auditoria.accion == "plan_asignado")).all()
            assert any("días de gracia 15" in (a.detalle or "") for a in aud)
    finally:
        app.dependency_overrides.clear()


def test_bloque_plan_de_la_sesion(general):
    eid, t = _admin_empresa("-428s")
    _superadmin()
    try:
        hoy = ahora_cr().date()
        vence = (hoy - timedelta(days=2)).isoformat()
        c.post(f"/api/admin/cuentas/{eid}/plan", json={"plan": "fac_emprendedor", "extras": [], "vence": vence, "plan_dias_gracia": 5})
        hasta = (hoy + timedelta(days=3)).isoformat()
        p = c.get("/api/plan", headers=H(t)).json()
        for k in ("estado_pago", "vence", "gracia_hasta", "dias_gracia", "aviso_pago", "pago_en_linea"):
            assert k in p, k
        assert p["estado_pago"] == "en_gracia" and p["vence"] == vence and p["gracia_hasta"] == hasta and p["dias_gracia"] == 5
        assert p["aviso_pago"] == (f"Tiene un pago pendiente de su plan: venció el {planes.fecha_cr(vence)}. Puede seguir trabajando hasta el "
                                   f"{planes.fecha_cr(hasta)}; después el sistema queda solo para consultar.")
        yo = c.get("/api/auth/yo", headers=H(t)).json()
        emp = next(x for x in yo["empresas"] if x["id"] == eid)
        assert emp["plan"]["estado_pago"] == "en_gracia" and emp["plan"]["gracia_hasta"] == hasta
        cuenta = next(x for x in c.get("/api/admin/cuentas").json() if x["id"] == eid)        # la consola recibe lo mismo
        assert cuenta["plan"]["estado_pago"] == "en_gracia" and cuenta["plan"]["plan_dias_gracia"] == 5
    finally:
        app.dependency_overrides.clear()


def test_solo_el_administrador_del_sistema_cambia_la_configuracion(general):
    eid, t = _admin_empresa("-428p")
    app.dependency_overrides.clear()
    assert c.put("/api/admin/cobro-plan", headers=H(t), json={"dia_vence": 1, "dias_gracia": 15}).status_code in (401, 403)
    assert c.get("/api/admin/cobro-plan", headers=H(t)).status_code in (401, 403)
    assert c.post(f"/api/admin/cuentas/{eid}/plan", headers=H(t), json={"plan": "fac_emprendedor", "plan_dias_gracia": 60}).status_code in (401, 403)
    assert sistema.cobro_plan() == {"dia_vence": None, "dias_gracia": 0}
    _superadmin()
    try:
        assert c.put("/api/admin/cobro-plan", json={"dia_vence": 29, "dias_gracia": 0}).status_code == 400
        assert c.put("/api/admin/cobro-plan", json={"dia_vence": 1, "dias_gracia": 61}).status_code == 400
        r = c.put("/api/admin/cobro-plan", json={"dia_vence": 1, "dias_gracia": 15})
        assert r.status_code == 200 and r.json() == {"dia_vence": 1, "dias_gracia": 15}
        assert c.get("/api/admin/cobro-plan").json() == {"dia_vence": 1, "dias_gracia": 15}
        assert json.loads(sistema.ARCHIVO.read_text(encoding="utf-8"))["cobro_plan"] == {"dia_vence": 1, "dias_gracia": 15}
        with Session(engine) as s:
            a = s.exec(select(auth.Auditoria).where(auth.Auditoria.accion == "cobro_plan_configurado").order_by(auth.Auditoria.id.desc())).first()
            assert a and "días de gracia 0 → 15" in a.detalle and "sin día fijo → 1" in a.detalle
        # el nombre del sistema se guarda sin borrar el vencimiento (viven en el mismo archivo)
        assert c.put("/api/admin/sistema", json={"nombre": "FISITAAP by Brillante Agencia"}).status_code == 200
        assert sistema.cobro_plan() == {"dia_vence": 1, "dias_gracia": 15}
        # fijar el día no cambia la fecha de ninguna empresa
        with Session(engine) as s:
            e = s.get(Empresa, eid); e.plan = "fac_emprendedor"; e.vence = "2030-01-20"; s.add(e); s.commit()
        c.put("/api/admin/cobro-plan", json={"dia_vence": 5, "dias_gracia": 3})
        with Session(engine) as s:
            assert s.get(Empresa, eid).vence == "2030-01-20"
    finally:
        app.dependency_overrides.clear()


def _fijar_hoy(monkeypatch, iso: str) -> None:
    """C5: fija «hoy» en Costa Rica (planes._hoy lee planes.ahora_cr; mediodía, lejos de la medianoche)."""
    d = date.fromisoformat(iso)
    monkeypatch.setattr(planes, "ahora_cr", lambda: datetime(d.year, d.month, d.day, 12, 0, tzinfo=TZ_CR))
    assert planes._hoy() == iso


def test_pago_manual_corre_al_dia_fijo_sin_regalar_ni_perder_dias(general, monkeypatch):
    """C5: con «hoy» fijo y fechas escritas a mano (los ejemplos del encargo, día 1 y 15 de gracia, pago de 1 mes)."""
    eid, t = _admin_empresa("-428m")
    _superadmin()
    try:
        general(1, 15)
        for vence, hoy, esperado in (("2026-11-01", "2026-11-10", "2026-12-01"),    # paga en gracia: la fecha no se corre cada mes
                                     ("2026-11-20", "2026-11-18", "2027-01-01"),    # se alinea una sola vez, sin quitarle días
                                     ("2026-08-01", "2026-11-20", "2027-01-01")):   # atrasado más de un periodo: desde hoy
            _fijar_hoy(monkeypatch, hoy)
            c.post(f"/api/admin/cuentas/{eid}/plan", json={"plan": "fac_emprendedor", "extras": [], "vence": vence})
            r = c.post(f"/api/admin/cuentas/{eid}/pagos", json={"monto": 5537, "meses": 1, "medio": "SINPE"})
            assert r.status_code == 200, r.text
            assert r.json()["pago"]["vence_anterior"] == vence and r.json()["pago"]["vence_nuevo"] == esperado, (vence, hoy, r.json()["pago"])
            assert r.json()["cuenta"]["plan"]["estado_pago"] == "al_dia", (vence, hoy)
        # sin nada configurado: como siempre (desde hoy, porque ya venció; desde el vencimiento si todavía no)
        general(None, 0)
        for vence, hoy, esperado in (("2026-11-05", "2026-11-10", "2026-12-10"), ("2026-11-20", "2026-11-18", "2026-12-20")):
            _fijar_hoy(monkeypatch, hoy)
            c.post(f"/api/admin/cuentas/{eid}/plan", json={"plan": "fac_emprendedor", "extras": [], "vence": vence})
            assert c.post(f"/api/admin/cuentas/{eid}/pagos", json={"monto": 5537, "meses": 1}).json()["pago"]["vence_nuevo"] == esperado, (vence, hoy)
    finally:
        app.dependency_overrides.clear()


def _empresa_central(**kw):
    with Session(engine) as s:
        e = Empresa(nombre="Pagos 428 S.A.", numero_id="3101428428", actividad="620100", otras_senas="Frente al parque", correo="pagos428@example.test",
                    ambiente="sandbox", plan="fac_emprendedor", extras="[]", **kw)
        s.add(e); s.commit(); s.refresh(e)
        return e.id


def test_pago_con_tarjeta_unico_y_automatico(general, monkeypatch):
    general(1, 15)
    _fijar_hoy(monkeypatch, "2026-11-10")                                # C5: «hoy» fijo y fechas escritas a mano
    hoy = date(2026, 11, 10)
    # pago único con tarjeta (sin cobro automático): al día fijo, contando la gracia como crédito (vence 1 nov, paga 10 nov → 1 dic)
    eid = _empresa_central(vence="2026-11-01")
    with Session(engine) as s:
        e = s.get(Empresa, eid)
        assert suscripcion._registrar_unico(s, e, f"PL{eid}-428-a", 5537.0)
        s.refresh(e)
        assert e.vence == "2026-12-01"
    vence = "2026-11-06"
    # cobro automático ACTIVO: su fecha la lleva el cobro (sin día fijo); con gracia, desde el vencimiento anterior
    from tests.test_suscripcion import TilopayFalso
    falso = TilopayFalso()
    monkeypatch.setattr(suscripcion, "llamar", falso)
    monkeypatch.setattr(suscripcion, "ARCHIVO", pathlib.Path(sistema.ARCHIVO).with_name("pasarela.json"))
    monkeypatch.setenv("FE_TILOPAY_KEY", "1111-2222-3333-4444-5555")
    monkeypatch.setenv("FE_TILOPAY_USER", "usuario-prueba")
    monkeypatch.setenv("FE_TILOPAY_PASSWORD", "clave-prueba")
    eid2 = _empresa_central(vence=vence)
    with Session(engine) as s:
        reg = suscripcion.SuscripcionPago(empresa_id=eid2, plan_id=428428, correo="pagos428@example.test", estado="pendiente")
        s.add(reg); s.commit(); s.refresh(reg)
        falso.subs[428428] = [{"id": 4281, "email": "pagos428@example.test", "status": "Active", "expire": "2030-01-01", "create": "2026-11-01"}]
        falso.pagos[428428] = [{"id": 42801, "suscriptor_id": 4281, "reference": "ORD-428", "currency": "CRC", "amount": "5537.00", "status": 1, "create": hoy.isoformat()}]
        e2 = s.get(Empresa, eid2)
        assert suscripcion.sincronizar(s, e2, reg)["registrados"] == 1
        s.refresh(e2)
        assert planes.cobro_automatico_activo(e2, s)
        assert planes.dia_fijo(e2, s) is None
        assert e2.vence == "2026-12-06"                                    # sin día fijo (no el 1 de enero) y sin regalar la gracia (no el 10 de diciembre)
        pago = s.exec(select(auth.PagoPlan).where(auth.PagoPlan.empresa_id == eid2)).first()
        assert pago.vence_anterior == vence and pago.vence_nuevo == e2.vence


def test_correos_de_aviso_con_y_sin_gracia(general):
    hoy = ahora_cr().date()
    enviados = []
    eid = _empresa_central(vence=(hoy - timedelta(days=3)).isoformat(), plan_dias_gracia=15)

    def enviar(s, e, asunto, texto):
        if e.id != eid:
            return False
        enviados.append((asunto, texto))
        return True

    planes.recordatorios_vencimiento(enviar)
    assert len(enviados) == 1 and "pago pendiente" in enviados[0][0]
    hasta = (hoy + timedelta(days=12)).strftime("%d/%m/%Y")
    assert f"hasta el {hasta}" in enviados[0][1] and "quedó en modo consulta" not in enviados[0][1]
    planes.recordatorios_vencimiento(enviar)
    assert len(enviados) == 1                                             # una sola vez por fecha
    with Session(engine) as s:
        e = s.get(Empresa, eid); assert e.aviso_plan.startswith("g:")
        e.vence = (hoy - timedelta(days=20)).isoformat(); e.aviso_plan = f"g:{e.vence}"; s.add(e); s.commit()
    planes.recordatorios_vencimiento(enviar)                             # terminó la gracia: «quedó en modo consulta», una vez
    assert len(enviados) == 2 and "venció" in enviados[1][0] and "quedó en modo consulta" in enviados[1][1]
    planes.recordatorios_vencimiento(enviar)
    assert len(enviados) == 2
    # sin días de gracia: el correo de siempre el día después de vencer
    with Session(engine) as s:
        e = s.get(Empresa, eid); e.plan_dias_gracia = None; e.vence = (hoy - timedelta(days=1)).isoformat(); e.aviso_plan = None; s.add(e); s.commit()
    planes.recordatorios_vencimiento(enviar)
    assert len(enviados) == 3 and "quedó en modo consulta" in enviados[2][1]


# ------------------------------------------------------------------------------------------------ programa de escritorio (P-7)
_AVISA = types.SimpleNamespace(headers={sinc.CABECERA_PLAN: str(sinc.PROTOCOLO_PLAN)})   # una petición del programa 4.28 (C1)
def test_programa_de_escritorio_usa_el_mayor_entre_7_y_la_gracia(general, monkeypatch):
    general(1, 15)
    assert "plan_dias_gracia" in sinc.CAMPOS_EMPRESA
    e = Empresa(nombre="Local 428", numero_id="3101000428", actividad="620100", otras_senas="x", correo="l428@example.test", plan="fac_emprendedor", vence="2030-01-01")
    assert sinc._datos_empresa(e, _AVISA)["plan_dias_gracia"] == 15        # baja con los días EFECTIVOS (al programa que los entiende, C1)
    e.plan_dias_gracia = 3
    assert sinc._datos_empresa(e, _AVISA)["plan_dias_gracia"] == 3
    # en la computadora
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    monkeypatch.setattr(planes, "MODO_LOCAL", True)
    monkeypatch.setattr(sinc, "vinculada", lambda eid: True)
    hoy = ahora_cr().date()
    eid = 999428
    sinc._inst_estado[eid] = {"ultima_bajada": datetime.now(timezone.utc).isoformat()}
    try:
        d = lambda n: (hoy - timedelta(days=n)).isoformat()
        assert sinc.fecha_confirmada(eid, d(8)) is True                    # sin gracia: los 7 de siempre
        assert sinc.fecha_confirmada(eid, d(10), 15) is False              # con 15: la nube tiene que confirmar después del fin de la gracia
        assert sinc.fecha_confirmada(eid, d(16), 15) is True               # pasó el mayor (15)
        assert sinc.fecha_confirmada(eid, d(8), 3) is True                 # el mayor es 7
        assert sinc.fecha_confirmada(eid, d(5), 3) is True                 # confirmada por la nube hoy, después del fin de la gracia (hace 2 días)
        loc = types.SimpleNamespace(id=eid, plan="fac_emprendedor", vence=d(10), prueba_hasta=None, es_demo=False, plan_dia_vence=None, plan_dias_gracia=15)
        assert planes._cobro_general() == {"dia_vence": None, "dias_gracia": 0}   # en la computadora no hay general: manda lo que bajó
        assert planes.estado_pago(loc) == "en_gracia" and planes.vencido(loc) is False
        loc.vence = d(16)
        assert planes.estado_pago(loc) == "vencido" and planes.vencido(loc) is True
    finally:
        sinc._inst_estado.pop(eid, None)


# ------------------------------------------------------------------------------------------------ C1: programa anterior a la 4.28
def _viejo_vencido(vence: str, hoy: str, ultima_bajada: str) -> bool:
    """La regla del programa 4.16 a 4.27 (sinc.fecha_confirmada de la 4.27 con su planes.vencido): con internet, vencido si hoy es
    posterior a `vence` y la última bajada buena es de un día posterior a `vence`. No conoce los días de gracia."""
    return hoy > vence and ultima_bajada[:10] > vence


def test_c1_la_nube_solo_manda_la_gracia_a_quien_avisa(general):
    general(1, 15)
    e = Empresa(nombre="Local C1", numero_id="3101000429", actividad="620100", otras_senas="x", correo="c1-428@example.test", plan="fac_emprendedor", vence="2026-12-01")
    viejo, nuevo = sinc._datos_empresa(e), sinc._datos_empresa(e, _AVISA)
    assert (viejo["vence"], viejo["plan_dias_gracia"]) == ("2026-12-16", 0)           # sin aviso: el último día de gracia y 0 días
    assert (nuevo["vence"], nuevo["plan_dias_gracia"]) == ("2026-12-01", 15)          # con aviso: la fecha real y los días
    assert e.vence == "2026-12-01"                                                    # no toca la empresa
    for raro in ({}, {sinc.CABECERA_PLAN: "abc"}, {sinc.CABECERA_PLAN: "0"}, {sinc.CABECERA_INGRESO: "1"}):
        assert sinc._datos_empresa(e, types.SimpleNamespace(headers=raro))["vence"] == "2026-12-16", raro
    # 0 días de gracia (P-1): los dos reciben lo mismo que en la 4.27
    e.plan_dias_gracia = 0
    assert sinc._datos_empresa(e)["vence"] == sinc._datos_empresa(e, _AVISA)["vence"] == "2026-12-01"
    assert sinc._datos_empresa(e)["plan_dias_gracia"] == sinc._datos_empresa(e, _AVISA)["plan_dias_gracia"] == 0
    general(None, 0)
    e.plan_dias_gracia = None
    assert sinc._datos_empresa(e) == sinc._datos_empresa(e, _AVISA) and sinc._datos_empresa(e)["vence"] == "2026-12-01"
    # sin fecha sigue vacío; la prueba gratis no se toca
    general(1, 15)
    e.vence = None
    assert sinc._datos_empresa(e)["vence"] is None
    e.vence, e.prueba_hasta = "2026-12-01", "2026-11-20"
    assert sinc._datos_empresa(e)["vence"] == "2026-12-01" and sinc._datos_empresa(e)["prueba_hasta"] == "2026-11-20"


def test_c1_el_programa_viejo_queda_en_consulta_el_mismo_dia_que_la_web(general):
    general(1, 15)
    e = _e(vence="2026-12-01")
    recibe = sinc._datos_empresa(Empresa(nombre="Viejo C1", numero_id="3101000430", actividad="620100", otras_senas="x", correo="c1v-428@example.test",
                                         plan="fac_emprendedor", vence="2026-12-01"))["vence"]
    dia = date(2026, 11, 28)
    while dia <= date(2026, 12, 20):
        hoy = dia.isoformat()
        web = planes.estado_pago(e, hoy) == "vencido"
        viejo = _viejo_vencido(recibe, hoy, hoy)                          # con internet: bajó hoy
        assert viejo == web, (hoy, viejo, web)
        dia += timedelta(days=1)
    assert not _viejo_vencido(recibe, "2026-12-02", "2026-12-02") and not _viejo_vencido(recibe, "2026-12-16", "2026-12-16")   # durante la gracia, no
    assert _viejo_vencido(recibe, "2026-12-17", "2026-12-17")                                                                   # el día después, sí
    # sin la corrección (la fecha real) quedaba en consulta el día 2, con la web todavía completa
    assert _viejo_vencido("2026-12-01", "2026-12-02", "2026-12-02") and planes.estado_pago(e, "2026-12-02") == "en_gracia"


def test_c1_rutas_de_la_nube_y_peticiones_del_programa(general, monkeypatch):
    """Canje del código y bajada del catálogo (nube), con y sin la cabecera; el programa 4.28 la manda en el canje, en la bajada y en
    las llamadas de la conexión aprobada en la página web, y guarda la fecha real y los días."""
    from tests import test_49_local_sinc as L
    general(None, 0)
    eid_a, ta = L._admin_empresa("-428c1n", "3101428431")
    eid_b, tb = L._admin_empresa("-428c1l", "3101428432")
    with Session(engine) as sc:
        e = sc.get(Empresa, eid_a); e.plan = "fac_emprendedor"; e.vence = "2030-01-01"; e.plan_dias_gracia = 15; sc.add(e); sc.commit()
    try:
        # nube: el canje (la misma _alta_instalacion que entrega la conexión aprobada) y el catálogo
        L._soltar_limite_vinculacion()
        cod = L.c.post("/api/sinc/codigo", headers=L.H(ta), json={"nombre": "Caja C1 vieja"}).json()["codigo"]
        j = L.c.post("/api/sinc/canje", json={"codigo": cod, "nombre": "Caja C1 vieja"}).json()
        assert (j["empresa"]["vence"], j["empresa"]["plan_dias_gracia"]) == ("2030-01-16", 0)
        tok = j["token"]
        cat = L.c.get("/api/sinc/catalogo", headers=L.H(tok)).json()["empresa"]
        assert (cat["vence"], cat["plan_dias_gracia"]) == ("2030-01-16", 0)
        cat = L.c.get("/api/sinc/catalogo", headers={**L.H(tok), sinc.CABECERA_PLAN: "1"}).json()["empresa"]
        assert (cat["vence"], cat["plan_dias_gracia"]) == ("2030-01-01", 15)
        cod = L.c.post("/api/sinc/codigo", headers=L.H(ta), json={"nombre": "Caja C1 nueva"}).json()["codigo"]
        j = L.c.post("/api/sinc/canje", headers={sinc.CABECERA_PLAN: "1"}, json={"codigo": cod, "nombre": "Caja C1 nueva"}).json()
        assert (j["empresa"]["vence"], j["empresa"]["plan_dias_gracia"]) == ("2030-01-01", 15)
        # programa 4.28: vincula y baja con el aviso, y guarda la fecha real y los días
        shim = L._modo_local(monkeypatch)
        vistos = []
        get, post = shim.get, shim.post
        monkeypatch.setattr(shim, "get", lambda url, headers=None, timeout=None: vistos.append((url.split("?")[0][len(L.NUBE):], dict(headers or {}))) or get(url, headers=headers, timeout=timeout))
        monkeypatch.setattr(shim, "post", lambda url, headers=None, json=None, timeout=None: vistos.append((url[len(L.NUBE):], dict(headers or {}))) or post(url, headers=headers, json=json, timeout=timeout))
        L._vincular(monkeypatch, ta, tb, "Caja C1 programa")
        assert not sinc.sincronizar(eid_b)["ultimo_error"]
        avisos = {r: h.get(sinc.CABECERA_PLAN) for r, h in vistos}
        assert avisos["/api/sinc/canje"] == "1" and avisos["/api/sinc/catalogo"] == "1", avisos
        with Session(engine) as sc:
            local = sc.get(Empresa, eid_b)
            assert (local.vence, local.plan_dias_gracia) == ("2030-01-01", 15)
    finally:
        with Session(engine_empresa(eid_b)) as s:
            cfg = sinc._cfg_local(s, eid_b)
            if cfg.get("vinculado"):
                cfg.update({"vinculado": False, "token": None}); sinc._escribir(s, eid_b, sinc.CLAVE_LOCAL, cfg); s.commit()
        for x in (eid_a, eid_b):
            sinc._inst_estado.pop(x, None); sinc._fijas.pop(x, None)
        L._soltar_limite_vinculacion()


def test_c1_la_conexion_aprobada_en_la_web_lleva_el_aviso(monkeypatch):
    vistos = []

    class _Web:
        Timeout = sinc.httpx.Timeout

        @staticmethod
        def post(url, headers=None, json=None, timeout=None):  # noqa: A002
            vistos.append((url, dict(headers or {})))
            raise sinc._ERROR_RED("sin red (prueba)")
    monkeypatch.setattr(sinc, "URL_NUBE", "https://nube-c1.example.test")
    monkeypatch.setattr(sinc, "httpx", _Web())
    assert sinc._llamar_conexion("/api/sinc/conexion/recoger", {"secreto": "x"})[0] == "sin_internet"
    assert vistos and vistos[0][0].endswith("/api/sinc/conexion/recoger") and vistos[0][1].get(sinc.CABECERA_PLAN) == str(sinc.PROTOCOLO_PLAN)


# ------------------------------------------------------------------------------------------------ C3: correo de 7 días antes
def test_c3_correo_de_7_dias_antes_con_y_sin_gracia(general):
    hoy = ahora_cr().date()
    vence = hoy + timedelta(days=5)
    con = _empresa_central(vence=vence.isoformat(), plan_dias_gracia=15)
    sin = _empresa_central(vence=vence.isoformat(), plan_dias_gracia=0)
    uno = _empresa_central(vence=vence.isoformat(), plan_dias_gracia=1)
    textos = {}

    def enviar(s, e, asunto, texto):
        if e.id not in (con, sin, uno):
            return False
        textos[e.id] = texto
        return True
    planes.recordatorios_vencimiento(enviar)
    assert set(textos) == {con, sin, uno}
    f = vence.strftime("%d/%m/%Y")
    assert (f"Después de esa fecha tiene 15 días para ponerse al día; luego el sistema queda en modo consulta (puede ver y exportar) hasta que se "
            "renueve.") in textos[con] and "Al vencer, el sistema queda en modo consulta" not in textos[con]
    assert "tiene 1 día para ponerse al día" in textos[uno]
    with Session(engine) as s:
        e = s.get(Empresa, sin)
        nombre, plan = e.nombre_comercial or e.nombre, (planes.plan_de(e) or {}).get("nombre", "")
    assert textos[sin] == (f"Hola, {nombre}.\n\nSu plan {plan} vence el {f}. Para seguir emitiendo y guardando sin interrupción, renueve antes de esa fecha: "
                           f"escríbanos a {planes.correo_ventas()} o por WhatsApp.\n\nAl vencer, el sistema queda en modo consulta (puede ver y exportar) "
                           f"hasta que se renueve.\n\n{planes.nombre_sistema()}")   # sin gracia: el texto de la 4.27, sin cambios


# ------------------------------------------------------------------------------------------------ pantallas
def test_textos_de_las_pantallas():
    app_js, inicio, admin = _js("app.js"), _js("pages/inicio.js"), _js("pages/admin.js")
    # franja superior (todas las pantallas menos el Inicio, que tiene la suya) y la de vencido con «Pagar ahora»
    assert "v-if=\"sesion.empresaInfo?.plan?.estado_pago === 'en_gracia' && sesion.empresaInfo.plan.aviso_pago && path !== '/inicio'\"" in app_js
    assert "Para ponerse al día escríbanos a {{sistemaCfg().correo_ventas}}." in app_js
    assert app_js.count('href="#/configuracion/suscripcion">Pagar ahora</a>') == 2 and "pagoEnLinea() {" in app_js
    assert 'diasPara(sesion.empresaInfo.plan.vence) <= 7 && diasPara(sesion.empresaInfo.plan.vence) > 0"><b>Su plan vence el' in app_js   # la de hoy, intacta
    # C8: las franjas de siempre con la fecha en DD/MM/AAAA, como la de pago pendiente
    assert "<b>Su plan vence el {{fechaPlan(sesion.empresaInfo.plan.vence)}}.</b>" in app_js and "<b>Su plan venció el {{fechaPlan(sesion.empresaInfo.plan.vence)}}.</b>" in app_js
    assert "Su plan vence el {{sesion.empresaInfo.plan.vence}}" not in app_js and "Su plan venció el {{sesion.empresaInfo.plan.vence}}" not in app_js
    assert "fechaPlan(f) {" in app_js
    # C4: «Pagar ahora» con la misma regla del menú para la pantalla de pago (rutaPermitida), en la franja y en el Inicio
    assert "return !!(p && p.pago_en_linea) && rutaPermitida('/configuracion/suscripcion'); }" in app_js
    assert "pagoEnLinea() { return !!(this.pagoPendiente && this.pagoPendiente.pago_en_linea) && rutaPermitida('/configuracion/suscripcion'); }" in inicio
    assert "hotelActivo, rutaPermitida } from '../app.js';" in inicio
    for js in (app_js, inicio):
        linea = next(x for x in js.splitlines() if "pagoEnLinea() {" in x)
        assert "sesion.puede(" not in linea, linea
    # Inicio
    assert "pagoPendiente() {" in inicio and "pagoEnLinea() {" in inicio and "{{pagoPendiente.aviso_pago}}" in inicio
    assert 'href="#/configuracion/suscripcion">Pagar ahora</a>' in inicio
    # C7: el aviso de pago pendiente es lo primero del Inicio (antes del encabezado y de las tarjetas de módulos), una sola vez
    plantilla = inicio[inicio.index("template: `"):]
    assert plantilla.index('v-if="pagoPendiente"') < plantilla.index('class="erp-intro"') < plantilla.index('class="erp-apps"')
    assert plantilla.split("<Modal", 1)[0].strip().endswith("Pagar ahora</a></div>") and inicio.count('v-if="pagoPendiente"') == 1
    # C6: «Vencía» en el historial de pagos de la ficha
    assert "<th>Vencía</th><th>Vence</th>" in admin and "<td>{{fechaCr(p.vence_anterior)}}</td><td>{{fechaCr(p.vence_nuevo)}}</td>" in admin and "fechaCr(f) {" in admin
    # C2: vacío o letras no se guardan como 0 sin avisar
    assert "+f.dias_gracia || 0" not in admin and "Escriba los días de gracia: un número de 0 a 60" in admin
    assert "enteroCampo(f.dias_gracia, 0, 60, false, this.campoMalo('graciaGeneral'))" in admin and 'ref="graciaGeneral"' in admin
    assert "enteroCampo(f.plan_dias_gracia, 0, 60, true, this.campoMalo('graciaFicha'))" in admin and 'ref="graciaFicha"' in admin
    assert "enteroCampo(f.plan_dia_vence, 0, 28, true)" in admin and "plan_dia_vence: dv.valor, plan_dias_gracia: dg.valor" in admin
    # consola
    for t in ("Vencimiento de los planes y días de gracia", "Día de vencimiento de cada mes", "Días de gracia", "Cada empresa conserva su fecha",
              "Fijarlo NO cambia la fecha de ninguna empresa: cada una se alinea a ese día en su siguiente pago", "Usar el general",
              "Sin día fijo (conserva su fecha)", "En gracia hasta {{diaMes(c.plan.gracia_hasta)}}", ">Vencido</span>",
              "Con pago pendiente (en gracia o vencido)", "/api/admin/cobro-plan"):
        assert t in admin, t
    for nombre in ("cobroPlan:", "cobroForm:", "guardandoCobro:", "filtroPago:", "cargarCobroPlan()", "guardarCobroPlan()", "pagoPendiente(c)", "diaMes(f)", "generalCobro()"):
        assert nombre in admin, nombre


def _nodo():
    from test_425_ultimos_pantallas import _nodo as n
    return n()


def test_c2_y_c4_en_node(tmp_path):
    """C2: enteroCampo (la que usan los dos guardados de la consola) rechaza vacío (en lo general), letras, decimales y fuera de rango.
    C4: la regla del menú para #/configuracion/suscripcion (la que ahora usa «Pagar ahora»)."""
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    admin = _js("pages/admin.js")
    ini = admin.index("export function enteroCampo(")
    fuente = admin[ini:admin.index("\n}\n", ini) + 3].replace("export function", "function")
    (tmp_path / "menu.mjs").write_text(_js("menu.js"), encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(fuente + """
import { rutaPermitidaDe } from './menu.mjs';
const E = (v, a, b, vac, malo) => { const r = enteroCampo(v, a, b, vac, malo); return r.ok ? r.valor : 'X'; };
const ses = permisos => ({ empresa_id: 1, tipo: 'facturacion', permisos, esAdmin: false, puede(p) { return permisos.includes(p); }, tieneModulo: () => true });
const vieja = s => s.puede('usuarios') || (s.puede('ver_todo') && s.puede('escribir'));
const roles = { admin: ['ver', 'ver_todo', 'escribir', 'usuarios', 'configurar'], soloUsuarios: ['ver', 'usuarios'], contador: ['ver', 'ver_todo', 'escribir'], cajero: ['ver', 'pos'] };
console.log(JSON.stringify({
  general: ['', null, 'abc', '1e', '2.5', '-1', '61', '0', '15', 60, ' 7 '].map(v => E(v, 0, 60, false)),
  ficha: ['', null, 'abc', '61', '0', '30'].map(v => E(v, 0, 60, true)),
  malo: [E('', 0, 60, true, true), E('', 0, 60, false, true)],
  dia: ['', 0, 1, 28, 29, 'x'].map(v => E(v, 0, 28, true)),
  menu: Object.fromEntries(Object.entries(roles).map(([k, p]) => [k, [rutaPermitidaDe(ses(p), '/configuracion/suscripcion'), vieja(ses(p))]])),
}));
""", encoding="utf-8")
    out = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert out.returncode == 0, out.stderr[-2000:]
    r = json.loads(out.stdout)
    assert r["general"] == ["X", "X", "X", "X", "X", "X", "X", 0, 15, 60, 7]          # vacío o letras: no se guarda (antes: 0)
    assert r["ficha"] == [None, None, "X", "X", 0, 30]                                 # en la ficha vacío = usar el general
    assert r["malo"] == ["X", "X"]                                                     # letras que el navegador entrega como vacío
    assert r["dia"] == [None, 0, 1, 28, "X", "X"]
    assert r["menu"]["admin"] == [True, True] and r["menu"]["contador"] == [True, True] and r["menu"]["cajero"] == [False, False]
    assert r["menu"]["soloUsuarios"] == [False, True]                                  # la regla anterior le mostraba un botón que no abre


def test_sintaxis_y_plantillas(tmp_path):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    tocados = ("app.js", "pages/inicio.js", "pages/admin.js")
    for rel in tocados:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    rutas = json.dumps([str(JS / r) for r in tocados])
    guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const malos = [];
let n = 0;
for (const a of %s) {
  const txt = fs.readFileSync(a, 'utf8'); const re = /template:\\s*`([\\s\\S]*?)`/g; let m;
  while ((m = re.exec(txt))) {
    if (m[1].includes('${')) continue;
    n++;
    const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); }
    if (err.length) malos.push([a, err.slice(0, 2)]);
  }
}
console.log(JSON.stringify({ n, malos }));
""" % (json.dumps(vue), rutas)
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    r = json.loads(out.stdout)
    assert r["n"] >= 3 and r["malos"] == [], r
