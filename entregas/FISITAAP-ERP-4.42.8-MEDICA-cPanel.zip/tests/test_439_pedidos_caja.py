# -*- coding: utf-8 -*-
"""4.39 (frente A), soporte de un restaurante que trabaja en venta rápida (16 nov 2026, Itzen): «cliente pide en catálogo — el sistema
alerta y lo visualiza en el botón pedidos en línea que se encuentra en caja. En esa visualización puede "ver pedido" o "imprimir comanda"
— si le da ver pedido va a ver los datos resumen del pedido y se habilita el imprimir comanda o cancelar con justificación — si le da
imprimir comanda el pedido automáticamente pasa a monitor de cocina y a la lista de pedidos guardados». Y Norman: «todas las pantallas
deberían tener el botón atrás».

En la ventana «🌐 Pedidos en línea» de la caja (página web y programa de escritorio):
- cada pedido tiene «Ver pedido»; el nuevo (y en la web el aceptado que quedó sin cuenta) tiene «Imprimir comanda»; el aceptado que ya
  está en esta caja, «Abrir para cobrar». Ya no está «Aceptar en Pedidos» (llevaba a otra aplicación).
- «Ver pedido» muestra el resumen dentro de la misma ventana con «← Atrás» (arriba a la izquierda y abajo); Escape vuelve atrás.
- «Imprimir comanda» en la web usa la lógica de Ventas en línea › Pedidos: pages/pos/_aceptar_pedido.js es copia EXACTA de los métodos
  de fis/pages/pedidos.js (se comprueba letra por letra y corriendo los mismos casos en los dos); en el programa, el aceptarWeb de la 4.32.
  Después la caja sincroniza (la cuenta llega a «Para llevar en espera») y vuelve a leer la ventana.
- Cancelar con justificación (8+ caracteres; el cliente la ve).
Nada va a una impresora, a la red ni a un servidor de verdad: la API, el agente y las ventanas son funciones de la prueba."""
import json
import posixpath
import re
import shutil
import subprocess

import pytest

from tests.test_425_ultimos_pantallas import JS, _js, _node, _nodo, _tramo
from tests.test_431_estacion_pantallas import BASE, FALSOS_PED, _pedidos_js
from tests.test_432_caja_pedidos_web import _boton, _computadas, _metodos, _ventana

MODULO = "pages/pos/_aceptar_pedido.js"
METODOS_COPIADOS = ("nombreAtiende(p) {", "async cargarImpresion() {", "async aceptar(p) {", "async aceptarComo(p, extra) {", "async aceptarEnPrograma(p) {",
                    "async comandaDelPedido(C, r, vent) {", "async comandaDeCopia(C, r, vent, copia, ahora, datos) {", "async marcarDespues(C, envios) {",
                    "async comandaAnterior(C, r, vent, datos) {")


def _metodo_de(t, firma):
    """El método que empieza con `    firma` hasta su `    },` (o la línea, si es de una sola línea)."""
    i = t.index("\n    " + firma) + 1
    fin = t.index("\n", i)
    if t[i:fin].rstrip().endswith("},"):
        return t[i:fin]
    return t[i:t.index("\n    },\n", i) + len("\n    },")]


def _correr(tmp_path, guion):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    (tmp_path / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=120, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout.strip().splitlines()[-1])


def _modulo_para_node():
    t = _js(MODULO).replace("import('/js/pages/pos/_comandas.js')", "import('./_comandas.js')")
    assert "'/js/" not in t
    return t


# ================================================================================================================ la lógica compartida
def test_el_aceptador_es_copia_exacta_de_ventas_en_linea_pedidos():
    ped, mod = _js("fis/pages/pedidos.js"), _js(MODULO)
    for firma in METODOS_COPIADOS:
        assert mod.count("\n    " + firma) == 1 and ped.count("\n    " + firma) == 1, firma
        assert _metodo_de(mod, firma) == _metodo_de(ped, firma), "pages/pos/_aceptar_pedido.js y fis/pages/pedidos.js ya no son iguales en " + firma
    for nombre in ("menu", "conComanda", "enProg"):                                                   # las computadas de pedidos.js, como get
        linea = _tramo(ped, "\n    " + nombre + "() {", "\n")[1:]
        assert "\n    get " + linea[4:] + "\n" in mod, nombre
    alla = next(l for l in ped.splitlines() if l.startswith("export const TEXTO_ACEPTADO_ALLA = "))
    assert alla in mod.splitlines()
    # nada se importa al cargar (ni fis/sesion.js ni app.js): las importaciones son las de pedidos.js, al usarse, y llegan a los mismos archivos
    codigo = "\n".join(l for l in mod.splitlines() if not l.strip().startswith("//"))
    assert not re.search(r"^\s*import\s", codigo, re.M) and " from '" not in codigo and "fis/sesion" not in codigo and "app.js" not in codigo
    rutas = set(re.findall(r"import\('([^']+)'\)", codigo))
    assert rutas == {"/js/pages/pos/_comandas.js", "../../pages/pos/_agente.js"} and rutas <= set(re.findall(r"import\('([^']+)'\)", ped))
    for carpeta in ("/js/fis/pages", "/js/pages/pos"):
        assert posixpath.normpath(posixpath.join(carpeta, "../../pages/pos/_agente.js")) == "/js/pages/pos/_agente.js"
    # lo propio de la caja: preparar (negocio e impresión antes del toque) y cargar (lo que la caja hace después)
    assert "async preparar() {" in mod and "api('/api/pedidos/negocio')" in mod and "await this.cargarImpresion();" in mod
    assert "async cargar(silencioso) { try { if (recargar) await recargar(silencioso); } catch" in mod
    assert "get menu() { return base?.tipo === 'restaurante' || this.negocio?.presentacion === 'menu'; }," in mod     # como fis/sesion.js
    fis = _js("fis/sesion.js")
    assert "get menu() { return this.tipo === 'restaurante' || this.negocio?.presentacion === 'menu'; }," in fis
    assert "get nombreUsuario() { return this.usuario?.nombre || this.usuario?.correo || ''; }," in fis
    assert "get nombreUsuario() { return base?.usuario?.nombre || base?.usuario?.correo || ''; }," in mod
    assert _js(MODULO).count("\r\n") == 0


GUION_IGUALES = BASE + r"""
Q.sesionFis = { menu: true, negocio: { terminal_id: 1 }, empresaInfo: {}, fisica: true, tieneModulo: () => false, sucursalActual: null, nombreUsuario: 'Ana QA' };
const api0 = Q.api;
Q.api = async (url, opt) => {
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) {
    Q.llamadas.push('PUT ' + url + ' ' + JSON.stringify(opt.body));
    if (Q.segundo) throw Object.assign(new Error('El pedido está «Confirmado»; solo se confirma un pedido nuevo'), { status: 400 });
    return { id: Q.pid, estado: 'en_preparacion', cuenta_espera_id: 100 + Q.pid, ...(Q.alla ? { atiende: 3, atiende_nombre: 'Caja Sur' } : {}) };
  }
  if (url === '/api/registros/pos_config') { if (Q.colgar) return new Promise(() => {}); return { datos: Q.cfg }; }
  if (url === '/api/registros/pos_impresoras') return { datos: Q.imps };
  if (url === '/api/registros/categorias') return { datos: Q.cats };
  if (url === '/api/registros/items_extra') return { datos: {} };
  if (url.startsWith('/api/productos')) return Q.store.productos;
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  return api0(url, opt);
};
const P = (await import('./js/fis/pages/pedidos.js')).default;
const M = await import('./js/pages/pos/_aceptar_pedido.js');
/* Ventas en línea › Pedidos, montada como en test_431; la caja, con el aceptador y la sesión armada con la del ERP */
const deVentas = () => { const vm = Object.assign({ params: { query: {} } }, P.data.call({ params: { query: {} } })); for (const [k, f] of Object.entries(P.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true }); for (const [k, f] of Object.entries(P.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f; return vm; };
const deCaja = () => { const s = M.sesionDeCaja({ tipo: Q.sesionFis.menu ? 'restaurante' : 'comercio', empresaInfo: Q.sesionFis.empresaInfo, usuario: { nombre: 'Ana QA', correo: 'ana@example.test' } }); s.negocio = { terminal_id: 1 };
  return M.crearAceptador({ api: (u, o) => Q.api(u, o), toast: (m, t) => Q.toasts.push([m, t || '']), sesion: s, recargar: async () => { Q.recargas++; } }); };
const caso = async (hacer, pid, prep, tras) => {
  S.copias = {}; S.filas = {}; S.t = Date.now(); limpiar(); Q.pid = pid; Q.rotas = []; Q.agente = true; Q.ventanas = 0; Q.recargas = 0; Q.segundo = false; Q.alla = false; Q.sesionFis.menu = true;
  copia(pid, { origen: 'aceptar' }); if (prep) prep();
  const vm = hacer(); await vm.cargarImpresion(); if (tras) tras(); const p = { id: pid, estado: 'nuevo' };
  const ok = Q.doble ? await Promise.all([vm.aceptar(p), vm.aceptar(p)]) : await vm.aceptar(p);
  return { ok, toasts: Q.toasts, impresos: Q.impresos, ventanas: Q.ventanas, put: Q.llamadas.filter(x => x.startsWith('PUT')),
    posts: Q.llamadas.filter(x => x.startsWith('POST')).map(x => x.split(' ')[1] + ' ' + JSON.stringify(JSON.parse(x.slice(x.indexOf('{'))).lineas)),
    nombres: [...new Set(Q.llamadas.filter(x => x.startsWith('POST /api/pos/comanda/reclamar')).map(x => JSON.parse(x.slice(x.indexOf('{'))).nombre))],
    filas: Object.entries(S.filas).map(([k, f]) => k + ':' + f.estado).sort(), estado: Q.estadoPedido || null, p, recargas: Q.recargas };
};
const CASOS = {
  bien: [1], sinAgente: [2, () => { Q.agente = false; }],
  ocupada: [3, () => { S.filas['3|1'] = { estado: 'reclamada', equipo: 'otraPestana01', nombre: 'Caja 1 · Cocina', vence: iso(S.t + 50000), intentos: 0 }; }],
  sinRed: [4, () => { Q.sinRed = 'reclamar'; }],
  masTarde: [5, () => { Q.agente = false; Object.assign(S.copias[5], { hora_entrega: '19:00', listo_desde: iso(Date.now() + 3600000) }); }],
  caida: [6, () => { Q.rotas = ['Cocina']; }],
  segundo: [7, () => { Q.segundo = true; }],
  sinMenu: [8, () => { Q.sesionFis.menu = false; }],
  alla: [9, () => { Q.alla = true; }],
  doble: [10, () => { Q.doble = true; }],
  colgada: [11, null, () => { Q.colgar = true; }],
};
const out = { ventas: {}, caja: {} };
for (const [nombre, [pid, prep, tras]] of Object.entries(CASOS)) {
  for (const [lado, hacer] of [['ventas', deVentas], ['caja', deCaja]]) {
    Q.sinRed = null; Q.colgar = false; Q.doble = false; Q.estadoPedido = null;
    out[lado][nombre] = await caso(hacer, pid, prep, tras);
  }
}
console.log(JSON.stringify(out));
process.exit(0);
"""


def test_el_aceptador_de_la_caja_hace_lo_mismo_que_ventas_en_linea(tmp_path):
    falsos = dict(FALSOS_PED)
    falsos["fis/pages/pedidos.js"] = _pedidos_js()
    falsos["pages/pos/_agente_real.js"] = _js("pages/pos/_agente.js")
    falsos[MODULO] = _modulo_para_node()
    r = _node(tmp_path, GUION_IGUALES, archivos=("pages/pos/_comandas.js",), falsos=falsos)
    v, c = r["ventas"], r["caja"]
    for nombre in v:
        ventas, caja = dict(v[nombre]), dict(c[nombre])
        rv, rc = ventas.pop("recargas"), caja.pop("recargas")
        assert caja == ventas, (nombre, caja, ventas)                                        # lo mismo: avisos, ventana, reclamos, marcas, impresos
        assert rc == (0 if nombre == "segundo" else 1), (nombre, rc)                         # después de aceptar, la caja vuelve a leer (una vez)
        assert rv == 0                                                                        # (Ventas en línea lee la lista con la API, no con recargar)
    b = c["bien"]
    assert b["ok"] is True and '"reclama":true' in b["put"][0] and '"estado":"confirmado"' in b["put"][0], b
    assert b["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]] and b["impresos"] == [["Cocina", "Casado"]] and b["ventanas"] == 1, b
    assert b["nombres"] == ["Pedidos · Ana QA"] and b["filas"] == ["1|0:impresa", "1|1:impresa"], b       # el nombre de quien la imprime sale de la sesión del ERP
    assert c["alla"]["toasts"] == [["Pedido aceptado: lo atiende «Caja Sur»; su comanda sale allá.", "ok"]] and c["alla"]["impresos"] == [], c["alla"]
    assert c["segundo"]["ok"] is False and c["segundo"]["toasts"] == [["El pedido está «Confirmado»; solo se confirma un pedido nuevo", "err"]]
    assert c["sinMenu"]["toasts"] == [["Pedido actualizado.", "ok"]] and c["sinMenu"]["ventanas"] == 0 and c["sinMenu"]["posts"] == []
    assert c["doble"]["ok"] == [True, False] and len(c["doble"]["put"]) == 1 and c["doble"]["impresos"] == [["Cocina", "Casado"]]
    assert "no se pudo leer a tiempo" in c["colgada"]["toasts"][0][0]


# ================================================================================================================ la ventana de la caja
GUION_VENTANA = r"""
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\s\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const Vue = await import(%(vue)s);
const texto = n => n == null ? '' : typeof n === 'string' ? n : Array.isArray(n) ? n.map(texto).join(' ') : n.type === Vue.Comment ? '' : typeof n.children === 'string' ? n.children : Array.isArray(n.children) ? n.children.map(texto).join(' ') : '';
function buscar(n, f, out) { out = out || []; if (!n || typeof n !== 'object') return out; if (Array.isArray(n)) { n.forEach(x => buscar(x, f, out)); return out; } if (f(n)) out.push(n); if (Array.isArray(n.children)) n.children.forEach(x => buscar(x, f, out)); return out; }
const limpio = s => String(s).replace(/\s+/g, ' ').trim();
const sesion = { empresaInfo: {}, tieneModulo: x => x === 'pedidos_online' };
const C = new Function('sesion', 'api', 'toast', 'return { computed: {' + %(comp)s + '}, methods: {' + %(met)s + '} };')(sesion, async () => [], () => {});
function vmCon(extra) {
  const vm = Object.assign({ online: { nuevos: 0, ultimo: null, sinVer: 0 }, panelWeb: null, esperaCaja: [], money: v => '₡' + v, recuperar() {} }, extra || {});
  for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
  return vm;
}
const ventana = Vue.compile(%(ventana)s), boton = Vue.compile(%(boton)s);
const conDato = (n, k) => buscar(n, x => x.props && x.props[k] !== undefined);
function dibujar(extra) {
  const vm = vmCon(extra), v = ventana.call(vm, vm, []);
  const filas = buscar(v, n => n.type === 'tr' && n.props && n.props['data-pedido-web'] !== undefined).map(tr => [tr.props['data-pedido-web'], buscar(tr, n => n.type === 'button' || n.type === 'a').map(n => limpio(texto(n)))]);
  const out = { filas: Object.fromEntries(filas), avisos: buscar(v, n => n.props && n.props.class === 'alert info' && n.props['data-nota-web'] === undefined).map(n => limpio(texto(n))) };
  out.deshab = Object.fromEntries(buscar(v, n => n.type === 'tr' && n.props && n.props['data-pedido-web'] !== undefined).map(tr => [tr.props['data-pedido-web'], buscar(tr, n => n.type === 'button').map(n => !!n.props.disabled)]));
  const det = conDato(v, 'data-detalle-web')[0];
  if (det) {
    const campo = k => { const x = conDato(det, k)[0]; return x ? limpio(texto(x)) : null; };
    out.detalle = { cliente: campo('data-cliente-web'), entrega: campo('data-entrega-web'), hora: campo('data-hora-web'), pago: campo('data-pago-web'), total: campo('data-total-web'), nota: campo('data-nota-web'),
      lineas: conDato(det, 'data-linea-web').map(tr => buscar(tr, n => n.type === 'td').map(td => limpio(texto(td)))),
      botones: buscar(det, n => n.type === 'button').map(n => [limpio(texto(n)), !!n.props.disabled]), arriba: limpio(texto(conDato(det, 'data-atras-web')[0])),
      textarea: buscar(det, n => n.type === 'textarea').length, todo: limpio(texto(det)) };
  }
  return out;
}
const NOMBRES = { nuevo: 'Nuevo', confirmado: 'Confirmado', en_preparacion: 'En preparación', cancelado: 'Cancelado' };
const ped = (id, estado, extra) => ({ id, numero: 40 + id, nombre: 'Ana QA', telefono: '8888-1234', tipo: 'domicilio', tipo_nombre: 'Express a domicilio', direccion: '200 m norte de la iglesia', zona: 'Centro',
  creado: '2026-11-16T10:12:00', hora_programada: '11:30', estado, estado_nombre: NOMBRES[estado] || estado, forma_pago: 'SINPE por verificar', pago_estado: 'sinpe_pendiente', pago_estado_nombre: 'SINPE por verificar',
  total: 9500, envio: 1500, descuento: 0, nota: 'Tocar el timbre', lineas: [{ detalle: 'Casado', cantidad: 2, total: 8000, nota: 'sin cebolla', opciones: [{ id: 1, nombre: 'Huevo' }, { id: 2, nombre: 'Aguacate' }] },
  { detalle: 'Refresco', cantidad: 1, total: 1000, nota: '', opciones: [] }], ...(extra || {}) });
const lista = [ped(1, 'nuevo'), ped(2, 'confirmado'), ped(3, 'nuevo', { atiende: 5, atiende_nombre: 'Caja Sur' }), ped(4, 'confirmado'), ped(5, 'en_preparacion'),
  ped(6, 'nuevo', { tipo: 'recoger', tipo_nombre: 'Para recoger', direccion: 'Barrio Amón', zona: null, hora_programada: null, nota: '', forma_pago: 'Pagado en línea', envio: 0 }),
  ped(7, 'cancelado', { motivo: 'Se nos acabó el pollo' })];
const pw = extra => ({ cargando: false, lista, error: '', aceptando: {}, ver: null, cancelar: null, imprime: null, ...(extra || {}) });
const espera = [{ id: 900, pedido_id: 2 }];
const o = {};
sesion.empresaInfo = {};
o.lista_web = dibujar({ panelWeb: pw(), esperaCaja: espera });
o.lista_web_sin_comanda = dibujar({ panelWeb: pw({ imprime: false }), esperaCaja: espera });
o.det_nuevo = dibujar({ panelWeb: pw({ ver: 1 }), esperaCaja: espera });
o.det_recoger = dibujar({ panelWeb: pw({ ver: 6 }), esperaCaja: espera });
o.det_aceptado = dibujar({ panelWeb: pw({ ver: 2 }), esperaCaja: espera });
o.det_otra = dibujar({ panelWeb: pw({ ver: 3 }), esperaCaja: espera });
o.det_cancelado = dibujar({ panelWeb: pw({ ver: 7 }), esperaCaja: espera });
o.det_cancelando = dibujar({ panelWeb: pw({ ver: 1, cancelar: { motivo: '', enviando: false } }), esperaCaja: espera });
o.det_enviando = dibujar({ panelWeb: pw({ ver: 1, cancelar: { motivo: 'Se nos acabó el pollo', enviando: true } }), esperaCaja: espera });
o.det_imprimiendo = dibujar({ panelWeb: pw({ ver: 1, aceptando: { 1: true } }), esperaCaja: espera });
o.det_sin_comanda = dibujar({ panelWeb: pw({ ver: 1, imprime: false }), esperaCaja: espera });
o.det_que_ya_no_esta = dibujar({ panelWeb: pw({ ver: 99 }), esperaCaja: espera });
/* revisión: mientras se lee lo de imprimir (listo false), «Imprimir comanda» dice «Preparando…» y no se puede tocar */
o.lista_web_preparando = dibujar({ panelWeb: pw({ listo: false }), esperaCaja: espera });
o.det_preparando = dibujar({ panelWeb: pw({ ver: 1, listo: false }), esperaCaja: espera });
o.lista_web_lista = dibujar({ panelWeb: pw({ listo: true, imprime: true }), esperaCaja: espera });
sesion.empresaInfo = { es_local: true, pedidos_programa: true };
o.lista_prog_sin_comanda = dibujar({ panelWeb: pw({ imprime: false, listo: true }), esperaCaja: espera });
o.det_prog_sin_comanda = dibujar({ panelWeb: pw({ ver: 1, imprime: false, listo: true }), esperaCaja: espera });
o.lista_prog = dibujar({ panelWeb: pw(), esperaCaja: espera });
o.det_prog = dibujar({ panelWeb: pw({ ver: 1 }), esperaCaja: espera });
o.det_prog_sin_cuenta = dibujar({ panelWeb: pw({ ver: 4 }), esperaCaja: espera });
sesion.tieneModulo = () => false; const vb = vmCon(); const b = boton.call(vb, vb, []); o.sin_modulo = !!(b && b.type === 'button');
console.log(JSON.stringify(o));
"""


def test_la_ventana_dibuja_los_botones_y_el_resumen(tmp_path):
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    o = _correr(tmp_path, GUION_VENTANA % {"vue": json.dumps(vue), "comp": json.dumps(_computadas()), "met": json.dumps(_metodos()),
                                           "ventana": json.dumps(_ventana()), "boton": json.dumps(_boton())})
    VER, IMP, COBRAR = "Ver pedido", "Imprimir comanda", "Abrir para cobrar"
    # la lista (página web): «Ver pedido» en todos; el nuevo y el aceptado que quedó sin cuenta se imprimen aquí; sin el aviso de ir a Pedidos
    assert o["lista_web"]["filas"] == {"1": [VER, IMP], "2": [VER, COBRAR], "3": [VER], "4": [VER, IMP], "5": [VER], "6": [VER, IMP]}, o["lista_web"]
    assert o["lista_web"]["avisos"] == [] and "detalle" not in o["lista_web"]
    assert o["lista_web_sin_comanda"]["filas"]["1"] == [VER, "Aceptar pedido"]                 # se sabe que no sale comanda: como en Ventas en línea
    # el programa: el nuevo se acepta aquí (aceptarWeb); el aceptado sin cuenta no (allá no se retoma). «Imprimir comanda» si sale comanda
    # (o no se pudo saber); revisión: «Aceptar pedido» si se sabe que no sale (imprimeProgWeb, ver test_revision_programa_preparando_y_cancelar)
    assert o["lista_prog"]["filas"] == {"1": [VER, IMP], "2": [VER, COBRAR], "3": [VER], "4": [VER], "5": [VER], "6": [VER, IMP]}, o["lista_prog"]
    assert o["lista_prog_sin_comanda"]["filas"] == {"1": [VER, "Aceptar pedido"], "2": [VER, COBRAR], "3": [VER], "4": [VER], "5": [VER], "6": [VER, "Aceptar pedido"]}
    assert o["det_prog_sin_comanda"]["detalle"]["botones"][-1] == ["Aceptar pedido", False]
    # revisión: en la página web, mientras se lee lo de imprimir, «Preparando…» y deshabilitado (Ver pedido y Abrir para cobrar sí se tocan)
    pr = o["lista_web_preparando"]
    assert pr["filas"] == {"1": [VER, "Preparando…"], "2": [VER, COBRAR], "3": [VER], "4": [VER, "Preparando…"], "5": [VER], "6": [VER, "Preparando…"]}, pr
    assert pr["deshab"] == {"1": [False, True], "2": [False, False], "3": [False], "4": [False, True], "5": [False], "6": [False, True]}, pr
    assert o["det_preparando"]["detalle"]["botones"] == [["← Atrás", False], ["← Atrás", False], ["Cancelar con justificación", False], ["Preparando…", True]]
    assert o["lista_web_lista"]["filas"]["1"] == [VER, IMP] and o["lista_web_lista"]["deshab"]["1"] == [False, False]
    assert o["lista_web"]["deshab"]["1"] == [False, False]                                   # sin «listo» (ventana de antes): como siempre
    # el resumen del pedido nuevo, dentro de la misma ventana (la lista no se dibuja mientras tanto)
    d = o["det_nuevo"]
    assert d["filas"] == {} and d["detalle"]["arriba"] == "← Atrás", d
    x = d["detalle"]
    assert "Pedido #41" in x["todo"] and "Nuevo" in x["todo"]
    assert x["cliente"] == "Ana QA · 8888-1234"
    assert x["entrega"] == "Express a domicilio · 200 m norte de la iglesia · zona Centro"
    assert x["hora"] == "Pedido a las 10:12 · lo quiere para las 11:30"
    assert x["pago"] == "SINPE por verificar"
    assert x["lineas"] == [["2", "Casado Con: Huevo, Aguacate Nota: sin cebolla", "₡8000"], ["1", "Refresco", "₡1000"]], x["lineas"]
    assert x["total"] == "Envío ₡1500 Total ₡9500" and x["nota"] == "Nota del cliente: Tocar el timbre"
    assert x["botones"] == [["← Atrás", False], ["← Atrás", False], ["Cancelar con justificación", False], [IMP, False]], x["botones"]
    assert x["textarea"] == 0
    r = o["det_recoger"]["detalle"]
    assert r["entrega"] == "Para recoger" and r["hora"] == "Pedido a las 10:12" and r["nota"] is None and r["pago"] == "Pagado en línea" and r["total"] == "Total ₡9500", r
    assert o["det_aceptado"]["detalle"]["botones"] == [["← Atrás", False], ["← Atrás", False], ["Cancelar con justificación", False], [COBRAR, False]]
    ot = o["det_otra"]["detalle"]
    assert "Lo atiende «Caja Sur»: cóbrelo allá." in ot["todo"] and ot["botones"] == [["← Atrás", False], ["← Atrás", False], ["Cancelar con justificación", False]], ot
    ca = o["det_cancelado"]["detalle"]
    assert ca["botones"] == [["← Atrás", False], ["← Atrás", False]] and "Motivo Se nos acabó el pollo" in ca["todo"], ca
    cn = o["det_cancelando"]["detalle"]
    assert cn["botones"] == [["← Atrás", False], ["Volver", False], ["Confirmar cancelación", False]] and cn["textarea"] == 1, cn
    assert "Justificación de la cancelación" in cn["todo"] and "Al menos 8 caracteres. El cliente la ve" in cn["todo"]
    assert o["det_enviando"]["detalle"]["botones"][-1] == ["Confirmar cancelación", True]
    assert o["det_imprimiendo"]["detalle"]["botones"][-1] == ["Confirmando…", True]
    assert o["det_sin_comanda"]["detalle"]["botones"][-1] == ["Aceptar pedido", False]
    assert "detalle" not in o["det_que_ya_no_esta"] and o["det_que_ya_no_esta"]["filas"]                 # un pedido que ya no está: la lista
    assert o["det_prog"]["detalle"]["botones"][-1] == [IMP, False]
    assert o["det_prog_sin_cuenta"]["detalle"]["botones"] == [["← Atrás", False], ["← Atrás", False], ["Cancelar con justificación", False]]
    assert o["sin_modulo"] is False                                                           # sin pedidos en línea no hay botón ni ventana


GUION_METODOS = r"""
const Q = { llamadas: [], toasts: [], sincs: 0, lista: [], falla: null, respuesta: null };
const sesion = { empresaInfo: {}, tieneModulo: x => x === 'pedidos_online' };
const api = async (url, op) => {
  Q.llamadas.push([url, op ? op.method : 'GET', op && op.body ? op.body : null]);
  if (Q.falla) throw new Error(Q.falla);
  if (url === '/api/pedidos') return Q.lista;
  if (/^\/api\/pedidos\/\d+\/estado$/.test(url)) return Q.respuesta || { id: 1 };
  throw new Error('ruta ' + url);
};
const toast = (m, t) => Q.toasts.push([m, t]);
const C = new Function('sesion', 'api', 'toast', 'return { computed: {' + %(comp)s + '}, methods: {' + %(met)s + '} };')(sesion, api, toast);
const T = new Function('return {' + %(tecla)s + '};')();
function caja(extra) {
  const vm = Object.assign({ online: { nuevos: 0, ultimo: null, sinVer: 0 }, panelWeb: null, esperaCaja: [], pago: null, nuevoCliente: null, pedido: null,
    sincronizar() { Q.sincs++; }, recuperar() {} }, extra || {});
  for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
  vm.tecla = T.tecla.bind(vm);
  return vm;
}
const pasar = async () => { for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r)); };
const esc = vm => vm.tecla({ key: 'Escape', preventDefault() {} });
const o = {};
Q.lista = [{ id: 1, numero: 41, estado: 'nuevo' }, { id: 2, numero: 42, estado: 'confirmado' }];

// 1. ver, cancelar y atrás: Escape primero cierra la cancelación, después el resumen y al final la ventana
let vm = caja(); vm.cargarAceptador = async () => null;
vm.abrirPanelWeb(); await pasar();
const foto = () => vm.panelWeb ? [vm.panelWeb.ver, !!vm.panelWeb.cancelar] : null;
const pasos = [];
vm.verPedidoWeb(vm.panelWeb.lista[0]); pasos.push(foto(), vm.verWeb && vm.verWeb.numero);
vm.abrirCancelarWeb(); pasos.push(foto());
esc(vm); pasos.push(foto()); esc(vm); pasos.push(foto()); esc(vm); pasos.push(foto());
o.pasos = pasos;
vm.abrirPanelWeb(); await pasar(); vm.abrirCancelarWeb(); o.cancelar_sin_resumen = foto();        // sin resumen abierto no hay qué cancelar
vm.verPedidoWeb({ id: 2 }); vm.atrasWeb(); o.boton_atras = foto(); vm.atrasWeb(); o.boton_cerrar = vm.panelWeb;

// 2. cancelar con justificación: motivo corto, error del servidor, bien
Q.llamadas = []; Q.toasts = []; Q.sincs = 0;
vm.abrirPanelWeb(); await pasar(); const p1 = vm.panelWeb.lista[0]; vm.verPedidoWeb(p1); vm.abrirCancelarWeb();
Q.llamadas = [];
vm.panelWeb.cancelar.motivo = '  corto  '; await vm.cancelarWeb(p1);
o.corto = [Q.toasts.slice(), Q.llamadas.length, !!vm.panelWeb.cancelar];
Q.toasts = []; Q.falla = 'La cuenta ya tiene cobros en la caja: anule la venta desde la caja'; vm.panelWeb.cancelar.motivo = '  Se nos acabó el pollo ';
await vm.cancelarWeb(p1);
o.error = [Q.toasts.slice(), !!vm.panelWeb.cancelar, vm.panelWeb.cancelar.enviando, vm.panelWeb.ver, Q.sincs];
Q.falla = null; Q.toasts = []; Q.llamadas = []; Q.respuesta = { id: 1, numero: 41, estado: 'cancelado', motivo: 'Se nos acabó el pollo' };
await vm.cancelarWeb(p1);
o.cancelado = [Q.llamadas.slice(), Q.toasts.slice(), vm.panelWeb.ver, vm.panelWeb.cancelar, Q.sincs, p1.estado];
Q.lista = [{ id: 1, numero: 41, estado: 'nuevo' }, { id: 2, numero: 42, estado: 'confirmado' }];
sesion.empresaInfo = { es_local: true, pedidos_programa: true }; Q.toasts = []; Q.respuesta = { id: 2, mensaje: 'Pedido #42 cancelado en la página web.' };
vm.abrirPanelWeb(); await pasar(); const p2 = vm.panelWeb.lista[1]; vm.verPedidoWeb(p2); vm.abrirCancelarWeb(); vm.panelWeb.cancelar.motivo = 'El cliente llamó para cancelar';
await vm.cancelarWeb(p2); o.cancelado_prog = Q.toasts.slice();
sesion.empresaInfo = {}; Q.respuesta = null;

// 3. «Imprimir comanda» en la página web: la lógica compartida, llamada EN EL TOQUE (sin esperar nada antes), una vez; vuelve a la lista
Q.llamadas = []; Q.toasts = []; Q.sincs = 0;
const vw = caja();
const acep = { llamado: [], resolver: null, menu: true, impresion: { cfg: {}, impresoras: [] }, conComanda: true, preparado: 0,
  async preparar() { acep.preparado++; }, aceptarComo(p, extra) { acep.llamado.push([p.id, extra]); return new Promise(r => { acep.resolver = r; }); } };
vw.cargarAceptador = async () => { vw._acep = acep; return acep; };
vw.abrirPanelWeb(); await pasar();
o.preparado = [acep.preparado, vw.panelWeb.imprime, Q.llamadas.map(l => l[0])];
const pa = vw.panelWeb.lista[0]; vw.verPedidoWeb(pa);
const pr = vw.imprimirComandaWeb(pa); o.en_el_toque = acep.llamado.slice();
const pr2 = vw.imprimirComandaWeb(pa); o.ocupado = [!!vw.panelWeb.aceptando[1], acep.llamado.length];
acep.resolver(true); await pr; await pr2;
o.impreso = [vw.panelWeb.ver, vw.panelWeb.aceptando, Q.llamadas.filter(l => l[1] === 'PUT').length];
vw.verPedidoWeb(pa); const pr3 = vw.imprimirComandaWeb(pa); acep.resolver(false); await pr3;
o.fallo = [vw.panelWeb.ver, vw.panelWeb.aceptando];
// la lógica todavía no estaba cargada: se carga y se llama igual
const vl = caja(); let cargo = 0; vl.cargarAceptador = async () => { cargo++; return cargo > 1 ? acep : null; };
vl.abrirPanelWeb(); await pasar(); acep.llamado = []; const pl = vl.imprimirComandaWeb(vl.panelWeb.lista[0]); await pasar(); acep.resolver(true); await pl;
o.carga_tarde = [cargo, acep.llamado];
// no se pudo cargar: aviso y nada más
const vx = caja(); vx.cargarAceptador = async () => null; vx.abrirPanelWeb(); await pasar(); Q.toasts = []; Q.llamadas = [];
await vx.imprimirComandaWeb(vx.panelWeb.lista[0]);
o.no_cargo = [Q.toasts.slice(), Q.llamadas.length, vx.panelWeb.aceptando, vx.panelWeb.imprime];
// el texto del botón: «Aceptar pedido» solo cuando se sabe que no sale comanda
const vy = caja(); const ac2 = { menu: false, impresion: null, conComanda: false, async preparar() {} }; vy.cargarAceptador = async () => ac2;
const imprime = async () => { vy.abrirPanelWeb(); await pasar(); return [vy.panelWeb.imprime, vy.textoImprimirWeb]; };
o.textos = [await imprime()]; ac2.menu = true; o.textos.push(await imprime()); ac2.impresion = { cfg: null, impresoras: [] }; o.textos.push(await imprime()); ac2.conComanda = true; o.textos.push(await imprime());
// la ventana se cerró mientras se leía: no se toca la que ya no está
const vz = caja(); let soltarZ = null; vz.cargarAceptador = () => new Promise(r => { soltarZ = r; }); vz.abrirPanelWeb(); const pwz = vz.panelWeb; vz.panelWeb = null; soltarZ(ac2); await pasar();
o.cerrada = [vz.panelWeb, pwz.imprime];

// 4. en el programa: «Imprimir comanda» = aceptarWeb de la 4.32 (sin «reclama»: la comanda la saca la estación); no carga la lógica de la web
sesion.empresaInfo = { es_local: true, pedidos_programa: true };
const vp = caja(); let cargas = 0; vp.cargarAceptador = async () => { cargas++; return null; };
Q.llamadas = []; Q.toasts = []; Q.sincs = 0; Q.respuesta = { id: 1, numero: 41, mensaje: 'Pedido #41 aceptado.' };
vp.abrirPanelWeb(); await pasar(); const alAbrir = Q.llamadas.map(l => l[0]);
await vp.imprimirComandaWeb(vp.panelWeb.lista[0]); await pasar();
o.programa = [alAbrir, Q.llamadas.slice(1), Q.toasts.slice(), Q.sincs, cargas, vp.panelWeb.aceptando];
sesion.empresaInfo = {}; Q.respuesta = null;

// 5. después de aceptar (lo que la lógica compartida llama «cargar»): la caja trae la cuenta y vuelve a leer la ventana
const vt = caja(); vt.cargarAceptador = async () => null; vt.abrirPanelWeb(); await pasar(); Q.llamadas = []; Q.sincs = 0;
await vt.trasAceptarWeb(); o.tras = [Q.sincs, Q.llamadas.map(l => l[0])];
vt._fuera = true; Q.sincs = 0; await vt.trasAceptarWeb(); o.tras_fuera = Q.sincs;

// 6. quién tiene «Imprimir comanda»
const vq = caja({ esperaCaja: [{ id: 900, pedido_id: 6 }] });
const puede = () => [vq.puedeImprimirWeb({ id: 1, estado: 'nuevo' }), vq.puedeImprimirWeb({ id: 1, estado: 'nuevo', atiende: 3 }), vq.puedeImprimirWeb({ id: 5, estado: 'confirmado' }),
  vq.puedeImprimirWeb({ id: 5, estado: 'confirmado', cuenta_espera_id: 'c1' }), vq.puedeImprimirWeb({ id: 5, estado: 'confirmado', documento_id: 9 }), vq.puedeImprimirWeb({ id: 6, estado: 'confirmado' }),
  vq.puedeImprimirWeb({ id: 2, estado: 'en_preparacion' }), vq.puedeImprimirWeb(null)];
o.puede_web = puede(); sesion.empresaInfo = { es_local: true, pedidos_programa: true }; o.puede_prog = puede(); sesion.empresaInfo = {};
o.opciones = [vq.opcionesWeb({ opciones: [{ nombre: 'Huevo' }, null, { nombre: '' }, { nombre: 'Queso' }] }), vq.opcionesWeb({}), vq.opcionesWeb(null)];
console.log(JSON.stringify(o));
"""


def _tecla():
    return _tramo(_js("pages/pos/caja.js"), "    tecla(e) {", "\n    },\n") + "\n    }"


def test_ver_atras_escape_cancelar_e_imprimir(tmp_path):
    o = _correr(tmp_path, GUION_METODOS % {"comp": json.dumps(_computadas()), "met": json.dumps(_metodos()), "tecla": json.dumps(_tecla())})
    assert o["pasos"] == [[1, False], 41, [1, True], [1, False], [None, False], None], o["pasos"]
    assert o["cancelar_sin_resumen"] == [None, False]
    assert o["boton_atras"] == [None, False] and o["boton_cerrar"] is None
    corto = "Escriba la justificación (al menos 8 caracteres): el cliente la ve."
    assert o["corto"] == [[[corto, "err"]], 0, True], o["corto"]                                 # sin motivo no se manda nada
    assert o["error"] == [[["La cuenta ya tiene cobros en la caja: anule la venta desde la caja", "err"]], True, False, 1, 0], o["error"]
    llamadas, avisos, ver, cancelar, sincs, estado = o["cancelado"]
    assert llamadas == [["/api/pedidos/1/estado", "PUT", {"estado": "cancelado", "motivo": "Se nos acabó el pollo"}], ["/api/pedidos", "GET", None]], llamadas
    assert avisos == [["Pedido #41 cancelado. El cliente ve el motivo.", "ok"]] and ver is None and cancelar is None and sincs == 1 and estado == "cancelado"
    assert o["cancelado_prog"] == [["Pedido #42 cancelado en la página web.", "ok"]]
    # la web: se prepara al abrir, se llama en el toque, una sola vez, y vuelve a la lista
    assert o["preparado"] == [1, True, ["/api/pedidos"]], o["preparado"]
    assert o["en_el_toque"] == [[1, None]] and o["ocupado"] == [True, 1]
    assert o["impreso"] == [None, {}, 0], o["impreso"]                                            # el PUT y la comanda los hace la lógica compartida
    assert o["fallo"] == [1, {}]                                                                  # no se pudo aceptar: el resumen sigue abierto
    assert o["carga_tarde"] == [2, [[1, None]]]
    assert o["no_cargo"] == [[["No se pudo preparar la impresión de la comanda. Revise la conexión e intente otra vez.", "err"]], 0, {}, None], o["no_cargo"]
    assert o["textos"] == [[False, "Aceptar pedido"], [None, "Imprimir comanda"], [False, "Aceptar pedido"], [True, "Imprimir comanda"]], o["textos"]
    assert o["cerrada"] == [None, None]
    al_abrir, despues, avisos, sincs, cargas, ocupado = o["programa"]
    assert al_abrir == ["/api/pedidos"] and cargas == 0, o["programa"]                           # el programa no lee lo de imprimir de la web
    assert despues == [["/api/pedidos/1/estado", "PUT", {"estado": "confirmado"}], ["/api/pedidos", "GET", None]], despues
    assert avisos == [["Pedido #41 aceptado.", "ok"]] and sincs == 1 and ocupado == {}
    assert o["tras"] == [1, ["/api/pedidos"]] and o["tras_fuera"] == 0
    assert o["puede_web"] == [True, False, True, False, False, False, False, False], o["puede_web"]
    assert o["puede_prog"] == [True, False, False, False, False, False, False, False], o["puede_prog"]
    assert o["opciones"] == ["Huevo, Queso", "", ""]


# ================================================================================================================ de punta a punta
GUION_PUNTA = BASE + r"""
const api0 = Q.api;
Q.api = async (url, opt) => {
  if (url === '/api/pedidos') { Q.llamadas.push('GET /api/pedidos'); return Q.lista; }
  if (url === '/api/pedidos/negocio') { Q.llamadas.push('GET /api/pedidos/negocio'); return { terminal_id: 1, presentacion: '' }; }
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) { Q.llamadas.push('PUT ' + url + ' ' + JSON.stringify(opt.body)); return { id: Q.pid, numero: 40 + Q.pid, estado: 'confirmado', cuenta_espera_id: 100 + Q.pid, ...(Q.alla ? { atiende: 3, atiende_nombre: 'Caja Sur' } : {}) }; }
  if (url === '/api/registros/pos_config') return { datos: Q.cfg };
  if (url === '/api/registros/pos_impresoras') return { datos: Q.imps };
  if (url === '/api/registros/categorias') return { datos: Q.cats };
  if (url === '/api/registros/items_extra') return { datos: {} };
  if (url.startsWith('/api/productos')) return Q.store.productos;
  if (url === '/api/registros/pos_espera') return { datos: [] };
  return api0(url, opt);
};
const erp = { tipo: 'restaurante', empresaInfo: { es_local: false }, usuario: { nombre: 'Ana QA', correo: 'ana@example.test' }, tieneModulo: m => m === 'pedidos_online' };
const C = new Function('sesion', 'api', 'toast', 'return { computed: {' + %(comp)s + '}, methods: {' + %(met)s + '} };')(erp, (u, o) => Q.api(u, o), (m, t) => Q.toasts.push([m, t || '']));
function caja() {
  const vm = { online: { nuevos: 1, ultimo: 1, sinVer: 0 }, panelWeb: null, esperaCaja: [], sincs: 0, sincronizar() { this.sincs++; }, recuperar() {} };
  for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
  return vm;
}
const esperar = async c => { for (let i = 0; i < 400 && !c(); i++) await new Promise(r => setTimeout(r, 5)); };
const out = {};
const web = async (pid, prep) => {
  S.copias = {}; S.filas = {}; S.t = Date.now(); limpiar(); Q.pid = pid; Q.ventanas = 0; Q.alla = false; copia(pid, { origen: 'aceptar' }); if (prep) prep();
  Q.lista = [{ id: pid, numero: 40 + pid, estado: 'nuevo', nombre: 'Ana', lineas: [] }];
  const vm = caja(); vm.abrirPanelWeb(); await esperar(() => vm.panelWeb.listo === true);   /* revisión: el botón se puede tocar (antes esperaba a `imprime`) */
  const leido = Q.llamadas.filter(x => x.startsWith('GET')).sort();
  limpiar();
  const p = vm.panelWeb.lista[0]; vm.verPedidoWeb(p);
  const pr = vm.imprimirComandaWeb(p); const toque = Q.ventanas, ocupado = !!vm.panelWeb.aceptando[pid];
  await pr;
  return { leido, imprime: vm.panelWeb.imprime, toque, ocupado, toasts: Q.toasts, impresos: Q.impresos, put: Q.llamadas.filter(x => x.startsWith('PUT')),
    nombres: [...new Set(Q.llamadas.filter(x => x.startsWith('POST /api/pos/comanda/reclamar')).map(x => JSON.parse(x.slice(x.indexOf('{'))).nombre))],
    filas: Object.entries(S.filas).map(([k, f]) => k + ':' + f.estado).sort(), sincs: vm.sincs, relee: Q.llamadas.filter(x => x === 'GET /api/pedidos').length,
    ver: vm.panelWeb.ver, aceptando: vm.panelWeb.aceptando, estado: p.estado };
};
out.web = await web(1);
out.alla = await web(2, () => { Q.alla = true; });
erp.empresaInfo = { es_local: true, pedidos_programa: true };
limpiar(); Q.pid = 3; Q.ventanas = 0; Q.lista = [{ id: 3, numero: 43, estado: 'nuevo', nombre: 'Ana', lineas: [] }];
const vp = caja(); vp.abrirPanelWeb(); await esperar(() => !vp.panelWeb.cargando); const alAbrir = Q.llamadas.slice();
await vp.imprimirComandaWeb(vp.panelWeb.lista[0]);
out.programa = { alAbrir, put: Q.llamadas.filter(x => x.startsWith('PUT')), toasts: Q.toasts, ventanas: Q.ventanas, sincs: vp.sincs, cargada: !!vp._acep };
console.log(JSON.stringify(out));
process.exit(0);
"""


def test_de_punta_a_punta_con_la_logica_compartida(tmp_path):
    falsos = dict(FALSOS_PED)
    falsos["pages/pos/_agente_real.js"] = _js("pages/pos/_agente.js")
    falsos[MODULO] = _modulo_para_node()
    met = _metodos()
    assert met.count("import('./_aceptar_pedido.js')") == 1
    met = met.replace("import('./_aceptar_pedido.js')", "import('./js/pages/pos/_aceptar_pedido.js')")   # desde la carpeta de la prueba
    r = _node(tmp_path, GUION_PUNTA % {"comp": json.dumps(_computadas()), "met": json.dumps(met)}, archivos=("pages/pos/_comandas.js",), falsos=falsos)
    w = r["web"]
    assert w["leido"] == ["GET /api/pedidos", "GET /api/pedidos/negocio"] and w["imprime"] is True, w   # al abrir: la lista, el negocio y lo de imprimir
    assert w["toque"] == 1 and w["ocupado"] is True, w                                       # la ventana del navegador se abrió en el toque
    assert len(w["put"]) == 1 and '"reclama":true' in w["put"][0] and '"estado":"confirmado"' in w["put"][0], w
    assert w["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]] and w["impresos"] == [["Cocina", "Casado"]], w
    assert w["nombres"] == ["Pedidos · Ana QA"] and w["filas"] == ["1|0:impresa", "1|1:impresa"], w
    assert w["sincs"] == 1 and w["relee"] == 1 and w["ver"] is None and w["aceptando"] == {} and w["estado"] == "confirmado", w   # A-4
    a = r["alla"]
    assert a["toasts"] == [["Pedido aceptado: lo atiende «Caja Sur»; su comanda sale allá.", "ok"]] and a["impresos"] == [] and a["sincs"] == 1, a
    p = r["programa"]
    assert p["alAbrir"] == ["GET /api/pedidos"] and p["cargada"] is False and p["ventanas"] == 0, p
    assert p["put"] == ['PUT /api/pedidos/3/estado {"estado":"confirmado"}'] and p["sincs"] == 1, p
    assert p["toasts"] == [["Pedido #43 aceptado: ya está en la caja y su comanda sale sola en unos segundos.", "ok"]], p


# ================================================================================================================ revisión (16 nov 2026)
# 1. En la página web, «Imprimir comanda» no se puede tocar hasta que la caja leyó el negocio y la configuración de impresión (antes:
#    tocado en ese lapso, la ventana del navegador se abría tarde o el pedido de un comercio con menú se aceptaba sin comanda).
# 2. En el programa, el botón dice «Aceptar pedido» cuando se sabe que no sale comanda (sin impresoras de comanda, tienda de mostrador).
# 3. Cancelar desde la caja el pedido cuya cuenta está en pantalla la cierra aquí mismo, sin el aviso falso de «otro equipo».
GUION_REVISION = r"""
/* 4.39 (tercera vuelta, T7): soltarCuentaCanceladaWeb usa lidsDeBase (caja.js lo importa de _fusion.js): el real, copiado junto a la prueba */
globalThis.lidsDeBase = (await import('./_fusion.js')).lidsDeBase;
const Q = { llamadas: [], toasts: [], sincs: [], mesas: [], lista: [], falla: null, respuesta: null };
const sesion = { empresaInfo: {}, tipo: 'restaurante', tieneModulo: x => x === 'pedidos_online' };
const api = async (url, op) => {
  Q.llamadas.push([url, op ? op.method : 'GET', op && op.body ? op.body : null]);
  if (Q.falla) throw new Error(Q.falla);
  if (url === '/api/pedidos') return Q.lista;
  if (/^\/api\/pedidos\/\d+\/estado$/.test(url)) return Q.respuesta || { id: 1 };
  throw new Error('ruta ' + url);
};
const toast = (m, t) => Q.toasts.push([m, t]);
let nId = 0; globalThis.uuid = () => 'idem-' + (++nId);
const C = new Function('sesion', 'api', 'toast', 'return { computed: {' + %(comp)s + '}, methods: {' + %(met)s + '} };')(sesion, api, toast);
function caja(extra) {
  const vm = Object.assign({ online: { nuevos: 0, ultimo: null, sinVer: 0 }, panelWeb: null, esperaCaja: [], pago: null, cobrando: false, cobroParcial: null, esRestaurante: false,
    esperaId: null, lineas: [], nombreEspera: '', nota: '', idem: 'idem-0',
    sincronizar() { Q.sincs.push(this.esperaId); }, volverAMesas(s) { Q.mesas.push(s); this.lineas = []; this.esperaId = null; this.nombreEspera = ''; }, recuperar() {} }, extra || {});
  for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
  return vm;
}
const pasar = async () => { for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r)); };
const o = {};
Q.lista = [{ id: 1, numero: 41, estado: 'nuevo' }];

// 2. el programa: si sale comanda se sabe al abrir, con lo guardado en esta computadora y sin red (las reglas de la estación de comandas)
sesion.empresaInfo = { es_local: true, pedidos_programa: true };
let IMPS = [], TS = [{ id: 1, modo: 'restaurante' }];
globalThis.impresoras = () => IMPS; globalThis.terminales = () => TS;
const vp = caja(); vp.cargarAceptador = async () => { throw new Error('el programa no carga la lógica de la página web'); };
const regla = () => { vp.abrirPanelWeb(); return [vp.panelWeb.imprime, vp.panelWeb.listo, vp.textoImprimirWeb]; };
o.prog = { sin_impresoras: regla() };
IMPS = [{ id: 1, nombre: 'Cocina', uso: 'comanda' }]; o.prog.restaurante = regla();
IMPS = [{ id: 1, nombre: 'Cocina', uso: 'comanda', activa: false }, { id: 2, nombre: 'Etiquetas', uso: 'etiquetas' }, { id: 3, nombre: 'Tiquetes', uso: 'tiquetes' }]; o.prog.sin_de_comanda = regla();
IMPS = [{ id: 1, nombre: 'Cocina' }];
sesion.tipo = 'comercio'; TS = [{ id: 1, modo: 'mostrador' }]; o.prog.mostrador = regla();
TS = [{ id: 1, modo: 'mostrador' }, { id: 2, modo: 'restaurante' }]; o.prog.comercio_con_caja_restaurante = regla();
sesion.tipo = 'restaurante'; TS = [{ id: 1, modo: 'restaurante', imprimir_comanda: false }]; o.prog.caja_sin_comanda = regla();
TS = []; o.prog.sin_cajas = regla();
globalThis.impresoras = () => { throw new Error('registro dañado'); }; o.prog.no_se_sabe = regla();
globalThis.impresoras = () => IMPS; TS = [{ id: 1, modo: 'restaurante' }];
o.prog.red = Q.llamadas.map(l => l[0]).filter(u => u !== '/api/pedidos');
IMPS = []; regla(); await pasar(); Q.llamadas = []; Q.toasts = []; Q.respuesta = { id: 1, numero: 41, mensaje: 'Pedido #41 aceptado.' };
await vp.imprimirComandaWeb(vp.panelWeb.lista[0]);                                           /* «Aceptar pedido»: el mismo aceptarWeb de la 4.32 */
o.prog.acepta = [Q.llamadas.map(l => [l[0], l[1], l[2]]), Q.toasts.slice(), Q.sincs.length];
Q.respuesta = null; Q.sincs = [];

// 1. la página web: «Imprimir comanda» espera a que termine la preparación (y no se puede tocar mientras tanto)
sesion.empresaInfo = {}; Q.llamadas = []; Q.toasts = [];
let soltarPrep = null;
const acep = { llamado: [], menu: true, impresion: { cfg: {}, impresoras: [] }, conComanda: true, preparar: () => new Promise(r => { soltarPrep = r; }),
  aceptarComo(p) { acep.llamado.push(p.id); return Promise.resolve(true); } };
const vw = caja(); vw.cargarAceptador = async () => { vw._acep = acep; return acep; };
vw.abrirPanelWeb(); await pasar();
o.web_antes = [vw.panelWeb.listo, vw.panelWeb.imprime, vw.textoImprimirWeb, vw.panelWeb.cargando, vw.panelWeb.lista.length];
await vw.imprimirComandaWeb(vw.panelWeb.lista[0]);
o.web_toque_temprano = [acep.llamado.slice(), vw.panelWeb.aceptando, Q.toasts.slice(), Q.llamadas.filter(l => l[1] === 'PUT').length];
soltarPrep(); await pasar();
o.web_despues = [vw.panelWeb.listo, vw.panelWeb.imprime, vw.textoImprimirWeb];
await vw.imprimirComandaWeb(vw.panelWeb.lista[0]);
o.web_toque = acep.llamado.slice();
// no se pudo cargar la lógica o falló la preparación: el botón se habilita igual (lo que falte se lee al tocarlo, como en Ventas en línea)
const vf = caja(); vf.cargarAceptador = async () => null; vf.abrirPanelWeb(); await pasar(); o.web_sin_logica = [vf.panelWeb.listo, vf.panelWeb.imprime, vf.textoImprimirWeb];
const vr = caja(); vr.cargarAceptador = async () => ({ menu: true, preparar: async () => { throw new Error('sin conexión'); } }); vr.abrirPanelWeb(); await pasar();
o.web_preparar_falla = [vr.panelWeb.listo, vr.panelWeb.imprime, vr.textoImprimirWeb];
// la preparación no termina: 6 s como mucho (aquí el reloj corre ya)
const st = globalThis.setTimeout, plazos = []; globalThis.setTimeout = (f, ms) => { plazos.push(ms); return st(f, 0); };
const vh = caja(); vh.cargarAceptador = () => new Promise(() => {}); vh.abrirPanelWeb(); await pasar(); await new Promise(r => st(r, 5)); globalThis.setTimeout = st;
o.web_tope = [vh.panelWeb.listo, vh.panelWeb.imprime, vh.textoImprimirWeb, plazos];
// la ventana se cerró mientras se preparaba: no se toca la que ya no está
let soltarZ = null; const vz = caja(); vz.cargarAceptador = () => new Promise(r => { soltarZ = r; }); vz.abrirPanelWeb(); const pwz = vz.panelWeb; vz.panelWeb = null; soltarZ(acep); soltarPrep(); await pasar();
o.web_cerrada = [vz.panelWeb, pwz.listo, pwz.imprime];

// 3. cancelar el pedido cuya cuenta está en pantalla
const L = (d, enviado) => ({ detalle: d, cantidad: 1, enviado: enviado === false ? null : '2026-11-16T10:00:00' });
const ped41 = () => ({ id: 1, numero: 41, estado: 'confirmado', cuenta_espera_id: 901 });
const ESP = [{ id: 901, pedido_id: 1, nombre: 'Pedido #41 · Ana' }, { id: 902, pedido_id: 2, nombre: 'Pedido #42 · Luis' }];
const cancelar = async (extra, p, falla) => {
  Q.toasts = []; Q.sincs = []; Q.mesas = []; Q.falla = null; Q.respuesta = { id: p.id, numero: p.numero, estado: 'cancelado', cuenta_espera_id: null };
  Q.lista = [p];
  const vm = caja(extra); vm.cargarAceptador = async () => null;
  vm.abrirPanelWeb(); await pasar();
  const q = vm.panelWeb.lista[0]; vm.verPedidoWeb(q); vm.abrirCancelarWeb(); vm.panelWeb.cancelar.motivo = 'El cliente llamó para cancelar';
  Q.falla = falla || null; await vm.cancelarWeb(q); Q.falla = null;
  return { toasts: Q.toasts.slice(), sincs: Q.sincs.slice(), mesas: Q.mesas.slice(), esperaId: vm.esperaId, lineas: vm.lineas.map(l => l.detalle), nombre: vm.nombreEspera, nota: vm.nota, idem: vm.idem, rapida: vm.rapida };
};
const abierta = extra => ({ esperaCaja: ESP, esperaId: 901, nombreEspera: 'Pedido #41 · Ana', nota: 'Tocar el timbre', idem: 'idem-0', lineas: [L('Casado'), L('Refresco')], ...(extra || {}) });
o.cancela = {};
o.cancela.mostrador = await cancelar(abierta(), ped41());
o.cancela.restaurante = await cancelar(abierta({ esRestaurante: true }), ped41());
o.cancela.por_cuenta = await cancelar(abierta({ esperaCaja: [] }), ped41());                      /* la lista de la caja todavía no la tenía */
o.cancela.por_parte = await cancelar(abierta({ esperaCaja: [{ id: 'p2', pedido_id: 1 }], esperaId: 'p2' }), ped41());   /* otra cuenta del mismo pedido */
o.cancela.sin_enviar = await cancelar(abierta({ esRestaurante: true, lineas: [L('Casado'), L('Flan', false)] }), ped41());
o.cancela.otra = await cancelar(abierta({ esperaId: 902, nombreEspera: 'Pedido #42 · Luis' }), ped41());
o.cancela.cobrando = await cancelar(abierta({ pago: { total: 9500 } }), ped41());
o.cancela.parcial = await cancelar(abierta({ cobroParcial: { pagado: 1000 } }), ped41());
o.cancela.rechazo = await cancelar(abierta(), ped41(), 'La cuenta ya tiene cobros en la caja: anule la venta desde la caja');
o.cancela.sin_cuenta = await cancelar({ esperaCaja: ESP }, ped41());
/* 4.39 (tercera vuelta, T7): lo no enviado que ya estaba guardado en la cuenta del pedido (su base: el envío a domicilio) se va con el pedido;
   lo agregado aquí sin guardar sigue en pantalla y, en la venta sin mesa, como venta rápida (su comanda sale al cobrarlo) */
const conBase = (lineas, extra) => abierta({ esRestaurante: true, vista: 'venta', mesaActual: null, rapida: false, _base: { id: 901, lineas: [{ lid: 'l-casado' }, { lid: 'l-envio' }] },
  lineas: [{ ...L('Casado'), lid: 'l-casado' }, { ...L('Envío a domicilio', false), lid: 'l-envio' }, ...lineas], ...(extra || {}) });
o.cancela.envio_y_flan = await cancelar(conBase([{ ...L('Flan', false), lid: 'l-flan' }]), ped41());
o.cancela.solo_envio = await cancelar(conBase([]), ped41());
o.cancela.envio_y_flan_mesa = await cancelar(conBase([{ ...L('Flan', false), lid: 'l-flan' }], { mesaActual: { id: 6, nombre: 'Mesa 6' } }), ped41());
console.log(JSON.stringify(o));
"""


def test_revision_programa_preparando_y_cancelar(tmp_path):
    # 4.39 (tercera vuelta, T7): soltarCuentaCanceladaWeb descuenta lo de la base (lidsDeBase de _fusion.js, el módulo real junto al guion)
    shutil.copyfile(JS / "pages/pos/_fusion.js", tmp_path / "_fusion.js")
    o = _correr(tmp_path, GUION_REVISION % {"comp": json.dumps(_computadas()), "met": json.dumps(_metodos())})
    IMP, ACE = "Imprimir comanda", "Aceptar pedido"
    # 2. el programa (las reglas de la estación de comandas, que es la que imprime allá); sin red al abrir
    pg = o["prog"]
    assert pg["sin_impresoras"] == [False, True, ACE] and pg["sin_de_comanda"] == [False, True, ACE], pg
    assert pg["restaurante"] == [True, True, IMP] and pg["comercio_con_caja_restaurante"] == [True, True, IMP], pg
    assert pg["mostrador"] == [False, True, ACE] and pg["caja_sin_comanda"] == [False, True, ACE], pg
    assert pg["sin_cajas"] == [None, True, IMP] and pg["no_se_sabe"] == [None, True, IMP], pg     # no se pudo saber: como antes
    assert pg["red"] == [], pg
    llamadas, avisos, sincs = pg["acepta"]
    # 4.39 (duodécima vuelta): con «Aceptar pedido» (aquí sin impresoras de comanda: se sabe que no sale) el aviso ya no es el del servidor (que dice que
    # la comanda sale sola) sino «aceptado: ya está en la caja»; lo que se manda y lo que se trae, igual
    assert llamadas == [["/api/pedidos/1/estado", "PUT", {"estado": "confirmado"}], ["/api/pedidos", "GET", None]] and avisos == [["Pedido #41 aceptado: ya está en la caja.", "ok"]] and sincs == 1, pg["acepta"]
    # 1. la página web
    assert o["web_antes"] == [False, None, "Preparando…", False, 1], o["web_antes"]              # la lista ya se ve; el botón todavía no
    assert o["web_toque_temprano"] == [[], {}, [], 0], o["web_toque_temprano"]                   # tocado antes de tiempo: nada (ni aceptar)
    assert o["web_despues"] == [True, True, IMP] and o["web_toque"] == [1], o
    assert o["web_sin_logica"] == [True, None, IMP] and o["web_preparar_falla"] == [True, None, IMP], o
    assert o["web_tope"] == [True, None, IMP, [6000]], o["web_tope"]
    assert o["web_cerrada"] == [None, False, None], o["web_cerrada"]
    # 3. cancelar con la cuenta del pedido en pantalla: se cierra aquí antes de traer lo del servidor (sincronizar ve esperaId vacío: sin el
    #    aviso de «otro equipo»); sin cobro en curso, solo la de ese pedido, y solo si el servidor la canceló
    c = o["cancela"]
    ok = [["Pedido #41 cancelado. El cliente ve el motivo.", "ok"]]
    m = c["mostrador"]
    assert m["toasts"] == ok and m["sincs"] == [None] and m["mesas"] == [] and m["esperaId"] is None and m["lineas"] == [], m
    assert m["nombre"] == "" and m["nota"] == "" and m["idem"] not in ("idem-0", None), m
    r = c["restaurante"]
    assert r["mesas"] == [True] and r["sincs"] == [None] and r["esperaId"] is None and r["toasts"] == ok, r   # como una cuenta cerrada (sin mesas: venta rápida, frente B)
    for k in ("por_cuenta", "por_parte"):
        assert c[k]["esperaId"] is None and c[k]["sincs"] == [None] and c[k]["lineas"] == [], (k, c[k])
    s = c["sin_enviar"]
    assert s["lineas"] == ["Flan"] and s["esperaId"] is None and s["nombre"] == "" and s["mesas"] == [], s
    assert s["toasts"] == ok + [["Lo que no se había enviado a cocina sigue en pantalla como una cuenta nueva.", "ok"]], s
    for k, ident in (("otra", 902), ("cobrando", 901), ("parcial", 901)):
        assert c[k]["esperaId"] == ident and c[k]["lineas"] == ["Casado", "Refresco"] and c[k]["sincs"] == [ident] and c[k]["mesas"] == [], (k, c[k])
    rz = c["rechazo"]
    assert rz["toasts"] == [["La cuenta ya tiene cobros en la caja: anule la venta desde la caja", "err"]] and rz["esperaId"] == 901 and rz["sincs"] == [], rz
    assert rz["lineas"] == ["Casado", "Refresco"] and rz["nombre"] == "Pedido #41 · Ana"
    assert c["sin_cuenta"]["esperaId"] is None and c["sin_cuenta"]["toasts"] == ok and c["sin_cuenta"]["sincs"] == [None], c["sin_cuenta"]
    # 4.39 (tercera vuelta, T7): el envío a domicilio (guardado en la cuenta del pedido, sin enviar) se va con el pedido cancelado: ya no queda
    # para cobrarlo. Lo agregado aquí sin guardar (el Flan) sigue como cuenta nueva y, sin mesa, como venta rápida (su comanda sale al cobrarlo)
    ef = c["envio_y_flan"]
    assert ef["lineas"] == ["Flan"] and ef["esperaId"] is None and ef["rapida"] is True and ef["mesas"] == [], ef
    assert ef["toasts"] == ok + [["Lo que no se había enviado a cocina sigue en pantalla como una cuenta nueva.", "ok"]], ef
    se = c["solo_envio"]                                                                      # nada más que el envío: se cierra como una cuenta cerrada
    assert se["lineas"] == [] and se["esperaId"] is None and se["mesas"] == [True] and se["toasts"] == ok, se
    em = c["envio_y_flan_mesa"]                                                               # en una mesa no pasa a venta rápida
    assert em["lineas"] == ["Flan"] and em["rapida"] is False and em["esperaId"] is None, em
    assert s.get("rapida") is None, s                              # sin_enviar (sin base ni vista): como antes, solo queda lo no enviado


# Revisión 1 de punta a punta, con el aceptador de verdad y el servidor lento: el cajero toca apenas ve la lista. Antes: en un restaurante la
# ventana del navegador no se abría en el toque (0 y después 1) y en un comercio con menú el pedido se aceptaba sin comanda. Ahora el toque
# temprano no hace nada, el botón dice «Preparando…» y, cuando se habilita, imprime como Ventas en línea. El restaurante lee el negocio y
# la impresión a la vez; el comercio, primero el negocio (dice si usa menú).
GUION_TIEMPOS = BASE + r"""
const api0 = Q.api;
const tarde = (ms, v) => new Promise(r => setTimeout(() => r(v), ms));
Q.pres = '';
Q.api = async (url, opt) => {
  if (url === '/api/pedidos') { Q.llamadas.push('GET /api/pedidos'); return tarde(10, Q.lista); }
  if (url === '/api/pedidos/negocio') { Q.llamadas.push('GET /api/pedidos/negocio'); const n = await tarde(150, { terminal_id: 1, presentacion: Q.pres }); Q.llamadas.push('FIN /api/pedidos/negocio'); return n; }
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) { Q.llamadas.push('PUT ' + url + ' ' + JSON.stringify(opt.body)); return { id: Q.pid, numero: 40 + Q.pid, estado: 'confirmado', cuenta_espera_id: 100 + Q.pid }; }
  if (url === '/api/registros/pos_config') { Q.llamadas.push('GET ' + url); return tarde(150, { datos: Q.cfg }); }
  if (url === '/api/registros/pos_impresoras') { Q.llamadas.push('GET ' + url); return tarde(150, { datos: Q.imps }); }
  if (url === '/api/registros/categorias') return { datos: Q.cats };
  if (url === '/api/registros/items_extra') return { datos: {} };
  if (url.startsWith('/api/productos')) return Q.store.productos;
  if (url === '/api/registros/pos_espera') return { datos: [] };
  return api0(url, opt);
};
const erp = { tipo: 'restaurante', empresaInfo: { es_local: false }, usuario: { nombre: 'Ana QA', correo: 'ana@example.test' }, tieneModulo: m => m === 'pedidos_online' };
const C = new Function('sesion', 'api', 'toast', 'return { computed: {' + %(comp)s + '}, methods: {' + %(met)s + '} };')(erp, (u, o) => Q.api(u, o), (m, t) => Q.toasts.push([m, t || '']));
function caja() {
  const vm = { online: { nuevos: 1, ultimo: 1, sinVer: 0 }, panelWeb: null, esperaCaja: [], sincs: 0, sincronizar() { this.sincs++; }, recuperar() {} };
  for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
  return vm;
}
const esperar = async c => { for (let i = 0; i < 400 && !c(); i++) await new Promise(r => setTimeout(r, 2)); };
const out = {};
const tocarApenasSeVe = async (pid, tipo, pres) => {
  S.copias = {}; S.filas = {}; S.t = Date.now(); limpiar(); Q.pid = pid; Q.ventanas = 0; erp.tipo = tipo; Q.pres = pres; copia(pid, { origen: 'aceptar' });
  Q.lista = [{ id: pid, numero: 40 + pid, estado: 'nuevo', nombre: 'Ana', lineas: [] }];
  const vm = caja(); vm.abrirPanelWeb(); await esperar(() => !vm.panelWeb.cargando && vm.panelWeb.lista.length);
  const alVer = [vm.textoImprimirWeb, vm.panelWeb.listo];
  const t0 = vm.imprimirComandaWeb(vm.panelWeb.lista[0]); const ventanaTemprana = Q.ventanas; await t0;
  const temprano = [ventanaTemprana, Q.llamadas.filter(x => x.startsWith('PUT')).length, Q.toasts.slice()];
  await esperar(() => vm.panelWeb.listo === true);
  const orden = Q.llamadas.filter(x => /negocio|pos_config|pos_impresoras/.test(x));
  const etiqueta = vm.textoImprimirWeb;
  const pr = vm.imprimirComandaWeb(vm.panelWeb.lista[0]); const enElToque = Q.ventanas;
  await pr;
  return { alVer, temprano, orden, etiqueta, enElToque, despues: Q.ventanas, toasts: Q.toasts, impresos: Q.impresos, put: Q.llamadas.filter(x => x.startsWith('PUT')), sincs: vm.sincs };
};
out.restaurante = await tocarApenasSeVe(1, 'restaurante', '');
out.comercio_menu = await tocarApenasSeVe(2, 'comercio', 'menu');
out.comercio_catalogo = await tocarApenasSeVe(3, 'comercio', '');
console.log(JSON.stringify(out));
process.exit(0);
"""


def test_revision_tocar_apenas_se_ve_la_lista(tmp_path):
    falsos = dict(FALSOS_PED)
    falsos["pages/pos/_agente_real.js"] = _js("pages/pos/_agente.js")
    falsos[MODULO] = _modulo_para_node()
    met = _metodos().replace("import('./_aceptar_pedido.js')", "import('./js/pages/pos/_aceptar_pedido.js')")
    r = _node(tmp_path, GUION_TIEMPOS % {"comp": json.dumps(_computadas()), "met": json.dumps(met)}, archivos=("pages/pos/_comandas.js",), falsos=falsos)
    NEG, FIN, CFG, IMPS = "GET /api/pedidos/negocio", "FIN /api/pedidos/negocio", "GET /api/registros/pos_config", "GET /api/registros/pos_impresoras"
    for nombre in ("restaurante", "comercio_menu"):
        x = r[nombre]
        assert x["alVer"] == ["Preparando…", False], (nombre, x)                                 # la lista se ve antes de que el botón esté listo
        assert x["temprano"] == [0, 0, []], (nombre, x)                                          # el toque temprano no acepta nada
        assert x["etiqueta"] == "Imprimir comanda" and x["enElToque"] == 1 and x["despues"] == 1, (nombre, x)   # la ventana se abre en el toque
        assert len(x["put"]) == 1 and '"reclama":true' in x["put"][0], (nombre, x)
        assert x["toasts"] == [["Pedido aceptado y comanda impresa.", "ok"]] and x["impresos"] == [["Cocina", "Casado"]] and x["sincs"] == 1, (nombre, x)
    o = r["restaurante"]["orden"]
    assert o.index(CFG) < o.index(FIN) and o.index(IMPS) < o.index(FIN), o                     # el restaurante lee todo a la vez
    o = r["comercio_menu"]["orden"]
    assert o.index(FIN) < o.index(CFG) and o.index(FIN) < o.index(IMPS), o                     # el comercio sabe si usa menú por el negocio
    k = r["comercio_catalogo"]                                                                  # sin menú: «Aceptar pedido», sin comanda ni ventana
    assert k["alVer"] == ["Preparando…", False] and k["etiqueta"] == "Aceptar pedido" and k["enElToque"] == 0 and k["impresos"] == [], k
    assert k["toasts"] == [["Pedido actualizado.", "ok"]] and k["orden"] == [NEG, FIN], k


# ================================================================================================================ fuente, textos y sintaxis
def test_fuente_sin_el_enlace_viejo_y_con_las_reglas_de_escritura():
    k = _js("pages/pos/caja.js")
    assert "Aceptar en Pedidos" not in k and "ábralo en Ventas en línea › Pedidos" not in k
    assert k.count("import('./_aceptar_pedido.js')") == 1 and "from './_aceptar_pedido.js'" not in k   # se carga al abrir la ventana: si no carga, la caja sigue
    assert '<Modal v-if="panelWeb" title="Pedidos en línea" lg @close="panelWeb=null">' in k
    assert "else if (this.panelWeb) this.atrasWeb();" in _tecla()
    assert k.count('@click="abrirPanelWeb"') == 2 and k.count('v-if="conPedidosWeb" @click="abrirPanelWeb"') == 2   # sin pedidos en línea no se abre
    assert "if (!sesion.tieneModulo('pedidos_online')) return;" in _tramo(k, "    async revisarOnline() {", "\n    },\n")
    # en el programa, «Imprimir comanda» pasa por el aceptarWeb de la 4.32; aceptado, baja el número del botón y vuelve a la lista (prueba de punta a punta)
    assert "if (this.enProgWeb) { const ok = await this.aceptarWeb(p);" in _metodos()
    v = re.sub(r"<!--.*?-->", "", _tramo(k, '    <Modal v-if="panelWeb"', "    </Modal>"))
    assert v.count("← Atrás") == 2 and v.index('data-atras-web') < v.index("Pedido #{{verWeb.numero}}")   # arriba a la izquierda, antes del título
    nuevas = [l for l in k.splitlines() if "4.39" in l or re.search(r"\b(verWeb|atrasWeb|imprimirComandaWeb|cancelarWeb|prepararWeb|cargarAceptador|trasAceptarWeb|puedeImprimirWeb|opcionesWeb|abrirCancelarWeb|verPedidoWeb|textoImprimirWeb)\b", l)]
    assert len(nuevas) > 25
    for l in nuevas:
        if l.strip().startswith("//"):
            continue
        assert not re.search(r"(?<![:\"'])//(?!/)", l.replace("http://", "").replace("https://", "")), l   # ningún comentario «//» en línea
        assert not re.search(r'@(click|submit\.prevent|change)="[^"]*\bif\b', l), l
    # textos para el usuario sin palabras técnicas (avisos y plantilla nueva)
    textos = re.findall(r"toast\('([^']*)'", "\n".join(nuevas)) + re.findall(r">([^<>{}]*[A-Za-zÁÉÍÓÚáéíóúñ][^<>{}]*)<", v)
    assert textos and not [t for t in textos if re.search(r"sincroniz|token|\bAPI\b|servidor|módulo|error|null|undefined", t, re.I)], textos


def test_sintaxis_plantilla_y_finales_de_linea(tmp_path):
    from tests.test_424_etiquetas import COMPILAR_JS
    node = _nodo()
    for rel in ("pages/pos/caja.js", MODULO, "fis/pages/pedidos.js"):
        b = (JS / rel).read_bytes()
        assert b.count(b"\r\n") == 0, rel                                                   # los tres son LF
    if not node:
        pytest.skip("sin Node.js en este equipo")
    for rel in ("pages/pos/caja.js", MODULO):
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_bytes((JS / rel).read_bytes())
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, encoding="utf-8", timeout=60)
        assert out.returncode == 0, (rel, out.stderr[-2000:])
    shutil.copy(JS / "vendor" / "vue.esm-browser.prod.min.js", tmp_path / "vue.mjs")
    (tmp_path / "compilar.mjs").write_text(COMPILAR_JS, encoding="utf-8")
    (tmp_path / "caja.js").write_bytes((JS / "pages/pos/caja.js").read_bytes())
    r = subprocess.run([node, "compilar.mjs", "caja.js"], capture_output=True, text=True, encoding="utf-8", timeout=180, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    o = json.loads(r.stdout)
    assert o["caja.js"]
    for p in o["caja.js"]:
        assert p["errores"] == [] and p["desbalance"] == [], p
