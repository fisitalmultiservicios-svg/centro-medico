"""3.62: fecha del hotel (auditoría nocturna). Con hotel_config.fecha_hotel, las tareas automáticas del servidor trabajan con la
fecha del registro hotel_fecha (que avanza al cerrar el día), nunca con una fecha posterior al calendario."""
from datetime import timedelta

from sqlmodel import Session, select

from app import modulos
from app.config import ahora_cr
from app.db import Empresa, engine, engine_empresa, init_db


def _poner(s, eid, clave, datos):
    """Escribe un registro exista o no (reemplazar sin versión sobre uno existente pide recargar la página)."""
    r = modulos._registro(s, eid, clave)
    modulos.reemplazar(s, eid, clave, datos, version=(r.version or 0) if r is not None else 0)


def _empresa():
    init_db()
    with Session(engine) as s:
        e = s.exec(select(Empresa).where(Empresa.nombre == "Hotel Fecha 362 QA")).first()
        if not e:
            e = Empresa(nombre="Hotel Fecha 362 QA", numero_id="3101362362", actividad="551001", otras_senas="Montaña", correo="hotel362@example.test", ambiente="sandbox", tipo_negocio="hospitalidad")
            s.add(e); s.commit(); s.refresh(e)
        s.expunge(e)
    return e


def _reservas(hoy_hotel):
    ayer = (hoy_hotel - timedelta(days=1)).isoformat()
    manana = (hoy_hotel + timedelta(days=1)).isoformat()
    return [
        {"id": 1, "tipo": "reserva", "numero": "R-0001", "estado": "confirmada", "huesped_id": None, "huesped_nombre": "Llegó ayer y no apareció", "llegada": ayer, "salida": manana, "creado": ayer + "T10:00:00"},
        {"id": 2, "tipo": "reserva", "numero": "R-0002", "estado": "confirmada", "huesped_id": None, "huesped_nombre": "Llega mañana (según el hotel)", "llegada": manana, "salida": (hoy_hotel + timedelta(days=3)).isoformat(), "creado": ayer + "T10:00:00"},
    ]


def test_tareas_diarias_usan_la_fecha_del_hotel():
    from app.main import hotel_diario_empresa
    e = _empresa()
    hoy_cal = ahora_cr().date()
    hoy_hotel = hoy_cal - timedelta(days=3)                 # el hotel lleva tres días sin cerrar
    with Session(engine_empresa(e.id)) as s:
        _poner(s, e.id, "hotel_config", {"activo": True, "nombre": "Hotel Fecha", "fecha_hotel": True, "ical_auto": False, "no_show_auto": True, "no_show_dias": 1,
                                                     "recordatorio_adelanto": False, "recordatorio_llegada": False, "salida_tardia_auto": False})
        _poner(s, e.id, "hotel_fecha", {"fecha": hoy_hotel.isoformat(), "usuario": "qa"})
        _poner(s, e.id, "hotel_reservas", _reservas(hoy_hotel))
        _poner(s, e.id, "hotel_diario", {"fecha": ""})
    r = hotel_diario_empresa(e, forzar=True)
    assert r.get("motivo") != "hotel inactivo"
    with Session(engine_empresa(e.id)) as s:
        res = {x["numero"]: x for x in modulos.leer(s, e.id, "hotel_reservas", [])}
        marca = modulos.leer(s, e.id, "hotel_diario", None) or {}
    assert res["R-0001"]["estado"] == "no_show"                      # un día después de la llegada según la fecha del hotel
    assert res["R-0002"]["estado"] == "confirmada"                   # llega «mañana» para el hotel aunque el calendario ya pasó
    assert str(marca.get("fecha", ""))[:10] == hoy_hotel.isoformat()


def test_fecha_del_hotel_nunca_adelanta_al_calendario():
    from app.main import hotel_diario_empresa
    e = _empresa()
    hoy_cal = ahora_cr().date()
    with Session(engine_empresa(e.id)) as s:
        _poner(s, e.id, "hotel_config", {"activo": True, "nombre": "Hotel Fecha", "fecha_hotel": True, "ical_auto": False, "no_show_auto": False,
                                                     "recordatorio_adelanto": False, "recordatorio_llegada": False, "salida_tardia_auto": False})
        _poner(s, e.id, "hotel_fecha", {"fecha": (hoy_cal + timedelta(days=5)).isoformat(), "usuario": "qa"})   # registro corrupto: en el futuro
        _poner(s, e.id, "hotel_diario", {"fecha": ""})
    hotel_diario_empresa(e, forzar=True)
    with Session(engine_empresa(e.id)) as s:
        marca = modulos.leer(s, e.id, "hotel_diario", None) or {}
    assert str(marca.get("fecha", ""))[:10] == hoy_cal.isoformat()


def test_sin_fecha_del_hotel_se_usa_el_calendario():
    from app.main import hotel_diario_empresa
    e = _empresa()
    hoy_cal = ahora_cr().date()
    with Session(engine_empresa(e.id)) as s:
        _poner(s, e.id, "hotel_config", {"activo": True, "nombre": "Hotel Fecha", "fecha_hotel": False, "ical_auto": False, "no_show_auto": False,
                                                     "recordatorio_adelanto": False, "recordatorio_llegada": False, "salida_tardia_auto": False})
        _poner(s, e.id, "hotel_fecha", {"fecha": (hoy_cal - timedelta(days=9)).isoformat(), "usuario": "qa"})
        _poner(s, e.id, "hotel_diario", {"fecha": ""})
    hotel_diario_empresa(e, forzar=True)
    with Session(engine_empresa(e.id)) as s:
        marca = modulos.leer(s, e.id, "hotel_diario", None) or {}
    assert str(marca.get("fecha", ""))[:10] == hoy_cal.isoformat()
