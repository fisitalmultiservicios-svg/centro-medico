# -*- coding: utf-8 -*-
"""4.39, séptima vuelta de los arreglos de la comanda automática al cobrar (17 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py y las ayudas de las vueltas tercera a sexta: destinoDe e impresoraDe reales, la Cocina como única
impresora de comanda y cada comanda anotada).

- X1 emitirCobro y reclamarHab: si arriba se esperó la comanda de otro equipo (la marca), en la mesa (V2, V3) y en la cuenta guardada sin
  mesa sin platos por enviar se junta después de esperar: si mientras tanto otro equipo cambió la cuenta, no se cobra ni se carga nada.
- X7 si al juntar llegó una comanda más nueva del otro equipo (la marca se renovó), se espera también esa y se junta otra vez (V2, V3, los
  bucles de la venta rápida R2 y R7, y «Cobrar parte»): la segunda comanda del otro equipo sale.
- X5 «Cobrar parte» junta (sin esperar) aunque la comanda del otro equipo sea vieja: lo que queda en la cuenta queda enviado.
- X6 «Dividir» avisa y se cierra si el servidor tiene enviado un plato que aquí sigue sin enviar, aunque la comanda sea vieja; al volver a
  abrirlo todo está enviado. Separar, pasar a una mesa o partir una cuenta guardada traen la lista aunque todo esté enviado.
- X2 «Dividir» que esperó la marca mira otra vez la cuenta: si otro equipo la cambió, no se parte.
- D0 separar, pasar a una mesa o partir una cuenta que otro equipo ya cobró no deja sus platos en una cuenta nueva.
- X3 la cuenta que ya no está después de esperar (V2, V3): sin el aviso «ya se cobró»; solo el de siempre de sincronizar.
- X0 (la comanda de la parte de la venta rápida, quitada) se prueba en tests/test_439_sexta_vuelta.py (test_w2_...).
Un solo equipo: los cobros, «Cobrar parte», separar y pasar a una mesa no esperan; separar, pasar o partir una cuenta guardada traen la
lista una vez (1,5 s como mucho) y nada más.
Cada caso corre también, cuando muestra el defecto, con los métodos de ANTES de esta vuelta: se sacan de caja.js con la séptima vuelta
deshecha (SEPTIMA y _caja_sin_septima de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la
vuelta) y ahí se ve el defecto que el cambio arregla.
4.39 (octava vuelta): el contrato compara la séptima vuelta contra caja.js sin la octava (OCTAVA y _caja_sin_octava de
tests/test_439_tercera_vuelta.py); lo de la octava vuelta se prueba en tests/test_439_octava_vuelta.py.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import _metodo
from tests.test_439_cuarta_vuelta import AVISO_DIVIDIR, AVISO_DIVIDIR_7, MEDIAS
from tests.test_439_revision_arreglos import EMITIR, RECLAMAR, SOLTAR
from tests.test_439_sexta_vuelta import _correr as _correr6
from tests.test_439_tercera_vuelta import AMBOS, CAMBIO, CAMBIO_HAB, NO_HAY, RECIENTE, SEPTIMA, VIGENTE, _caja_sin_octava, _caja_sin_septima, _caja_sin_sexta

# los métodos que cambió la séptima vuelta (cada tripleta de SEPTIMA está en uno de ellos)
CAMBIADOS = ("enviarComanda() {", "comandaNumerada(modo,", "async cobrarParte(n) {", "async confirmarDividir() {", "async cobroOcupado(r) {",
             "async reclamarHab() {", "async emitirCobro(otra) {")
COBRADA = "Esta cuenta ya se cobró en otro equipo, completa o en parte. Revise el total antes de cobrar."
CAMBIO_DIV = "La cuenta cambió en otro equipo mientras se esperaba. Vuelva a dividir."
NEUTRO = "Aquí no se cobró ni se cargó nada: la cuenta cambió en otro equipo. Revísela antes de cobrar."
CERRADA_M6 = "La cuenta «Mesa 6» fue cobrada o cerrada en otro equipo"
CERRADA_C1 = "La cuenta «Cuenta 1» fue cobrada o cerrada en otro equipo"
CASADO1, POSTRE1, LIMONADA1 = ["Casado×1"], ["Postre×1"], ["Limonada×1"]
CON_LIM = ["Casado×1", "Limonada×1", "Postre×1"]
MEDIAS_LIM = ["Casado×0.5", "Limonada×0.5", "Postre×0.5"]


def _antes(cabezas=CAMBIADOS):
    """Los métodos que cambió la séptima vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k = _caja_sin_septima()
    return tuple(_metodo(k, c) for c in cabezas)


AYUDAS = r"""
const CAMBIO_DIV = @CAMBIO_DIV@, NEUTRO = @NEUTRO@;
// ese plato de la cuenta `id` del servidor ya figura enviado
const enviadoEnSrv = (id, d) => { const c = S.items.find(x => x.id === id); return !!c && (c.lineas || []).some(l => l.detalle === d && l.enviado); };
// B quita el Postre (en su pantalla) y guarda la cuenta
async function quitarPostre(b) { b.lineas = b.lineas.filter(l => l.detalle !== 'Postre'); b.persistirCuenta(); await b.A.mock.guardarTodo(); }
// B pasa todos sus platos a la Mesa 7 con «Dividir» (la cuenta de la Mesa 6 se cierra)
async function todoA7(b) {
  b.mesas = [M6, M7]; b._alDia = 0; await b.abrirDividir(); if (!b.dividir) return false;
  b.dividir.destino = 7; b.dividir.sel = Object.fromEntries(b.lineas.map((l, i) => [i, +l.cantidad])); await b.confirmarDividir(); await b.A.mock.guardarTodo(); return true;
}
// los avisos de esta vuelta y los del cobro
const cambioDividir = vm => avisos(vm).filter(t => t === CAMBIO_DIV);
const neutros = vm => avisos(vm).filter(t => t === NEUTRO);
const delCobroA = vm => avisos(vm).filter(x => x === CAMBIO || x === CAMBIO_HAB || x === AVISO_COBRADA);
// la hoja de la habitación de ESE equipo queda anotada (HOJAS)
const hojaHab = vm => { HOJAS.length = 0; vm.comandaHab = (r, ls) => HOJAS.push(ls.map(l => l.detalle + '×' + l.cantidad).sort()); };
// la cuenta con Casado y Postre sin enviar en A y en B: la Mesa 6 (mesa) o la cuenta guardada sin mesa (guardada)
async function cuenta(mesa, platos) {
  if (mesa) return mesaGuardada(platos || [CASADO(), POSTRE()]);
  const id = await guardada(platos || [CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id); return [id, a, b];
}
"""


def _correr(tmp_path, casos, antes=()):
    guion = AYUDAS.replace("@CAMBIO_DIV@", json.dumps(CAMBIO_DIV)).replace("@NEUTRO@", json.dumps(NEUTRO)) + casos
    return _correr6(tmp_path, guion, antes=antes)


# ================================================================================================================ X1: juntar después de la marca
CASOS_X1 = r"""
// la cuenta (`kind`: mesa, la Mesa 6; guardada, la cuenta guardada sin mesa; con «_lim», A agrega además una Limonada sin guardar: un plato por
// enviar) con Casado y Postre sin enviar, abierta en A y en B. B toca «Comanda» (sale enseguida); A la ve al sincronizar (la marca), abre el cobro
// (o, con `hab`, la ventana de la habitación) y toca «Cobrar» («Cargar»): espera la marca. A los 1,5 s, B (`que`) quita el Postre (quita) o nada
// (nada). Después, si A quedó con la ventana abierta, vuelve a tocar «Cobrar» («Cargar»)
async function x1(kind, hab, que) {
  const [id, a, b] = await cuenta(kind.startsWith('mesa'));
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  await a.sincronizar(); const m0 = marca(a);
  if (kind.endsWith('_lim')) a.lineas.push(LIMONADA());
  if (hab) { a.habCargo = HAB(); hojaHab(a); a.habCargo.reserva_id = 1; } else await a.abrirPago();
  const t0 = Date.now(); let fin = 0;
  const pa = (hab ? a.cargarAHabitacion() : a.cobrar()).then(() => { fin = Date.now(); });
  await espera(1500); if (que === 'quita') await quitarPostre(b);
  const srvB = srv();
  await pa; const t = fin - t0; await hastaLibre(); await a.A.mock.guardarTodo();
  const r = { m0: !!m0, t, srvB, impresos: quienes(a), hechos: cobrados(a), folios: folios(), avisos: delCobroA(a), cerradas: cerradas(a), tras: est(a), srv: srv(), libre: libre(), orden: orden(a.nEq) };
  if (hab ? a.habCargo : a.pago) {
    if (hab) await cargar(a); else { await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); }
    r.luego = { hechos: cobrados(a), folios: folios(), impresos: quienes(a), srv: srv(), libre: libre(), fin: est(a) };
  }
  return r;
}
for (const que of @QUES@) out[que] = await x1(@KIND@, @HAB@, que);
"""
X1_KINDS = ["mesa", "mesa_lim", "guardada", "guardada_lim"]


@pytest.mark.parametrize("kind", X1_KINDS)
@pytest.mark.parametrize("hab", [False, True])
def test_x1_despues_de_esperar_la_marca_se_junta_lo_del_otro_equipo_en_node(tmp_path, hab, kind):
    casos = CASOS_X1.replace("@KIND@", json.dumps(kind)).replace("@HAB@", json.dumps(hab))
    r = _correr(tmp_path / "ahora", casos.replace("@QUES@", json.dumps(["quita", "nada"])))
    nombre, lim = ("Mesa 6" if kind.startswith("mesa") else "Cuenta 1"), kind.endswith("_lim")
    cambio = CAMBIO_HAB if hab else CAMBIO
    resto, todo = sorted(CASADO1 + (LIMONADA1 if lim else [])), sorted(AMBOS + (LIMONADA1 if lim else []))
    de_a = [["A", LIMONADA1]] if kind == "guardada_lim" else []     # la Limonada de la cuenta guardada sale a cocina al cobrarla (la mesa, no)

    def folio(ps):
        return sorted(p.split("×")[0] + " (" + nombre + ")" for p in ps)

    for que in ("quita", "nada"):
        x = r[que]
        # A vio la comanda de B al sincronizar (la marca) y esperó; la comanda de B salió una vez; el cobro pedido quedó libre
        assert x["m0"] is True and 3500 <= x["t"] < 7000 and x["libre"] is True and x["cerradas"] == [] and x["impresos"][:1] == [["B", AMBOS]], (hab, kind, que, x)
    q = r["quita"]
    # B quitó el Postre durante la espera: no se cobra ni se carga nada, el aviso, el cobro pedido queda libre y la ventana sigue abierta con lo que
    # quedó; al tocar otra vez se cobra (o se carga) una vez lo que quedó
    assert q["srvB"] == [[nombre, CASADO1, None]] and q["hechos"] == [] and q["folios"] == [] and q["avisos"] == [cambio] and q["orden"] == [RECLAMAR, SOLTAR], (hab, kind, q)
    assert q["tras"] == {**q["tras"], "pago": not hab, "hab": hab, "platos": resto}, (hab, kind, q)
    lu = q["luego"]
    assert (lu["folios"] == folio(resto) and lu["hechos"] == []) if hab else (lu["hechos"] == [["A", resto]] and lu["folios"] == []), (hab, kind, q)
    assert lu["impresos"] == [["B", AMBOS]] + de_a and lu["srv"] == [] and lu["libre"] is True and lu["fin"]["pago"] is False and lu["fin"]["hab"] is False, (hab, kind, q)
    n = r["nada"]
    # sin cambios: se cobra (o se carga) una vez, entera
    assert n["avisos"] == [] and n["srv"] == [] and "luego" not in n and n["impresos"] == [["B", AMBOS]] + de_a, (hab, kind, n)
    assert (n["folios"] == folio(todo) and n["hechos"] == []) if hab else (n["hechos"] == [["A", todo]] and n["folios"] == []), (hab, kind, n)
    if kind == "guardada_lim":
        return   # control: con un plato por enviar, la cuenta guardada sin mesa va por la revisión de la venta rápida (R2, R7), que ya juntaba

    # antes de esta vuelta: después de esperar la marca no se juntaba (en la mesa sin platos que esperar, en la mesa con platos por enviar que no
    # eran de esa comanda y en la cuenta guardada sin platos por enviar): se cobraba (o cargaba) también el Postre que B ya había quitado
    v = _correr(tmp_path / "antes", casos.replace("@QUES@", json.dumps(["quita"])), antes=_antes())["quita"]
    assert v["avisos"] == [] and v["srvB"] == [[nombre, CASADO1, None]], (hab, kind, v)
    assert (v["folios"] == folio(todo)) if hab else (v["hechos"] == [["A", todo]]), (hab, kind, v)


# ================================================================================================================ X7: la segunda comanda del otro equipo
CASOS_X7 = r"""
// la cuenta con Casado y Postre sin enviar, abierta en A y en B (la Mesa 6; en r2 y r7, la cuenta guardada sin mesa). A agrega la Limonada y la
// guarda sin enviar (B no la tiene en pantalla). B toca «Comanda» (su revisión, lenta: 1,5 s): salen el Casado y el Postre. En cuanto el guardado
// de B llegó al servidor, A toca «Cobrar» (v2, r2), «Cargar» (v3, r7) o «Cobrar parte 1 de 2» (parte, y cobra la parte) y espera la comanda de B.
// Cuando su revisión terminó, B sincroniza (le llega la Limonada sin enviar; la lista, lenta) y a los 3 s de la primera toca «Comanda» otra vez: la
// Limonada (otra revisión lenta, 1,5 s)
async function x7(via) {
  const hab = via === 'v3' || via === 'r7';
  const [id, a, b] = await cuenta(via !== 'r2' && via !== 'r7');
  a.lineas.push(LIMONADA()); a.persistirCuenta(); await a.A.mock.guardarTodo();
  if (hab) { a.habCargo = HAB(); hojaHab(a); a.habCargo.reserva_id = 1; } else if (via !== 'parte') await a.abrirPago();
  const suelta = lento(b, 1500), tB = Date.now();
  const pb1 = b.enviarComanda(); await hasta(() => enviadoEnSrv(id, 'Casado'));
  const t0 = Date.now(); let fin = 0;
  const pa = (via === 'parte' ? (async () => { await a.cobrarParte(2); await conPago(a); if (a.pago) await a.cobrar(); })() : hab ? a.cargarAHabitacion() : a.cobrar()).then(() => { fin = Date.now(); });
  await pb1; suelta(); await b.sincronizar(); await espera(Math.max(0, 3000 - (Date.now() - tB)));
  const limB = b.lineas.filter(l => l.detalle === 'Limonada' && !l.enviado).length, tB2 = Date.now() - tB;
  const suelta2 = lento(b, 1500), pb2 = b.enviarComanda();
  await pa; await pb2; suelta2(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { t: fin - t0, tB2, limB, impresos: quienes(a), noSalioB: noSalio(b), comandasB: comandas(b), hechos: cobrados(a), folios: folios(), srv: srv(), enviados: enviados(), libre: libre(), fin: est(a), orden: orden(a.nEq) };
}
out.r = await x7(@VIA@);
"""


@pytest.mark.parametrize("via", ["v2", "v3", "r2", "r7", "parte"])
def test_x7_la_segunda_comanda_del_otro_equipo_tambien_sale_en_node(tmp_path, via):
    casos = CASOS_X7.replace("@VIA@", json.dumps(via))
    r = _correr(tmp_path / "ahora", casos)["r"]
    nombre, hab = ("Cuenta 1" if via in ("r2", "r7") else "Mesa 6"), via in ("v3", "r7")
    # B tenía la Limonada sin enviar para su segunda comanda, a los 3 s de la primera (A todavía esperaba)
    assert r["limB"] == 1 and 2900 <= r["tB2"] < 3700, (via, r)
    # salen las dos comandas de B, la segunda con la Limonada, sin «No salió»; A no manda otra ni pide otro cobro
    assert r["impresos"] == [["B", AMBOS], ["B", LIMONADA1]] and r["noSalioB"] == [] and r["comandasB"] == ["Comanda 1 enviada a Cocina", "Comanda 2 enviada a Cocina"], (via, r)
    assert r["orden"].count(RECLAMAR) == 1 and "COMANDA" not in r["orden"] and r["orden"][-1] == SOLTAR and r["libre"] is True, (via, r)
    # A esperó también la segunda comanda y cobró (o cargó) una vez
    assert 7000 <= r["t"] < 12000 and r["fin"]["pago"] is False and r["fin"]["hab"] is False and r["fin"]["parcial"] is False, (via, r)
    if via == "parte":
        assert r["hechos"] == [["A", MEDIAS_LIM]] and r["srv"] == [["Mesa 6", MEDIAS_LIM, {"total": 2, "cobradas": 1}]] and r["enviados"] == [MEDIAS_LIM], r
    elif hab:
        assert r["folios"] == sorted(p.split("×")[0] + " (" + nombre + ")" for p in CON_LIM) and r["hechos"] == [] and r["srv"] == [], (via, r)
    else:
        assert r["hechos"] == [["A", CON_LIM]] and r["folios"] == [] and r["srv"] == [] and r["orden"].count(EMITIR) == 1, (via, r)

    # antes de esta vuelta: después de juntar la primera comanda se cobraba (o se partía la cuenta) mientras B revisaba la segunda: la Limonada se
    # cobraba y nunca llegaba a cocina («No salió en la comanda»)
    v = _correr(tmp_path / "antes", casos, antes=_antes())["r"]
    assert v["limB"] == 1 and v["impresos"] == [["B", AMBOS]] and v["comandasB"] == ["Comanda 1 enviada a Cocina"], (via, v)
    assert v["noSalioB"] == ["No salió en la comanda: Limonada. En otro equipo ya se había quitado o cobrado de " + nombre + "."] and v["t"] < 6500, (via, v)


# ================================================================================================================ X5: «Cobrar parte» con una comanda vieja
CASOS_X5 = r"""
// la Mesa 6 con Casado y Postre sin enviar en A y en B; A abre «Dividir» (junta la cuenta). B toca «Comanda» (sale enseguida) y su marca de envío en
// el servidor queda de hace `hace` ms (A no la tiene: su lista es de hace menos de 3 s y no la vuelve a traer). A elige 2 partes iguales (la mesa:
// «Cobrar parte 1 de 2») y cobra la parte 1; después vuelve a la mesa y toca «Comanda»
async function x5(hace) {
  const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]);
  await a.abrirDividir();
  await b.enviarComanda(); await b.A.mock.guardarTodo(); marcarEnServidor(id, hace);
  const t0 = Date.now(); a.dividir.modo = 'partes'; a.dividir.partes = 2; await a.confirmarDividir(); await conPago(a); const ms = Date.now() - t0;
  const parte = est(a), m = marca(a);
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  const tras = { hechos: cobrados(a), srv: srv(), enviados: enviados() };
  await a.sincronizar(); a.abrirMesa(M6); const sinEnviar = a.lineas.filter(l => !l.enviado).map(l => l.detalle + '×' + l.cantidad).sort();
  try { await a.enviarComanda(); } catch { /* nada */ } await espera(100); await hastaLibre(); await a.A.mock.guardarTodo();
  return { ms, parte, marca: m, tras, sinEnviar, impresos: quienes(a), noHay: conTexto(a, NO_HAY), hechos: cobrados(a), srv: srv(), enviados: enviados(), libre: libre() };
}
for (const hace of [8500, 12000]) out[hace] = await x5(hace);
"""


def test_x5_cobrar_parte_junta_aunque_la_comanda_sea_vieja_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_X5)
    for hace in ("8500", "12000"):
        x = r[hace]
        # sin esperar (esa comanda ya terminó), pero se junta: la parte y lo que queda en la mesa llegan enviados
        assert x["ms"] < 2000 and x["parte"]["parcial"] is True and x["parte"]["pago"] is True and x["parte"]["platos"] == MEDIAS, (hace, x)
        assert x["tras"]["hechos"] == [["A", MEDIAS]] and x["tras"]["srv"] == [["Mesa 6", MEDIAS, {"total": 2, "cobradas": 1}]] and x["tras"]["enviados"] == [MEDIAS], (hace, x)
        # lo que quedó no vuelve a cocina: la «Comanda» de A no encuentra nada; solo salió la comanda de B
        assert x["sinEnviar"] == [] and x["noHay"] == [NO_HAY] and x["impresos"] == [["B", AMBOS]] and x["libre"] is True, (hace, x)
    # la marca solo con la comanda de menos de 10 s, ya vencida (t = comanda + 4 s: no hizo esperar); con la de 12 s, ninguna
    m = r["8500"]["marca"]
    assert m is not None and m["t"] == m["env"] + 4000 and r["12000"]["marca"] is None, r

    # antes de esta vuelta: sin espera pendiente no se juntaba; lo que quedaba se guardaba «sin enviar» y la «Comanda» de A lo mandaba otra vez
    v = _correr(tmp_path / "antes", CASOS_X5, antes=_antes())
    for hace in ("8500", "12000"):
        x = v[hace]
        assert x["tras"]["enviados"] == [[]] and x["sinEnviar"] == MEDIAS and x["impresos"] == [["B", AMBOS], ["A", MEDIAS]], (hace, x)


# ================================================================================================================ X6: «Dividir» con una comanda vieja
CASOS_X6 = r"""
// `como`: nueva (separar a una cuenta aparte), 7 (pasar a la Mesa 7), cobrar («Cobrar estos platos»), en la Mesa 6; o partes (2 partes iguales, la
// cuenta guardada sin mesa). La cuenta con Casado y Postre sin enviar en A y en B; A abre «Dividir». B toca «Comanda» (sale enseguida) y su marca de
// envío en el servidor queda de hace 12 s (A tuvo «Dividir» abierto un buen rato). A elige el Casado (o las partes) y confirma; si salió el aviso,
// vuelve a abrir «Dividir», elige lo mismo y confirma (y, con «cobrar», cobra la parte)
async function x6(como) {
  const [id, a, b] = await cuenta(como !== 'partes'); a.mesas = [M6, M7];
  await a.abrirDividir();
  await b.enviarComanda(); await b.A.mock.guardarTodo(); marcarEnServidor(id, 12000);
  const elegir = () => { if (como === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = como; a.dividir.sel = { 0: 1 }; } };
  const lis = listas(a), t0 = Date.now(); elegir(); await a.confirmarDividir(); if (como === 'cobrar' && a.cobroParcial) await conPago(a);
  const primero = { ms: Date.now() - t0, consultas: lis.n, dividir: !!a.dividir, pago: !!a.pago, parcial: !!a.cobroParcial, platos: detalles(a), sinEnviar: a.lineas.filter(l => !l.enviado).length,
    avisos: avisosDividir(a), marca: marca(a), alDia: a._alDia, srv: srv() };
  let segundo = null;
  if (primero.avisos.length && !a.dividir && !a.pago && !a.cobroParcial) {
    await a.abrirDividir(); const abierto = !!a.dividir, sinEnviar = a.lineas.filter(l => !l.enviado).length;
    if (a.dividir) { elegir(); const t1 = Date.now(); await a.confirmarDividir(); if (como === 'cobrar') await conPago(a); segundo = { abierto, sinEnviar, ms: Date.now() - t1, dividir: !!a.dividir }; }
  }
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { primero, segundo, avisos: avisosDividir(a), cambio: cambioDividir(a), impresos: quienes(a), hechos: cobrados(a), srv: srv(), enviados: enviados(), libre: libre() };
}
for (const como of @COMOS@) out[como] = await x6(como);
"""
X6_COMOS = ["nueva", 7, "cobrar", "partes"]
X6_FIN = {"nueva": ([["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], [POSTRE1, CASADO1], []),
          "7": ([["Mesa 6", POSTRE1, None], ["Mesa 7", CASADO1, None]], [POSTRE1, CASADO1], []),
          "cobrar": ([["Mesa 6", POSTRE1, None]], [POSTRE1], [["A", CASADO1]]),
          "partes": ([["Cuenta 1", MEDIAS, None], ["Cuenta 1 · parte 2 de 2", MEDIAS, None]], [MEDIAS, MEDIAS], [])}


def test_x6_dividir_avisa_con_una_comanda_vieja_que_la_pantalla_no_tiene_en_node(tmp_path):
    casos = CASOS_X6.replace("@COMOS@", json.dumps(X6_COMOS))
    r = _correr(tmp_path / "ahora", casos)
    for como in ("nueva", "7", "cobrar", "partes"):
        x, p, s = r[como], r[como]["primero"], r[como]["segundo"]
        nombre = "Cuenta 1" if como == "partes" else "Mesa 6"
        # el aviso nuevo, «Dividir» cerrado y nada partido (ni cobro abierto); una consulta, sin esperar; sin marca (la comanda es de hace 12 s) y la
        # próxima apertura de «Dividir» junta la cuenta
        assert p["avisos"] == [AVISO_DIVIDIR_7] and p["dividir"] is False and p["pago"] is False and p["parcial"] is False and p["srv"] == [[nombre, AMBOS, None]], (como, x)
        assert p["platos"] == AMBOS and p["consultas"] == 1 and p["ms"] < 2000 and p["marca"] is None and p["alDia"] == 0, (como, x)
        # al volver a abrir «Dividir» todo está enviado; se divide sin otro aviso ni espera
        assert s == {"abierto": True, "sinEnviar": 0, "ms": s["ms"], "dividir": False} and s["ms"] < 2000, (como, x)
        assert x["avisos"] == [AVISO_DIVIDIR_7] and x["cambio"] == [] and x["libre"] is True, (como, x)
        # nada sale dos veces: solo la comanda de B; todo lo partido queda enviado
        srv, enviados, hechos = X6_FIN[como]
        assert x["impresos"] == [["B", AMBOS]] and x["srv"] == srv and x["enviados"] == enviados and x["hechos"] == hechos, (como, x)

    # antes de esta vuelta: sin aviso (la comanda tenía más de 10 s) se partía enseguida con los platos «sin enviar»: lo que pasaba a la cuenta
    # aparte, a la Mesa 7 o a la otra parte quedaba sin enviar y volvía a salir a cocina con la próxima «Comanda»
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for como in ("nueva", "7", "cobrar", "partes"):
        assert v[como]["primero"]["avisos"] == [] and v[como]["segundo"] is None, (como, v[como])
    assert v["nueva"]["enviados"] == [POSTRE1, []] and v["7"]["enviados"] == [POSTRE1, []] and v["partes"]["enviados"] == [[], []], v
    assert v["cobrar"]["primero"]["parcial"] is True, v["cobrar"]


# ================================================================================================================ X2: «Dividir» después de esperar la marca
CASOS_X2 = r"""
// la Mesa 6 (o, con `destino` partes, la cuenta guardada sin mesa) con Casado y Postre sin enviar en A y en B. B toca «Comanda» (sale enseguida);
// A sincroniza (la marca), abre «Dividir» y elige el Casado para `destino` (nueva, 7 o cobrar) o 2 partes iguales (partes): espera la marca. `que`:
// a los 1,5 s B quita el Postre (quita); nada (nada); o A había agregado una Limonada sin guardar antes de abrir «Dividir» (limonada). Con
// «cobrar», si se abrió el cobro de la parte, se cobra
async function x2(destino, que) {
  const [id, a, b] = await cuenta(destino !== 'partes'); a.mesas = [M6, M7];
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  await a.sincronizar(); const m0 = marca(a);
  if (que === 'limonada') a.lineas.push(LIMONADA());
  await a.abrirDividir(); if (destino === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = destino; a.dividir.sel = { 0: 1 }; }
  const t0 = Date.now(), pd = a.confirmarDividir();
  await espera(1500); if (que === 'quita') await quitarPostre(b);
  await pd; if (destino === 'cobrar' && a.cobroParcial) await conPago(a); const ms = Date.now() - t0;
  const tras = { ...est(a), cambio: cambioDividir(a), alDia: a._alDia, srv: srv() };
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { m0: !!m0, ms, tras, hechos: cobrados(a), impresos: quienes(a), srv: srv(), enviados: enviados(), libre: libre() };
}
for (const [destino, que] of @CASOS@) out[destino + '_' + que] = await x2(destino, que);
"""
X2_CASOS = {"nueva": [["nueva", "quita"], ["nueva", "nada"], ["nueva", "limonada"]], "7": [[7, "quita"]],
            "cobrar": [["cobrar", "quita"], ["cobrar", "nada"]], "partes": [["partes", "quita"], ["partes", "nada"]]}
X2_NADA = {"nueva": ([["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], []), "cobrar": ([["Mesa 6", POSTRE1, None]], [["A", CASADO1]]),
           "partes": ([["Cuenta 1", MEDIAS, None], ["Cuenta 1 · parte 2 de 2", MEDIAS, None]], [])}
# antes de esta vuelta, con B quitando el Postre mientras A esperaba: lo que quedaba en el servidor y lo cobrado
X2_ANTES = {"nueva": ([["Mesa 6", [], None], ["Mesa 6 · aparte", CASADO1, None]], []), "7": ([["Mesa 6", [], None], ["Mesa 7", CASADO1, None]], []),
            "cobrar": ([["Mesa 6", [], None]], [["A", CASADO1]]), "partes": ([["Cuenta 1", ["Casado×0.5"], None], ["Cuenta 1 · parte 2 de 2", MEDIAS, None]], [])}


@pytest.mark.parametrize("destino", ["nueva", "7", "cobrar", "partes"])
def test_x2_dividir_mira_la_cuenta_despues_de_esperar_la_marca_en_node(tmp_path, destino):
    casos = CASOS_X2.replace("@CASOS@", json.dumps(X2_CASOS[destino]))
    r = _correr(tmp_path / "ahora", casos)
    nombre = "Cuenta 1" if destino == "partes" else "Mesa 6"
    for k, x in r.items():
        # A esperó la marca (unos 4 s) y la comanda de B salió una vez
        assert x["m0"] is True and 3000 <= x["ms"] < 6500 and x["impresos"] == [["B", AMBOS]] and x["libre"] is True, (k, x)
    q = r[destino + "_quita"]
    # B quitó el Postre mientras A esperaba: el aviso «La cuenta cambió…», «Dividir» cerrado, nada partido ni cobrado y la próxima apertura junta
    assert q["tras"]["cambio"] == [CAMBIO_DIV] and q["tras"]["dividir"] is False and q["tras"]["pago"] is False and q["tras"]["parcial"] is False and q["tras"]["alDia"] == 0, q
    assert q["srv"] == [[nombre, CASADO1, None]] and q["hechos"] == [], q
    if destino in X2_NADA:
        n = r[destino + "_nada"]
        # sin cambios: se divide normal, sin el aviso
        assert n["tras"]["cambio"] == [] and n["tras"]["dividir"] is False and n["srv"] == X2_NADA[destino][0] and n["hechos"] == X2_NADA[destino][1], n
    if destino == "nueva":
        x = r["nueva_limonada"]
        # un plato agregado aquí sin guardar no da un aviso falso: se separa el Casado y la Limonada queda en la mesa con el Postre
        assert x["tras"]["cambio"] == [] and x["tras"]["dividir"] is False and x["srv"] == [["Mesa 6", ["Limonada×1", "Postre×1"], None], ["Mesa 6 · aparte", CASADO1, None]], x

    # antes de esta vuelta: después de esperar se partía con la cuenta de antes en pantalla (B ya había quitado el Postre): sin aviso y con la
    # cuenta partida (o la parte cobrada) igual; con partes, la segunda parte se llevaba medio Postre que ya no estaba en la cuenta
    v = _correr(tmp_path / "antes", CASOS_X2.replace("@CASOS@", json.dumps([X2_CASOS[destino][0]])), antes=_antes())[destino + "_quita"]
    assert v["tras"]["cambio"] == [] and (v["srv"], v["hechos"]) == X2_ANTES[destino], v


# ================================================================================================================ D0: la cuenta ya cobrada
CASOS_D0 = r"""
// `como`: nueva (separar a una cuenta aparte) o 7 (pasar a la Mesa 7), en la Mesa 6; o partes (2 partes iguales, la cuenta guardada sin mesa). La
// cuenta con Casado y Postre sin enviar en A y en B; A abre «Dividir». B cobra la cuenta entera (A no sincroniza). A elige el Casado (o las partes)
// y confirma
async function d0(como) {
  const [id, a, b] = await cuenta(como !== 'partes'); a.mesas = [M6, M7];
  await a.abrirDividir();
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  if (como === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = como; a.dividir.sel = { 0: 1 }; }
  const lis = listas(a); await a.confirmarDividir(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  return { srv: srv(), hechos: cobrados(a), impresos: quienes(a), cerradas: cerradas(a), hecho: avisos(a).filter(t => t.startsWith('Platos pasados a ') || t.startsWith('Cuenta dividida')),
    dividir: !!a.dividir, fin: est(a), vista: a.vista, consultas: lis.n };
}
for (const como of @COMOS@) out[como] = await d0(como);
"""


def test_d0_separar_pasar_o_partir_una_cuenta_ya_cobrada_no_deja_cuenta_nueva_en_node(tmp_path):
    casos = CASOS_D0.replace("@COMOS@", json.dumps(["nueva", 7, "partes"]))
    r = _correr(tmp_path / "ahora", casos)
    for como, aviso in (("nueva", CERRADA_M6), ("7", CERRADA_M6), ("partes", CERRADA_C1)):
        x = r[como]
        # B cobró la cuenta una vez; A no deja ninguna cuenta nueva con esos platos y no dice que los pasó o la dividió
        assert x["hechos"] == [["B", AMBOS]] and x["srv"] == [] and x["hecho"] == [] and x["dividir"] is False, (como, x)
        # la caja se pone al día: el aviso de siempre (sincronizar), sin la cuenta en pantalla y de vuelta al plano; la lista se trajo (D0) y otra
        # vez al sincronizar
        assert x["cerradas"] == [aviso] and x["fin"]["platos"] == [] and x["fin"]["cuenta"] is None and x["vista"] == "mesas" and x["consultas"] == 2, (como, x)
    # la comanda: en la mesa no sale al cobrar; la cuenta guardada sin mesa la mandó B al cobrarla (una vez)
    assert r["nueva"]["impresos"] == [] and r["7"]["impresos"] == [] and r["partes"]["impresos"] == [["B", AMBOS]], r

    # antes de esta vuelta: el Casado (o las partes) quedaban en una cuenta nueva, por cobrar otra vez
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    assert v["nueva"]["srv"] == [["Mesa 6 · aparte", CASADO1, None]] and v["7"]["srv"] == [["Mesa 7", CASADO1, None]], v
    assert sorted(x[0] for x in v["partes"]["srv"]) == ["Cuenta 1", "Cuenta 1 · parte 2 de 2"] and all(x[1] == MEDIAS for x in v["partes"]["srv"]), v["partes"]
    for como in ("nueva", "7", "partes"):
        assert v[como]["hechos"] == [["B", AMBOS]] and len(v[como]["hecho"]) == 1, (como, v[como])


# ================================================================================================================ X3: la cuenta que ya no está
CASOS_X3 = r"""
// la Mesa 6 con Casado y Postre sin enviar, abierta en A y en B. `entra`: revision, A abre el cobro (o, con `hab`, la habitación), B toca «Comanda»
// (revisión lenta: 1,5 s) y en cuanto su guardado llegó al servidor A toca «Cobrar» («Cargar»): lo ve V2 (V3); marca, B toca «Comanda» (sale
// enseguida), A sincroniza (la marca), abre el cobro (la habitación) y toca «Cobrar» («Cargar»). Mientras A espera, B (`que`) borra la cuenta
// (borra) o pasa todos sus platos a la Mesa 7 (mesa7)
async function x3(hab, entra, que) {
  const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]);
  let pb = null, suelta = () => {};
  if (entra === 'marca') { await b.enviarComanda(); await b.A.mock.guardarTodo(); await a.sincronizar(); }
  if (hab) { a.habCargo = HAB(); hojaHab(a); a.habCargo.reserva_id = 1; } else await a.abrirPago();
  if (entra === 'revision') { suelta = lento(b, 1500); pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id)); }
  const m0 = marca(a), t0 = Date.now(); let fin = 0;
  const pa = (hab ? a.cargarAHabitacion() : a.cobrar()).then(() => { fin = Date.now(); });
  if (pb) await pb; suelta(); await b.A.mock.guardarTodo(); if (entra === 'marca') await espera(1000);
  const hecho = que === 'borra' ? (await b.borrarEspera(b.cuentaActual), await b.A.mock.guardarTodo(), true) : await todoA7(b);
  const srvB = srv();
  await pa; const t = fin - t0; await hastaLibre(); await a.A.mock.guardarTodo();
  return { m0: !!m0, hecho, t, srvB, impresos: quienes(a), hechos: cobrados(a), folios: folios(), delCobro: delCobroA(a), neutro: neutros(a), cerradas: cerradas(a),
    fin: est(a), srv: srv(), libre: libre(), orden: orden(a.nEq) };
}
for (const entra of ['revision', 'marca']) for (const que of ['borra', 'mesa7']) out[entra + '_' + que] = await x3(@HAB@, entra, que);
// (sigue) cobroOcupado con «cerrada» y la cuenta todavía en la lista: el aviso neutro, sin «ya se cobró»; la ventana de cobro se cierra
{ const [id, a] = await mesaGuardada([CASADO(), POSTRE()]); await a.abrirPago(); await a.cobroOcupado({ resultado: 'cerrada', comunes: [] });
  out.sigue = { neutro: neutros(a), delCobro: delCobroA(a), cerradas: cerradas(a), fin: est(a), srv: srv() }; }
"""


@pytest.mark.parametrize("hab", [False, True])
def test_x3_la_cuenta_que_desaparece_durante_la_espera_solo_da_el_aviso_de_siempre_en_node(tmp_path, hab):
    casos = CASOS_X3.replace("@HAB@", json.dumps(hab))
    r = _correr(tmp_path / "ahora", casos)
    for entra in ("revision", "marca"):
        for que, srv_b in (("borra", []), ("mesa7", [["Mesa 7", AMBOS, None]])):
            x = r[entra + "_" + que]
            # B borró la cuenta o pasó todo a la Mesa 7 mientras A esperaba su comanda (que salió una vez)
            assert x["hecho"] is True and x["srvB"] == srv_b and x["impresos"] == [["B", AMBOS]] and x["m0"] is (entra == "marca") and 3500 <= x["t"] < 7000, (hab, entra, que, x)
            # nada cobrado ni cargado, el cobro pedido queda libre, sin ventanas abiertas y solo el aviso de siempre: ni «ya se cobró» ni el neutro
            assert x["hechos"] == [] and x["folios"] == [] and x["orden"] == [RECLAMAR, SOLTAR] and x["libre"] is True and x["srv"] == srv_b, (hab, entra, que, x)
            assert x["delCobro"] == [] and x["neutro"] == [] and x["cerradas"] == [CERRADA_M6], (hab, entra, que, x)
            assert x["fin"]["pago"] is False and x["fin"]["hab"] is False and x["fin"]["platos"] == [] and x["fin"]["cuenta"] is None, (hab, entra, que, x)
    s = r["sigue"]
    # con la cuenta todavía en la lista: el aviso neutro (nada se cobró ni se cargó), sin «ya se cobró»; la cuenta queda en pantalla
    assert s["neutro"] == [NEUTRO] and s["delCobro"] == [] and s["cerradas"] == [] and s["fin"]["pago"] is False and s["fin"]["platos"] == AMBOS and s["srv"] == [["Mesa 6", AMBOS, None]], s

    # antes de esta vuelta: con la comanda vista en V2 o V3, el aviso decía «ya se cobró en otro equipo» (B la borró o la movió); con la marca de antes
    # (A ya había sincronizado), después de esperar no se juntaba y se cobraba (o cargaba) la cuenta que ya no existía
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for que in ("borra", "mesa7"):
        assert v["revision_" + que]["delCobro"] == [COBRADA] and v["revision_" + que]["hechos"] == [] and v["revision_" + que]["folios"] == [], (hab, que, v["revision_" + que])
        x = v["marca_" + que]
        assert (x["folios"] == ["Casado (Mesa 6)", "Postre (Mesa 6)"]) if hab else (x["hechos"] == [["A", AMBOS]]), (hab, que, x)
    assert v["sigue"]["delCobro"] == [COBRADA] and v["sigue"]["neutro"] == [], v["sigue"]


# ================================================================================================================ un solo equipo
CASOS_SOLO = r"""
// un solo equipo (A), sin nada de otro equipo: cuánto tarda (ms) y cuántas veces trae la lista (consultas). `caso`: lo que se hace (cobro, hab:
// «Cargar», parte: «Cobrar parte 1 de 2», separar, pasar: a la Mesa 7, partir: 2 partes iguales, lenta: separar con la lista lenta, 3 s) y dónde
// (mesa: la Mesa 6; guardada: la cuenta guardada sin mesa; rapida: la venta rápida nueva). `env`: los platos ya enviados hace un minuto
async function solo(caso, env) {
  const [accion, donde] = caso.split('_');
  const platos = () => env ? [{ ...CASADO(), enviado: VIEJA(), ronda: 1 }, { ...POSTRE(), enviado: VIEJA(), ronda: 1 }] : [CASADO(), POSTRE()];
  let a;
  if (donde === 'rapida') { nuevo(); a = venta(await equipo()); a.lineas.push(...platos()); }
  else a = (await cuenta(donde === 'mesa', platos()))[1];
  a.mesas = [M6, M7]; HOJAS.length = 0;
  let lis = listas(a), t0 = Date.now();
  if (accion === 'cobro') { await a.abrirPago(); lis = listas(a); t0 = Date.now(); await a.cobrar(); }
  else if (accion === 'hab') { a.habCargo = HAB(); hojaHab(a); a.habCargo.reserva_id = 1; await a.cargarAHabitacion(); }
  else if (accion === 'parte') { await a.cobrarParte(2); await conPago(a); }
  else {
    await a.abrirDividir(); if (accion === 'lenta') lento(a, 3000);
    lis = listas(a); t0 = Date.now();
    if (accion === 'partir') { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = accion === 'pasar' ? 7 : 'nueva'; a.dividir.sel = { 0: 1 }; }
    await a.confirmarDividir();
  }
  const ms = Date.now() - t0, consultas = lis.n, parcial = !!a.cobroParcial;
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { ms, consultas, parcial, dividir: !!a.dividir, hechos: cobrados(a), folios: folios(), srv: srv(), avisos: avisos(a).filter(t => !/^(Comanda |Platos pasados a |Cuenta dividida|Tiquete |«)/.test(t) && !t.includes(' cargados a la habitación')), libre: libre() };   // sin los avisos de siempre
}
for (const [caso, env] of @CASOS@) out[caso + (env ? '_env' : '')] = await solo(caso, env);
"""
SOLO = [["cobro_mesa", True], ["cobro_mesa", False], ["cobro_guardada", True], ["cobro_guardada", False], ["cobro_rapida", False], ["hab_mesa", False],
        ["hab_guardada", True], ["parte_mesa", False], ["separar_mesa", True], ["separar_mesa", False], ["pasar_mesa", True], ["pasar_mesa", False],
        ["partir_guardada", True], ["separar_guardada", True], ["separar_rapida", False], ["lenta_mesa", True]]


def test_un_solo_equipo_no_espera_y_trae_la_lista_una_vez_en_node(tmp_path):
    r = _correr(tmp_path, CASOS_SOLO.replace("@CASOS@", json.dumps(SOLO)))
    for k in ("cobro_mesa_env", "cobro_mesa", "cobro_guardada_env", "cobro_guardada", "cobro_rapida"):
        x = r[k]
        # los cobros de todos los días: sin espera, una vez, entera; con platos sin enviar en una cuenta guardada, una consulta (la revisión)
        assert x["ms"] < 1500 and x["hechos"] == [["A", AMBOS]] and x["srv"] == [] and x["libre"] is True and x["avisos"] == [], (k, x)
        assert x["consultas"] == (0 if k.endswith("_env") or k == "cobro_rapida" else 1), (k, x)
    for k, nombre in (("hab_mesa", "Mesa 6"), ("hab_guardada_env", "Cuenta 1")):
        x = r[k]
        assert x["ms"] < 1500 and x["folios"] == ["Casado (" + nombre + ")", "Postre (" + nombre + ")"] and x["hechos"] == [] and x["srv"] == [] and x["libre"] is True, (k, x)
    p = r["parte_mesa"]
    # «Cobrar parte»: la cuenta al día y la revisión de sus platos sin enviar (dos consultas), sin esperar
    assert p["ms"] < 1500 and p["parcial"] is True and p["consultas"] == 2 and p["hechos"] == [["A", MEDIAS]] and p["srv"] == [["Mesa 6", MEDIAS, {"total": 2, "cobradas": 1}]], p
    fin = {"separar_mesa": [["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], "pasar_mesa": [["Mesa 6", POSTRE1, None], ["Mesa 7", CASADO1, None]],
           "partir_guardada": [["Cuenta 1", MEDIAS, None], ["Cuenta 1 · parte 2 de 2", MEDIAS, None]], "separar_guardada": [["Cuenta 1", POSTRE1, None], ["Cuenta 1 · aparte", CASADO1, None]]}
    for k in ("separar_mesa_env", "separar_mesa", "pasar_mesa_env", "pasar_mesa", "partir_guardada_env", "separar_guardada_env"):
        x = r[k]
        # separar, pasar a una mesa o partir una cuenta guardada: una consulta de la lista (con o sin platos por enviar) y nada más, sin esperar
        assert x["consultas"] == 1 and x["ms"] < 1500 and x["dividir"] is False and x["avisos"] == [] and x["srv"] == fin[k.replace("_env", "")], (k, x)
    s = r["separar_rapida"]
    # la venta rápida nueva (no está guardada): ninguna consulta
    assert s["consultas"] == 0 and s["ms"] < 1500 and s["srv"] == [["Cuenta · aparte", CASADO1, None]], s
    lenta = r["lenta_mesa_env"]
    # con la lista lenta (3 s), la consulta espera 1,5 s como mucho y se separa con la copia que hay. 4.39 (décima vuelta): sigue en 1,5 s porque los platos
    # ya están enviados (R1 espera hasta 3 s solo con platos por enviar; ver tests/test_439_decima_vuelta.py). 4.39 (undécima vuelta): Q1 lleva la consulta a
    # 3 s como mucho también con los platos enviados: con la lista a 3 s, unos 3 s (la lista o el tope, lo que llegue primero) y se separa igual
    assert lenta["consultas"] == 1 and 2900 <= lenta["ms"] < 4000 and lenta["srv"] == fin["separar_mesa"] and lenta["avisos"] == [], lenta


# ================================================================================================================ contrato
def test_contrato_de_la_septima_vuelta():
    # 4.39 (octava vuelta): «ahora» es caja.js sin la octava vuelta (la octava cambió líneas de cobrarParte, confirmarDividir y cobroOcupado: Y1 a
    # Y5); lo de la octava está en tests/test_439_octava_vuelta.py
    k, k0 = _caja_sin_octava(), _caja_sin_septima()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    # cada tripleta de SEPTIMA: «lo de ahora» está en caja.js las veces anotadas, todas dentro de los métodos cambiados (la de rapida0, que solo
    # quita una línea, tiene de «lo de ahora» la línea que sigue, que ya estaba)
    assert len(SEPTIMA) == 17
    for viejo, nuevo, veces in SEPTIMA:
        assert k.count(nuevo) == veces and k0.count(viejo) >= veces and k0.count(nuevo) == (veces if nuevo in viejo else 0), nuevo[:120]
        assert sum(m.count(nuevo) for m in metodos.values()) == veces, nuevo[:120]
    # cada método cambió; enviarComanda y comandaNumerada quedaron como antes de la sexta vuelta (X0)
    for c in metodos:
        assert metodos[c] != antes[c], c
    k6 = _caja_sin_sexta()
    for c in ("enviarComanda() {", "comandaNumerada(modo,"):
        assert metodos[c] == _metodo(k6, c), c
    # fuera de ellos, caja.js no cambió
    resto, resto0 = k, k0
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], ""), resto0.replace(antes[c], "")
    assert resto == resto0
    # todo lo de la vuelta lleva su comentario
    assert k.count("4.39 (séptima vuelta)") >= 12 and k0.count("4.39 (séptima vuelta)") == 0 and k.count("Séptima vuelta:") >= 1
    # la marca sigue igual que en la sexta vuelta (seis lugares, con la hora de la comanda); RECIENTE queda en las cuatro revisiones de la marca y los
    # dos cortes de la venta rápida (en cobrarParte y en «Dividir» se separa lo visto de lo reciente)
    assert k.count("this._marcaAjena = {") == 6 and k.count(RECIENTE) == 6
    e, rh, cp, cd, co = (metodos[c] for c in ("async emitirCobro(otra) {", "async reclamarHab() {", "async cobrarParte(n) {", "async confirmarDividir() {", "async cobroOcupado(r) {"))
    # X1: emitirCobro anota si va a esperar la marca ANTES de esperarla; V2 junta si esperó (junta = esperoMarca) o si vio una comanda reciente
    marca_e = "{ const ma = this._marcaAjena, falta = ma && esperaId !== null && esperaId !== undefined && ma.id === esperaId ? ma.t + 4000 - Date.now() : 0;"
    assert e.index("const esperoMarca = esperaId !== null && esperaId !== undefined && " + VIGENTE("esperaId") + ";") < e.index(marca_e) < e.index("let rc = null, rcPedido = false;")
    assert e.index("let junta = esperoMarca;") < e.index("for (let k = 0; junta && k < 2; k++) {") < e.index("let doc = null, body = null;")
    # X7 y X3 en V2: dos vueltas como mucho; la cuenta que ya no está va con «cerrada» y suelta el cobro; se compara con lo que se iba a cobrar
    v2 = e[e.index("let junta = esperoMarca;"):e.index("let doc = null, body = null;")]
    assert v2.index("if (!enEspera().some(v => v.id === esperaId)) { this.soltarCobro(rc, false); return this.cobroOcupado({ resultado: 'cerrada', comunes: [] }); }") \
        < v2.index("const cambio2 = this.cobroCambiado(esperaId, lineasCobradas, total, false); if (cambio2) { this.soltarCobro(rc, false); return cambio2; }") \
        < v2.index("junta = " + VIGENTE("esperaId") + ";")
    assert "resultado: 'cobrada'" not in v2 and "this.cobroParcial.rapida" not in e and "this.enviarComanda(); } catch { /* la comanda no detiene el cobro */ } }" not in e
    # X1 en reclamarHab: esperoHab antes de la espera de la marca; rapHab, la condición del bloque de la venta rápida, antes de él; el bloque de la mesa
    # corre para todo lo demás, con platos por enviar o si se esperó la marca, y antes de cargar
    marca_h = "{ const ma = this._marcaAjena, id1 = this.esperaId; if (ma && ma.id === id1) {"
    assert rh.index("const esperoHab = " + VIGENTE("this.esperaId") + ";") < rh.index(marca_h) < rh.index("rc = await this.reclamarCobro(this.lineas);")
    rap = "this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(l => !l.enviado && +l.cantidad > 0 && this.destinoDe(l))"
    pasos_h = ["const rapHab = " + rap + ";", "if (" + rap + ") {", "if (this.esRestaurante && !this.cobroParcial && !rapHab) {",
               "if (idM !== null && idM !== undefined && (sin1.size || esperoHab)) {", "let junta = esperoHab;", "for (let k = 0; junta && k < 2; k++) {",
               "if (!enEspera().some(v => v.id === idM)) { this.habCargo = null; return this.cobroOcupado({ resultado: 'cerrada', comunes: [] }); }",
               "if (this.cobroCambiado(idM, lineas0, total0, false, true)) return;", "junta = " + VIGENTE("idM") + ";", "this._habSigue = true; this.cargarAHabitacion();"]
    pos = [rh.index(x) for x in pasos_h]
    assert pos == sorted(pos), pos
    assert "resultado: 'cobrada'" not in rh and "setTimeout(r, 4000)" not in rh                         # la habitación sigue en tramos de 200 ms
    # X7 en los cortes de los dos bucles de la venta rápida: una tercera vuelta solo con la marca renovada
    corte = "if (vuelta > 1 || (vuelta ? !" + VIGENTE("this.esperaId")[2:] + " : !this.lineas.some(l => l.enviado && sin0.has(l.lid) && " + RECIENTE + "))) break;"
    assert e.count(corte) == 1 and rh.count(corte) == 1 and "if (vuelta || " not in e and "if (vuelta || " not in rh
    # X5 y X7 en cobrarParte: junta también con lo visto (a cualquier hora), la marca solo con lo reciente; dos vueltas como mucho, que alargan la espera
    # con la marca nueva; después, las guardas de siempre antes de partir
    pasos_p = ["vistos = c1 ? (c1.lineas || []).filter(l => l && l.enviado && sin1.has(l.lid) && this.destinoDe(l)) : [], ls = vistos.filter(l => !(Date.now() - Date.parse(l.enviado) > 10000)); if (vistos.length) junta = true;",
               "for (let k = 0; k < 2 && (Date.now() < hasta || junta); k++) {",
               "this._alDia = 0; await this.alDiaParaCobrar(); const m2 = this._marcaAjena; if (m2 && m2.id === id0) hasta = Math.max(hasta, m2.t + 4000); }",
               "if (this.cobroParcial || this.esperaId !== id0 || this.habCargo || this.pago || this.dividir !== div0) return;", "this.lineas = resto; const id = this.persistirCuenta(true);"]
    pos = [cp.index(x) for x in pasos_p]
    assert pos == sorted(pos), pos
    # X6, X2 y D0 en confirmarDividir, en este orden y antes de pedir el turno y de partir
    aviso7 = "this._alDia = 0; if (this.dividir === d) this.dividir = null; return toast('" + AVISO_DIVIDIR_7 + "', 'err');"
    pasos_d = ["b1 = this._base, ex1 = !!(b1 && b1.id === id1 && b1.existia) || !!(mock.confirmado && mock.confirmado('pos_espera', id1));",
               "if (sin1.size || (ex1 && (d.modo === 'partes' || d.destino !== 'cobrar'))) {", "if (vistos.length) { if (ls.length) {", aviso7,
               "const espero = " + VIGENTE("id1") + ";", "if (espero) {", "if (!c2 && ex1) { this.dividir = null; this.sincronizar(); return; }",
               "this._alDia = 0; this.dividir = null; return toast('" + CAMBIO_DIV + "', 'err');",
               "!enEspera().some(v => v.id === idx)) { this.dividir = null; this.sincronizar(); return; } }",
               "if (d.destino === 'cobrar' && d.modo !== 'partes') { if (this.cfg.pedir_apertura", "if (d.modo === 'partes') {", "if (d.destino === 'nueva') {"]
    pos = [cd.index(x) for x in pasos_d]
    assert pos == sorted(pos), pos
    assert AVISO_DIVIDIR not in k and cd.count(aviso7) == 1 and "rapida0" not in cd
    assert "const firma = ls => (ls || []).map(l => String(l && l.lid) + ':' + (+(l && l.cantidad) || 0)).sort().join('|')" in cd and "ponerLids(JSON.parse(JSON.stringify(c2)))" in cd
    # X3: con «cerrada», sin el aviso «ya se cobró»; el neutro solo si la cuenta sigue en la lista (si no, el de sincronizar)
    assert co.index("if (res !== 'cerrada') toast(res === 'ocupada' ?") < co.index("if (this.esperaId && !enEspera().some(v => v.id === this.esperaId)) this.sincronizar();") \
        < co.index("else { if (res === 'cerrada') toast('" + NEUTRO + "', 'err'); this.seguirCobroAjeno(this.esperaId); }")
    assert k.count("resultado: 'cerrada'") == 2
