# -*- coding: utf-8 -*-
"""4.31 (servidor): estación de comandas, la comanda de un pedido en línea siempre sale (diseño exe430/diseno_estacion.md, sección 8).

- pedidos.a_caja guarda la copia fija de la comanda (tabla comanda_pedido) en el mismo commit que la cuenta; el origen (pago, aceptar,
  aceptar_anterior) decide cuánto espera la estación.
- Reclamos por plato (tabla comanda_reclamo): dos a la vez nunca ganan los dos (hilos con dos sesiones y dos motores, y HTTP); vencen a
  los 60 s; soltar, reintentar y agotar; impresa y doble; sin comanda; cancelado; cobro.
- La ruta vieja POST /api/pedidos/{id}/comanda/impresa y la marca de una Cocina anterior dejan los platos «impresa».
- Respaldo y restauración no reviven ni pierden comandas; una base de una versión anterior abre sin error (también en el programa).
- El 9800 del programa ofrece GET /equipo solo con fuente. L-9: la fusión del servidor en pedidos.py.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json
import threading
import urllib.request
from datetime import datetime, timedelta

import pytest
from sqlalchemy import text
from sqlmodel import Session

from app import comandas, config, db, modulos, pedidos, planes, sinc
from app.db import engine_empresa
from tests.test_429_pedido_web_comanda import _cuenta, _montar_negocio
from tests.test_exoneraciones import api  # noqa: F401  (fixture)

T0 = datetime(2026, 11, 12, 14, 0, 0, tzinfo=config.TZ_CR)
EQ_A, EQ_B, EQ_C, EQ_D = "equipoA0000000001", "equipoB0000000002", "equipoC0000000003", "equipoD0000000004"
_TEL = {"n": 0}


@pytest.fixture
def sin_limite(monkeypatch):
    """Los pedidos públicos de estas pruebas no gastan el cupo por IP de las demás."""
    monkeypatch.setattr(pedidos, "limitar_ip", lambda *a, **k: None)


def _reloj(monkeypatch, t):
    R = {"t": t}
    monkeypatch.setattr(comandas, "ahora_cr", lambda: R["t"])
    monkeypatch.setattr(pedidos, "ahora_cr", lambda: R["t"])
    return R


def _pedido3(c, slug, a, b, tipo="domicilio"):
    _TEL["n"] += 1
    r = c.post(f"/api/publico/{slug}/pedido", json={"nombre": "Cliente QA", "telefono": f"8{_TEL['n']:07d}", "tipo": tipo, "direccion": "Barrio QA", "lineas": [
        {"producto_id": a["id"], "cantidad": 2, "nota": "sin cebolla"}, {"producto_id": b["id"], "cantidad": 1}, {"producto_id": a["id"], "cantidad": 1, "nota": "extra"}]})
    assert r.status_code == 200, r.text
    return r.json()["id"]


def _aceptar(c, pid, reclama=True, extra=None):
    cuerpo = {"estado": "confirmado", **({"reclama": True} if reclama else {}), **(extra or {})}
    r = c.put(f"/api/pedidos/{pid}/estado", json=cuerpo)
    assert r.status_code == 200, r.text
    return r.json()["cuenta_espera_id"]


def _copia(eid, pid):
    with Session(engine_empresa(eid)) as s:
        return comandas._copia(s, eid, pid)


def _filas(eid, pid):
    with Session(engine_empresa(eid)) as s:
        return comandas._filas(s, eid, pid)


def _rec(c, pid, lineas, equipo, momento, grupo="10", nombre="Caja QA · Cocina"):
    r = c.post("/api/pos/comanda/reclamar", json={"pedido_id": pid, "lineas": lineas, "grupo": grupo, "grupo_nombre": "Cocina", "equipo": equipo,
                                                  "nombre": nombre, "momento": momento})
    assert r.status_code == 200, r.text
    return r.json()


def _impresa(c, pid, equipo, lineas, sin_comanda=()):
    r = c.post("/api/pos/comanda/impresa", json={"pedido_id": pid, "equipo": equipo, "lineas": list(lineas), "sin_comanda": list(sin_comanda)})
    assert r.status_code == 200, r.text
    return r.json()


def _soltar(c, pid, equipo, lineas, motivo="sin papel"):
    r = c.post("/api/pos/comanda/soltar", json={"pedido_id": pid, "equipo": equipo, "lineas": lineas, "motivo": motivo})
    assert r.status_code == 200, r.text
    return r.json()


def _negocio(c):
    return _montar_negocio(c, {"modo": "restaurante"})


# ================================================================================================================ 1. dos a la vez
def _limpiar_reclamos(eid, pid):
    with Session(engine_empresa(eid)) as s:
        s.execute(text("DELETE FROM comanda_reclamo WHERE empresa_id = :e AND pedido_id = :p"), {"e": eid, "p": pid}); s.commit()


def _a_la_vez(eid, pid, grupos, otro):
    barrera, out, errores = threading.Barrier(len(grupos)), [None] * len(grupos), []

    def trabajar(i):
        eng = otro if i % 2 else engine_empresa(eid)                       # dos motores sobre el mismo archivo: como dos procesos
        try:
            with Session(eng) as s:
                barrera.wait()
                out[i] = comandas.reclamar(s, eid, pid, grupos[i], f"g{i}", "Cocina", (EQ_A, EQ_B)[i % 2], f"Caja {i}", "cocina")
        except Exception as ex:  # noqa: BLE001
            errores.append(repr(ex))
    hilos = [threading.Thread(target=trabajar, args=(i,)) for i in range(len(grupos))]
    for h in hilos:
        h.start()
    for h in hilos:
        h.join(60)
    assert not errores, errores
    return out


def test_dos_reclamos_a_la_vez_gana_uno_y_los_grupos_que_se_cruzan(api, sin_limite):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    _aceptar(c, pid)
    otro = db._nuevo_engine(f"sqlite:///{db.EMPRESAS_DIR / f'empresa_{eid}.db'}")
    try:
        for _ in range(20):
            _limpiar_reclamos(eid, pid)
            res = _a_la_vez(eid, pid, [[0, 1, 2], [0, 1, 2]], otro)
            assert sorted(r["resultado"] for r in res) == ["ganada", "ocupada"], res
            assert next(r for r in res if r["resultado"] == "ocupada")["por"] in ("Caja 0", "Caja 1")
        for _ in range(20):
            _limpiar_reclamos(eid, pid)
            grupos = [[0, 1], [1, 2]]
            res = _a_la_vez(eid, pid, grupos, otro)
            ganadas = [i for i, r in enumerate(res) if r["resultado"] == "ganada"]
            assert len(ganadas) == 1, res                                    # nunca ganan los dos
            tomadas = {p for p, f in _filas(eid, pid).items() if f["estado"] == "reclamada"}
            assert tomadas == set(grupos[ganadas[0]]), (res, tomadas)        # el que pierde no deja ninguna fila tomada
    finally:
        otro.dispose()


def test_dos_reclamos_a_la_vez_por_http(api, sin_limite):  # noqa: F811
    from fastapi.testclient import TestClient
    from app.main import app
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    _aceptar(c, pid)
    for _ in range(10):
        _limpiar_reclamos(eid, pid)
        barrera, out, errores = threading.Barrier(2), [None, None], []

        def caja(i):
            cli = TestClient(app)
            try:
                barrera.wait()
                r = cli.post("/api/pos/comanda/reclamar", json={"pedido_id": pid, "lineas": [0, 1, 2], "grupo": "10", "equipo": (EQ_A, EQ_B)[i], "momento": "cocina"})
                assert r.status_code == 200, r.text
                out[i] = r.json()["resultado"]
            except Exception as ex:  # noqa: BLE001
                errores.append(repr(ex))
        hilos = [threading.Thread(target=caja, args=(i,)) for i in range(2)]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join(60)
        assert not errores, errores
        assert sorted(out) == ["ganada", "ocupada"], out


# ================================================================================================================ 2 y 3. mismo equipo, espera y vigencia
def test_mismo_equipo_en_curso_y_vencido(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    R = _reloj(monkeypatch, T0)
    pid = _pedido3(c, slug, a, b)
    _aceptar(c, pid)
    r = _rec(c, pid, [0, 1], EQ_A, "cocina")
    assert r["resultado"] == "ganada" and r["lineas"] == [0, 1] and r["vence"] == "2026-11-12T14:01:00-06:00", r
    assert _rec(c, pid, [0, 1], EQ_A, "cocina") == {"resultado": "en_curso", "vence": "2026-11-12T14:01:00-06:00"}   # la misma pestaña no lo retoma
    assert _rec(c, pid, [1, 2], EQ_B, "cocina") == {"resultado": "ocupada", "por": "Caja QA · Cocina", "vence": "2026-11-12T14:01:00-06:00"}
    assert _filas(eid, pid).get(2) is None                                   # el grupo que perdió no tomó el 2
    R["t"] = T0 + timedelta(seconds=61)
    assert _rec(c, pid, [0, 1], EQ_A, "cocina")["resultado"] == "ganada"     # vencido: también el mismo equipo


def test_espera_de_la_estacion_por_origen_y_vigencia(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    R = _reloj(monkeypatch, T0)
    nuevo, viejo, vieja, otro = (_pedido3(c, slug, a, b) for _ in range(4))
    _aceptar(c, nuevo, reclama=True)
    _aceptar(c, viejo, reclama=False)
    _aceptar(c, vieja, reclama=True)
    _aceptar(c, otro, reclama=True)
    assert _copia(eid, nuevo)["origen"] == "aceptar" and _copia(eid, viejo)["origen"] == "aceptar_anterior"
    R["t"] = T0 + timedelta(seconds=10)
    assert _rec(c, nuevo, [0], EQ_A, "estacion") == {"resultado": "pronto", "espere_s": 5}
    assert _rec(c, otro, [0], EQ_A, "aceptar")["resultado"] == "ganada"     # quien acepta no espera
    assert _rec(c, otro, [1], EQ_B, "cocina")["resultado"] == "ganada"      # Cocina a mano tampoco
    R["t"] = T0 + timedelta(seconds=16)
    assert _rec(c, nuevo, [0], EQ_A, "estacion")["resultado"] == "ganada"
    R["t"] = T0 + timedelta(seconds=30)
    assert _rec(c, viejo, [0], EQ_A, "estacion") == {"resultado": "pronto", "espere_s": 30}   # pestaña anterior: 60 s
    R["t"] = T0 + timedelta(seconds=61)
    assert _rec(c, viejo, [0], EQ_A, "estacion")["resultado"] == "ganada"
    R["t"] = T0 + timedelta(minutes=31)
    assert _rec(c, vieja, [0], EQ_A, "estacion") == {"resultado": "vieja"}
    assert _rec(c, vieja, [0], EQ_A, "cocina")["resultado"] == "ganada"     # a mano se puede siempre
    pend = c.get("/api/pos/comanda/pendientes").json()
    assert pend["ahora"] == "2026-11-12T14:31:00-06:00"
    assert all(x["pedido_id"] not in (nuevo, viejo, vieja, otro) for x in pend["copias"])   # viejas: fuera de la lista
    una = c.get(f"/api/pos/comanda/pendientes?pedido_id={vieja}").json()["copias"]
    assert len(una) == 1 and una[0]["vieja"] is True and una[0]["lineas"][0]["estado"] == "reclamada"   # con pedido_id, aunque sea vieja


def test_pedido_programado(api, sin_limite, monkeypatch):  # noqa: F811
    L = comandas.listo_desde
    assert L("2026-11-12T14:00:00-06:00", "19:00") == "2026-11-12T18:15:00-06:00"
    assert L("2026-11-12T23:30:00-06:00", "00:30") == "2026-11-12T23:45:00-06:00"     # del día siguiente
    assert L("2026-11-12T14:00:00-06:00", "13:30") == "2026-11-12T14:00:00-06:00"     # ya pasó (menos de una hora): sale ya
    assert L("2026-11-12T14:00:00-06:00", "12:30") == "2026-11-13T11:45:00-06:00"     # más de una hora antes: mañana
    assert L("2026-11-12T14:00:00-06:00", "") == L("2026-11-12T14:00:00-06:00", "29:99") == "2026-11-12T14:00:00-06:00"
    c = api
    eid, slug, a, b = _negocio(c)
    R = _reloj(monkeypatch, T0)
    pid = _pedido3(c, slug, a, b)
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, pid); p.hora_programada = "19:00"; s.add(p); s.commit()
    _aceptar(c, pid)
    cp = _copia(eid, pid)
    assert cp["listo_desde"] == "2026-11-12T18:15:00-06:00" and cp["hora_entrega"] == "19:00" and cp["nota"].startswith("PARA LAS 19:00"), cp
    R["t"] = datetime(2026, 11, 12, 18, 15, 14, tzinfo=config.TZ_CR)
    assert _rec(c, pid, [0], EQ_A, "estacion") == {"resultado": "pronto", "espere_s": 1}
    assert c.get("/api/pedidos/resumen").json()["comanda_espera_s"] == 1
    R["t"] = datetime(2026, 11, 12, 18, 15, 16, tzinfo=config.TZ_CR)
    assert _rec(c, pid, [0], EQ_A, "estacion")["resultado"] == "ganada"


# ================================================================================================================ 5 y 6. vence, doble, soltar, agotada
def test_vence_otro_la_toma_y_la_marca_tardia_es_doble(api, sin_limite, monkeypatch, caplog):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    R = _reloj(monkeypatch, T0)
    pid = _pedido3(c, slug, a, b)
    cid = _aceptar(c, pid)
    R["t"] = T0 + timedelta(seconds=20)
    assert _rec(c, pid, [0, 1, 2], EQ_A, "estacion")["resultado"] == "ganada"
    R["t"] = T0 + timedelta(seconds=81)
    assert _rec(c, pid, [0, 1, 2], EQ_B, "estacion")["resultado"] == "ganada"
    with caplog.at_level("WARNING", logger="app.comandas"):
        r = _impresa(c, pid, EQ_A, [0, 1, 2])
    assert r == {"resultado": "doble", "copia": "impresa", "marcadas": 3, "cancelado": False}, r
    assert any("otra vez" in m for m in caplog.messages)
    assert all(f["estado"] == "impresa" for f in _filas(eid, pid).values())
    cu = _cuenta(eid, cid)
    assert [bool(l.get("impreso")) for l in cu["lineas"]] == [True, True, True, False]   # D-18 (el envío no va a cocina)
    assert _impresa(c, pid, EQ_B, [0, 1, 2])["resultado"] == "ok"           # la segunda marca no cambia nada
    assert _rec(c, pid, [0], EQ_C, "cocina") == {"resultado": "impresa"}


def test_soltar_reintentar_y_agotada(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    R = _reloj(monkeypatch, T0)
    pid = _pedido3(c, slug, a, b)
    _aceptar(c, pid)
    R["t"] = T0 + timedelta(seconds=20)
    assert _rec(c, pid, [0], EQ_A, "estacion")["resultado"] == "ganada"
    assert _soltar(c, pid, EQ_B, [0]) == {"resultado": "no_era_suya"}
    assert _soltar(c, pid, EQ_A, [0]) == {"resultado": "ok"}
    assert _rec(c, pid, [0], EQ_A, "estacion") == {"resultado": "reintente", "espere_s": 60}   # el mismo equipo espera 60 s
    for eq in (EQ_B, EQ_C):                                                   # otro equipo puede de inmediato
        assert _rec(c, pid, [0], eq, "estacion")["resultado"] == "ganada"
        assert _soltar(c, pid, eq, [0], "la impresora «Cocina» no respondió") == {"resultado": "ok"}
    assert _filas(eid, pid)[0]["intentos"] == 3
    assert _rec(c, pid, [0], EQ_D, "estacion") == {"resultado": "agotada", "motivo": "la impresora «Cocina» no respondió"}
    R["t"] = T0 + timedelta(minutes=5)
    assert _rec(c, pid, [0], EQ_A, "estacion")["resultado"] == "agotada"
    assert _rec(c, pid, [0], EQ_D, "cocina")["resultado"] == "ganada"       # Cocina a mano siempre puede
    assert _soltar(c, pid, EQ_D, [0]) == {"resultado": "ok"}
    assert _filas(eid, pid)[0]["intentos"] == 3                              # una falla a mano no cuenta


# ================================================================================================================ 7 y 8. a_caja y origen
def test_a_caja_guarda_la_copia_en_el_mismo_commit(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    original = modulos.aplicar_cambios

    def roto(*a, **k):
        raise RuntimeError("guardar la cuenta falló")
    monkeypatch.setattr(modulos, "aplicar_cambios", roto)
    with pytest.raises(RuntimeError):
        c.put(f"/api/pedidos/{pid}/estado", json={"estado": "confirmado", "reclama": True})
    monkeypatch.setattr(modulos, "aplicar_cambios", original)
    assert _copia(eid, pid) is None                                           # sin cuenta no queda copia
    with Session(engine_empresa(eid)) as s:
        assert s.get(pedidos.Pedido, pid).estado == "nuevo"
    # a_caja dos veces para el mismo pedido (retomar un aceptar a medias): una sola copia, que sigue a la cuenta nueva
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, pid); n = pedidos._negocio(s, eid)
        c1 = pedidos.a_caja(s, eid, p, n, "aceptar")
        c2 = pedidos.a_caja(s, eid, p, n, "aceptar_anterior")
    assert c1 != c2
    cp = _copia(eid, pid)
    assert cp["cuenta_id"] == c2 and cp["origen"] == "aceptar" and [l["pos"] for l in cp["lineas"]] == [0, 1, 2]
    with Session(engine_empresa(eid)) as s:
        assert s.execute(text("SELECT COUNT(*) FROM comanda_pedido WHERE empresa_id = :e AND pedido_id = :p"), {"e": eid, "p": pid}).scalar() == 1
    assert _rec(c, pid, [0], EQ_A, "cocina")["resultado"] == "ganada"
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, pid)
        c3 = pedidos.a_caja(s, eid, p, pedidos._negocio(s, eid))
    assert c3 not in (c1, c2) and _copia(eid, pid)["cuenta_id"] == c2       # con un plato reclamado, la copia no cambia de cuenta


def test_la_copia_nunca_impide_aceptar(api, sin_limite):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    with engine_empresa(eid).begin() as conn:                                 # tabla dañada (sin tocar la huella: no se vuelve a migrar)
        conn.exec_driver_sql("DROP TABLE comanda_pedido")
    try:
        cid = _aceptar(c, pid)
        assert cid and len(_cuenta(eid, cid)["lineas"]) == 4
        assert c.get("/api/pedidos/resumen").json()["comandas_pendientes"] == 0
        assert c.post(f"/api/pedidos/{pid}/comanda/impresa", json={"lineas": [0]}).json() == {"ok": True, "marcadas": 1}
    finally:
        with engine_empresa(eid).begin() as conn:
            conn.exec_driver_sql("PRAGMA user_version = 0")
        eng, _ = db._engines.pop(eid)
        eng.dispose()
        engine_empresa(eid)


def test_origen_de_la_copia(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    con, sin, raro, pago = (_pedido3(c, slug, a, b, tipo="recoger") for _ in range(4))
    _aceptar(c, con, reclama=True)
    _aceptar(c, sin, reclama=False)
    _aceptar(c, raro, reclama=False, extra={"campo_nuevo": 1, "otro": [1, 2]})    # una pestaña con campos de más sigue igual
    assert [_copia(eid, x)["origen"] for x in (con, sin, raro)] == ["aceptar", "aceptar_anterior", "aceptar_anterior"]
    from app.db import Empresa, engine
    with Session(engine) as sc:
        e = sc.get(Empresa, eid); sc.expunge(e)
    monkeypatch.setattr(pedidos, "_avisar_negocio", lambda *a, **k: None)
    monkeypatch.setattr(pedidos, "avisar_cliente", lambda *a, **k: None)
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, pago); p.estado = "pendiente_pago"; s.add(p); s.commit()
        pedidos._pago_aprobado(s, e, pedidos._negocio(s, eid), p, {"referencia": "REF-QA-431"})
        assert p.estado == "confirmado" and p.cuenta_espera_id
    cp = _copia(eid, pago)
    assert cp["origen"] == "pago" and cp["cuenta_id"] == p.cuenta_espera_id and cp["tipo"] == "llevar"


# ================================================================================================================ 9 a 11. cobro, cancelado, marcas viejas, sin comanda
def test_cuenta_cobrada_y_pedido_cancelado(api, sin_limite):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    cobrado, cancelado = _pedido3(c, slug, a, b), _pedido3(c, slug, a, b)
    cid = _aceptar(c, cobrado)
    _aceptar(c, cancelado)
    with Session(engine_empresa(eid)) as s:                                   # la caja cobró: la cuenta sale de pos_espera
        modulos.aplicar_cambios(s, eid, "pos_espera", [], [cid], [])
    una = c.get(f"/api/pos/comanda/pendientes?pedido_id={cobrado}").json()["copias"][0]
    assert una["cuenta_viva"] is False and una["estado"] == "pendiente" and una["cuenta_id"] == cid
    assert [l["detalle"] for l in una["lineas"]] == ["Casado QA", "Refresco QA", "Casado QA"] and una["lineas"][0]["huella"].endswith("|sin cebolla|2")
    lista = c.get("/api/pos/comanda/pendientes").json()["copias"]
    assert {x["pedido_id"]: x["cuenta_viva"] for x in lista if x["pedido_id"] in (cobrado, cancelado)} == {cobrado: False, cancelado: True}
    assert _rec(c, cobrado, [0, 1, 2], EQ_A, "cocina")["resultado"] == "ganada"     # la comida hay que hacerla
    r = c.put(f"/api/pedidos/{cancelado}/estado", json={"estado": "cancelado", "motivo": "Cliente QA no lo quiere"})
    assert r.status_code == 200, r.text
    assert _rec(c, cancelado, [0], EQ_A, "cocina") == {"resultado": "cancelado"}
    assert c.get(f"/api/pos/comanda/pendientes?pedido_id={cancelado}").json()["copias"][0]["estado"] == "cerrada"
    assert all(x["pedido_id"] != cancelado for x in c.get("/api/pos/comanda/pendientes").json()["copias"])


def test_cancelado_mientras_se_imprimia(api, sin_limite):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    _aceptar(c, pid)
    assert _rec(c, pid, [0, 1, 2], EQ_A, "cocina")["resultado"] == "ganada"
    assert c.put(f"/api/pedidos/{pid}/estado", json={"estado": "cancelado", "motivo": "Cliente QA"}).status_code == 200
    r = _impresa(c, pid, EQ_A, [0, 1, 2])
    assert r["cancelado"] is True and r["copia"] == "cerrada" and r["marcadas"] == 0, r


def test_ruta_vieja_y_cocina_anterior_dejan_la_comanda_impresa(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    R = _reloj(monkeypatch, T0)
    vieja, cocina, parcial = (_pedido3(c, slug, a, b) for _ in range(3))
    _aceptar(c, vieja, reclama=False)                                         # pestaña 4.29: imprime y marca con la ruta vieja
    assert c.post(f"/api/pedidos/{vieja}/comanda/impresa", json={"lineas": [0, 1, 2]}).json() == {"ok": True, "marcadas": 3}
    assert {f["equipo"] for f in _filas(eid, vieja).values()} == {"pestana-anterior"} and _copia(eid, vieja)["estado"] == "impresa"
    R["t"] = T0 + timedelta(seconds=61)
    assert _rec(c, vieja, [0, 1, 2], EQ_A, "estacion") == {"resultado": "impresa"}
    for pid, marcar in ((cocina, [0, 1, 2]), (parcial, [0])):                 # una Cocina anterior imprimió y marcó en la cuenta
        cid = _aceptar(c, pid)
        cu = _cuenta(eid, cid)
        cu["lineas"] = [{**l, "impreso": True} if i in marcar else l for i, l in enumerate(cu["lineas"])]
        with Session(engine_empresa(eid)) as s:
            modulos.aplicar_cambios(s, eid, "pos_espera", [cu], [], [])
    assert _rec(c, cocina, [0, 1, 2], EQ_A, "estacion") == {"resultado": "impresa"}
    assert {f["equipo"] for f in _filas(eid, cocina).values()} == {"cocina-anterior"} and _copia(eid, cocina)["estado"] == "impresa"
    r = _rec(c, parcial, [0, 1], EQ_A, "cocina")
    assert r["resultado"] == "ganada" and r["lineas"] == [1], r
    assert _filas(eid, parcial)[0]["estado"] == "impresa"


def test_ruta_vieja_y_cocina_anterior_que_cierran_la_copia_ponen_la_marca_de_cocina(api, sin_limite):  # noqa: F811
    """Corrección (alta 1): cuando la copia queda «impresa» por la ruta vieja o por la marca de una Cocina anterior, también se marca
    «impreso» en todos sus platos de la caja (D-18), como cuando la cierra la estación: en Cocina se ve «Impresa» y reimprimir pregunta."""
    c = api
    eid, slug, a, b = _negocio(c)
    vieja, cocina = _pedido3(c, slug, a, b), _pedido3(c, slug, a, b)
    for pid in (vieja, cocina):
        cid = _aceptar(c, pid)
        assert _impresa(c, pid, EQ_A, [], sin_comanda=[2])["copia"] == "pendiente"     # el 2 no va a ninguna impresora
    r = c.post(f"/api/pedidos/{vieja}/comanda/impresa", json={"lineas": [0, 1]})          # pestaña 4.29: imprimió y marca lo suyo
    assert r.json() == {"ok": True, "marcadas": 2} and _copia(eid, vieja)["estado"] == "impresa"
    cu = next(x for x in _todas(eid) if x.get("pedido_id") == vieja)
    assert [l.get("impreso") for l in cu["lineas"]] == [True, True, True, None], cu["lineas"]   # también el «sin comanda»; el envío no
    cid = next(x for x in _todas(eid) if x.get("pedido_id") == cocina)["id"]
    cu = _cuenta(eid, cid)                                                                       # una Cocina anterior imprimió y marcó 0 y 1
    cu["lineas"] = [{**l, "impreso": True} if i in (0, 1) else l for i, l in enumerate(cu["lineas"])]
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "pos_espera", [cu], [], [])
    assert _rec(c, cocina, [0, 1], EQ_B, "cocina") == {"resultado": "impresa"} and _copia(eid, cocina)["estado"] == "impresa"
    assert [l.get("impreso") for l in _cuenta(eid, cid)["lineas"]] == [True, True, True, None]


def test_cocina_anterior_plato_por_plato(api, sin_limite):  # noqa: F811
    """Corrección (media, prueba T9c): nunca se da por impreso un plato que no salió. Dos platos iguales con una sola marca «impreso» en
    la caja: solo uno pasa a «impresa»; el otro se reclama y se imprime. Una marca que ya corresponde a un plato impreso no cuenta dos veces."""
    c = api
    eid, slug, a, b = _negocio(c)
    _TEL["n"] += 1
    r = c.post(f"/api/publico/{slug}/pedido", json={"nombre": "Cliente QA", "telefono": f"8{_TEL['n']:07d}", "tipo": "recoger", "lineas": [
        {"producto_id": a["id"], "cantidad": 1, "nota": "sin sal"}, {"producto_id": b["id"], "cantidad": 1}, {"producto_id": a["id"], "cantidad": 1, "nota": "sin sal"}]})
    assert r.status_code == 200, r.text
    pid = r.json()["id"]
    cid = _aceptar(c, pid)
    cp = _copia(eid, pid)
    assert [l["pos"] for l in cp["lineas"]] == [0, 1, 2] and cp["lineas"][0]["huella"] == cp["lineas"][2]["huella"], cp
    cu = _cuenta(eid, cid)                                                         # una Cocina anterior marcó solo el primero de los dos iguales
    cu["lineas"] = [{**l, "impreso": True} if i == 0 else l for i, l in enumerate(cu["lineas"])]
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "pos_espera", [cu], [], [])
    r = _rec(c, pid, [0, 2], EQ_A, "cocina")
    assert r["resultado"] == "ganada" and r["lineas"] == [2], r                    # el segundo plato sale
    assert _filas(eid, pid)[0]["estado"] == "impresa" and _filas(eid, pid)[0]["equipo"] == "cocina-anterior"
    assert _impresa(c, pid, EQ_A, [2])["resultado"] == "ok"
    assert _rec(c, pid, [1], EQ_B, "cocina")["resultado"] == "ganada"              # el plato distinto sigue libre: la marca del 0 no le cuenta


def _todas(eid):
    with Session(engine_empresa(eid)) as s:
        return [x for x in modulos.leer(s, eid, "pos_espera", []) if isinstance(x, dict)]


def test_impresa_con_sin_comanda_y_solo_sin_comanda(api, sin_limite):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid, todo_sin = _pedido3(c, slug, a, b), _pedido3(c, slug, a, b)
    cid = _aceptar(c, pid)
    _aceptar(c, todo_sin)
    assert _rec(c, pid, [0, 1], EQ_A, "cocina")["resultado"] == "ganada"
    r = _impresa(c, pid, EQ_A, [0, 1], sin_comanda=[2])
    assert r == {"resultado": "ok", "copia": "impresa", "marcadas": 3, "cancelado": False}, r
    cu = _cuenta(eid, cid)
    assert [l.get("impreso") for l in cu["lineas"]] == [True, True, True, None]       # también la «sin comanda»; el envío no
    assert _copia(eid, pid)["sin_comanda"] == [2]
    r = _impresa(c, todo_sin, EQ_B, [], sin_comanda=[0, 1, 2])                # la caja no imprime comandas: nada que imprimir
    assert r == {"resultado": "ok", "copia": "sin_comanda", "marcadas": 0, "cancelado": False}, r
    assert _rec(c, todo_sin, [0], EQ_B, "estacion") == {"resultado": "impresa"}
    assert all(x["pedido_id"] not in (pid, todo_sin) for x in c.get("/api/pos/comanda/pendientes").json()["copias"])
    # una marca sin reclamo de ese equipo también se guarda (el papel salió)
    otro = _pedido3(c, slug, a, b)
    _aceptar(c, otro)
    assert _impresa(c, otro, EQ_C, [0])["resultado"] == "sin_reclamo"
    assert _filas(eid, otro)[0]["estado"] == "impresa"


def test_cuerpos_que_no_sirven_400_y_sin_copia(api, sin_limite):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    base = {"pedido_id": pid, "lineas": [0], "grupo": "10", "equipo": EQ_A, "momento": "cocina"}
    assert _rec(c, pid, [0], EQ_A, "cocina") == {"resultado": "sin_copia"}   # sin aceptar: sin copia (nunca 404)
    _aceptar(c, pid)
    for cuerpo in ({}, [], "x", {**base, "pedido_id": None}, {**base, "lineas": []}, {**base, "lineas": "0"}, {**base, "lineas": [-1]},
                   {**base, "grupo": ""}, {**base, "momento": "otro"}, {k: v for k, v in base.items() if k != "equipo"}, {**base, "lineas": list(range(201))}):
        r = c.post("/api/pos/comanda/reclamar", json=cuerpo)
        assert r.status_code == 400 and r.json()["detail"] == comandas.MENSAJE_FALTAN, (cuerpo, r.text)
    for eq in ("corto", "con espacios 123", "x" * 65, "ñandú12345"):
        r = c.post("/api/pos/comanda/reclamar", json={**base, "equipo": eq})
        assert r.status_code == 400 and r.json()["detail"] == comandas.MENSAJE_EQUIPO, eq
    r = c.post("/api/pos/comanda/reclamar", json={**base, "lineas": [0, 9]})
    assert r.status_code == 400 and r.json()["detail"] == "Esos platos no son de la comanda de este pedido: actualice la página."
    assert c.post("/api/pos/comanda/impresa", json={"pedido_id": 999999, "equipo": EQ_A, "lineas": [0]}).json() == {
        "resultado": "sin_reclamo", "copia": "cerrada", "marcadas": 0, "cancelado": False}
    assert c.post("/api/pos/comanda/soltar", json={"pedido_id": pid, "equipo": "x"}).status_code == 400
    assert c.get("/api/pos/comanda/pendientes?pedido_id=abc").status_code == 400
    assert c.get("/api/pos/comanda/pendientes?pedido_id=999999").json()["copias"] == []


# ================================================================================================================ 12. respaldos
def test_restaurar_no_revive_lo_impreso(api, sin_limite):  # noqa: F811
    from app import respaldo
    from app.db import Empresa, engine
    c = api
    eid, slug, a, b = _negocio(c)
    impresa_aqui, sigue = _pedido3(c, slug, a, b), _pedido3(c, slug, a, b)
    _aceptar(c, impresa_aqui)
    _aceptar(c, sigue)
    with Session(engine) as sc:
        e = sc.get(Empresa, eid); sc.expunge(e)
    try:
        zipf = respaldo.ejecutar_empresa(e, forzar=True)                      # respaldo con las dos copias pendientes
        assert _rec(c, impresa_aqui, [0, 1, 2], EQ_A, "cocina")["resultado"] == "ganada"
        assert _impresa(c, impresa_aqui, EQ_A, [0, 1, 2])["copia"] == "impresa"
        r = respaldo.restaurar_empresa(e, zipf)
        assert r["copiados"]["base"] == 1
        assert _copia(eid, impresa_aqui)["estado"] == "impresa"               # no se reimprime
        assert all(f["estado"] == "impresa" for f in _filas(eid, impresa_aqui).values())
        assert _copia(eid, sigue)["estado"] == "pendiente"                    # lo demás queda como venía (lo corta la vigencia)
        assert _rec(c, impresa_aqui, [0], EQ_B, "cocina") == {"resultado": "impresa"}
    finally:
        for x in respaldo.listar_empresa(eid):
            respaldo.eliminar_empresa(eid, x["nombre"])
    # respaldo de otra instalación: no se conserva nada y sus copias pendientes quedan cerradas
    assert comandas.conservar_comandas(eid, {"copias": [(sigue, "impresa")]}, ajeno=True) == 1
    assert _copia(eid, sigue)["estado"] == "cerrada"
    assert _rec(c, sigue, [0], EQ_B, "estacion") == {"resultado": "cancelado"}
    assert comandas.leer_comandas(db.EMPRESAS_DIR / "no_existe_431.db") == {} and comandas.conservar_comandas(eid, {}) == 0


# ================================================================================================================ base anterior y programa
def test_una_base_de_una_version_anterior_abre_sin_error_tambien_en_el_programa(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    for local in (False, True):
        with engine_empresa(eid).begin() as conn:                             # como una base de la 4.29: sin las tablas ni su huella
            for sql in ("DROP INDEX IF EXISTS ux_comanda_pedido", "DROP INDEX IF EXISTS ix_comanda_pedido_estado", "DROP INDEX IF EXISTS ux_comanda_reclamo",
                        "DROP TABLE IF EXISTS comanda_pedido", "DROP TABLE IF EXISTS comanda_reclamo", "PRAGMA user_version = 0"):
                conn.exec_driver_sql(sql)
        eng, _ = db._engines.pop(eid)
        eng.dispose()
        if local:
            monkeypatch.setenv("FE_MODO_LOCAL", "1")
        assert comandas.leer_comandas(db.EMPRESAS_DIR / f"empresa_{eid}.db") == {}
        with engine_empresa(eid).connect() as conn:
            tablas = {r[0] for r in conn.exec_driver_sql("SELECT name FROM sqlite_master WHERE type IN ('table', 'index')")}
            assert {"comanda_pedido", "comanda_reclamo", "ux_comanda_pedido", "ux_comanda_reclamo", "ix_comanda_pedido_estado"} <= tablas
            assert conn.exec_driver_sql("PRAGMA user_version").scalar() == db.huella_esquema()
        if local:
            monkeypatch.delenv("FE_MODO_LOCAL")
            eng, _ = db._engines.pop(eid)
            eng.dispose()
    assert _aceptar(c, pid) and _copia(eid, pid)["estado"] == "pendiente"
    assert {t.name for t in db.TABLAS_EMPRESA} >= {"comanda_pedido", "comanda_reclamo"}


# ================================================================================================================ 13. resumen, sinc, permisos y plan
def test_resumen_y_las_tablas_no_viajan(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    R = _reloj(monkeypatch, T0)
    r = c.get("/api/pedidos/resumen").json()
    assert r["comandas_pendientes"] == 0 and r["comanda_espera_s"] is None and {"nuevos", "ultimo_id", "hace"} <= set(r)
    pid = _pedido3(c, slug, a, b)
    _aceptar(c, pid)
    R["t"] = T0 + timedelta(seconds=5)
    r = c.get("/api/pedidos/resumen").json()
    assert r["comandas_pendientes"] == 1 and r["comanda_espera_s"] == 10
    R["t"] = T0 + timedelta(minutes=31)
    assert c.get("/api/pedidos/resumen").json()["comandas_pendientes"] == 0  # vieja
    import inspect
    fuente = inspect.getsource(sinc)
    assert "comanda_pedido" not in fuente and "comanda_reclamo" not in fuente and "ComandaPedido" not in fuente
    for lista in (sinc.CLAVES_CATALOGO, sinc.CLAVES_OPERATIVAS, sinc.CLAVES_RED, sinc.CLAVES_DEL_EQUIPO):
        assert not any("comanda" in str(k) for k in lista), lista


def test_permisos_y_plan_vencido():
    from tests.test_387_registros import H, _borrar, _empresa, c as cli
    usuarios = {"Administrador": "admin.est431@example.test", "Cajero": "cajero.est431@example.test", "Bodega": "bodega.est431@example.test"}
    eid, tok = _empresa("Estación 431 QA", "restaurante", {"Bodega": ["inventario"]}, usuarios, "e431")
    try:
        cuerpo = {"pedido_id": 1, "lineas": [0], "grupo": "10", "equipo": EQ_A, "momento": "cocina"}
        rutas = (("get", "/api/pos/comanda/pendientes", None), ("post", "/api/pos/comanda/reclamar", cuerpo),
                 ("post", "/api/pos/comanda/impresa", {"pedido_id": 1, "equipo": EQ_A, "lineas": [0]}), ("post", "/api/pos/comanda/soltar", {"pedido_id": 1, "equipo": EQ_A, "lineas": [0]}))
        for metodo, url, js in rutas:
            assert getattr(cli, metodo)(url, **({"json": js} if js else {})).status_code == 401, url          # sin sesión
            assert getattr(cli, metodo)(url, headers=H(tok["Bodega"]), **({"json": js} if js else {})).status_code == 403, url
            assert getattr(cli, metodo)(url, headers=H(tok["Cajero"]), **({"json": js} if js else {})).status_code == 200, url
        assert cli.post("/api/pos/comanda/reclamar", json=cuerpo, headers=H(tok["Cajero"])).json() == {"resultado": "sin_copia"}
        orig = planes.vencido
        planes.vencido = lambda e: True
        try:
            for metodo, url, js in rutas:
                r = getattr(cli, metodo)(url, headers=H(tok["Cajero"]), **({"json": js} if js else {}))
                if metodo == "get":
                    assert r.status_code == 200, r.text                      # consultar sí
                else:
                    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "plan_vencido", (url, r.text)
        finally:
            planes.vencido = orig
    finally:
        _borrar(eid, list(usuarios.values()))


# ================================================================================================================ 14. el 9800 del programa
def _pedir(puerto, ruta, origen=None):
    req = urllib.request.Request(f"http://127.0.0.1:{puerto}{ruta}", headers={"Origin": origen} if origen else {})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as ex:
        return ex.code, json.loads(ex.read().decode("utf-8"))


def test_agente_ofrece_los_ajustes_del_equipo_solo_con_fuente():
    from app import escpos
    sin = escpos.iniciar_agente_en_hilo(0, version="4.31")
    ajustes = {"propias": [], "ajustes": {"10": {"conexion": "red", "direccion": "192.168.1.50"}}, "tiquetes": "", "etiquetas": ""}
    con = escpos.iniciar_agente_en_hilo(0, version="4.31", extra={"programa": "FISITAAP QA", "modo": "completo"},
                                        fuente_equipo=lambda ced: ajustes if ced == "3101123456" else None)
    try:
        st, info = _pedir(sin.puerto, "/estado")
        assert st == 200 and "equipo" not in info
        assert _pedir(sin.puerto, "/equipo?cedula=3101123456") == (404, {"ok": False})          # el agente suelto no lo tiene
        st, info = _pedir(con.puerto, "/estado")
        assert info["equipo"] == 1 and info["programa"] == "FISITAAP QA"
        assert _pedir(con.puerto, "/equipo?cedula=3101123456", "https://fisitaap.com") == (200, {"ok": True, "equipo": ajustes})
        assert _pedir(con.puerto, "/equipo?cedula=999") == (404, {"ok": False})
        assert _pedir(con.puerto, "/equipo") == (404, {"ok": False})
        st, r = _pedir(con.puerto, "/equipo?cedula=3101123456", "https://pagina-ajena.example.test")
        assert st == 403 and "equipo" not in r
    finally:
        for s in (sin, con):
            s.shutdown(); s.server_close()


def test_programa_busca_la_empresa_por_cedula():
    from tests.test_49_local_programa import RAIZ, _cargar
    from tests.test_387_registros import _borrar, _empresa
    from app import agente_local
    programa = _cargar("local_431_prueba", RAIZ / "local" / "local.py")
    eid, _ = _empresa("Programa 431 QA", "restaurante", {}, {"Administrador": "admin.prg431@example.test"}, "94319")   # cédula 310138794319
    try:
        with Session(engine_empresa(eid)) as s:
            modulos.reemplazar(s, eid, agente_local.CLAVE_EQUIPO, {"tiquetes": "t1", "ajustes": {"10": {"conexion": "usb"}}})
        for ced in ("310138794319", "3-101-387-94319"):
            r = programa._equipo_de_empresa(ced)
            assert r is not None and r["tiquetes"] == "t1" and r["ajustes"] == {"10": {"conexion": "usb"}}, ced
        assert programa._equipo_de_empresa("1000000431") is None              # otra empresa: nunca los ajustes de esta
    finally:
        _borrar(eid, ["admin.prg431@example.test"])
    import inspect
    assert "fuente_equipo=_equipo_de_empresa" in inspect.getsource(programa.iniciar_agente)


def test_limpieza_de_copias_de_mas_de_dos_dias(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    R = _reloj(monkeypatch, T0)
    viejo, nuevo = _pedido3(c, slug, a, b), _pedido3(c, slug, a, b)
    _aceptar(c, viejo)
    assert _rec(c, viejo, [0], EQ_A, "cocina")["resultado"] == "ganada"
    R["t"] = T0 + timedelta(days=2, minutes=1)
    _aceptar(c, nuevo)
    with Session(engine_empresa(eid)) as s:
        assert comandas.limpiar(s, eid, forzar=True) == 1
        assert comandas.limpiar(s, eid) == 0                                  # una vez por hora y por proceso
    assert _copia(eid, viejo) is None and _filas(eid, viejo) == {} and _copia(eid, nuevo) is not None


# ================================================================================================================ huella y L-9
def test_huella_como_la_pantalla():
    h = comandas.huella
    assert h({"detalle": "Casado", "enviado": "2026-11-12T14:00:00-06:00", "nota": "sin cebolla", "cantidad": 2.0}) == "Casado|2026-11-12T14:00:00-06:00|sin cebolla|2"
    assert h({"detalle": "Café", "cantidad": 1.5}) == "Café|||1.5"
    assert h({"detalle": None, "enviado": None, "nota": None, "cantidad": None}) == "|||0"
    assert h({"detalle": "x", "cantidad": "3"}) == "x|||3" and h(None) == ""


def _cuenta_sola(eid, cid):
    with Session(engine_empresa(eid)) as s:
        return next(x for x in modulos.leer(s, eid, "pos_espera", []) if x["id"] == cid)


def test_l9_las_escrituras_de_pedidos_leen_la_cuenta_dentro_del_bloqueo(api, sin_limite, monkeypatch):  # noqa: F811
    """«Entregado», SINPE verificado y la marca de la ruta vieja leen la cuenta DESPUÉS de tomar el bloqueo de escritura: un plato que la
    caja guarda justo antes (otro proceso, mientras el pedido ya se estaba procesando) no se pierde."""
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    cid = _aceptar(c, pid)
    plato = {"producto_id": a["id"], "detalle": "Postre de la caja QA", "cantidad": 1, "precio_unitario": 900, "enviado": "2026-11-12T15:00:00-06:00", "ronda": 2}
    original = modulos._bloquear

    def caja_guarda_antes(s, r):                                              # la caja guarda en el instante antes del bloqueo
        if r.clave == "pos_espera" and not getattr(caja_guarda_antes, "hecho", False):
            caja_guarda_antes.hecho = True
            eng = db._nuevo_engine(f"sqlite:///{db.EMPRESAS_DIR / f'empresa_{eid}.db'}")
            with Session(eng) as otro:
                cu = next(x for x in modulos.leer(otro, eid, "pos_espera", []) if x["id"] == cid)
                original(otro, modulos._registro(otro, eid, "pos_espera"))
                modulos.aplicar_cambios(otro, eid, "pos_espera", [{**cu, "lineas": cu["lineas"] + [plato]}], [], [])
            eng.dispose()
        return original(s, r)
    monkeypatch.setattr(modulos, "_bloquear", caja_guarda_antes)
    r = c.post(f"/api/pedidos/{pid}/comanda/impresa", json={"lineas": [0]})
    assert r.json() == {"ok": True, "marcadas": 1}
    cu = _cuenta_sola(eid, cid)
    assert cu["lineas"][-1]["detalle"] == "Postre de la caja QA" and cu["lineas"][0]["impreso"] is True   # el plato de la caja sigue
    caja_guarda_antes.hecho = False
    plato["detalle"] = "Café de la caja QA"
    assert c.put(f"/api/pedidos/{pid}/estado", json={"estado": "entregado"}).status_code == 200
    cu = _cuenta_sola(eid, cid)
    assert cu["estado"] == "entregado" and [l["detalle"] for l in cu["lineas"][-2:]] == ["Postre de la caja QA", "Café de la caja QA"]
    import inspect
    fuente = inspect.getsource(pedidos)
    assert fuente.count("comandas.reescribir_cuentas(s, eid, lambda x: x.get(\"id\") == p.cuenta_espera_id,") == 2
    assert "comandas.marcar_impresas(s, eid, p.id, posiciones=list(data.lineas), cuenta_id=p.cuenta_espera_id)" in fuente


def test_l9_sinpe_verificado_dentro_del_bloqueo(api, sin_limite, monkeypatch):  # noqa: F811
    c = api
    eid, slug, a, b = _negocio(c)
    pid = _pedido3(c, slug, a, b)
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, pid); p.pago_medio = "sinpe"; s.add(p); s.commit()
    cid = _aceptar(c, pid)
    monkeypatch.setattr(pedidos, "avisar_cliente", lambda *a, **k: None)
    with Session(engine_empresa(eid)) as s:                                   # la caja guardó un plato y una nota
        cu = _cuenta_sola(eid, cid)
        modulos.aplicar_cambios(s, eid, "pos_espera", [{**cu, "nota": "nota de la caja QA", "lineas": cu["lineas"] + [{**cu["lineas"][0], "detalle": "Extra QA"}]}], [], [])
    r = c.put(f"/api/pedidos/{pid}/sinpe", json={"verificado": True})
    assert r.status_code == 200, r.text
    cu = _cuenta_sola(eid, cid)
    assert cu["prepago"] and cu["prepago"]["medio"] == "06" and cu["lineas"][-1]["detalle"] == "Extra QA" and cu["nota"] == "nota de la caja QA"
    with Session(engine_empresa(eid)) as s:                                   # con cobros en la caja no se toca (como antes)
        modulos.aplicar_cambios(s, eid, "pos_espera", [{**cu, "cobros": [{"doc_id": 1}], "prepago": None}], [], [])
    assert c.put(f"/api/pedidos/{pid}/sinpe", json={"verificado": False, "motivo": "QA"}).status_code == 200
    assert _cuenta_sola(eid, cid)["prepago"] is None
