# -*- coding: utf-8 -*-
"""4.39, cuarta vuelta de los arreglos de la comanda automática al cobrar (16 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos (o tres) «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py y las ayudas de tests/test_439_tercera_vuelta.py: destinoDe e impresoraDe reales, la Cocina como única
impresora de comanda y cada comanda anotada).

- U1 fusionarAbierta y persistirCuenta: si al juntar, un plato que en la pantalla estaba sin enviar queda «enviado» (otro equipo tocó
  «Comanda»), anotan this._marcaAjena = {id de la cuenta, hora}.
- U2 emitirCobro (toda cuenta guardada, también de mesa) y reclamarHab: con una marca de esa cuenta de hace menos de 4 s se espera lo que
  falta (allá la revisión de esa comanda dura 3 s como mucho y la imprime si la cuenta sigue abierta). B toca «Comanda» con su revisión
  lenta y A cobra (o carga a la habitación) enseguida: una comanda (la de B) y un comprobante (o un cargo). Sin marca reciente, con la marca
  vieja, con la de otra cuenta o tras la «Comanda» de la misma A, no se espera. La espera de la habitación va en tramos de 200 ms: al
  cerrar la ventana se deja de esperar.
- U3 los avisos nuevos: emitirCobro con la habitación revisando («Se está revisando el cargo a la habitación…») y el segundo toque en
  «Cargar» («Se está revisando la cuenta para cargarla…»); «Cargar» con una parte en cobro no carga. Después la caja sigue cobrando.
- U4 «Cobrar parte» y «Habitación» cruzados: abrirCargoHab no abre con una parte en cobro ni si mientras esperaba se abrió el cobro;
  abrirPago y cobrarParte, después de sus esperas, no abren el cobro ni parten la cuenta si se abrió la habitación (si era una parte,
  vuelve a la cuenta). Ninguna parte colgada, nada cobrado o cargado dos veces, la cuenta del servidor intacta.
- U5 revisarComanda: los platos dudosos que siguen en la cuenta salen con la cantidad y la nota del servidor (B subió el Casado a 2 o
  cambió la nota y A, sin sincronizar, toca «Comanda»), con y sin numeración; con dos «Comanda» a la vez, la única lleva ×2.
- U6 alDiaCuentaNueva: la cuenta rehecha por el servidor que se llama «Cuenta N» (sin nombre en pantalla) y repite el nombre de otra
  cuenta abierta pasa al número siguiente, en el servidor y en todos los equipos; la de una mesa o con nombre propio no se renombra.
Cada caso corre también, cuando se puede, con los métodos de ANTES de esta vuelta: se sacan de caja.js con la cuarta vuelta deshecha
(CUARTA y _caja_sin_cuarta de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la vuelta) y
ahí se ve el defecto que el cambio arregla.
Defecto que quedaba (era xfail estricto): «Cobrar parte» o «Dividir» en partes iguales justo después de la «Comanda» de otro equipo
partían la cuenta antes de que esa comanda se revisara: no salía de ningún equipo. 4.39 (quinta vuelta, V4): arreglado; ahora es una prueba
normal (test_v4_..., abajo). Las pruebas de la quinta vuelta están en tests/test_439_quinta_vuelta.py.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import _metodo
from tests.test_439_revision_arreglos import CASADO, COMANDA, EMITIR, LIMONADA, POSTRE, RECLAMAR, SOLTAR
from tests.test_439_tercera_vuelta import AMBOS, CUARTA, EN_CURSO, FOLIOS, TERMINE, _caja_sin_cuarta, _caja_sin_quinta
from tests.test_439_tercera_vuelta import _correr as _correr3

# los métodos que cambió la cuarta vuelta (cada par de CUARTA está en uno de ellos)
CAMBIADOS = ("persistirCuenta(devolverId) {", "fusionarAbierta(motivo) {", "async alDiaCuentaNueva(id) {", "async revisarComanda(e, dudosas) {",
             "async reclamarHab() {", "async cobrarParte(n) {", "async abrirPago() {", "async emitirCobro(otra) {", "async abrirCargoHab() {",
             "cargarAHabitacion() {")
REVISA_HAB = "Se está revisando el cargo a la habitación: espere un momento"
REVISA_CARGA = "Se está revisando la cuenta para cargarla: espere un momento"
OTRA_VEZ = "No salieron otra vez en la comanda: Casado, Postre. Ya se habían mandado a cocina desde otro equipo."
NO_SALIERON = "No salieron en la comanda: Casado, Postre. En otro equipo ya se habían quitado o cobrado de {}."
MEDIAS = ["Casado×0.5", "Postre×0.5"]


def _antes():
    """Los métodos que cambió la cuarta vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k = _caja_sin_cuarta()
    return tuple(_metodo(k, c) for c in CAMBIADOS)


AYUDAS = r"""
const REVISA_HAB = @REVISA_HAB@, REVISA_CARGA = @REVISA_CARGA@;
// el estado de la pantalla que importa aquí, y la lista de cuentas del servidor con sus partes
const estado = vm => ({ pago: !!vm.pago, hab: !!vm.habCargo, parcial: !!vm.cobroParcial, cobrando: vm.cobrando, enCurso: !!vm._cobroEnCurso, habEnCurso: !!vm._habEnCurso, platos: detalles(vm), cuenta: vm.esperaId });
const srv = () => S.items.map(x => [x.nombre, (x.lineas || []).map(l => l.detalle + '×' + l.cantidad).sort(), x.partes || null]);
// la Mesa 6 guardada sin enviar (por un tercer equipo) y abierta en A y en B (los dos con la caja en la venta)
async function mesaGuardada(platos) {
  nuevo();
  const g = venta(await equipo()); g.abrirMesa(M6); for (const p of platos) g.lineas.push(p); g.persistirCuenta(); await g.A.mock.guardarTodo();
  const id = S.items[S.items.length - 1].id;
  const a = venta(await equipo()), b = venta(await equipo());
  await a.sincronizar(); a.abrirMesa(M6); await b.sincronizar(); b.abrirMesa(M6);
  return [id, a, b];
}
// la hoja para la firma del huésped (comandaHab) queda anotada; «Cargar» con la habitación elegida
const HOJAS = [];
async function cargar(a) { a.comandaHab = (r, ls) => HOJAS.push(ls.map(l => l.detalle + '×' + l.cantidad).sort()); if (a.habCargo) { a.habCargo.reserva_id = 1; await a.cargarAHabitacion(); } await hastaLibre(); await a.A.mock.guardarTodo(); }
// la comanda con la nota de cada plato (el arnés anota «Plato×cantidad»; aquí también la nota y el número)
const NOTAS = [];
const conNotas = vm => { const f = vm.imprimirComanda; vm.imprimirComanda = (g, r, d) => { const ls = []; for (const x of Object.values(g)) for (const l of x.ls) ls.push(l.detalle + '×' + l.cantidad + (l.nota ? ' «' + l.nota + '»' : '')); NOTAS.push([vm.nEq, ls.sort(), (d && d.numero) || null]); return f(g, r, d); }; return vm; };
const nombres = vm => (vm ? vm.espera : S.items).map(x => [x.id, x.nombre]);
"""


def _correr(tmp_path, casos, antes=()):
    guion = AYUDAS.replace("@REVISA_HAB@", json.dumps(REVISA_HAB)).replace("@REVISA_CARGA@", json.dumps(REVISA_CARGA)) + casos
    return _correr3(tmp_path, guion, antes=antes)


# ================================================================================================================ U1 y U2: esperar la comanda de otro equipo
CASOS_U12 = r"""
// A y B tienen la cuenta (guardada sin mesa, o la Mesa 6) con Casado y Postre sin enviar. B toca «Comanda» y su revisión es lenta (su lista
// llega `ms` después); en cuanto el guardado de B llegó al servidor, A junta (al abrir el cobro: alDiaParaCobrar; o al sincronizar) y cobra
// enseguida (o, con la ventana de la habitación abierta, toca «Cargar»). `ta`: lo que tardó el cobro (o el cargo) de A
async function marcaAjena(como, ms) {
  let id, a, b;
  if (como.mesa) [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]);
  else { id = await guardada([CASADO(), POSTRE()]); a = await abierta(id); b = await abierta(id); }
  const suelta = lento(b, ms);
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  if (como.sinc) await a.sincronizar();
  if (como.hab) a.habCargo = HAB(); else await a.abrirPago();
  const marca = !!a._marcaAjena && a._marcaAjena.id === id, tm = marca ? a._marcaAjena.t : null, pago = !!a.pago;
  let fin = 0; const t0 = Date.now(); const pa = (como.hab ? a.cargarAHabitacion() : a.cobrar()).then(() => { fin = Date.now(); return fin - t0; });
  const [, ta] = await Promise.all([pb, pa]); suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  return { ta, desdeMarca: tm === null ? null : fin - tm, marca, pago, impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), hechos: hechos().map(h => [quien(h[0], a), h[1], h[2]]), folios: folios(), noSalioB: noSalio(b),
    comandasB: comandas(b), servidor: servidor(), pagoFin: !!a.pago, hab: !!a.habCargo, orden: orden(a.nEq), libre: libre(), noHay: conTexto(a, NO_HAY) };
}
"""
HECHO_A = [["A", CASADO + POSTRE, AMBOS]]


def _comprobar_espera(c, cargo=False):
    """Una comanda (la de B, con los dos platos) y un comprobante o un cargo (el de A), con la espera de A."""
    assert c["marca"] is True and c["impresos"] == [["B", AMBOS]] and c["comandasB"] == ["Comanda 1 enviada a Cocina"] and c["noSalioB"] == [], c
    assert c["servidor"] == [] and c["pagoFin"] is False and c["hab"] is False and c["libre"] is True and c["noHay"] == [], c
    if cargo:
        assert c["folios"] == FOLIOS and c["hechos"] == [] and c["orden"] == [RECLAMAR, SOLTAR], c
    else:
        assert c["pago"] is True and c["hechos"] == HECHO_A and c["folios"] == [] and c["orden"] == [RECLAMAR, EMITIR, SOLTAR, SOLTAR], c   # A no manda comanda
    assert c["desdeMarca"] >= 3950 and c["ta"] < 6500, c                                                # A terminó 4 s (o más) después de la marca


def _comprobar_sin_espera(v, nombre, cargo=False):
    """Antes de esta vuelta: A cobraba (o cargaba) sin esperar y cerraba la cuenta; la revisión de B ya no la encontraba: los platos se
    cobraban y nunca llegaban a cocina."""
    assert v["marca"] is False and v["impresos"] == [] and v["comandasB"] == [] and v["noSalioB"] == [NO_SALIERON.format(nombre)], v
    assert (v["folios"] == FOLIOS and v["hechos"] == []) if cargo else (v["hechos"] == HECHO_A), v
    assert v["ta"] < 1000 and v["servidor"] == [], v


def test_u1_u2_al_cobrar_se_espera_la_comanda_de_otro_equipo_en_node(tmp_path):
    casos = CASOS_U12 + "\nout.cobro = await marcaAjena({}, 1500);\nout.sinc = await marcaAjena({ sinc: true }, 2000);\n"
    r = _correr(tmp_path / "ahora", casos)
    _comprobar_espera(r["cobro"])                                                                       # la marca la junta alDiaParaCobrar
    _comprobar_espera(r["sinc"])                                                                        # la marca la trajo sincronizar
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    _comprobar_sin_espera(v["cobro"], "Cuenta 1")
    _comprobar_sin_espera(v["sinc"], "Cuenta 1")


def test_u1_u2_en_una_mesa_y_al_cargar_a_la_habitacion_en_node(tmp_path):
    casos = CASOS_U12 + "\nout.mesa = await marcaAjena({ mesa: true }, 1500);\nout.hab = await marcaAjena({ sinc: true, hab: true }, 2000);\n"
    r = _correr(tmp_path / "ahora", casos)
    _comprobar_espera(r["mesa"])                                                                        # también en una mesa (sin comanda al cobrar)
    _comprobar_espera(r["hab"], cargo=True)                                                             # reclamarHab espera antes de pedir el cobro
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    _comprobar_sin_espera(v["mesa"], "Mesa 6")
    _comprobar_sin_espera(v["hab"], "Cuenta 1", cargo=True)


# ================================================================================================================ U2: cuándo no se espera
CASOS_U2_NO = r"""
const cobroDeA = async (a, cargo) => { const t0 = Date.now(); if (cargo) await a.cargarAHabitacion(); else await a.cobrar(); return Date.now() - t0; };
// (sin) nadie más tocó la cuenta: ni marca ni espera, al cobrar ni al cargar
for (const cargo of [false, true]) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  if (cargo) a.habCargo = HAB(); else await a.abrirPago();
  const t = await cobroDeA(a, cargo); await hastaLibre(); await a.A.mock.guardarTodo();
  out[cargo ? 'sin_hab' : 'sin'] = { t, marca: a._marcaAjena || null, impresos: impresos(), hechos: hechos().map(h => h[2]), folios: folios(), servidor: servidor() };
}
// (vieja) B mandó su comanda (ya salió) y A la juntó; A cobra más de 4 s después
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  await a.sincronizar(); const marca = !!a._marcaAjena && a._marcaAjena.id === id; await espera(4100);
  await a.abrirPago(); const t = await cobroDeA(a); await hastaLibre(); await a.A.mock.guardarTodo();
  out.vieja = { marca, t, impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), hechos: hechos().map(h => [quien(h[0], a), h[2]]), servidor: servidor(), orden: orden(a.nEq) }; }
// (propia) A toca «Comanda» (con su revisión: los platos ya estaban guardados), sincroniza y cobra enseguida: lo enviado es suyo, no hay marca
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  await a.enviarComanda(); await a.A.mock.guardarTodo(); await a.sincronizar();
  const marca = a._marcaAjena || null;
  await a.abrirPago(); const t = await cobroDeA(a); await hastaLibre(); await a.A.mock.guardarTodo();
  out.propia = { marca, t, impresos: impresos(), hechos: hechos().map(h => h[2]), servidor: servidor(), orden: orden(a.nEq) }; }
// (otra_cuenta) A juntó la comanda de B en la cuenta 1 y enseguida cobra la cuenta 2: la marca es de otra cuenta
{ nuevo(); const g = venta(await equipo()); g.lineas.push(CASADO()); g.guardarCuenta(); await g.A.mock.guardarTodo(); g.lineas.push(POSTRE()); g.guardarCuenta(); await g.A.mock.guardarTodo();
  const [id1, id2] = S.items.map(x => x.id);
  const a = await abierta(id1), b = await abierta(id1);
  await b.enviarComanda(); await b.A.mock.guardarTodo(); await a.sincronizar(); const marca = a._marcaAjena ? a._marcaAjena.id : null;
  a.recuperar(a.espera.find(x => x.id === id2)); a._alDia = 0;
  await a.abrirPago(); const t = await cobroDeA(a); await hastaLibre(); await a.A.mock.guardarTodo();
  out.otra_cuenta = { marca, id1, id2, t, impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), hechos: hechos().map(h => [quien(h[0], a), h[2]]), servidor: servidor().map(x => [x.id, x.platos]) }; }
"""


def test_u2_sin_marca_reciente_el_cobro_no_espera_en_node(tmp_path):
    r = _correr(tmp_path, CASOS_U2_NO)
    for k in ("sin", "sin_hab"):
        s = r[k]
        assert s["t"] < 2000 and s["marca"] is None and s["impresos"] == [AMBOS] and s["servidor"] == [], (k, s)   # una comanda, al cobrar (o cargar)
        assert (s["folios"] == FOLIOS and s["hechos"] == []) if k == "sin_hab" else (s["hechos"] == [AMBOS] and s["folios"] == []), (k, s)
    v = r["vieja"]
    assert v["marca"] is True and v["t"] < 2000, v                                                      # la marca tiene más de 4 s
    assert v["impresos"] == [["B", AMBOS]] and v["hechos"] == [["A", AMBOS]] and v["servidor"] == [] and v["orden"] == [RECLAMAR, EMITIR, SOLTAR, SOLTAR], v
    p = r["propia"]
    assert p["marca"] is None and p["t"] < 2000, p                                                      # su propia «Comanda» no deja marca
    assert p["impresos"] == [AMBOS] and p["hechos"] == [AMBOS] and p["servidor"] == [] and p["orden"] == [COMANDA, RECLAMAR, EMITIR, SOLTAR, SOLTAR], p
    o = r["otra_cuenta"]
    assert o["marca"] == o["id1"] and o["t"] < 2000, o                                                  # la marca es de la cuenta 1; se cobra la 2
    assert o["impresos"] == [["B", ["Casado×1"]], ["A", ["Postre×1"]]] and o["hechos"] == [["A", ["Postre×1"]]] and o["servidor"] == [[o["id1"], ["Casado×1"]]], o


CASOS_U2_CIERRA = r"""
// (cierra) A juntó la comanda de B (marca) y abrió la ventana de la habitación; toca «Cargar» y a los 300 ms cierra la ventana: deja de esperar
// y no pide el cobro
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  await b.enviarComanda(); await b.A.mock.guardarTodo(); await a.sincronizar();
  a.habCargo = HAB(); const t0 = Date.now(); const p = a.cargarAHabitacion(); await espera(300); a.habCargo = null; await p; const t = Date.now() - t0;
  await hastaLibre(); await a.A.mock.guardarTodo();
  const o = out.cierra = { t, habEnCurso: !!a._habEnCurso, folios: folios(), orden: orden(a.nEq), servidor: servidor().map(x => x.platos), platos: detalles(a), cuenta: a.esperaId === id };
  await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();   // la caja sigue: se cobra
  o.luego = { hechos: hechos().map(h => h[2]), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), servidor: servidor() }; }
// (bucle) B toca «Comanda» con la revisión lenta; A, con la ventana abierta y sin sincronizar, toca «Cargar» (al juntar llega «enviado»: la
// espera de 4 s del bucle) y a los 1,5 s cierra la ventana: cuánto tarda en soltar el cobro
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  const suelta = lento(b, 1500);
  a.habCargo = HAB();
  const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
  const p = a.cargarAHabitacion(); await espera(1500); const enCurso = !!a._habEnCurso; a.habCargo = null; const t1 = Date.now(); await p; const t = Date.now() - t1;
  await pb; suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  out.bucle = { enCurso, t, habEnCurso: !!a._habEnCurso, folios: folios(), impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), orden: orden(a.nEq), libre: libre(), servidor: servidor().map(x => x.platos) }; }
"""


def test_u2_la_espera_de_la_habitacion_se_corta_al_cerrar_la_ventana_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U2_CIERRA)
    c = r["cierra"]
    # la espera de la marca (antes de pedir el cobro) se corta: ni cobro pedido ni cargo; la cuenta sigue en pantalla y en el servidor
    assert c["t"] < 1000 and c["habEnCurso"] is False and c["folios"] == [] and c["orden"] == [] and c["servidor"] == [AMBOS], c
    assert c["platos"] == AMBOS and c["cuenta"] is True, c
    assert c["luego"]["hechos"] == [AMBOS] and c["luego"]["impresos"] == [["B", AMBOS]] and c["luego"]["servidor"] == [], c   # se cobra una vez, sin otra comanda
    b = r["bucle"]
    # la espera de 4 s del bucle se corta en el tramo siguiente: el cobro pedido queda libre enseguida (F9 ya no se frena) y no se carga
    assert b["enCurso"] is True and b["t"] < 1000 and b["habEnCurso"] is False and b["libre"] is True, b
    assert b["folios"] == [] and b["impresos"] == [["B", AMBOS]] and b["orden"] == [RECLAMAR, SOLTAR] and b["servidor"] == [AMBOS], b

    # reclamarHab de antes: la espera del bucle era de 4 s de una vez: con la ventana ya cerrada seguía «revisando» (y el cobro pedido) hasta el final
    v = _correr(tmp_path / "antes", CASOS_U2_CIERRA, antes=_antes())
    assert v["bucle"]["t"] >= 2000 and v["bucle"]["folios"] == [] and v["bucle"]["libre"] is True, v["bucle"]


# ================================================================================================================ U3: los avisos
CASOS_U3 = r"""
// (cierra_y_cobra) «Cargar» pide el cobro (el servidor tarda) y la cajera cierra la ventana de la habitación, abre el cobro y toca «Cobrar»
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  C.reclamoLento = 400; a.habCargo = HAB(); const p1 = a.cargarAHabitacion(); await espera(30);
  a.habCargo = null; await a.abrirPago(); const e1 = estado(a);
  await a.cobrar(); const e2 = estado(a), hechos2 = hechos().length;
  await p1; C.reclamoLento = 0; await hastaLibre(); const e3 = estado(a);
  await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();   // la caja sigue: el cobro sale
  out.cierra_y_cobra = { e1, e2, hechos2, e3, fin: estado(a), avisos: conTexto(a, REVISA_HAB), hechos: hechos().map(h => [h[1], h[2]]), impresos: impresos(), folios: folios(), orden: orden(a.nEq), servidor: servidor(), libre: libre() }; }
// (segundo) dos toques en «Cargar»: el segundo, mientras el primero pide el cobro
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  a.habCargo = HAB(); C.reclamoLento = 300;
  const p1 = a.cargarAHabitacion(); await espera(30); const enCurso = !!a._habEnCurso && !!a.habCargo; const p2 = a.cargarAHabitacion();
  await Promise.all([p1, p2]); C.reclamoLento = 0; await hastaLibre(); await a.A.mock.guardarTodo();
  const o = out.segundo = { enCurso, avisos: conTexto(a, REVISA_CARGA), folios: folios(), impresos: impresos(), orden: orden(a.nEq), servidor: servidor(), fin: estado(a) };
  // la caja sigue: otra venta rápida (tras el cargo el arnés deja la caja en «Mesas») a la habitación, con su comanda
  a.nuevaVentaRapida(); a.lineas.push(LIMONADA()); a.habCargo = HAB(); await a.cargarAHabitacion(); await hastaLibre(); await a.A.mock.guardarTodo();
  o.luego = { folios: folios(), impresos: impresos(), servidor: servidor(), fin: estado(a) }; }
// (parte) con «Cobrar parte 1 de 2» abierta, la ventana de la habitación (simulada: abrirCargoHab ya no la abre) y «Cargar»; después se cancela la parte
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  await a.cobrarParte(2); await a.A.mock.guardarTodo(); const e0 = estado(a), s0 = srv();
  a.habCargo = HAB(); a.comandaHab = () => {}; await a.cargarAHabitacion(); await hastaLibre();
  const e1 = estado(a), f1 = folios();
  a.habCargo = null; a.cerrarPago(); await hastaLibre(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  out.parte = { e0, s0, e1, f1, avisos: conTexto(a, EN_CURSO), fin: estado(a), srv: srv(), hechos: hechos().length }; }
"""


def test_u3_los_avisos_y_la_caja_sigue_cobrando_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U3)
    c = r["cierra_y_cobra"]
    # «Cobrar» con la habitación todavía revisando: el aviso nuevo, nada se emite y la caja no queda trabada
    assert c["e1"]["pago"] is True and c["e1"]["habEnCurso"] is True and c["avisos"] == [REVISA_HAB], c
    assert c["hechos2"] == 0 and c["e2"]["cobrando"] is False and c["e2"]["enCurso"] is False and c["e2"]["pago"] is True and c["e2"]["platos"] == AMBOS, c
    assert c["e3"]["habEnCurso"] is False and c["e3"]["pago"] is True, c                                # la habitación soltó su cobro
    # después, el cobro sale una vez con su comanda; nada se cargó a la habitación
    assert c["hechos"] == [[CASADO + POSTRE, AMBOS]] and c["impresos"] == [AMBOS] and c["folios"] == [] and c["servidor"] == [] and c["libre"] is True, c
    assert c["orden"] == [RECLAMAR, SOLTAR, RECLAMAR, COMANDA, EMITIR, SOLTAR, SOLTAR] and c["fin"]["pago"] is False, c
    s = r["segundo"]
    assert s["enCurso"] is True and s["avisos"] == [REVISA_CARGA], s                                   # el segundo toque avisa
    assert s["folios"] == FOLIOS and s["impresos"] == [AMBOS] and s["orden"] == [RECLAMAR, COMANDA, SOLTAR] and s["servidor"] == [], s   # un cargo, una comanda
    assert s["fin"]["hab"] is False and s["fin"]["habEnCurso"] is False, s
    assert s["luego"]["folios"] == ["Casado (Cuenta 1)", "Limonada", "Postre (Cuenta 1)"] and s["luego"]["impresos"] == [AMBOS, ["Limonada×1"]], s
    p = r["parte"]
    assert p["e0"]["parcial"] is True and p["e0"]["pago"] is True and p["e0"]["platos"] == MEDIAS, p
    # «Cargar» con la parte en cobro: aviso, nada se carga; al cancelar la parte vuelve y la cuenta del servidor queda como estaba
    assert p["avisos"] == [EN_CURSO] and p["f1"] == [] and p["e1"]["platos"] == MEDIAS and p["e1"]["parcial"] is True, p
    assert p["fin"]["platos"] == AMBOS and p["fin"]["parcial"] is False and p["fin"]["pago"] is False and p["srv"] == [["Cuenta 1", AMBOS, None]] and p["hechos"] == 0, p

    # antes de esta vuelta: «Cobrar» y el segundo toque callaban, y «Cargar» con la parte en cobro cargaba la mitad a la habitación con la
    # ventana de cobro de esa parte todavía abierta (la cuenta quedaba con la otra mitad y sus «2 partes»)
    v = _correr(tmp_path / "antes", CASOS_U3, antes=_antes())
    assert v["cierra_y_cobra"]["avisos"] == [] and v["segundo"]["avisos"] == [], v
    vp = v["parte"]
    assert vp["avisos"] == [] and vp["f1"] == FOLIOS and vp["e1"]["platos"] == [] and vp["e1"]["pago"] is True and vp["e1"]["parcial"] is True, vp
    assert vp["srv"] == [["Cuenta 1", MEDIAS, {"total": 2, "cobradas": 0}]], vp


# ================================================================================================================ U4: «Cobrar parte» y «Habitación» cruzados
CASOS_U4 = r"""
// (parte) «Cobrar parte 1 de 2» espera la lista (lenta) y mientras tanto se abre «Habitación»; después F9 y «Cargar»
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id); HOJAS.length = 0;
  const suelta = lento(a, 400);
  const pp = a.cobrarParte(2); await espera(60); await a.abrirCargoHab(); const medio = estado(a);
  await pp; suelta(); await a.A.mock.guardarTodo(); const tras = estado(a), s1 = srv();
  const f9 = tecla(a, 'F9'); await espera(50);
  await cargar(a);
  out.parte = { medio, tras, s1, f9, fin: estado(a), folios: folios(), hojas: HOJAS.slice(), hechos: hechos().length, impresos: impresos(), srv: srv(), orden: orden(a.nEq) }; }
// (pago) abrirPago espera alDiaParaCobrar (lenta) y mientras tanto se abre «Habitación»; «Cargar» y, si quedó la ventana de cobro, «Cobrar»
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id); HOJAS.length = 0;
  const suelta = lento(a, 400);
  const pp = a.abrirPago(); await espera(60); await a.abrirCargoHab(); const medio = estado(a);
  await pp; suelta(); const tras = estado(a), s1 = srv();
  await cargar(a);
  const o = out.pago = { medio, tras, s1, fin: estado(a), folios: folios(), hojas: HOJAS.slice(), hechos: hechos().length, impresos: impresos(), srv: srv(), orden: orden(a.nEq) };
  if (a.pago) { await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); }
  o.luego = { folios: folios(), hechos: hechos().map(h => [h[1], h[2]]), fin: estado(a) }; }
// (hab_pago, hab_parte) abrirCargoHab espera cobroPermitido (lento) y mientras tanto se abre el cobro (F9) o «Cobrar parte»; después se cancela
for (const via of ['pago', 'parte']) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  const cp0 = a.cobroPermitido; a.cobroPermitido = async acc => { if (acc === 'cargar a la habitación') await espera(300); return cp0(acc); };
  const ph = a.abrirCargoHab(); await espera(30);
  if (via === 'pago') await a.abrirPago(); else await a.cobrarParte(2);
  await conPago(a); await ph; await a.A.mock.guardarTodo(); const tras = estado(a), s1 = srv();
  a.cobroPermitido = cp0;
  await cargar(a); const f1 = folios();
  a.cerrarPago(); await hastaLibre(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  out['hab_' + via] = { tras, s1, f1, fin: estado(a), folios: folios(), hechos: hechos().length, srv: srv(), libre: libre() };
}
// (abriendo) «Cobrar parte» ya partió la cuenta y su ventana de cobro se está abriendo (abrirPago espera cobroPermitido, lento): en ese momento
// «Habitación». Después se cancela la parte
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  const cp0 = a.cobroPermitido; let n = 0; a.cobroPermitido = async acc => { if (acc === 'cobrar' && ++n === 2) await espera(300); return cp0(acc); };
  await a.cobrarParte(2); await hasta(() => !!a.cobroParcial); const medio = estado(a);
  await a.abrirCargoHab(); const hab = !!a.habCargo; await conPago(a); await espera(50); await a.A.mock.guardarTodo(); const tras = estado(a);
  a.cobroPermitido = cp0; a.habCargo = null; a.cerrarPago(); await hastaLibre(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  out.abriendo = { medio, hab, tras, avisos: conTexto(a, TERMINE), fin: estado(a), srv: srv() }; }
// (devuelve) simulado: la ventana de la habitación aparece mientras el abrirPago de «Cobrar parte» espera cobroPermitido: la parte vuelve a la cuenta
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  const cp0 = a.cobroPermitido; let n = 0; a.cobroPermitido = async acc => { if (++n === 2) await espera(200); return cp0(acc); };
  const pp = a.cobrarParte(2); await hasta(() => !!a.cobroParcial); const medio = estado(a);
  a.habCargo = HAB(); await espera(300); await pp; await hastaLibre(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  out.devuelve = { medio, tras: estado(a), srv: srv(), orden: orden(a.nEq), libre: libre(), hechos: hechos().length }; }
"""
INTACTA = [["Cuenta 1", AMBOS, None]]


def test_u4_cobrar_parte_y_habitacion_cruzados_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U4)
    p = r["parte"]
    # la habitación se abrió mientras «Cobrar parte» esperaba: la cuenta no se parte (ni parte colgada ni ventana de cobro) y queda intacta
    assert p["medio"]["hab"] is True and p["tras"] == {**p["tras"], "pago": False, "hab": True, "parcial": False, "platos": AMBOS}, p
    assert p["s1"] == INTACTA and p["f9"] is True, p
    # «Cargar»: un cargo y una comanda, con la cuenta entera
    assert p["folios"] == FOLIOS and p["hojas"] == [AMBOS] and p["hechos"] == 0 and p["impresos"] == [AMBOS] and p["srv"] == [], p
    assert p["orden"] == [RECLAMAR, COMANDA, SOLTAR] and p["fin"]["parcial"] is False and p["fin"]["pago"] is False, p
    g = r["pago"]
    assert g["medio"]["hab"] is True and g["tras"]["pago"] is False and g["tras"]["hab"] is True and g["s1"] == INTACTA, g   # el cobro no se abre debajo
    assert g["folios"] == FOLIOS and g["hojas"] == [AMBOS] and g["hechos"] == 0 and g["srv"] == [] and g["luego"]["hechos"] == [], g
    for k in ("hab_pago", "hab_parte"):
        x = r[k]
        # el cobro (o la parte) se abrió mientras abrirCargoHab esperaba: la habitación no se abre encima; al cancelar, todo vuelve
        assert x["tras"]["pago"] is True and x["tras"]["hab"] is False and x["f1"] == [], (k, x)
        assert x["fin"]["platos"] == AMBOS and x["fin"]["parcial"] is False and x["fin"]["pago"] is False and x["srv"] == INTACTA, (k, x)
        assert x["folios"] == [] and x["hechos"] == 0 and x["libre"] is True, (k, x)
    assert r["hab_parte"]["tras"]["parcial"] is True and r["hab_parte"]["s1"] == [["Cuenta 1", MEDIAS, {"total": 2, "cobradas": 0}]], r["hab_parte"]
    u = r["abriendo"]
    # con la parte ya partida y su ventana de cobro abriéndose, «Habitación» avisa y no abre; la ventana de la parte se abre sola; al
    # cancelar, la parte vuelve
    assert u["medio"]["parcial"] is True and u["medio"]["pago"] is False and u["hab"] is False and u["avisos"] == [TERMINE], u
    assert u["tras"]["pago"] is True and u["tras"]["hab"] is False and u["tras"]["parcial"] is True, u
    assert u["fin"]["platos"] == AMBOS and u["fin"]["parcial"] is False and u["fin"]["pago"] is False and u["srv"] == INTACTA, u
    d = r["devuelve"]
    # la parte vuelve a la cuenta (cerrarPago): sin ventana de cobro ni parte colgada, la cuenta del servidor como estaba
    assert d["medio"]["parcial"] is True and d["tras"] == {**d["tras"], "pago": False, "hab": True, "parcial": False, "platos": AMBOS}, d
    assert d["srv"] == INTACTA and d["hechos"] == 0 and d["libre"] is True and d["orden"] == [RECLAMAR, SOLTAR], d

    # antes de esta vuelta: la parte quedaba colgada (cobroParcial sin ventana) y su mitad se cargaba a la habitación dejando la cuenta con
    # «2 partes» sin cobrar; el cobro se abría debajo de la habitación y, cargada la cuenta, «Cobrar» emitía un tiquete vacío; la
    # habitación se abría encima del cobro o de la parte
    v = _correr(tmp_path / "antes", CASOS_U4, antes=_antes())
    vp = v["parte"]
    assert vp["tras"]["parcial"] is True and vp["tras"]["pago"] is False and vp["tras"]["hab"] is True, vp
    assert vp["hojas"] == [MEDIAS] and vp["fin"]["parcial"] is True and vp["srv"] == [["Cuenta 1", MEDIAS, {"total": 2, "cobradas": 0}]], vp
    vg = v["pago"]
    assert vg["tras"]["pago"] is True and vg["tras"]["hab"] is True and vg["luego"]["hechos"] == [[0, []]], vg
    for k in ("hab_pago", "hab_parte"):
        assert v[k]["tras"]["pago"] is True and v[k]["tras"]["hab"] is True and v[k]["f1"] == FOLIOS, (k, v[k])
    va = v["abriendo"]                                                                                  # la habitación encima de la parte: las dos ventanas
    assert va["hab"] is True and va["avisos"] == [] and va["tras"]["pago"] is True and va["tras"]["hab"] is True and va["tras"]["parcial"] is True, va
    assert v["devuelve"]["tras"]["pago"] is True and v["devuelve"]["tras"]["parcial"] is True, v["devuelve"]


# ================================================================================================================ U5: la comanda con lo del servidor
CASOS_U5 = r"""
// (revisada, numerada) B sube el Casado a 2 y le pone nota al Postre; A, sin sincronizar, toca «Comanda»; después A sincroniza y cobra
for (const numerada of [false, true]) {
  const id = await guardada([CASADO(), POSTRE()]); const a = conNotas(await abierta(id)), b = await abierta(id); NOTAS.length = 0;
  if (numerada) a.numerarComanda = 'diaria';
  b.lineas.find(l => l.detalle === 'Casado').cantidad = 2; b.lineas.find(l => l.detalle === 'Postre').nota = 'sin azúcar'; b.persistirCuenta(); await b.A.mock.guardarTodo();
  const enA = detalles(a);
  await a.enviarComanda(); await a.A.mock.guardarTodo();
  const o = out[numerada ? 'numerada' : 'revisada'] = { enA, notas: NOTAS.map(x => [quien(x[0], a), x[1], x[2]]), impresos: impresos(), platosA: detalles(a),
    comandas: comandas(a), servidor: servidor().map(x => x.platos) };
  await a.sincronizar(); o.sinc = detalles(a);
  a._alDia = 0; await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  o.luego = { hechos: hechos().map(h => [h[1], h[2]]), impresos: impresos(), servidor: servidor() };
}
// (dos_A, dos_B) A y B tocan «Comanda» sobre los mismos platos; B subió el Casado a 2 (A no lo sabe). El primero guarda primero y su
// revisión es lenta; la comanda sale solo del último (T6)
for (const ultimo of ['A', 'B']) {
  const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id), b = await abierta(id);
  b.lineas.find(l => l.detalle === 'Casado').cantidad = 2;
  const [p, s] = ultimo === 'B' ? [a, b] : [b, a];
  const suelta = lento(p, 400);
  const pp = p.enviarComanda(); await hasta(() => enviadaEnServidor(id)); await espera(5);
  const ps = s.enviarComanda(); await Promise.all([pp, ps]); suelta();
  await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  out['dos_' + ultimo] = { impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), noSalioA: noSalio(a), noSalioB: noSalio(b), servidor: servidor().map(x => x.platos) };
}
"""
DOS_CASADOS = ["Casado×2", "Postre×1"]


def test_u5_la_comanda_lleva_la_cantidad_y_la_nota_del_servidor_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U5)
    for k, numero, aviso in (("revisada", None, "Comanda 1 enviada a Cocina"), ("numerada", 77, "Comanda N.º 77 enviada a Cocina")):
        x = r[k]
        # A tenía Casado ×1 en pantalla: la comanda sale con ×2 y la nota nueva del Postre (lo que tiene la cuenta y lo que se cobra)
        assert x["enA"] == AMBOS and x["notas"] == [["A", ["Casado×2", "Postre×1 «sin azúcar»"], numero]] and x["impresos"] == [DOS_CASADOS], (k, x)
        assert x["comandas"] == [aviso] and x["servidor"] == [DOS_CASADOS], (k, x)
        assert x["platosA"] == AMBOS and x["sinc"] == DOS_CASADOS, (k, x)                                # la pantalla, al sincronizar
        lu = x["luego"]                                                                                  # se cobra lo mismo que salió a cocina, sin otra comanda
        assert lu["hechos"] == [[2 * CASADO + POSTRE, ["Casado×2", "Postre (sin azúcar)×1"]]] and lu["impresos"] == [DOS_CASADOS] and lu["servidor"] == [], (k, x)
    for ultimo, primero in (("A", "B"), ("B", "A")):
        x = r["dos_" + ultimo]
        # una sola comanda (la del último) y lleva ×2, aunque el último sea A, que tenía ×1 en pantalla
        assert x["impresos"] == [[ultimo, DOS_CASADOS]] and x["noSalio" + primero] == [OTRA_VEZ] and x["noSalio" + ultimo] == [], (ultimo, x)
        assert x["servidor"] == [DOS_CASADOS], (ultimo, x)

    # revisarComanda de antes: la comanda salía con lo de la pantalla (Casado ×1, sin la nota) y se cobraban 2
    v = _correr(tmp_path / "antes", CASOS_U5, antes=_antes())
    for k in ("revisada", "numerada"):
        assert v[k]["notas"][0][1] == AMBOS and v[k]["impresos"] == [AMBOS], (k, v[k])
        assert v[k]["luego"]["hechos"] == [[2 * CASADO + POSTRE, ["Casado×2", "Postre (sin azúcar)×1"]]], (k, v[k])
    assert v["dos_A"]["impresos"] == [["A", AMBOS]], v["dos_A"]                                         # la única comanda, con ×1
    assert v["dos_B"]["impresos"] == [["B", DOS_CASADOS]], v["dos_B"]


# ================================================================================================================ U6: el nombre de la cuenta rehecha
CASOS_U6 = r"""
// A manda la comanda del Casado (la venta rápida queda guardada como «Cuenta 1»; o la Mesa 6; o la cuenta «Ana»); B la recupera y la cobra; C
// hace otra con el Postre y manda su comanda (para C no hay ninguna abierta: otra «Cuenta 1», «Mesa 6» o «Ana»); A, sin sincronizar, agrega la
// Limonada y toca «Comanda»: el servidor rehace la cuenta de A con otro id. Después todos sincronizan; A agrega un Postre y guarda
async function rehecha(o) {
  nuevo(); const a = venta(await equipo()); const b = venta(await equipo());
  if (o.mesa) a.abrirMesa(M6);
  if (o.nombre) a.nombreEspera = o.nombre;
  a.lineas.push(CASADO()); await a.enviarComanda(); await a.A.mock.guardarTodo();
  const id1 = a.esperaId;
  await b.sincronizar(); b.recuperar(b.espera.find(x => x.id === id1)); if (o.mesa) b.mesaActual = M6;
  await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  const c = venta(await equipo()); if (o.mesa) c.abrirMesa(M6); if (o.nombre) c.nombreEspera = o.nombre;
  c.lineas.push(POSTRE()); await c.enviarComanda(); await c.A.mock.guardarTodo();
  a.lineas.push(LIMONADA()); await a.enviarComanda(); await a.A.mock.guardarTodo();
  await a._alDiaNueva; await a.A.mock.guardarTodo();
  const enServidor = nombres();
  await b.sincronizar(); await c.sincronizar(); await a.sincronizar();
  const r = { id1, idA: a.esperaId, nombreA: a.nombreEspera, enServidor, enA: nombres(a), enB: nombres(b), enC: nombres(c), servidor: servidor().map(x => [x.nombre, x.platos]) };
  a.lineas.push(POSTRE()); a.persistirCuenta(); await a.A.mock.guardarTodo();
  r.luego = nombres();
  return r;
}
out.rapida = await rehecha({});
out.nombre = await rehecha({ nombre: 'Ana' });
out.mesa = await rehecha({ mesa: true });
"""


def test_u6_la_cuenta_rehecha_no_repite_cuenta_n_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U6)
    x = r["rapida"]
    # la cuenta rehecha de A (id 3) repetía «Cuenta 1» (la de C, id 2): pasa al número siguiente con la regla de la 4.38 (el mayor entre la
    # cantidad de cuentas y los números en uso, más uno: «Cuenta 3»), en el servidor y en los tres equipos; A sigue sin nombre en pantalla
    renombrada = [[2, "Cuenta 1"], [3, "Cuenta 3"]]
    assert x["id1"] == 1 and x["idA"] == 3 and x["nombreA"] == "", x
    assert x["enServidor"] == renombrada and x["enA"] == renombrada and x["enB"] == renombrada and x["enC"] == renombrada, x
    assert x["servidor"] == [["Cuenta 1", ["Postre×1"]], ["Cuenta 3", ["Limonada×1"]]], x
    assert x["luego"] == renombrada, x                                                                 # el guardado siguiente de A conserva «Cuenta 3»
    for k, nombre in (("nombre", "Ana"), ("mesa", "Mesa 6")):
        y = r[k]
        # con nombre propio o de una mesa no se renombra (la regla es solo para «Cuenta N» sin nombre en pantalla)
        assert y["idA"] == 3 and y["enServidor"] == [[2, nombre], [3, nombre]] and y["enB"] == [[2, nombre], [3, nombre]] and y["luego"] == [[2, nombre], [3, nombre]], (k, y)

    # alDiaCuentaNueva de antes: quedaban dos «Cuenta 1» abiertas (en el servidor y en todos los equipos)
    v = _correr(tmp_path / "antes", CASOS_U6, antes=_antes())
    assert v["rapida"]["enServidor"] == [[2, "Cuenta 1"], [3, "Cuenta 1"]] and v["rapida"]["enB"] == [[2, "Cuenta 1"], [3, "Cuenta 1"]], v["rapida"]


# ================================================================================================================ «Cobrar parte» o «Dividir» tras la «Comanda» de otro equipo
# 4.39 (quinta vuelta, V4): era el defecto que quedaba de la cuarta vuelta (xfail estricto): «Cobrar parte» o «Dividir» justo después de la
# «Comanda» de otro equipo partían la cuenta antes de que esa comanda se revisara (los platos pasaban a líneas nuevas, con otro lid) y no salía
# de ningún equipo. La quinta vuelta lo arregla (dio XPASS) y ahora es una prueba normal con lo que se espera. Además del caso de la cuarta
# («Cobrar parte 1 de 2»), las partes iguales con «Dividir» ya abierto (alDiaParaCobrar no vuelve a traer la lista: la espera sale de mirar la
# cuenta en el servidor) y «Dividir → Cobrar estos platos» (no se divide: aviso, «Dividir» se cierra y se vuelve a dividir). Más casos, y los
# métodos de antes de la quinta vuelta (donde se ve el defecto), en tests/test_439_quinta_vuelta.py
AVISO_DIVIDIR = "Otro equipo acaba de mandar a cocina platos de esta cuenta. Espere unos segundos y vuelva a dividir."
# 4.39 (séptima vuelta, X6): el aviso de «Dividir» cuando otro equipo mandó a cocina platos de la cuenta dice ahora que se vuelva a abrir «Dividir»
# (sale también con una comanda vieja que la pantalla todavía no tiene). AVISO_DIVIDIR queda como el de antes (lo dan las versiones «de antes»)
AVISO_DIVIDIR_7 = "Otro equipo mandó a cocina platos de esta cuenta. Vuelva a abrir «Dividir» para verla al día."
CASOS_PARTE = r"""
// la Mesa 6 con 2 Casados y 2 Postres guardados sin enviar, abierta en A y en B. B toca «Comanda» (su revisión, lenta: 1,5 s); en cuanto su
// guardado llegó al servidor, A toca «Cobrar parte 1 de 2» (parte); o, con «Dividir» ya abierto desde antes, elige 2 partes iguales (partes) o
// «Cobrar estos platos» con un Casado y un Postre (dividir: sale el aviso; la cajera espera unos segundos y vuelve a dividir). Después cobra
const como = @COMO@;
const [id, a, b] = await mesaGuardada([{ ...CASADO(), cantidad: 2 }, { ...POSTRE(), cantidad: 2 }]);
if (como !== 'parte') await a.abrirDividir();
const suelta = lento(b, 1500);
const pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id));
const t0 = Date.now(); let primero = null;
if (como === 'parte') await a.cobrarParte(2);
else if (como === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; await a.confirmarDividir(); }
else {
  a.dividir.destino = 'cobrar'; a.dividir.sel = { 0: 1, 1: 1 }; await a.confirmarDividir();
  primero = { ms: Date.now() - t0, dividir: !!a.dividir, pago: !!a.pago, parcial: !!a.cobroParcial, platos: detalles(a), avisos: conTexto(a, @AVISO@), srv: srv() };
  // (si no dividió) la cajera espera unos segundos y vuelve a dividir. (Con los métodos de antes de la quinta vuelta ya dividió: se cobra esa parte)
  if (!a.cobroParcial && !a.pago) { await pb; await espera(3100); await a.abrirDividir(); a.dividir.destino = 'cobrar'; a.dividir.sel = { 0: 1, 1: 1 }; await a.confirmarDividir(); }
}
await conPago(a); const ms = Date.now() - t0;
const marca = !!a._marcaAjena && a._marcaAjena.id === id, parcial = !!a.cobroParcial;
if (a.pago) await a.cobrar();
await pb; suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
out.r = { ms, marca, parcial, primero, impresos: IMPRESOS.map(x => [quien(x[0], a), x[1]]), noSalioB: noSalio(b), comandasB: comandas(b), hechos: hechos().map(h => [quien(h[0], a), h[2]]),
  avisos: conTexto(a, @AVISO@), srv: srv(), enviados: S.items.map(x => x.lineas.filter(l => l.enviado).map(l => l.detalle + '×' + l.cantidad).sort()), fin: estado(a), libre: libre() };
"""
UNO_Y_UNO = ["Casado×1", "Postre×1"]


@pytest.mark.parametrize("como", ["parte", "partes", "dividir"])
def test_v4_cobrar_parte_o_dividir_tras_la_comanda_de_otro_equipo_en_node(tmp_path, como):
    # 4.39 (séptima vuelta, X6): con el texto nuevo del aviso (caja.js de ahora ya no tiene el de antes)
    r = _correr(tmp_path, CASOS_PARTE.replace("@COMO@", json.dumps(como)).replace("@AVISO@", json.dumps(AVISO_DIVIDIR_7)))["r"]
    # la comanda de B sale una vez, con los 4 platos (la cuenta seguía entera mientras B la revisaba); A no manda otra
    assert r["impresos"] == [["B", ["Casado×2", "Postre×2"]]] and r["noSalioB"] == [] and r["comandasB"] == ["Comanda 1 enviada a Cocina"], r
    # la parte (un Casado y un Postre) se cobra una vez, con la cuenta ya juntada: lo que queda en la mesa está enviado a cocina
    assert r["hechos"] == [["A", UNO_Y_UNO]] and r["enviados"] == [UNO_Y_UNO] and r["libre"] is True, r
    assert r["fin"]["pago"] is False and r["fin"]["parcial"] is False and r["fin"]["hab"] is False, r
    assert r["marca"] is True and r["ms"] >= 3500, r                                                    # A esperó la comanda de B
    if como == "dividir":
        p = r["primero"]
        # «Cobrar estos platos» no divide todavía: el aviso, «Dividir» cerrado, nada en cobro y la cuenta entera (en el servidor y en pantalla)
        assert p["avisos"] == [AVISO_DIVIDIR_7] and p["dividir"] is False and p["pago"] is False and p["parcial"] is False, p
        assert p["srv"] == [["Mesa 6", ["Casado×2", "Postre×2"], None]] and p["platos"] == ["Casado×2", "Postre×2"] and p["ms"] < 2500, p
        assert r["avisos"] == [AVISO_DIVIDIR_7] and r["srv"] == [["Mesa 6", UNO_Y_UNO, None]], r    # al volver a dividir, sin otro aviso
    else:
        assert r["avisos"] == [] and r["srv"] == [["Mesa 6", UNO_Y_UNO, {"total": 2, "cobradas": 1}]], r


# ================================================================================================================ contrato
def test_contrato_de_la_cuarta_vuelta():
    # 4.39 (quinta vuelta): «ahora» es caja.js sin la quinta vuelta (la quinta cambió líneas de varios de estos métodos: la marca de U1, el
    # bucle de reclamarHab, abrirCargoHab, abrirPago, cobrarParte, alDiaCuentaNueva); lo de la quinta está en tests/test_439_quinta_vuelta.py
    k, k0 = _caja_sin_quinta(), _caja_sin_cuarta()
    # cada par de CUARTA está una sola vez en caja.js y dentro de uno solo de los métodos cambiados; fuera de ellos, caja.js no cambió
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    for viejo, nuevo in CUARTA:
        assert k.count(nuevo) == 1 and k0.count(viejo) >= 1, nuevo[:120]
        assert sum(nuevo in m for m in metodos.values()) == 1, nuevo[:120]
    for c in CAMBIADOS:
        assert metodos[c] != _metodo(k0, c), c
    resto, resto0 = k, k0
    for c in CAMBIADOS:
        resto, resto0 = resto.replace(metodos[c], ""), resto0.replace(_metodo(k0, c), "")
    assert resto == resto0
    # U1: la marca se anota después de juntar, en las dos
    f = metodos["fusionarAbierta(motivo) {"]
    assert f.index("const sinEnviar0 = new Set(this.lineas.filter(l => !l.enviado).map(l => l.lid));") < f.index("this.lineas = aplicarEnLugar(this.lineas, res.lineas);") < f.index("this._marcaAjena = { id: this.esperaId, t: Date.now() };")
    p = metodos["persistirCuenta(devolverId) {"]
    assert p.index("const sinEnviar0 = new Set(") < p.index("this.lineas = aplicarEnLugar(this.lineas, res.lineas); this.ponerImportes();") < p.index("this._marcaAjena = { id, t: Date.now() };")
    # U2: en emitirCobro, con «cobrando» ya puesto y antes del bloque de la comanda y del reclamo; en reclamarHab, antes de pedir el cobro
    e = metodos["async emitirCobro(otra) {"]
    espera = "{ const ma = this._marcaAjena, falta = ma && esperaId !== null && esperaId !== undefined && ma.id === esperaId ? ma.t + 4000 - Date.now() : 0; if (falta > 0) await new Promise(r => setTimeout(r, Math.min(falta, 4000))); }"
    assert e.count(espera) == 1 and e.index("this.cobrando = true;") < e.index(espera) < e.index("let rc = null, rcPedido = false;") < e.index("if (reclamar && !rcPedido) {")
    rh = metodos["async reclamarHab() {"]
    assert rh.index("if (this._habEnCurso) return; this._habEnCurso = true;") < rh.index("const ma = this._marcaAjena, id1 = this.esperaId;") < rh.index("rc = await this.reclamarCobro(this.lineas);")
    assert "i < 20 && Date.now() < ma.t + 4000 && this.habCargo === hc && this.esperaId === id1; i++) await new Promise(r => setTimeout(r, 200));" in rh
    # U3: los avisos
    assert e.split("\n")[2].startswith("      if (this._habEnCurso) return toast('" + REVISA_HAB + "', 'err');")
    assert metodos["cargarAHabitacion() {"].split("\n")[1].startswith("      if (this._habEnCurso && !this._habSigue) return toast('" + REVISA_CARGA + "', 'ok');")
    # U4: las revisiones después de las esperas
    ap = metodos["async abrirPago() {"]
    assert ap.index("const fresca = api('/api/clientes/'") < ap.index("if (this.habCargo) { if (this.cobroParcial) this.cerrarPago(); return; }") < ap.index("this.pago = { tipo_documento: td,")
    cp = metodos["async cobrarParte(n) {"]
    assert cp.index("await this.alDiaParaCobrar();") < cp.index("if (this.cobroParcial || this.esperaId !== id0 || this.habCargo || this.pago) return;") < cp.index("this.lineas = resto; const id = this.persistirCuenta(true);")
    ah = metodos["async abrirCargoHab() {"]
    assert ah.index("await this.cobroPermitido('cargar a la habitación')") < ah.index("      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial) return;   ") < ah.index("this.habCargo = { reserva_id: null")
    # U5: las copias para imprimir, después de decidir lo que queda fuera y antes de usarlo
    rv = metodos["async revisarComanda(e, dudosas) {"]
    assert rv.index("const fuera = dudosas.filter(") < rv.index("const srv = new Map(") < rv.index("return s ? { ...l, cantidad: s.cantidad, nota: s.nota } : l;") < rv.index("if (!fuera.length) {")
    # U6: el nombre se cambia con actualizarCuenta (viaja como cambio de la cuenta) antes de poner la pantalla al día
    ad = metodos["async alDiaCuentaNueva(id) {"]
    assert ad.index("this.espera = enEspera();") < ad.index("/^Cuenta \\d+$/.test(cn.nombre || '')") < ad.index("this.actualizarCuenta(id, x => ({ ...x, nombre }));") < ad.index("if (this.esperaId === id) this.fusionarAbierta('sinc');")
