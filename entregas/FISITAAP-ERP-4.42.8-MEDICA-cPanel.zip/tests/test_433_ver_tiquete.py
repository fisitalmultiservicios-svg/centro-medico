# -*- coding: utf-8 -*-
"""4.33, pedido de Norman (14 nov 2026, foto del encabezado «Caja salón · 6 ventas · ₡10.300,00»): «que en caja puedan ver o reimprimir
tickets. Puede ser allí». El texto «N ventas · ₡total» de los dos encabezados de la caja abre «Ventas de esta caja», y cada venta trae
«Ver» (el tiquete con COPIA en el navegador, sin mandarlo a la impresora) junto a «Reimprimir». Nada sale a la red."""
import json
import pathlib
import re

from tests.test_425_ultimos_pantallas import _js, _node, _tramo


def test_el_texto_de_ventas_de_los_dos_encabezados_abre_la_ventana_de_ventas():
    t = _js("pages/pos/caja.js")
    enlaces = re.findall(r'<a class="enlace-ventas"[^>]*@click="modalVentas=true"[^>]*>\{\{textoVentas\(resumenCaja\.ventas\)\}\}', t)
    assert len(enlaces) == 2, enlaces                                   # plano de mesas y pantalla de venta (también la de restaurante)
    assert t.count('{{caja.caja}} · <a class="enlace-ventas"') == 1       # «Caja salón · 6 ventas · ₡…»: el nombre de la caja sigue igual
    assert 'title="Ver o reimprimir los tiquetes de esta caja"' in t


def test_el_modal_trae_ver_con_las_mismas_condiciones_que_reimprimir():
    m = _tramo(_js("pages/pos/caja.js"), '<Modal v-if="modalVentas && caja"', "</Modal>")
    ver = re.search(r'<button[^>]*@click="verTiquete\(v\)"[^>]*>Ver</button>', m)
    assert ver, m
    for cond in ("v.doc_id", "!v.anulada", "v.tipo !== 'hab'", "!v.abono"):
        assert cond in ver.group(0), cond
    assert m.index("verTiquete(v)") < m.index("reimprimirVenta(v)") < m.index("Anular / devolver")


def test_ver_abre_el_tiquete_con_copia_en_el_navegador_y_no_imprime(tmp_path):
    t = _js("pages/pos/caja.js")
    fuente = _tramo(t, "async imprimirTermico(u, imp, copia) {", "    // ---- venta sin internet")
    assert "abrirGaveta" not in _tramo(fuente, "verTiquete(v) {", "reimprimirVenta(v) {")
    guion = r"""
const src = __SRC__;
const Q = { agente: [], llamadas: [], abiertos: [], gaveta: 0 };
const store = { empresa: { nombre: 'Soda' } }, sesion = { usuario: { nombre: 'Ana' } }, nombreMedio = m => m;
const api = async url => { Q.llamadas.push(url); return { id: 5 }; };
const docTiquete = o => ({ bloques: [] });
const imprimirAgente = async (imp, doc) => { Q.agente.push(imp.nombre); };
const porAgente = imp => !!imp && (imp.conexion === 'usb' || imp.conexion === 'red');
const abrirGaveta = () => { Q.gaveta++; };
const avisoImpresion = (p, e) => p + e.message, toast = () => {};
globalThis.window = { open: u => Q.abiertos.push(u) };
const M = new Function('api', 'docTiquete', 'imprimirAgente', 'porAgente', 'abrirGaveta', 'avisoImpresion', 'toast', 'store', 'sesion', 'nombreMedio', 'return ({' + src + '\n})')
  (api, docTiquete, imprimirAgente, porAgente, abrirGaveta, avisoImpresion, toast, store, sesion, nombreMedio);
const v = Object.assign({}, M, { cfg: { ancho_ticket: 80, nombre: 'Caja 1' }, impresoraTiquete: () => ({ nombre: 'Tiq', conexion: 'red' }), imprimirProvisional: () => { throw new Error('no'); }, cola: [] });
const venta = { id: 1, doc_id: 5, consecutivo: 'X', total: 100, medios: [{ medio: '01', monto: 100 }] };
const out = {};
await v.verTiquete(venta);
out.ver = { agente: Q.agente.length, llamadas: Q.llamadas.length, abiertos: Q.abiertos.slice() };
Q.abiertos = [];
for (const x of [{ ...venta, doc_id: null }, { ...venta, anulada: true }, { ...venta, tipo: 'hab' }, { ...venta, abono: true }]) await v.verTiquete(x);
out.ignoradas = Q.abiertos.length;
out.gaveta = Q.gaveta;
console.log(JSON.stringify(out));
""".replace("__SRC__", json.dumps(fuente))
    r = _node(tmp_path, guion, archivos=(), falsos={})
    assert r["ver"]["agente"] == 0 and r["ver"]["llamadas"] == 0, r                 # no pasa por la impresora de la caja
    assert len(r["ver"]["abiertos"]) == 1, r
    u = r["ver"]["abiertos"][0]
    assert u.startswith("/api/comprobantes/5/tiquete?ancho=80") and u.endswith("&copia=true"), u
    assert r["ignoradas"] == 0 and r["gaveta"] == 0, r


# ================================================================================================================ 4.34
def test_434_venta_rapida_del_restaurante_trae_el_boton_ventas_visible():
    """Norman (foto de Venta rápida, «No me salen los cambios»): en la pantalla de venta del restaurante no había botón «Ventas» y el
    texto gris «0 ventas» no parecía tocable. Ahora hay «🧾 Ventas» ahí, y los de Mesas y mostrador dicen lo mismo."""
    t = _js("pages/pos/caja.js")
    titulo = 'title="Ventas de esta caja: ver, reimprimir, anular o devolver">🧾 Ventas</button>'
    assert t.count(titulo) == 3, t.count(titulo)                         # Mesas, Venta rápida del restaurante y mostrador
    assert '<button class="btn sm ghost" v-if="caja && esRestaurante" @click="modalVentas=true" ' + titulo in t
    assert '<template v-if="caja && !esRestaurante">' in t                # el de mostrador sigue dentro de su grupo
    assert ">Ventas</button>" not in t                                    # ninguno quedó con el texto viejo


def test_434_el_enlace_se_ve_como_enlace_y_la_lista_vacia_dice_donde_buscar():
    css = (pathlib.Path(__file__).resolve().parents[1] / "app" / "static" / "ui.css").read_text(encoding="utf-8")
    regla = re.search(r"\.enlace-ventas\{([^}]*)\}", css)
    assert regla and "color:var(--primary)" in regla.group(1) and "text-decoration:underline" in regla.group(1), regla
    m = _tramo(_js("pages/pos/caja.js"), '<Modal v-if="modalVentas && caja"', "</Modal>")
    assert "Las de cajas anteriores están en Punto de venta › Ventas de caja." in m
