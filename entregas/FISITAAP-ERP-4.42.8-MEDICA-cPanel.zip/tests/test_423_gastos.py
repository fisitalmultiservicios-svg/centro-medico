# -*- coding: utf-8 -*-
"""4.23 · Gastos: las listas «Compras» y «Gastos» son el registro de lo aceptado; eliminar una compra o un gasto lo saca de los
reportes y de la contabilidad (la aceptación ante Hacienda no se toca); y lo que se elimina, se vuelve a registrar o cambia de
clasificación de un mes pasado queda en el registro «gastos_rectificaciones», que solo escribe el servidor."""
import datetime as dt
import pathlib
import re
import types

import pytest
from sqlalchemy import create_engine, text
from sqlmodel import Session, select

from app import auth, db, main, modulos, recepcion, resumen
from app.db import Empresa, engine, engine_empresa
from tests.test_375_costeo import _registrar, _xml_proveedor
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

JS = pathlib.Path(main.__file__).parent / "static" / "js"
AHORA = dt.datetime(2026, 11, 10, 9, 0, 0, tzinfo=dt.timezone(dt.timedelta(hours=-6)))   # «hoy» de estas pruebas: noviembre de 2026
OCTUBRE = "2026-10-08T10:30:00-06:00"        # un documento de un mes pasado
NOVIEMBRE = "2026-11-03T10:00:00-06:00"      # un documento del mes en curso
MOTIVO = "Se registró dos veces por error"
PAGOS_PRIMERO = "Elimine primero los pagos y las notas de débito de esta factura"


@pytest.fixture(autouse=True)
def _reloj(monkeypatch):
    """El mes en curso no depende del día en que corran las pruebas; y el resumen no sale a buscar el tipo de cambio."""
    monkeypatch.setattr(main, "ahora_cr", lambda: AHORA)

    def _sin_red():
        raise RuntimeError("sin red en las pruebas")
    monkeypatch.setattr(main.tipo_cambio, "obtener", _sin_red)


def _ctx():
    return main.app.dependency_overrides[auth.contexto]()


def _eid():
    return _ctx().empresa.id


def _como(rol, correo="otro@example.test"):
    e = _ctx().empresa
    main.app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo=correo, es_superadmin=False, nombre="QA"), e, rol)


def _aceptado(n, fecha=OCTUBRE, clasificacion="gasto", respuesta="05", **xml):
    """Un comprobante de proveedor recibido y ACEPTADO (como queda después de responderlo), con su clasificación."""
    eid = _eid()
    rid = _registrar(eid, _xml_proveedor(n, f"{42300000 + n}", fecha_emision=fecha, **xml))
    with Session(engine_empresa(eid)) as s:
        r = s.get(recepcion.Recibido, rid)
        r.respuesta, r.estado_mensaje, r.clasificacion = respuesta, "aceptado", clasificacion
        r.condicion_impuesto, r.monto_impuesto_acreditar, r.monto_gasto_aplicable = "01", recepcion.iva_recibido(r), r.total
        s.add(r); s.commit()
    return rid


def _recibido(rid):
    with Session(engine_empresa(_eid())) as s:
        return s.get(recepcion.Recibido, rid)


def _fila(c, rid):
    return next(x for x in c.get("/api/recepcion").json() if x["id"] == rid)


def _compra(i, creacion, tipo="gasto", **extra):
    """Una factura hecha a mano como la guarda la pantalla (10 000 + 13 % de IVA)."""
    return {"id": i, "tipo": tipo, "recepcion_id": None, "clave": None, "numero": f"FC-{i:04d}", "proveedor_id": None, "proveedor": "Proveedor QA", "creacion": creacion,
            "vencimiento": creacion, "moneda": "CRC", "tipo_cambio": 1, "bodega": "Principal", "retenciones": [], "total": 11300, "pagado": 0, "emision": "No electrónica",
            "fec_id": None, "fec_consecutivo": None, "ordenes_ids": [],
            "lineas": [{"producto_id": None, "detalle": "Servicio de limpieza", "cantidad": 1, "precio_unitario": 10000, "descuento": 0, "codigo_tarifa": "08", "tarifa": 13}], **extra}


def _alta(c, *compras):
    r = c.post("/api/registros/compras/cambios", json={"upserts": list(compras), "deletes": [], "nuevos": [x["id"] for x in compras]})
    assert r.status_code == 200, r.text


def _compras(c):
    return {x["id"]: x for x in c.get("/api/registros/compras").json()["datos"] or []}


def _rects(c):
    return c.get("/api/registros/gastos_rectificaciones").json()["datos"] or []


def _auditoria(eid):
    with Session(engine) as s:
        return [(a.accion, a.detalle) for a in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid).order_by(auth.Auditoria.id)).all()
                if a.accion.startswith(("gastos_", "recepcion_clasificacion"))]


def _octubre(c):
    """El resumen y la D-104 de octubre de 2026 por la API (lo que ven los reportes en vivo)."""
    r = c.get("/api/resumen?periodo=rango&desde=2026-10-01&hasta=2026-10-31&detalle=1"); assert r.status_code == 200, r.text
    iva = c.get("/api/resumen/iva?desde=2026-10-01&hasta=2026-10-31"); assert iva.status_code == 200, iva.text
    return r.json(), {f["codigo"]: f for f in iva.json()["filas"]}


# ------------------------------------------------------------------------------------------------ (1) quitar del registro
def test_quitar_del_registro_reglas(api):  # noqa: F811
    c = api
    eid = _eid()
    # otra empresa: su comprobante no existe aquí
    with Session(engine) as s:
        otra = Empresa(nombre="Otra empresa QA", numero_id="3101888888", actividad="620100", correo="otra@example.test", ambiente="sandbox")
        s.add(otra); s.commit(); s.refresh(otra)
    with Session(engine_empresa(otra.id)) as s:
        ajeno = recepcion.Recibido(empresa_id=otra.id, clave="5" * 50, respuesta="05", estado_mensaje="aceptado", fecha_emision=NOVIEMBRE, total=100)
        s.add(ajeno); s.commit(); s.refresh(ajeno)
    assert c.post(f"/api/recepcion/{ajeno.id}/quitar-registro", json={}).status_code == 404
    assert c.post(f"/api/recepcion/{ajeno.id}/registrar", json={"clasificacion": "gasto"}).status_code == 404
    with Session(engine_empresa(otra.id)) as s:
        assert s.get(recepcion.Recibido, ajeno.id).registrado is True
    # sin aceptar no está en el registro: 409 (se elimina desde Recepción, como siempre)
    pendiente = _registrar(eid, _xml_proveedor(1, "42300001", fecha_emision=NOVIEMBRE))
    r = c.post(f"/api/recepcion/{pendiente}/quitar-registro", json={})
    assert r.status_code == 409 and "aceptado" in r.json()["detail"]
    rechazado = _aceptado(2, NOVIEMBRE, respuesta="07")
    assert c.post(f"/api/recepcion/{rechazado}/quitar-registro", json={}).status_code == 409
    # el cajero no tiene el permiso de gastos
    rid = _aceptado(3, NOVIEMBRE, "compra")
    admin = main.app.dependency_overrides[auth.contexto]
    _como("Cajero")
    assert c.post(f"/api/recepcion/{rid}/quitar-registro", json={}).status_code == 403
    assert c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto"}).status_code == 403
    assert c.post("/api/gastos/compras/1/eliminar", json={}).status_code == 403
    main.app.dependency_overrides[auth.contexto] = admin
    assert _recibido(rid).registrado is True
    # del mes en curso basta confirmar: sin motivo y sin rectificación; queda quién y cuándo, y la aceptación no se toca
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={})
    assert r.status_code == 200, r.text
    x = r.json()
    assert x["ok"] is True and x["registrado"] is False and x["rectificacion"] is None and x["aviso"] is None and x["compras_eliminadas"] == []
    assert x["respuesta"] == "05" and x["estado_mensaje"] == "aceptado" and x["respuesta_nombre"] == "Aceptado"
    fila = _recibido(rid)
    assert fila.registrado is False and fila.registro_quitado_por == "qa-exo@example.test" and fila.registro_quitado_en == "2026-11-10T09:00:00-06:00" and fila.registro_motivo is None
    assert _rects(c) == []
    # ya quitado: 409
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={})
    assert r.status_code == 409 and "ya no está en el registro" in r.json()["detail"]
    assert _auditoria(eid) == [("gastos_registro_quitado", f"Compra {fila.consecutivo} de {fila.emisor_nombre} eliminada del registro")]
    # el DELETE de siempre no cambia: un respondido no se elimina
    assert c.delete(f"/api/recepcion/{rid}").status_code == 409 and c.delete(f"/api/recepcion/{pendiente}").status_code == 200


def test_quitar_del_registro_con_factura_pagos_e_inventario(api):  # noqa: F811
    c = api
    eid = _eid()
    rid = _aceptado(1, NOVIEMBRE, "compra")
    clave = _recibido(rid).clave
    _alta(c, _compra(1, "2026-11-03", "compra", recepcion_id=rid, clave=clave, pagado=5000), _compra(2, "2026-11-04"))
    assert c.put(f"/api/recepcion/{rid}/compra", json={"compra_id": 1}).status_code == 200
    with Session(engine_empresa(eid)) as s:                    # ya había entrado al inventario
        r = s.get(recepcion.Recibido, rid); r.inventario_ajuste_id, r.inventario_codigo = 7, "CO-0007"; s.add(r); s.commit()
    # con pagos o notas de débito aplicados a su factura no sale
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={})
    assert r.status_code == 409 and r.json()["detail"] == PAGOS_PRIMERO
    assert _recibido(rid).registrado is True and set(_compras(c)) == {1, 2}
    # sin pagos: el servidor quita también su factura y limpia el vínculo; el inventario no se toca y se avisa
    assert c.post("/api/registros/compras/cambios", json={"upserts": [_compra(1, "2026-11-03", "compra", recepcion_id=rid, clave=clave)], "deletes": [], "nuevos": []}).status_code == 200
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": "  no  era\tde esta empresa "})
    assert r.status_code == 200, r.text
    x = r.json()
    assert x["registrado"] is False and x["compras_eliminadas"] == [1] and x["compra_id"] is None and x["rectificacion"] is None
    assert x["aviso"] == "La entrada de inventario CO-0007 no se revierte: ajústela en Inventario si corresponde"
    assert set(_compras(c)) == {2}                              # la otra factura sigue
    fila = _recibido(rid)
    assert fila.compra_id is None and fila.inventario_codigo == "CO-0007" and fila.registro_motivo == "no era de esta empresa"   # el motivo es opcional en el mes en curso
    assert _rects(c) == []


def test_quitado_deja_de_contar_en_reportes_y_asientos(api):  # noqa: F811
    c = api
    eid = _eid()
    gasto, compra = _aceptado(1, OCTUBRE, "gasto"), _aceptado(2, OCTUBRE, "compra")
    total, iva = _recibido(gasto).total, recepcion.iva_recibido(_recibido(gasto))
    res, d104 = _octubre(c)
    assert res["egresos"]["CRC"] == round(2 * total, 2) and res["egresos_docs"] == 2 and res["iva"]["credito"]["CRC"] == round(2 * iva, 2)
    assert [x["id"] for x in res["detalle"]["egresos"]] == [gasto, compra] and d104["rec"]["docs"] == 2 and d104["rec"]["credito"] == round(2 * iva, 2)
    assert all(x["registrado"] is True for x in c.get("/api/recepcion").json())
    r = c.post(f"/api/recepcion/{gasto}/quitar-registro", json={"motivo": MOTIVO})
    assert r.status_code == 200, r.text
    # los reportes en vivo cambian al instante
    res, d104 = _octubre(c)
    assert res["egresos"]["CRC"] == round(total, 2) and res["egresos_docs"] == 1 and res["iva"]["credito"]["CRC"] == round(iva, 2) and res["iva"]["docs_recibidos"] == 1
    assert [x["id"] for x in res["detalle"]["egresos"]] == [compra] and [x["id"] for x in res["detalle"]["iva_recibidos"]] == [compra]
    assert [p["docs"] for p in res["detalle"]["proveedores"]] == [1]
    assert d104["rec"]["docs"] == 1 and d104["rec"]["credito"] == round(iva, 2) and d104["rec"]["compras"] == round(total - iva, 2)
    # las funciones puras: con la fila del servidor y con un diccionario (sin el dato cuenta como registrado: lo de antes de la 4.23)
    with Session(engine_empresa(eid)) as s:
        filas = s.exec(select(recepcion.Recibido)).all()
        assert len(resumen._aceptados(filas, "2026-10-01", "2026-10-31")) == 1
        dic = [recepcion.recibido_dict(f) for f in filas]
    assert [x["id"] for x in resumen._aceptados(dic, "2026-10-01", "2026-10-31")] == [compra]
    assert len(resumen._aceptados([{k: v for k, v in x.items() if k != "registrado"} for x in dic], "2026-10-01", "2026-10-31")) == 2
    assert recepcion.esta_registrado({}) and recepcion.esta_registrado({"registrado": None}) and recepcion.esta_registrado({"registrado": 1}) and not recepcion.esta_registrado({"registrado": 0})
    # /api/recepcion lo sigue entregando (Recepción lo muestra como «Aceptado sin registrar»), marcado para que los asientos lo salten
    assert _fila(c, gasto)["registrado"] is False and _fila(c, gasto)["respuesta"] == "05" and _fila(c, compra)["registrado"] is True
    au = (JS / "pages/contabilidad/automaticos.js").read_text(encoding="utf-8")
    assert "const registrado = r => r.registrado !== false;" in au
    assert "['05', '06'].includes(r.respuesta) && registrado(r) && recOk(r)" in au                 # el asiento rec: y el recp: del pago anterior
    assert au.count("registrado(r)") == 3 and "!['rechazado', 'error'].includes(r.estado_mensaje || '') && registrado(r)).map(r => r.clave)" in au   # y la factura de una nota
    # la nota de crédito que se refiere a un comprobante quitado tampoco resta (esa factura ya no suma)
    nota = {"clave": "9" * 50, "tipo_documento": "03", "respuesta": "05", "estado_mensaje": "aceptado", "fecha_emision": OCTUBRE, "total": 100, "impuesto": 0, "moneda": "CRC"}
    de = lambda reg: len(resumen._aceptados([{**dic[0], "registrado": reg}, {**nota, "referencia_clave": dic[0]["clave"]}], "2026-10-01", "2026-10-31"))   # noqa: E731
    assert de(True) == 2 and de(False) == 0


# ------------------------------------------------------------------------------------------------ (2) volver a registrar
def test_volver_a_registrar(api):  # noqa: F811
    c = api
    rid = _aceptado(1, NOVIEMBRE, "compra")
    r = c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto"})
    assert r.status_code == 409 and "ya está registrado" in r.json()["detail"]
    pendiente = _registrar(_eid(), _xml_proveedor(2, "42300002", fecha_emision=NOVIEMBRE))
    assert c.post(f"/api/recepcion/{pendiente}/registrar", json={"clasificacion": "gasto"}).status_code == 409
    assert c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": "duplicado"}).status_code == 200
    assert c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "otra"}).status_code == 422
    r = c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto", "cuenta_contable": " 6.2.02.05 Papelería "})
    assert r.status_code == 200, r.text
    x = r.json()
    assert x["registrado"] is True and x["clasificacion"] == "gasto" and x["cuenta_contable"] == "6.2.02.05 Papelería" and x["rectificacion"] is None
    fila = _recibido(rid)
    assert fila.registrado is True and fila.registro_quitado_en is None and fila.registro_quitado_por is None and fila.registro_motivo is None
    assert _rects(c) == []                                       # del mes en curso: sin rectificación
    assert [a for a, _ in _auditoria(_eid())] == ["gastos_registro_quitado", "gastos_registro_puesto"]
    # vuelve a contar
    res = c.get("/api/resumen?periodo=rango&desde=2026-11-01&hasta=2026-11-30&detalle=1").json()
    assert res["egresos_docs"] == 1 and res["detalle"]["egresos"][0]["clasificacion"] == "gasto"


# ------------------------------------------------------------------------------------------------ (3) rectificación: solo de un mes pasado
def test_rectificacion_de_un_mes_pasado(api):  # noqa: F811
    c = api
    eid = _eid()
    assert main._mes_pasado(OCTUBRE) == "2026-10" and main._mes_pasado("2025-12-31") == "2025-12"
    assert main._mes_pasado(NOVIEMBRE) is None and main._mes_pasado("2026-11-30") is None and main._mes_pasado("2026-12-01") is None
    assert main._mes_pasado("") is None and main._mes_pasado(None) is None and main._mes_pasado("octubre") is None
    rid = _aceptado(1, OCTUBRE, "compra")
    fila = _recibido(rid)
    # el motivo es obligatorio: de 5 a 300 letras
    for malo in ({}, {"motivo": ""}, {"motivo": "  no  "}, {"motivo": None}):
        r = c.post(f"/api/recepcion/{rid}/quitar-registro", json=malo)
        assert r.status_code == 400 and "octubre de 2026" in r.json()["detail"] and "Rectificaciones" in r.json()["detail"], r.text
    assert c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": "x" * 301}).status_code == 400
    assert _recibido(rid).registrado is True and _rects(c) == []
    # el periodo contable de octubre está cerrado: se anota igual y queda dicho
    assert c.put("/api/registros/periodos_2026", json={"datos": [{"n": 10, "mes": "Octubre", "estado": "Cerrado"}, {"n": 11, "mes": "Noviembre", "estado": "Abierto"}], "version": 0}).status_code == 200
    r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": "  Se registró  dos veces\n por error "})
    assert r.status_code == 200, r.text
    rect = r.json()["rectificacion"]
    assert _rects(c) == [rect]
    assert rect == {"id": 1, "fecha": "2026-11-10T09:00:00-06:00", "usuario": "qa-exo@example.test", "accion": "eliminado", "tipo": "compra", "origen": "electronica",
                    "recibido_id": rid, "documento": fila.consecutivo, "clave": fila.clave, "tipo_documento": "01", "proveedor": fila.emisor_nombre,
                    "proveedor_identificacion": fila.emisor_id, "fecha_documento": "2026-10-08", "moneda": "CRC", "tipo_cambio": 1.0, "total": fila.total, "impuesto": fila.impuesto,
                    "iva_acreditar": recepcion.iva_recibido(fila), "mes": "2026-10", "motivo": MOTIVO, "periodo_cerrado": True}
    assert _recibido(rid).registro_motivo == MOTIVO
    assert _auditoria(eid) == [("gastos_registro_quitado", f"Compra {fila.consecutivo} de {fila.emisor_nombre} eliminada del registro · rectificación de octubre de 2026: {MOTIVO}")]
    # volver a registrarlo también es una rectificación y pide el motivo
    assert c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto"}).status_code == 400
    assert c.put("/api/registros/periodos_2026", json={"datos": [{"n": 10, "mes": "Octubre", "estado": "Abierto"}], "version": 1}).status_code == 200
    r = c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto", "motivo": "Sí era de la empresa"})
    assert r.status_code == 200, r.text
    r2 = r.json()["rectificacion"]
    assert r2["id"] == 2 and r2["accion"] == "registrado" and r2["tipo"] == "gasto" and "tipo_anterior" not in r2 and r2["recibido_id"] == rid and r2["mes"] == "2026-10"
    assert r2["motivo"] == "Sí era de la empresa" and r2["periodo_cerrado"] is False and r2["total"] == fila.total
    assert _rects(c) == [rect, r2]
    # una nota de crédito recibida se anota con el signo con que cuenta en los reportes
    nc = _aceptado(2, OCTUBRE, "gasto")
    with Session(engine_empresa(eid)) as s:
        x = s.get(recepcion.Recibido, nc); x.tipo_documento = "03"; s.add(x); s.commit()
    r3 = c.post(f"/api/recepcion/{nc}/quitar-registro", json={"motivo": MOTIVO}).json()["rectificacion"]
    assert r3["tipo_documento"] == "03" and r3["total"] == -fila.total and r3["impuesto"] == -fila.impuesto and r3["iva_acreditar"] == -recepcion.iva_recibido(fila)
    # del mes en curso nunca hay rectificación, con motivo o sin él
    hoy = _aceptado(3, NOVIEMBRE)
    assert c.post(f"/api/recepcion/{hoy}/quitar-registro", json={"motivo": MOTIVO}).json()["rectificacion"] is None
    assert c.post(f"/api/recepcion/{hoy}/registrar", json={"clasificacion": "compra"}).json()["rectificacion"] is None
    assert len(_rects(c)) == 3


def test_rectificacion_en_el_programa_local(api):  # noqa: F811
    """En una instalación local los ids nuevos van en el rango de su terminal: la rectificación también (si no, no se podía guardar)."""
    c = api
    eid = _eid()
    rid = _aceptado(1, OCTUBRE)
    modulos.fijar_rango(eid, 3)
    try:
        r = c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO})
        assert r.status_code == 200 and r.json()["rectificacion"]["id"] == 3 * modulos.RANGO + 1, r.text
        r = c.post(f"/api/recepcion/{rid}/registrar", json={"clasificacion": "gasto", "motivo": MOTIVO})
        assert r.status_code == 200 and r.json()["rectificacion"]["id"] == 3 * modulos.RANGO + 2, r.text
        assert [(x["id"], x["accion"]) for x in _rects(c)] == [(30_000_001, "eliminado"), (30_000_002, "registrado")]
    finally:
        modulos.fijar_rango(eid, 0)


# ------------------------------------------------------------------------------------------------ (4) eliminar una factura hecha a mano
def test_eliminar_factura_manual_por_la_ruta_nueva(api):  # noqa: F811
    c = api
    eid = _eid()
    _alta(c, _compra(1, "2026-11-04", "compra"), _compra(2, "2026-10-15", "gasto"), _compra(3, "2026-10-20", "compra", pagado=1000),
          _compra(4, "2026-10-21", fec_id=77, emision="FEC aceptado"), _compra(5, "2026-10-22", "gasto", inventario_codigo="CO-0003"))
    assert c.post("/api/gastos/compras/99/eliminar", json={}).status_code == 404
    # las dos reglas que antes solo cuidaba la pantalla
    r = c.post("/api/gastos/compras/3/eliminar", json={"motivo": MOTIVO})
    assert r.status_code == 409 and r.json()["detail"] == PAGOS_PRIMERO
    r = c.post("/api/gastos/compras/4/eliminar", json={"motivo": MOTIVO})
    assert r.status_code == 409 and "factura electrónica de compra" in r.json()["detail"]
    # del mes en curso: basta confirmar
    r = c.post("/api/gastos/compras/1/eliminar", json={})
    assert r.status_code == 200 and r.json() == {"ok": True, "compra_id": 1, "aviso": None, "rectificacion": None, "compras_eliminadas": [1]}
    assert _rects(c) == []
    # de un mes pasado: motivo obligatorio y queda la rectificación con el total y el IVA como los cuentan los reportes
    assert c.post("/api/gastos/compras/2/eliminar", json={}).status_code == 400 and set(_compras(c)) == {2, 3, 4, 5}
    antes, _ = _octubre(c)
    assert antes["egresos_docs"] == 3 and antes["egresos"]["CRC"] == 33900                 # las tres hechas a mano de octubre sin FEC
    r = c.post("/api/gastos/compras/2/eliminar", json={"motivo": MOTIVO})
    assert r.status_code == 200, r.text
    rect = r.json()["rectificacion"]
    assert rect == {"id": 1, "fecha": "2026-11-10T09:00:00-06:00", "usuario": "qa-exo@example.test", "accion": "eliminado", "tipo": "gasto", "origen": "manual", "compra_id": 2,
                    "documento": "FC-0002", "clave": None, "proveedor": "Proveedor QA", "proveedor_identificacion": "", "fecha_documento": "2026-10-15", "moneda": "CRC",
                    "tipo_cambio": 1.0, "total": 11300.0, "impuesto": 1300.0, "iva_acreditar": 1300.0, "mes": "2026-10", "motivo": MOTIVO, "periodo_cerrado": False}
    assert _rects(c) == [rect] and set(_compras(c)) == {3, 4, 5}
    despues, d104 = _octubre(c)
    assert despues["egresos_docs"] == 2 and despues["egresos"]["CRC"] == 22600 and d104["08"]["credito"] == 2600   # salió de los reportes
    x = c.post("/api/gastos/compras/5/eliminar", json={"motivo": MOTIVO}).json()
    assert x["aviso"] == "La entrada de inventario CO-0003 no se revierte: ajústela en Inventario si corresponde" and x["rectificacion"]["id"] == 2
    assert _auditoria(eid)[-2:] == [("gastos_registro_quitado", f"Gasto FC-0002 de Proveedor QA eliminado del registro · rectificación de octubre de 2026: {MOTIVO}"),
                                    ("gastos_registro_quitado", f"Gasto FC-0005 de Proveedor QA eliminado del registro · rectificación de octubre de 2026: {MOTIVO}")]


def test_eliminar_factura_que_vino_de_un_recibido(api):  # noqa: F811
    c = api
    rid = _aceptado(1, OCTUBRE, "compra")
    fila = _recibido(rid)
    _alta(c, _compra(1, "2026-10-08", "compra", recepcion_id=rid, clave=fila.clave, numero=fila.consecutivo))
    assert c.put(f"/api/recepcion/{rid}/compra", json={"compra_id": 1}).status_code == 200
    # hace lo mismo que quitar el recibido del registro: pide el motivo, saca los dos y anota UNA rectificación (la del comprobante)
    assert c.post("/api/gastos/compras/1/eliminar", json={}).status_code == 400
    assert _recibido(rid).registrado is True and set(_compras(c)) == {1}
    r = c.post("/api/gastos/compras/1/eliminar", json={"motivo": MOTIVO})
    assert r.status_code == 200, r.text
    x = r.json()
    assert x["compra_id"] == 1 and x["compras_eliminadas"] == [1] and x["registrado"] is False and x["id"] == rid
    assert _compras(c) == {} and _recibido(rid).registrado is False and _recibido(rid).compra_id is None
    assert [(z["accion"], z["origen"], z["recibido_id"], z["tipo"]) for z in _rects(c)] == [("eliminado", "electronica", rid, "compra")]
    # la factura de un recibido que ya no está en el registro (o que nunca se aceptó) se elimina sola
    pendiente = _registrar(_eid(), _xml_proveedor(2, "42300002", fecha_emision=NOVIEMBRE))
    _alta(c, _compra(2, "2026-11-03", recepcion_id=pendiente, clave=_recibido(pendiente).clave))
    assert c.put(f"/api/recepcion/{pendiente}/compra", json={"compra_id": 2}).status_code == 200
    r = c.post("/api/gastos/compras/2/eliminar", json={})
    assert r.status_code == 200 and r.json()["compras_eliminadas"] == [2] and _recibido(pendiente).compra_id is None and _recibido(pendiente).registrado is True
    assert len(_rects(c)) == 1


def test_el_guardado_generico_tambien_anota(api):  # noqa: F811
    """Hay navegadores con la pantalla anterior: borran por el guardado genérico, que sigue permitiéndolo. Lo de un mes pasado
    queda igual en Rectificaciones, con el motivo vacío."""
    c = api
    eid = _eid()
    rid = _aceptado(1, OCTUBRE, "gasto")
    clave = _recibido(rid).clave
    _alta(c, _compra(1, "2026-10-15", "gasto"), _compra(2, "2026-11-04", "gasto"), _compra(3, "2026-10-08", "gasto", recepcion_id=rid, clave=clave), _compra(4, "2026-10-16", "compra"),
          _compra(5, "2026-10-17", "gasto"))
    assert _rects(c) == []                                       # las altas no son rectificaciones
    # /cambios: borra una de octubre, una de noviembre y la que salió de un comprobante que sigue aceptado y registrado
    r = c.post("/api/registros/compras/cambios", json={"upserts": [], "deletes": [1, 2, 3, 99], "nuevos": []})
    assert r.status_code == 200 and set(_compras(c)) == {4, 5}
    rects = _rects(c)
    assert [(x["accion"], x["origen"], x["compra_id"], x["tipo"], x["mes"], x["motivo"], x["total"], x["iva_acreditar"]) for x in rects] == [("eliminado", "manual", 1, "gasto", "2026-10", "", 11300.0, 1300.0)]
    assert rects[0]["usuario"] == "qa-exo@example.test" and rects[0]["documento"] == "FC-0001" and rects[0]["periodo_cerrado"] is False
    assert _recibido(rid).registrado is True                     # ese documento no salió del registro: sigue como electrónico aceptado
    # PUT de la lista completa sin la 4
    v = c.get("/api/registros/compras").json()
    r = c.put("/api/registros/compras", json={"datos": [x for x in v["datos"] if x["id"] != 4], "version": v["version"]})
    assert r.status_code == 200 and set(_compras(c)) == {5}
    assert [(x["accion"], x["compra_id"], x["tipo"], x["motivo"]) for x in _rects(c)] == [("eliminado", 1, "gasto", ""), ("eliminado", 4, "compra", "")]
    # un PUT que no se guarda (otra versión) no anota nada
    assert c.put("/api/registros/compras", json={"datos": [], "version": v["version"]}).status_code == 409
    assert len(_rects(c)) == 2 and set(_compras(c)) == {5}
    # cambiar de gasto a compra una factura hecha a mano de un mes pasado: «reclasificado»; otros cambios no
    assert c.post("/api/registros/compras/cambios", json={"upserts": [{**_compras(c)[5], "notas": "revisada"}], "deletes": [], "nuevos": []}).status_code == 200
    assert len(_rects(c)) == 2
    assert c.post("/api/registros/compras/cambios", json={"upserts": [{**_compras(c)[5], "tipo": "compra"}], "deletes": [], "nuevos": []}).status_code == 200
    ult = _rects(c)[-1]
    assert (ult["accion"], ult["tipo"], ult["tipo_anterior"], ult["origen"], ult["compra_id"], ult["mes"], ult["motivo"], ult["total"]) == ("reclasificado", "compra", "gasto", "manual", 5, "2026-10", "", 11300.0)
    assert [a for a, _ in _auditoria(eid)] == ["gastos_registro_quitado", "gastos_registro_quitado", "gastos_reclasificado"]
    assert _auditoria(eid)[0][1] == "Gasto FC-0001 de Proveedor QA eliminado del registro · rectificación de octubre de 2026"
    assert _auditoria(eid)[2][1] == "Gasto FC-0005 de Proveedor QA pasa a compra · rectificación de octubre de 2026"


# ------------------------------------------------------------------------------------------------ (5) reclasificar un documento de un mes pasado
def test_reclasificar_un_recibido_de_un_mes_pasado(api):  # noqa: F811
    c = api
    eid = _eid()
    rid, hoy = _aceptado(1, OCTUBRE, "gasto"), _aceptado(2, NOVIEMBRE, "gasto")
    pendiente = _registrar(eid, _xml_proveedor(3, "42300003", fecha_emision=OCTUBRE))
    # la pantalla de hoy no manda motivo: no se rompe
    r = c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "compra", "cuenta_contable": None})
    assert r.status_code == 200 and r.json()["clasificacion"] == "compra"
    rects = _rects(c)
    assert len(rects) == 1 and (rects[0]["accion"], rects[0]["tipo"], rects[0]["tipo_anterior"], rects[0]["origen"], rects[0]["recibido_id"], rects[0]["mes"], rects[0]["motivo"]) == \
        ("reclasificado", "compra", "gasto", "electronica", rid, "2026-10", "")
    assert rects[0]["total"] == _recibido(rid).total and rects[0]["usuario"] == "qa-exo@example.test"
    # adenda A2: la misma clasificación con otra cuenta contable también es una rectificación (sin tipo_anterior); lo mismo otra vez, no
    assert c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "compra", "cuenta_contable": "5.1.01.01 Costos del inventario"}).status_code == 200
    assert len(_rects(c)) == 2 and "tipo_anterior" not in _rects(c)[1] and (_rects(c)[1]["cuenta_anterior"], _rects(c)[1]["cuenta_nueva"]) == ("", "5.1.01.01 Costos del inventario")
    assert c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "compra", "cuenta_contable": "5.1.01.01 Costos del inventario"}).status_code == 200
    assert len(_rects(c)) == 2
    # con motivo, queda
    assert c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "gasto", "motivo": "Era un gasto de oficina"}).status_code == 200
    assert [(x["tipo"], x.get("tipo_anterior"), x["motivo"]) for x in _rects(c)] == [("compra", "gasto", ""), ("compra", None, ""), ("gasto", "compra", "Era un gasto de oficina")]
    assert c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "compra", "motivo": "x" * 301}).status_code == 400
    # del mes en curso, sin aceptar o fuera del registro: se cambia sin rectificación
    assert c.put(f"/api/recepcion/{hoy}/clasificacion", json={"clasificacion": "compra"}).status_code == 200
    assert c.put(f"/api/recepcion/{pendiente}/clasificacion", json={"clasificacion": "compra"}).status_code == 200
    assert c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200
    assert c.put(f"/api/recepcion/{rid}/clasificacion", json={"clasificacion": "compra"}).status_code == 200
    assert [x["accion"] for x in _rects(c)] == ["reclasificado", "reclasificado", "reclasificado", "eliminado"]
    aud = [d for a, d in _auditoria(eid) if a == "recepcion_clasificacion"]
    assert aud[0].endswith(": compra · rectificación de octubre de 2026") and aud[3].endswith(": gasto · rectificación de octubre de 2026: Era un gasto de oficina")
    assert aud[1].endswith(": compra · 5.1.01.01 Costos del inventario · rectificación de octubre de 2026")
    assert "rectificación" not in aud[2] and all("rectificación" not in x for x in aud[4:]) and len(aud) == 7


# ------------------------------------------------------------------------------------------------ (6) el registro lo escribe solo el servidor
def test_rectificaciones_solo_las_escribe_el_servidor(api):  # noqa: F811
    c = api
    assert main.CLAVE_RECTIFICACIONES == "gastos_rectificaciones" and main.CLAVE_RECTIFICACIONES in main.CLAVES_SOLO_SERVIDOR
    falsa = {"id": 1, "accion": "eliminado", "mes": "2026-10", "total": 1}
    for r in (c.put("/api/registros/gastos_rectificaciones", json={"datos": [falsa], "version": 0}),
              c.post("/api/registros/gastos_rectificaciones/cambios", json={"upserts": [falsa], "deletes": [], "nuevos": [1]})):
        assert r.status_code == 403 and "no se editan" in r.json()["detail"], r.text
    assert _rects(c) == []
    rid = _aceptado(1, OCTUBRE)
    assert c.post(f"/api/recepcion/{rid}/quitar-registro", json={"motivo": MOTIVO}).status_code == 200
    assert len(_rects(c)) == 1
    # ni se cambia ni se borra
    assert c.post("/api/registros/gastos_rectificaciones/cambios", json={"upserts": [], "deletes": [1], "nuevos": []}).status_code == 403
    assert c.put("/api/registros/gastos_rectificaciones", json={"datos": [], "version": 1}).status_code == 403
    r = c.delete("/api/registros/gastos_rectificaciones")
    assert r.status_code == 403 and r.json()["detail"] == "Las rectificaciones de compras y gastos no se borran"
    assert len(_rects(c)) == 1
    # quién lo lee: gastos, contabilidad o ver_todo
    lee = lambda *p: auth.puede_leer_registro(set(p) | {"ver"}, "gastos_rectificaciones")   # noqa: E731
    assert lee("gastos") and lee("contabilidad") and lee("ver_todo")
    assert not lee() and not lee("facturar", "cobros", "catalogos", "inventario") and not lee("pos") and not lee("rrhh") and not lee("reportes")
    assert auth.permiso_registro("gastos_rectificaciones") == "gastos"
    for rol, ve in (("Contador", True), ("Solo lectura", True), ("Vendedor", False), ("Cajero", False)):
        _como(rol)
        r = c.get("/api/registros/gastos_rectificaciones")
        assert (r.status_code == 200 and len(r.json()["datos"]) == 1) if ve else r.status_code == 403, rol
        assert ("gastos_rectificaciones" in c.get("/api/registros?v=2").json()["datos"]) is ve, rol


# ------------------------------------------------------------------------------------------------ (7) bases que ya existen
def test_bases_viejas_nacen_registradas(tmp_path):
    """La columna nueva llega a una base de antes de la 4.23 con todo lo que ya tenía en verdadero, sin perder nada."""
    eng = create_engine(f"sqlite:///{(tmp_path / 'vieja.db').as_posix()}")
    tabla = recepcion.Recibido.__table__
    nuevas = ("registrado", "registro_quitado_en", "registro_quitado_por", "registro_motivo")
    with eng.begin() as conn:                                    # la tabla como era en la 4.22
        conn.execute(text("CREATE TABLE recibido (" + ", ".join(f"{col.name} {col.type.compile(eng.dialect)}" + (" PRIMARY KEY" if col.primary_key else "")
                                                               for col in tabla.columns if col.name not in nuevas) + ")"))
        conn.execute(text("INSERT INTO recibido (id, empresa_id, clave, respuesta, estado_mensaje, clasificacion, total, fecha_emision) VALUES "
                          "(1, 1, :a, '05', 'aceptado', 'compra', 113000, :f), (2, 1, :b, NULL, NULL, NULL, 500, :f)"), {"a": "1" * 50, "b": "2" * 50, "f": OCTUBRE})
    db._agregar_columnas_faltantes(eng, [tabla])
    with eng.connect() as conn:
        assert conn.execute(text("SELECT id, registrado, registro_quitado_en, registro_quitado_por, registro_motivo, clasificacion, total FROM recibido ORDER BY id")).all() == \
            [(1, 1, None, None, None, "compra", 113000), (2, 1, None, None, None, None, 500)]
    with Session(eng) as s:
        filas = s.exec(select(recepcion.Recibido).order_by(recepcion.Recibido.id)).all()
        assert [f.registrado for f in filas] == [True, True] and all(recepcion.esta_registrado(f) for f in filas)
        assert [x.id for x in resumen._aceptados(filas, "2026-10-01", "2026-10-31")] == [1]            # el aceptado sigue contando
        nuevo = recepcion.Recibido(empresa_id=1, clave="3" * 50)
        s.add(nuevo); s.commit(); s.refresh(nuevo)
        assert nuevo.registrado is True                          # y lo que se recibe después también nace registrado
    eng.dispose()
    assert recepcion.Recibido.model_fields["registrado"].default is True
    assert all(recepcion.Recibido.model_fields[k].default is None for k in nuevas[1:])


# ------------------------------------------------------------------------------------------------ (8) menú, rutas y pantallas
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")


def _js(*partes):
    return (JS / pathlib.Path(*partes)).read_text(encoding="utf-8").replace("\r\n", "\n")


def _node(tmp_path, codigo, **modulos):
    """Corre `codigo` en Node con copias .mjs de los módulos indicados (los que no importan nada: menu.js y gastos/_registro.js)."""
    import json
    import shutil
    import subprocess
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    for nombre, origen in modulos.items():
        (tmp_path / f"{nombre}.mjs").write_text(_js(*origen), encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(codigo, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout)


ENTRADAS = [("Compras", "/gastos/compras"), ("Gastos", "/gastos/gastos"), ("Recepción de comprobantes", "/gastos/recepcion"), ("Proveedores", "/contactos?tipo=Proveedor"),
            ("Órdenes de compra", "/gastos/ordenes"), ("Notas de débito del proveedor", "/gastos/notas-debito"), ("Pagos a proveedores", "/gastos/pagos"),
            ("Pagos recurrentes", "/gastos/recurrentes"), ("Rectificaciones", "/gastos/rectificaciones"), ("Reportes", "/reportes/de-compras")]


def test_menu_el_grupo_gastos_y_sus_entradas(tmp_path):
    m = _js("menu.js")
    ini = m.index("  { label: 'Gastos', ico: '↙', permiso: 'gastos', children: [")
    bloque = m[ini:m.index("  ] },", ini)]
    assert re.findall(r"\{ label: '([^']+)', to: '([^']+)'", bloque) == ENTRADAS                 # las entradas, en este orden
    assert "to: '/reportes/de-compras', permisos: ['gastos', 'reportes'], modulo: 'reportes'" in bloque
    # el grupo ya no se llama «Compras» en ningún lugar que lo nombre por su texto; «Facturas de compra» es ahora «Compras»
    assert "label: 'Compras', ico:" not in m and "Facturas de compra" not in m and "por['Compras']" not in m and "Compras: 'box'" not in m
    assert "Ingresos: 'sales', Gastos: 'box', Contactos: 'users'" in m and "...(conCompras ? [{ ...sin(por['Gastos']), permiso: 'gastos' }] : [])" in m
    orden = m[m.index("const ORDEN_TIPO = {"):m.index("const _menus = {};")]
    assert orden.count("'Gastos'") == 4 and "'Compras'" not in orden
    assert "['/gastos', 'gastos']" in m                                                         # el mismo permiso para abrir las rutas
    a = _js("app.js")
    for ruta in ("'/gastos/compras': 'gastos/compras', '/gastos/compras/nueva': 'gastos/compra-form',", "'/gastos/gastos': 'gastos/compras', '/gastos/rectificaciones': 'gastos/rectificaciones',",
                 "'/gastos/pagos': 'gastos/pagos'", "'/gastos/recurrentes': 'gastos/recurrentes'", "'/gastos/notas-debito': 'gastos/notas-debito'", "'/gastos/ordenes': 'gastos/ordenes'",
                 "'/gastos/recepcion': 'gastos/recepcion',"):
        assert ruta in a, ruta
    assert "Gastos: ['Compras, gastos, proveedores y cuentas por pagar'" in _js("pages", "inicio.js") and "  Compras: [" not in _js("pages", "inicio.js")
    # textos de ayuda que nombraban el grupo
    assert "Registrar también el pago en Gastos › Pagos a proveedores" in _js("pages", "pos", "caja.js") and "Compras ›" not in _js("pages", "pos", "caja.js")
    assert "por registrar en Gastos" in _js("pages", "pos", "cierres.js") and "quien tiene acceso a Gastos" in _js("pages", "inventario", "reponer.js")
    # el menú que arma cada tipo de negocio, de verdad
    r = _node(tmp_path, """
import { menuTipo, menuVisibleDe, rutaPermitidaDe } from './menu.mjs';
const ses = (tipo, permisos) => ({ empresa_id: 1, tipo, permisos, esAdmin: false, puede(p) { return permisos.includes(p); }, tieneModulo: () => true });
const grupo = (tipo, permisos) => { const v = menuVisibleDe(ses(tipo, permisos), () => true); const raiz = v.find(x => x.label === 'Gastos') || ((v.find(x => x.label === 'Contabilidad') || {}).children || []).find(x => x.label === 'Gastos'); return raiz ? raiz.children.map(c => [c.label, c.to]) : null; };
const todos = ['ver', 'gastos', 'reportes', 'contabilidad', 'facturar', 'cobros', 'escribir'];
console.log(JSON.stringify({
  raiz: Object.fromEntries(['facturacion', 'comercio', 'restaurante', 'servicios', 'hospitalidad'].map(t => [t, menuTipo(t).map(x => x.label)])),
  conGastos: Object.fromEntries(['facturacion', 'comercio', 'hospitalidad'].map(t => [t, grupo(t, todos)])),
  soloGastos: grupo('facturacion', ['ver', 'gastos']), vendedor: grupo('facturacion', ['ver', 'facturar', 'cobros']), soloLectura: grupo('facturacion', ['ver', 'ver_todo']),
  rutas: ['/gastos/compras', '/gastos/gastos', '/gastos/rectificaciones'].map(p => [rutaPermitidaDe(ses('facturacion', ['ver', 'gastos']), p), rutaPermitidaDe(ses('facturacion', ['ver', 'facturar']), p)]),
}));
""", menu=("menu.js",))
    for tipo in ("facturacion", "comercio", "restaurante", "servicios"):
        assert "Gastos" in r["raiz"][tipo] and "Compras" not in r["raiz"][tipo], tipo
    assert "Gastos" not in r["raiz"]["hospitalidad"] and "Compras" not in r["raiz"]["hospitalidad"]          # en el hotel va dentro de Contabilidad
    for tipo in ("facturacion", "comercio", "hospitalidad"):
        assert r["conGastos"][tipo] == [list(x) for x in ENTRADAS], tipo
    assert r["soloGastos"] == [list(x) for x in ENTRADAS] and r["vendedor"] is None and r["soloLectura"] == [list(x) for x in ENTRADAS]   # quien ve todo también lo consulta
    assert r["rutas"] == [[True, False]] * 3


def test_pantallas_compras_gastos_y_rectificaciones():
    c = _js("pages", "gastos", "compras.js")
    # una sola pantalla con el tipo como parámetro; la lista sale del registro (facturas + aceptados registrados)
    assert "const tipoDeRuta = () => (/^#?\\/gastos\\/gastos(\\/|\\?|$)/.test(String(location.hash || '')) ? 'gasto' : 'compra');" in c
    assert "rows() { return filasRegistro(this.tipo, this.lista, this.recibidos); }" in c and "this.recibidos = await api('/api/recepcion');" in c
    assert "titulo: 'Compras'" in c and "titulo: 'Gastos'" in c and "nueva: '+ Nueva compra'" in c and "nueva: '+ Nuevo gasto'" in c
    for etiqueta in ("label: 'Fecha'", "label: 'Número'", "label: 'Proveedor'", "label: 'Origen'", "label: 'Total'", "label: 'IVA'", "label: 'Por pagar'"):
        assert etiqueta in c, etiqueta
    assert "(v === null || v === undefined ? '—' : money(v, r.moneda))" in c                       # sin factura en 'compras' no hay saldo por pagar
    # acciones: las de siempre para las facturas; para un aceptado sin factura, registrar para pagar, pasar a gasto o a compra y eliminar
    for accion in ("Dar entrada al inventario", "Registrar pago", "Registrar para pagar", "pasar: 'Pasar a gasto'", "pasar: 'Pasar a compra'", 'title="Eliminar del registro" @click.stop="eliminar(row)"'):
        assert accion in c, accion
    assert "registrarParaPagar(r) { location.hash = '/gastos/compras/nueva?recepcion=' + r.rid; }" in c
    assert "api('/api/recepcion/' + r.rid + '/clasificacion', { method: 'PUT', body: { clasificacion: this.t.otra, cuenta_contable: null, motivo:" in c
    # eliminar va por las rutas nuevas (el servidor aplica las reglas y anota la rectificación); la pantalla ya no borra por el guardado genérico
    assert "api('/api/gastos/compras/' + r.cid + '/eliminar', { method: 'POST', body })" in c and "api('/api/recepcion/' + r.rid + '/quitar-registro', { method: 'POST', body })" in c
    assert "this.lista = this.lista.filter(" not in c and "await mock.guardarTodo();" in c
    # de un mes pasado: el cuadro que lo explica y pide el motivo; del mes en curso, la confirmación de siempre
    assert "const mes = mesPasado(r.fecha, hoy());" in c and "if (mes) { this.rect = { fila: r, accion: 'eliminar', mes, motivo: '' }; return; }" in c
    assert "avisoRectificacion(x.mes, x.accion === 'eliminar' ? 'eliminarlo' : 'cambiarlo de '" in c and '<div class="alert warn">{{rectTexto}}</div>' in c
    assert "(x.accion === 'eliminar' ? motivoValido(x.motivo) :" in c and "if (!confirm('¿Eliminar ' + this.nombreFila(r) + '? Sale de los reportes y de la contabilidad'" in c
    # totales al pie y las tres exportaciones con la función común
    assert "totales() { return totalesRegistro(this.rows); }" in c and 'v-for="x in totales"' in c
    assert "import { descargarTabla } from '../reportes/_montos.js';" in c and c.count("descargarTabla(") == 1
    for formato in ("pdf", "xlsx", "csv"):
        assert f'@click="exportar(\'{formato}\')"' in c, formato
    assert "exportarFilas(" not in c and "descargarCSV(" not in c
    # el formulario: compra o gasto, y vuelve a la lista de su tipo
    f = _js("pages", "gastos", "compra-form.js")
    assert "if (this.params.tipo === 'gasto') this.f.tipo = 'gasto';" in f and "location.hash = doc.tipo === 'gasto' ? '/gastos/gastos' : '/gastos/compras';" in f
    assert ":crumbs=\"[{label: f.tipo === 'gasto' ? 'Gastos' : 'Compras', to: lista},{label:'Nueva factura'}]\"" in f and "Facturas de compra" not in f
    # Recepción: el aceptado que se quitó del registro
    rc = _js("pages", "gastos", "recepcion.js")
    assert "respuesta_nombre: sinRegistrar(r) ? 'Aceptado sin registrar' : r.respuesta_nombre" in rc
    assert '<button class="btn sm" v-if="sinRegistrar(row)" @click.stop="abrirRegistrar(row)"' in rc and ">Registrar como compra o gasto</button>" in rc
    assert "api('/api/recepcion/' + x.row.id + '/registrar', { method: 'POST', body: { clasificacion: x.clasificacion, cuenta_contable: x.cuenta_contable || null, motivo:" in rc
    assert "{{avisoRectificacion(reg.mes, 'registrarlo de nuevo')}}" in rc and "sinRegistrar, avisoRectificacion, motivoValido," in rc
    # Rectificaciones: solo lectura
    x = _js("pages", "gastos", "rectificaciones.js")
    assert ('<PageHead title="Rectificaciones" sub="Compras y gastos de meses pasados que se eliminaron, se volvieron a registrar o cambiaron de clasificación. '
            'Si ya presentó la declaración de ese mes, debe rectificarla.">') in x
    assert "mock.get('gastos_rectificaciones', [])" in x and "mock.set(" not in x and "api(" not in x and "@click=\"eliminar" not in x
    for etiqueta in ("Fecha", "Usuario", "Acción", "Tipo", "Documento", "Proveedor", "Fecha del documento", "Mes afectado", "Total", "IVA", "Motivo", "Periodo contable"):
        assert f"label: '{etiqueta}'" in x, etiqueta
    assert "'Cerrado: el reverso queda en el mes en curso' : 'Cerrado: el ajuste queda en el mes en curso'" in x and "reábralo" not in x     # adenda A1: el asiento del mes cerrado no se toca
    assert 'v-model="mes" title="Mes afectado"' in x and 'v-model="accion" title="Acción"' in x and "Resumen por mes afectado" in x
    assert 'empty-title="No hay rectificaciones"' in x and "Lo del mes en curso no es una rectificación." in x
    assert "import { descargarTabla } from '../reportes/_montos.js';" in x and x.count("descargarTabla(") == 2            # la lista y el resumen por mes
    for formato in ("pdf", "xlsx", "csv"):
        assert f'@click="exportar(\'{formato}\')"' in x and f'@click="exportarResumen(\'{formato}\')"' in x, formato
    # el historial de operaciones nombra las acciones nuevas
    s = _js("pages", "configuracion", "seccion.js")
    assert "gastos_registro_quitado: ['Gastos', 'Compra o gasto eliminado del registro']" in s and "gastos_registro_puesto: ['Gastos'," in s and "gastos_reclasificado: ['Gastos'," in s


def test_reglas_del_registro_en_la_pantalla(tmp_path):
    """filasRegistro junta sin repetir las facturas de 'compras' y los aceptados registrados, con las mismas reglas que los reportes."""
    r = _node(tmp_path, """
import { filasRegistro, totalesRegistro, mesPasado, mesLegible, avisoRectificacion, motivoValido, resumenRectificaciones, sinRegistrar, enRegistro } from './registro.mjs';
const rec = (id, o = {}) => ({ id, clave: String(id).padStart(50, '0'), tipo_documento: '01', consecutivo: 'C' + id, emisor_nombre: 'Prov ' + id, fecha_emision: '2026-10-08T10:00:00-06:00', moneda: 'CRC',
  total: 1130, impuesto: 130, iva: 130, monto_impuesto_acreditar: 130, respuesta: '05', estado_mensaje: 'aceptado', clasificacion: 'gasto', registrado: true, compra_id: null, ...o });
const com = (id, o = {}) => ({ id, tipo: 'gasto', numero: 'FC-' + id, proveedor: 'Manual ' + id, creacion: '2026-11-02', moneda: 'CRC', total: 11300, pagado: 0, lineas: [{ cantidad: 1, precio_unitario: 10000, descuento: 0, tarifa: 13 }], ...o });
const recibidos = [rec(1), rec(2, { clasificacion: 'compra' }), rec(3, { registrado: false }), rec(4, { respuesta: null, estado_mensaje: null }),
  rec(5, { tipo_documento: '03', referencia_clave: rec(1).clave, total: 226, impuesto: 26, iva: 26, monto_impuesto_acreditar: 26 }), rec(6, { tipo_documento: '10' }), rec(7, { estado_mensaje: 'rechazado' }),
  rec(8, { tipo_documento: '03', referencia_clave: rec(3).clave }), rec(9, { clasificacion: null, respuesta: '06', registrado: undefined }), rec(10, { clasificacion: 'compra', moneda: 'USD', total: 113, monto_impuesto_acreditar: 0 }),
  rec(11, { compra_id: 7 })];
const compras = [com(1), com(2, { tipo: 'compra' }), com(3, { recepcion_id: 9, clave: rec(9).clave, tipo: 'compra', total: 1130, pagado: 130 }), com(4, { fec_id: 55 }), com(5, { recepcion_id: 4, clave: rec(4).clave }),
  com(6, { tipo: undefined, lineas: [], total: 500 }), com(7, { creacion: '2026-10-08' })];
const g = filasRegistro('gasto', compras, recibidos), c = filasRegistro('compra', compras, recibidos);
const corta = f => ({ id: f.id, cid: f.cid, rid: f.rid, origen: f.origenTexto, fecha: f.fecha, total: f.total, iva: f.iva, por_pagar: f.por_pagar });
console.log(JSON.stringify({ gastos: g.map(corta), compras: c.map(corta), totG: totalesRegistro(g), totC: totalesRegistro(c), fechas: g.map(f => f.fecha),
  meses: [mesPasado('2026-10-31', '2026-11-10'), mesPasado('2026-11-01', '2026-11-10'), mesPasado('2026-12-01', '2026-11-10'), mesPasado('', '2026-11-10'), mesPasado('2025-12-31T23:00:00-06:00', '2026-01-01')],
  texto: avisoRectificacion('2026-10', 'eliminarlo'), legible: [mesLegible('2026-09'), mesLegible('x')], motivo: [motivoValido(''), motivoValido(' abc '), motivoValido('abcde'), motivoValido('x'.repeat(300)), motivoValido('x'.repeat(301))],
  estados: [sinRegistrar(recibidos[2]), sinRegistrar(recibidos[0]), sinRegistrar(recibidos[3]), enRegistro(recibidos[8]), enRegistro(recibidos[6])],
  resumen: resumenRectificaciones([{ mes: '2026-10', accion: 'eliminado', moneda: 'CRC', total: 1130, iva_acreditar: 130 }, { mes: '2026-10', accion: 'eliminado', moneda: 'USD', tipo_cambio: 500, total: 10, iva_acreditar: 1 },
    { mes: '2026-10', accion: 'registrado', moneda: 'CRC', total: 1130, iva_acreditar: 130 }, { mes: '2026-10', accion: 'reclasificado', moneda: 'CRC', total: 999, iva_acreditar: 9 },
    { mes: '2026-09', accion: 'eliminado', moneda: 'CRC', total: -226, iva_acreditar: -26 }]) }));
""", registro=("pages", "gastos", "_registro.js"))
    porid = {f["id"]: f for f in r["gastos"]}
    # gastos: las facturas (la hecha a mano, la del comprobante 9, la de la FEC, la de un recibido sin aceptar, la que no dice el tipo y la 7) y los aceptados
    # sin factura: el 1 y su nota de crédito, con signo, y el 11. Fuera: el quitado del registro (3) y la nota que se refiere a él (8), el que no está
    # aceptado (4), el recibo de pago (6), el que Hacienda rechazó (7) y el que ya sale por su factura (9)
    assert sorted(porid, key=str) == [1, 3, 4, 5, 6, 7, "r1", "r11", "r5"]
    assert porid[1] == {"id": 1, "cid": 1, "rid": None, "origen": "Manual", "fecha": "2026-11-02", "total": 11300, "iva": 1300, "por_pagar": 11300}
    assert porid[3] == {"id": 3, "cid": 3, "rid": 9, "origen": "Electrónica aceptada", "fecha": "2026-10-08", "total": 1130, "iva": 130, "por_pagar": 1000}   # una sola fila, la de la factura
    assert porid[4]["origen"] == "Factura electrónica de compra" and porid[5]["origen"] == "Manual" and porid[5]["rid"] is None and porid[6]["total"] == 500
    # pulido P10: el compra_id que anotó el recibido 11 no vincula por sí solo (la factura 7 no guarda recepcion_id ni clave): son dos documentos, como
    # en los reportes, los asientos y el servidor
    assert porid[7]["rid"] is None and porid[7]["origen"] == "Manual" and porid[7]["total"] == 11300 and porid["r11"]["total"] == 1130
    assert porid["r1"] == {"id": "r1", "cid": None, "rid": 1, "origen": "Electrónica aceptada", "fecha": "2026-10-08", "total": 1130, "iva": 130, "por_pagar": None}
    assert porid["r5"]["origen"] == "Electrónica aceptada · nota de crédito" and porid["r5"]["total"] == -226 and porid["r5"]["iva"] == -26
    assert r["fechas"] == sorted(r["fechas"], reverse=True)                                       # lo más reciente primero
    assert sorted((f["id"] for f in r["compras"]), key=str) == [2, "r10", "r2"]                   # lo clasificado como compra
    assert r["totG"] == [{"moneda": "CRC", "docs": 9, "total": 48864, "iva": 5564, "por_pagar": 46700}]
    assert r["totC"] == [{"moneda": "CRC", "docs": 2, "total": 12430, "iva": 1430, "por_pagar": 11300}, {"moneda": "USD", "docs": 1, "total": 113, "iva": 0, "por_pagar": 0}]
    assert r["meses"] == ["2026-10", None, None, None, "2025-12"]
    assert r["texto"] == ("Este documento es de octubre de 2026: eliminarlo cambia los reportes de ese mes. Queda anotado en Gastos › Rectificaciones; "
                          "si ya presentó la declaración de ese mes, debe rectificarla.")
    assert r["legible"] == ["setiembre de 2026", "x"] and r["motivo"] == [False, False, True, True, False]
    assert r["estados"] == [True, False, False, True, False]
    assert r["resumen"] == [{"mes": "2026-10", "cuantas": 4, "eliminados": 2, "registrados": 1, "reclasificados": 1, "salio_total": 6130, "salio_iva": 630, "entro_total": 1130, "entro_iva": 130, "id": "2026-10"},
                            {"mes": "2026-09", "cuantas": 1, "eliminados": 1, "registrados": 0, "reclasificados": 0, "salio_total": -226, "salio_iva": -26, "entro_total": 0, "entro_iva": 0, "id": "2026-09"}]
