"""3.59: respaldos por empresa (crear, listar, descargar, eliminar desde Configuración › Respaldos) y eliminación de respaldos
desde el panel del administrador del sistema (generales y de las empresas)."""
import io
import json
import types
import zipfile

from fastapi.testclient import TestClient
from sqlmodel import Session, select

import pytest

from app import auth, respaldo
from app.db import Empresa, engine, init_db


@pytest.fixture(autouse=True)
def _sin_superadmin_al_final():
    yield
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-359@example.test")).first()
        if u:
            s.delete(u); s.commit()


def _superadmin(s):
    u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-359@example.test")).first()
    if not u:
        u = auth.Usuario(correo="sa-359@example.test", nombre="SA 359", password_hash=auth.hash_password("Clave-Segura-359-QA!"), es_superadmin=True)
        s.add(u); s.commit(); s.refresh(u)
    return u


def _cliente():
    from app.main import app
    init_db()
    with Session(engine) as s:
        sa = _superadmin(s)
        e = s.exec(select(Empresa).where(Empresa.nombre == "Respaldos 359 QA")).first()
        if not e:
            e = Empresa(nombre="Respaldos 359 QA", numero_id="3-101-359359", actividad="620100", otras_senas="Oficina 2", correo="respaldos359@example.test", ambiente="sandbox", tipo_negocio="facturacion")
            s.add(e); s.commit(); s.refresh(e)
        s.expunge(e)
        sa = types.SimpleNamespace(id=sa.id, correo=sa.correo, es_superadmin=True, nombre="SA", mfa_activo=True)
    ctx = auth.Contexto(sa, e, "Administrador")
    app.dependency_overrides[auth.superadmin] = lambda: sa
    app.dependency_overrides[auth.solo_usuario] = lambda: sa
    app.dependency_overrides[auth.contexto] = lambda: ctx
    return TestClient(app), e, app


def _limpiar(app):
    app.dependency_overrides.clear()


def test_empresa_crea_lista_descarga_y_elimina_su_respaldo():
    c, e, app = _cliente()
    try:
        for r in respaldo.listar_empresa(e.id):             # por si otra prueba dejó alguno
            respaldo.eliminar_empresa(e.id, r["nombre"])
        r = c.post("/api/respaldos")
        assert r.status_code == 200, r.text
        nombre = r.json()["nombre"]
        assert nombre.startswith(f"empresa_{e.id}_") and nombre.endswith(".zip")
        assert (respaldo.dir_empresa(e.id) / nombre).is_file()

        lista = c.get("/api/respaldos").json()
        assert [x["nombre"] for x in lista["respaldos"]] == [nombre] and lista["maximo"] == respaldo.MAXIMO_EMPRESA

        d = c.get(f"/api/respaldos/{nombre}")
        assert d.status_code == 200 and d.headers["content-type"].startswith("application/zip")
        with zipfile.ZipFile(io.BytesIO(d.content)) as z:
            nombres = z.namelist()
            assert f"data/empresas/empresa_{e.id}.db" in nombres and "empresa.json" in nombres and "LEEME.txt" in nombres
            datos = json.loads(z.read("empresa.json"))
            assert datos["nombre"] == "Respaldos 359 QA"
            assert not any(k for k in datos if "clave" in k or "pass" in k or "token" in k)   # nada sensible en el json
            assert not any(n.endswith(("secret.key", "master.key")) for n in nombres)

        # otro nombre válido pero de otra empresa, o inventado: no existe para esta empresa
        assert c.get(f"/api/respaldos/empresa_999999_20260101_000000.zip").status_code == 404
        assert c.get("/api/respaldos/../facturacr.db").status_code in (404, 422)

        assert c.delete(f"/api/respaldos/{nombre}").json()["ok"] is True
        assert c.get("/api/respaldos").json()["respaldos"] == []
        assert c.delete(f"/api/respaldos/{nombre}").status_code == 404
    finally:
        _limpiar(app)


def test_tope_de_respaldos_por_empresa(monkeypatch):
    c, e, app = _cliente()
    try:
        for r in respaldo.listar_empresa(e.id):
            respaldo.eliminar_empresa(e.id, r["nombre"])
        monkeypatch.setattr(respaldo, "MAXIMO_EMPRESA", 1)
        assert c.post("/api/respaldos").status_code == 200
        r = c.post("/api/respaldos")
        assert r.status_code == 409 and "elimine" in r.json()["detail"].lower()
        for x in respaldo.listar_empresa(e.id):
            respaldo.eliminar_empresa(e.id, x["nombre"])
    finally:
        _limpiar(app)


def test_rol_sin_configurar_no_ve_respaldos():
    from app.main import app
    c, e, app = _cliente()
    try:
        with Session(engine) as s:
            sa = _superadmin(s)
            sa = types.SimpleNamespace(id=sa.id, correo=sa.correo, es_superadmin=False, nombre="V", mfa_activo=True)
        app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(sa, e, "Vendedor")
        assert c.get("/api/respaldos").status_code == 403
        assert c.post("/api/respaldos").status_code == 403
    finally:
        _limpiar(app)


def test_admin_lista_y_elimina_respaldos_generales_y_de_empresas():
    c, e, app = _cliente()
    try:
        propio = c.post("/api/respaldos").json()["nombre"]
        general = c.post("/api/admin/respaldos").json()["nombre"]
        j = c.get("/api/admin/respaldos").json()
        assert general in [r["nombre"] for r in j["respaldos"]]
        fila = next(x for x in j["empresas"] if x["empresa_id"] == e.id)
        assert fila["nombre"] == "Respaldos 359 QA" and propio in [r["nombre"] for r in fila["respaldos"]]
        assert j["maximo_empresa"] == respaldo.MAXIMO_EMPRESA

        d = c.get(f"/api/admin/respaldos/empresa/{e.id}/{propio}")
        assert d.status_code == 200 and d.headers["content-type"].startswith("application/zip")

        assert c.delete(f"/api/admin/respaldos/empresa/{e.id}/{propio}").json()["ok"] is True
        assert c.delete(f"/api/admin/respaldos/empresa/{e.id}/{propio}").status_code == 404
        assert c.delete(f"/api/admin/respaldos/{general}").json()["ok"] is True
        assert c.delete(f"/api/admin/respaldos/{general}").status_code == 404
        assert c.delete("/api/admin/respaldos/otro.zip").status_code == 404
        j = c.get("/api/admin/respaldos").json()
        assert general not in [r["nombre"] for r in j["respaldos"]]
        assert not any(x["empresa_id"] == e.id for x in j["empresas"])
    finally:
        _limpiar(app)
