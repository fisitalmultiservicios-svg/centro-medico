"""4.32, bloque B1 (lado programa): app/sinc_datos_programa.py con UN dato de punta a punta (categorías).

La cola (sinc_cambio: anotar, fundir, una enviada no cambia), aplicar_canonico (versión mayor, lápidas, no pisa lo pendiente), la ida y
vuelta POST /api/sinc/datos (goteo con cursor, veredictos, siguiente_en, mas), la pausa única (404, 405, sin la señal datos_v2), la época
mínima (respaldo restaurado aquí o en la web), las acciones en vivo (pedir_accion) y los ganchos al_aplicar con su reintento.

La «web» es un simulador que sigue el JSON del contrato (contrato_432.md §2.2 y §2.4): las rutas de verdad las prueba el bloque web (P1)
en test_432_mecanismo.py y el escenario S1-cat con dos servidores. Aquí no hay red: httpx del módulo se reemplaza por el simulador."""
import copy
import json
import logging
import random

import httpx
import pytest
from fastapi import HTTPException
from sqlmodel import Session

from app import auth, modulos, secretos, sinc
from app import sinc_diario as diario
from app.db import Cliente, engine, engine_empresa, init_db
from app import sinc_datos as sd  # noqa: E402  (bloque web, P1: Dato, declarar, huella, tablas y el oyente)
try:                                                    # las declaraciones de P1 van primero: así «categoria» no se declara dos veces
    from app import sinc_datos_decl  # noqa: F401
except ImportError:
    pass
from app import sinc_datos_programa as sdp  # noqa: E402

init_db()
NUBE = "http://nube432b1"
T = 3                                                   # terminal de la computadora de estas pruebas
R = modulos.RANGO
TOKEN = "fcr_prueba_b1_programa"
if sd.dato("categoria") is None:
    sd.declarar(sd.Dato("categoria", registro="categorias", escribe="todos", viaja="dos", permiso="catalogos"))
CAT = sd.dato("categoria")


class _Respuesta:
    def __init__(self, status: int, cuerpo=None):
        self.status_code, self._cuerpo = status, cuerpo
        self.text = json.dumps(cuerpo) if cuerpo is not None else ""

    def json(self):
        if self._cuerpo is None:
            raise ValueError("no es JSON")
        return self._cuerpo

    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError(str(self.status_code), request=None, response=None)


class _Web:
    """La web del contrato §2.2, en memoria: una línea por dato con versión creciente, goteo por cursor SIN filtrar por origen, (autora, n)
    único con `repetido`, n_max por autora. `veredicto(op)` permite forzar el resultado de una op (conflicto, rechazo, renumerar)."""
    Timeout = httpx.Timeout

    def __init__(self):
        self.v, self.datos, self.log, self.recibidas, self.llamadas = 1000, {}, [], {}, []
        self.epoca, self.forzar, self.veredicto, self.tope, self.siguiente_en = "web1", None, None, 500, 5
        self.antes_de_contestar = None                   # excepción después de aplicar (respuesta perdida)
        self.accion = None                               # fn(cuerpo) -> _Respuesta
        self.filas_resp, self.filas_codigo = {}, 200     # B3: /datos/filas {(tipo, ref): (estado, v, datos)}; lo demás «nunca»
        self.hora = "2026-11-20T21:02:12+00:00"

    def cambiar(self, tipo, ref, contenido=None, borrado=False):
        self.v += 1
        ref = str(ref)
        self.datos[(tipo, ref)] = None if borrado else copy.deepcopy(contenido)
        self.log = [f for f in self.log if (f["tipo"], f["ref"]) != (tipo, ref)]
        f = {"tipo": tipo, "ref": ref, "v": self.v, "dueno": None, "borrado": bool(borrado), "origen": 0, "campos": {},
             "datos": None if borrado else copy.deepcopy(contenido)}
        self.log.append(f)
        return f

    def _aplicar(self, op):
        if self.veredicto:
            r = self.veredicto(op)
            if r:
                return {"n": op["n"], "motivo": None, "v": None, "ref": op["ref"], "canonico": None, "pisados": [], **r}
        clave = (op["tipo"], op["ref"])
        if op["op"] == "alta":
            contenido = op["datos"]["fila"]
        elif op["op"] == "cambio":
            contenido = dict(self.datos.get(clave) or {})
            for g, (_a, b, _w) in op["datos"]["campos"].items():
                contenido[g] = b[0]
        else:
            contenido = None
        f = self.cambiar(op["tipo"], op["ref"], contenido, borrado=contenido is None)
        return {"n": op["n"], "estado": "aplicado", "motivo": None, "v": f["v"], "ref": op["ref"], "canonico": copy.deepcopy(contenido), "pisados": []}

    def post(self, url, headers=None, json=None, timeout=None):  # noqa: A002
        assert url.startswith(NUBE), url
        assert headers == {"Authorization": "Bearer " + TOKEN}
        self.llamadas.append((url[len(NUBE):], copy.deepcopy(json)))
        if isinstance(self.forzar, Exception):
            raise self.forzar
        if isinstance(self.forzar, _Respuesta):
            return self.forzar
        ruta = url[len(NUBE):]
        if ruta == sdp.RUTA_ACCION:
            return self.accion(json)
        if ruta == sdp.RUTA_FILAS:
            if self.filas_codigo != 200:
                return _Respuesta(self.filas_codigo, {"detail": "Not Found"})
            out = []
            for x in json["refs"]:
                est, v, datos = self.filas_resp.get((x["tipo"], x["ref"]), ("nunca", None, None))
                out.append({"tipo": x["tipo"], "ref": x["ref"], "estado": est, "v": v, "datos": copy.deepcopy(datos)})
            return _Respuesta(200, {"filas": out, "max_dado": {}, "epoca": self.epoca})
        assert ruta == sdp.RUTA_DATOS
        autora, resultados = json["autora"], []
        for i, op in enumerate(json["ops"]):
            k = (autora, op["n"])
            if k in self.recibidas:
                resultados.append({**self.recibidas[k], "estado": "repetido"})
                continue
            res = self._aplicar(op)
            if res["estado"] == "reintentar":            # (I-2) ella y las siguientes: sin anotar (no avanza n_max) y sin aplicar
                resultados.extend({**res, "n": x["n"]} for x in json["ops"][i:])
                break
            self.recibidas[k] = res
            resultados.append(res)
        if self.antes_de_contestar is not None:
            ex, self.antes_de_contestar = self.antes_de_contestar, None
            raise ex
        todas = [f for f in self.log if f["v"] > json["desde"]]
        filas = todas[:self.tope]
        return _Respuesta(200, {"protocolo": 2, "hora": self.hora, "epoca": self.epoca,
                                "cursor": filas[-1]["v"] if filas else json["desde"], "mas": len(todas) > len(filas), "sembrando": False,
                                "siguiente_en": self.siguiente_en, "n_max": max([n for (a, n) in self.recibidas if a == autora] + [0]),
                                "pedidos_programa": False, "resultados": resultados, "filas": copy.deepcopy(filas)})

    def ops_de(self, i):
        return self.llamadas[i][1]["ops"]


@pytest.fixture
def web(monkeypatch):
    w = _Web()
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    monkeypatch.setattr(sdp, "httpx", w)
    yield w


_CREADAS = []


@pytest.fixture(autouse=True, scope="module")
def _limpieza():
    yield
    for eid in _CREADAS:
        modulos._rangos.pop(eid, None); sdp.olvidar(eid)


def _empresa(protocolo2: bool = True) -> int:
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "B1 programa QA", f"b1prog-{random.randint(1, 10**9)}@example.test", "31012" + str(random.randint(10**4, 10**5 - 1)))
        eid, clave = e.id, e.clave_cifrada
    with Session(engine_empresa(eid)) as s:
        sinc._escribir(s, eid, sinc.CLAVE_LOCAL, {"vinculado": True, "url": NUBE, "token": secretos.cifrar(clave, TOKEN), "terminal": T})
    modulos.fijar_rango(eid, T)
    _CREADAS.append(eid)
    sdp.olvidar(eid)
    if protocolo2:
        orig = sinc.MODO_LOCAL
        sinc.MODO_LOCAL = True
        try:
            sdp.pasar_a_protocolo_2(eid)
            sdp._guardar_estado(eid, releyendo=False, carga="hecha")      # B3: la carga inicial se prueba aparte
        finally:
            sinc.MODO_LOCAL = orig
    return eid


def _ops(eid, estado=None):
    with Session(engine_empresa(eid)) as s:
        q = "SELECT id, autora, n, tipo, ref, op, base_v, datos, estado FROM sinc_cambio" + (" WHERE estado = :e" if estado else "") + " ORDER BY id"
        return [dict(zip(("id", "autora", "n", "tipo", "ref", "op", "base_v", "datos", "estado"), f))
                for f in s.connection().execute(sdp._sql(q), {"e": estado} if estado else {}).all()]


def _linea(eid, tipo, ref):
    with Session(engine_empresa(eid)) as s:
        f = s.connection().execute(sdp._sql("SELECT v, borrado, huella FROM sinc_dato WHERE tipo = :t AND ref = :r"), {"t": tipo, "r": str(ref)}).first()
        return None if f is None else {"v": f[0], "borrado": bool(f[1]), "huella": f[2]}


def _pisados(eid):
    with Session(engine_empresa(eid)) as s:
        return [dict(zip(("tipo", "ref", "campo", "motivo", "perdio"), f)) for f in
                s.connection().execute(sdp._sql("SELECT tipo, ref, campo, motivo, perdio FROM sinc_pisado ORDER BY id")).all()]


def _cat(eid, iid):
    with Session(engine_empresa(eid)) as s:
        return sdp.contenido_local(s, eid, CAT, str(iid))


def _poner_cat(eid, iid, contenido):
    """Escribe una categoría aquí como si viniera de afuera (sin que el oyente la anote)."""
    with Session(engine_empresa(eid)) as s, diario.aplicando(0):
        sdp._escribir(s, eid, CAT, str(iid), contenido)
        s.commit()


def _anotar(eid, ref, antes, despues):
    with Session(engine_empresa(eid)) as s:
        r = sdp.anotar(s, eid, "categoria", ref, antes, despues)
        s.commit()
        return r


def _fila(ref, v, datos=None, borrado=False, tipo="categoria"):
    return {"tipo": tipo, "ref": str(ref), "v": v, "dueno": None, "borrado": borrado, "origen": 0, "campos": {}, "datos": datos}


def _aplicar(eid, fila, **kw):
    with Session(engine_empresa(eid)) as s, diario.aplicando(0):
        r = sdp.aplicar_canonico(s, eid, fila, **kw)
        s.commit()
        return r


# ---------------------------------------------------------------------------------------------------------------- sin protocolo
def test_sin_protocolo_todo_como_la_431(web):
    eid = _empresa(protocolo2=False)
    assert sdp.protocolo(eid) == 0 and not sdp.en_pausa(eid)
    assert _anotar(eid, "7", None, {"id": 7, "nombre": "Bebidas"}) is False
    assert _ops(eid) == []
    assert sdp.salta_en_bajar(eid, "categorias") is False
    web.forzar = _Respuesta(405)                         # web 4.31: el POST cae en los archivos fijos
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_PROBAR
    assert sdp.protocolo(eid) == 0


def test_sin_conectar_no_llama_y_vuelve_a_revisar_en_un_minuto(web):
    eid = _empresa(protocolo2=False)
    with Session(engine_empresa(eid)) as s:
        sinc._escribir(s, eid, sinc.CLAVE_LOCAL, {"vinculado": False, "terminal": T})
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_SIN_VINCULAR == 60
    assert web.llamadas == []


def test_en_la_web_el_protocolo_siempre_es_0(monkeypatch):
    eid = _empresa()
    monkeypatch.setattr(sinc, "MODO_LOCAL", False)
    sdp.olvidar(eid)
    assert sdp.protocolo(eid) == 0


def test_probar_pasa_al_protocolo_2_cuando_la_web_tiene_el_canal(web):
    eid = _empresa(protocolo2=False)
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_MINIMO
    est = sdp.estado(eid)
    assert sdp.protocolo(eid) == 2 and est["cursor"] == 0 and est["releyendo"] is True and est["carga"] == "pendiente"
    assert est["epoca"] and len(est["epoca"]) >= 4
    assert web.llamadas[0][1]["ops"] == [] and web.llamadas[0][1]["desde"] == 0


# ---------------------------------------------------------------------------------------------------------------- la cola
def test_anotar_alta_funde_cambios_y_se_anula_con_la_baja(web):
    eid = _empresa()
    assert _anotar(eid, str(T * R + 1), None, {"id": T * R + 1, "nombre": "Postres"})
    ops = _ops(eid)
    assert len(ops) == 1 and ops[0]["op"] == "alta" and ops[0]["n"] == 1 and ops[0]["base_v"] == 0 and ops[0]["estado"] == "abierta"
    assert ops[0]["autora"] == f"{T}.{sdp.estado(eid)['epoca']}"
    assert _anotar(eid, str(T * R + 1), {"id": T * R + 1, "nombre": "Postres"}, {"id": T * R + 1, "nombre": "Postres caseros"})
    ops = _ops(eid)
    assert len(ops) == 1 and ops[0]["op"] == "alta" and json.loads(ops[0]["datos"])["fila"]["nombre"] == "Postres caseros"
    assert _anotar(eid, str(T * R + 1), {"id": T * R + 1, "nombre": "Postres caseros"}, None)
    assert _ops(eid) == []                               # alta y baja antes de salir: no sube nada


def test_anotar_cambio_conserva_el_primer_antes_y_vuelve_a_cero(web):
    eid = _empresa()
    _poner_cat(eid, 7, {"id": 7, "nombre": "A", "color": "rojo"})
    _aplicar(eid, _fila(7, 70, {"id": 7, "nombre": "A", "color": "rojo"}))
    _anotar(eid, "7", {"id": 7, "nombre": "A", "color": "rojo"}, {"id": 7, "nombre": "B", "color": "rojo"})
    op = _ops(eid)[0]
    d = json.loads(op["datos"])
    assert op["op"] == "cambio" and op["base_v"] == 70 and list(d["campos"]) == ["nombre"]
    assert d["campos"]["nombre"][:2] == [["A"], ["B"]] and "T" in d["campos"]["nombre"][2]
    _anotar(eid, "7", {"id": 7, "nombre": "B", "color": "rojo"}, {"id": 7, "nombre": "C", "color": "azul"})
    d = json.loads(_ops(eid)[0]["datos"])
    assert len(_ops(eid)) == 1 and d["campos"]["nombre"][:2] == [["A"], ["C"]] and d["campos"]["color"][:2] == [["rojo"], ["azul"]]
    _anotar(eid, "7", {"id": 7, "nombre": "C", "color": "azul"}, {"id": 7, "nombre": "A", "color": "rojo"})
    assert _ops(eid) == []                               # volvió a lo de antes: nada que subir


def test_fundir_conjuntos_agregar_y_quitar_se_anulan():
    d1 = {"campos": {}, "conjuntos": {"codigos_alternos": {"mas": ["B2"], "menos": ["X"]}}}
    d2 = {"campos": {}, "conjuntos": {"codigos_alternos": {"mas": ["X", "C3"], "menos": ["B2"]}}}
    assert sdp._fundir_cambios(d1, d2) == {"campos": {}, "conjuntos": {"codigos_alternos": {"mas": ["C3"], "menos": []}}}


def test_una_op_enviada_no_cambia_y_lo_siguiente_abre_otra(web):
    eid = _empresa()
    _poner_cat(eid, 7, {"id": 7, "nombre": "A"})
    _anotar(eid, "7", {"id": 7, "nombre": "A"}, {"id": 7, "nombre": "B"})
    autora = _ops(eid)[0]["autora"]
    enviadas = sdp._tomar_ops(eid, autora)
    assert [o["n"] for o in enviadas] == [1] and _ops(eid)[0]["estado"] == "enviada"
    antes = _ops(eid)[0]["datos"]
    _anotar(eid, "7", {"id": 7, "nombre": "B"}, {"id": 7, "nombre": "C"})
    ops = _ops(eid)
    assert len(ops) == 2 and ops[0]["datos"] == antes and ops[1]["estado"] == "abierta" and ops[1]["n"] == 2
    assert json.loads(ops[1]["datos"])["campos"]["nombre"][:2] == [["B"], ["C"]]


@pytest.fixture
def decl_prueba():
    """Declaraciones de prueba de las otras dos formas de escribir (se quitan al terminar: no quedan en DATOS para otras pruebas)."""
    llamadas = {"gancho": [], "responder": []}

    def gancho(s, eid, fila):
        llamadas["gancho"].append(fila["ref"])
        return llamadas["responder"].pop(0) if llamadas["responder"] else True

    nuevos = [sd.declarar(sd.Dato("zz_prueba_cuenta", registro="zz_prueba_cuentas", escribe="dueno", dueno_de="rango", viaja="sube",
                                  filtro=lambda c: bool(c.get("pedido_id")))),
              sd.declarar(sd.Dato("zz_prueba_web", modelo=Cliente, escribe="web", viaja="baja", copia_local=True, locales=("comentarios",),
                                  no_viajan=("correo_cc",), al_aplicar=gancho)),
              sd.declarar(sd.Dato("zz_prueba_baja", registro="zz_prueba_bajan", escribe="todos", viaja="baja"))]
    yield llamadas
    for d in nuevos:
        sd.DATOS.pop(d.tipo, None)
    getattr(sd, "_vigilados", {}).clear()                # el filtro rápido del oyente se rehace sin ellas


def test_anotar_respeta_aplicando_y_las_tres_formas(web, decl_prueba):
    eid = _empresa()
    with Session(engine_empresa(eid)) as s, diario.aplicando(0):
        assert sdp.anotar(s, eid, "categoria", "8", None, {"id": 8, "nombre": "X"}) is False          # lo que llegó de afuera no vuelve
    with Session(engine_empresa(eid)) as s:
        assert sdp.anotar(s, eid, "zz_prueba_web", "5", None, {"id": 5, "nombre": "Ana"}) is False        # escribe="web": nunca sube
        assert sdp.anotar(s, eid, "zz_prueba_baja", "5", None, {"id": 5}) is False                        # viaja="baja": nunca sube
        ajena = str(4 * R + 5)
        assert sdp.anotar(s, eid, "zz_prueba_cuenta", ajena, None, {"id": int(ajena), "pedido_id": 9}) is False   # otro rango: nunca
        mia = str(T * R + 5)
        assert sdp.anotar(s, eid, "zz_prueba_cuenta", mia, None, {"id": int(mia), "mesa": 2}) is False             # no pasa el filtro
        with diario.aplicando(4):                                                                               # dueño: también dentro de aplicando
            assert sdp.anotar(s, eid, "zz_prueba_cuenta", mia, None, {"id": int(mia), "pedido_id": 9}) is True
        assert sdp.anotar(s, eid, "zz_prueba_cuenta", mia, {"id": int(mia), "pedido_id": 9}, None) is True
        s.commit()
    ops = _ops(eid)
    assert len(ops) == 1 and ops[0]["op"] == "copia" and json.loads(ops[0]["datos"]) == {"fila": None}


# ---------------------------------------------------------------------------------------------------------------- aplicar_canonico
def test_aplicar_canonico_solo_version_mayor_y_lapida_que_no_revive(web):
    eid = _empresa()
    assert _aplicar(eid, _fila(501, 10, {"id": 501, "nombre": "Bebidas"})) is True
    assert _cat(eid, 501) == {"id": 501, "nombre": "Bebidas"} and _linea(eid, "categoria", 501)["v"] == 10
    assert _aplicar(eid, _fila(501, 10, {"id": 501, "nombre": "Otra"})) is False                  # I2: la misma versión no
    assert _aplicar(eid, _fila(501, 9, {"id": 501, "nombre": "Vieja"})) is False                  # ni una menor
    assert _cat(eid, 501)["nombre"] == "Bebidas"
    with Session(engine_empresa(eid)) as s:
        version_antes = modulos._registro(s, eid, "categorias").version
    assert _aplicar(eid, _fila(501, 11, {"id": 501, "nombre": "Bebidas"})) is True                # igual: solo la versión
    with Session(engine_empresa(eid)) as s:
        assert modulos._registro(s, eid, "categorias").version == version_antes
    assert _linea(eid, "categoria", 501)["v"] == 11
    assert _aplicar(eid, _fila(501, 12, borrado=True)) is True
    assert _cat(eid, 501) is None and _linea(eid, "categoria", 501) == {"v": 12, "borrado": True, "huella": ""}
    assert _aplicar(eid, _fila(501, 11, {"id": 501, "nombre": "Bebidas"})) is False               # I7: una copia vieja no revive
    assert _cat(eid, 501) is None
    assert _ops(eid) == []                                                                         # nada de lo aplicado vuelve a la cola


def test_aplicar_canonico_no_vuelve_a_la_cola_aunque_se_confirme_fuera_de_aplicando(web):
    eid = _empresa()
    for f in (_fila(501, 10, {"id": 501, "nombre": "Bebidas"}), _fila(501, 11, {"id": 501, "nombre": "Bebidas frías"}), _fila(501, 12, borrado=True)):
        with Session(engine_empresa(eid)) as s:                      # quien llama confirma fuera de aplicando(0) (p. ej. una ruta de B4)
            assert sdp.aplicar_canonico(s, eid, f) is True
            s.commit()
        assert _ops(eid) == []                                       # después de cada una (un alta y su baja se anularían entre sí)


def test_aplicar_canonico_no_pisa_un_grupo_con_op_pendiente(web):
    eid = _empresa()
    _aplicar(eid, _fila(7, 10, {"id": 7, "nombre": "A", "color": "rojo"}))
    _poner_cat(eid, 7, {"id": 7, "nombre": "Mío", "color": "rojo"})
    _anotar(eid, "7", {"id": 7, "nombre": "A", "color": "rojo"}, {"id": 7, "nombre": "Mío", "color": "rojo"})
    assert _aplicar(eid, _fila(7, 11, {"id": 7, "nombre": "De la web", "color": "azul"})) is True
    assert _cat(eid, 7) == {"id": 7, "nombre": "Mío", "color": "azul"}                             # I3: el nombre espera su veredicto
    sdp._tomar_ops(eid, _ops(eid)[0]["autora"])                                                     # ya salió: sigue retenido
    _aplicar(eid, _fila(7, 12, {"id": 7, "nombre": "Otra vez", "color": "verde"}))
    assert _cat(eid, 7) == {"id": 7, "nombre": "Mío", "color": "verde"}


def test_aplicar_canonico_alta_pendiente_no_se_toca(web):
    eid = _empresa()
    ref = T * R + 9
    _poner_cat(eid, ref, {"id": ref, "nombre": "Nueva"})
    _anotar(eid, str(ref), None, {"id": ref, "nombre": "Nueva"})
    _aplicar(eid, _fila(ref, 20, {"id": ref, "nombre": "Otra"}))
    assert _cat(eid, ref)["nombre"] == "Nueva"


def test_relectura_anota_lo_que_la_web_reemplaza(web):
    eid = _empresa()
    _poner_cat(eid, 7, {"id": 7, "nombre": "Local", "color": "rojo"})
    _aplicar(eid, _fila(7, 10, {"id": 7, "nombre": "Web", "color": "rojo"}), motivo_pisado="programa_anterior")
    assert _cat(eid, 7)["nombre"] == "Web"
    p = _pisados(eid)
    assert len(p) == 1 and p[0]["motivo"] == "programa_anterior" and p[0]["campo"] == "nombre" and json.loads(p[0]["perdio"]) == ["Local"]


# ---------------------------------------------------------------------------------------------------------------- la ida y vuelta
def test_categoria_de_punta_a_punta(web):
    eid = _empresa()
    # creada en la web → llega aquí
    web.cambiar("categoria", "501", {"id": 501, "nombre": "Bebidas"})
    sdp.ciclo(eid)
    assert _cat(eid, 501) == {"id": 501, "nombre": "Bebidas"} and sdp.estado(eid)["cursor"] == web.v
    cuerpo = web.llamadas[-1][1]
    assert cuerpo["protocolo"] == 2 and cuerpo["autora"] == f"{T}.{sdp.estado(eid)['epoca']}" and cuerpo["estacion_viva"] is False
    # creada aquí → sube
    mia = T * R + 1
    _poner_cat(eid, mia, {"id": mia, "nombre": "Postres"})
    _anotar(eid, str(mia), None, {"id": mia, "nombre": "Postres"})
    sdp.marcar_estacion(eid)
    sdp.ciclo(eid)
    assert web.llamadas[-1][1]["estacion_viva"] is True
    assert [o["op"] for o in web.ops_de(-1)] == ["alta"] and web.datos[("categoria", str(mia))] == {"id": mia, "nombre": "Postres"}
    assert _ops(eid)[0]["estado"] == "hecha" and _linea(eid, "categoria", mia)["v"] == web.v
    # eliminada en la web → desaparece aquí
    web.cambiar("categoria", "501", borrado=True)
    sdp.ciclo(eid)
    assert _cat(eid, 501) is None
    # eliminada aquí → desaparece en la web
    _poner_cat(eid, mia, None)
    _anotar(eid, str(mia), {"id": mia, "nombre": "Postres"}, None)
    sdp.ciclo(eid)
    assert web.datos[("categoria", str(mia))] is None and _linea(eid, "categoria", mia)["borrado"] is True
    assert all(o["estado"] == "hecha" for o in _ops(eid))


def test_primero_un_goteo_puro_hasta_saber_los_numeros_de_la_web(web):
    eid = _empresa()
    _poner_cat(eid, T * R + 1, {"id": T * R + 1, "nombre": "X"})
    _anotar(eid, str(T * R + 1), None, {"id": T * R + 1, "nombre": "X"})
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_MINIMO                     # queda algo en la cola: vuelve enseguida
    assert web.ops_de(0) == [] and len(web.ops_de(1) if len(web.llamadas) > 1 else []) == 0
    sdp.ciclo(eid)
    assert [o["n"] for o in web.ops_de(1)] == [1]


def test_siguiente_en_y_mas(web):
    eid = _empresa()
    web.siguiente_en = 7
    assert sdp.ciclo(eid) == 7
    web.cambiar("categoria", "1", {"id": 1, "nombre": "a"}); web.cambiar("categoria", "2", {"id": 2, "nombre": "b"})
    web.tope = 1
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_MINIMO and _cat(eid, 1) and not _cat(eid, 2)
    assert sdp.ciclo(eid) == 7 and _cat(eid, 2)
    web.siguiente_en = 0
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_MINIMO                     # nunca menos de 2 s


def test_conflicto_y_rechazo_dejan_lo_de_la_web_y_lo_perdido_anotado(web):
    eid = _empresa()
    web.cambiar("categoria", "7", {"id": 7, "nombre": "A"})
    sdp.ciclo(eid)
    _poner_cat(eid, 7, {"id": 7, "nombre": "Mío"})
    _anotar(eid, "7", {"id": 7, "nombre": "A"}, {"id": 7, "nombre": "Mío"})

    def conflicto(op):
        f = web.cambiar("categoria", "7", {"id": 7, "nombre": "De la web"})
        return {"estado": "fusionado", "v": f["v"], "canonico": {"id": 7, "nombre": "De la web"},
                "pisados": [{"campo": "nombre", "motivo": "conflicto", "perdio": ["Mío"]}]}
    web.veredicto = conflicto
    sdp.ciclo(eid)
    assert _cat(eid, 7)["nombre"] == "De la web"
    assert [(p["motivo"], p["campo"], json.loads(p["perdio"])) for p in _pisados(eid)] == [("conflicto", "nombre", ["Mío"])]
    # una baja frenada en la web: el elemento vuelve aquí
    _poner_cat(eid, 7, None)
    _anotar(eid, "7", {"id": 7, "nombre": "De la web"}, None)
    web.veredicto = lambda op: {"estado": "rechazado", "motivo": "freno", "canonico": {"id": 7, "nombre": "De la web"}}
    sdp.ciclo(eid)
    assert _cat(eid, 7) == {"id": 7, "nombre": "De la web"}
    assert _ops(eid)[-1]["estado"] == "rechazada" and _pisados(eid)[-1]["motivo"] == "freno"
    # un alta rechazada (p. ej. una caja creada aquí) se quita: la web no la tiene
    nueva = T * R + 4
    _poner_cat(eid, nueva, {"id": nueva, "nombre": "No vale"})
    _anotar(eid, str(nueva), None, {"id": nueva, "nombre": "No vale"})
    web.veredicto = lambda op: {"estado": "rechazado", "motivo": "no_valido"}
    sdp.ciclo(eid)
    assert _cat(eid, nueva) is None and _pisados(eid)[-1]["motivo"] == "no_valido"


def test_renumerar_cambia_el_id_aqui(web):
    eid = _empresa()
    vieja, nueva = T * R + 2, T * R + 50
    _poner_cat(eid, vieja, {"id": vieja, "nombre": "Promo"})
    _anotar(eid, str(vieja), None, {"id": vieja, "nombre": "Promo"})
    sdp.ciclo(eid)

    def renumera(op):
        f = web.cambiar("categoria", str(nueva), {"id": nueva, "nombre": "Promo"})
        return {"estado": "renumerar", "v": f["v"], "ref": str(nueva), "canonico": {"id": nueva, "nombre": "Promo"}}
    web.veredicto = renumera
    sdp.ciclo(eid)
    assert _cat(eid, vieja) is None and _cat(eid, nueva) == {"id": nueva, "nombre": "Promo"}


def test_sin_internet_la_op_sale_igual_despues_y_un_reenvio_es_repetido(web):
    eid = _empresa()
    sdp.ciclo(eid)                                                   # ya sabe los números de la web
    _poner_cat(eid, T * R + 1, {"id": T * R + 1, "nombre": "X"})
    _anotar(eid, str(T * R + 1), None, {"id": T * R + 1, "nombre": "X"})
    web.forzar = httpx.ConnectError("sin red")
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_SIN_CONEXION
    assert sdp.estado(eid)["sin_conexion_desde"] and _ops(eid)[0]["estado"] == "enviada"
    enviado = web.ops_de(-1)
    web.forzar = None
    web.antes_de_contestar = httpx.ReadTimeout("lento")             # la web la aplicó y la respuesta se perdió
    sdp.ciclo(eid)
    assert _ops(eid)[0]["estado"] == "enviada" and web.ops_de(-1) == enviado
    v_web = web.v
    sdp.ciclo(eid)
    assert web.ops_de(-1) == enviado and web.v == v_web               # idéntica, misma n: «repetido», no se aplica dos veces
    assert _ops(eid)[0]["estado"] == "hecha" and sdp.estado(eid)["sin_conexion_desde"] is None


@pytest.mark.parametrize("codigo", [404, 405])
def test_pausa_unica_con_404_o_405_y_sigue_encolando(web, monkeypatch, codigo):
    eid = _empresa()
    sdp.ciclo(eid)
    web.forzar = _Respuesta(codigo, {"detail": "Not Found"} if codigo == 404 else None)
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_PAUSA
    assert sdp.en_pausa(eid) and sdp.protocolo(eid) == 2
    _poner_cat(eid, T * R + 1, {"id": T * R + 1, "nombre": "En pausa"})
    assert _anotar(eid, str(T * R + 1), None, {"id": T * R + 1, "nombre": "En pausa"}) is True    # en pausa se guarda aquí y se encola
    n = len(web.llamadas)
    assert sdp.ciclo(eid) > 0 and len(web.llamadas) == n           # no vuelve a probar antes de tiempo
    web.forzar = None
    monkeypatch.setitem(sdp._ultimo_intento_pausa, eid, -1e9)       # pasó el tiempo de la pausa
    sdp.ciclo(eid)
    assert not sdp.en_pausa(eid) and web.datos.get(("categoria", str(T * R + 1))) == {"id": T * R + 1, "nombre": "En pausa"}


def test_pausa_por_la_senal_del_catalogo(web):
    eid = _empresa()
    sdp.senal_catalogo(eid, None)
    assert sdp.en_pausa(eid)
    sdp.ciclo(eid)                                                   # contesta 200, pero el catálogo dijo que no: sigue en pausa
    assert sdp.en_pausa(eid)
    sdp.senal_catalogo(eid, True)
    sdp._ultimo_intento_pausa[eid] = -1e9
    sdp.ciclo(eid)
    assert not sdp.en_pausa(eid)


def test_respaldo_restaurado_aqui_estrena_epoca(web):
    eid = _empresa()
    autora_vieja = f"{T}.{sdp.estado(eid)['epoca']}"
    for n in range(1, 6):                                            # la web ya vio 5 ops de esta autora; el respaldo no las tiene
        web.recibidas[(autora_vieja, n)] = {"n": n, "estado": "aplicado", "motivo": None, "v": 1, "ref": "1", "canonico": None, "pisados": []}
    for i in (1, 2):
        ref = T * R + i
        _poner_cat(eid, ref, {"id": ref, "nombre": f"Nueva {i}"})
        _anotar(eid, str(ref), None, {"id": ref, "nombre": f"Nueva {i}"})
    assert [o["n"] for o in _ops(eid)] == [1, 2]
    sdp.ciclo(eid)                                                   # goteo puro: aprende n_max=5 y estrena época
    ops = _ops(eid)
    assert ops[0]["autora"] != autora_vieja and [o["n"] for o in ops] == [1, 2] and sdp.estado(eid)["epoca"] in ops[0]["autora"]
    sdp.ciclo(eid)
    assert web.datos.get(("categoria", str(T * R + 1))) == {"id": T * R + 1, "nombre": "Nueva 1"}   # se aplicaron: no «repetido»
    assert all(o["estado"] == "hecha" for o in _ops(eid))


def test_una_op_que_quedo_con_otra_autora_sale_con_la_actual(web):
    eid = _empresa()
    sdp.ciclo(eid)
    ref = T * R + 1
    _poner_cat(eid, ref, {"id": ref, "nombre": "Entre épocas"})
    _anotar(eid, str(ref), None, {"id": ref, "nombre": "Entre épocas"})
    sdp._guardar_estado(eid, epoca="otra1")                          # se estrenó una época justo después de anotarla
    sdp.ciclo(eid)                                                   # autora nueva: primero un goteo puro
    sdp.ciclo(eid)
    assert web.datos.get(("categoria", str(ref))) == {"id": ref, "nombre": "Entre épocas"}
    assert _ops(eid)[0]["autora"] == f"{T}.otra1" and _ops(eid)[0]["estado"] == "hecha"


def test_respaldo_restaurado_en_la_web_relee_desde_cero(web):
    eid = _empresa()
    web.cambiar("categoria", "7", {"id": 7, "nombre": "A"})
    sdp.ciclo(eid)
    _poner_cat(eid, 7, {"id": 7, "nombre": "Cambiado aquí y perdido allá"})
    with Session(engine_empresa(eid)) as s:                          # simula que el cambio local ya subió (sin op pendiente)
        s.connection().execute(sdp._sql("UPDATE sinc_dato SET v = 5000 WHERE tipo = 'categoria' AND ref = '7'")); s.commit()
    web.epoca = "web2"
    web.v = 10                                                       # la web volvió atrás: versiones menores que las de aquí
    web.log = []
    web.cambiar("categoria", "7", {"id": 7, "nombre": "A"})
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_MINIMO
    est = sdp.estado(eid)
    assert est["cursor"] == 0 and est["epoca_web"] == "web2" and est["releyendo"] is True and _linea(eid, "categoria", 7)["v"] == 0
    sdp.ciclo(eid)
    assert _cat(eid, 7)["nombre"] == "A" and sdp.estado(eid)["releyendo"] is False
    assert [(p["motivo"], p["campo"]) for p in _pisados(eid)] == [("programa_anterior", "nombre")]


# ---------------------------------------------------------------------------------------------------------------- copia local, ganchos y acciones
def test_copia_local_no_pisa_locales_y_el_gancho_se_reintenta(web, decl_prueba):
    eid = _empresa()
    decl_prueba["responder"].extend([False, True])
    web.cambiar("zz_prueba_web", "777", {"id": 777, "nombre": "Ana", "numero_id": "1", "comentarios": "de la web", "correo_cc": "x@example.test"})
    sdp.ciclo(eid)
    with Session(engine_empresa(eid)) as s:
        c = s.get(Cliente, 777)
        assert c.nombre == "Ana" and c.comentarios is None and c.correo_cc is None
        c.comentarios = "nota de esta caja"; s.add(c); s.commit()
    assert decl_prueba["gancho"] == ["777"] and ("zz_prueba_web", "777") in sdp._reintentar[eid]
    web.cambiar("zz_prueba_web", "777", {"id": 777, "nombre": "Ana María", "numero_id": "1"})
    sdp.ciclo(eid)
    with Session(engine_empresa(eid)) as s:
        c = s.get(Cliente, 777)
        assert c.nombre == "Ana María" and c.comentarios == "nota de esta caja"
    assert decl_prueba["gancho"][:2] == ["777", "777"] and not sdp._reintentar[eid]
    web.cambiar("zz_prueba_web", "777", borrado=True)                    # dejó de pasar el filtro en la web: se quita la copia
    sdp.ciclo(eid)
    with Session(engine_empresa(eid)) as s:
        assert s.get(Cliente, 777) is None
    assert _ops(eid) == []


def test_pedir_accion(web, decl_prueba):
    eid = _empresa()
    web.accion = lambda cuerpo: _Respuesta(200, {"resultado": {"ok": True, "eco": cuerpo["accion"]},
                                                 "filas": [{"tipo": "zz_prueba_web", "ref": "45", "v": 2000, "dueno": None, "borrado": False, "origen": 0,
                                                            "campos": {}, "datos": {"id": 45, "nombre": "Pedido", "numero_id": "9"}}]})
    j = sdp.pedir_accion(eid, "zz_prueba_web", "45", "aceptar", {"reclama": True}, "Caja 1 · Ana")
    assert j["resultado"] == {"ok": True, "eco": "aceptar"} and decl_prueba["gancho"] == ["45"]
    with Session(engine_empresa(eid)) as s:
        assert s.get(Cliente, 45).nombre == "Pedido"
    assert web.llamadas[-1] == (sdp.RUTA_ACCION, {"tipo": "zz_prueba_web", "ref": "45", "accion": "aceptar", "datos": {"reclama": True}, "por": "Caja 1 · Ana"})
    web.accion = lambda cuerpo: _Respuesta(409, {"detail": "Otro equipo ya aceptó este pedido."})
    with pytest.raises(HTTPException) as ex:
        sdp.pedir_accion(eid, "zz_prueba_web", "45", "aceptar")
    assert ex.value.status_code == 409 and ex.value.detail == "Otro equipo ya aceptó este pedido."
    for respuesta in (_Respuesta(404, {"detail": "Not Found"}), _Respuesta(405), _Respuesta(503), _Respuesta(401, {"detail": {"codigo": "x"}})):
        web.accion = lambda cuerpo, r=respuesta: r
        with pytest.raises(sdp.SinConexionWeb):
            sdp.pedir_accion(eid, "zz_prueba_web", "45", "aceptar")
    web.forzar = httpx.ConnectError("sin red")
    with pytest.raises(sdp.SinConexionWeb):
        sdp.pedir_accion(eid, "zz_prueba_web", "45", "aceptar")
    web.forzar = httpx.ReadTimeout("lento")
    with pytest.raises(sdp.SinRespuestaWeb):
        sdp.pedir_accion(eid, "zz_prueba_web", "45", "aceptar")


def test_nada_secreto_va_al_registro(web, caplog):
    eid = _empresa()
    caplog.set_level(logging.DEBUG)
    web.forzar = httpx.ConnectError(f"conexión rechazada {TOKEN}")
    sdp.ciclo(eid)
    web.forzar = _Respuesta(500, {"detail": f"error con {TOKEN}"})
    sdp.ciclo(eid)
    web.forzar = None
    web.accion = lambda cuerpo: _Respuesta(422, {"detail": [{"input": TOKEN}]})
    with pytest.raises(sdp.SinConexionWeb):
        sdp.pedir_accion(eid, "categoria", "1", "x")
    assert TOKEN not in caplog.text
    assert TOKEN not in json.dumps(sdp.estado(eid))


def test_salta_en_bajar_solo_lo_declarado_con_el_protocolo_2(web):
    eid = _empresa()
    assert sdp.salta_en_bajar(eid, "categorias") is True
    assert sdp.salta_en_bajar(eid, "monedas") is False
    assert "categorias" in sdp.claves_declaradas()


def test_el_hilo_no_corre_fuera_del_programa(monkeypatch):
    monkeypatch.setattr(sdp, "_hilo", False)
    monkeypatch.setattr(sinc, "MODO_LOCAL", False)
    sdp.iniciar_hilo()
    assert sdp._hilo is False
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    monkeypatch.setenv("FE_SINC_HILO", "0")
    sdp.iniciar_hilo()
    assert sdp._hilo is False


def test_purgar_conserva_el_numero_de_cada_autora(web):
    eid = _empresa()
    sdp.ciclo(eid)
    for i in (1, 2, 3):
        ref = T * R + i
        _poner_cat(eid, ref, {"id": ref, "nombre": str(i)})
        _anotar(eid, str(ref), None, {"id": ref, "nombre": str(i)})
    sdp.ciclo(eid)
    with Session(engine_empresa(eid)) as s:
        s.connection().execute(sdp._sql("UPDATE sinc_cambio SET creado = '2020-01-01T00:00:00+00:00'")); s.commit()
    sdp.purgar(eid)
    assert [o["n"] for o in _ops(eid)] == [3]
    _poner_cat(eid, T * R + 9, {"id": T * R + 9, "nombre": "9"})
    _anotar(eid, str(T * R + 9), None, {"id": T * R + 9, "nombre": "9"})
    assert _ops(eid)[-1]["n"] == 4


# ================================================================================================================ B3: el programa completo
from app import respaldo  # noqa: E402
from app.db import Documento, DocumentoLinea, Producto  # noqa: E402


@pytest.fixture
def decl_catalogo():
    """«producto», «cliente» e «impresora» como en el contrato §1.5 si el bloque B2 todavía no los declaró (se quitan al terminar)."""
    nuevos = []
    if sd.dato("producto") is None:
        nuevos.append(sd.declarar(sd.Dato("producto", modelo=Producto, escribe="todos", viaja="dos", permiso="productos")))
    if sd.dato("cliente") is None:
        nuevos.append(sd.declarar(sd.Dato("cliente", modelo=Cliente, escribe="todos", viaja="dos", permiso="clientes")))
    if sd.dato("impresora") is None:
        nuevos.append(sd.declarar(sd.Dato("impresora", registro="pos_impresoras", escribe="todos", viaja="dos", permiso="pos")))
    yield
    for d in nuevos:
        sd.DATOS.pop(d.tipo, None)
    getattr(sd, "_vigilados", {}).clear()


class _Viejo:
    """httpx de app/sinc.py (los caminos 4.31): anota lo que se manda y contesta con `respuestas[ruta]`."""
    Timeout = httpx.Timeout

    def __init__(self, respuestas=None, falla=None):
        self.llamadas, self.respuestas, self.falla = [], respuestas or {}, falla

    def post(self, url, headers=None, json=None, timeout=None):  # noqa: A002
        if self.falla is not None:
            raise self.falla
        ruta = url[len(NUBE):]
        self.llamadas.append(("POST", ruta, copy.deepcopy(json)))
        return _Respuesta(200, self.respuestas.get(ruta, {}))

    def get(self, url, headers=None, timeout=None):
        if self.falla is not None:
            raise self.falla
        ruta = url[len(NUBE):].split("?")[0]
        self.llamadas.append(("GET", ruta, None))
        return _Respuesta(200, self.respuestas.get(ruta, {}))


def _producto(eid, nombre="Té frío", **extra):
    with Session(engine_empresa(eid)) as s:
        p = Producto(empresa_id=eid, nombre=nombre, cabys="2202100000000", precio=1000, **extra)
        s.add(p); s.commit(); s.refresh(p)
        return p.id


def _venta(eid, pid, cliente_id=None, n=1):
    clave = "506081126" + "003101049023" + f"001000020400000{n:05d}" + "1" + f"{n:08d}"
    with Session(engine_empresa(eid)) as s:
        d = Documento(empresa_id=eid, tipo_documento="04", clave=clave, consecutivo=f"001000020400000{n:05d}", fecha_emision="2026-11-08T10:00:00-06:00",
                      moneda="CRC", tipo_cambio=1, total=1130, impuesto=130, estado="interno", ambiente="produccion", condicion_venta="01", cliente_id=cliente_id)
        s.add(d); s.commit(); s.refresh(d)
        s.add(DocumentoLinea(documento_id=d.id, numero=1, producto_id=pid, cabys="2202100000000", detalle="Té", cantidad=1, unidad_medida="Unid",
                             precio_unitario=1000, descuento=0, codigo_tarifa="08", tarifa=13, impuesto=130, total=1130))
        s.commit()
        return clave


def _cfg(eid, **cambios):
    with Session(engine_empresa(eid)) as s:
        cfg = sinc._cfg_local(s, eid)
        cfg.update(cambios)
        sinc._escribir(s, eid, sinc.CLAVE_LOCAL, cfg); s.commit()
        return cfg


# ---------------------------------------------------------------------------------------------------------------- saltos de sinc.py
def test_rango_web_e_impresoras_con_el_protocolo_2(web, decl_catalogo):
    eid, eid0 = _empresa(), _empresa(protocolo2=False)
    for e in (eid, eid0):
        _cfg(e, impresoras_web=True)
    assert sinc.rango_web(eid0) == T and sinc.va_a_la_web(eid0, 5) is True                 # 4.31: lo ajeno va a la web en vivo
    assert sinc.rango_web(eid) is None and sinc.va_a_la_web(eid, 5) is False               # 4.32: se guarda aquí y sube por la cola
    assert sinc.separar_ajenos(eid, [5, T * R + 1]) == ([5, T * R + 1], [])
    with Session(engine_empresa(eid)) as s, Session(engine_empresa(eid0)) as s0:
        assert sinc.impresoras_de_la_web(s0, eid0) is True and sinc.impresoras_de_la_web(s, eid) is False


def test_rango_web_sin_declarar_los_items_sigue_como_la_431(web):
    eid = _empresa()
    if sd.dato("producto") is None:
        assert sinc.rango_web(eid) == T                                                     # el canal todavía no lleva ítems: nada cambia


def test_subir_catalogos_apagado_con_el_protocolo_2(web, decl_catalogo, monkeypatch):
    eid, eid0 = _empresa(), _empresa(protocolo2=False)
    viejo = _Viejo({"/api/sinc/cambios": {"clientes": 0, "productos": 1}})
    monkeypatch.setattr(sinc, "httpx", viejo)
    for e in (eid, eid0):
        _producto(e)
    for e in (eid, eid0):
        with Session(engine_empresa(e)) as s:
            cfg = sinc._cfg_local(s, e)
            sinc._subir_catalogos(s, e, cfg, NUBE, {"Authorization": "x"}, T)
    assert len(viejo.llamadas) == 1 and len(viejo.llamadas[0][2]["productos"]) == 1        # solo la de protocolo 0


def test_carga_inicial_paso_1_sube_por_el_camino_viejo_antes_de_cambiar(web, decl_catalogo, monkeypatch):
    eid = _empresa(protocolo2=False)
    pid = _producto(eid, "Hecho antes de la 4.32")
    viejo = _Viejo(falla=httpx.ConnectError("sin red"))
    monkeypatch.setattr(sinc, "httpx", viejo)
    assert sdp.ciclo(eid) == sdp.SEGUNDOS_SIN_CONEXION and sdp.protocolo(eid) == 0          # sin la última subida no se cambia
    viejo.falla = None
    viejo.respuestas = {"/api/sinc/cambios": {"clientes": 0, "productos": 1}}
    sdp.ciclo(eid)
    assert [c[1] for c in viejo.llamadas] == ["/api/sinc/cambios"] and [p["id"] for p in viejo.llamadas[0][2]["productos"]] == [pid]
    est = sdp.estado(eid)
    assert sdp.protocolo(eid) == 2 and est["carga"] == "pendiente" and est["releyendo"] is True and est["cursor"] == 0


# ---------------------------------------------------------------------------------------------------------------- retención de comprobantes
def test_comprobante_con_alta_pendiente_espera(web, decl_catalogo, monkeypatch):
    eid = _empresa()
    sdp.ciclo(eid)                                                                          # aprende los números de la web
    pid = _producto(eid)                                                                    # el oyente la encola como alta
    assert [(o["tipo"], o["op"]) for o in _ops(eid)] == [("producto", "alta")]
    clave = _venta(eid, pid)
    viejo = _Viejo({"/api/sinc/documentos": {"recibidos": [clave]}})
    monkeypatch.setattr(sinc, "httpx", viejo)
    with Session(engine_empresa(eid)) as s:
        assert sinc._subir_documentos(s, eid, sinc._cfg_local(s, eid), NUBE, {}) == 0      # espera: el ítem todavía no está en la web
    assert viejo.llamadas == [] and sdp.en_espera(eid) == {"cambios": 1, "ventas": 1, "pausa": False}
    sdp.ciclo(eid)                                                                          # el alta sube y recibe veredicto
    assert web.datos.get(("producto", str(pid))) and _ops(eid)[0]["estado"] == "hecha"
    with Session(engine_empresa(eid)) as s:
        assert sinc._subir_documentos(s, eid, sinc._cfg_local(s, eid), NUBE, {}) == 1      # ahora sí, después de su ítem
    assert [d["clave"] for d in viejo.llamadas[0][2]["documentos"]] == [clave]


def test_retencion_por_cliente_por_receta_y_por_gancho(web, decl_catalogo, monkeypatch):
    eid = _empresa()
    eid0 = _empresa(protocolo2=False)
    for e in (eid, eid0):
        _venta(e, 9001, n=1)
        _venta(e, 9002, cliente_id=7001, n=2)
    monkeypatch.setattr(sdp, "_retenciones", [])
    monkeypatch.setattr(sdp.importlib.import_module("app.inventario"), "recetas", lambda s, e: {9001: {"ingredientes": [{"producto_id": 9500}]}})
    sdp.registrar_retencion(lambda s, e: {"producto": {9500}, "cliente": {"7001"}})
    for e, esperan in ((eid, 2), (eid0, 0)):                                                # sin protocolo: ninguno espera (como la 4.31)
        with Session(engine_empresa(e)) as s:
            docs = s.exec(sdp.select(Documento)).all()
            assert len(sdp.documentos_en_espera(s, e, docs)) == esperan
    sdp.registrar_retencion(lambda s, e: 1 / 0)                                             # un gancho que falla no detiene nada
    with Session(engine_empresa(eid)) as s:
        assert len(sdp.documentos_en_espera(s, eid, s.exec(sdp.select(Documento)).all())) == 2


# ---------------------------------------------------------------------------------------------------------------- carga inicial (pasos 2 y 4)
def _empresa_en_carga():
    eid = _empresa()
    sdp._guardar_estado(eid, carga="pendiente", releyendo=True, cursor=0)
    return eid


def test_carga_inicial_filas_del_rango_propio(web, monkeypatch):
    monkeypatch.setattr(sdp, "_pasos_carga", [])
    eid = _empresa_en_carga()
    a, b, c, d = (T * R + i for i in (1, 2, 3, 4))
    for ref, nombre in ((a, "Solo aquí"), (b, "Nombre de aquí"), (c, "Eliminada allá"), (d, "Ya en la web")):
        _poner_cat(eid, ref, {"id": ref, "nombre": nombre})
    _poner_cat(eid, 40, {"id": 40, "nombre": "Del rango de la web"})                        # el rango 0 es de la primera subida (B6)
    web.cambiar("categoria", str(d), {"id": d, "nombre": "Ya en la web"})                   # llega con el goteo desde 0
    web.filas_resp = {("categoria", str(b)): ("existe", 1500, {"id": b, "nombre": "Nombre de la web"}),
                      ("categoria", str(c)): ("borrado", 1501, None)}
    sdp.ciclo(eid)                                                                          # goteo desde 0 y, al terminar, /datos/filas
    preguntas = [x["ref"] for (ruta, cuerpo) in web.llamadas if ruta == sdp.RUTA_FILAS for x in cuerpo["refs"]]
    assert preguntas == [str(a), str(b), str(c)]                                            # ni lo que ya tiene versión ni el rango 0
    assert _cat(eid, b)["nombre"] == "Nombre de la web" and _cat(eid, c) is None and _linea(eid, "categoria", c)["borrado"]
    assert [(p["ref"], p["motivo"], p["campo"]) for p in _pisados(eid)] == [(str(b), "programa_anterior", "nombre")]
    assert [(o["ref"], o["op"]) for o in _ops(eid)] == [(str(a), "alta")] and sdp.estado(eid)["carga"] == "hecha"
    sdp.ciclo(eid); sdp.ciclo(eid)
    assert web.datos.get(("categoria", str(a))) == {"id": a, "nombre": "Solo aquí"}       # vuelve a la web con su mismo id


def test_carga_inicial_espera_si_la_web_no_tiene_filas_y_sigue_con_los_pasos_registrados(web, monkeypatch):
    eid = _empresa_en_carga()
    _poner_cat(eid, T * R + 1, {"id": T * R + 1, "nombre": "X"})
    web.filas_codigo = 404
    sdp.ciclo(eid)
    assert sdp.estado(eid)["carga"] == "filas"
    n = len(web.llamadas)
    sdp.ciclo(eid)
    assert not [r for r, _c in web.llamadas[n:] if r == sdp.RUTA_FILAS]                    # no insiste antes de SEGUNDOS_FILAS
    web.filas_codigo = 200
    monkeypatch.setitem(sdp._filas_despues, eid, 0.0)
    respuestas = [False, True]
    monkeypatch.setattr(sdp, "_pasos_carga", [])
    sdp.registrar_paso_carga(lambda e: respuestas.pop(0))
    sdp.ciclo(eid)
    assert sdp.estado(eid)["carga"] == "reenlace"
    sdp.ciclo(eid)
    assert sdp.estado(eid)["carga"] == "hecha"


def test_epoca_nueva_de_la_web_repite_filas_del_rango_propio(web):
    eid = _empresa()
    ref = T * R + 7
    _poner_cat(eid, ref, {"id": ref, "nombre": "Creada después del respaldo de la web"})
    with Session(engine_empresa(eid)) as s:                                                 # ya había subido antes del respaldo
        s.connection().execute(sdp._sql("INSERT INTO sinc_dato (tipo, ref, v, campos, origen, borrado, huella, cambiado) "
                                        "VALUES ('categoria', :r, 1200, '{}', 0, 0, '', '')"), {"r": str(ref)}); s.commit()
    sdp.ciclo(eid)
    web.epoca, web.log = "web2", []                                                         # la web volvió a un respaldo: ya no la tiene
    sdp.ciclo(eid)
    assert sdp.estado(eid)["filas_propias"] is True
    sdp.ciclo(eid)                                                                          # relee desde 0 y pregunta por lo propio
    assert sdp.estado(eid)["filas_propias"] is False and [(o["ref"], o["op"]) for o in _ops(eid)] == [(str(ref), "alta")]
    sdp.ciclo(eid)
    assert web.datos.get(("categoria", str(ref)))["nombre"] == "Creada después del respaldo de la web"


# ---------------------------------------------------------------------------------------------------------------- desfase y pausa
def test_desfase_de_reloj_queda_anotado(web, caplog):
    from datetime import datetime, timedelta, timezone
    eid = _empresa()
    web.hora = (datetime.now(timezone.utc) + timedelta(seconds=600)).isoformat()
    with caplog.at_level(logging.WARNING):
        sdp.ciclo(eid)
    assert 595 <= sdp.estado(eid)["desfase_s"] <= 605 and "difiere" in caplog.text
    cuerpo = web.llamadas[-1][1]
    assert datetime.fromisoformat(cuerpo["hora_local"]).tzinfo is not None                  # la web corrige cada op con esta hora


def test_en_pausa_el_bajar_viejo_respeta_lo_pendiente_y_las_lapidas(web, decl_catalogo, monkeypatch):
    eid = _empresa()
    mia, borrada, web_cat = T * R + 1, 30, 31
    _poner_cat(eid, mia, {"id": mia, "nombre": "Nueva aquí"})
    _anotar(eid, str(mia), None, {"id": mia, "nombre": "Nueva aquí"})                       # alta propia sin veredicto
    with Session(engine_empresa(eid)) as s:
        s.connection().execute(sdp._sql("INSERT INTO sinc_dato (tipo, ref, v, campos, origen, borrado, huella, cambiado) "
                                        "VALUES ('categoria', :r, 900, '{}', 0, 1, '', ''), ('producto', '77', 901, '{}', 0, 1, '', '')"),
                               {"r": str(borrada)}); s.commit()
    catalogo = {"empresa": {}, "registros": {"categorias": [{"id": borrada, "nombre": "Vieja"}, {"id": web_cat, "nombre": "De la web"}],
                                             "monedas": [{"codigo": "CRC"}]},
                "productos": [{"id": 77, "nombre": "Eliminado", "cabys": "1", "precio": 1}, {"id": 78, "nombre": "Nuevo web", "cabys": "1", "precio": 1}],
                "clientes": [], "datos_v2": False}
    monkeypatch.setattr(sinc, "httpx", _Viejo({"/api/sinc/catalogo": catalogo}))
    with Session(engine_empresa(eid)) as s, Session(engine) as sc:
        cfg = sinc._cfg_local(s, eid)
        sinc._bajar(s, sc, sc.get(auth.Empresa, eid), cfg, NUBE, {}, T)
    assert sdp.en_pausa(eid)                                                                # sin la señal datos_v2: pausa
    assert _cat(eid, web_cat) == {"id": web_cat, "nombre": "De la web"} and _cat(eid, borrada) is None
    assert _cat(eid, mia) == {"id": mia, "nombre": "Nueva aquí"}                            # lo propio pendiente no se pisa
    with Session(engine_empresa(eid)) as s:
        assert s.get(Producto, 78) is not None and s.get(Producto, 77) is None              # nada con lápida revive
    assert [(o["ref"], o["op"]) for o in _ops(eid)] == [(str(mia), "alta")]                 # lo bajado no volvió a la cola


def test_sin_pausa_el_bajar_viejo_no_toca_lo_del_canal(web, decl_catalogo, monkeypatch):
    eid = _empresa()
    catalogo = {"empresa": {}, "registros": {"categorias": [{"id": 31, "nombre": "De la web"}]},
                "productos": [{"id": 78, "nombre": "Nuevo web", "cabys": "1", "precio": 1}], "clientes": [], "datos_v2": True}
    monkeypatch.setattr(sinc, "httpx", _Viejo({"/api/sinc/catalogo": catalogo}))
    with Session(engine_empresa(eid)) as s, Session(engine) as sc:
        sinc._bajar(s, sc, sc.get(auth.Empresa, eid), sinc._cfg_local(s, eid), NUBE, {}, T)
        assert s.get(Producto, 78) is None and _cat(eid, 31) is None                        # lo trae el goteo
    assert not sdp.en_pausa(eid)


def test_novedades_no_revive_un_item_con_lapida(web, decl_catalogo, monkeypatch):
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        s.connection().execute(sdp._sql("INSERT INTO sinc_dato (tipo, ref, v, campos, origen, borrado, huella, cambiado) "
                                        "VALUES ('producto', '77', 901, '{}', 0, 1, '', '')")); s.commit()
    nov = {"productos": [{"id": 77, "nombre": "Eliminado", "cabys": "1", "precio": 1}, {"id": 78, "nombre": "Vendido", "cabys": "1", "precio": 1}],
           "clientes": [], "documentos": [], "cursor": 5, "mas": False}
    monkeypatch.setattr(sinc, "httpx", _Viejo({"/api/sinc/novedades": nov}))
    with Session(engine_empresa(eid)) as s:
        cfg = sinc._cfg_local(s, eid)
        sinc._bajar_novedades(s, eid, cfg, NUBE, {}, json.loads(json.dumps(cfg)))
        assert s.get(Producto, 78) is not None and s.get(Producto, 77) is None


def test_red_local_con_el_protocolo_2_solo_crea_lo_que_no_existe(web, decl_catalogo, monkeypatch):
    """Revisión n.º 31: con el protocolo 2 la red del local ya no actualiza ni desactiva ítems y clientes (eso lo trae la web), pero sí crea
    los que aquí no existen, sin encolarlos: la venta de esa computadora que llega en el mismo envío no queda sin ítem."""
    eid, eid0 = _empresa(), _empresa(protocolo2=False)
    cuerpo = {"terminal": 4, "nombre": "Caja 2", "productos": [{"id": 4 * R + 1, "nombre": "De la caja 2", "cabys": "1", "precio": 1}],
              "productos_vivos": [4 * R + 1]}
    for e, protocolo2 in ((eid, True), (eid0, False)):
        monkeypatch.setattr(sinc, "_autenticar_red", lambda request, numero_id, sc, e=e: e)
        antes = len(_ops(e)) if protocolo2 else 0
        out = sinc.red_cambios("x", None, copy.deepcopy(cuerpo), None)
        with Session(engine_empresa(e)) as s:
            assert s.get(Producto, 4 * R + 1) is not None and out["productos"] == 1
        if protocolo2:
            assert len(_ops(e)) == antes                                           # no entra a la cola: lo sube la computadora que lo creó
    cambio = {"terminal": 4, "nombre": "Caja 2", "productos": [{"id": 4 * R + 1, "nombre": "Otro nombre", "cabys": "1", "precio": 9}],
              "productos_vivos": []}
    monkeypatch.setattr(sinc, "_autenticar_red", lambda request, numero_id, sc: eid)
    out = sinc.red_cambios("x", None, copy.deepcopy(cambio), None)
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, 4 * R + 1)
        assert (p.nombre, p.activo, out["productos"]) == ("De la caja 2", True, 0)   # cambios y bajas: los trae el goteo de la web


# ---------------------------------------------------------------------------------------------------------------- respaldo
def test_respaldo_conserva_secuencias_y_estrena_epoca_en_la_web(monkeypatch):
    from app.db import EMPRESAS_DIR
    monkeypatch.setattr(sinc, "MODO_LOCAL", False)
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "B3 respaldo QA", f"b3resp-{random.randint(1, 10**9)}@example.test", "31012" + str(random.randint(10**4, 10**5 - 1)))
        eid = e.id
    _CREADAS.append(eid)
    pid = _producto(eid)
    with Session(engine_empresa(eid)) as s:
        epoca = sd.epoca(s, eid)
    previas = respaldo.leer_secuencias(EMPRESAS_DIR / f"empresa_{eid}.db")
    assert previas["seq"].get("producto") == pid
    previas["seq"]["producto"] = pid + 100
    previas["seq"]["sinc_dato"] = 5000
    previas["propio"] = [("producto", 0, pid + 100), ("cliente", 3, T * R + 50)]
    assert respaldo.conservar_secuencias(eid, previas) >= 3
    with Session(engine_empresa(eid)) as s:
        con = s.connection()
        assert con.execute(sdp._sql("SELECT seq FROM sqlite_sequence WHERE name = 'producto'")).scalar() == pid + 100
        assert con.execute(sdp._sql("SELECT seq FROM sqlite_sequence WHERE name = 'sinc_dato'")).scalar() == 5000
        assert con.execute(sdp._sql("SELECT ultimo FROM sinc_id_propio WHERE tabla = 'cliente' AND rango = 3")).scalar() == T * R + 50
        assert sd.epoca(s, eid) != epoca                                                     # los programas releen desde 0
    assert respaldo.conservar_secuencias(eid, {"seq": {"producto": 1}, "propio": [("producto", 0, 1)]}) == 0   # nunca baja
    assert _producto(eid) == pid + 101


def test_respaldo_en_el_programa_olvida_los_numeros_de_la_web(web):
    eid = _empresa()
    sdp.ciclo(eid)
    assert eid in sdp._n_web
    respaldo.conservar_secuencias(eid, {"seq": {}, "propio": []})
    assert eid not in sdp._n_web                                                            # la primera llamada vuelve a ser un goteo puro (n_max)


def test_restaurar_empresa_llama_a_conservar_secuencias():
    fuente = (RAIZ_APP / "respaldo.py").read_text(encoding="utf-8")
    cuerpo = fuente[fuente.index("def restaurar_empresa("):fuente.index("def reemplazar_base(")]   # 4.32 (S12): el reemplazo vive en reemplazar_base
    assert cuerpo.index("secuencias = leer_secuencias(destino_db)") < cuerpo.index("reemplazar_base(eid, tmp_db, destino_db)") < cuerpo.index("conservar_secuencias(eid, secuencias)")
    assert "os.replace(tmp_db, destino_db)" in fuente[fuente.index("def reemplazar_base("):fuente.index("def leer_secuencias(")]


RAIZ_APP = __import__("pathlib").Path(__file__).resolve().parent.parent / "app"


def test_cruce_estacion_viva_en_la_ruta_de_pendientes():
    fuente = (RAIZ_APP / "comandas.py").read_text(encoding="utf-8")
    if "marcar_estacion" not in fuente:
        pytest.skip("cruce pendiente: comandas.ruta_pendientes debe llamar a sinc_datos_programa.marcar_estacion")
    ruta = fuente[fuente.index("def ruta_pendientes("):]
    ruta = ruta[:ruta.index("\ndef ", 10)]
    assert "marcar_estacion(ctx.empresa.id)" in ruta or "_estacion_viva(ctx.empresa.id)" in ruta     # P3 lo hizo con una ayuda propia


# ---------------------------------------------------------------------------------------------------------------- revisión: grupo G (programa)
def test_rev_g_estado_desconocido_no_es_veredicto(web, decl_catalogo):
    """(I-2) Un estado que el programa no conoce (p. ej. «reintentar» o uno futuro) deja la op «enviada» sin tocar nada aquí."""
    eid = _empresa()
    sdp.ciclo(eid)
    pid = _producto(eid, "Nuevo QA")
    web.veredicto = lambda op: {"estado": "esperar", "motivo": None}
    sdp.ciclo(eid)
    with Session(engine_empresa(eid)) as s:
        assert s.get(Producto, pid) is not None
    assert [(o["op"], o["estado"]) for o in _ops(eid)] == [("alta", "enviada")] and _pisados(eid) == []
    assert sdp._ops_en_espera(eid) > 0


def test_rev_10_en_pausa_el_cobro_de_un_pedido_espera(web, decl_catalogo):
    eid = _empresa()
    c1, c2 = _venta(eid, None, n=1), _venta(eid, None, n=2)
    with Session(engine_empresa(eid)) as s:
        d1 = s.exec(sdp.select(Documento).where(Documento.clave == c1)).first()
        d1.pedido_id = 77; s.add(d1); s.commit()
        docs = s.exec(sdp.select(Documento).where(Documento.empresa_id == eid)).all()
        assert sdp.documentos_en_espera(s, eid, docs) == set()                        # sin pausa: sube como siempre
    sdp._guardar_estado(eid, pausa_desde=sdp._ahora())
    with Session(engine_empresa(eid)) as s:
        docs = s.exec(sdp.select(Documento).where(Documento.empresa_id == eid)).all()
        assert sdp.documentos_en_espera(s, eid, docs) == {d1.id}                      # en pausa: solo el cobro del pedido espera
    assert c2


def test_rev_32_lo_guardado_durante_la_ultima_subida_vieja_se_encola(web, decl_catalogo, monkeypatch):
    eid = _empresa(protocolo2=False)
    pid = _producto(eid, "Café QA")
    assert modulos.en_rango(pid, T)

    def subida(e, fotos=None):
        with Session(engine_empresa(e)) as s:
            p = s.get(Producto, pid)
            fotos.setdefault("productos", {})[str(pid)] = p.model_dump()
            fotos.setdefault("clientes", {})
            p.precio = 2500; s.add(p); s.commit()             # el cajero cambia el precio mientras sube (protocolo 0: no se encola)
        return True
    monkeypatch.setattr(sinc, "subida_final_vieja", subida)
    assert _ops(eid) == []
    sdp.ciclo(eid)                                            # _probar: la web tiene el canal nuevo
    assert sdp.protocolo(eid) == sdp.PROTOCOLO
    ops = _ops(eid)
    assert [(o["tipo"], o["ref"], o["op"]) for o in ops] == [("producto", str(pid), "cambio")], ops
    assert "2500" in ops[0]["datos"]


def test_rev_cruce_c_el_ciclo_confirma_las_cancelaciones(web, decl_catalogo, monkeypatch):
    from app import pedidos_programa
    vistas = []
    monkeypatch.setattr(pedidos_programa, "confirmar_cancelaciones", lambda e, forzar=False: vistas.append(e) or 0)
    eid = _empresa()
    sdp.ciclo(eid)
    assert vistas == [eid]
    sdp._guardar_estado(eid, pausa_desde=sdp._ahora())
    sdp._ultimo_intento_pausa.pop(eid, None)
    web.forzar = _Respuesta(404, {"detail": "Not Found"})
    sdp.ciclo(eid)                                            # en pausa no sale a confirmar nada
    assert vistas == [eid]
