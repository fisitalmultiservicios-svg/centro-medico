# -*- coding: utf-8 -*-
"""4.39, undécima vuelta de los arreglos de la comanda automática al cobrar (17 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py y las ayudas de las vueltas tercera a décima: destinoDe e impresoraDe reales, la Cocina como única
impresora de comanda y cada comanda anotada) y, para «Pedidos web» en el programa, los métodos reales de la ventana y del resumen.

- Q1 confirmarDividir: las tres consultas de la lista (antes de partir en el restaurante, la de después de esperar la marca y la de la caja
  de comercio) esperan hasta 3 s siempre (antes 1,5 s, o 3 s solo con platos por enviar al separar, pasar o partir). Con la lista a 2 s, lo
  que otro equipo ya cobró (entera o con «Cobrar estos platos») o quitó se ve: el aviso y nada pasa a la otra cuenta (antes quedaba por
  cobrar otra vez); igual en la caja de comercio y después de esperar la marca ya sin platos por enviar (lo que otro equipo quitó o cobró
  durante la espera); con «Cobrar estos platos», lo que queda de un plato recién mandado a cocina no vuelve a salir; al pasar todo un
  pedido con prepago, P1 ve el plato agregado (también en la caja de comercio). Un solo equipo: con la red normal no espera; con la lista a
  2 s, unos 2 s y sin aviso («Cobrar estos platos» con todo enviado no trae la lista: no espera).
- Q2 tras la primera consulta, si «Dividir» se canceló o se volvió a tocar, sale sin revisar «vistos»: un solo equipo que cancela y toca
  «Comanda» mientras se trae la lista no ve el aviso falso ni queda con la marca de su propia comanda (el cobro siguiente no espera); con
  dos toques en «Separar» el aviso sale una sola vez.
- Q3 un pedido en línea (sin prepago, o a crédito) no se pasa entero a una mesa: aviso y «Dividir» sigue abierto; la cuenta conserva el
  enlace con el pedido, el teléfono y el crédito, y al cobrarla el comprobante lleva su pedido_id (antes la cuenta de la mesa perdía todo
  eso). Pasar solo un plato del pedido a una mesa y pasar una mesa normal entera a otra siguen igual.
- Q4 al pasar todo un pedido con prepago a una cuenta aparte, la baja de la cuenta de origen va como la de un cobro: con la lista a más de
  3 s, si otro equipo le agregó un plato, la cuenta que queda con él no conserva lo ya pagado en línea (antes se aplicaba y se registraba en
  Bancos dos veces). Un solo equipo, igual que antes.
- Q5 en el programa, el pedido aceptado en «Pedidos web» queda como ya avisado: cuando su cuenta entra a la caja no suena, no avisa ni
  suma al botón (antes el botón se volvía a poner rojo). Uno aceptado en otra caja sí avisa; en la página web nada cambia.
Cada caso corre también, cuando muestra el defecto, con los métodos de ANTES de esta vuelta: se sacan de caja.js con la undécima vuelta
deshecha (UNDECIMA y _caja_sin_undecima de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de
la vuelta) y ahí se ve el defecto que el cambio arregla.
4.39 (decimotercera vuelta): el control «antes» de Q5 toma también aceptarWeb de antes de esta vuelta (la decimotercera hace que aceptarWeb anote el
pedido en _entAvisados en cuanto el PUT sale bien; con el de ahora el control ya no mostraba el defecto).
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import RAIZ, _metodo
from tests.test_432_caja_pedidos_web import _computadas, _metodos, _node, _tramo
from tests.test_439_cuarta_vuelta import AVISO_DIVIDIR_7
from tests.test_439_decima_vuelta import PED, TEL, _cuenta
from tests.test_439_decima_vuelta import _correr as _correr10
from tests.test_439_octava_vuelta import AVISO_Y3
from tests.test_439_revision_arreglos import _caja
from tests.test_439_septima_vuelta import CAMBIO_DIV, CERRADA_C1, CERRADA_M6
from tests.test_439_tercera_vuelta import UNDECIMA, _caja_sin_duodecima, _caja_sin_undecima

# los métodos que cambió la undécima vuelta (cada tripleta de UNDECIMA está en uno de ellos)
CAMBIADOS = ("async confirmarDividir() {", "async imprimirComandaWeb(p) {")
CASADO1, POSTRE1, LIMONADA1, AMBOS = ["Casado×1"], ["Postre×1"], ["Limonada×1"], ["Casado×1", "Postre×1"]
TRES = ["Casado×1", "Envío a domicilio×1", "Postre×1"]
CUATRO = ["Casado×1", "Envío a domicilio×1", "Limonada×1", "Postre×1"]
NO_A_MESA = "Este pedido en línea no se puede pasar entero a una mesa: páselo a una cuenta aparte o cóbrelo aquí"
TODO_APARTE = "Todo se pasó a una cuenta aparte (en «Para llevar en espera»): la cuenta quedó vacía"   # el texto no es literal (límite aceptado)
TODO_7 = "Todo se pasó a Mesa 7: la cuenta quedó vacía"


def _antes(cabezas=("async confirmarDividir() {",)):
    """Los métodos que cambió la undécima vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k = _caja_sin_undecima()
    return tuple(_metodo(k, c) for c in cabezas)


AYUDAS = r"""
// lo que la caja manda al emitir (el enlace con el pedido) y los pagos que registra en Bancos (lo ya pagado en línea entra como «Pago en línea»)
const CUERPOS = [], PAGOS = [];
{ const api0 = globalThis.API; globalThis.API = async (u, o, n) => { if (u === '/api/comprobantes' && o && o.body) CUERPOS.push({ pedido: o.body.pedido_id || null, parcial: !!o.body.pedido_parcial }); if (u === '/api/pagos' && o && o.body) PAGOS.push([+o.body.monto, String(o.body.detalles || '').startsWith('Pago en línea')]); return api0(u, o, n); }; }
// las cuentas del servidor con lo que importa aquí: platos, lo ya pagado en línea, el enlace con el pedido, el teléfono, el crédito y la mesa
const cuentasQ = () => S.items.map(x => ({ nombre: x.nombre, platos: (x.lineas || []).map(l => l.detalle + '×' + l.cantidad).sort(), prepago: x.prepago ? +x.prepago.monto : 0, pedido: x.pedido_id || null, telefono: x.telefono || null, credito: !!x.credito, cliente: x.cliente_id || null, mesa: x.mesa_id || null }));
// un equipo nuevo cobra cada cuenta que quedó en el servidor (la de una mesa, abriendo la mesa; las demás, desde «Para llevar en espera»)
async function cobrarTodas() {
  for (const c of S.items.slice()) {
    const v = venta(await equipo()); v.mesas = [M6, M7]; await v.sincronizar();
    if (c.mesa_id) v.abrirMesa(c.mesa_id === 7 ? M7 : M6); else v.recuperar(v.espera.find(x => x.id === c.id));
    await v.abrirPago(); if (v.pago) await v.cobrar(); await hastaLibre(); await v.A.mock.guardarTodo();
  }
  await hastaLibre();
}
// ESE equipo elige ese plato (entero) para `destino` (nueva, 7 o cobrar)
function elegir(vm, detalle, destino) { const i = vm.lineas.findIndex(l => l.detalle === detalle); vm.dividir.destino = destino; vm.dividir.sel = { [i]: +vm.lineas[i].cantidad }; }
"""


def _correr(tmp_path, casos, antes=()):
    return _correr10(tmp_path, AYUDAS + casos, antes=antes)


# ================================================================================================================ Q1: la lista a 2 s
CASOS_Q1 = r"""
// la Mesa 6 con Casado y Postre ya enviados (hace un minuto), abierta en A y en B (con `comercio`, la cuenta guardada sin mesa en la caja de comercio). A
// abre «Dividir». B (`que`): entera, cobra la cuenta entera; estos, «Dividir → Cobrar estos platos» con el Casado y lo cobra; quita, quita el Postre. Desde
// ahí la lista de cuentas de A tarda 2 s. A elige el plato que tocó B (el Casado; con quita, el Postre) para `destino` (nueva o la Mesa 7) y confirma. Si
// salió el aviso de volver a abrir «Dividir», lo vuelve a abrir (la lista ya llega al día) y lo cierra
async function q1(que, destino, comercio) {
  const env = comercio ? {} : { enviado: VIEJA(), ronda: 1 };
  const [id, a, b] = await cuenta(!comercio, [{ ...CASADO(), ...env }, { ...POSTRE(), ...env }]); a.mesas = [M6, M7];
  if (comercio) { a.esRestaurante = false; b.esRestaurante = false; }
  await a.abrirDividir();
  if (que === 'entera') { await b.abrirPago(); await b.cobrar(); }
  else if (que === 'estos') { await b.abrirDividir(); elegir(b, 'Casado', 'cobrar'); await b.confirmarDividir(); await conPago(b); await b.cobrar(); }
  else await quitarPostre(b);
  await hastaLibre(); await b.A.mock.guardarTodo();
  const srvB = srv(), hechosB = cobrados(a);
  const suelta = lento(a, 2000), lis = listas(a), t0 = Date.now();
  elegir(a, que === 'quita' ? 'Postre' : 'Casado', destino); await a.confirmarDividir(); const ms = Date.now() - t0;
  await espera(2200); suelta(); await a.A.mock.guardarTodo(); await hastaLibre();
  const primero = { ms, consultas: lis.n, dividir: !!a.dividir, alDia: a._alDia, avisos: avisosDiv(a), cerradas: cerradas(a), hecho: hechoDiv(a), srv: srv() };
  let segundo = null;
  if (primero.avisos.length && !a.dividir) { await a.abrirDividir(); segundo = { abierto: !!a.dividir, platos: detalles(a) }; a.dividir = null; }
  return { srvB, hechosB, primero, segundo, hechos: cobrados(a), srv: srv(), impresos: quienes(a), libre: libre() };
}
for (const [que, destino, comercio] of @CASOS@) out[que + '_' + destino + (comercio ? '_comercio' : '')] = await q1(que, destino, comercio);
"""

# a qué cuenta pasa lo elegido (antes de esta vuelta): a la cuenta aparte o a la Mesa 7
DESTINO = {"nueva": "Mesa 6 · aparte", "7": "Mesa 7", "nueva_comercio": "Cuenta 1 · aparte"}
# lo que dejó B en el servidor, lo que cobró B, el plato que elige A y lo que A ve al volver a abrir «Dividir»
Q1_B = {"entera": ([], [["B", AMBOS]], "Casado×1", None), "estos": (POSTRE1, [["B", CASADO1]], "Casado×1", POSTRE1),
        "quita": (CASADO1, [], "Postre×1", CASADO1)}


@pytest.mark.parametrize("que", ["entera", "estos", "quita"])
def test_q1_con_la_lista_a_2_s_lo_cobrado_o_quitado_en_otro_equipo_no_pasa_a_otra_cuenta_en_node(tmp_path, que):
    casos = CASOS_Q1.replace("@CASOS@", json.dumps([[que, "nueva", False], [que, 7, False], [que, "nueva", True]]))
    r = _correr(tmp_path / "ahora", casos)
    queda, hechos_b, plato, al_volver = Q1_B[que]
    for k in ("nueva", "7", "nueva_comercio"):
        x, p = r[que + "_" + k], r[que + "_" + k]["primero"]
        nombre = "Cuenta 1" if k.endswith("comercio") else "Mesa 6"
        srv_b = [[nombre, queda, None]] if queda else []
        assert x["srvB"] == srv_b and x["hechosB"] == hechos_b, (que, k, x)
        # la lista llegó a los 2 s (la espera es de hasta 3 s): lo que hizo B se vio y A no pasó nada a otra cuenta ni a la Mesa 7
        assert 1950 <= p["ms"] < 2900 and p["dividir"] is False and p["hecho"] == [] and p["srv"] == srv_b, (que, k, x)
        if que == "entera":
            # la cuenta ya no está: el aviso de siempre de sincronizar (cobrada o cerrada en otro equipo) y la sincronización de siempre (otra consulta)
            cerrada = CERRADA_C1 if k.endswith("comercio") else CERRADA_M6
            assert p["avisos"] == [] and p["cerradas"] == [cerrada] and p["consultas"] == 2 and x["segundo"] is None, (que, k, x)
        else:
            # la cuenta cambió: el aviso de volver a abrir «Dividir» (una consulta) y la próxima apertura la junta: A ve lo que dejó B
            assert p["avisos"] == [AVISO_Y3] and p["cerradas"] == [] and p["consultas"] == 1 and p["alDia"] == 0, (que, k, x)
            assert x["segundo"] == {"abierto": True, "platos": al_volver}, (que, k, x)
        # al final nada quedó por cobrar dos veces: el servidor como lo dejó B, lo cobrado una vez (en B) y nada salió a cocina
        assert x["srv"] == srv_b and x["hechos"] == hechos_b and x["impresos"] == [] and x["libre"] is True, (que, k, x)

    # antes de esta vuelta: la consulta esperaba 1,5 s y se partía con la copia vieja: lo que B ya había cobrado (entero o con «Cobrar estos platos») o
    # quitado pasaba a una cuenta aparte o a la Mesa 7, por cobrar otra vez
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for k in ("nueva", "7", "nueva_comercio"):
        x, p = v[que + "_" + k], v[que + "_" + k]["primero"]
        nombre = "Cuenta 1" if k.endswith("comercio") else "Mesa 6"
        srv_b = [[nombre, queda, None]] if queda else []
        assert 1400 <= p["ms"] < 1950 and p["avisos"] == [] and p["cerradas"] == [] and len(p["hecho"]) == 1, (que, k, x)
        assert x["srv"] == srv_b + [[DESTINO[k], [plato], None]] and x["hechos"] == hechos_b, (que, k, x)


CASOS_Q1_COCINA = r"""
// la Mesa 6 con 2 Casados y un Postre sin enviar, abierta en A y en B. A abre «Dividir»; B toca «Comanda» (sale enseguida y su guardado llega al servidor).
// Desde ahí la lista de A tarda 2 s. A elige un Casado para «Cobrar estos platos» y confirma; si se abre el cobro de la parte, lo cobra. Después un tercer
// equipo abre cada cuenta del servidor y toca «Comanda»
const [id, a, b] = await mesaGuardada([{ ...CASADO(), cantidad: 2 }, POSTRE()]); a.mesas = [M6, M7];
await a.abrirDividir();
await b.enviarComanda(); await b.A.mock.guardarTodo();
const suelta = lento(a, 2000), lis = listas(a), t0 = Date.now();
a.dividir.destino = 'cobrar'; a.dividir.sel = { [a.lineas.findIndex(l => l.detalle === 'Casado')]: 1 };
await a.confirmarDividir(); const ms = Date.now() - t0; await conPago(a); if (a.pago) await a.cobrar();
await espera(2200); suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
const primero = { ms, consultas: lis.n, dividir: !!a.dividir, alDia: a._alDia, avisos: avisosDiv(a), hechos: cobrados(a), srv: srv(), enviados: enviados() };
await otraComanda();
out.r = { primero, impresos: impresos(), enviados: enviados(), srv: srv() };
"""


def test_q1_cobrar_estos_platos_con_la_lista_a_2_s_no_vuelve_a_mandar_a_cocina_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_Q1_COCINA)["r"]
    p = r["primero"]
    # la lista llegó a los 2 s (antes, con «Cobrar estos platos», 1,5 s): la comanda de B se vio; el aviso «Otro equipo mandó a cocina…», «Dividir» cerrado,
    # nada partido ni cobrado
    assert 1950 <= p["ms"] < 2900 and p["consultas"] == 1 and p["avisos"] == [AVISO_DIVIDIR_7] and p["dividir"] is False and p["alDia"] == 0, r
    assert p["hechos"] == [] and p["srv"] == [["Mesa 6", ["Casado×2", "Postre×1"], None]] and p["enviados"] == [["Casado×2", "Postre×1"]], r
    # la cocina recibió cada plato una vez (la comanda de B); la próxima «Comanda» no manda nada
    assert r["impresos"] == [["Casado×2", "Postre×1"]] and r["enviados"] == [["Casado×2", "Postre×1"]], r

    # antes de esta vuelta: la consulta esperaba 1,5 s y se cobraba un Casado con la copia vieja: el otro Casado quedaba en la mesa «sin enviar» y la próxima
    # «Comanda» lo mandaba otra vez a cocina
    v = _correr(tmp_path / "antes", CASOS_Q1_COCINA, antes=_antes())["r"]
    assert v["primero"]["avisos"] == [] and v["primero"]["hechos"] == [["A", CASADO1]] and v["primero"]["srv"] == [["Mesa 6", AMBOS, None]], v
    assert v["impresos"] == [["Casado×2", "Postre×1"], CASADO1], v


CASOS_Q1_X2 = r"""
// la Mesa 6 con Casado y Postre sin enviar, abierta en A y en B. B toca «Comanda» (sale enseguida); A sincroniza (le llegan enviados: la marca), abre
// «Dividir», elige el Casado para `destino` y confirma: espera la marca, ya sin platos por enviar. Desde ese momento la lista de A tarda 2 s. A los 1,5 s B
// (`que`) quita el Casado y guarda, o cobra la cuenta entera
async function q1x2(que, destino) {
  const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]); a.mesas = [M6, M7];
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  await a.sincronizar(); const m0 = !!marca(a), sin0 = a.lineas.filter(l => !l.enviado).length;
  await a.abrirDividir(); elegir(a, 'Casado', destino);
  const t0 = Date.now(), pd = a.confirmarDividir(), suelta = lento(a, 2000), lis = listas(a);
  await espera(1500); if (que === 'quita') await quitarCasado(b); else { await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo(); }
  const srvB = srv();
  await pd; const ms = Date.now() - t0; await espera(2200); suelta(); await a.A.mock.guardarTodo(); await hastaLibre(); await b.A.mock.guardarTodo();
  return { m0, sin0, srvB, ms, consultas: lis.n, dividir: !!a.dividir, alDia: a._alDia, avisos: avisosDiv(a), cerradas: cerradas(a), hecho: hechoDiv(a), srv: srv(), hechos: cobrados(a), impresos: quienes(a) };
}
for (const [que, destino] of @CASOS@) out[que + '_' + destino] = await q1x2(que, destino);
"""


@pytest.mark.parametrize("que", ["quita", "entera"])
def test_q1_despues_de_esperar_la_marca_sin_platos_por_enviar_con_la_lista_a_2_s_en_node(tmp_path, que):
    casos = CASOS_Q1_X2.replace("@CASOS@", json.dumps([[que, "nueva"], [que, 7]]))
    r = _correr(tmp_path / "ahora", casos)
    srv_b = [["Mesa 6", POSTRE1, None]] if que == "quita" else []
    for k in ("nueva", "7"):
        x = r[que + "_" + k]
        # A vio la comanda de B (la marca) y ya no tenía platos por enviar (antes la consulta de después de esperar quedaba en 1,5 s); la comanda de B salió
        # una vez
        assert x["m0"] is True and x["sin0"] == 0 and x["srvB"] == srv_b and 5000 <= x["ms"] < 9000 and x["impresos"] == [["B", AMBOS]], (que, k, x)
        # la lista llegó a los 2 s: lo que hizo B durante la espera se vio y no se partió nada
        assert x["dividir"] is False and x["hecho"] == [] and x["srv"] == srv_b, (que, k, x)
        if que == "quita":
            assert x["avisos"] == [CAMBIO_DIV] and x["cerradas"] == [] and x["consultas"] == 1 and x["alDia"] == 0, (que, k, x)
        else:
            assert x["avisos"] == [] and x["cerradas"] == [CERRADA_M6] and x["consultas"] == 2 and x["hechos"] == [["B", AMBOS]], (que, k, x)

    # antes de esta vuelta: se partía con la copia vieja: el Casado que B quitó (o que ya cobró con la cuenta entera) pasaba a la cuenta aparte o a la Mesa 7
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for k in ("nueva", "7"):
        x = v[que + "_" + k]
        assert x["avisos"] == [] and x["cerradas"] == [] and len(x["hecho"]) == 1 and x["srv"] == srv_b + [[DESTINO[k], CASADO1, None]], (que, k, x)


CASOS_Q1_P1 = r"""
// el pedido en línea con ₡1 000 ya pagados en línea, abierto en A y en B (con `comercio`, en la caja de comercio). A abre «Dividir»; B agrega una Limonada y
// la guarda (llega al servidor). Desde ahí la lista de A tarda 2 s. A marca todo lo que ve y lo pasa a una cuenta aparte. Cada cuenta abre su cobro (lo ya
// pagado en línea que descontaría)
async function p1(comercio) {
  const [a, b] = await pedidoAbierto(true, 2, comercio);
  await a.abrirDividir();
  b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo();
  const suelta = lento(a, 2000), lis = listas(a);
  const ms = await separar(a, false);
  await espera(2200); suelta(); await a.A.mock.guardarTodo(); await hastaLibre();
  return { ms, consultas: lis.n, dividir: !!a.dividir, alDia: a._alDia, avisos: avisosDiv(a), hecho: hechoDiv(a), cuentas: cuentasP(), prepagos: await prepagosAlCobrar() };
}
for (const comercio of [false, true]) out[comercio ? 'comercio' : 'restaurante'] = await p1(comercio);
"""


def test_q1_p1_con_la_lista_a_2_s_ve_el_plato_de_otro_equipo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_Q1_P1)
    for k in ("restaurante", "comercio"):
        x = r[k]
        # la lista llegó a los 2 s: P1 ve la Limonada de B; el aviso de volver a abrir «Dividir» y no se pasa nada: una sola cuenta con lo ya pagado (una vez)
        assert 1950 <= x["ms"] < 2900 and x["consultas"] == 1 and x["avisos"] == [AVISO_Y3] and x["dividir"] is False and x["alDia"] == 0 and x["hecho"] == [], (k, x)
        assert x["cuentas"] == [_cuenta(PED, CUATRO, 1000)] and x["prepagos"] == [1000], (k, x)

    # antes de esta vuelta (en el restaurante y en la caja de comercio): la consulta esperaba 1,5 s, P1 miraba la copia vieja y se pasaba todo: lo ya pagado
    # en línea quedaba en las dos cuentas (se descontaba dos veces)
    v = _correr(tmp_path / "antes", CASOS_Q1_P1, antes=_antes())
    for k in ("restaurante", "comercio"):
        x = v[k]
        assert 1400 <= x["ms"] < 1950 and x["avisos"] == [] and x["hecho"] == [TODO_APARTE], (k, x)
        assert x["cuentas"] == [_cuenta(PED, LIMONADA1, 1000), _cuenta(PED + " · aparte", TRES, 1000)] and x["prepagos"] == [1000, 1000], (k, x)


CASOS_Q1_SOLO = r"""
// un solo equipo (A), sin nada de otro equipo; la lista de cuentas de A tarda `ms` (0: la red normal). `caso`: separar / pasar (la Mesa 6 con Casado y
// Postre ya enviados: el Casado a una cuenta aparte o a la Mesa 7); partes (la cuenta guardada sin mesa con los platos ya enviados, 2 partes iguales);
// cobrar («Cobrar estos platos» con el Casado de la Mesa 6 ya enviado, y se cobra); cobrar_sin (lo mismo con los platos sin enviar); comercio (la cuenta
// guardada en la caja de comercio, el Casado a una cuenta aparte); pedido (el pedido en línea con ₡1 000 ya pagados, todo a una cuenta aparte). Cuánto
// tarda confirmarDividir (con cobrar, hasta que se abre el cobro de la parte)
async function solo(caso, ms) {
  let a; const env = caso !== 'cobrar_sin' && caso !== 'comercio' ? { enviado: VIEJA(), ronda: 1 } : {};
  if (caso === 'pedido') [a] = await pedidoAbierto(true, 1, false);
  else { [, a] = await cuenta(caso !== 'partes' && caso !== 'comercio', [{ ...CASADO(), ...env }, { ...POSTRE(), ...env }]); a.mesas = [M6, M7]; if (caso === 'comercio') a.esRestaurante = false; }
  await a.abrirDividir(); const suelta = ms ? lento(a, ms) : () => {}, lis = listas(a), t0 = Date.now();
  if (caso === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; }
  else if (caso === 'pedido') { a.dividir.destino = 'nueva'; a.dividir.sel = Object.fromEntries(a.lineas.map((l, i) => [i, +l.cantidad])); }
  else elegir(a, 'Casado', caso === 'pasar' ? 7 : caso.startsWith('cobrar') ? 'cobrar' : 'nueva');
  const pd = a.confirmarDividir();
  if (caso.startsWith('cobrar')) { for (let i = 0; i < 2000 && !a.cobroParcial; i++) await espera(2); } else await pd;
  const t = Date.now() - t0, consultas = lis.n;
  await pd; if (caso.startsWith('cobrar')) { await conPago(a); if (a.pago) await a.cobrar(); }
  await espera(ms ? ms + 100 : 50); suelta(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { ms: t, consultas, dividir: !!a.dividir, avisos: otrosAvisos(a), hecho: hechoDiv(a), srv: srv(), hechos: cobrados(a), impresos: quienes(a), prepagos: caso === 'pedido' ? await prepagosAlCobrar() : null };
}
for (const [caso, ms] of @CASOS@) out[caso + '_' + ms] = await solo(caso, ms);
"""

MEDIAS = ["Casado×0.5", "Postre×0.5"]
SOLO_Q1 = {"separar": [["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], "pasar": [["Mesa 6", POSTRE1, None], ["Mesa 7", CASADO1, None]],
           "partes": [["Cuenta 1", MEDIAS, None], ["Cuenta 1 · parte 2 de 2", MEDIAS, None]], "cobrar": [["Mesa 6", POSTRE1, None]], "cobrar_sin": [["Mesa 6", POSTRE1, None]],
           "comercio": [["Cuenta 1", POSTRE1, None], ["Cuenta 1 · aparte", CASADO1, None]], "pedido": [[PED + " · aparte", TRES, None]]}


def test_q1_un_solo_equipo_sin_espera_con_la_red_normal_y_unos_2_s_con_la_lista_lenta_en_node(tmp_path):
    casos = CASOS_Q1_SOLO.replace("@CASOS@", json.dumps([[c, ms] for ms in (0, 2000) for c in SOLO_Q1]))
    r = _correr(tmp_path, casos)
    for ms in (0, 2000):
        for caso, srv in SOLO_Q1.items():
            x = r[caso + "_" + str(ms)]
            # sin aviso (fuera de lo hecho) y se divide o se cobra igual; nada sale a cocina
            avisos = [t for t in x["avisos"] if not t.startswith("Todo se pasó a ")]
            assert avisos == [] and x["dividir"] is False and x["srv"] == srv and x["impresos"] == [], (caso, ms, x)
            assert x["hechos"] == ([["A", CASADO1]] if caso.startswith("cobrar") else []) and (caso.startswith("cobrar") or len(x["hecho"]) == 1), (caso, ms, x)
            # «Cobrar estos platos» con todo enviado no trae la lista (no hay nada que mirar); lo demás, una consulta
            assert x["consultas"] == (0 if caso == "cobrar" else 1), (caso, ms, x)
            # con la red normal, sin espera; con la lista a 2 s, se espera la lista (unos 2 s; antes de esta vuelta, sin platos por enviar, con «Cobrar estos
            # platos» y en la caja de comercio, 1,5 s y se seguía con la copia)
            if ms == 0 or caso == "cobrar":
                assert x["ms"] < 1000, (caso, ms, x)
            else:
                assert 1950 <= x["ms"] < 2900, (caso, ms, x)
    for ms in (0, 2000):
        assert r["pedido_" + str(ms)]["prepagos"] == [1000], r["pedido_" + str(ms)]


# ================================================================================================================ Q2: «Dividir» cancelado o tocado otra vez
CASOS_Q2_SOLO = r"""
// un solo equipo (A): la Mesa 6 con Casado y Postre sin enviar; la lista de cuentas de A tarda 2 s. A abre «Dividir», elige el Casado para una cuenta aparte
// y toca «Separar»; a los 0,4 s toca «Cancelar» y a los 0,6 s toca «Comanda» (sale su comanda). Cuando todo terminó, A abre el cobro y cobra: cuánto tarda
const [id, a] = await mesaGuardada([CASADO(), POSTRE()]); a.mesas = [M6, M7];
await a.abrirDividir();
const suelta = lento(a, 2000), lis = listas(a), t0 = Date.now();
elegir(a, 'Casado', 'nueva'); const pd = a.confirmarDividir();
await espera(400); a.dividir = null;
await espera(200); const pc = a.enviarComanda();
await pd; const ms = Date.now() - t0; suelta();
await pc; await a.A.mock.guardarTodo(); await hastaLibre();
const primero = { ms, consultas: lis.n, dividir: !!a.dividir, alDia: a._alDia, marca: marca(a), avisos: otrosAvisos(a), hecho: hechoDiv(a), srv: srv(), impresos: quienes(a), enviados: enviados() };
const t1 = Date.now(); await a.abrirPago(); if (a.pago) await a.cobrar(); const cobro = Date.now() - t1; await hastaLibre(); await a.A.mock.guardarTodo();
out.r = { primero, cobro, hechos: cobrados(a), srv: srv(), impresos: quienes(a), avisos: otrosAvisos(a) };
"""


def test_q2_un_solo_equipo_que_cancela_y_toca_comanda_mientras_trae_la_lista_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_Q2_SOLO)["r"]
    p = r["primero"]
    # la consulta de «Separar» volvió a los 2 s con la comanda de A (su propia «Comanda»): como «Dividir» ya estaba cancelado, sale sin mirar: sin aviso,
    # sin la marca de «otro equipo» y nada partido; la comanda de A salió una vez (dos consultas: la de «Separar» y la revisión de la comanda)
    assert 1950 <= p["ms"] < 2900 and p["consultas"] == 2 and p["dividir"] is False and p["marca"] is None and p["avisos"] == [] and p["hecho"] == [], r
    assert p["srv"] == [["Mesa 6", AMBOS, None]] and p["impresos"] == [["A", AMBOS]] and p["enviados"] == [AMBOS], r
    # el cobro siguiente no espera nada y cobra una vez; la cocina no recibe nada más
    assert r["cobro"] < 1500 and r["hechos"] == [["A", AMBOS]] and r["srv"] == [] and r["impresos"] == [["A", AMBOS]] and r["avisos"] == [], r

    # antes de esta vuelta: la consulta miraba igual: los platos de la comanda de A llegaban «enviados» y salía el aviso falso «Otro equipo mandó a cocina…»
    # (con un solo equipo), quedaba la marca de su propia comanda y el cobro siguiente esperaba hasta 4 s
    v = _correr(tmp_path / "antes", CASOS_Q2_SOLO, antes=_antes())["r"]
    assert v["primero"]["avisos"] == [AVISO_DIVIDIR_7] and v["primero"]["marca"] is not None and v["cobro"] >= 2500, v
    assert v["hechos"] == [["A", AMBOS]] and v["impresos"] == [["A", AMBOS]], v


CASOS_Q2_DOS = r"""
// la Mesa 6 con Casado y Postre sin enviar, abierta en A y en B. A abre «Dividir»; B toca «Comanda» (sale enseguida y su guardado llega al servidor). Desde
// ahí la lista de A tarda 2 s. A elige el Casado para una cuenta aparte y toca «Separar»; a los 0,3 s lo toca otra vez. Después un tercer equipo abre cada
// cuenta del servidor y toca «Comanda»
const [id, a, b] = await mesaGuardada([CASADO(), POSTRE()]); a.mesas = [M6, M7];
await a.abrirDividir();
await b.enviarComanda(); await b.A.mock.guardarTodo();
const suelta = lento(a, 2000), lis = listas(a), t0 = Date.now();
elegir(a, 'Casado', 'nueva'); const p1 = a.confirmarDividir(); await espera(300); const p2 = a.confirmarDividir();
await Promise.all([p1, p2]); const ms = Date.now() - t0; await espera(100); suelta(); await a.A.mock.guardarTodo(); await hastaLibre();
const primero = { ms, consultas: lis.n, dividir: !!a.dividir, alDia: a._alDia, avisos: avisosDiv(a), hecho: hechoDiv(a), srv: srv(), marca: !!marca(a) };
await otraComanda();
out.r = { primero, impresos: impresos(), enviados: enviados() };
"""


def test_q2_dos_toques_en_separar_dan_el_aviso_una_vez_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_Q2_DOS)["r"]
    p = r["primero"]
    # las dos consultas volvieron (a los 2 y a los 2,3 s): la primera vio la comanda de B, avisó y cerró «Dividir»; la segunda salió sin avisar otra vez
    assert p["consultas"] == 2 and p["avisos"] == [AVISO_DIVIDIR_7] and p["dividir"] is False and p["alDia"] == 0 and p["marca"] is True and p["hecho"] == [], r
    # nada partido; cada plato salió a cocina una vez (de B)
    assert p["srv"] == [["Mesa 6", AMBOS, None]] and r["impresos"] == [AMBOS] and r["enviados"] == [AMBOS], r

    # antes de esta vuelta: el aviso salía dos veces (una por toque); lo demás, igual
    v = _correr(tmp_path / "antes", CASOS_Q2_DOS, antes=_antes())["r"]
    assert v["primero"]["avisos"] == [AVISO_DIVIDIR_7, AVISO_DIVIDIR_7] and v["primero"]["srv"] == p["srv"] and v["impresos"] == [AMBOS], v


# ================================================================================================================ Q3: un pedido en línea entero a una mesa
CASOS_Q3 = r"""
// `caso`: pedido (el pedido en línea a domicilio de contado sin prepago: Casado y Postre enviados hace un minuto y el envío, con el teléfono del cliente),
// credito (el mismo, a crédito de la revendedora QA, cliente 5), parte (el de contado: A pasa solo el Casado), mesa (la Mesa 6 con Casado y Postre ya
// enviados, sin pedido). En A: abre «Dividir», marca todo (con parte, el Casado) para la Mesa 7 y confirma. Si «Dividir» sigue abierto lo cancela y, si la
// cuenta sigue en pantalla (y no es a crédito: la revendedora y su límite no vienen en el arnés), la cobra; después un equipo nuevo cobra lo que quedó en el
// servidor (con credito, nada)
async function q3(caso) {
  let a;
  if (caso === 'mesa') { [, a] = await mesaGuardada([{ ...CASADO(), enviado: VIEJA(), ronda: 1 }, { ...POSTRE(), enviado: VIEJA(), ronda: 1 }]); }
  else {
    nuevo(); pedidoEnServidor([CASADO(), POSTRE()]); S.items[0].telefono = @TEL@; if (caso === 'credito') Object.assign(S.items[0], { credito: true, cliente_id: 5 });
    a = venta(await equipo()); await a.sincronizar(); a.recuperar(a.espera.find(x => x.id === 1));
  }
  a.mesas = [M6, M7]; CUERPOS.length = 0; PAGOS.length = 0;
  await a.abrirDividir(); const abierto = !!a.dividir;
  if (caso === 'parte') elegir(a, 'Casado', 7); else { a.dividir.destino = 7; a.dividir.sel = Object.fromEntries(a.lineas.map((l, i) => [i, +l.cantidad])); }
  await a.confirmarDividir(); await espera(50); await a.A.mock.guardarTodo(); await hastaLibre();
  const primero = { abierto, dividir: !!a.dividir, avisos: otrosAvisos(a), hecho: hechoDiv(a), platos: detalles(a), cuentas: cuentasQ(), vista: a.vista, enPantalla: a.esperaId !== null && a.esperaId !== undefined };
  if (a.dividir) a.dividir = null;
  if (caso !== 'credito') {
    if (primero.enPantalla && a.lineas.length) { await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); }
    await cobrarTodas();
  }
  return { primero, cuerpos: CUERPOS.slice(), emitidos: C.emitidos.map(e => e.lineas.slice().sort()), srv: S.items.length, impresos: quienes(a) };
}
for (const caso of @CASOS@) out[caso] = await q3(caso);
"""


def _q(nombre, platos, pedido=True, credito=False, mesa=None):
    """Una cuenta del servidor como la anota cuentasQ (prepago 0)."""
    return {"nombre": nombre, "platos": platos, "prepago": 0, "pedido": 9 if pedido else None, "telefono": TEL if pedido else None, "credito": credito,
            "cliente": 5 if credito else None, "mesa": mesa}


@pytest.mark.parametrize("caso", ["pedido", "credito"])
def test_q3_un_pedido_en_linea_no_se_pasa_entero_a_una_mesa_en_node(tmp_path, caso):
    casos = CASOS_Q3.replace("@CASOS@", json.dumps([caso])).replace("@TEL@", json.dumps(TEL))
    r = _correr(tmp_path / "ahora", casos)[caso]
    p = r["primero"]
    # el aviso y nada se mueve: «Dividir» sigue abierto (se puede elegir una cuenta aparte o cobrar), la cuenta sigue en pantalla con todo y en el servidor
    # conserva el enlace con el pedido, el teléfono y el crédito
    assert p["abierto"] is True and p["dividir"] is True and p["avisos"] == [NO_A_MESA] and p["hecho"] == [] and p["platos"] == TRES, r
    assert p["vista"] == "venta" and p["enPantalla"] is True and p["cuentas"] == [_q(PED, TRES, credito=caso == "credito")], r
    if caso == "pedido":
        # se cobra aquí: el comprobante lleva su pedido_id (el cliente recibe sus puntos) y la cuenta se cierra
        assert r["cuerpos"] == [{"pedido": 9, "parcial": False}] and r["emitidos"] == [TRES] and r["srv"] == 0 and r["impresos"] == [], r
    else:
        assert r["cuerpos"] == [] and r["srv"] == 1, r

    # antes de esta vuelta: todo pasaba a la Mesa 7 sin el enlace con el pedido, sin el teléfono y sin el crédito: el comprobante salía sin pedido_id (sin
    # puntos ni enlace) y el pedido a crédito se habría cobrado de contado
    v = _correr(tmp_path / "antes", casos, antes=_antes())[caso]
    assert v["primero"]["dividir"] is False and v["primero"]["avisos"] == [TODO_7] and v["primero"]["vista"] == "mesas", v
    assert v["primero"]["cuentas"] == [_q("Mesa 7", TRES, pedido=False, mesa=7)], v
    if caso == "pedido":
        assert v["cuerpos"] == [{"pedido": None, "parcial": False}], v


def test_q3_pasar_un_plato_del_pedido_o_una_mesa_entera_sigue_igual_en_node(tmp_path):
    casos = CASOS_Q3.replace("@CASOS@", json.dumps(["parte", "mesa"])).replace("@TEL@", json.dumps(TEL))
    r = _correr(tmp_path / "ahora", casos)
    # solo el Casado del pedido a la Mesa 7: se pasa (la cuenta del pedido conserva el enlace, el teléfono, el resto y su comprobante el pedido_id)
    x = r["parte"]
    assert x["primero"]["dividir"] is False and x["primero"]["avisos"] == [] and x["primero"]["hecho"] == ["Platos pasados a Mesa 7"], x
    assert x["primero"]["cuentas"] == [_q(PED, ["Envío a domicilio×1", "Postre×1"]), _q("Mesa 7", CASADO1, pedido=False, mesa=7)], x
    assert x["cuerpos"][0] == {"pedido": 9, "parcial": False} and x["srv"] == 0, x
    # la Mesa 6 entera (sin pedido) a la Mesa 7: se pasa todo y la Mesa 6 queda libre
    m = r["mesa"]
    assert m["primero"]["dividir"] is False and m["primero"]["avisos"] == [TODO_7] and m["primero"]["vista"] == "mesas", m
    assert m["primero"]["cuentas"] == [_q("Mesa 7", AMBOS, pedido=False, mesa=7)] and m["cuerpos"] == [{"pedido": None, "parcial": False}] and m["srv"] == 0, m
    # control: antes de esta vuelta era igual
    assert _correr(tmp_path / "antes", casos, antes=_antes()) == r


# ================================================================================================================ Q4: todo con prepago a una cuenta aparte
CASOS_Q4 = r"""
// el pedido en línea con ₡1 000 ya pagados en línea (con tarjeta, en línea), abierto en A y en B (con `solo`, solo en A). A abre «Dividir»; B agrega una
// Limonada y la guarda (llega al servidor). Desde ahí la lista de cuentas de A tarda `ms` (3,5 s: más que la espera de 3 s). A marca todo lo que ve y lo
// pasa a una cuenta aparte. Después un equipo nuevo cobra cada cuenta del servidor: lo ya pagado en línea se descuenta y entra a Bancos («Pago en línea»)
async function q4(ms, solo) {
  nuevo(); pedidoEnServidor([CASADO(), POSTRE()]); S.items[0].telefono = @TEL@; S.items[0].prepago = { monto: 1000, medio: '02', referencia: 'QA-1', online: 1000 };
  const vs = []; for (let i = 0; i < (solo ? 1 : 2); i++) { const v = venta(await equipo()); await v.sincronizar(); v.recuperar(v.espera.find(x => x.id === 1)); vs.push(v); }
  const [a, b] = vs; CUERPOS.length = 0; PAGOS.length = 0;
  await a.abrirDividir();
  if (b) { b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo(); }
  const suelta = ms ? lento(a, ms) : () => {}, lis = listas(a);
  const t = await separar(a, false);
  await espera(ms ? ms + 200 : 50); suelta(); await a.A.mock.guardarTodo(); await hastaLibre();
  const primero = { ms: t, consultas: lis.n, avisos: avisosDiv(a), hecho: hechoDiv(a), cuentas: cuentasQ() };
  const prepagos = await prepagosAlCobrar();
  await cobrarTodas();
  return { primero, prepagos, cuerpos: CUERPOS.slice(), pagos: PAGOS.slice(), emitidos: C.emitidos.map(e => [e.total, e.lineas.slice().sort()]), quedan: S.items.length };
}
for (const [ms, solo] of @CASOS@) out[ms + (solo ? '_solo' : '')] = await q4(ms, solo);
"""


def _p(nombre, platos, prepago):
    """Una cuenta del pedido en el servidor como la anota cuentasQ."""
    return {"nombre": nombre, "platos": platos, "prepago": prepago, "pedido": 9, "telefono": TEL, "credito": False, "cliente": None, "mesa": None}


def test_q4_pasar_todo_con_prepago_y_la_lista_a_3_5_s_no_aplica_dos_veces_lo_pagado_en_linea_en_node(tmp_path):
    casos = CASOS_Q4.replace("@CASOS@", json.dumps([[3500, False]])).replace("@TEL@", json.dumps(TEL))
    r = _correr(tmp_path / "ahora", casos)["3500"]
    p = r["primero"]
    # la lista tardó más que la espera (3 s): P1 no vio la Limonada de B y se pasó todo lo que A veía a la cuenta aparte, con lo ya pagado, el enlace y el
    # teléfono (límite anotado de la red muy lenta)
    assert 2900 <= p["ms"] < 3600 and p["avisos"] == [] and p["hecho"] == [TODO_APARTE], r
    # la baja de la cuenta del pedido fue como la de un cobro: la que queda con la Limonada de B no conserva lo ya pagado (el enlace y el teléfono pueden
    # quedar en las dos: el servidor lo admite)
    assert p["cuentas"] == [_p(PED, LIMONADA1, 0), _p(PED + " · aparte", TRES, 1000)] and r["prepagos"] == [0, 1000], r
    # al cobrar las dos cuentas, lo pagado en línea se aplica una sola vez y entra a Bancos una sola vez («Pago en línea» por ₡1 000); la Limonada se cobra
    # entera; el primer comprobante sale como parte del pedido
    assert [x for x in r["pagos"] if x[1]] == [[1000, True]] and r["emitidos"] == [[1695, LIMONADA1], [6811, TRES]] and r["quedan"] == 0, r
    assert r["cuerpos"] == [{"pedido": 9, "parcial": True}, {"pedido": 9, "parcial": False}], r

    # antes de esta vuelta: la cuenta que quedaba con la Limonada conservaba lo ya pagado: al cobrarla se descontaba otra vez (la Limonada de ₡1 695 se
    # cobraba con ₡695) y se registraba en Bancos un segundo «Pago en línea» de ₡1 000
    v = _correr(tmp_path / "antes", casos, antes=_antes())["3500"]
    assert v["primero"]["cuentas"] == [_p(PED, LIMONADA1, 1000), _p(PED + " · aparte", TRES, 1000)] and v["prepagos"] == [1000, 1000], v
    assert [x for x in v["pagos"] if x[1]] == [[1000, True], [1000, True]], v


def test_q4_un_solo_equipo_pasa_todo_con_prepago_igual_que_antes_en_node(tmp_path):
    casos = CASOS_Q4.replace("@CASOS@", json.dumps([[0, True]])).replace("@TEL@", json.dumps(TEL))
    r = _correr(tmp_path / "ahora", casos)["0_solo"]
    # sin espera ni aviso: todo a la cuenta aparte con lo ya pagado (una vez) y la cuenta del pedido desaparece; al cobrar, un solo «Pago en línea»
    assert r["primero"]["ms"] < 1000 and r["primero"]["avisos"] == [] and r["primero"]["hecho"] == [TODO_APARTE], r
    assert r["primero"]["cuentas"] == [_p(PED + " · aparte", TRES, 1000)] and r["prepagos"] == [1000] and [x for x in r["pagos"] if x[1]] == [[1000, True]], r
    assert r["cuerpos"] == [{"pedido": 9, "parcial": False}] and r["emitidos"] == [[6811, TRES]] and r["quedan"] == 0, r
    # control: antes de esta vuelta era igual (salvo lo que tardó)
    v = _correr(tmp_path / "antes", casos, antes=_antes())["0_solo"]
    sin_ms = lambda x: {**x, "primero": {**x["primero"], "ms": None}}
    assert sin_ms(v) == sin_ms(r), v


# ================================================================================================================ Q5: el pedido aceptado aquí, en el programa
GUION_Q5 = r"""
const Q = { resp: null, toasts: [], sonidos: 0, espera: [], lista: [], sincs: 0 };
const sesion = { empresaInfo: @INFO@, tieneModulo: m => m === 'pedidos_online' };
const cta = (pid, num) => ({ id: 900 + pid, canal: 'online', pedido_id: pid, pedido_numero: num });
// el servidor: el resumen, la lista de pedidos y aceptar (la cuenta del pedido entra a la caja)
const api = async (url, op) => {
  if (url === '/api/pedidos/resumen') return Q.resp;
  if (url === '/api/pedidos') return Q.lista.map(p => ({ ...p }));
  const m = /^\/api\/pedidos\/(\d+)\/estado$/.exec(url);
  if (m) { const p = Q.lista.find(x => x.id === +m[1]); p.estado = 'confirmado'; Q.espera.push(cta(p.id, p.numero)); return { id: p.id, numero: p.numero, mensaje: 'Pedido #' + p.numero + ' aceptado.' }; }
  throw new Error('ruta ' + url);
};
const toast = (m, t) => Q.toasts.push(m);
const win = { AudioContext: function () { Q.sonidos++; throw new Error('sin audio en la prueba'); } };
const K = new Function('sesion', 'api', 'toast', 'enEspera', 'window', 'return { computed: {' + @COMP@ + '}, methods: {' + @MET@ + '} };')(sesion, api, toast, () => Q.espera, win);
const vm = { online: { nuevos: 0, ultimo: null, sinVer: 0 }, panelWeb: null, esperaCaja: [], _est: null, pago: null, sincronizar: async () => { Q.sincs++; }, recuperar() {} };
for (const [k, f] of Object.entries(K.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
for (const [k, f] of Object.entries(K.methods)) vm[k] = f.bind(vm);
// en la página web, «Imprimir comanda» usa la lógica de Ventas en línea › Pedidos (aquí, una que acepta y la cuenta entra a la caja)
const acep = { menu: true, impresion: { cfg: {}, impresoras: [] }, conComanda: true, async preparar() {}, async aceptarComo(p) { await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado' } }); return true; } };
vm.cargarAceptador = async () => { vm._acep = acep; return acep; };
const pasar = async () => { for (let i = 0; i < 30; i++) await new Promise(r => setImmediate(r)); };
// una consulta del resumen: los avisos, cuántas veces sonó y el número del botón «Pedidos web» (avisoWeb)
const vuelta = async resp => { Q.resp = resp; Q.toasts = []; const s0 = Q.sonidos; await vm.revisarOnline(); await pasar(); return { avisos: Q.toasts.slice(), sonidos: Q.sonidos - s0, boton: vm.avisoWeb }; };
const out = {};
out.primera = await vuelta({ nuevos: 0, ultimo_id: 40, ultimo_entrado_id: 40 });
// entra el pedido #41 (nuevo)
Q.lista = [{ id: 41, numero: 41, estado: 'nuevo', nombre: 'Cliente QA', lineas: [] }];
out.entra41 = await vuelta({ nuevos: 1, ultimo_id: 41, ultimo_entrado_id: 40 });
// se abre «Pedidos web», se acepta el #41 («Imprimir comanda») y se cierra la ventana
vm.abrirPanelWeb(); for (let i = 0; i < 100 && (vm.panelWeb.cargando || vm.panelWeb.listo === false); i++) await pasar();
Q.toasts = []; const s0 = Q.sonidos;
await vm.imprimirComandaWeb(vm.panelWeb.lista[0]); await pasar();
out.aceptado = { avisos: Q.toasts.slice(), sonidos: Q.sonidos - s0, boton: vm.avisoWeb, estado: Q.lista[0].estado, cuentas: Q.espera.map(v => v.pedido_id) };
vm.panelWeb = null;
// la consulta siguiente: la cuenta del #41 ya entró a la caja (ultimo_entrado_id = 41)
out.entro41 = await vuelta({ nuevos: 0, ultimo_id: 41, ultimo_entrado_id: 41 });
// el #42 entra y lo acepta otra caja: su cuenta entra a esta
Q.lista.push({ id: 42, numero: 42, estado: 'nuevo', nombre: 'Cliente QA', lineas: [] });
out.entra42 = await vuelta({ nuevos: 1, ultimo_id: 42, ultimo_entrado_id: 41 });
Q.lista[1].estado = 'confirmado'; Q.espera.push(cta(42, 42));
out.entro42 = await vuelta({ nuevos: 0, ultimo_id: 42, ultimo_entrado_id: 42 });
out.avisados = vm._entAvisados ? [...vm._entAvisados].sort() : null;
console.log(JSON.stringify(out));
"""


def _q5(tmp_path, programa, antes=False):
    """Corre GUION_Q5 en el programa (enProgWeb y pedidos_programa) o en la página web; con `antes`, con imprimirComandaWeb (y aceptarWeb) de antes de
    esta vuelta."""
    k = _caja()
    met = _metodos() + _tramo(k, "    async revisarOnline() {", "\n    // 3.87:")
    if antes:
        # 4.39 (decimotercera vuelta): también aceptarWeb como estaba antes de esta vuelta (sin la línea de V1): desde la decimotercera, aceptarWeb anota el
        # pedido en _entAvisados en cuanto el PUT sale bien, y con el de ahora el control «antes» ya no mostraba el defecto que arregló Q5
        k0 = _caja_sin_undecima()
        met += "    " + _metodo(k0, "async imprimirComandaWeb(p) {") + ",\n    " + _metodo(k0, "async aceptarWeb(p) {") + ",\n"
    info = {"es_local": True, "pedidos_programa": True} if programa else {}
    guion = GUION_Q5.replace("@INFO@", json.dumps(info)).replace("@COMP@", json.dumps(_computadas())).replace("@MET@", json.dumps(met))
    tmp_path.mkdir(parents=True, exist_ok=True)
    return _node(tmp_path, guion)


def test_q5_en_el_programa_el_pedido_aceptado_aqui_no_vuelve_a_avisar_en_node(tmp_path):
    r = _q5(tmp_path / "ahora", programa=True)
    nuevo = "Entró un pedido en línea: tóquelo en «🌐 Pedidos web» para verlo."
    assert r["primera"] == {"avisos": [], "sonidos": 0, "boton": 0}, r
    # entra el #41: el aviso, el sonido y el botón en 1; aceptado en esta caja («Imprimir comanda»), el botón deja de contarlo
    assert r["entra41"] == {"avisos": [nuevo], "sonidos": 1, "boton": 1}, r
    assert r["aceptado"] == {"avisos": ["Pedido #41 aceptado."], "sonidos": 0, "boton": 0, "estado": "confirmado", "cuentas": [41]}, r
    # la consulta siguiente (su cuenta ya entró a la caja: ultimo_entrado_id = 41): sin aviso, sin sonido y el botón en 0
    assert r["entro41"] == {"avisos": [], "sonidos": 0, "boton": 0}, r
    # el #42, aceptado en otra caja, sí avisa al entrar a esta, suena y cuenta 1
    assert r["entra42"] == {"avisos": [nuevo], "sonidos": 1, "boton": 1}, r
    assert r["entro42"] == {"avisos": ["Entró a la caja el pedido en línea #42."], "sonidos": 1, "boton": 1} and r["avisados"] == [41, 42], r

    # antes de esta vuelta: cuando la cuenta del #41 entraba a la caja sonaba, avisaba y el botón se volvía a poner rojo (y con el #42, en 2)
    v = _q5(tmp_path / "antes", programa=True, antes=True)
    assert v["aceptado"] == r["aceptado"], v
    assert v["entro41"] == {"avisos": ["Entró a la caja el pedido en línea #41."], "sonidos": 1, "boton": 1} and v["entro42"]["boton"] == 2, v


def test_q5_en_la_pagina_web_nada_cambia_en_node(tmp_path):
    r = _q5(tmp_path / "ahora", programa=False)
    # en la página web no se avisa lo que entra a la caja (eso es del programa) ni se anota nada: aceptar el #41 lo deja de contar y nada más
    assert r["aceptado"] == {"avisos": [], "sonidos": 0, "boton": 0, "estado": "confirmado", "cuentas": [41]}, r
    assert r["entro41"] == {"avisos": [], "sonidos": 0, "boton": 0} and r["entro42"] == {"avisos": [], "sonidos": 0, "boton": 0} and r["avisados"] is None, r
    # control: antes de esta vuelta era igual
    assert _q5(tmp_path / "antes", programa=False, antes=True) == r


# ================================================================================================================ contrato
REFRESCAR3 = "try { await Promise.race([mock.refrescar(['pos_espera'], { sinCorte: true }).catch(() => {}), new Promise(r => setTimeout(r, 3000))]); } catch { /* sigue con la copia */ }"


def test_contrato_de_la_undecima_vuelta():
    # 4.39 (duodécima vuelta): la undécima se compara contra caja.js sin la duodécima (la duodécima cambió la línea de Q5 en imprimirComandaWeb y metió
    # su comentario entre el de Q5 y esa línea; su contrato está en tests/test_439_duodecima_vuelta.py)
    k, k0 = _caja_sin_duodecima(), _caja_sin_undecima()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    cd, web = metodos["async confirmarDividir() {"], metodos["async imprimirComandaWeb(p) {"]
    # cada tripleta de UNDECIMA: «lo de ahora» está en caja.js las veces anotadas, en su método (Q5, la última, en imprimirComandaWeb; las demás en
    # confirmarDividir); «lo de antes» ya no está, salvo dentro de «lo de ahora» (Q3 agrega líneas antes de una que sigue); los dos métodos cambiaron
    assert len(UNDECIMA) == 7
    for i, (viejo, nuevo, veces) in enumerate(UNDECIMA):
        assert k.count(nuevo) == veces and k0.count(viejo) == veces and k0.count(nuevo) == 0, nuevo[:120]
        assert k.count(viejo) == (veces if viejo in nuevo else 0), nuevo[:120]
        assert (web if i == 6 else cd).count(nuevo) == veces, nuevo[:120]
    for c in metodos:
        assert metodos[c] != antes[c], c
    # fuera de ellos, caja.js no cambió
    resto, resto0 = k, k0
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], ""), resto0.replace(antes[c], "")
    assert resto == resto0
    # lo de la vuelta lleva su comentario (Q1 y Q2, Q3, Q4 y Q5)
    assert k.count("4.39 (undécima vuelta)") == 4 and k0.count("4.39 (undécima vuelta)") == 0
    # Q1: las tres consultas de confirmarDividir esperan hasta 3 s; ya no queda ni el tope de 1,5 s ni el de R1 (3 s solo con platos por enviar)
    assert cd.count(REFRESCAR3) == 3 and "setTimeout(r, 1500)" not in cd and "? 3000 : 1500" not in cd
    assert cd.index(REFRESCAR3) < cd.index("const espero = ") < cd.index("if (espero) {") < cd.find(REFRESCAR3, cd.index("if (espero) {")) \
        < cd.index("if (!this.esRestaurante) { " + REFRESCAR3 + " if (this.dividir !== d || this.esperaId !== idx) return; }")
    # Q2: justo después de la primera consulta, antes de mirar «vistos»
    assert cd.count(REFRESCAR3 + " if (this.dividir !== d || this.esperaId !== id1) return; const c1 = enEspera().find(v => v.id === id1),") == 1
    # Q3: después de la regla del prepago (4.9) y antes de «Cobrar estos platos»; avisa sin cerrar «Dividir»
    q3 = "if (!resto.length && d.destino !== 'cobrar' && d.destino !== 'nueva' && c0 && c0.canal === 'online') return toast('" + NO_A_MESA + "', 'err');"
    assert cd.count(q3) == 1 and cd.index("no se puede pasar todo a una mesa; páselo a una cuenta aparte o cóbrelo aquí") < cd.index(q3) < cd.index("if (d.destino === 'cobrar') {")
    # Q4: la baja de la cuenta que quedó vacía va como la de un cobro solo si lo ya pagado se fue con todo a la cuenta aparte
    assert cd.count("this.bajaCuenta(id, (this.baseDe(id, c0) || { lineas: [] }).lineas, this.nombreEspera, d.destino === 'nueva' && pre0 > 0);") == 1
    # Q5: en el programa, aceptado aquí, se anota como ya avisado (el Set que mira avisarEntrados), antes de bajar el número del botón
    q5 = "if (ok) (this._entAvisados || (this._entAvisados = new Set())).add(+p.id);"
    assert web.count(q5) == 1 and web.index("const ok = await this.aceptarWeb(p);") < web.index(q5) < web.index("if (ok && eraNuevo && this.online === o0)")
    assert "!this._entAvisados.has(id)" in _metodo(k, "async avisarEntrados(r) {")
    # las notas de la versión cuentan la vuelta: «Aceptar pedido» cuando no sale comanda, Q3 en «Dividir», el límite de la red muy lenta reescrito y Técnico
    # (la undécima vuelta y la lista de pruebas hasta este archivo)
    # 4.39 (duodécima vuelta): el comienzo del límite de la red muy lenta (ahora dice también lo de las partes iguales de una mesa) y la lista de pruebas de
    # Técnico (ahora hasta test_439_duodecima_vuelta.py) cambiaron en la duodécima: salen de aquí; lo que sigue igual de ese límite se exige abajo y las
    # frases nuevas, en el contrato de la duodécima
    notas = (RAIZ / "notas" / "4.39.md").read_text(encoding="utf-8")
    for t in ("(si no sale comanda, por ejemplo sin impresora de cocina, en una caja que no imprime comandas o en una tienda, el botón dice «Aceptar pedido» y solo lo acepta)",
              "Un pedido en línea ya no se puede pasar entero a una mesa, como ya pasaba con uno pagado en línea: se cobra desde «Para llevar en espera» o se pasa a una cuenta aparte",
              "lo que otro equipo acaba de hacer en la cuenta puede no verse al dividir: lo que mandó a "
              "cocina puede volver a salir, y lo que cobró o quitó puede quedar también en la cuenta aparte, en la otra mesa o en las partes. Revise las cuentas antes de cobrarlas.",
              "Undécima vuelta: esa espera de hasta 3 s vale para las tres consultas de confirmarDividir (también sin platos por enviar, con «Cobrar estos platos» y en la caja de comercio)",
              "pasar todo un pedido con prepago a una cuenta aparte da de baja la de origen como un cobro",
              "un pedido en línea no se pasa entero a una mesa; en el programa, el pedido aceptado ahí se anota en _entAvisados"):
        assert notas.count(t) == 1, t
    # y ya no dicen lo de antes
    for t in ("esos platos pueden volver a salir a cocina.", "de test_439_segunda_vuelta.py a test_439_decima_vuelta.py",
              "la cuenta queda en «Para llevar en espera»; el cliente ve el pedido en preparación"):
        assert notas.count(t) == 0, t
