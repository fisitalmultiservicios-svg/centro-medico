"""3.87: más rápido sin cambiar ningún resultado.
- /api/ia/config y el catálogo público ya no importan el SDK de IA (varios segundos en la primera visita de cada proceso) cuando no hay
  llave; con llave tampoco hace falta importarlo para saber si está disponible.
- Los archivos fijos (JS, CSS, HTML) salen comprimidos con gzip y se buscan antes que las rutas de la API; lo que ya trae
  Content-Encoding (la vía rápida _json_rapido) no se vuelve a comprimir.
- /api/pagos y el resumen / reporte ejecutivo van por la vía rápida (mismo JSON, con gzip).
- /api/resumen e /api/inicio/alertas leen solo las columnas que usan: mismas cifras que con los objetos completos.
- La caja pide al servidor solo los comprobantes del cliente con saldo para el fiado.
- Service worker: mientras no cambie ningún archivo del programa no revalida cada archivo; el servidor le pone la huella de los
  archivos (si se instaló mientras se extraía una entrega, se instala de nuevo al terminar). VERSION existe y tiene el formato de siempre.
- Las bases por empresa guardan la huella de su esquema: si ya está al día no se revisan tabla por tabla en cada arranque; una base
  vieja o restaurada de otra versión sí se migra.
- reportlab, qrcode y signxml se importan al usarse, no al arrancar."""
import contextlib
import gzip
import json
import os
import re
import sqlite3
import subprocess
import sys
import types
import zipfile
from pathlib import Path

import pytest
from fastapi.encoders import jsonable_encoder
from sqlmodel import Session, select

from app import auth, db, ia, modulos, recepcion, resumen
from app.db import Documento, DocumentoLinea, Empresa, engine, engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

RAIZ = Path(__file__).resolve().parents[1]
STATIC = RAIZ / "app" / "static"


def _ctx():
    from app.main import app
    return app.dependency_overrides[auth.contexto]()


def _doc(eid, n, **kw):
    base = dict(empresa_id=eid, tipo_documento="01", clave=f"506{eid:05d}{n:042d}", consecutivo=f"00100001{kw.get('tipo_documento', '01')}{n:010d}",
                fecha_emision="2026-11-02T10:00:00-06:00", ambiente="sandbox", estado="aceptado", moneda="CRC", tipo_cambio=1, total=1000.0,
                impuesto=115.04, condicion_venta="01")
    base.update(kw)
    return Documento(**base)


def _sembrar(eid):
    """Comprobantes de todos los tipos y casos que recorre el resumen (contado, crédito vigente y vencido, dólares, notas, compra,
    exportación, REP, rechazado, otros cargos) para comparar las cifras con objetos completos y con columnas."""
    oc = json.dumps([{"tipo": "06", "detalle": "Impuesto de servicio", "porcentaje": 10, "monto": 90.9}])
    docs = [_doc(eid, 1, cliente_id=1, receptor_nombre="Cliente Uno", vendedor="ana@example.test", otros_cargos=oc),
            _doc(eid, 2, cliente_id=1, receptor_nombre="Cliente Uno", condicion_venta="02", fecha_vencimiento="2026-10-20", total=5000.0, pagado=1000.0),
            _doc(eid, 3, cliente_id=2, receptor_nombre="Cliente Dos", condicion_venta="02", fecha_vencimiento="2026-12-30", total=2500.0, moneda="USD", tipo_cambio=505.5),
            _doc(eid, 4, tipo_documento="04", total=800.0, sucursal_id=None),
            _doc(eid, 5, tipo_documento="03", cliente_id=1, receptor_nombre="Cliente Uno", total=300.0, impuesto=34.51),
            _doc(eid, 6, tipo_documento="08", receptor_nombre="Proveedor FEC", total=1200.0, impuesto=138.05),
            _doc(eid, 7, tipo_documento="09", cliente_id=2, receptor_nombre="Cliente Dos", total=700.0, impuesto=0, condicion_venta="02", fecha_vencimiento="2026-11-03"),
            _doc(eid, 8, tipo_documento="10", total=0, impuesto=50.0),
            _doc(eid, 9, estado="rechazado", total=999.0),
            _doc(eid, 10, tipo_documento="02", cliente_id=1, receptor_nombre="Cliente Uno", total=150.0, condicion_venta="10", fecha_emision="2026-10-05T09:00:00-06:00"),
            _doc(eid, 11, cliente_id=2, receptor_nombre="Cliente Dos", condicion_venta="02", total=400.0, acreditado=150.0, fecha_vencimiento="2026-11-30", fecha_emision="2026-10-10T08:00:00-06:00"),
            _doc(eid, 12, estado="firmado", total=10.0)]
    with Session(engine_empresa(eid)) as s:
        for d in docs:
            s.add(d)
        s.commit()
        ids = [d.id for d in s.exec(select(Documento).where(Documento.empresa_id == eid)).all()]
        for i, did in enumerate(ids):
            s.add(DocumentoLinea(documento_id=did, numero=1, producto_id=(i % 3) or None, cabys="8314100000000", detalle=f"Servicio {i % 4}",
                                 cantidad=1 + i % 2, unidad_medida="Sp", precio_unitario=100.0 + i, total=113.0 + i, impuesto=13.0, tarifa=13))
        s.add(recepcion.Recibido(empresa_id=eid, clave="5" * 50, tipo_documento="01", emisor_nombre="Proveedor A", fecha_emision="2026-11-01",
                                 total=2260.0, impuesto=260.0, iva=260.0, respuesta="05", monto_impuesto_acreditar=260.0))
        s.add(recepcion.Recibido(empresa_id=eid, clave="6" * 50, tipo_documento="03", emisor_nombre="Proveedor A", fecha_emision="2026-11-02",
                                 total=113.0, impuesto=13.0, iva=13.0, respuesta="05", referencia_clave="5" * 50))
        s.commit()
    return ids


# ------------------------------------------------------------------------------------------------ IA sin importar el SDK
def test_ia_config_no_importa_el_sdk(api, monkeypatch, tmp_path):  # noqa: F811
    c = api
    monkeypatch.setattr(ia, "ARCHIVO", tmp_path / "ia.json")
    monkeypatch.setattr(ia, "anthropic", None)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    def _prohibido():
        raise AssertionError("no debe importar el SDK para saber si el asistente está disponible")
    monkeypatch.setattr(ia, "_sdk", _prohibido)
    r = c.get("/api/ia/config")
    assert r.status_code == 200, r.text
    assert r.json()["disponible"] is False
    # con llave: disponible según el paquete instalado (sin importarlo)
    monkeypatch.setattr(ia, "credenciales", lambda: "sk-ant-prueba-387")
    monkeypatch.setattr(ia, "_instalado", None)
    import importlib.util
    instalado = importlib.util.find_spec("anthropic") is not None
    assert c.get("/api/ia/config").json()["disponible"] is instalado
    monkeypatch.setattr(ia, "_instalado", False)
    assert c.get("/api/ia/config").json()["disponible"] is False
    assert ia._resumen_config()["paquete"] is False
    monkeypatch.setattr(ia, "anthropic", object())                        # ya importado: cuenta como instalado
    assert ia.disponible() is True and ia._resumen_config()["paquete"] is True


def test_ia_config_en_un_proceso_nuevo_no_carga_el_sdk(tmp_path):
    codigo = ("import os, sys, types\n"
              "from fastapi.testclient import TestClient\n"
              "from app import auth\n"
              "from app.main import app\n"
              "from app.db import Empresa, engine, init_db\n"
              "from sqlmodel import Session\n"
              "init_db()\n"
              "with Session(engine) as s:\n"
              "    e = Empresa(nombre='IA 387', numero_id='3101387387', actividad='620100', ambiente='sandbox'); s.add(e); s.commit(); s.refresh(e)\n"
              "u = types.SimpleNamespace(id=None, correo='ia387@example.test', es_superadmin=False, nombre='QA')\n"
              "app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(u, e, 'Administrador')\n"
              "r = TestClient(app).get('/api/ia/config')\n"
              "print(r.status_code, r.json()['disponible'], 'anthropic' in sys.modules)\n")
    env = {**os.environ, "FE_DATA_DIR": str(tmp_path), "FE_DB_URL": f"sqlite:///{(tmp_path / 'f.db').as_posix()}", "FE_COLA_HILO": "0", "FE_SINC_HILO": "0",
           "PYTHONDONTWRITEBYTECODE": "1"}
    env.pop("ANTHROPIC_API_KEY", None)
    r = subprocess.run([sys.executable, "-c", codigo], cwd=str(RAIZ), capture_output=True, text=True, timeout=180, env=env)
    assert r.returncode == 0, r.stderr[-800:]
    assert r.stdout.strip().splitlines()[-1] == "200 False False"


# ------------------------------------------------------------------------------------------------ archivos fijos con gzip
def test_estaticos_con_gzip_y_antes_de_la_api(api):  # noqa: F811
    from starlette.routing import Mount
    from app.main import app
    c = api
    original = (STATIC / "js" / "app.js").read_bytes()
    r = c.get("/js/app.js", headers={"Accept-Encoding": "gzip"})
    assert r.status_code == 200 and r.headers["content-encoding"] == "gzip" and r.headers["vary"] == "Accept-Encoding"
    assert r.content == original and int(r.headers["content-length"]) < len(original) // 2      # el cliente lo descomprime: mismo archivo
    assert r.headers["cache-control"] == "no-cache" and r.headers["content-type"].startswith("text/javascript")
    sin = c.get("/js/app.js", headers={"Accept-Encoding": "identity"})
    assert sin.headers.get("content-encoding") is None and sin.content == original and sin.headers["etag"] == r.headers["etag"]
    assert c.get("/js/app.js", headers={"Accept-Encoding": "gzip", "If-None-Match": r.headers["etag"]}).status_code == 304
    assert c.head("/js/app.js", headers={"Accept-Encoding": "gzip"}).headers.get("content-encoding") is None
    v = c.get("/js/vendor/vue.esm-browser.prod.min.js", headers={"Accept-Encoding": "gzip"})
    assert v.headers["content-encoding"] == "gzip" and v.headers["cache-control"] == "public, max-age=604800"
    for ruta in ("/ui.css", "/fisitaap/assets/app.bundle.css", "/sw-app.js"):
        x = c.get(ruta, headers={"Accept-Encoding": "gzip"})
        assert x.status_code == 200 and x.headers["content-encoding"] == "gzip", ruta
    f = c.get("/fonts/inter-latin.woff2", headers={"Accept-Encoding": "gzip"})
    assert f.status_code == 200 and f.headers.get("content-encoding") is None                    # ya viene comprimida
    pagina = c.get("/app/", headers={"Accept-Encoding": "gzip"})
    assert pagina.status_code == 200 and "Content-Security-Policy" in pagina.headers and pagina.headers["cache-control"] == "no-cache"
    assert c.get("/app/fisitaap/").status_code == 200 and c.get("/js/no-existe.js").status_code == 404
    redir = c.get("/app", follow_redirects=False)
    assert redir.status_code in (301, 307) and redir.headers["location"].endswith("/app/")
    # los archivos fijos van antes que las rutas de la API
    primeros = [x.path for x in app.router.routes[:5] if isinstance(x, Mount)]
    assert set(primeros) == {"/js", "/fonts", "/img", "/fisitaap", "/app"}
    # lo que ya viene comprimido (vía rápida) no se comprime dos veces: el cliente lo lee con una sola descompresión
    _sembrar(_ctx().empresa.id)                                         # más de 1 KB: _json_rapido sí lo comprime
    j = c.get("/api/comprobantes", headers={"Accept-Encoding": "gzip"})
    assert j.status_code == 200 and j.headers["content-encoding"] == "gzip" and len(j.content) > 1024
    assert len(j.json()) == 12 and all(d["clave"].startswith("506") for d in j.json())


def test_json_rapido_sin_nan():
    from app import main
    req = types.SimpleNamespace(headers={"accept-encoding": "identity"})
    r = main._json_rapido(req, {"a": float("nan"), "b": [1.5, float("inf")], "c": "ñ"})
    assert json.loads(r.body) == {"a": 0.0, "b": [1.5, 0.0], "c": "ñ"}                          # antes salía «NaN», que el navegador no lee
    assert main._json_rapido(req, {"a": 1}).body == b'{"a":1}'


# ------------------------------------------------------------------------------------------------ pagos y resumen: mismo JSON
def test_pagos_por_la_via_rapida_mismo_json(api):  # noqa: F811
    c = api
    eid = _ctx().empresa.id
    with Session(engine_empresa(eid)) as s:
        for n in range(1, 41):
            s.add(modulos.Pago(empresa_id=eid, numero=n, tipo="caja", cliente_id=1, cliente_nombre="Cliente «Ñandú»", fecha=f"2026-11-{1 + n % 4:02d}",
                               cuenta="Caja", monto=1000.5 + n, notas="x" * 40, facturas=json.dumps([{"id": n, "consecutivo": f"0010000101{n:010d}", "monto": 10.25}])))
        s.commit()
        filas = s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == eid)).all()
        esperado = json.loads(json.dumps(jsonable_encoder([modulos.pago_dict(p) for p in sorted(filas, key=lambda p: p.numero, reverse=True)])))
    r = c.get("/api/pagos", headers={"Accept-Encoding": "gzip"})
    assert r.status_code == 200 and r.headers.get("content-encoding") == "gzip" and r.headers["cache-control"] == "no-store"
    assert r.json() == esperado
    r2 = c.get("/api/pagos", headers={"Accept-Encoding": "identity"})
    assert r2.headers.get("content-encoding") is None and r2.json() == esperado and r2.headers["content-type"] == "application/json"


def test_resumen_y_alertas_con_columnas_mismas_cifras(api, monkeypatch):  # noqa: F811
    from app import main
    c = api
    eid = _ctx().empresa.id
    _sembrar(eid)
    rutas = ["/api/inicio/alertas", "/api/resumen?periodo=mes", "/api/resumen?periodo=anio", "/api/resumen?detalle=1&periodo=rango&desde=2026-01-01&hasta=2026-12-31"]
    nuevos = {}
    for ruta in rutas:
        r = c.get(ruta, headers={"Accept-Encoding": "identity"})
        assert r.status_code == 200, (ruta, r.text)
        nuevos[ruta] = r.content
    gz = c.get(rutas[-1], headers={"Accept-Encoding": "gzip"})
    assert gz.headers.get("content-encoding") == "gzip" and gz.content == nuevos[rutas[-1]]       # reporte ejecutivo con gzip
    # el mismo cálculo con los objetos completos (como antes de 3.87) da exactamente el mismo JSON
    monkeypatch.setattr(main, "_filas", lambda s, modelo, columnas, *cond: s.exec(select(modelo).where(*cond)).all())
    for ruta in rutas:
        viejo = c.get(ruta, headers={"Accept-Encoding": "identity"})
        assert json.loads(viejo.content) == json.loads(nuevos[ruta]), ruta
        assert viejo.content == nuevos[ruta], ruta
    j = json.loads(nuevos[rutas[-1]])
    assert j["cxc"]["docs"] >= 3 and j["devoluciones_docs"] == 1 and j["egresos_docs"] >= 2 and j["detalle"]["ventas"]
    assert json.loads(nuevos[rutas[0]])["flujo"]["vencido"] > 0


def test_calcular_solo_usa_las_columnas_leidas():
    """resumen.calcular con filas de solo _COLS_RESUMEN / _COLS_LINEAS_RESUMEN da lo mismo que con los objetos completos; si algún día
    usa otra columna, _Fila da un error (no un None que cambie las cifras en silencio)."""
    from datetime import date
    from app import main
    with pytest.raises(LookupError):
        getattr(main._Fila(total=1), "pagado", 0)
    docs = [d for d in (_doc(1, n, id=n) for n in range(1, 13))]
    for d, extra in zip(docs, [{}, {"condicion_venta": "02", "fecha_vencimiento": "2026-10-01", "pagado": 10.0}, {"moneda": "USD", "tipo_cambio": 500.0, "condicion_venta": "02"},
                               {"tipo_documento": "03"}, {"tipo_documento": "08"}, {"tipo_documento": "10", "impuesto": 9.0}, {"tipo_documento": "09", "condicion_venta": "10"},
                               {"estado": "rechazado"}, {"tipo_documento": "02", "acreditado": 5.0, "condicion_venta": "08"}, {"otros_cargos": json.dumps([{"monto": 3.5}])},
                               {"tipo_documento": "04", "receptor_nombre": None}, {"vendedor": "v@example.test"}]):
        for k, v in extra.items():
            setattr(d, k, v)
    lineas = [DocumentoLinea(documento_id=d.id, numero=1, producto_id=d.id % 3 or None, cabys="1", detalle=f"D{d.id % 2}", cantidad=1.5, unidad_medida="Unid",
                             precio_unitario=10, total=11.3, impuesto=1.3) for d in docs]
    rec = [recepcion.Recibido(empresa_id=1, clave="7" * 50, emisor_nombre="P", fecha_emision="2026-11-01", total=100, iva=13, respuesta="06", monto_gasto_aplicable=50)]
    compras = [{"id": 1, "numero": "C-1", "proveedor": "P2", "creacion": "2026-11-01", "total": 226, "pagado": 0, "moneda": "CRC", "lineas": [{"cantidad": 2, "precio_unitario": 100, "tarifa": 13}]}]
    filas = [main._Fila(**{k: getattr(d, k) for k in main._COLS_RESUMEN}) for d in docs]
    flineas = [main._Fila(**{k: getattr(x, k) for k in main._COLS_LINEAS_RESUMEN}) for x in lineas]
    hoy = date(2026, 11, 5)
    for detalle in (False, True):
        a = resumen.calcular(docs, lineas, rec, compras, "2026-01-01", "2026-12-31", "2025-01-01", "2025-12-31", 505.0, hoy, con_detalle=detalle)
        b = resumen.calcular(filas, flineas, rec, compras, "2026-01-01", "2026-12-31", "2025-01-01", "2025-12-31", 505.0, hoy, con_detalle=detalle)
        assert json.dumps(a) == json.dumps(b)


# ------------------------------------------------------------------------------------------------ fiado de la caja
def test_fiado_filtrado_en_el_servidor(api):  # noqa: F811
    c = api
    eid = _ctx().empresa.id
    _sembrar(eid)
    todos = c.get("/api/comprobantes", headers={"Accept-Encoding": "identity"}).json()
    for cid in (1, 2):
        r = c.get(f"/api/comprobantes?cliente_id={cid}&con_saldo=1")
        assert r.status_code == 200
        ids = {d["id"] for d in r.json()}
        # lo que la caja calcula con la lista completa (saldoFiado en pos/caja.js) sale igual con la lista filtrada
        caja = {d["id"] for d in todos if d["cliente_id"] == cid and d["tipo_documento"] in ("01", "04") and d["estado"] != "rechazado"
                and (d["condicion_venta"] or "01") != "01" and round(d["total"] - d["pagado"] - d["acreditado"], 2) > 0.005}
        assert caja and caja <= ids and all(d["cliente_id"] == cid for d in r.json())
        assert all(d["total"] - d["pagado"] - d["acreditado"] > 0.004 for d in r.json())
    assert len(c.get("/api/comprobantes?cliente_id=1").json()) == sum(1 for d in todos if d["cliente_id"] == 1)
    js = (STATIC / "js" / "pages" / "pos" / "caja.js").read_text(encoding="utf-8")
    assert "async saldoFiado(cid) { const docs = await api('/api/comprobantes' + (cid != null ? '?cliente_id=' + encodeURIComponent(cid) + '&con_saldo=1' : ''));" in js


# ------------------------------------------------------------------------------------------------ service worker
def test_service_worker_version_y_cache_sin_revalidar():
    from app import version
    sw = (STATIC / "sw-app.js").read_text(encoding="utf-8")
    m = re.search(r"^const VERSION = 'app-v(\d+\.\d+)';$", sw, re.M)
    assert m, "sw-app.js debe declarar const VERSION = 'app-vX.YY'; (cada entrega la cambia: así se renueva la caché del programa)"
    assert m.group(1) == version.actual()["version"]
    assert sw.count("const VERSION") == 1 and sw.count("const HUELLA = '';") == 1 and "const ESTATICO = VERSION + HUELLA + ':estatico', API = VERSION + ':api';" in sw
    # mientras HUELLA no cambie, lo guardado del programa se sirve sin volver a preguntar (salvo la página, un servidor local de desarrollo
    # o el archivo servido sin huella)
    i_cache = sw.index("if (guardado && !esPagina && !DESARROLLO && HUELLA && PROPIO.test(u.pathname)) return guardado;")
    assert i_cache < sw.index("const red = fetch(req)")
    assert "const DESARROLLO = ['localhost', '127.0.0.1', '[::1]'].includes(self.location.hostname);" in sw
    assert r"const PROPIO = /^\/(js|fonts|img|fisitaap)\/|^\/[^/]+\.(css|js)$/;" in sw
    # al instalar se pide al servidor (no a la caché HTTP de 7 días) y se borra el programa guardado con otra huella
    assert "c.add(new Request(u, { cache: 'no-cache' }))" in sw and "k.startsWith('app-v') && k !== ESTATICO && k !== API" in sw
    js = (STATIC / "js" / "api.js").read_text(encoding="utf-8")
    assert "navigator.serviceWorker.register('/sw-app.js')" in js and "window.addEventListener('load', registrar, { once: true })" in js


def test_service_worker_con_la_huella_del_programa(api, monkeypatch, tmp_path):  # noqa: F811
    """Revisión de 3.87: dentro de una versión el service worker ya no revalida, así que si se instalaba mientras se extraía la entrega
    (sw-app.js nuevo, app.js todavía viejo) quedaba con el archivo viejo hasta la versión siguiente. /sw-app.js sale con la huella de los
    archivos del programa: si uno cambia, cambia el service worker y el navegador guarda el programa otra vez."""
    from app import main
    c = api
    monkeypatch.setattr(main, "_HUELLA_SW", {"t": None, "h": ""}, raising=False)
    archivo = (STATIC / "sw-app.js").read_text(encoding="utf-8")
    r = c.get("/sw-app.js", headers={"Accept-Encoding": "identity"})
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/javascript") and r.headers["cache-control"] == "no-cache"
    m = re.search(r"^const HUELLA = '-([0-9a-f]{12})';", r.text, re.M)
    assert m, "el servidor debe llenar HUELLA"
    assert r.text == archivo.replace("const HUELLA = '';", f"const HUELLA = '-{m.group(1)}';")       # lo demás igual, VERSION incluida
    assert c.get("/sw-app.js", headers={"If-None-Match": r.headers["etag"]}).status_code == 304
    gz = c.get("/sw-app.js", headers={"Accept-Encoding": "gzip"})
    assert gz.headers["content-encoding"] == "gzip" and gz.text == r.text
    # con un programa propio en una carpeta temporal: un archivo que cambia (o uno nuevo) cambia la huella; por 10 s se reutiliza
    prog = tmp_path / "static"
    (prog / "js").mkdir(parents=True)
    (prog / "sw-app.js").write_text(archivo, encoding="utf-8")
    (prog / "js" / "app.js").write_text("// viejo\n", encoding="utf-8")
    monkeypatch.setattr(main, "STATIC", prog)
    main._HUELLA_SW["t"] = None
    h1 = main._huella_programa()
    (prog / "js" / "app.js").write_text("// nuevo, recién extraído\n", encoding="utf-8")
    assert main._huella_programa() == h1
    main._HUELLA_SW["t"] = None
    h2 = main._huella_programa()
    assert h2 != h1 and f"const HUELLA = '-{h2}';" in c.get("/sw-app.js").text
    (prog / "js" / "otro.js").write_text("// x\n", encoding="utf-8")
    main._HUELLA_SW["t"] = None
    assert main._huella_programa() not in (h1, h2)
    (prog / "sw-app.js").write_text(archivo.replace("const HUELLA = '';", "const HUELLA = 'x';"), encoding="utf-8")
    assert "const HUELLA = 'x';" in c.get("/sw-app.js").text                                         # sin el marcador sale tal cual


def test_archivos_sueltos_no_rompen_url_path_for():
    """_ArchivosRaiz va primero en las rutas: no debe impedir que app.url_path_for / request.url_for encuentren las demás (antes daba
    NotImplementedError para cualquier nombre)."""
    from app import main
    assert main.app.url_path_for("pagina_inicio") == "/" and main.app.url_path_for("static", path="ui.css") == "/ui.css"
    assert main.app.url_path_for("sw_app") == "/sw-app.js" and main.app.url_path_for("static_js", path="app.js") == "/js/app.js"
    assert main._ruta_de({"path": "/ui.css", "root_path": ""}) == "/ui.css"
    raiz = [x for x in main.app.router.routes if isinstance(x, main._ArchivosRaiz)]
    assert len(raiz) == 1 and "sw-app.js" not in raiz[0].nombres and "ui.css" in raiz[0].nombres


# ------------------------------------------------------------------------------------------------ migraciones por huella
def test_migracion_solo_si_cambio_el_esquema(api, monkeypatch):  # noqa: F811
    eid = _ctx().empresa.id
    ruta = db.EMPRESAS_DIR / f"empresa_{eid}.db"
    engine_empresa(eid)
    huella = db.huella_esquema()

    def _version():
        with sqlite3.connect(ruta) as cx:
            return cx.execute("PRAGMA user_version").fetchone()[0]

    def _columnas():
        with sqlite3.connect(ruta) as cx:
            return {r[1] for r in cx.execute("PRAGMA table_info(documento)")}

    def _soltar():
        hit = db._engines.pop(eid, None)
        if hit is not None:
            hit[0].dispose()
    assert huella > 0 and _version() == huella                          # empresa nueva: migrada y marcada
    llamadas = []
    orig = db._agregar_columnas_faltantes
    monkeypatch.setattr(db, "_agregar_columnas_faltantes", lambda eng, tablas: (llamadas.append(1), orig(eng, tablas))[1])
    _soltar(); engine_empresa(eid)
    assert llamadas == []                                               # al día: no revisa tabla por tabla
    # base vieja (o restaurada de otra versión): le falta una columna y trae otra huella -> se migra y se marca
    for marca in (0, 12345):
        _soltar()
        with sqlite3.connect(ruta) as cx:
            cx.execute("ALTER TABLE documento DROP COLUMN importado_de")
            cx.execute(f"PRAGMA user_version = {marca}")
        assert "importado_de" not in _columnas()
        engine_empresa(eid)
        assert "importado_de" in _columnas() and _version() == huella
    assert len(llamadas) == 2
    with Session(engine_empresa(eid)) as s:                             # la base sigue sirviendo
        assert s.exec(select(Documento)).all() is not None
    # cualquier tabla nueva cambia la huella
    from sqlalchemy import Column, Integer, MetaData, Table
    extra = Table("tabla_387_prueba", MetaData(), Column("id", Integer, primary_key=True))
    db.TABLAS_EMPRESA.append(extra)
    try:
        assert db.huella_esquema() != huella
    finally:
        db.TABLAS_EMPRESA.remove(extra)
    assert db.huella_esquema() == huella


def test_base_restaurada_se_migra_aunque_traiga_la_huella(api, tmp_path):  # noqa: F811
    """Revisión de 3.87: la base de un respaldo trae su PRAGMA user_version. Un respaldo editado a mano que diga tener la huella actual,
    pero sin una columna ni el índice único de consecutivos, quedaba como «al día». Al restaurar se borra la huella: se migra una vez."""
    from app import respaldo
    e = _ctx().empresa
    eid = e.id
    ruta = db.EMPRESAS_DIR / f"empresa_{eid}.db"
    nombre_db = f"data/empresas/empresa_{eid}.db"
    engine_empresa(eid)
    huella = db.huella_esquema()
    try:
        bueno = respaldo.ejecutar_empresa(e, forzar=True)
        base = tmp_path / "base.db"
        with zipfile.ZipFile(bueno) as z:
            base.write_bytes(z.read(nombre_db))
            otros = {n: z.read(n) for n in z.namelist() if n != nombre_db}
        with contextlib.closing(sqlite3.connect(base)) as cx:
            cx.execute("DROP INDEX IF EXISTS ux_documento_consecutivo")
            cx.execute("ALTER TABLE documento DROP COLUMN importado_de")
            cx.execute(f"PRAGMA user_version = {huella}")
            cx.commit()
        alterado = tmp_path / "alterado.zip"
        with zipfile.ZipFile(alterado, "w") as z:
            for n, b in otros.items():
                z.writestr(n, b)
            z.write(base, nombre_db)
        respaldo.restaurar_empresa(e, alterado)
        engine_empresa(eid)
        with contextlib.closing(sqlite3.connect(ruta)) as cx:
            columnas = {r[1] for r in cx.execute("PRAGMA table_info(documento)")}
            indices = {r[1] for r in cx.execute("PRAGMA index_list('documento')")}
            marca = cx.execute("PRAGMA user_version").fetchone()[0]
        assert "importado_de" in columnas and "ux_documento_consecutivo" in indices and marca == huella
    finally:
        for r in respaldo.listar_empresa(eid):
            respaldo.eliminar_empresa(eid, r["nombre"])


# ------------------------------------------------------------------------------------------------ importación diferida
def test_reportlab_y_signxml_se_importan_al_usarse(tmp_path):
    codigo = ("import sys, app.main\n"
              "print(sorted(m for m in ('reportlab', 'qrcode', 'signxml', 'anthropic') if m in sys.modules))\n"
              "from app import reportes\n"
              "from app.db import Empresa\n"
              "d = reportes.ReporteIn(titulo='Prueba 387', columnas=[{'key': 'a', 'label': 'A'}], filas=[{'a': 'uno'}])\n"
              "print(reportes._pdf(d, Empresa(nombre='Empresa 387', numero_id='3101387387', actividad='620100'), None)[:5])\n")
    env = {**os.environ, "FE_DATA_DIR": str(tmp_path), "FE_DB_URL": f"sqlite:///{(tmp_path / 'f.db').as_posix()}", "FE_COLA_HILO": "0", "PYTHONDONTWRITEBYTECODE": "1"}
    r = subprocess.run([sys.executable, "-c", codigo], cwd=str(RAIZ), capture_output=True, text=True, timeout=180, env=env)
    assert r.returncode == 0, r.stderr[-800:]
    lineas = r.stdout.strip().splitlines()
    assert lineas[-2] == "[]" and lineas[-1] == "b'%PDF-'"


def test_pdf_y_tiquete_siguen_saliendo():
    from app.fe import pdf
    d = pdf.datos_desde_json({"tipo": "cotizacion", "numero": "COT-387", "fecha": "2026-11-05", "moneda": "CRC", "emisor": {"nombre": "Empresa 387"},
                              "cliente": {"nombre": "Cliente 387"}, "lineas": [{"detalle": "Servicio", "cantidad": 2, "precio_unitario": 1500, "total": 3000}],
                              "totales": {"total": 3000}})
    assert pdf.render(d, {"campos": ["cliente", "lineas", "totales"]}).startswith(b"%PDF-")
    assert pdf._Canvas is not None and issubclass(pdf._Canvas, pdf._CanvasPaginas) and pdf.mm > 2.8
    d["clave"] = "5" * 50
    assert pdf.render_tiquete(d, 80).startswith(b"%PDF-")
