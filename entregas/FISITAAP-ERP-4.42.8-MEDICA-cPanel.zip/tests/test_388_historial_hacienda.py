# -*- coding: utf-8 -*-
"""3.88: historial de Hacienda en la tarjeta Salud. Cada verificación real queda en data/hacienda_historial.jsonl y la consola
muestra el % de respuestas de 7 días, las últimas 24 h, el tiempo típico y las caídas."""
import json
from datetime import datetime, timedelta, timezone

from app import cola, salud


def _linea(t, ok, ms=400, det=""):
    d = {"t": t.isoformat(timespec="seconds"), "amb": "produccion", "ok": ok, "ms": ms}
    if not ok:
        d["det"] = det
    return json.dumps(d)


def test_resumen_con_caidas(monkeypatch, tmp_path):
    archivo = tmp_path / "hist.jsonl"
    monkeypatch.setattr(cola, "HISTORIAL_FILE", archivo)
    ahora = datetime(2026, 11, 5, 18, 0, tzinfo=timezone.utc)
    l = [_linea(ahora - timedelta(days=8), False, det="vieja")]                 # fuera de los 7 días
    l += [_linea(ahora - timedelta(hours=30, minutes=5 * i), True) for i in range(10)]
    l += [_linea(ahora - timedelta(hours=10), False, det="Hacienda no responde (ConnectTimeout)"),
          _linea(ahora - timedelta(hours=9, minutes=55), False, det="Hacienda no responde (ConnectTimeout)"),
          _linea(ahora - timedelta(hours=9, minutes=30), True)]
    l += [_linea(ahora - timedelta(minutes=5), True, ms=300)]
    l += ['{"t": "otro ambiente", "amb": "sandbox", "ok": false}', "línea rota"]
    archivo.write_text("\n".join(l) + "\n", encoding="utf-8")
    h = salud.historial_hacienda("produccion", ahora=ahora)
    assert h["revisiones"] == 14 and h["caidas"] == 1
    assert "12 de 14" in h["valor"] and "1 caída(s)" in h["valor"]
    assert "ConnectTimeout" in h["accion"] and "(30 min)" in h["accion"]
    assert h["estado"] == "mal"                                                   # 85,7 % < 95 %
    assert "vieja" not in h["accion"]


def test_sin_datos_y_caida_en_curso(monkeypatch, tmp_path):
    archivo = tmp_path / "hist.jsonl"
    monkeypatch.setattr(cola, "HISTORIAL_FILE", archivo)
    assert salud.historial_hacienda("produccion")["estado"] == "info"
    ahora = datetime.now(timezone.utc)
    archivo.write_text("\n".join([_linea(ahora - timedelta(minutes=10 * i), True) for i in range(40, 0, -1)]
                                 + [_linea(ahora, False, det="503")]) + "\n", encoding="utf-8")
    h = salud.historial_hacienda("produccion")
    assert h["estado"] == "mal" and "sigue sin responder" in h["accion"]


def test_anotar_una_por_minuto_si_responde_y_siempre_las_fallas(monkeypatch, tmp_path):
    archivo = tmp_path / "hist.jsonl"
    monkeypatch.setattr(cola, "HISTORIAL_FILE", archivo)
    monkeypatch.setattr(cola, "_ult_hist", {})
    cola.anotar_historial("produccion", True, 350)
    cola.anotar_historial("produccion", True, 360)          # misma pasada, otra empresa: no se repite
    cola.anotar_historial("produccion", False, 30000, "timeout")
    cola.anotar_historial("produccion", False, 30000, "timeout")
    filas = [json.loads(x) for x in archivo.read_text(encoding="utf-8").splitlines()]
    assert [f["ok"] for f in filas] == [True, False, False] and filas[1]["det"] == "timeout"
    assert len(cola.leer_historial("produccion", datetime.now(timezone.utc) - timedelta(hours=1))) == 3


def test_la_tarjeta_salud_trae_la_fila_del_historial():
    src = open(salud.__file__, encoding="utf-8").read()
    assert 'fila(f"hacienda_hist_{amb}"' in src
