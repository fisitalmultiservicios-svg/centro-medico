"""3.58 (frente B): importar ítems desde Excel o CSV en el servidor (simular, crear, actualizar, errores), plantilla de Excel,
plantilla inicial de mesas para restaurantes y el enlace de ayuda (portal TiKe) en /api/sistema."""
import io

from openpyxl import Workbook, load_workbook
from sqlmodel import Session

from app import auth, importacion_items, modulos, sitio
from app.db import engine, engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture)


def _xlsx(filas, cab=importacion_items.COLUMNAS):
    wb = Workbook(); ws = wb.active; ws.title = "Ítems"; ws.append(list(cab))
    for f in filas:
        ws.append(f)
    buf = io.BytesIO(); wb.save(buf)
    return buf.getvalue()


def _subir(c, datos, nombre="items.xlsx", modo="crear", simular="0"):
    tipo = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" if nombre.endswith(".xlsx") else "text/csv"
    return c.post("/api/productos/importar", files={"archivo": (nombre, datos, tipo)}, data={"modo": modo, "simular": simular})


def test_leer_tarifa():
    lt = importacion_items.leer_tarifa
    assert lt("08") == {"codigo_tarifa": "08"} and lt("8") == {"codigo_tarifa": "08"} and lt("13%") == {"codigo_tarifa": "08"} and lt("0,5") == {"codigo_tarifa": "09"}
    assert lt("") == {"codigo_tarifa": "08", "defecto": True} and lt(None)["defecto"]
    assert "ambigua" in lt("0")["problema"] and "no válida" in lt("abc")["problema"] and "ningún" in lt("17")["problema"]
    assert importacion_items.numero("1.234,50") == 1234.5 and importacion_items.numero("89.90") == 89.9 and importacion_items.numero("") is None


def test_importar_excel_y_csv(api):  # noqa: F811
    c = api
    antes = len(c.get("/api/productos").json())
    # plantilla de Excel
    r = c.get("/api/productos/plantilla.xlsx"); assert r.status_code == 200 and r.headers["content-type"].startswith("application/vnd.openxml")
    wb = load_workbook(io.BytesIO(r.content)); assert wb.sheetnames == ["Ítems", "Instrucciones"] and wb["Ítems"]["A1"].value == "nombre" and wb["Ítems"].max_row == 4
    filas = [
        ["Cemento gris 50 kg", "CEM-50", "2395100000100", 9500, "Unid", "Producto", "08", "CRC", "Construcción", 7200, "Saco de 50 kg", 20, "si"],
        ["Consultoría contable", "SERV-01", "8231100000000", 45000, "h", "Servicio", "", "", "Servicios", None, None, None, "no"],
        ["CABYS malo", "X1", "123", 100, "", "", "08", "", "", "", "", "", ""],
        ["Tarifa ambigua", "X2", "2395100000100", 100, "", "", "0", "", "", "", "", "", ""],
        ["", "X3", "2395100000100", 100, "", "", "", "", "", "", "", "", ""],
    ]
    # simular: valida y no guarda nada
    r = _subir(c, _xlsx(filas), simular="1"); assert r.status_code == 200, r.text
    d = r.json(); assert d["simulado"] and d["creados"] == 2 and d["omitidos"] == 3 and len(d["errores"]) == 3 and d["filas"] == 5
    assert any("CABYS" in e for e in d["errores"]) and any("ambigua" in e for e in d["errores"]) and any("sin tarifa" in a for a in d["avisos"])
    assert len(c.get("/api/productos").json()) == antes
    # crear de verdad
    r = _subir(c, _xlsx(filas)); assert r.status_code == 200, r.text
    d = r.json(); assert not d["simulado"] and d["creados"] == 2 and d["actualizados"] == 0
    prods = {p["codigo"]: p for p in c.get("/api/productos").json()}
    cem, serv = prods["CEM-50"], prods["SERV-01"]
    assert cem["precio"] == 9500 and cem["costo"] == 7200 and cem["visible_catalogo"] and cem["categoria"] == "Construcción" and cem["codigo_tarifa"] == "08"
    assert serv["es_servicio"] and serv["tipo"] == "Servicio" and not serv["inventariable"] and serv["codigo_tarifa"] == "08" and serv["unidad_medida"] == "h"
    ex = {e["producto_id"]: e for e in c.get("/api/inventario/existencias").json()}
    assert ex[cem["id"]]["cantidad"] == 20
    # crear otra vez: el código ya existe
    r = _subir(c, _xlsx(filas[:1])); assert r.json()["creados"] == 0 and "actualizar" in r.json()["errores"][0]
    # actualizar por código: cambia precio y categoría, no la existencia
    r = _subir(c, _xlsx([["Cemento gris 50 kg", "CEM-50", "2395100000100", 9900, "Unid", "Producto", "08", "CRC", "Materiales", 7500, "", 99, ""]]), modo="actualizar")
    d = r.json(); assert d["actualizados"] == 1 and d["creados"] == 0 and any("existencia" in a for a in d["avisos"]), d
    cem2 = next(p for p in c.get("/api/productos").json() if p["id"] == cem["id"])
    assert cem2["precio"] == 9900 and cem2["categoria"] == "Materiales" and cem2["costo"] == 7500
    assert {e["producto_id"]: e for e in c.get("/api/inventario/existencias").json()}[cem["id"]]["cantidad"] == 20
    # actualizar sin código: por nombre; y una fila nueva se crea
    r = _subir(c, _xlsx([["Consultoría contable", "", "8231100000000", 50000, "h", "Servicio", "08", "", "", "", "", "", ""],
                         ["Disco SSD 1 TB", "SSD-1T", "4755000000100", 89.90, "Unid", "Producto", "08", "USD", "Computo", 62, "", 5, "si"]]), modo="actualizar")
    d = r.json(); assert d["actualizados"] == 1 and d["creados"] == 1, d
    assert next(p for p in c.get("/api/productos").json() if p["id"] == serv["id"])["precio"] == 50000
    ssd = {p["codigo"]: p for p in c.get("/api/productos").json()}["SSD-1T"]; assert ssd["moneda"] == "USD" and ssd["precio"] == 89.9
    # CSV con punto y coma y sin algunas columnas opcionales
    csv = "nombre;codigo;cabys;precio;unidad;tipo;tarifa\nPintura blanca 1 gal;PIN-01;3511000000100;12500;Unid;Producto;13%\n".encode("utf-8")
    r = _subir(c, csv, nombre="items.csv"); assert r.status_code == 200 and r.json()["creados"] == 1, r.text
    # archivos no admitidos
    assert _subir(c, b"x", nombre="items.xls").status_code == 400
    assert _subir(c, b"", nombre="vacio.csv").status_code == 400
    assert _subir(c, _xlsx([]), modo="otro").status_code == 400


def test_plantilla_mesas_restaurante():
    from app.db import init_db
    init_db()
    with Session(engine) as s:
        e = auth.crear_empresa(s, "Soda Plantilla QA", "plantilla@example.test", "3101777999", tipo_negocio="restaurante")
        eid = e.id
    with Session(engine_empresa(eid)) as se:
        cfg = modulos.leer(se, eid, "pos_config")
        assert cfg and len(cfg["terminales"]) == 1
        t = cfg["terminales"][0]
        assert t["modo"] == "restaurante" and t["nombre"] == "Caja salón" and len(t["mesas"]) == 6 and t["servicio_pct"] == 10
        m = t["mesas"][0]; assert m["nombre"] == "Mesa 1" and m["forma"] == "cuadrada" and m["asientos"] == 4 and 0 <= m["x"] <= 100 and set(m) >= {"id", "x", "y", "w", "h", "rot", "sector_id", "deco"}
        assert {"cuentas", "sectores", "destinos", "modificadores", "saloneros", "plano_aspecto"} <= set(t)
        assert modulos.plantilla_restaurante(se, eid) is False        # ya existe: no se pisa
    with Session(engine) as s:
        e2 = auth.crear_empresa(s, "Tienda sin plantilla QA", "tienda@example.test", "3101777998", tipo_negocio="comercio")
    with Session(engine_empresa(e2.id)) as se:
        assert modulos.leer(se, e2.id, "pos_config") is None


def test_sistema_con_soporte(api):  # noqa: F811
    c = api
    base = sitio.leer()
    assert base["soporte"] == {"slug": "", "whatsapp": ""}
    r = c.get("/api/sistema").json(); assert r["soporte_url"] == "" and "nombre" in r
    cfg = sitio.validar({**base, "soporte": {"slug": "/soporte/ItCoreSync", "whatsapp": "506 6228-1597"}})
    assert cfg["soporte"] == {"slug": "itcoresync", "whatsapp": "62281597"}
    sitio.guardar(cfg)
    try:
        r = c.get("/api/sistema").json()
        assert r["soporte_url"] == "http://pruebas.local/soporte/itcoresync" and r["soporte_whatsapp"] == "62281597"
        import pytest
        from fastapi import HTTPException
        with pytest.raises(HTTPException):
            sitio.validar({**base, "soporte": {"slug": "Mal Slug!", "whatsapp": ""}})
    finally:
        sitio.guardar(base)
