"""4.32, cierre de la revisión: piezas pequeñas que unen el trabajo de varios bloques."""
import inspect

from app import pedidos


def test_con_un_interruptor_apagado_la_tienda_de_la_web_no_dice_quien_atiende():
    """El negocio guarda el programa elegido, pero con FE_SINC_DATOS o FE_PEDIDOS_PROGRAMA apagados la web no lo muestra: así fis/pages/pedidos.js
    (conProgramaElegido) no ofrece «Aceptar y atenderlo aquí» y la pantalla queda como la 4.31."""
    fuente = inspect.getsource(pedidos._salida_negocio)
    assert "_elegido = n.atiende_terminal if (_en_programa() or interruptores_encendidos()) else None" in fuente
    assert 'd["atiende_terminal"] = _elegido or None' in fuente
    assert 'd["atiende_nombre"] = nombre_terminal(s, e.id, _elegido) if _elegido else ""' in fuente
