"""3.79: modo mayorista en Ventas en línea. Un negocio que vende a revendedoras publica su catálogo en privado: entra solo quien está
en Contactos (por su celular) con el código del negocio, ve los precios de su lista de precios, pide a crédito dentro de su límite,
repite pedidos y ve su estado de cuenta. El pedido a crédito entra a la caja como cuenta del cliente, marcado. Un negocio normal
sigue igual. También las páginas nuevas del sitio (Restaurante, Servicios e IT) y la sección de revendedoras."""
from sqlmodel import Session

from app import modulos
from app.db import engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)
from tests.test_pedidos import _eid, _productos, _publicar


def _registros(c, **regs):
    for clave, datos in regs.items():
        r = c.put(f"/api/registros/{clave}", json={"datos": datos}); assert r.status_code == 200, (clave, r.text)


def test_catalogo_privado_precios_por_lista_y_credito(api):  # noqa: F811
    c = api; eid = _eid()
    a, b, _oculto, _agotado = _productos(c)
    cli = c.post("/api/clientes", json={"nombre": "Revendedora Ana", "tipo": "Cliente", "tipo_id": "01", "numero_id": "303330333", "celular": 87001111, "limite_credito": 20000}).json()
    assert cli.get("id"), cli
    _registros(c, listas_precios=[{"id": 1, "nombre": "General", "principal": True, "tipo": "Valor"}, {"id": 2, "nombre": "Mayorista", "tipo": "Valor", "activa": True}],
               items_extra={str(a["id"]): {"listas": [{"lista_id": 2, "valor": 3000}]}}, contactos_extra={str(cli["id"]): {"lista_precios_id": 2}},
               pos_config={"terminales": [{"id": 1, "nombre": "Caja QA", "modo": "restaurante", "mesas": []}]})
    r = _publicar(c, slug="mayor-379-qa", activo=True, mayorista=True, mayorista_codigo="colonias", mayorista_credito=True); assert r.status_code == 200, r.text
    assert r.json()["mayorista"] is True and r.json()["mayorista_codigo"] == "COLONIAS" and r.json()["mayorista_credito"] is True
    # sin sesión: la puerta cerrada, sin ítems ni precios; y sin pedido
    d = c.get("/api/publico/mayor-379-qa").json()
    assert d["privado"] is True and d["mayorista"] is True and d["items"] == [] and d["nombre"]
    r = c.post("/api/publico/mayor-379-qa/pedido", json={"nombre": "Alguien", "telefono": "87001111", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 1}]})
    assert r.status_code == 401, r.text
    # teléfono no registrado → 403; código malo → 403; bien → token con los datos de la revendedora
    assert c.post("/api/publico/mayor-379-qa/cliente/acceso", json={"telefono": "87009999", "pin": "1234", "nombre": "Otra"}).status_code == 403
    r = c.post("/api/publico/mayor-379-qa/cliente/acceso", json={"telefono": "87001111", "pin": "1234", "codigo": "MALO"}); assert r.status_code == 403, r.text
    # 3.87: el código común del negocio ya no basta; cada revendedora entra con su código personal (Mi página › Revendedoras)
    r = c.post("/api/publico/mayor-379-qa/cliente/acceso", json={"telefono": "87001111", "pin": "1234", "codigo": "colonias"}); assert r.status_code == 403, r.text
    personal = next(x for x in c.get("/api/pedidos/revendedoras").json() if x["contacto_id"] == cli["id"])["codigo"]
    r = c.post("/api/publico/mayor-379-qa/cliente/acceso", json={"telefono": "87001111", "pin": "1234", "codigo": personal}); assert r.status_code == 200, r.text
    tok = r.json()["token"]; assert r.json()["contacto"]["lista"] == "Mayorista" and r.json()["contacto"]["credito"]["limite"] == 20000 and r.json()["nombre"] == "Revendedora Ana"
    h = {"X-Cliente": tok}
    d = c.get("/api/publico/mayor-379-qa", headers=h).json()
    assert not d.get("privado") and d["mayorista"] is True and d["cliente"]["nombre"] == "Revendedora Ana" and d["cliente"]["lista"] == "Mayorista"
    pa = next(i for i in d["items"] if i["id"] == a["id"]); pb = next(i for i in d["items"] if i["id"] == b["id"])
    assert pa["precio"] == 3390.0 and pb["precio"] == 1130.0      # a: 3.000 de la lista + 13 %; b sin precio en la lista: 1.000 + 13 %
    # pedido a crédito dentro del límite: 4 × 3.390 = 13.560
    r = c.post("/api/publico/mayor-379-qa/pedido", json={"nombre": "Ana", "telefono": "87001111", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 4}], "pago": "credito"}, headers=h)
    assert r.status_code == 200, r.text
    p = r.json(); assert p["a_credito"] is True and p["pago_medio"] == "credito" and p["total"] == 13560.0 and p["lineas"][0]["precio_unitario"] == 3000.0
    # el siguiente a crédito se pasa del límite (13.560 comprometidos + 6.780 > 20.000) → 400
    r = c.post("/api/publico/mayor-379-qa/pedido", json={"nombre": "Ana", "telefono": "87001111", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 2}], "pago": "credito"}, headers=h)
    assert r.status_code == 400 and "disponible" in r.text
    # al recibir sigue funcionando, con los precios de la lista
    r = c.post("/api/publico/mayor-379-qa/pedido", json={"nombre": "Ana", "telefono": "87001111", "tipo": "recoger", "lineas": [{"producto_id": b["id"], "cantidad": 2}]}, headers=h)   # 2 × 1.130 (pedido mínimo 2.000)
    assert r.status_code == 200, r.text
    assert r.json()["a_credito"] is False and r.json()["total"] == 2260.0
    # estado de cuenta de la revendedora
    m = c.get("/api/publico/mayor-379-qa/mis-pedidos", headers=h).json()
    assert m["cuenta"]["credito"]["en_pedidos"] == 13560.0 and m["cuenta"]["credito"]["disponible"] == 6440.0 and len(m["pedidos"]) == 2
    assert all("producto_id" in l for l in m["pedidos"][0]["lineas"])    # «repetir pedido» en la página arma el carrito con estas líneas
    # al confirmar, la cuenta en la caja lleva el cliente y la marca de crédito
    r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}); assert r.status_code == 200, r.text
    with Session(engine_empresa(eid)) as s:
        cu = next(x for x in modulos.leer(s, eid, "pos_espera", []) if x.get("pedido_id") == p["id"])
    assert cu["cliente_id"] == cli["id"] and cu["credito"] is True and "A crédito" in cu["nombre"] and "A crédito" in cu["nota"]
    # la página web y la pantalla de Ventas en línea traen el modo
    js = c.get("/js/tienda.js").text; pub = c.get("/js/fis/pages/publicar.js").text
    assert "Código de acceso" in js and "repetir(p)" in js and "'A crédito'" in js and "n.mayorista_codigo" in pub and "'mayorista'" in pub


def test_negocio_normal_sin_cambios(api):  # noqa: F811
    c = api
    a, b, _o, _g = _productos(c)
    r = _publicar(c, slug="normal-379-qa", activo=True); assert r.status_code == 200, r.text
    d = c.get("/api/publico/normal-379-qa").json()
    assert d["mayorista"] is False and not d.get("privado") and d["cliente"] is None and len(d["items"]) >= 2
    r = c.post("/api/publico/normal-379-qa/pedido", json={"nombre": "Luis", "telefono": "88887777", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 1}], "pago": "credito"})
    assert r.status_code == 400                                    # sin modo mayorista no hay crédito por la página
    assert c.post("/api/publico/normal-379-qa/cliente/acceso", json={"telefono": "88887777", "pin": "1234", "nombre": "Luis"}).status_code == 200


def test_sitio_por_tipo_de_negocio(api):  # noqa: F811
    c = api
    for ruta, h1 in (("/restaurante", "Mesas, cocina y pedidos en línea en un solo sistema"), ("/servicios", "Tickets, contratos y facturación para empresas de servicios")):
        r = c.get(ruta); assert r.status_code == 200 and h1 in r.text and "{{" not in r.text, ruta
    inicio = c.get("/").text
    assert 'href="/restaurante"' in inicio and 'href="/servicios"' in inicio
    assert "También para vender a revendedoras" in c.get("/ventas-en-linea").text and "DESPLIEGUE" not in inicio
