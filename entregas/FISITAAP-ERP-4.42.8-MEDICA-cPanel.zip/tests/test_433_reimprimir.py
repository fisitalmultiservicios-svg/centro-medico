# -*- coding: utf-8 -*-
"""4.33: «Reimprimir» en «Ventas de esta caja» (tiquete de 80 mm de una venta anterior, con COPIA arriba).

- ruta GET /api/comprobantes/{id}/tiquete?copia=true: el PDF dice COPIA; sin el parametro, no.
- docTiquete({ copia }): el texto termico lleva COPIA; sin copia, igual que antes.
- plantilla del modal: el boton solo con comprobante emitido, sin anular, que no sea cargo a habitacion ni abono.
- reimprimirVenta: usa la impresora de tiquetes (agente) o el navegador; nunca la gaveta ni la API de emision.
Nada va a una impresora real, a Hacienda ni al correo."""
import io
import json
import re

import pytest
from pypdf import PdfReader

from tests.test_387_documentos import ent  # noqa: F401  (fixture)
from tests.test_425_ultimos_pantallas import _js, _node, _nodo, _tramo


def _texto(pdf_bytes: bytes) -> str:
    return "\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(pdf_bytes)).pages)


# ================================================================================================================ servidor
def test_ruta_tiquete_con_copia_dice_copia_y_sin_copia_no(ent):
    ent.usuario("admin", "Administrador")
    d = ent.emitir("admin")
    base = f"/api/comprobantes/{d['id']}/tiquete?ancho=80"
    r0 = ent.get("admin", base)
    r1 = ent.get("admin", base + "&copia=true")
    r2 = ent.get("admin", base + "&copia=false")
    assert r0.status_code == r1.status_code == r2.status_code == 200
    assert "COPIA" not in _texto(r0.content) and "COPIA" not in _texto(r2.content)
    assert "COPIA" in _texto(r1.content)
    assert d["consecutivo"][-10:] in _texto(r1.content).replace(" ", "") or "No." in _texto(r1.content)


def test_ruta_tiquete_con_copia_conserva_recibido_y_vuelto(ent):
    ent.usuario("admin", "Administrador")
    d = ent.emitir("admin")
    r = ent.get("admin", f"/api/comprobantes/{d['id']}/tiquete?ancho=80&copia=true&recibido=50000&vuelto=100")
    t = _texto(r.content)
    assert "COPIA" in t and "Recibido" in t and "Vuelto" in t


def test_el_cajero_reimprime_su_tiquete_con_copia_y_el_rol_operativo_sigue_sin_ruta(ent):
    ent.usuario("admin", "Administrador"); ent.usuario("cajero", "Cajero")
    d = ent.emitir("admin")
    r = ent.get("cajero", f"/api/comprobantes/{d['id']}/tiquete?ancho=80&copia=true")
    assert r.status_code == 200 and "COPIA" in _texto(r.content)


# ================================================================================================================ plantilla
def _plantilla_modal() -> str:
    return _tramo(_js("pages/pos/caja.js"), '<Modal v-if="modalVentas && caja"', "</Modal>")


def test_el_modal_de_ventas_trae_reimprimir_con_las_condiciones():
    m = _plantilla_modal()
    boton = re.search(r'<button[^>]*@click="reimprimirVenta\(v\)"[^>]*>Reimprimir</button>', m)
    assert boton, m
    b = boton.group(0)
    for cond in ("v.doc_id", "!v.anulada", "v.tipo !== 'hab'", "!v.abono"):
        assert cond in b, cond
    assert "Anular / devolver" in m                                  # el boton de siempre sigue
    assert "gaveta" not in m.lower()


# ================================================================================================================ docTiquete
FALSO_API = """
export const fmt = (v, d) => (+v).toFixed(d === undefined ? 2 : d), fecha = v => String(v).slice(0, 10), api = async () => ({});
"""


def test_doc_tiquete_con_copia_la_incluye_arriba_y_sin_copia_queda_igual(tmp_path):
    r = _node(tmp_path, """
const { docTiquete } = await import('./js/pages/pos/_agente.js');
const doc = { tipo_documento: '04', consecutivo: '00100001040000000007', fecha_emision: '2026-11-14T10:00:00-06:00', moneda: 'CRC', total: 1130, impuesto: 130, lineas: [{ cantidad: 1, precio_unitario: 1000, descuento: 0, impuesto: 130, tarifa: 13, detalle: 'Café' }] };
const base = { empresa: { nombre: 'Soda Prueba' }, doc, cfg: {}, medios: [{ medio: '01', monto: 1130 }], nombreMedio: m => 'Efectivo' };
const a = docTiquete(base), b = docTiquete({ ...base, copia: true });
const textos = d => d.bloques.filter(x => x.t === 'texto').map(x => x.x);
console.log(JSON.stringify({ sin: textos(a), con: textos(b), primero: b.bloques[0], nSin: a.bloques.length, nCon: b.bloques.length }));
""", archivos=("pages/pos/_agente.js",), falsos={"api.js": FALSO_API})
    assert not any("COPIA" in t for t in r["sin"]), r
    assert r["con"][0] == "*** COPIA ***" and r["primero"]["b"] is True and r["primero"]["tam"] == 2, r
    assert r["nCon"] == r["nSin"] + 2, r                            # solo las dos lineas de la copia
    assert [t for t in r["con"] if "COPIA" not in t and "Reimpresión" not in t] == r["sin"], r


# ================================================================================================================ reimprimirVenta (metodos reales de la caja)
def _metodos():
    t = _js("pages/pos/caja.js")
    return _tramo(t, "async imprimirTermico(u, imp, copia) {", "    // ---- venta sin internet")


def test_reimprimir_venta_por_el_agente_con_copia_sin_gaveta_ni_emision(tmp_path):
    fuente = _metodos()
    assert "abrirGaveta" not in _tramo(fuente, "reimprimirVenta(v) {", "imprimir(u, formato, sinAgente, copia) {")
    r = _node(tmp_path, """
const src = %s;
const Q = { agente: [], docs: [], llamadas: [], abiertos: [], toasts: [], gaveta: 0, emisiones: 0 };
const store = { empresa: { nombre: 'Soda' } }, sesion = { usuario: { nombre: 'Ana' } }, nombreMedio = m => m;
const api = async url => { Q.llamadas.push(url); return { id: 5, consecutivo: 'X', tipo_documento: '04', moneda: 'CRC', total: 100, lineas: [] }; };
const docTiquete = o => { Q.docs.push(o); return { bloques: [] }; };
const imprimirAgente = async (imp, doc) => { if (imp.falla) throw new Error('sin papel'); Q.agente.push([imp.nombre, doc]); };
const porAgente = imp => !!imp && (imp.conexion === 'usb' || imp.conexion === 'red');
const abrirGaveta = () => { Q.gaveta++; };
const avisoImpresion = (p, e) => p + e.message, toast = (t, k) => Q.toasts.push([t, k]);
globalThis.window = { open: u => Q.abiertos.push(u) };
const M = new Function('api', 'docTiquete', 'imprimirAgente', 'porAgente', 'abrirGaveta', 'avisoImpresion', 'toast', 'store', 'sesion', 'nombreMedio', 'return ({' + src + '\\n})')
  (api, docTiquete, imprimirAgente, porAgente, abrirGaveta, avisoImpresion, toast, store, sesion, nombreMedio);
const vm = (imp, cfg) => Object.assign({}, M, { cfg: cfg || { ancho_ticket: 80, vendedor: 'Caja 1', nombre: 'Caja 1' }, impresoraTiquete: () => imp, imprimirProvisional: () => { throw new Error('no'); }, cola: [] });
const venta = { id: 1, doc_id: 5, consecutivo: 'X', total: 100, medios: [{ medio: '01', monto: 100 }], vuelto: 0 };
const out = {};
let v = vm({ nombre: 'Tiq', conexion: 'red' });
await v.reimprimirVenta(venta);
out.agente = { impreso: Q.agente.length, copia: Q.docs[0] && Q.docs[0].copia, recibido: Q.docs[0] ? (Q.docs[0].recibido ?? null) : 0, medios: Q.docs[0] && Q.docs[0].medios, llamadas: Q.llamadas.slice(), abiertos: Q.abiertos.length };
Q.agente = []; Q.docs = []; Q.llamadas = [];
v = vm({ nombre: 'Tiq', conexion: 'red', falla: true });
await v.reimprimirVenta(venta);
out.falla = { abiertos: Q.abiertos.slice(), toast: Q.toasts.length };
Q.abiertos = [];
v = vm(null);
await v.reimprimirVenta({ ...venta, recibido: 150, vuelto: 50 });
out.navegador = Q.abiertos.slice();
Q.abiertos = []; Q.llamadas = [];
v = vm(null);
for (const x of [{ ...venta, doc_id: null }, { ...venta, anulada: true }, { ...venta, tipo: 'hab' }, { ...venta, abono: true }]) await v.reimprimirVenta(x);
out.ignoradas = [Q.abiertos.length, Q.llamadas.length];
out.gaveta = Q.gaveta;
console.log(JSON.stringify(out));
""" % json.dumps(fuente), archivos=(), falsos={})
    assert r["agente"]["impreso"] == 1 and r["agente"]["copia"] is True, r
    assert r["agente"]["recibido"] is None and r["agente"]["medios"] == [{"medio": "01", "monto": 100}], r      # lo que la venta no guarda, se omite
    assert r["agente"]["llamadas"] == ["/api/comprobantes/5"] and r["agente"]["abiertos"] == 0, r             # solo lee el comprobante
    assert r["falla"]["toast"] == 1 and len(r["falla"]["abiertos"]) == 1 and r["falla"]["abiertos"][0].endswith("&copia=true"), r
    assert "/api/comprobantes/5/tiquete?ancho=80" in r["navegador"][0] and r["navegador"][0].endswith("&copia=true"), r
    assert "recibido=150&vuelto=50" in r["navegador"][0], r
    assert r["ignoradas"] == [0, 0] and r["gaveta"] == 0, r


def test_el_tiquete_de_la_ultima_venta_no_cambia():
    t = _js("pages/pos/caja.js")
    assert "if (imprime) this.imprimir(this.ultima);" in t
    assert t.count("copia: true") == 0 and "'&copia=true'" in t       # solo reimprimirVenta pide copia (this.imprimir(..., true))
    assert "'tiquete', false, true)" in t
