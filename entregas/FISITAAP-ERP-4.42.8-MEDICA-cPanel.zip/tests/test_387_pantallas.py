"""3.87: pantallas sueltas (QA 3.87, grupo de pantallas).
- Reportes: el hub muestra las categorías a quien tiene reportes o ver_todo (la cadena v-if/v-else las escondía) y cada reporte se
  ofrece solo a quien el servidor le va a entregar sus datos (el Vendedor veía Cuentas por pagar, Compras, Ingresos y gastos…).
- Recepción de comprobantes: el XML, el PDF y el mensaje de receptor de un comprobante recibido exigen lo mismo que la lista
  (gastos o ver_todo); antes cualquier rol los abría por número. Solo lectura ya no pide el buzón.
- Traslados a otra empresa: un hotel (sin el extra «Grupo de empresas» en su tipo) recibe un texto que no le pide contratarlo.
- Entrada al inventario por compra con clave («compra:<id>», «Dar entrada al inventario» de Facturas de compra): no entra dos veces.
- Mis tareas, nuevo pago recibido, caja, configuración del punto de venta, diseño de la página, monitor de cocina, manifiesto de
  Ventas en línea, Traslados e Instalación local: revisiones de texto de la interfaz (como test_387_superadmin)."""
import json
import pathlib
import re
import types

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth
from app.db import Empresa, engine, init_db

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
JS = RAIZ / "static" / "js"


def _txt(rel):
    return (JS / rel).read_text(encoding="utf-8")


# ----------------------------------------------------------------------------- servidor
@pytest.fixture()
def empresas():
    """Una empresa de Comercio y un hotel (@example.test), con un contexto que la prueba cambia de rol."""
    from app.main import app
    init_db()
    nombres = {"comercio": "Pantallas Comercio 387 QA S.A.", "hospitalidad": "Pantallas Hotel 387 QA S.A."}
    ids = {}
    with Session(engine) as s:
        for tipo, n in nombres.items():
            viejo = s.exec(select(Empresa).where(Empresa.nombre == n)).first()
            if viejo:
                s.delete(viejo); s.commit()
            e = auth.crear_empresa(s, n, f"{tipo}.pantallas387@example.test", "3101387" + ("101" if tipo == "comercio" else "202"), provincia=1, canton=1, distrito=1,
                                   otras_senas="Oficina de pruebas (QA)", actividad="471101", telefono=22223333, tipo_negocio=tipo, factura_electronica=False,
                                   correo_automatico=False)
            if tipo == "comercio":                                     # con plan y sin el extra «grupo» (sin plan todo está encendido)
                e.plan, e.extras = "pos", "[]"; s.add(e); s.commit(); s.refresh(e)
            ids[tipo] = e.id
    usuario = types.SimpleNamespace(id=None, correo="pantallas387@example.test", es_superadmin=False, nombre="Pantallas 387")
    estado = {"tipo": "comercio", "rol": "Administrador"}

    def ctx():
        with Session(engine) as s:
            return auth.Contexto(usuario, s.get(Empresa, ids[estado["tipo"]]), estado["rol"])
    app.dependency_overrides[auth.contexto] = ctx
    try:
        yield TestClient(app), estado, ids
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            for n in nombres.values():
                e = s.exec(select(Empresa).where(Empresa.nombre == n)).first()
                if e:
                    s.delete(e)
            s.commit()


def test_recepcion_xml_pdf_y_mensaje_exigen_gastos_o_ver_todo(empresas):
    c, estado, _ids = empresas
    for rol, esperado in (("Vendedor", 403), ("Cajero", 403), ("Contador", 404), ("Solo lectura", 404), ("Administrador", 404)):
        estado["rol"] = rol
        for ruta in ("/api/recepcion/987654/xml", "/api/recepcion/987654/pdf", "/api/recepcion/987654/mensaje"):
            r = c.get(ruta)
            # sin permiso: 403 antes de buscar el comprobante (no se puede ni sondear qué números existen); con permiso: 404 (no existe)
            assert r.status_code == esperado, (rol, ruta, r.status_code, r.text)
    estado["rol"] = "Vendedor"
    assert c.get("/api/recepcion").status_code == 403                    # la lista ya lo exigía


def test_hotel_recibe_traslados_sin_que_le_pidan_contratar_el_extra(empresas):
    c, estado, ids = empresas
    estado.update(tipo="hospitalidad", rol="Administrador")
    r = c.get("/api/traslados")
    assert r.status_code == 200, r.text
    assert r.json()["extra_activo"] is False and r.json()["extra_disponible"] is False
    r = c.post("/api/traslados", json={"empresa_destino_id": ids["comercio"], "lineas": [{"producto_id": 1, "cantidad": 1}]})
    assert r.status_code == 400 and "Esta versión no envía traslados" in r.json()["detail"] and "Suscripción" not in r.json()["detail"]
    estado["tipo"] = "comercio"                                         # Comercio sí lo puede contratar: el texto de siempre
    r = c.get("/api/traslados")
    assert r.json()["extra_disponible"] is True
    r = c.post("/api/traslados", json={"empresa_destino_id": ids["hospitalidad"], "lineas": [{"producto_id": 1, "cantidad": 1}]})
    assert r.status_code == 400 and "Suscripción y planes" in r.json()["detail"]


def test_entrada_por_compra_con_clave_no_entra_dos_veces(empresas):
    """«Dar entrada al inventario» manda la clave «compra:<id>»: un segundo intento (otro clic, otra persona o un guardado de la marca
    que no llegó) da 409 y la mercadería no entra dos veces. Otra clave, o sin clave (el formulario de compra), entra como siempre."""
    c, _estado, _ids = empresas
    r = c.post("/api/productos", json={"nombre": "Cemento QA 387", "cabys": "2395100000100", "precio": 1000, "tarifa": 13, "codigo_tarifa": "08"})
    assert r.status_code == 200, r.text
    pid = r.json()["id"]
    cuerpo = {"numero": "FC-387", "proveedor": "Proveedor QA", "clave": "compra:7", "lineas": [{"producto_id": pid, "cantidad": 3, "costo_unitario": 100}]}
    r1 = c.post("/api/inventario/compras", json=cuerpo)
    assert r1.status_code == 200, r1.text
    r2 = c.post("/api/inventario/compras", json=cuerpo)
    assert r2.status_code == 409 and r1.json()["codigo"] in r2.json()["detail"] and "ya entró al inventario" in r2.json()["detail"], r2.text
    existencia = lambda: next(e for e in c.get("/api/inventario/existencias").json() if e["producto_id"] == pid)["cantidad"]
    assert existencia() == 3
    assert c.post("/api/inventario/compras", json={**cuerpo, "clave": "compra:8"}).status_code == 200    # otra compra sí entra
    assert c.post("/api/inventario/compras", json={**cuerpo, "clave": None}).status_code == 200         # sin clave, como antes
    assert existencia() == 9


def test_los_reportes_que_el_hub_reserva_los_niega_el_servidor(empresas):
    """Lo que hub.js (PERMISOS_REPORTE) le quita al Vendedor es exactamente lo que el servidor le niega."""
    c, estado, _ids = empresas
    rutas = ("/api/resumen?periodo=mes", "/api/resumen/iva?desde=2026-10-01&hasta=2026-10-31",
             "/api/inventario/ventas-por-bodega?desde=2026-10-01&hasta=2026-10-31", "/api/sucursales/ventas?desde=2026-10-01&hasta=2026-10-31")
    for rol, esperado in (("Vendedor", 403), ("Contador", 200), ("Solo lectura", 200)):
        estado["rol"] = rol
        for ruta in rutas:
            assert c.get(ruta).status_code == esperado, (rol, ruta)
    estado["rol"] = "Vendedor"                                          # lo que el Vendedor sí abre
    assert c.get("/api/comprobantes").status_code == 200
    assert c.get("/api/inventario/valor").status_code == 200
    assert c.get("/api/registros/bancos").status_code == 403            # Transacciones, Flujo de caja, Documentos por conciliar


# ----------------------------------------------------------------------------- interfaz
def test_hub_de_reportes_muestra_las_categorias_y_filtra_por_reporte():
    hub = _txt("pages/reportes/hub.js")
    # las tarjetas de categoría dependen del buscador, no de la tarjeta «Reporte ejecutivo»
    assert '<div class="tiles" v-if="!q.trim()">\n      <a class="tile" v-for="t in tiles"' in hub.replace("\r\n", "\n")
    assert "export function puedeReporte(cat, slug)" in hub and "export function reportesDe(cat)" in hub
    assert "n: reportesDe(key).length })).filter(x => x.n)" in hub
    assert "for (const r of reportesDe(key))" in hub                     # la búsqueda tampoco ofrece lo que el rol no abre
    assert "key: 'cierres-caja'" in hub and "key: 'pos', nombre: 'Punto de venta', ico: '🛒', desc: 'Cierres" not in hub
    cat = _txt("pages/reportes/categoria.js")
    assert "else lista = reportesDe(this.cat)" in cat and '<div class="page" v-else>' in cat
    rep = _txt("pages/reportes/reporte.js")
    assert "permitido() { return puedeReporte(this.params.cat, this.slug); }" in rep
    assert '<div class="page" v-if="!permitido">' in rep and '<div class="page" v-else>' in rep
    assert "if (!this.rep || !this.existe || !this.permitido)" in rep and "if (this.rep && this.permitido) registrarReciente" in rep


def test_permisos_por_reporte_cubren_cada_fuente_de_datos():
    """Cada reporte de reporte.js que lee una fuente con permiso propio en el servidor tiene ese permiso en hub.js."""
    hub, rep = _txt("pages/reportes/hub.js"), _txt("pages/reportes/reporte.js")
    permisos = dict(re.findall(r"'?([a-z0-9-]+)'?: (P_RESUMEN|P_BANCOS|P_CAJA)", hub.split("export const PERMISOS_REPORTE = {", 1)[1].split("};", 1)[0]))
    catalogo = hub.split("export const CATALOGO = {", 1)[1].split("\n};", 1)[0]
    cat_de = {}
    for bloque in re.split(r"\n  (?='?[a-z-]+'?: \{ nombre)", catalogo):
        m = re.match(r"'?([a-z-]+)'?: \{ nombre", bloque.strip())
        if m:
            for slug in re.findall(r"slug: '([a-z0-9-]+)'", bloque):
                cat_de[slug] = m.group(1)
    cuerpo = rep.split("const REPORTES = {", 1)[1]
    trozos = re.split(r"\n  async '([a-z0-9-]+)'\(c\) \{", cuerpo)
    fuentes = {trozos[i]: trozos[i + 1] for i in range(1, len(trozos) - 1, 2)}
    assert len(fuentes) >= 30
    for slug, codigo in fuentes.items():
        if re.search(r"resumen\(|/api/resumen/iva|/api/inventario/ventas-por-bodega|/api/sucursales/ventas", codigo):
            assert permisos.get(slug) == "P_RESUMEN", slug
        elif re.search(r"bancos\(\)|movimientos\(\)|compras\(\)|pagosGastos\(\)", codigo):
            assert permisos.get(slug) == "P_BANCOS", slug
        elif re.search(r"servicioPor", codigo):
            assert permisos.get(slug) == "P_CAJA", slug
        elif "cargarAsientos" in codigo or slug == "libro-inventarios-balances":
            assert cat_de.get(slug) == "contables", slug                    # PERMISOS_REPORTE_CAT.contables: contabilidad o ver_todo
    assert "const PERMISOS_REPORTE_CAT = { contables: ['contabilidad', 'ver_todo'] };" in hub


def test_compra_del_contador_deja_la_entrada_al_inventario_pendiente():
    form = _txt("pages/gastos/compra-form.js")
    assert "import { store, sesion } from '../../app.js';" in form
    assert "!sesion.puede('inventario') && lineasInventario(this.f, lineas).length > 0" in form
    assert "inventario_pendiente: true, bodega_id: this.bodegaId" in form
    assert "if (doc.inventario_pendiente) return;" in form                # no se pide la entrada que el servidor rechazaría
    lista = _txt("pages/gastos/compras.js")
    assert "import { lineasInventario, entradaCompra } from './compra-form.js';" in lista
    assert "puedeEntrada(c) { return !!c.inventario_pendiente && this.puede('inventario') && this.puede('gastos'); }" in lista
    assert "Dar entrada al inventario" in lista
    # no entra dos veces: se trae la lista del servidor, se manda la clave de la compra, se espera el guardado; el confirm muestra qué entra
    assert "await mock.refrescar(['compras'], { sinCorte: true }); this.lista = compras();" in lista
    assert "entradaCompra(x, inv, bodega, x.recepcion_id, 'compra:' + x.id)" in lista
    assert "const ok = await mock.set('compras', this.lista);" in lista
    assert "fmtCant(l.cantidad) + ' × ' + nombre(l.producto_id) + ' a ' + money(l.costo_unitario)" in lista
    assert "...(clave ? { clave } : {})" in form


def test_tareas_sin_escribir_no_ofrecen_cambios_y_avisan_tras_guardar():
    t = _txt("pages/tareas.js")
    assert '<button class="btn ghost" v-if="puede(\'escribir\')" @click="sugerir">' in t
    assert '<button class="btn" v-if="puede(\'escribir\')" @click="nueva">' in t
    assert ":disabled=\"!puede('escribir')\" @change=\"cambiarEstado" in t
    assert "guardarTodo() { return mock.set('tareas', this.tareas).then(ok =>" in t
    assert "this.guardarTodo().then(ok => ok && toast('Tarea guardada', 'ok'));" in t
    assert "toast('Tarea guardada', 'ok');\n" not in t.replace("\r\n", "\n").split("guardar() {", 1)[1].split("},", 1)[0]


def test_pago_sin_facturacion_electronica_no_ofrece_rep():
    p = _txt("pages/ventas/pago-form.js")
    assert '<button v-if="sesion.electronica" :class="{on:tipo===\'rep\'}"' in p
    assert "['aceptado', 'interno'].includes(d.estado)" in p                 # la interna de crédito 10/08 se cobra con recibo de caja
    f = _txt("pages/ventas/facturas.js")
    assert "!['aceptado', 'interno'].includes(d.estado)) return toast(" in f
    assert "rep: sesion.electronica && ['10', '08'].includes(d.condicion_venta)" in f


def test_recepcion_solo_pide_el_buzon_a_quien_lo_puede_leer():
    r = _txt("pages/gastos/recepcion.js")
    assert "verBuzon() { return sesion.puede('gastos') || sesion.puede('configurar'); }" in r
    assert "if (this.verBuzon) { try { const b = await api('/api/recepcion/buzon');" in r
    assert '<button v-if="verBuzon" :class="{on: tab===\'buzon\'}"' in r
    assert "v-if=\"sesion.puede('configurar')\" @click=\"guardarBuzon\"" in r


def test_caja_muestra_la_configuracion_solo_a_quien_configura():
    caja = _txt("pages/pos/caja.js")
    enlaces = re.findall(r'<a [^>]*href="#/pos/configuracion"[^>]*>', caja)
    assert len(enlaces) == 3
    assert all("v-if=\"sesion.puede('configurar')\"" in x for x in enlaces), enlaces


def test_configuracion_pos_avisa_el_limite_de_cajas_del_plan():
    c = _txt("pages/pos/configuracion.js")
    assert "limiteCajas() { const e = sesion.empresaInfo || {}, p = e.plan || {}; return (!p.codigo || p.sin_plan || p.prueba || e.es_demo) ? 0 : (+p.cajas || 0); }" in c
    assert "nueva() { if (this.topeCajas) return toast(" in c
    assert ':disabled="!puedeConfigurar || topeCajas"' in c


def test_vista_previa_del_diseno_en_el_mismo_servidor():
    c = (JS / "fis/pages/contenido.js").read_text(encoding="utf-8")
    assert "vista() { const n = this.n; return n && n.slug ? '/t/' + encodeURIComponent(n.slug) : ''; }" in c
    assert ':src="vista"' in c and ':src="url"' not in c
    assert ':href="url"' in c                                              # «Abrir página completa» sigue con la dirección pública


def test_monitor_de_cocina_saca_las_cuentas_entregadas():
    k = _txt("pages/pos/cocina.js")
    assert "entregadas = this.cerradaAfuera(v, lineas) || lineas.every(l => l.entregado)" in k
    # solo las comandas enviadas antes de la entrega: una ronda nueva de una cuenta ya entregada sí se prepara (revisión 3.87)
    assert "cerradaAfuera(v, lineas) { if (v.estado !== 'entregado') return false; const h = Date.parse(v.hora_entregado || ''); return !isNaN(h) && lineas.every(l => Date.parse(l.enviado) <= h); }" in k
    assert "v.estado === 'entregado' ||" not in k
    assert "v.pedido && v.estado === 'entregado' && porCocina ? 'listo' : v.estado" in k               # regresar no reabre lo que cerró el motorizado
    caja = _txt("pages/pos/caja.js")
    assert "estado: prev.estado, hora_entregado: prev.hora_entregado }" in caja                          # la caja no pierde la hora de entrega
    assert "pendientes() { return this.tickets.filter(t => !t.listoTodo && !t.entregada).length; }" in k
    assert 'v-if="t.lineas.every(l => l.entregado)" @click="devolver(t)">↩ Regresar a Listo</button>' in k   # solo lo que entregó la cocina


def test_manifiesto_de_ventas_en_linea_existe():
    html = (RAIZ / "static/app/fisitaap/index.html").read_text(encoding="utf-8")
    assert '<link rel="manifest" href="/fisitaap/manifest.webmanifest">' in html
    m = json.loads((RAIZ / "static/fisitaap/manifest.webmanifest").read_text(encoding="utf-8"))
    assert m["start_url"].startswith("/app/fisitaap/") and "FISITAAP ERP" not in json.dumps(m, ensure_ascii=False)
    for i in m["icons"]:
        assert (RAIZ / "static" / i["src"].lstrip("/")).exists(), i["src"]
    from app.main import app
    r = TestClient(app).get("/fisitaap/manifest.webmanifest")
    assert r.status_code == 200 and r.json()["short_name"] == "Ventas en línea"


def test_traslados_e_instalacion_local_con_el_contenedor_de_pagina():
    t = _txt("pages/inventario/traslados.js")
    assert '<div class="page">\n    <PageHead title="Traslados a otra empresa"' in t.replace("\r\n", "\n")
    assert '<div class="tabs" v-if="extraActivo || extraDisponible">' in t and 'class="tab"' not in t
    assert "this.extraDisponible = r.extra_disponible !== false;" in t
    assert "if (!this.extraActivo && !this.extraDisponible) this.tab = 'historial';" in t                # el hotel abre en lo recibido
    i = _txt("pages/configuracion/instalacion-local.js")
    assert '<div class="page">\n    <PageHead title="Instalación local"' in i.replace("\r\n", "\n")
