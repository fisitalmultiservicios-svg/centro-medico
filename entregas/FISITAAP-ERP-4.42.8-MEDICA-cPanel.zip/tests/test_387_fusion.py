# -*- coding: utf-8 -*-
"""3.87, fusión de los arreglos: el cajero cierra su caja y luego el navegador anota en esa sesión cerrada que el reporte Z salió por
correo (correo_z / correo_z_pendiente). La regla de cierres hechos (el cajero no los reabre ni los maquilla) no debe rechazar esa marca."""
from tests.test_387_registros import ROLES_COMERCIO, _borrar, _cambios, _empresa, _leer


def test_cajero_marca_el_correo_del_z_pero_no_maquilla_el_cierre():
    correos = {"Administrador": "admin.fusion387@example.test", "Cajero": "cajero.fusion387@example.test"}
    eid, tok = _empresa("Comercio Fusión 387 QA", "comercio", ROLES_COMERCIO, correos, "91")
    try:
        t = tok["Cajero"]
        ses = {"id": 7, "caja": "Caja 1", "estado": "Abierta", "usuario": "cajero", "monto_inicial": 1000, "fecha": "2026-11-05", "conteo": None, "diferencia": None}
        assert _cambios(t, "pos_cajas", [ses], nuevos=[7]).status_code == 200
        cerrada = {**ses, "estado": "Cerrada", "cerrada_en": "2026-11-05T20:00:00", "conteo": 900, "diferencia": -100}
        assert _cambios(t, "pos_cajas", [cerrada]).status_code == 200
        pendiente = {**cerrada, "correo_z_pendiente": True}                                   # sin conexión: queda por enviar
        assert _cambios(t, "pos_cajas", [pendiente]).status_code == 200
        enviado = {**cerrada, "correo_z_pendiente": False, "correo_z": {"enviado": "2026-11-05T20:01:00", "para": ["dueno@example.test"]}}
        assert _cambios(t, "pos_cajas", [enviado]).status_code == 200
        assert _cambios(t, "pos_cajas", [{**enviado, "conteo": 1000, "diferencia": 0}]).status_code == 403       # maquillar sigue prohibido
        assert _cambios(t, "pos_cajas", [{**enviado, "estado": "Abierta"}]).status_code == 403                   # reabrir también
        g = {x["id"]: x for x in _leer(eid, "pos_cajas")}[7]
        assert g["estado"] == "Cerrada" and g["diferencia"] == -100 and g["correo_z"]["para"] == ["dueno@example.test"]
    finally:
        _borrar(eid, correos.values())
