# -*- coding: utf-8 -*-
"""4.39, décima vuelta de los arreglos de la comanda automática al cobrar (17 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py y las ayudas de las vueltas tercera a novena: destinoDe e impresoraDe reales, la Cocina como única
impresora de comanda y cada comanda anotada).

- P1 confirmarDividir, al pasar TODO un pedido en línea (o con lo ya pagado en línea, prepago) a una cuenta aparte: si la cuenta del servidor
  tiene un plato que esta pantalla no conoce (lo agregó otro equipo con «Dividir» abierto aquí), no se pasa nada, se cierra «Dividir» y sale el
  aviso de volver a abrirlo; al volver a abrirlo se pasa todo (también ese plato) y la cuenta del pedido desaparece. Antes (novena vuelta) la
  cuenta del pedido quedaba viva con el plato del otro equipo, con el prepago, el enlace del pedido y el teléfono, y la cuenta aparte también:
  el prepago se descontaba dos veces (y el pedido quedaba enlazado a dos cuentas). Separar solo una parte sigue igual (el prepago queda en la
  cuenta del pedido) y un solo equipo nunca ve el aviso (el pedido sin lid, guardado, con un plato agregado aquí guardado o no, tras su propia
  «Comanda», tras devolver la parte de un cobro cancelado, en la caja de comercio).
- R1 confirmarDividir, con platos por enviar al separar, pasar a una mesa o partir: las dos consultas del restaurante (antes de partir y la de
  después de esperar la marca, X2) esperan la lista hasta 3 s en vez de 1,5 s. Con la lista a 2 s, lo que otro equipo acaba de mandar a cocina
  se ve (el aviso «Otro equipo mandó a cocina…» o, después de esperar, «…mientras se esperaba») y no se parte; antes se partía con la copia
  vieja y lo partido pasaba «sin enviar» a la otra cuenta y volvía a salir a cocina con su próxima «Comanda». Sin platos por enviar, con
  «Cobrar estos platos» y en la caja de comercio sigue siendo 1,5 s.
Cada caso corre también, cuando muestra el defecto, con los métodos de ANTES de esta vuelta: se sacan de caja.js con la décima vuelta
deshecha (DECIMA y _caja_sin_decima de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la
vuelta) y ahí se ve el defecto que el cambio arregla.
Defecto que dejaba P1 (era un xfail estricto, abajo): P1 compara con la lista traída por la consulta de antes de partir, que en un pedido con
todo enviado (no hay platos por enviar: R1 no aplica) esperaba 1,5 s como mucho. Con la lista a 2 s, P1 miraba la copia vieja (sin el plato de
B) y se pasaba todo: lo ya pagado en línea quedaba en las dos cuentas, como antes de esta vuelta.
4.39 (undécima vuelta): Q1 lo corrige (las tres consultas de confirmarDividir esperan la lista hasta 3 s siempre): la prueba ya no lleva la
marca xfail y su control corre con confirmarDividir de antes de la undécima. Las pruebas de un solo equipo con la lista a 2 s («Cobrar estos
platos», los platos ya enviados y la caja de comercio) ahora esperan unos 2 s. El contrato compara la décima vuelta contra caja.js sin la
undécima (UNDECIMA y _caja_sin_undecima de tests/test_439_tercera_vuelta.py: la undécima cambió las dos consultas de R1 y su comentario); las
frases de las notas que reescribió la undécima (el límite de la red muy lenta y la lista de pruebas de Técnico) pasaron a su contrato, en
tests/test_439_undecima_vuelta.py.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import RAIZ, _metodo
from tests.test_439_cuarta_vuelta import AVISO_DIVIDIR_7
from tests.test_439_novena_vuelta import _correr as _correr9
from tests.test_439_octava_vuelta import AVISO_Y3
from tests.test_439_septima_vuelta import CAMBIO_DIV
from tests.test_439_tercera_vuelta import DECIMA, ESPERA_R1, REFRESCAR15, _caja_sin_decima, _caja_sin_undecima

# el único método que cambió la décima vuelta (cada tripleta de DECIMA está en él)
CAMBIADOS = ("async confirmarDividir() {",)
PED = "Pedido #41 · Cliente QA"
TEL = "8888-0000"
CUATRO = ["Casado×1", "Envío a domicilio×1", "Limonada×1", "Postre×1"]
TRES = ["Casado×1", "Envío a domicilio×1", "Postre×1"]
AMBOS, CASADO1, POSTRE1, LIMONADA1 = ["Casado×1", "Postre×1"], ["Casado×1"], ["Postre×1"], ["Limonada×1"]
MEDIAS = ["Casado×0.5", "Postre×0.5"]
APARTE = "Platos pasados a una cuenta aparte (en «Para llevar en espera»)"
TODO_APARTE = "Todo se pasó a una cuenta aparte (en «Para llevar en espera»): la cuenta quedó vacía"   # el texto no es literal (límite aceptado)


def _antes(cabezas=CAMBIADOS):
    """Los métodos que cambió la décima vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k = _caja_sin_decima()
    return tuple(_metodo(k, c) for c in cabezas)


AYUDAS = r"""
// lo que importa de cada cuenta del servidor: sus platos, lo ya pagado en línea (prepago), el enlace con el pedido y el teléfono del cliente
const cuentasP = () => S.items.map(x => ({ nombre: x.nombre, platos: (x.lineas || []).map(l => l.detalle + '×' + l.cantidad).sort(), prepago: x.prepago ? +x.prepago.monto : 0, pedido: x.pedido_id || null, telefono: x.telefono || null }));
// cada cuenta del servidor abre su cobro en un equipo nuevo y se cierra sin cobrar: lo ya pagado en línea que descontaría (abrirPago lo toma de la cuenta)
async function prepagosAlCobrar() {
  const ps = [];
  for (const c of S.items.slice()) { const v = venta(await equipo()); await v.sincronizar(); v.recuperar(v.espera.find(x => x.id === c.id)); await v.abrirPago(); ps.push(v.prepago ? +v.prepago.monto : 0); v.cerrarPago(); }
  await hastaLibre(); return ps;
}
// el pedido en línea a domicilio (sus líneas sin lid: Casado y Postre enviados hace un minuto y el envío), con el teléfono del cliente y, con `prepago`,
// ₡1 000 ya pagados en línea; abierto en `n` equipos desde «Para llevar en espera» (con `comercio`, en la caja de comercio)
async function pedidoAbierto(prepago, n, comercio) {
  nuevo(); pedidoEnServidor([CASADO(), POSTRE()]); S.items[0].telefono = @TEL@; if (prepago) S.items[0].prepago = { monto: 1000, medio: '06', referencia: 'QA-1' };
  const vs = [];
  for (let i = 0; i < n; i++) { const v = venta(await equipo()); if (comercio) v.esRestaurante = false; await v.sincronizar(); v.recuperar(v.espera.find(x => x.id === 1)); vs.push(v); }
  return vs;
}
// ESE equipo marca todo lo que ve (o, con `parte`, solo el Casado) para una cuenta aparte y toca «Separar»; devuelve cuánto tardó confirmarDividir
async function separar(vm, parte) {
  vm.dividir.destino = 'nueva';
  vm.dividir.sel = parte ? { [vm.lineas.findIndex(l => l.detalle === 'Casado')]: 1 } : Object.fromEntries(vm.lineas.map((l, i) => [i, +l.cantidad]));
  const t0 = Date.now(); await vm.confirmarDividir(); const ms = Date.now() - t0;
  await vm.A.mock.guardarTodo(); await hastaLibre(); await espera(50); await vm.A.mock.guardarTodo();
  return ms;
}
// un tercer equipo abre cada cuenta del servidor y toca «Comanda»: lo que quedó sin enviar sale (otra vez) a cocina
async function otraComanda() { for (const c of S.items.slice()) { const v = await abierta(c.id); await v.enviarComanda(); await v.A.mock.guardarTodo(); } await hastaLibre(); }
"""


def _correr(tmp_path, casos, antes=()):
    return _correr9(tmp_path, AYUDAS.replace("@TEL@", json.dumps(TEL)) + casos, antes=antes)


# ================================================================================================================ P1: pasar todo un pedido
CASOS_P1 = r"""
// el pedido (`caso`: prepago, con ₡1 000 ya pagados en línea; pedido, sin prepago; comercio, con prepago en la caja de comercio; parte, con prepago y A
// separa solo el Casado; lenta, con prepago y la lista de cuentas de A tarda 2 s) abierto en A y en B. A abre «Dividir»; B agrega una Limonada y la guarda
// (llega al servidor). A (sin sincronizar) marca todo lo que ve y toca «Separar». Cada cuenta abre su cobro (lo ya pagado que descontaría). Si salió el
// aviso, A vuelve a abrir «Dividir» y pasa todo otra vez
async function p1(caso) {
  const [a, b] = await pedidoAbierto(caso !== 'pedido', 2, caso === 'comercio');
  await a.abrirDividir();
  b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo();
  const suelta = caso === 'lenta' ? lento(a, 2000) : null, srvB = cuentasP(), lis = listas(a);
  await separar(a, caso === 'parte');
  if (suelta) { await espera(2100); suelta(); await a.A.mock.guardarTodo(); await hastaLibre(); }
  const primero = { dividir: !!a.dividir, alDia: a._alDia, consultas: lis.n, avisos: avisosDiv(a), hecho: hechoDiv(a), cuentas: cuentasP(), prepagos: await prepagosAlCobrar() };
  let segundo = null;
  if (primero.avisos.length && !a.dividir) {
    await a.abrirDividir(); segundo = { abierto: !!a.dividir, platos: detalles(a) };
    if (a.dividir) { await separar(a, false); segundo.dividir = !!a.dividir; }
  }
  return { srvB, primero, segundo, avisos: avisosDiv(a), hecho: hechoDiv(a), cuentas: cuentasP(), prepagos: await prepagosAlCobrar(), impresos: impresos() };
}
for (const caso of @CASOS@) out[caso] = await p1(caso);
"""


def _cuenta(nombre, platos, prepago, pedido=True):
    return {"nombre": nombre, "platos": platos, "prepago": prepago, "pedido": 9 if pedido else None, "telefono": TEL if pedido else None}


@pytest.mark.parametrize("caso", ["prepago", "pedido", "comercio"])
def test_p1_pasar_todo_un_pedido_con_un_plato_de_otro_equipo_pide_volver_a_dividir_en_node(tmp_path, caso):
    casos = CASOS_P1.replace("@CASOS@", json.dumps([caso]))
    r = _correr(tmp_path / "ahora", casos)[caso]
    pre = 0 if caso == "pedido" else 1000
    srv_b = [_cuenta(PED, CUATRO, pre)]
    # B guardó su Limonada en la cuenta del pedido
    assert r["srvB"] == srv_b, r
    # A no pasó nada: el aviso de volver a abrir «Dividir», «Dividir» cerrado y la próxima apertura junta; una sola cuenta (la del pedido, con la
    # Limonada de B, lo ya pagado, el enlace y el teléfono) y lo ya pagado se descontaría una vez
    p = r["primero"]
    assert p["avisos"] == [AVISO_Y3] and p["dividir"] is False and p["alDia"] == 0 and p["hecho"] == [] and p["consultas"] == 1, r
    assert p["cuentas"] == srv_b and p["prepagos"] == [pre], r
    # al volver a abrir «Dividir» la pantalla tiene la Limonada y se pasa todo sin repetir el aviso: la cuenta aparte se lleva todo, lo ya pagado, el
    # enlace y el teléfono, y la cuenta del pedido desaparece; nada sale a cocina
    assert r["segundo"] == {"abierto": True, "platos": CUATRO, "dividir": False}, r
    assert r["avisos"] == [AVISO_Y3] and r["hecho"] == [TODO_APARTE], r
    assert r["cuentas"] == [_cuenta(PED + " · aparte", CUATRO, pre)] and r["prepagos"] == [pre] and r["impresos"] == [], r

    # antes de esta vuelta: se pasaba todo lo que se veía; la cuenta del pedido quedaba con la Limonada de B y TAMBIÉN con lo ya pagado, el enlace y el
    # teléfono, y la cuenta aparte con todo eso: lo ya pagado en línea se descontaba dos veces y el pedido quedaba enlazado a dos cuentas
    v = _correr(tmp_path / "antes", casos, antes=_antes())[caso]
    assert v["primero"]["avisos"] == [] and v["segundo"] is None and v["hecho"] == [TODO_APARTE] and v["primero"]["cuentas"] == v["cuentas"], v
    assert v["cuentas"] == [_cuenta(PED, LIMONADA1, pre), _cuenta(PED + " · aparte", TRES, pre)] and v["prepagos"] == [pre, pre], v


# 4.39 (undécima vuelta): era un xfail estricto (el defecto que dejaba P1); Q1 lo corrige: la consulta de antes de partir espera la lista hasta 3 s
# también sin platos por enviar, P1 ve la Limonada de B y sale el aviso. El control corre con confirmarDividir de antes de la undécima
def test_p1_con_la_lista_a_2_s_pasar_todo_no_duplica_el_prepago_en_node(tmp_path):
    # el caso de P1 (B agregó una Limonada con «Dividir» abierto en A) con la lista de A a 2 s: el pedido tiene todo enviado (y el envío, que no va a cocina)
    casos = CASOS_P1.replace("@CASOS@", json.dumps(["lenta"]))
    # control, antes de la undécima vuelta: la consulta esperaba 1,5 s como mucho y P1 miraba la copia que había, sin la Limonada: se pasaba todo y la
    # cuenta del pedido quedaba con la Limonada, lo ya pagado, el enlace y el teléfono, y la cuenta aparte también (se descontaba dos veces)
    v = _correr(tmp_path / "antes", casos, antes=(_metodo(_caja_sin_undecima(), "async confirmarDividir() {"),))["lenta"]
    assert v["primero"]["avisos"] == [] and v["segundo"] is None and v["hecho"] == [TODO_APARTE], v
    assert v["cuentas"] == [_cuenta(PED, LIMONADA1, 1000), _cuenta(PED + " · aparte", TRES, 1000)] and v["prepagos"] == [1000, 1000], v

    r = _correr(tmp_path / "ahora", casos)["lenta"]
    # todo lo pedido sigue en alguna cuenta, una sola vez
    assert sorted(sum((c["platos"] for c in r["cuentas"]), [])) == CUATRO, r
    # lo pagado en línea (₡1 000) está en UNA sola cuenta y se descuenta una vez; el pedido queda enlazado a una sola cuenta
    assert sum(c["prepago"] for c in r["cuentas"]) == 1000 and sum(r["prepagos"]) == 1000, r
    assert sum(1 for c in r["cuentas"] if c["pedido"] == 9) == 1, r
    # 4.39 (undécima vuelta): la lista llegó a los 2 s (la espera es de hasta 3 s): el aviso de volver a abrir «Dividir» y nada pasado; al volver a abrirlo
    # se pasa todo (también la Limonada) y la cuenta del pedido desaparece; nada sale a cocina
    p = r["primero"]
    assert p["avisos"] == [AVISO_Y3] and p["dividir"] is False and p["alDia"] == 0 and p["hecho"] == [] and p["cuentas"] == [_cuenta(PED, CUATRO, 1000)], r
    assert r["segundo"] == {"abierto": True, "platos": CUATRO, "dividir": False} and r["avisos"] == [AVISO_Y3] and r["hecho"] == [TODO_APARTE], r
    assert r["cuentas"] == [_cuenta(PED + " · aparte", CUATRO, 1000)] and r["prepagos"] == [1000] and r["impresos"] == [], r


def test_p1_separar_solo_una_parte_sigue_igual_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_P1.replace("@CASOS@", json.dumps(["parte"])))["parte"]
    # sin aviso (no se pasa todo): el Casado pasa a la cuenta aparte, sin lo ya pagado ni el enlace; la cuenta del pedido conserva el prepago (una vez),
    # el enlace, el teléfono, la Limonada de B y lo demás
    assert r["primero"]["avisos"] == [] and r["segundo"] is None and r["hecho"] == [APARTE] and r["impresos"] == [], r
    assert r["cuentas"] == [_cuenta(PED, ["Envío a domicilio×1", "Limonada×1", "Postre×1"], 1000), _cuenta(PED + " · aparte", CASADO1, 0, pedido=False)], r
    assert r["prepagos"] == [1000, 0] and r["primero"]["consultas"] == 1, r
    # control: antes de esta vuelta era igual (P1 solo mira cuando se pasa todo); _alDia es una hora
    v = _correr(tmp_path / "antes", CASOS_P1.replace("@CASOS@", json.dumps(["parte"])), antes=_antes())["parte"]
    sin_hora = lambda x: {**x, "primero": {**x["primero"], "alDia": None}}
    assert sin_hora(v) == sin_hora(r), v


CASOS_P1_SOLO = r"""
// un solo equipo (A), sin nada de otro equipo, con el pedido con prepago (con `pedido`, sin prepago). `caso`: pedido / prepago (como llega, sus líneas sin
// lid y el envío sin enviar); guardado0 (A lo guarda una vez: las líneas del servidor ya llevan lid); singuardar / guardado / ya (A agrega una Limonada:
// sin guardar, guardada, guardada y subida); comanda / comanda_ya (A agrega una Limonada y toca «Comanda»; con _ya, después de que su guardado llegó);
// cancelada (A abre «Cobrar estos platos» con el Casado y lo cancela: la parte vuelve a la cuenta); comercio (en la caja de comercio). A marca todo lo
// que ve y toca «Separar»
async function soloP1(caso) {
  const [a] = await pedidoAbierto(caso !== 'pedido', 1, caso === 'comercio');
  if (caso === 'guardado0') { a.persistirCuenta(); await a.A.mock.guardarTodo(); }
  if (['singuardar', 'guardado', 'ya', 'comanda', 'comanda_ya'].includes(caso)) a.lineas.push(LIMONADA());
  if (caso === 'guardado' || caso === 'ya') a.persistirCuenta();
  if (caso === 'ya') await a.A.mock.guardarTodo();
  if (caso.startsWith('comanda')) { await a.enviarComanda(); if (caso === 'comanda_ya') await a.A.mock.guardarTodo(); }
  let parte = null;
  if (caso === 'cancelada') {
    await a.abrirDividir(); a.dividir.destino = 'cobrar'; a.dividir.sel = { [a.lineas.findIndex(l => l.detalle === 'Casado')]: 1 }; await a.confirmarDividir(); await conPago(a);
    parte = { pago: !!a.pago, parcial: !!a.cobroParcial, platos: detalles(a) };
    a.cerrarPago(); for (let i = 0; i < 200 && a.cobroParcial; i++) await espera(5); await hastaLibre(); await a.A.mock.guardarTodo(); await hastaLibre();
    parte.vuelta = detalles(a);
  }
  await a.abrirDividir(); const abierto = !!a.dividir, lis = listas(a);
  const ms = await separar(a, false);
  return { abierto, parte, ms, consultas: lis.n, dividir: !!a.dividir, avisos: avisosDiv(a), hecho: hechoDiv(a), cuentas: cuentasP(), prepagos: await prepagosAlCobrar(), impresos: quienes(a) };
}
for (const caso of @CASOS@) out[caso] = await soloP1(caso);
"""
SOLO_P1 = {"pedido": (TRES, 0), "prepago": (TRES, 1000), "guardado0": (TRES, 1000), "singuardar": (CUATRO, 1000), "guardado": (CUATRO, 1000),
           "ya": (CUATRO, 1000), "comanda": (CUATRO, 1000), "comanda_ya": (CUATRO, 1000), "cancelada": (TRES, 1000), "comercio": (TRES, 1000)}


def test_p1_un_solo_equipo_pasa_todo_sin_aviso_en_node(tmp_path):
    r = _correr(tmp_path, CASOS_P1_SOLO.replace("@CASOS@", json.dumps(list(SOLO_P1))))
    for caso, (platos, pre) in SOLO_P1.items():
        x = r[caso]
        # sin el aviso: lo que A agregó (guardado o no), su propia «Comanda», la parte que volvió y las líneas del pedido sin lid no cuentan como «otro
        # equipo»; la cuenta aparte se lleva todo con lo ya pagado (una vez), el enlace y el teléfono, y la cuenta del pedido desaparece
        assert x["abierto"] is True and x["avisos"] == [] and x["hecho"] == [TODO_APARTE] and x["dividir"] is False, (caso, x)
        # dos consultas (la de antes de partir y la sincronización de siempre al cerrar la cuenta en esta pantalla), sin esperar
        assert x["consultas"] == 2 and x["ms"] < 1000, (caso, x)
        assert x["cuentas"] == [_cuenta(PED + " · aparte", platos, pre)] and x["prepagos"] == [pre], (caso, x)
        # la comanda de la Limonada salió una vez, de A; nada más salió a cocina
        assert x["impresos"] == ([["A", LIMONADA1]] if caso.startswith("comanda") else []), (caso, x)
    # la parte de «Cobrar estos platos» se abrió y, al cancelarla, el Casado volvió a la cuenta
    c = r["cancelada"]["parte"]
    assert c["pago"] is True and c["parcial"] is True and c["platos"] == CASADO1 and c["vuelta"] == TRES, c


# ================================================================================================================ R1: la lista lenta
CASOS_R1 = r"""
// la cuenta con Casado y Postre sin enviar en A y en B: la Mesa 6 (nueva, 7) o la cuenta guardada sin mesa (partes). A abre «Dividir»; B toca «Comanda»
// (sale enseguida y su guardado llega al servidor). Desde ahí la lista de cuentas de A tarda `ms`. A elige el Casado para `destino` (o 2 partes iguales)
// y confirma. Después un tercer equipo abre cada cuenta del servidor y toca «Comanda»
async function r1(destino, ms) {
  const [id, a, b] = await cuenta(destino !== 'partes', [CASADO(), POSTRE()]); a.mesas = [M6, M7];
  await a.abrirDividir();
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  const suelta = lento(a, ms), lis = listas(a), t0 = Date.now();
  elegirCasado(a, destino); await a.confirmarDividir(); const t = Date.now() - t0;
  await espera(Math.max(0, ms - t) + 50); suelta(); await a.A.mock.guardarTodo(); await hastaLibre();
  const primero = { ms: t, consultas: lis.n, dividir: !!a.dividir, alDia: a._alDia, avisos: avisosDiv(a), hecho: hechoDiv(a), srv: srv(), enviados: enviados() };
  await otraComanda();
  return { primero, impresos: impresos(), enviados: enviados() };
}
for (const destino of @DESTINOS@) out[destino] = await r1(destino, @MS@);
"""
# antes de esta vuelta, después de partir con la copia vieja: lo que quedaba en el servidor, lo enviado a cocina en cada cuenta y lo que salió a cocina,
# contando la próxima «Comanda»
R1_ANTES = {"nueva": ([["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], [POSTRE1, []], [AMBOS, CASADO1]),
            "7": ([["Mesa 6", POSTRE1, None], ["Mesa 7", CASADO1, None]], [POSTRE1, []], [AMBOS, CASADO1]),
            "partes": ([["Cuenta 1", MEDIAS, None], ["Cuenta 1 · parte 2 de 2", MEDIAS, None]], [[], []], [AMBOS, MEDIAS, MEDIAS])}


def test_r1_con_la_lista_lenta_lo_que_otro_equipo_mando_a_cocina_no_se_parte_en_node(tmp_path):
    casos = CASOS_R1.replace("@DESTINOS@", json.dumps(["nueva", 7, "partes"])).replace("@MS@", "2000")
    r = _correr(tmp_path / "ahora", casos)
    for destino in ("nueva", "7", "partes"):
        x, p = r[destino], r[destino]["primero"]
        nombre = "Cuenta 1" if destino == "partes" else "Mesa 6"
        # la lista llegó a los 2 s (la espera de hasta 3 s): la comanda de B se vio; el aviso «Otro equipo mandó a cocina…», «Dividir» cerrado y nada partido
        assert 1950 <= p["ms"] < 2900 and p["consultas"] == 1, (destino, x)
        assert p["avisos"] == [AVISO_DIVIDIR_7] and p["dividir"] is False and p["alDia"] == 0 and p["hecho"] == [], (destino, x)
        assert p["srv"] == [[nombre, AMBOS, None]] and p["enviados"] == [AMBOS], (destino, x)
        # cada plato salió a cocina una vez (la comanda de B); la próxima «Comanda» no manda nada
        assert x["impresos"] == [AMBOS] and x["enviados"] == [AMBOS], (destino, x)

    # antes de esta vuelta: la consulta esperaba 1,5 s y se partía con la copia vieja: lo partido pasaba «sin enviar» a la otra cuenta (o a las dos partes)
    # y su próxima «Comanda» lo mandaba otra vez a cocina
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for destino in ("nueva", "7", "partes"):
        x, p = v[destino], v[destino]["primero"]
        srv, enviados, impresos = R1_ANTES[destino]
        assert 1400 <= p["ms"] < 1950 and p["avisos"] == [] and len(p["hecho"]) == 1 and p["srv"] == srv and p["enviados"] == enviados, (destino, x)
        assert x["impresos"] == impresos, (destino, x)                       # el Casado (o la mitad de cada plato, en cada parte) salió dos veces


CASOS_R1_X2 = r"""
// la Mesa 6 (o, con partes, la cuenta guardada sin mesa) con Casado y Postre sin enviar en A y en B. A agrega una Limonada y la guarda sin enviar; B toca
// «Comanda» (salen el Casado y el Postre). A sincroniza (la marca), abre «Dividir», elige la Limonada para `destino` (o 2 partes iguales) y confirma: espera
// la marca. Desde ese momento la lista de A tarda 2 s. A los 1,5 s B sincroniza (le llega la Limonada) y toca «Comanda» otra vez. Después un tercer equipo
// abre cada cuenta del servidor y toca «Comanda»
async function r1x2(destino) {
  const [id, a, b] = await cuenta(destino !== 'partes'); a.mesas = [M6, M7];
  a.lineas.push(LIMONADA()); a.persistirCuenta(); await a.A.mock.guardarTodo();
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  await a.sincronizar(); const m0 = !!marca(a);
  await a.abrirDividir();
  if (destino === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; } else { a.dividir.destino = destino; a.dividir.sel = { [a.lineas.findIndex(l => l.detalle === 'Limonada')]: 1 }; }
  const t0 = Date.now(), pd = a.confirmarDividir(), suelta = lento(a, 2000), lis = listas(a);
  await espera(1500); await b.sincronizar(); const limB = b.lineas.filter(l => l.detalle === 'Limonada' && !l.enviado).length; await b.enviarComanda(); await b.A.mock.guardarTodo();
  await pd; const ms = Date.now() - t0; await espera(2100); suelta(); await a.A.mock.guardarTodo(); await hastaLibre(); await b.A.mock.guardarTodo();
  const primero = { m0, limB, ms, consultas: lis.n, dividir: !!a.dividir, alDia: a._alDia, avisos: avisosDiv(a), hecho: hechoDiv(a), srv: srv(), enviados: enviados() };
  await otraComanda();
  return { primero, impresos: impresos(), enviados: enviados() };
}
out.r = await r1x2(@DESTINO@);
"""
CON_LIM = ["Casado×1", "Limonada×1", "Postre×1"]
MEDIAS_LIM = ["Casado×0.5", "Limonada×0.5", "Postre×0.5"]
# antes de esta vuelta: lo que quedaba en el servidor y lo que salió a cocina, contando la próxima «Comanda» (la Limonada, otra vez)
R1_X2_ANTES = {"nueva": ([["Mesa 6", AMBOS, None], ["Mesa 6 · aparte", LIMONADA1, None]], [AMBOS, LIMONADA1, LIMONADA1]),
               "7": ([["Mesa 6", AMBOS, None], ["Mesa 7", LIMONADA1, None]], [AMBOS, LIMONADA1, LIMONADA1]),
               "partes": ([["Cuenta 1", MEDIAS_LIM, None], ["Cuenta 1 · parte 2 de 2", MEDIAS_LIM, None]], [AMBOS, LIMONADA1, ["Limonada×0.5"], ["Limonada×0.5"]])}


@pytest.mark.parametrize("destino", ["nueva", "7", "partes"])
def test_r1_despues_de_esperar_la_marca_con_la_lista_lenta_en_node(tmp_path, destino):
    casos = CASOS_R1_X2.replace("@DESTINO@", json.dumps(7 if destino == "7" else destino))
    r = _correr(tmp_path / "ahora", casos)["r"]
    p = r["primero"]
    nombre = "Cuenta 1" if destino == "partes" else "Mesa 6"
    # A vio la comanda de B (la marca) y esperó; B tenía la Limonada sin enviar para su segunda comanda; la consulta de después de esperar trajo la lista
    # a los 2 s (espera de hasta 3 s): la segunda «Comanda» de B se vio
    assert p["m0"] is True and p["limB"] == 1 and p["consultas"] == 1 and 5000 <= p["ms"] < 8500, (destino, r)
    # el aviso «…mientras se esperaba», «Dividir» cerrado y nada partido; la Limonada salió una vez (de B) y la próxima «Comanda» no manda nada
    assert p["avisos"] == [CAMBIO_DIV] and p["dividir"] is False and p["alDia"] == 0 and p["hecho"] == [], (destino, r)
    assert p["srv"] == [[nombre, CON_LIM, None]] and p["enviados"] == [CON_LIM], (destino, r)
    assert r["impresos"] == [AMBOS, LIMONADA1] and r["enviados"] == [CON_LIM], (destino, r)

    # antes de esta vuelta: la consulta esperaba 1,5 s y se partía con la copia vieja (la Limonada «sin enviar»): su próxima «Comanda» la mandaba otra vez
    v = _correr(tmp_path / "antes", casos, antes=_antes())["r"]
    srv, impresos = R1_X2_ANTES[destino]
    assert v["primero"]["m0"] is True and v["primero"]["avisos"] == [] and len(v["primero"]["hecho"]) == 1 and v["primero"]["srv"] == srv, (destino, v)
    assert v["impresos"] == impresos, (destino, v)


CASOS_R1_SOLO = r"""
// un solo equipo (A), sin nada de otro equipo; la lista de cuentas de A tarda 2 s. `caso`: nueva, 7 o partes con Casado y Postre sin enviar (la Mesa 6;
// partes, la cuenta guardada sin mesa); nueva_env (los platos enviados hace un minuto); cobrar («Cobrar estos platos» con el Casado sin enviar); comercio
// (la cuenta guardada en la caja de comercio, separar el Casado). Cuánto tarda confirmarDividir (con cobrar, hasta que se abre el cobro de la parte)
async function soloR1(caso) {
  const [accion, env] = caso.split('_'), com = accion === 'comercio';
  const platos = env ? [{ ...CASADO(), enviado: VIEJA(), ronda: 1 }, { ...POSTRE(), enviado: VIEJA(), ronda: 1 }] : [CASADO(), POSTRE()];
  const [id, a] = await cuenta(accion !== 'partes' && !com, platos); a.mesas = [M6, M7]; if (com) a.esRestaurante = false;
  await a.abrirDividir(); const suelta = lento(a, 2000), lis = listas(a), t0 = Date.now();
  elegirCasado(a, com ? 'nueva' : (accion === '7' ? 7 : accion));
  const pd = a.confirmarDividir();
  if (accion === 'cobrar') { for (let i = 0; i < 1000 && !a.cobroParcial; i++) await espera(2); } else await pd;
  const ms = Date.now() - t0, consultas = lis.n;
  await pd; if (accion === 'cobrar') { await conPago(a); if (a.pago) await a.cobrar(); }
  await espera(2100); suelta(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { ms, consultas, dividir: !!a.dividir, avisos: otrosAvisos(a), hecho: hechoDiv(a), srv: srv(), hechos: cobrados(a), impresos: quienes(a) };
}
for (const caso of @CASOS@) out[caso] = await soloR1(caso);
"""
SOLO_R1 = {"nueva": [["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], "7": [["Mesa 6", POSTRE1, None], ["Mesa 7", CASADO1, None]],
           "partes": [["Cuenta 1", MEDIAS, None], ["Cuenta 1 · parte 2 de 2", MEDIAS, None]],
           "nueva_env": [["Mesa 6", POSTRE1, None], ["Mesa 6 · aparte", CASADO1, None]], "cobrar": [["Mesa 6", POSTRE1, None]],
           "comercio": [["Cuenta 1", POSTRE1, None], ["Cuenta 1 · aparte", CASADO1, None]]}


def test_r1_un_solo_equipo_con_la_lista_lenta_en_node(tmp_path):
    casos = CASOS_R1_SOLO.replace("@CASOS@", json.dumps(list(SOLO_R1)))
    r = _correr(tmp_path / "ahora", casos)
    for caso, srv in SOLO_R1.items():
        x = r[caso]
        # sin aviso, una consulta y se divide (o se cobra) igual
        assert x["avisos"] == [] and x["consultas"] == 1 and x["dividir"] is False and x["srv"] == srv and x["impresos"] == [], (caso, x)
    # con platos por enviar, al separar, pasar o partir: se espera la lista (llega a los 2 s, la espera es de hasta 3 s)
    for caso in ("nueva", "7", "partes"):
        assert 1950 <= r[caso]["ms"] < 2900, (caso, r[caso])
    # sin platos por enviar, con «Cobrar estos platos» y en la caja de comercio: 1,5 s como antes y se sigue con la copia que hay. 4.39 (undécima vuelta):
    # Q1 lleva el tope de 3 s a las tres consultas de confirmarDividir: con la lista a 2 s también se espera la lista (unos 2 s)
    for caso in ("nueva_env", "cobrar", "comercio"):
        assert 1950 <= r[caso]["ms"] < 2900, (caso, r[caso])
    assert r["cobrar"]["hechos"] == [["A", CASADO1]], r["cobrar"]

    # antes de esta vuelta: 1,5 s en todos los casos (con la lista a 2 s se partía con la copia que había); lo demás, igual
    v = _correr(tmp_path / "antes", casos, antes=_antes())
    for caso, srv in SOLO_R1.items():
        x = v[caso]
        assert 1400 <= x["ms"] < 1950 and x["avisos"] == [] and x["srv"] == srv, (caso, x)


# ================================================================================================================ contrato
def test_contrato_de_la_decima_vuelta():
    # 4.39 (undécima vuelta): «ahora» es caja.js sin la undécima vuelta (la undécima cambió las dos consultas de R1 y su comentario, y la de la caja de
    # comercio); lo de la undécima está en tests/test_439_undecima_vuelta.py
    k, k0 = _caja_sin_undecima(), _caja_sin_decima()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    # cada tripleta de DECIMA: «lo de ahora» está en caja.js las veces anotadas, todas dentro de confirmarDividir; el método cambió
    assert len(DECIMA) == 3
    for viejo, nuevo, veces in DECIMA:
        assert k.count(nuevo) == veces and k0.count(viejo) == veces and k0.count(nuevo) == 0, nuevo[:120]
        assert sum(m.count(nuevo) for m in metodos.values()) == veces, nuevo[:120]
    for c in metodos:
        assert metodos[c] != antes[c], c
    # fuera de él, caja.js no cambió
    resto, resto0 = k, k0
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], ""), resto0.replace(antes[c], "")
    assert resto == resto0
    # lo de la vuelta lleva su comentario (R1 y P1)
    assert k.count("4.39 (décima vuelta)") == 2 and k0.count("4.39 (décima vuelta)") == 0
    cd, cd0 = metodos["async confirmarDividir() {"], antes["async confirmarDividir() {"]
    # R1: las dos consultas del restaurante con el tope de 3 s (platos por enviar al separar, pasar o partir); la de la caja de comercio sigue en 1,5 s
    assert cd.count("new Promise(r => setTimeout(r, " + ESPERA_R1 + "))") == 2 and cd.count(REFRESCAR15) == 1 and cd0.count(REFRESCAR15) == 3
    assert cd.index("new Promise(r => setTimeout(r, " + ESPERA_R1 + "))") < cd.index("const espero = ") < cd.index("if (espero) {") \
        < cd.rindex("new Promise(r => setTimeout(r, " + ESPERA_R1 + "))") < cd.index("const firma = l => ") < cd.index("if (!this.esRestaurante) { " + REFRESCAR15)
    # P1: solo en la rama de la cuenta aparte, después de calcular `todo` y antes de crearla; con la base de ESA cuenta, la lista ya traída y ponerLids
    p1 = ("{ const ib = this.esperaId, bb = this._base; if (todo && ib !== null && ib !== undefined && bb && bb.id === ib) { const cs = enEspera().find(v => v.id === ib), "
          "bl = new Set((bb.lineas || []).map(l => l.lid)); if (cs && (ponerLids(JSON.parse(JSON.stringify(cs))).lineas || []).some(l => !bl.has(l.lid))) { this._alDia = 0; "
          "this.dividir = null; return toast('" + AVISO_Y3 + "', 'err'); } } }")
    assert cd.count(p1) == 1
    assert cd.index("if (d.destino === 'nueva') {") < cd.index("todo = !resto.length && c0 && (c0.canal === 'online'") < cd.index(p1) \
        < cd.index("this.nuevaCuentaEspera((this.nombreEspera || 'Cuenta') + ' · aparte', mov, null, todo ?")
    # las notas de la versión cuentan la vuelta: el botón de «Pedidos web», «Dividir» (las partes de una mesa juntan solas, lo que hace volver a dividir
    # durante la espera y el plato solo agregado), P1, el límite de «Cobrar estos platos» y Técnico. 4.39 (undécima vuelta): la undécima reescribió el
    # límite de la red muy lenta y la lista de pruebas de Técnico: esas frases pasaron al contrato de la undécima (tests/test_439_undecima_vuelta.py)
    notas = (RAIZ / "notas" / "4.39.md").read_text(encoding="utf-8")
    for t in ("deja de contarlo en ese momento (y deja de estar rojo si no quedan otros pedidos nuevos)",
              "(en las partes iguales de una mesa la junta sola y sigue, sin aviso)",
              "si durante esa espera otro equipo cobra una parte, quita o cambia un plato (o el servicio), la caja pide volver a dividir",
              "un plato que otro equipo solo agregó queda en la cuenta de origen y la caja avisa que se sumó",
              "Pasar todos los platos de un pedido en línea a una cuenta aparte tampoco se hace si otro equipo le agregó un plato",
              "(antes lo ya pagado en línea quedaba en las dos cuentas y se descontaba dos veces)",
              "otro equipo baja, quita o cambia un plato (precio, descuento o nota) y aquí se usa «Cobrar estos platos»",
              "y lo que queda en la cuenta de un plato cobrado en parte también queda como estaba aquí",
              "Décima vuelta: pasar todo un pedido en línea o con prepago a una cuenta aparte vuelve a pedir «Dividir»",
              "las dos consultas del restaurante en confirmarDividir esperan la lista hasta 3 s al separar, pasar o partir"):
        assert notas.count(t) == 1, t
    # y ya no dicen lo de antes
    for t in ("deja de estar rojo en ese momento.", "si otro equipo cambia la cuenta durante esa espera", "otro equipo baja o quita un plato y aquí",
              "ajustes explicados en test_427 y test_432."):
        assert notas.count(t) == 0, t
