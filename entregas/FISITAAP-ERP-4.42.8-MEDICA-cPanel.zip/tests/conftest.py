"""Configuración común de las pruebas: los módulos de la aplicación trabajan sobre una carpeta de datos TEMPORAL (bases, llaves,
XML), nunca sobre data/ real. Se define antes de que cualquier prueba importe app.*."""
import os
import pathlib
import tempfile

_TMP = pathlib.Path(tempfile.mkdtemp(prefix="facturacr_pruebas_"))
os.environ["FE_DATA_DIR"] = str(_TMP)
os.environ["FE_DB_URL"] = f"sqlite:///{(_TMP / 'facturacr.db').as_posix()}"
os.environ["FE_COLA_HILO"] = "0"
os.environ["FE_SINC_HTTP"] = "1"                 # las pruebas simulan la nube en direcciones http
os.environ["FE_URL_PUBLICA"] = "http://pruebas.local"
os.environ["FE_RESPALDOS_DIR"] = str(_TMP / "respaldos")
os.environ["FE_CABYS_SINCRONO"] = "1"
os.environ["FE_PRUEBAS_TESTCLIENT"] = "1"        # 4.25: solo aquí; en el programa local real el cliente «testclient» no exime de la revisión de Host y Origin (sinc.revisar_host_origen)
os.environ["FE_SINC_DATOS"] = "0"                # 4.32: el canal nuevo (/api/sinc/datos) apagado para las pruebas viejas; las del 4.32 lo encienden con monkeypatch.setenv


def _limpiar_viejas():
    """Carpetas de corridas anteriores que no se pudieron borrar al salir (en Windows un archivo abierto no se borra, y cada una pesa
    unos 40 MB: llegaron a llenar el disco). Solo las de más de un día, para no tocar la de otra corrida que esté en marcha."""
    import shutil
    import time
    limite = time.time() - 24 * 3600
    for p in _TMP.parent.glob("facturacr_pruebas_*"):
        try:
            if p != _TMP and p.is_dir() and p.stat().st_ctime < limite:
                shutil.rmtree(p, ignore_errors=True)
        except OSError:
            pass


_limpiar_viejas()


def _limpiar():
    import gc
    import shutil
    try:
        from app import db
        for eng, _ in list(db._engines.values()):      # las bases de cada empresa también quedan abiertas: sin cerrarlas no se borra nada
            try:
                eng.dispose()
            except Exception:  # noqa: BLE001
                pass
        db._engines.clear()
        db.engine.dispose()
    except Exception:  # noqa: BLE001
        pass
    gc.collect()
    shutil.rmtree(_TMP, ignore_errors=True)


import atexit  # noqa: E402
atexit.register(_limpiar)
os.environ.pop("FE_ENTORNO", None)
os.environ.pop("FE_SETUP_TOKEN", None)
