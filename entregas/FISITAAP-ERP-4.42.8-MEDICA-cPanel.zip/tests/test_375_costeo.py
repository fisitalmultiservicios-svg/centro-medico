"""3.75: costeo del inventario por capas (promedio ponderado, PEPS y UEPS), entradas por compra (CO-####) que actualizan el
costo del ítem, y las líneas del comprobante recibido relacionadas con los ítems (o creadas) al aceptarlo."""
from decimal import Decimal

import pytest
from sqlmodel import Session, select

from app import auth, inventario, recepcion
from app.db import Empresa, engine, engine_empresa
from app.fe.clave import generar_clave, generar_consecutivo
from app.fe.modelos import Descuento, Identificacion, Impuesto, Linea, Parte
from app.fe.xml_builder import a_bytes, construir_xml
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)
from tests.test_fe import CEDULA, FECHA, comprobante

CABYS = "2395100000100"


def _eid():
    from app.main import app
    return app.dependency_overrides[auth.contexto]().empresa.id


def _prod(c, nombre, costo=0, codigo=None, **extra):
    r = c.post("/api/productos", json={"nombre": nombre, "cabys": CABYS, "precio": 1000, "tarifa": 13, "codigo_tarifa": "08", "costo": costo, "codigo": codigo, **extra})
    assert r.status_code == 200, r.text
    return r.json()


def _compra(c, pid, cantidad, costo, **extra):
    r = c.post("/api/inventario/compras", json={"lineas": [{"producto_id": pid, "cantidad": cantidad, "costo_unitario": costo}], **extra})
    assert r.status_code == 200, r.text
    return r.json()


def _baja(c, pid, cantidad, costo=None):
    r = c.post("/api/inventario/ajustes", json={"lineas": [{"producto_id": pid, "tipo": "disminucion", "cantidad": cantidad, "costo_unitario": costo}]})
    assert r.status_code == 200, r.text
    return r.json()


def _ex(c, pid):
    return next(e for e in c.get("/api/inventario/existencias").json() if e["producto_id"] == pid)


def _capas(c, pid):
    return c.get(f"/api/inventario/capas?producto_id={pid}").json()


def _config(c, metodo, actualizar=True):
    r = c.put("/api/inventario/config", json={"metodo": metodo, "actualizar_costo_compras": actualizar})
    assert r.status_code == 200, r.text
    return r.json()


def _producto(c, pid):
    return next(p for p in c.get("/api/productos").json() if p["id"] == pid)


def test_promedio_sigue_igual_y_lleva_capas(api):  # noqa: F811
    c = api
    assert c.get("/api/inventario/config").json()["metodo"] == "promedio"
    p = _prod(c, "Cemento promedio")
    _compra(c, p["id"], 10, 100); _compra(c, p["id"], 10, 200)
    ex = _ex(c, p["id"]); assert ex["cantidad"] == 20 and ex["costo_promedio"] == 150
    a = _baja(c, p["id"], 5)
    assert a["movimientos"][0]["costo_unitario"] == 150 and a["total"] == -750         # la salida va al promedio, como siempre
    ex = _ex(c, p["id"]); assert ex["cantidad"] == 15 and ex["costo_promedio"] == 150
    k = _capas(c, p["id"])                                                              # las capas se llevan igual (por si cambia de método)
    assert k["metodo"] == "promedio" and [(x["cantidad"], x["costo_unitario"]) for x in k["capas"]] == [(5, 100), (10, 200)]
    assert [(x["cantidad"], x["costo_unitario"]) for x in a["movimientos"][0]["capas"]] == [(5, 100)]


def test_peps(api):  # noqa: F811
    c = api
    r = _config(c, "peps"); assert r["metodo"] == "peps" and "recalculados" in r
    p = _prod(c, "Cemento PEPS")
    _compra(c, p["id"], 10, 100, fecha="2026-10-01"); _compra(c, p["id"], 10, 200, fecha="2026-10-02")
    assert _ex(c, p["id"])["costo_promedio"] == 150
    a = _baja(c, p["id"], 15, costo=999)                                               # el costo enviado no manda: salen las capas
    m = a["movimientos"][0]
    assert m["costo_unitario"] == pytest.approx((10 * 100 + 5 * 200) / 15) and a["total"] == pytest.approx(-2000) and a["metodo"] == "peps"
    assert [(x["cantidad"], x["costo_unitario"], x["fecha"]) for x in m["capas"]] == [(10, 100, "2026-10-01"), (5, 200, "2026-10-02")]
    ex = _ex(c, p["id"]); assert ex["cantidad"] == 5 and ex["costo_promedio"] == 200   # lo que queda vale lo de su capa
    k = _capas(c, p["id"]); assert [(x["cantidad"], x["costo_unitario"]) for x in k["capas"]] == [(5, 200)] and k["valor"] == 1000
    v = c.get("/api/inventario/valor").json(); assert v["total"] == 1000
    v2 = c.get("/api/inventario/valor?hasta=2099-12-31").json(); assert v2["total"] == pytest.approx(1000)   # a una fecha: suma de movimientos
    assert next(x for x in v2["items"] if x["producto_id"] == p["id"])["costo_promedio"] == pytest.approx(200)


def test_ueps(api):  # noqa: F811
    c = api
    _config(c, "ueps")
    p = _prod(c, "Cemento UEPS")
    _compra(c, p["id"], 10, 100, fecha="2026-10-01"); _compra(c, p["id"], 10, 200, fecha="2026-10-02")
    a = _baja(c, p["id"], 15)
    m = a["movimientos"][0]
    assert m["costo_unitario"] == pytest.approx((10 * 200 + 5 * 100) / 15)
    assert [(x["cantidad"], x["costo_unitario"]) for x in m["capas"]] == [(10, 200), (5, 100)]
    ex = _ex(c, p["id"]); assert ex["cantidad"] == 5 and ex["costo_promedio"] == 100
    assert [(x["cantidad"], x["costo_unitario"]) for x in _capas(c, p["id"])["capas"]] == [(5, 100)]


def test_existencia_anterior_ventas_y_devoluciones(api):  # noqa: F811
    c = api
    _config(c, "peps")
    eid = _eid()
    p = _prod(c, "Pintura vieja", costo=50, cantidad_inicial=10)
    with Session(engine_empresa(eid)) as s:                     # existencia de antes de 3.75: sin capas
        for k in s.exec(select(inventario.CapaCosto).where(inventario.CapaCosto.producto_id == p["id"])).all():
            s.delete(k)
        s.commit()
    assert _capas(c, p["id"])["capas"] == [] and _ex(c, p["id"])["costo_promedio"] == 50
    _compra(c, p["id"], 5, 80, fecha="2026-10-05")
    with Session(engine_empresa(eid)) as s:
        inventario.descontar_por_venta(s, eid, None, "FE 001", None, [{"producto_id": p["id"], "cantidad": 12}], "2026-10-06"); s.commit()
    movs = c.get(f"/api/inventario/movimientos?producto_id={p['id']}").json()
    venta = movs[0]
    assert venta["tipo"] == "venta" and venta["costo_unitario"] == pytest.approx((10 * 50 + 2 * 80) / 12)   # la base (vieja) sale primero
    ex = _ex(c, p["id"]); assert ex["cantidad"] == 3 and ex["costo_promedio"] == 80
    k = _capas(c, p["id"]); assert [(x["cantidad"], x["costo_unitario"], x["base"]) for x in k["capas"]] == [(3, 80, False)]
    with Session(engine_empresa(eid)) as s:                     # devolución: vuelve al costo que había
        inventario.descontar_por_venta(s, eid, None, "NC 001", None, [{"producto_id": p["id"], "cantidad": 2}], "2026-10-07", devolucion=True); s.commit()
    ex = _ex(c, p["id"]); assert ex["cantidad"] == 5 and ex["costo_promedio"] == 80
    assert [(x["cantidad"], x["costo_unitario"]) for x in _capas(c, p["id"])["capas"]] == [(3, 80), (2, 80)]


def test_existencia_negativa(api):  # noqa: F811
    c = api
    _config(c, "peps")
    p = _prod(c, "Hielo negativo", venta_negativo=True)
    _compra(c, p["id"], 4, 100)
    a = _baja(c, p["id"], 6)
    m = a["movimientos"][0]
    assert m["costo_unitario"] == 100 and [(x["cantidad"], x["capa_id"] is None) for x in m["capas"]] == [(4, False), (2, True)]
    assert _ex(c, p["id"])["cantidad"] == -2 and _capas(c, p["id"])["capas"] == []
    _compra(c, p["id"], 10, 150)                                # lo ya vendido en negativo no abre capa
    ex = _ex(c, p["id"]); assert ex["cantidad"] == 8 and ex["costo_promedio"] == 150
    assert [(x["cantidad"], x["costo_unitario"]) for x in _capas(c, p["id"])["capas"]] == [(8, 150)]


def test_transferencia_peps(api):  # noqa: F811
    c = api
    _config(c, "peps")
    principal = next(b for b in c.get("/api/inventario/bodegas").json() if b["principal"])["id"]
    suc = c.post("/api/inventario/bodegas", json={"nombre": "Sucursal costeo", "activa": True}).json()["id"]
    p = _prod(c, "Cable transferido")
    _compra(c, p["id"], 10, 100, fecha="2026-10-01"); _compra(c, p["id"], 10, 200, fecha="2026-10-02")
    r = c.post("/api/inventario/transferencias", json={"origen_id": principal, "destino_id": suc, "lineas": [{"producto_id": p["id"], "cantidad": 12}]})
    assert r.status_code == 200, r.text
    salida, entrada = r.json()["movimientos"]
    esperado = (10 * 100 + 2 * 200) / 12
    assert salida["costo_unitario"] == pytest.approx(esperado) and entrada["costo_unitario"] == pytest.approx(esperado)
    ex = _ex(c, p["id"])
    assert ex["bodegas"][str(principal)]["cantidad"] == 8 and ex["bodegas"][str(principal)]["costo_promedio"] == 200
    assert ex["bodegas"][str(suc)]["cantidad"] == 12 and ex["bodegas"][str(suc)]["costo_promedio"] == pytest.approx(esperado)


def test_compra_actualiza_costo_y_numera(api):  # noqa: F811
    c = api
    p = _prod(c, "Tubo PVC", costo=0)
    a = _compra(c, p["id"], 5, 120, numero="FAC-77", proveedor="Ferretería QA")
    assert a["codigo"] == "CO-0001" and a["tipo"] == "compra" and a["total"] == 600 and a["movimientos"][0]["tipo"] == "compra"
    assert "Compra FAC-77" in a["observaciones"] and "Ferretería QA" in a["observaciones"]
    assert _producto(c, p["id"])["costo"] == 120                                       # la compra actualiza el costo del ítem
    assert any(x["codigo"] == "CO-0001" and x["tipo"] == "compra" for x in c.get("/api/inventario/ajustes").json())
    _config(c, "promedio", actualizar=False)
    _compra(c, p["id"], 5, 130)
    assert _producto(c, p["id"])["costo"] == 120                                       # apagado: el costo del ítem no cambia
    assert _compra(c, p["id"], 1, 140, actualizar_costo=True)["codigo"] == "CO-0003" and _producto(c, p["id"])["costo"] == 140
    assert c.post("/api/inventario/compras", json={"lineas": [], }).status_code == 400
    assert c.post("/api/inventario/compras", json={"recepcion_id": 999, "lineas": [{"producto_id": p["id"], "cantidad": 1, "costo_unitario": 1}]}).status_code == 404
    serv = c.post("/api/productos", json={"nombre": "Instalación", "cabys": "8311000000000", "precio": 1000, "es_servicio": True, "tipo": "Servicio"}).json()
    assert c.post("/api/inventario/compras", json={"lineas": [{"producto_id": serv["id"], "cantidad": 1, "costo_unitario": 1}]}).status_code == 400
    assert c.put("/api/inventario/config", json={"metodo": "fifo"}).status_code == 422


def _xml_proveedor(numero=1, seguridad="12345678", **kw):
    cons = generar_consecutivo("01", numero)
    recep = Parte(nombre="Empresa Exoneraciones QA", identificacion=Identificacion(tipo="02", numero="3101999999"), correo="facturas@example.test")
    lineas = [
        Linea(cabys=CABYS, detalle="Cemento gris 50 kg", cantidad=Decimal(10), unidad_medida="Unid", precio_unitario=Decimal("9000"), codigo_comercial="CEM-50"),
        Linea(cabys="8311000000000", detalle="Transporte", es_servicio=True, unidad_medida="Sp", precio_unitario=Decimal("5000")),
        Linea(cabys="3511000000100", detalle="Pintura blanca 1 gal", cantidad=Decimal(2), precio_unitario=Decimal("12000"),
              descuentos=[Descuento(monto=Decimal("4000"), naturaleza="Promoción")], impuestos=[Impuesto(codigo_tarifa="08", tarifa=Decimal(13))]),
    ]
    comp = comprobante("01", clave=generar_clave(CEDULA, cons, FECHA, codigo_seguridad=seguridad), consecutivo=cons, receptor=recep, lineas=lineas, **kw)
    return a_bytes(construir_xml(comp))


def _registrar(eid, xml):
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
    with Session(engine_empresa(eid)) as s:
        r, estado = recepcion.registrar(s, e, xml)
        assert estado == "nuevo", estado
        return r.id


def test_lineas_del_comprobante_recibido_e_inventario(api):  # noqa: F811
    c = api
    eid = _eid()
    cem = _prod(c, "Cemento gris 50 kg", costo=8000, codigo="CEM-50")
    rid = _registrar(eid, _xml_proveedor(1))
    r = c.get(f"/api/recepcion/{rid}/lineas"); assert r.status_code == 200, r.text
    d = r.json()
    assert d["con_mercaderia"] and d["tipo_cambio"] == 1 and d["config"]["metodo"] == "promedio"
    l1, l2, l3 = d["lineas"]
    assert l1["codigo"] == "CEM-50" and l1["cabys"] == CABYS and l1["cantidad"] == 10 and l1["costo_crc"] == 9000 and l1["producto_id"] == cem["id"] and l1["motivo"] == "codigo"
    assert l2["detalle"] == "Transporte" and l2["producto_id"] is None
    assert l3["descuento"] == 4000 and l3["subtotal"] == 20000 and l3["costo_crc"] == 10000 and l3["producto_id"] is None and l3["tarifa"] == 13
    # entra: la línea 1 al ítem existente, la 3 como ítem nuevo, la 2 (servicio) no entra
    r = c.post(f"/api/recepcion/{rid}/inventario", json={"lineas": [{"numero": 1, "producto_id": cem["id"]}, {"numero": 3, "crear": {"precio": 15000, "categoria": "Pinturas"}}, {"numero": 2}]})
    assert r.status_code == 200, r.text
    x = r.json()
    assert x["entradas"] == 2 and x["omitidas"] == 1 and x["relaciones"] == 2 and [n["nombre"] for n in x["creados"]] == ["Pintura blanca 1 gal"]
    assert x["ajuste"]["codigo"] == "CO-0001" and x["ajuste"]["tipo"] == "compra" and len(x["ajuste"]["movimientos"]) == 2
    nuevo = _producto(c, x["creados"][0]["id"])
    assert nuevo["cabys"] == "3511000000100" and nuevo["costo"] == 10000 and nuevo["precio"] == 15000 and nuevo["categoria"] == "Pinturas" and nuevo["inventariable"]
    assert _ex(c, cem["id"])["cantidad"] == 10 and _ex(c, cem["id"])["costo_promedio"] == 9000 and _ex(c, nuevo["id"])["cantidad"] == 2
    assert _producto(c, cem["id"])["costo"] == 9000                                    # el costo del ítem pasa al de la factura
    fila = next(z for z in c.get("/api/recepcion").json() if z["id"] == rid)
    assert fila["inventario_codigo"] == "CO-0001" and fila["inventario_ajuste_id"] and fila["inventario_en"]
    assert c.post(f"/api/recepcion/{rid}/inventario", json={"lineas": [{"numero": 1, "producto_id": cem["id"]}]}).status_code == 409
    assert c.post("/api/inventario/compras", json={"recepcion_id": rid, "lineas": [{"producto_id": cem["id"], "cantidad": 1, "costo_unitario": 1}]}).status_code == 409
    # segunda factura del mismo proveedor: las relaciones guardadas se proponen solas
    rid2 = _registrar(eid, _xml_proveedor(2, "87654321"))
    d2 = c.get(f"/api/recepcion/{rid2}/lineas").json()
    assert [(l["producto_id"], l["motivo"]) for l in d2["lineas"]] == [(cem["id"], "relacion"), (None, None), (nuevo["id"], "relacion")]
    # la factura de compra sin FEC también puede dar la entrada, y deja marcado el comprobante recibido
    a = c.post("/api/inventario/compras", json={"recepcion_id": rid2, "numero": "0002", "lineas": [{"producto_id": cem["id"], "cantidad": 10, "costo_unitario": 9000}]}).json()
    assert a["codigo"] == "CO-0002"
    assert next(z for z in c.get("/api/recepcion").json() if z["id"] == rid2)["inventario_codigo"] == "CO-0002"
    # líneas sin ítem ni creación: solo relaciones, sin entrada
    rid3 = _registrar(eid, _xml_proveedor(3, "11112222"))
    x3 = c.post(f"/api/recepcion/{rid3}/inventario", json={"lineas": [{"numero": 2}]}).json()
    assert x3["ajuste"] is None and x3["entradas"] == 0 and x3["omitidas"] == 1
    assert c.post(f"/api/recepcion/{rid3}/inventario", json={"lineas": [{"numero": 9}]}).status_code == 400
    assert c.get("/api/recepcion/99999/lineas").status_code == 404
