# -*- coding: utf-8 -*-
"""4.24 · Etiquetas de productos con código de barras:
E1 · el código de barras es el «Código» del producto y no se repite (alta, cambio, importación, compras y traslados); repetidos de antes;
E2 · código autogenerado (EAN-13 interno: marca de la empresa + id), único también sin conexión; «Generar códigos de barras»;
E3 · código alterno: lo que se reemplazó sigue encontrando el producto (también en la caja);
E4 · etiquetas en PDF a la medida de la etiqueta (o en hoja carta);
E5 · la pantalla de Ítems: varios productos y cuántas copias de cada uno;
E6 · impresora de etiquetas configurada, con modelos y medidas predefinidos;
E7 · el trabajo en el lenguaje de la impresora (TSPL y ZPL) y su envío por el servicio de impresión local;
E9 · «Registrar código»: leer con el lector el código que el producto ya trae."""
import io
import json
import pathlib
import shutil
import subprocess
import types

import pytest
from sqlmodel import Session, select

from app import auth, etiquetas, main
from app import etiquetas_impresora as ei
from app.db import Empresa, Producto, engine, engine_empresa, init_db
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

RAIZ = pathlib.Path(main.__file__).parent.parent
JS = RAIZ / "app" / "static" / "js"
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")
CABYS = "4755000000100"
MARCA = "999"                       # la marca de la empresa de estas pruebas en sus códigos generados: los 3 últimos dígitos de su cédula (3101999999)


def _propio(pid):
    """El código generado de un producto de la empresa de estas pruebas."""
    return ei.codigo_barras_propio(pid, MARCA)


def _js(*partes):
    return JS.joinpath(*partes).read_text(encoding="utf-8")


def _ctx():
    return main.app.dependency_overrides[auth.contexto]()


def _eid():
    return _ctx().empresa.id


def _como(rol):
    e = _ctx().empresa
    main.app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo="otro@example.test", es_superadmin=False, nombre="QA"), e, rol)


def _alta(c, nombre, codigo=None, **mas):
    r = c.post("/api/productos", json={"nombre": nombre, "codigo": codigo, "cabys": CABYS, "precio": 1000, "unidad_medida": "Unid", "inventariable": False, **mas})
    assert r.status_code == 200, r.text
    return r.json()


def _prod(c, pid):
    return next(p for p in c.get("/api/productos").json() if p["id"] == pid)


def _repetido_viejo(nombre, codigo):
    """Un producto con un código que ya tiene otro, puesto directo en la base: así quedaron los de antes de la regla."""
    with Session(engine_empresa(_eid())) as s:
        p = Producto(empresa_id=_eid(), codigo=codigo, nombre=nombre, cabys=CABYS, precio=500, inventariable=False)
        s.add(p); s.commit(); s.refresh(p)
        return p.id


def _node(tmp_path, guion, archivos=(("pages", "inventario", "_etiquetas.js"),), falsos=None):
    """Corre un guion de Node sobre los archivos de app/static/js tal como están (los demás módulos, con un sustituto mínimo)."""
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    raiz = tmp_path / "js"
    for ruta, texto in (falsos or {}).items():
        (raiz / ruta).parent.mkdir(parents=True, exist_ok=True)
        (raiz / ruta).write_text(texto, encoding="utf-8")
    for partes in archivos:
        (raiz / pathlib.Path(*partes)).parent.mkdir(parents=True, exist_ok=True)
        (raiz / pathlib.Path(*partes)).write_text(_js(*partes), encoding="utf-8")
    (tmp_path / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout)


# ================================================================================================ E1 · el código no se repite
def test_e1_alta_y_cambio_no_aceptan_un_codigo_que_ya_tiene_otro_producto(api):  # noqa: F811
    c = api
    cafe = _alta(c, "Café molido 500 g", "CAF-500")
    # alta: mismo código, con espacios y en minúsculas → 409 con el nombre del otro
    r = c.post("/api/productos", json={"nombre": "Otro café", "codigo": "  caf-500 ", "cabys": CABYS, "precio": 1})
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código caf-500: Café molido 500 g", r.text
    assert len(c.get("/api/productos").json()) == 1                                # no se guardó
    # el código se guarda sin espacios a los lados; sin código no hay nada que comparar
    te = _alta(c, "Té negro", "  TE-01  "); assert te["codigo"] == "TE-01"
    s1, s2 = _alta(c, "Sin código uno"), _alta(c, "Sin código dos", "   ")
    assert s1["codigo"] is None and s2["codigo"] is None
    # cambio: poner el código de otro → 409; el producto queda como estaba
    r = c.put(f"/api/productos/{te['id']}", json={"codigo": "CAF-500"})
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código CAF-500: Café molido 500 g", r.text
    assert _prod(c, te["id"])["codigo"] == "TE-01"
    # cambiar a un código libre, o guardar la ficha entera con su mismo código, sí pasa
    assert c.put(f"/api/productos/{te['id']}", json={"codigo": "TE-02", "precio": 1500}).json()["codigo"] == "TE-02"
    r = c.put(f"/api/productos/{te['id']}", json={"codigo": "TE-02", "nombre": "Té negro en hojas"}); assert r.status_code == 200 and r.json()["nombre"] == "Té negro en hojas"
    # quitar el código siempre se puede
    assert c.put(f"/api/productos/{te['id']}", json={"codigo": ""}).json()["codigo"] is None


def test_e1_un_repetido_de_antes_se_puede_seguir_editando(api):  # noqa: F811
    c = api
    a = _alta(c, "Jabón azul", "JAB-1")
    b_id = _repetido_viejo("Jabón verde", "JAB-1")                                  # repetido de antes de la regla
    # cambiar otros datos del repetido (la ficha manda también su código) no se bloquea
    r = c.put(f"/api/productos/{b_id}", json={"codigo": "JAB-1", "precio": 750, "activo": False}); assert r.status_code == 200, r.text
    assert r.json()["precio"] == 750 and r.json()["codigo"] == "JAB-1"
    assert c.put(f"/api/productos/{a['id']}", json={"nombre": "Jabón azul grande"}).status_code == 200
    # la lista de repetidos los muestra juntos
    d = c.get("/api/productos/codigos/repetidos").json()
    assert d["codigos"] == 1 and d["productos"] == 2 and d["grupos"][0]["codigo"] == "JAB-1"
    assert sorted(p["id"] for p in d["grupos"][0]["productos"]) == sorted([a["id"], b_id])
    # pero volver a poner un código repetido, no: primero lo cambia y luego no puede regresar
    assert c.put(f"/api/productos/{b_id}", json={"codigo": "JAB-2"}).status_code == 200
    assert c.get("/api/productos/codigos/repetidos").json() == {"grupos": [], "codigos": 0, "productos": 0}
    r = c.put(f"/api/productos/{b_id}", json={"codigo": "jab-1"}); assert r.status_code == 409 and "Jabón azul grande" in r.json()["detail"]


def test_e1_importacion_por_servidor(api):  # noqa: F811
    from tests.test_358_b import _subir, _xlsx
    c = api
    arroz = _alta(c, "Arroz 1 kg", "ARR-1")
    frijol = _alta(c, "Frijoles 800 g", "FRI-NUEVO")
    assert c.put(f"/api/productos/{frijol['id']}", json={"codigo": "FRI-2", "conservar_codigo_anterior": True}).json()["codigos_alternos"] == "FRI-NUEVO"
    fila = lambda nombre, codigo, precio=100: [nombre, codigo, CABYS, precio, "Unid", "Producto", "08", "CRC", "", "", "", "", ""]   # noqa: E731
    # crear: el código de otro (en minúsculas) y el código alterno de otro se rechazan con el nombre; lo demás entra
    d = _subir(c, _xlsx([fila("Arroz integral", "arr-1"), fila("Frijoles rojos", "FRI-NUEVO"), fila("Lentejas", "LEN-1"), fila("Lentejas otra vez", "LEN-1")])).json()
    assert d["creados"] == 1 and d["omitidos"] == 3, d
    assert "Fila 2 (Arroz integral): Ya existe otro producto con el código arr-1: Arroz 1 kg; use el modo «actualizar» para cambiarlo" in d["errores"]
    assert any("Ya existe otro producto con el código FRI-NUEVO: Frijoles 800 g" in e for e in d["errores"])
    assert any("Ya existe otro producto con el código LEN-1: Lentejas" in e for e in d["errores"])          # repetido dentro del mismo archivo
    assert sorted(p["nombre"] for p in c.get("/api/productos").json()) == ["Arroz 1 kg", "Frijoles 800 g", "Lentejas"]
    # actualizar: por su código o por un código alterno se actualiza ESE producto, sin tocarle el código
    d = _subir(c, _xlsx([fila("Arroz 1 kg", "ARR-1", 950), fila("Frijoles 800 g", "fri-nuevo", 1250)]), modo="actualizar").json()
    assert d["actualizados"] == 2 and d["creados"] == 0 and not d["errores"], d
    f2 = _prod(c, frijol["id"]); assert f2["precio"] == 1250 and f2["codigo"] == "FRI-2" and f2["codigos_alternos"] == "FRI-NUEVO"
    assert _prod(c, arroz["id"])["precio"] == 950
    assert c.get("/api/productos/codigos/repetidos").json()["codigos"] == 0


def test_e1_compras_y_traslados_no_crean_otro_con_el_mismo_codigo(api):  # noqa: F811
    c = api
    azucar = _alta(c, "Azúcar 2 kg", "AZU-2")
    with Session(engine_empresa(_eid())) as s:
        # traslados: el mismo código escrito distinto, o un código alterno, es ese producto (no se crea otro)
        from app import traslados
        d = {"codigo": "azu-2", "nombre": "Azucar blanca dos kilos", "cabys": CABYS}
        p, nuevo = traslados._producto_destino(s, _eid(), d)
        assert p.id == azucar["id"] and nuevo is False
        s.rollback()
    assert c.put(f"/api/productos/{azucar['id']}", json={"codigo": "7441001234567", "conservar_codigo_anterior": True}).status_code == 200
    with Session(engine_empresa(_eid())) as s:
        from app import traslados
        p, nuevo = traslados._producto_destino(s, _eid(), {"codigo": "AZU-2", "nombre": "Otro nombre", "cabys": CABYS})
        assert p.id == azucar["id"] and nuevo is False                              # por el código alterno
        p, nuevo = traslados._producto_destino(s, _eid(), {"codigo": "SAL-1", "nombre": "Sal fina", "cabys": CABYS, "precio_unitario": 300})
        assert nuevo is True and p.codigo == "SAL-1"
        s.rollback()
    # compras: la regla y su mensaje con el número de línea
    with Session(engine_empresa(_eid())) as s:
        with pytest.raises(main.HTTPException) as ex:
            etiquetas.exigir_codigo_libre(s, _eid(), "azu-2", prefijo="Línea 3: ")
        assert ex.value.status_code == 409 and ex.value.detail == "Línea 3: Ya existe otro producto con el código azu-2: Azúcar 2 kg"
        assert etiquetas.otro_con_codigo(s, _eid(), "7441001234567", excepto_id=azucar["id"]) is None
        assert etiquetas.otro_con_codigo(s, _eid(), "LIBRE-1") is None and etiquetas.otro_con_codigo(s, _eid(), "  ") is None
    comp = (RAIZ / "app" / "compras_inventario.py").read_text(encoding="utf-8")
    assert 'etiquetas.exigir_codigo_libre(s, eid, p.codigo, prefijo=f"Línea {li.numero}: ")' in comp
    assert "elif p.codigo and etiquetas.otro_con_codigo(s, eid, p.codigo) is not None:\n                p.codigo = None" in comp
    # ... y con un comprobante recibido de verdad (su línea 1 trae el código del proveedor «CEM-50»)
    from tests.test_375_costeo import _registrar, _xml_proveedor
    viejo = _alta(c, "Cemento de la casa", "cem-50")
    rid = _registrar(_eid(), _xml_proveedor(1))
    r = c.post(f"/api/recepcion/{rid}/inventario", json={"lineas": [{"numero": 1, "crear": {"codigo": "azu-2", "precio": 9500}}]})
    assert r.status_code == 409 and r.json()["detail"] == "Línea 1: Ya existe otro producto con el código azu-2: Azúcar 2 kg", r.text   # el que escribió el usuario (otro que el del proveedor) se rechaza
    assert len([p for p in c.get("/api/productos").json() if p["nombre"].startswith("Cemento")]) == 1
    r = c.post(f"/api/recepcion/{rid}/inventario", json={"lineas": [{"numero": 1, "crear": {"precio": 9500}}, {"numero": 3, "crear": {"codigo": "PIN-1", "precio": 15000}}]})
    assert r.status_code == 200, r.text                                             # el del proveedor, tomado solo, no entra como código si ya es de otro ítem
    creados = {p["nombre"]: p for p in c.get("/api/productos").json() if p["id"] in [x["id"] for x in r.json()["creados"]]}
    assert creados["Cemento gris 50 kg"]["codigo"] is None and creados["Pintura blanca 1 gal"]["codigo"] == "PIN-1"
    assert _prod(c, viejo["id"])["codigo"] == "cem-50" and c.get("/api/productos/codigos/repetidos").json()["codigos"] == 0


# ================================================================================================ E3 · códigos alternos
def test_e3_el_codigo_reemplazado_queda_como_alterno_y_tampoco_se_repite(api):  # noqa: F811
    c = api
    leche = _alta(c, "Leche entera 1 L", "LEC-1")
    assert leche["codigos_alternos"] is None
    # cambio corriente (corregir el código en la ficha): el anterior NO se guarda
    assert c.put(f"/api/productos/{leche['id']}", json={"codigo": "LEC-01"}).json()["codigos_alternos"] is None
    # «Registrar código» / «Generar» piden conservarlo
    r = c.put(f"/api/productos/{leche['id']}", json={"codigo": "7441000000017", "conservar_codigo_anterior": True}).json()
    assert r["codigo"] == "7441000000017" and r["codigos_alternos"] == "LEC-01"
    r = c.put(f"/api/productos/{leche['id']}", json={"codigo": "7441000000024", "conservar_codigo_anterior": True}).json()
    assert r["codigos_alternos"] == "7441000000017,LEC-01"                          # el más reciente primero
    assert _prod(c, leche["id"])["codigos_alternos"] == "7441000000017,LEC-01"      # GET /api/productos lo devuelve
    # otro producto no puede usar un código alterno de este, ni al crear ni al cambiar
    r = c.post("/api/productos", json={"nombre": "Leche descremada", "codigo": "lec-01", "cabys": CABYS, "precio": 1})
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código lec-01: Leche entera 1 L"
    crema = _alta(c, "Crema dulce", "CRE-1")
    assert c.put(f"/api/productos/{crema['id']}", json={"codigo": "7441000000017"}).status_code == 409
    # volver a un código que fue suyo: deja de ser alterno, y el que tenía pasa a serlo
    r = c.put(f"/api/productos/{leche['id']}", json={"codigo": "LEC-01", "conservar_codigo_anterior": True}).json()
    assert r["codigo"] == "LEC-01" and r["codigos_alternos"] == "7441000000024,7441000000017"
    # la ficha quita uno; lo que se quitó queda libre para otro producto
    r = c.put(f"/api/productos/{leche['id']}", json={"codigos_alternos": ["7441000000024"]}).json()
    assert r["codigos_alternos"] == "7441000000024" and r["codigo"] == "LEC-01"
    assert c.put(f"/api/productos/{crema['id']}", json={"codigo": "7441000000017"}).status_code == 200
    # un alterno nuevo tampoco puede ser de otro; ni más de cinco, ni con comas
    _alta(c, "Queso tierno", "QUE-1")
    r = c.put(f"/api/productos/{leche['id']}", json={"codigos_alternos": ["7441000000024", "que-1"]})
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código que-1: Queso tierno"
    assert c.put(f"/api/productos/{leche['id']}", json={"codigos_alternos": ["7441000000024", "7441000000017"]}).status_code == 409   # ahora es el código de la crema
    assert c.put(f"/api/productos/{leche['id']}", json={"codigos_alternos": ["7441000000024", "CRE-1"]}).json()["codigos_alternos"] == "7441000000024,CRE-1"   # libre: la crema ya no lo usa
    assert c.put(f"/api/productos/{leche['id']}", json={"codigos_alternos": [f"A{i}" for i in range(6)]}).status_code == 400
    assert c.put(f"/api/productos/{leche['id']}", json={"codigos_alternos": ""}).json()["codigos_alternos"] is None
    # solo se guardan los cinco más recientes
    for i in range(7):
        r = c.put(f"/api/productos/{leche['id']}", json={"codigo": f"N{i}", "conservar_codigo_anterior": True}).json()
    assert r["codigo"] == "N6" and r["codigos_alternos"] == "N5,N4,N3,N2,N1"
    # cambiar otros datos no toca los alternos
    assert c.put(f"/api/productos/{leche['id']}", json={"precio": 2000}).json()["codigos_alternos"] == "N5,N4,N3,N2,N1"
    # un alterno de antes más largo que el tope de hoy no impide quitar otro en la ficha; uno nuevo así de largo no entra
    with Session(engine_empresa(_eid())) as s:
        p = s.get(Producto, leche["id"]); p.codigos_alternos = "CODIGO-VIEJO-DE-MAS-DE-VEINTE,N5"; s.add(p); s.commit()
    assert c.put(f"/api/productos/{leche['id']}", json={"codigos_alternos": ["CODIGO-VIEJO-DE-MAS-DE-VEINTE"]}).json()["codigos_alternos"] == "CODIGO-VIEJO-DE-MAS-DE-VEINTE"
    assert c.put(f"/api/productos/{leche['id']}", json={"codigos_alternos": ["OTRO-CODIGO-DE-MAS-DE-VEINTE"]}).status_code == 400


def test_e3_la_columna_es_opcional_y_viaja_a_las_instalaciones_locales():
    assert "codigos_alternos" in Producto.model_fields and Producto.model_fields["codigos_alternos"].default is None
    assert Producto(nombre="x", cabys="", precio=1).model_dump()["codigos_alternos"] is None
    # la sincronización copia los campos del modelo (sin lista aparte): un programa anterior ignora el campo que no conoce
    sinc = (RAIZ / "app" / "sinc.py").read_text(encoding="utf-8")
    assert "obj = modelo(**{k: v for k, v in d.items() if k in modelo.model_fields})" in sinc and "if k in modelo.model_fields and k != \"id\":" in sinc
    assert etiquetas.alternos(types.SimpleNamespace(codigos_alternos=" A1 , ,b2,")) == ["A1", "b2"] and etiquetas.alternos(types.SimpleNamespace()) == []
    assert etiquetas._unir(["x", "X", " y ", "con,coma", "", "act"], "ACT") == "x,y" and etiquetas._unir([]) is None


# ================================================================================================ E2 · código autogenerado
def test_e2_codigo_barras_propio():
    f = ei.codigo_barras_propio
    # «2» + marca de la empresa (3 dígitos) + id a 8 dígitos + verificador
    assert f(1, "000") == "2000000000015" and f(123, "000") == "2000000001234" and f(0, "000") == "2000000000008"
    assert f(37, "456") == "2456000000379" and f(37, MARCA) == _propio(37) == "2999000000371"
    # dígito verificador correcto (el que calcularía cualquier lector) y simbología EAN-13
    for pid in (1, 7, 42, 999, 123456, 9_999_999, 10_000_000, 10_000_001, 30_000_123, 99_999_999):
        for marca in ("000", "042", MARCA):
            cod = f(pid, marca)
            assert len(cod) == 13 and cod.isdigit() and cod[0] == "2" and cod[1:4] == marca and int(cod[4:12]) == pid
            pares, impares = sum(int(x) for x in cod[1:12:2]), sum(int(x) for x in cod[0:12:2])
            assert (impares + 3 * pares + int(cod[12])) % 10 == 0
            assert ei.es_ean13(cod) and ei.simbologia(cod) == "ean13"
    # distinto para ids distintos, también entre la nube (1 a 9.999.999) y los rangos de las instalaciones locales (terminal × 10 millones)
    ids = list(range(1, 3000)) + [t * 10_000_000 + n for t in (1, 2, 3, 9, 10, 57, 9999) for n in range(0, 500)]
    assert len({_propio(i) for i in ids}) == len(ids)
    from app import modulos
    assert modulos.RANGO == 10_000_000
    # un id que no cabe en 8 dígitos (terminal 10 o más): «P» + marca + «-» + id, en Code128; cabe en el largo del código
    assert f(100_000_000, "456") == "P456-100000000" and ei.simbologia(f(100_000_000, "456")) == "code128"
    assert len(f(99_990_000_499, MARCA)) <= ei.CODIGO_MAX and ei.codigo_imprimible(f(99_990_000_499, MARCA))
    with pytest.raises(ValueError):
        f(-1, MARCA)
    for mala in ("", "12", "1234", "12a", None):                 # la marca siempre son 3 dígitos (marca_empresa la arma)
        with pytest.raises(ValueError):
            f(1, mala)
    # EAN-13 de verdad frente a 13 dígitos cualesquiera
    assert ei.es_ean13("7501031311309") and not ei.es_ean13("7501031311300") and not ei.es_ean13("750103131130") and not ei.es_ean13("75010313113o9") and not ei.es_ean13(None)
    assert ei.digito_ean13("750103131130") == 9


def test_e2_generar_solo_a_los_que_no_tienen_o_reemplazando(api):  # noqa: F811
    c = api
    sin1, sin2 = _alta(c, "Galletas de avena"), _alta(c, "Galletas de coco")
    con = _alta(c, "Refresco de cola 600 ml", "7441009876543")
    propio = _propio
    # sin reemplazar: solo los que no tienen
    r = c.post("/api/productos/codigos/generar", json={"ids": [sin1["id"], con["id"]]}); assert r.status_code == 200, r.text
    d = r.json(); assert d["cambiados"] == 1 and d["sin_cambio"] == 1 and d["no_se_pudo"] == [] and d["codigos"] == {str(sin1["id"]): propio(sin1["id"])}
    assert _prod(c, sin1["id"])["codigo"] == propio(sin1["id"]) and _prod(c, con["id"])["codigo"] == "7441009876543" and _prod(c, sin2["id"])["codigo"] is None
    # otra vez: ya estaban bien
    assert c.post("/api/productos/codigos/generar", json={"ids": [sin1["id"], con["id"]]}).json()["cambiados"] == 0
    # todos, reemplazando: el anterior queda como código alterno
    d = c.post("/api/productos/codigos/generar", json={"todos": True, "reemplazar": True}).json()
    assert d["cambiados"] == 2 and d["sin_cambio"] == 1, d
    p = _prod(c, con["id"]); assert p["codigo"] == propio(con["id"]) and p["codigos_alternos"] == "7441009876543"
    assert _prod(c, sin2["id"])["codigo"] == propio(sin2["id"]) and _prod(c, sin2["id"])["codigos_alternos"] is None
    # queda en el historial de operaciones
    with Session(engine) as s:
        filas = [a.detalle for a in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == _eid(), auth.Auditoria.accion == "productos_codigos").order_by(auth.Auditoria.id)).all()]
    assert filas[0] == "1 código(s) de barras generados solo a los productos que no tenían código"
    assert filas[-1] == "2 código(s) de barras generados reemplazando los que ya tenían (el anterior queda como código alterno)"
    # sin productos elegidos
    assert c.post("/api/productos/codigos/generar", json={"ids": []}).status_code == 400
    assert c.post("/api/productos/codigos/generar", json={}).status_code == 400


def test_e2_generar_no_pisa_un_codigo_escrito_a_mano_ni_toca_otra_empresa(api):  # noqa: F811
    c = api
    a = _alta(c, "Atún en agua")
    b = _alta(c, "Atún en aceite", _propio(a["id"]))                                 # alguien escribió a mano el que le tocaría al otro
    d = c.post("/api/productos/codigos/generar", json={"ids": [a["id"], b["id"]], "reemplazar": True}).json()
    assert d["cambiados"] == 1 and len(d["no_se_pudo"]) == 1, d
    assert d["no_se_pudo"][0] == {"id": a["id"], "nombre": "Atún en agua", "codigo": _propio(a["id"]),
                                  "motivo": f"Ya existe otro producto con el código {_propio(a['id'])}: Atún en aceite"}
    assert _prod(c, a["id"])["codigo"] is None
    pb = _prod(c, b["id"]); assert pb["codigo"] == _propio(b["id"]) and pb["codigos_alternos"] == _propio(a["id"])
    # sigue sin poder: ahora es un código alterno del otro
    assert c.post("/api/productos/codigos/generar", json={"ids": [a["id"]]}).json()["no_se_pudo"][0]["id"] == a["id"]
    # ids que no son de esta empresa (o no existen) no se tocan
    init_db()
    with Session(engine) as s:
        otra = Empresa(nombre="Otra empresa QA 424", numero_id="3101888888", correo="otra424@example.test", ambiente="sandbox")
        s.add(otra); s.commit(); s.refresh(otra); otra_id = otra.id
    with Session(engine_empresa(otra_id)) as s:
        ajeno = Producto(empresa_id=otra_id, nombre="Producto de otra empresa", cabys=CABYS, precio=1)
        s.add(ajeno); s.commit(); s.refresh(ajeno); ajeno_id = ajeno.id
    d = c.post("/api/productos/codigos/generar", json={"ids": [ajeno_id + 1000, 987654], "reemplazar": True}).json()
    assert d["cambiados"] == 0 and d["sin_cambio"] == 0 and d["no_se_pudo"] == []
    c.post("/api/productos/codigos/generar", json={"todos": True, "reemplazar": True})
    with Session(engine_empresa(otra_id)) as s:
        assert s.get(Producto, ajeno_id).codigo is None


def test_e2_generar_pide_el_permiso_de_catalogos(api):  # noqa: F811
    c = api
    p = _alta(c, "Pan cuadrado")
    _como("Cajero")
    assert c.post("/api/productos/codigos/generar", json={"ids": [p["id"]]}).status_code == 403
    assert c.get("/api/productos/codigos/repetidos").status_code == 200              # verlos sí
    _como("Administrador")
    assert c.post("/api/productos/codigos/generar", json={"ids": [p["id"]]}).json()["cambiados"] == 1


# ================================================================================================ E3 · la caja encuentra por código alterno
def test_e3_la_caja_busca_por_codigo_luego_por_alterno_y_luego_por_cabys(tmp_path):
    caja = _js("pages", "pos", "caja.js")
    assert "import { productoPorCodigo } from '../inventario/_etiquetas.js';" in caja
    assert "const exacto = productoPorCodigo(this.productos, q);" in caja and "String(p.codigo || '').toLowerCase() === q.toLowerCase()" not in caja
    r = _node(tmp_path, """
import { productoPorCodigo, alternosDe } from './js/pages/inventario/_etiquetas.js';
const prods = [
  { id: 1, nombre: 'Leche', codigo: '2000000000015', codigos_alternos: '7441000000017,LEC-01', cabys: '2211000000100' },
  { id: 2, nombre: 'Crema', codigo: ' CRE-1 ', codigos_alternos: null, cabys: '2212000000100' },
  { id: 3, nombre: 'Queso', codigo: null, codigos_alternos: '', cabys: '2213000000100' },
  { id: 4, nombre: 'Yogur', codigo: 'LEC-01', cabys: '2214000000100' },          // un repetido viejo: su código es alterno de otro
];
const id = q => (productoPorCodigo(prods, q) || {}).id || null;
console.log(JSON.stringify({ codigo: id('2000000000015'), alterno: id('7441000000017'), minus: id(' cre-1'), gana_codigo: id('lec-01'), cabys: id('2213000000100'),
  nada: id('NO-EXISTE'), vacio: id('   '), sin_lista: productoPorCodigo(null, 'x'), alternos: alternosDe(prods[0]), sin: alternosDe(prods[2]) }));
""")
    assert r == {"codigo": 1, "alterno": 1, "minus": 2, "gana_codigo": 4, "cabys": 3, "nada": None, "vacio": None, "sin_lista": None, "alternos": ["7441000000017", "LEC-01"], "sin": []}


# ================================================================================================ E9 · «Registrar código»
def test_e9_registrar_codigo_en_node(tmp_path):
    """El flujo de «Registrar códigos con el lector»: guardar, choque 409 con otro producto, saltar, terminar y el alterno al reemplazar."""
    r = _node(tmp_path, """
import { nuevaTanda, productoDeTanda, registrarCodigo, registrarEnTanda, saltarEnTanda, terminarTanda, resumenTanda } from './js/pages/inventario/_etiquetas.js';
const pedidos = [];
const guardar = async (p, cuerpo) => {
  pedidos.push({ id: p.id, ...cuerpo });
  if (cuerpo.codigo === 'OCUPADO') { const e = new Error('Ya existe otro producto con el código OCUPADO: Arroz 1 kg'); e.status = 409; throw e; }
  if (cuerpo.codigo === 'ROTO') throw new Error('Sin conexión con el servidor');
  return { ...p, codigo: cuerpo.codigo, codigos_alternos: p.codigo ? p.codigo : null };
};
const out = {};
// uno solo: guarda por la ruta de cambio, pidiendo conservar el anterior como alterno
out.nuevo = await registrarCodigo({ id: 1, nombre: 'Leche', codigo: '' }, '  7441000000017 ', guardar);
out.reemplazo = await registrarCodigo({ id: 2, nombre: 'Crema', codigo: 'CRE-1' }, '7441000000024', guardar);
out.igual = await registrarCodigo({ id: 2, nombre: 'Crema', codigo: 'CRE-1' }, ' cre-1 ', guardar);
out.vacio = await registrarCodigo({ id: 3, nombre: 'Queso' }, '   ', guardar);
out.largo = await registrarCodigo({ id: 3, nombre: 'Queso' }, '123456789012345678901', guardar);
out.choque = await registrarCodigo({ id: 3, nombre: 'Queso' }, 'OCUPADO', guardar);
out.fallo = await registrarCodigo({ id: 3, nombre: 'Queso' }, 'ROTO', guardar);
out.pedidos = pedidos.slice();
// varios, de uno en uno
const t = nuevaTanda([{ id: 10, nombre: 'A' }, { id: 11, nombre: 'B' }, { id: 12, nombre: 'C' }, { id: 13, nombre: 'D' }, { id: 14, nombre: 'E' }]);
const pasos = [];
pasos.push(productoDeTanda(t).id); await registrarEnTanda(t, 'COD-A', guardar);
pasos.push(productoDeTanda(t).id); const ch = await registrarEnTanda(t, 'OCUPADO', guardar);
pasos.push(productoDeTanda(t).id);                                   // el choque no avanza: se puede leer otro
await registrarEnTanda(t, 'COD-B', guardar);                          // ... y con otro código sí queda
pasos.push(productoDeTanda(t).id); await registrarEnTanda(t, 'OCUPADO', guardar); saltarEnTanda(t);   // choca y se salta: cuenta como choque, no como saltado
pasos.push(productoDeTanda(t).id); saltarEnTanda(t);
pasos.push(productoDeTanda(t).id); terminarTanda(t);
out.pasos = pasos; out.choque_tanda = { ok: ch.ok, choque: ch.choque }; out.fin = t.fin; out.actual = productoDeTanda(t); out.resumen = resumenTanda(t);
out.vacia = nuevaTanda([]).fin;
console.log(JSON.stringify(out));
""")
    assert r["nuevo"]["ok"] and r["nuevo"]["producto"]["codigo"] == "7441000000017"
    assert r["reemplazo"]["ok"] and r["reemplazo"]["producto"] == {"id": 2, "nombre": "Crema", "codigo": "7441000000024", "codigos_alternos": "CRE-1"}
    assert r["igual"] == {"ok": True, "igual": True, "producto": {"id": 2, "nombre": "Crema", "codigo": "CRE-1"}}             # el mismo código no se manda
    assert r["vacio"]["ok"] is False and r["vacio"]["vacio"] and r["largo"]["ok"] is False and "20 caracteres" in r["largo"]["mensaje"]
    assert r["choque"] == {"ok": False, "choque": True, "mensaje": "Ya existe otro producto con el código OCUPADO: Arroz 1 kg"}   # el mensaje del servidor, tal cual
    assert r["fallo"] == {"ok": False, "choque": False, "mensaje": "Sin conexión con el servidor"}
    assert r["pedidos"] == [{"id": 1, "codigo": "7441000000017", "conservar_codigo_anterior": True}, {"id": 2, "codigo": "7441000000024", "conservar_codigo_anterior": True},
                            {"id": 3, "codigo": "OCUPADO", "conservar_codigo_anterior": True}, {"id": 3, "codigo": "ROTO", "conservar_codigo_anterior": True}]
    assert r["pasos"] == [10, 11, 11, 12, 13, 14] and r["choque_tanda"] == {"ok": False, "choque": True} and r["fin"] is True and r["actual"] is None and r["vacia"] is True
    res = r["resumen"]
    assert res["registrados"] == 2 and res["saltados"] == 1 and res["sin_ver"] == 1
    assert res["choques"] == [{"id": 12, "nombre": "C", "codigo": "OCUPADO", "mensaje": "Ya existe otro producto con el código OCUPADO: Arroz 1 kg"}]
    assert res["texto"] == "2 códigos registrados · 1 saltado · 1 chocó con otro producto · 1 sin ver"


def test_e9_registrar_codigo_en_el_servidor_y_en_la_pantalla(api):  # noqa: F811
    c = api
    pasta = _alta(c, "Pasta corta 250 g")
    salsa = _alta(c, "Salsa de tomate", "SAL-INT")
    # lo que manda el cuadro: el código leído por la ruta de cambio de siempre, conservando el anterior
    r = c.put(f"/api/productos/{pasta['id']}", json={"codigo": "7441002222226", "conservar_codigo_anterior": True}).json()
    assert r["codigo"] == "7441002222226" and r["codigos_alternos"] is None                    # no tenía código: no hay alterno
    r = c.put(f"/api/productos/{salsa['id']}", json={"codigo": "7441003333335", "conservar_codigo_anterior": True}).json()
    assert r["codigo"] == "7441003333335" and r["codigos_alternos"] == "SAL-INT"               # el interno sigue encontrando el producto
    # si ya lo tiene otro producto: 409 con el nombre del otro y no se guarda
    r = c.put(f"/api/productos/{pasta['id']}", json={"codigo": "7441003333335", "conservar_codigo_anterior": True})
    assert r.status_code == 409 and r.json()["detail"] == "Ya existe otro producto con el código 7441003333335: Salsa de tomate"
    r = c.put(f"/api/productos/{pasta['id']}", json={"codigo": "sal-int", "conservar_codigo_anterior": True})
    assert r.status_code == 409 and "Salsa de tomate" in r.json()["detail"]                    # también choca con un código alterno
    p = _prod(c, pasta["id"]); assert p["codigo"] == "7441002222226" and p["codigos_alternos"] is None
    # la pantalla: acción en la fila, en lote y en «Más acciones»; el cuadro pide confirmación si ya tenía código
    items = _js("pages", "inventario", "items.js"); dlg = _js("pages", "inventario", "_etiquetas-dialogos.js"); ficha = _js("pages", "inventario", "item-form.js")
    assert '@click.stop="abrirRegistrar([row])" title="Registrar código: leer con el lector el código de barras que el producto ya trae"' in items
    assert "{ label: 'Registrar códigos con el lector', kind: 'sec', handler: rows => this.abrirRegistrar(rows) }" in items
    assert '@click="registrarSinCodigo"' in items and ">Registrar códigos con el lector</a>" in items
    assert '<DialogoRegistrarCodigos v-if="registrar" :productos="registrar" @close="cerrarRegistrar"></DialogoRegistrarCodigos>' in items
    assert "components: { DialogoRegistrarCodigos" in items
    assert "Lea el código de <b>{{actual.nombre}}</b> con el lector." in dlg and '@keydown.enter.prevent="guardar"' in dlg and 'ref="lector"' in dlg
    assert "¿Reemplazarlo por ' + c + '? El anterior queda como código alterno: la caja lo sigue reconociendo.'" in dlg
    assert "api('/api/productos/' + prod.id, { method: 'PUT', body: cuerpo })" in dlg
    assert ">Saltar</button>" in dlg and ">Terminar</button>" in dlg and "No se guardaron porque el código ya es de otro producto:" in dlg
    # la ficha: el campo acepta el lector y su ayuda dice que puede leerse o generarse
    assert "Es el código de barras del ítem: léalo con el lector, escríbalo o genere uno." in ficha and '@click.prevent="generarCodigo"' in ficha
    assert "if (this.conservarAnterior && this.codigoCambiado) body.conservar_codigo_anterior = true;" in ficha and "if (this.alternosTocados) body.codigos_alternos = this.alternos;" in ficha
    assert "Códigos alternos (la caja también vende este ítem al leerlos)" in ficha and '@click.prevent="quitarAlterno(a)"' in ficha
    # la ficha y la importación del navegador muestran el mensaje del servidor tal cual
    assert "} catch (e) { toast(e.message, 'err'); }\n      this.guardando = false;" in ficha
    assert "} catch (e) { errores.push(nombre + ': ' + e.message); }" in _js("pages", "inventario", "gestion.js")
    assert "api('/api/productos/codigos/generar', { method: 'POST', body: { ids: [p.id] } })" in ficha       # ítem nuevo: se genera al guardar, cuando ya tiene número


# ================================================================================================ E4 · etiquetas en PDF a la medida
PT_MM = 72 / 25.4


def _pdf(r):
    from pypdf import PdfReader
    assert r.status_code == 200 and r.headers["content-type"] == "application/pdf" and r.content[:5] == b"%PDF-", r.text[:300]
    return PdfReader(io.BytesIO(r.content))


def _geometria(pagina):
    """Barras (rectángulos rellenos) y textos de una página, en puntos del PDF: [(x0, x1, y0, y1)] y [(y de la línea base, tamaño)]."""
    import re
    datos = pagina.get_contents().get_data().decode("latin-1")
    barras, textos, pila, org, tam = [], [], [], (0.0, 0.0), 0.0
    for ln in datos.splitlines():
        ln = ln.strip()
        if ln == "q":
            pila.append(org)
        elif ln == "Q":
            org = pila.pop()
        elif (m := re.fullmatch(r"1 0 0 1 (-?[\d.]+) (-?[\d.]+) cm", ln)):
            org = (org[0] + float(m.group(1)), org[1] + float(m.group(2)))
        elif (m := re.fullmatch(r"n (-?[\d.]+) (-?[\d.]+) (-?[\d.]+) (-?[\d.]+) re f\*", ln)):
            x, y, w, h = (float(v) for v in m.groups())
            barras.append((org[0] + x, org[0] + x + w, org[1] + y, org[1] + y + h))
        elif (m := re.search(r"BT /F\d+ ([\d.]+) Tf", ln)):
            tam = float(m.group(1))
        if (m := re.search(r"BT 1 0 0 1 (-?[\d.]+) (-?[\d.]+) Tm \(", ln)):
            textos.append((org[1] + float(m.group(2)), tam))
    return barras, textos


def test_e4_pdf_una_etiqueta_por_pagina_a_la_medida(api):  # noqa: F811
    c = api
    cafe = _alta(c, "Café molido 500 g", precio=1327.43, tarifa=13, codigo_tarifa="08")
    assert c.post("/api/productos/codigos/generar", json={"ids": [cafe["id"]]}).json()["cambiados"] == 1
    cod_cafe = _propio(cafe["id"])
    torn = _alta(c, "Tornillo hexagonal 3/8", "TOR-38X2", precio=250, tarifa=13, codigo_tarifa="08")
    # tantas páginas como etiquetas, cada una del tamaño pedido
    pdf = _pdf(c.post("/api/productos/etiquetas", json={"items": [{"id": cafe["id"], "copias": 3}, {"id": torn["id"], "copias": 2}], "ancho_mm": 50, "alto_mm": 30}))
    assert len(pdf.pages) == 5
    for pg in pdf.pages:
        assert abs(float(pg.mediabox.width) - 50 * PT_MM) < 0.01 and abs(float(pg.mediabox.height) - 30 * PT_MM) < 0.01
    # el nombre y el código, legibles, en el texto del PDF; sin precio en el formato por omisión
    t0, t4 = pdf.pages[0].extract_text(), pdf.pages[4].extract_text()
    assert "Café molido 500 g" in t0 and cod_cafe in t0 and "¢" not in t0
    assert "Tornillo hexagonal 3/8" in t4 and "TOR-38X2" in t4 and "Café" not in t4
    assert pdf.pages[2].extract_text() == t0 and pdf.pages[3].extract_text() == t4
    # EAN-13 (95 módulos: 30 barras) frente a Code128; zona quieta a los lados; el nombre arriba y el número debajo, sin tocar las barras
    for pg, es_ean in ((pdf.pages[0], True), (pdf.pages[4], False)):
        barras, textos = _geometria(pg)
        assert (len(barras) == 30) is es_ean and len(barras) >= 20
        x0, x1, y0, y1 = min(b[0] for b in barras), max(b[1] for b in barras), min(b[2] for b in barras), max(b[3] for b in barras)
        modulo = min(b[1] - b[0] for b in barras)
        assert x0 >= 10 * modulo - 0.01 and 50 * PT_MM - x1 >= 10 * modulo - 0.01                      # zona quieta de 10 módulos o más por lado
        assert abs((x0 + x1) / 2 - 25 * PT_MM) < 0.5                                                   # centrado
        if es_ean:
            assert abs((x1 - x0) / modulo - 95) < 0.01 and modulo >= 0.33 * PT_MM                      # EAN-13 al 100 % o más en 50 mm
        assert y1 - y0 >= 8 * PT_MM                                                                    # barras de 8 mm o más de alto
        arriba, abajo = [t for t in textos if t[0] > y1], [t for t in textos if t[0] < y0]
        assert len(arriba) == 1 and len(abajo) == 1 and len(textos) == 2                               # nombre arriba, número abajo: ninguno encima de las barras
        assert arriba[0][0] - arriba[0][1] * 0.25 >= y1 and abajo[0][0] + abajo[0][1] * 0.75 <= y0     # ni los rasgos bajos del nombre ni lo alto del número
        assert abajo[0][0] >= 1 * PT_MM and arriba[0][0] + arriba[0][1] * 0.75 <= 30 * PT_MM - 1 * PT_MM   # todo dentro de la etiqueta
    # con precio: el precio con IVA y su moneda; solo código: sin nombre
    pdf = _pdf(c.post("/api/productos/etiquetas", json={"items": [{"id": cafe["id"], "copias": 1}], "formato": "nombre_codigo_precio", "ancho_mm": 58, "alto_mm": 40}))
    t = pdf.pages[0].extract_text(); assert "Café molido 500 g" in t and cod_cafe in t and "¢1.500,00" in t
    assert abs(float(pdf.pages[0].mediabox.width) - 58 * PT_MM) < 0.01 and abs(float(pdf.pages[0].mediabox.height) - 40 * PT_MM) < 0.01
    pdf = _pdf(c.post("/api/productos/etiquetas", json={"items": [{"id": cafe["id"], "copias": 2}], "formato": "solo_codigo", "ancho_mm": 30, "alto_mm": 20}))
    assert len(pdf.pages) == 2 and pdf.pages[0].extract_text().strip() == cod_cafe
    # un nombre largo: hasta 2 renglones con la letra más chica; nunca encima de las barras
    largo = _alta(c, "Tornillo cabeza hexagonal galvanizado de 3/8 x 2 pulgadas con tuerca y arandela de presión extra", "LARGO-1")
    for a, h in ei.MEDIDAS:
        pg = _pdf(c.post("/api/productos/etiquetas", json={"items": [{"id": largo["id"], "copias": 1}], "formato": "nombre_codigo_precio", "ancho_mm": a, "alto_mm": h})).pages[0]
        barras, textos = _geometria(pg)
        y0, y1 = min(b[2] for b in barras), max(b[3] for b in barras)
        arriba = [t for t in textos if t[0] > y1]
        assert 1 <= len(arriba) <= 2 and len(textos) == len(arriba) + 2, (a, h, textos)                 # nombre (1 o 2 renglones), número y precio
        assert all(t[0] - t[1] * 0.25 >= y1 for t in arriba) and y1 - y0 >= 3 * PT_MM, (a, h)
        assert min(b[0] for b in barras) >= 0 and max(b[1] for b in barras) <= a * PT_MM
    # medida personalizada en sus límites
    assert len(_pdf(c.post("/api/productos/etiquetas", json={"items": [{"id": cafe["id"], "copias": 1}], "ancho_mm": 20, "alto_mm": 15})).pages) == 1
    assert len(_pdf(c.post("/api/productos/etiquetas", json={"items": [{"id": cafe["id"], "copias": 1}], "formato": "nombre_codigo_precio", "ancho_mm": 110, "alto_mm": 160})).pages) == 1
    # hoja carta: cuadrícula en páginas de 8,5 × 11 pulgadas
    pdf = _pdf(c.post("/api/productos/etiquetas", json={"items": [{"id": cafe["id"], "copias": 70}, {"id": torn["id"], "copias": 1}], "ancho_mm": 50, "alto_mm": 30, "hoja": "carta"}))
    assert len(pdf.pages) == 3 and [round(float(v)) for v in pdf.pages[0].mediabox[2:]] == [612, 792]      # 3 × 8 = 24 por hoja: 71 etiquetas en 3 hojas
    assert pdf.pages[0].extract_text().count(cod_cafe) == 24 and pdf.pages[2].extract_text().count(cod_cafe) == 22 and "TOR-38X2" in pdf.pages[2].extract_text()
    # etiqueta de prueba, sin productos (Configuración › Impresoras)
    pdf = _pdf(c.post("/api/productos/etiquetas", json={"prueba": True, "ancho_mm": 40, "alto_mm": 25}))
    assert len(pdf.pages) == 1 and "Etiqueta de prueba" in pdf.pages[0].extract_text() and "2000000000008" in pdf.pages[0].extract_text()
    # cualquier usuario que ve los productos puede imprimir sus etiquetas
    _como("Cajero")
    assert c.post("/api/productos/etiquetas", json={"items": [{"id": cafe["id"], "copias": 1}]}).status_code == 200


def test_e4_topes_y_productos_sin_codigo(api):  # noqa: F811
    c = api
    a = _alta(c, "Con código", "A-1"); b = _alta(c, "Sin código todavía"); raro = _alta(c, "Código con eñe", "CAÑA-1")
    pedir = lambda **k: c.post("/api/productos/etiquetas", json={"items": [{"id": a["id"], "copias": 1}], **k})   # noqa: E731
    assert pedir().status_code == 200
    # copias de 1 a 500 por producto y hasta 3.000 por pedido
    assert pedir(items=[{"id": a["id"], "copias": 500}]).status_code == 200
    for malas in (0, -1, 501):
        r = pedir(items=[{"id": a["id"], "copias": malas}]); assert r.status_code == 400 and r.json()["detail"] == "Las copias de cada producto van de 1 a 500"
    r = pedir(items=[{"id": a["id"], "copias": 500}] * 6 + [{"id": a["id"], "copias": 1}])
    assert r.status_code == 400 and r.json()["detail"] == "Un pedido lleva hasta 3.000 etiquetas: imprímalas en varias tandas"
    assert pedir(items=[]).status_code == 400 and pedir(items=[{"id": 987654, "copias": 1}]).status_code == 404
    # medidas: las predefinidas y la personalizada dentro de 20–110 × 15–160
    for ancho, alto in ((19, 30), (111, 30), (50, 14), (50, 161)):
        r = pedir(ancho_mm=ancho, alto_mm=alto); assert r.status_code == 400 and "de 20 a 110 mm de ancho y de 15 a 160 mm de alto" in r.json()["detail"]
    assert pedir(formato="otro").status_code == 400 and pedir(hoja="a4").status_code == 400
    # un producto sin código no se imprime: primero se le genera
    r = c.post("/api/productos/etiquetas", json={"items": [{"id": a["id"], "copias": 1}, {"id": b["id"], "copias": 2}]})
    assert r.status_code == 400 and r.json()["detail"] == "«Sin código todavía» no tiene código: genere primero el código de barras (Ítems › Generar códigos de barras)"
    assert c.post("/api/productos/codigos/generar", json={"ids": [b["id"]]}).json()["cambiados"] == 1
    assert len(_pdf(c.post("/api/productos/etiquetas", json={"items": [{"id": a["id"], "copias": 1}, {"id": b["id"], "copias": 2}]})).pages) == 3
    # un código que no se puede poner en barras, o que no cabe en esa etiqueta, se dice con claridad
    r = c.post("/api/productos/etiquetas", json={"items": [{"id": raro["id"], "copias": 1}]}); assert r.status_code == 400 and "no caben en un código de barras" in r.json()["detail"]
    veinte = _alta(c, "Código de veinte", "ABCDEFGHIJ-KLMNOPQRS")
    r = c.post("/api/productos/etiquetas", json={"items": [{"id": veinte["id"], "copias": 1}], "ancho_mm": 30, "alto_mm": 20})
    assert r.status_code == 400 and r.json()["detail"] == "El código ABCDEFGHIJ-KLMNOPQRS no cabe en una etiqueta de 30 mm de ancho: use una etiqueta más ancha"
    assert c.post("/api/productos/etiquetas", json={"items": [{"id": veinte["id"], "copias": 1}], "ancho_mm": 60, "alto_mm": 40}).status_code == 200
    assert etiquetas.texto_precio(1234567.891) == "¢1.234.567,89" and etiquetas.texto_precio(10.5, "USD") == "$10,50" and etiquetas.texto_precio(3, "MXN") == "MXN 3,00"


# ================================================================================================ E7 · el trabajo en TSPL y en ZPL
CAFE = {"nombre": "Café molido 500 g", "codigo": "2000000000015", "copias": 3}


def test_e7_tspl_salida_exacta_de_un_caso_simple():
    assert ei.tspl([CAFE], 50, 30) == (
        'SIZE 50 mm,30 mm\r\n'
        'GAP 2 mm,0 mm\r\n'
        'DIRECTION 1\r\n'
        'CODEPAGE 1252\r\n'
        'DENSITY 8\r\n'
        'CLS\r\n'
        'TEXT 64,12,"3",0,1,1,"Café molido 500 g"\r\n'
        'BARCODE 57,40,"EAN13",164,0,0,3,3,"200000000001"\r\n'
        'TEXT 122,208,"2",0,1,1,"2000000000015"\r\n'
        'PRINT 1,3\r\n').encode("cp1252")


def test_e7_zpl_salida_exacta_de_un_caso_simple():
    assert ei.zpl([CAFE], 50, 30) == (
        '^XA\n'
        '^PON\n'
        '^CI28\n'
        '^PW400\n'
        '^LL240\n'
        '^FO0,12^A0N,28,28^FB400,1,0,C^FDCafé molido 500 g\\&^FS\n'
        '^FO57,44^BY3^BEN,162,N,N^FD200000000001^FS\n'
        '^FO0,210^A0N,18,18^FB400,1,0,C^FD2000000000015\\&^FS\n'
        '^PQ3\n'
        '^XZ\n').encode("utf-8")


ORDENES_TSPL = ("SIZE ", "GAP ", "DIRECTION ", "CODEPAGE ", "DENSITY ", "CLS", "TEXT ", "BARCODE ", "PRINT ")
MALO = 'Tornillo "hex" 3/8\r\nPRINT 9,9\x00\x1b ^XA~JR \\ ñandú CLS'


def test_e7_tspl_limpieza_tildes_copias_y_medida():
    b = ei.tspl([{"nombre": MALO, "codigo": "TOR-38X2", "precio": "₡1.500,00", "copias": 7}, {"nombre": "", "codigo": "2000000001234", "copias": 500}], 58, 40, 3, 10)
    t = b.decode("cp1252")
    lineas = t.split("\r\n")
    assert lineas[-1] == "" and all(ln.startswith(ORDENES_TSPL) for ln in lineas[:-1])           # cada renglón es una orden conocida: nada de lo que vino en el nombre
    assert lineas[:5] == ["SIZE 58 mm,40 mm", "GAP 3 mm,0 mm", "DIRECTION 1", "CODEPAGE 1252", "DENSITY 10"]
    assert t.count("CLS\r\n") == 2 and lineas.count("PRINT 1,7") == 1 and lineas.count("PRINT 1,500") == 1 and "PRINT 9,9" not in lineas
    textos = [ln for ln in lineas if ln.startswith("TEXT ")]
    assert all(ln.count('"') == 4 for ln in textos)                                                # la comilla del nombre no cierra la orden
    assert textos[0].endswith(",\"Tornillo 'hex' 3/8 PRINT\"") and textos[1].endswith(',"9,9 XA JR / ñandú CLS"')   # comillas, saltos, controles, ^ ~ y \ fuera
    assert not any(ch in t for ch in "\x00\x1b^~\\ ")
    assert "ñandú".encode("cp1252") in b and b"\xf1and\xfa" in b                                # tildes y ñ en la página 1252
    assert textos[3].endswith(',"¢1.500,00"') and b"\xa21.500,00" in b                          # «₡» sale como «¢», que sí está en la impresora
    assert 'BARCODE 47,68,"128",188,0,0,3,3,"TOR-38X2"' in lineas                                # Code128 cuando no es EAN-13
    assert [ln for ln in lineas if ln.startswith("BARCODE")][1].startswith('BARCODE 89,') and '"EAN13"' in lineas[-4] and lineas[-4].endswith('"200000000123"')   # EAN-13: 12 dígitos, el verificador lo pone la impresora
    assert sum(1 for ln in lineas if ln.startswith("TEXT ")) == 5                                # 2 del nombre + número + precio, y solo el número en la segunda
    # sin densidad no se manda DENSITY; la separación 0 es papel continuo; medidas con decimales
    assert ei.tspl([CAFE], 76.2, 50.8, 0, None).decode("cp1252").split("\r\n")[:5] == ["SIZE 76.2 mm,50.8 mm", "GAP 0 mm,0 mm", "DIRECTION 1", "CODEPAGE 1252", "CLS"]
    # un carácter que la página 1252 no tiene no rompe el trabajo
    assert b'"Caf\xe9 ? 500 g"' in ei.tspl([{"nombre": "Café 咖 500 g", "codigo": "A1", "copias": 1}], 50, 30)


def test_e7_zpl_limpieza_tildes_copias_y_medida():
    b = ei.zpl([{"nombre": MALO, "codigo": "TOR-38X2", "precio": "₡1.500,00", "copias": 7}, {"nombre": "", "codigo": "2000000001234", "copias": 500}], 58, 40, 20)
    t = b.decode("utf-8")
    lineas = t.split("\n")
    assert lineas[0] == "~SD20" and lineas[1:6] == ["^XA", "^PON", "^CI28", "^PW464", "^LL320"] and lineas[-1] == ""
    assert t.count("^XA") == 2 and t.count("^XZ") == 2 and t.count("~") == 1 and lineas.count("^PQ7") == 1 and lineas.count("^PQ500") == 1
    campos = [ln for ln in lineas if "^FD" in ln]
    assert all(ln.count("^FD") == 1 and ln.endswith("^FS") and ln.count("^FO") == 1 for ln in campos)   # el «^XA~JR» del nombre no abre otra orden
    assert "^FDTornillo 'hex' 3/8 PRINT\\&^FS" in campos[0] and "^FD9,9 XA JR / ñandú CLS\\&^FS" in campos[1]
    assert "ñandú".encode("utf-8") in b and "¢1.500,00".encode("utf-8") in b and "₡" not in t
    assert "^FO47,76^BY3^BCN,178,N,N,N^FDTOR-38X2^FS" in lineas                                    # Code128
    assert any(ln.startswith("^FO89,") and "^BEN," in ln and ln.endswith("^FD200000000123^FS") for ln in lineas)   # EAN-13: 12 dígitos, el verificador lo pone la impresora
    assert all(c in "\n" or ord(c) >= 32 for c in t)
    assert ei.zpl([CAFE], 100, 150).decode("utf-8").split("\n")[:5] == ["^XA", "^PON", "^CI28", "^PW799", "^LL1199"]          # sin densidad: no se manda ~SD


def test_e7_todo_cabe_en_la_etiqueta_en_todas_las_medidas():
    """En cada medida predefinida y en los extremos de la personalizada: las barras con su zona quieta, cada cosa debajo de la anterior
    (el nombre nunca encima de las barras) y nada fuera de la etiqueta."""
    largo = "Tornillo cabeza hexagonal galvanizado de 3/8 x 2 pulgadas con tuerca y arandela de presión extra"
    fuentes = [((f, m), a, h) for f, m, a, h in ei.FUENTES_TSPL]
    vistos = 0
    for ancho, alto in ei.MEDIDAS + ((20, 15), (110, 160), (110, 15), (20, 160)):
        for codigo in ("2000000000015", "TOR-38X2", "ABCDEFGHIJ-KLMNOPQRS"):
            for precio in ("", "¢1.234.567,89"):
                for nombre in ("", "Café", largo):
                    try:
                        p = ei.plan_etiqueta(nombre, codigo, precio, ancho, alto, 203, fuentes)
                    except ValueError as ex:
                        assert "no cabe en una etiqueta" in str(ex) and codigo != "2000000000015", (ancho, alto, codigo, str(ex))   # el EAN-13 propio cabe en todas
                        continue
                    vistos += 1
                    x, y, h = p["barras"]
                    modulos = (95 if p["ean"] else 11 * (len(codigo) + 2) + 13) * p["n"]
                    assert x >= 10 * p["n"] and x + modulos <= p["W"] - 7 * p["n"] and h >= ei._puntos(3, 203), (ancho, alto, codigo)
                    cosas = [(t, tx, ty, p["f_nombre"]) for t, tx, ty in p["nombre"]] + [("", x, y, (None, modulos, h))] + [(*p["numero"], p["f_numero"])] + ([(*p["precio"], p["f_precio"])] if p["precio"] else [])
                    fondo = 0
                    for t, tx, ty, f in cosas:
                        ancho_px = f[1] if f[0] is None else len(t) * f[1]
                        assert ty >= fondo and tx >= 0 and tx + ancho_px <= p["W"], (ancho, alto, codigo, t)
                        fondo = ty + f[2]
                    assert fondo <= p["H"] and len(p["nombre"]) <= 2
    assert vistos > 150
    # un código de 20 caracteres no cabe en 30 mm: se dice, no se imprime mal
    with pytest.raises(ValueError, match="no cabe en una etiqueta de 30 mm de ancho"):
        ei.tspl([{"nombre": "x", "codigo": "ABCDEFGHIJ-KLMNOPQRS", "copias": 1}], 30, 20)
    # un código con signos que la impresora lee como órdenes (o con tildes) no se manda
    for malo in ('AB"CD', "AB^CD", "AB~CD", "AB>CD", "AB\\CD", "CAÑA", "AB\nCD", ""):
        assert not ei.codigo_imprimible(malo)
        with pytest.raises(ValueError):
            ei.zpl([{"nombre": "x", "codigo": malo, "copias": 1}], 50, 30)
    assert ei.codigo_imprimible("AB-12.3/4 X_5+6*7")
    assert ei.limpiar("  a\tb\r\nc  \x07 d ", 80) == "a b c d" and ei.limpiar("abcdef", 3) == "abc" and ei.limpiar(None) == ""


# ================================================================================================ E7/E8 · el trabajo de etiquetas del agente
def _trabajo(**cambios):
    return {"conexion": "usb", "direccion": "3nStar LDT124", "lenguaje": "tspl", "ancho_mm": 50, "alto_mm": 30, "separacion_mm": 2, "densidad": 8,
            "etiquetas": [dict(CAFE)], **cambios}


def test_e7_trabajo_de_etiquetas_validacion_y_topes():
    destino, datos = ei.trabajo_etiquetas(_trabajo())
    assert destino == {"conexion": "usb", "direccion": "3nStar LDT124"} and datos == ei.tspl([CAFE], 50, 30)
    destino, datos = ei.trabajo_etiquetas(_trabajo(conexion="red", direccion=" 192.168.1.60 ", lenguaje="ZPL", densidad=None))
    assert destino == {"conexion": "red", "direccion": "192.168.1.60"} and datos == ei.zpl([CAFE], 50, 30)
    assert ei.trabajo_etiquetas(_trabajo(densidad="", separacion_mm=None))[1] == ei.tspl([CAFE], 50, 30, 2, None)       # campos opcionales: valor por omisión
    malos = {"lenguaje": [("pdf", "TSPL o ZPL"), ("escpos", "TSPL o ZPL"), (None, "TSPL o ZPL")],
             "conexion": [("navegador", "USB"), ("", "USB")],
             "ancho_mm": [(19, "de 20 a 110 mm de ancho"), (111, "de 20 a 110"), ("x", "de 20 a 110"), (None, "de 20 a 110")],
             "alto_mm": [(14, "de 15 a 160 mm de alto"), (161, "de 15 a 160")],
             "separacion_mm": [(-1, "de 0 a 20 mm"), (21, "de 0 a 20 mm"), ("x", "deben ser números")],
             "densidad": [(16, "de 0 a 15"), (-1, "de 0 a 15")],
             "dpi": [(72, "203, 300 o 600")],
             "etiquetas": [([], "No hay etiquetas"), (None, "No hay etiquetas"), (["x"], "No hay etiquetas"),
                           ([{**CAFE, "copias": 0}], "de 1 a 500"), ([{**CAFE, "copias": 501}], "de 1 a 500"), ([{**CAFE, "copias": "x"}], "de 1 a 500"),
                           ([{**CAFE, "codigo": ""}], "sin código"), ([{**CAFE, "codigo": 'A"1'}], "no se puede imprimir en barras"),
                           ([{**CAFE, "copias": 500}] * 6 + [{**CAFE, "copias": 1}], "hasta 3000 etiquetas")]}
    for campo, casos in malos.items():
        for valor, mensaje in casos:
            with pytest.raises(ValueError, match=mensaje):
                ei.trabajo_etiquetas(_trabajo(**{campo: valor}))
    assert len(ei.trabajo_etiquetas(_trabajo(etiquetas=[{**CAFE, "copias": 500}] * 6))[1]) > 500           # 3.000 justas sí
    assert ei.trabajo_etiquetas(_trabajo(lenguaje="zpl", densidad=30))[1].startswith(b"~SD30\n")
    with pytest.raises(ValueError, match="de 0 a 30"):
        ei.trabajo_etiquetas(_trabajo(lenguaje="zpl", densidad=31))
    with pytest.raises(ValueError):
        ei.trabajo_etiquetas("SIZE 50 mm")                                                                  # nunca órdenes sueltas


def test_e7_el_agente_recibe_el_trabajo_por_su_ruta_de_imprimir(monkeypatch):
    import http.client
    from app import agente_local, escpos
    enviados = []
    monkeypatch.setattr(escpos, "enviar", lambda impresora, datos: enviados.append((impresora, datos)))
    # por la función que usan el agente suelto, el programa de escritorio y la instalación local
    escpos.ejecutar("imprimir", {"nombre": "Etiquetas", "conexion": "usb", "direccion": "3nStar LDT124"}, {"etiquetas": _trabajo()})
    assert enviados == [({"conexion": "usb", "direccion": "3nStar LDT124"}, ei.tspl([CAFE], 50, 30))]
    # la conexión puede venir solo en «impresora»
    enviados.clear()
    escpos.ejecutar("imprimir", {"conexion": "red", "direccion": "192.168.1.60"}, {"etiquetas": _trabajo(conexion=None, direccion=None, lenguaje="zpl", densidad=None)})
    assert enviados == [({"conexion": "red", "direccion": "192.168.1.60"}, ei.zpl([CAFE], 50, 30))]
    # el destino es el de los datos sin formato: USB o una IP privada en el 9100, nunca otra dirección ni otro puerto
    enviados.clear()
    for direccion in ("8.8.8.8", "127.0.0.1:8020", "192.168.1.60:8080", "impresora.ejemplo.test"):
        with pytest.raises(ValueError, match="impresora USB o a una impresora de la red local"):
            escpos.ejecutar("imprimir", {}, {"etiquetas": _trabajo(conexion="red", direccion=direccion)})
    with pytest.raises(ValueError, match="TSPL o ZPL"):
        escpos.ejecutar("imprimir", {}, {"etiquetas": _trabajo(lenguaje="pdf")})
    with pytest.raises(ValueError):
        escpos.ejecutar("imprimir", {"conexion": "usb"}, {"etiquetas": "SIZE 50 mm,30 mm\r\nPRINT 1"})    # no hay envío crudo: solo datos
    assert enviados == []
    # un tiquete de siempre sigue saliendo en ESC/POS
    escpos.ejecutar("imprimir", {"conexion": "usb", "direccion": "EPSON"}, {"documento": {"bloques": [{"t": "texto", "x": "hola"}]}})
    assert len(enviados) == 1 and enviados[0][1].startswith(b"\x1b@") and b"SIZE" not in enviados[0][1]
    # por HTTP en el 9800: /estado anuncia que sabe de etiquetas y /imprimir recibe el trabajo
    enviados.clear()
    srv = escpos.iniciar_agente_en_hilo(0, version="4.24")
    try:
        def pedir(metodo, ruta, cuerpo=None):
            con = http.client.HTTPConnection("127.0.0.1", srv.puerto, timeout=10)
            con.request(metodo, ruta, body=json.dumps(cuerpo).encode("utf-8") if cuerpo is not None else None, headers={"Content-Type": "application/json"})
            r = con.getresponse(); out = (r.status, json.loads(r.read())); con.close()
            return out
        assert pedir("GET", "/estado")[1]["etiquetas"] == escpos.VERSION_ETIQUETAS == 1
        st, j = pedir("POST", "/imprimir", {"impresora": {"nombre": "Etiquetas", "conexion": "usb", "direccion": "3nStar LDT124"}, "etiquetas": _trabajo(etiquetas=[{**CAFE, "copias": 2}])})
        assert st == 200 and j == {"ok": True} and len(enviados) == 1 and enviados[0][1].endswith(b"PRINT 1,2\r\n")
        st, j = pedir("POST", "/imprimir", {"impresora": {"conexion": "usb"}, "etiquetas": _trabajo(etiquetas=[{**CAFE, "copias": 9999}])})
        assert st == 500 and j == {"ok": False, "error": "Las copias de cada producto van de 1 a 500"} and len(enviados) == 1
        assert pedir("POST", "/raw", {"impresora": {"conexion": "usb"}, "datos": ""})[0] == 404           # sigue sin haber envío crudo
    finally:
        srv.shutdown(); srv.server_close()
    assert escpos.RUTAS_AGENTE == ("imprimir", "prueba", "gaveta")
    # la instalación local (un solo programa): lo mismo por /api/agente
    monkeypatch.setattr(agente_local, "MODO_LOCAL", True)
    assert agente_local.estado(None)["etiquetas"] == 1
    enviados.clear()
    assert agente_local.imprimir("imprimir", {"impresora": {"conexion": "usb", "direccion": "Zebra ZD230"}, "etiquetas": _trabajo(lenguaje="zpl", densidad=None)}, None) == {"ok": True}
    assert enviados == [({"conexion": "usb", "direccion": "3nStar LDT124"}, ei.zpl([CAFE], 50, 30))]
    with pytest.raises(main.HTTPException) as ex:
        agente_local.imprimir("imprimir", {"impresora": {}, "etiquetas": _trabajo(ancho_mm=500)}, None)
    assert ex.value.status_code == 400 and "de 20 a 110 mm de ancho" in ex.value.detail
    # el armador no depende de nada más del sistema (va dentro del agente suelto y del programa de escritorio)
    fuente = (RAIZ / "app" / "etiquetas_impresora.py").read_text(encoding="utf-8")
    assert [ln for ln in fuente.splitlines() if ln.startswith(("import ", "from "))] == ["import unicodedata"]
    assert "from . import etiquetas_impresora" in (RAIZ / "app" / "escpos.py").read_text(encoding="utf-8")


# ================================================================================================ E5/E6/E8 · la pantalla
def test_e8_medidas_formatos_modelos_y_topes_iguales_en_servidor_y_pantalla(tmp_path):
    """La misma lista en los dos lados: si alguien agrega una medida o un modelo solo en uno, esta prueba lo dice."""
    r = _node(tmp_path, """
import * as E from './js/pages/inventario/_etiquetas.js';
console.log(JSON.stringify({ medidas: E.MEDIDAS, modelos: E.MODELOS, formatos: E.FORMATOS.map(f => f[0]), nombres_formatos: E.FORMATOS.map(f => f[1]), lenguajes: E.LENGUAJES.map(l => l[0]), nombres_lenguajes: E.LENGUAJES.map(l => l[1]),
  topes: [E.ANCHO_MIN, E.ANCHO_MAX, E.ALTO_MIN, E.ALTO_MAX, E.COPIAS_MAX, E.ETIQUETAS_MAX, E.ALTERNOS_MAX, E.SEPARACION_MM, E.CODIGO_MAX],
  propios: [0, 1, 123, 9999999, 10000000, 30000123, 99999999, 100000000].map(i => E.codigoBarrasPropio(i, '999')), malo: [E.codigoBarrasPropio(-1, '999'), E.codigoBarrasPropio(1), E.codigoBarrasPropio(1, '12')],
  ean: ['7501031311309', '7501031311300', '750103131130', '2000000000015', 'ABCDEFGHIJKLM', null].map(E.esEan13),
  texto: E.medidaTexto([50, 30]), modelo: E.modeloDe('zebra-zd230').lenguaje, sin_modelo: E.modeloDe('x') }));
""")
    assert [tuple(m) for m in r["medidas"]] == list(ei.MEDIDAS) == [(30, 20), (40, 25), (40, 30), (50, 25), (50, 30), (58, 40), (60, 40), (76, 51), (100, 50), (100, 150)]
    assert r["modelos"] == [dict(m) for m in ei.MODELOS]
    assert r["formatos"] == list(ei.FORMATOS) and r["lenguajes"] == list(ei.LENGUAJES)
    assert r["topes"] == [ei.ANCHO_MIN, ei.ANCHO_MAX, ei.ALTO_MIN, ei.ALTO_MAX, ei.COPIAS_MAX, ei.ETIQUETAS_MAX, ei.ALTERNOS_MAX, ei.SEPARACION_MM, ei.CODIGO_MAX] == [20, 110, 15, 160, 500, 3000, 5, 2, 20]
    assert r["propios"] == [_propio(i) for i in (0, 1, 123, 9999999, 10000000, 30000123, 99999999, 100000000)] and r["malo"] == ["", "", ""]   # sin marca, la pantalla no supone un código
    assert r["ean"] == [True, False, False, True, False, False] and r["texto"] == "50 × 30 mm" and r["modelo"] == "zpl" and r["sin_modelo"] is None
    assert r["nombres_formatos"] == ["Nombre y código de barras", "Nombre, código de barras y precio", "Solo el código de barras"]
    assert r["nombres_lenguajes"] == ["TSPL", "ZPL", "Controlador de Windows (PDF)"]
    # los modelos que pidió el dueño, con el lenguaje de cada uno
    por = {m["nombre"]: m for m in ei.MODELOS}
    assert list(por) == ["3nStar LDT124", "3nStar LDT114", "TSC TE200", "TSC TTP-244 Pro", "TSC DA210", "Xprinter XP-365B", "Xprinter XP-420B", "Gprinter GP-1324D",
                         "Zebra ZD220", "Zebra ZD230", "Zebra ZD420", "Zebra GK420", "Otra con TSPL", "Otra con ZPL", "Otra, con controlador de Windows (PDF)"]
    assert all(m["dpi"] == 203 for m in ei.MODELOS) and por["3nStar LDT124"] == {"id": "3nstar-ldt124", "nombre": "3nStar LDT124", "lenguaje": "tspl", "dpi": 203, "ancho_max_mm": 104, "densidad": 8}
    assert {m["lenguaje"] for n, m in por.items() if n.startswith("Zebra")} == {"zpl"} and {m["lenguaje"] for n, m in por.items() if n.startswith(("3nStar", "TSC", "Xprinter", "Gprinter"))} == {"tspl"}
    assert por["Otra, con controlador de Windows (PDF)"]["lenguaje"] == "pdf" and len({m["id"] for m in ei.MODELOS}) == len(ei.MODELOS)


def test_e5_copias_impresora_propuesta_y_trabajo_en_node(tmp_path):
    r = _node(tmp_path, """
import * as E from './js/pages/inventario/_etiquetas.js';
import { ean13, barrasDe, code128 } from './js/pages/inventario/_barras.js';
const imp = { id: 7, nombre: 'Etiquetas bodega', uso: 'etiquetas', conexion: 'usb', direccion: '3nStar LDT124', lenguaje: 'tspl', dpi: 203, etq_ancho_mm: 58, etq_alto_mm: 40, separacion_mm: 3, densidad: 10, activa: true };
const zebra = { id: 8, nombre: 'Zebra caja', uso: 'etiquetas', conexion: 'red', direccion: '192.168.1.60', lenguaje: 'zpl', densidad: '', activa: true };
const pdf = { id: 9, nombre: 'Con controlador', uso: 'etiquetas', conexion: 'navegador', lenguaje: 'pdf', activa: true };
const tiquetes = { id: 1, nombre: 'Caja', uso: 'comprobante', conexion: 'usb', direccion: 'EPSON', activa: true };
const items = [{ id: 1, nombre: 'Café', codigo: ' 2000000000015 ', precio_texto: '₡1.500,00', copias: 3 }, { id: 2, nombre: 'Té', codigo: 'TE-1', precio_texto: '₡900,00', copias: 0 },
  { id: 3, nombre: 'Sin código', codigo: '', precio_texto: '₡1,00', copias: 2 }, { id: 4, nombre: 'Pan', codigo: 'PAN-1', precio_texto: '', copias: '2' }];
const bits = ean13('5901234123457');
console.log(JSON.stringify({
  copias: [1, '7', 500, 501, 9999, 0, -3, '', null, 2.9, 'x'].map(E.copiasDe), existencias: [0, 0.4, 12, 12.2, 800, -5, null].map(E.copiasPorExistencias),
  total: E.totalEtiquetas(items), total_vacio: E.totalEtiquetas([]),
  medidas: [[20, 15], [110, 160], [19, 30], [111, 30], [50, 14], [50, 161], ['', ''], [58.5, 40]].map(m => E.medidaValida(m[0], m[1])),
  propuesta: [E.impresoraPropuesta([imp, tiquetes], ''), E.impresoraPropuesta([imp, zebra], ''), E.impresoraPropuesta([imp, zebra], '8'), E.impresoraPropuesta([imp, zebra], '99'), E.impresoraPropuesta([tiquetes], '1'), E.impresoraPropuesta([{ ...imp, activa: false }, zebra], ''), E.impresoraPropuesta(null, '')],
  directa: [imp, zebra, pdf, tiquetes, { ...imp, conexion: 'navegador' }, null].map(E.directa), medida_imp: [E.medidaImpresora(imp), E.medidaImpresora(zebra), E.medidaImpresora({ etq_ancho_mm: 500, etq_alto_mm: 30 })],
  trabajo: E.trabajoEtiquetas(imp, items, 'nombre_codigo_precio', [58, 40]), trabajo_zebra: E.trabajoEtiquetas(zebra, items.slice(0, 1), 'solo_codigo', [50, 30]), trabajo_simple: E.trabajoEtiquetas(imp, items.slice(0, 1), 'nombre_codigo', [50, 30]),
  bits, ean_malo: ean13('ABC'), barras_ean: barrasDe('5901234123457', true), barras_128: { ...barrasDe('AB', false), tramos: barrasDe('AB', false).tramos.length }, largo_128: code128('AB').length, vacio: barrasDe('', false),
}));
""", archivos=(("pages", "inventario", "_etiquetas.js"), ("pages", "inventario", "_barras.js")))
    assert r["copias"] == [1, 7, 500, 500, 500, 0, 0, 0, 0, 2, 0]                    # de 1 a 500; 0 = ese producto no se imprime
    assert r["existencias"] == [0, 1, 12, 13, 500, 0, 0] and r["total"] == 7 and r["total_vacio"] == 0
    assert r["medidas"] == [True, True, False, False, False, False, False, True]
    # una sola impresora de etiquetas: se propone sola; varias: la última usada en este equipo; ninguna: PDF
    assert r["propuesta"] == ["7", "", "8", "", "", "8", ""]
    assert r["directa"] == [True, True, False, False, False, False] and r["medida_imp"] == [[58, 40], [50, 30], [50, 30]]
    # el trabajo para el servicio de impresión: solo datos; sin los que no tienen copias o código
    assert r["trabajo"] == {"conexion": "usb", "direccion": "3nStar LDT124", "lenguaje": "tspl", "ancho_mm": 58, "alto_mm": 40, "separacion_mm": 3, "densidad": 10, "dpi": 203, "girar": False,
                            "etiquetas": [{"nombre": "Café", "codigo": "2000000000015", "precio": "₡1.500,00", "copias": 3}, {"nombre": "Pan", "codigo": "PAN-1", "copias": 2}]}
    assert r["trabajo_zebra"] == {"conexion": "red", "direccion": "192.168.1.60", "lenguaje": "zpl", "ancho_mm": 50, "alto_mm": 30, "separacion_mm": 2, "densidad": None, "dpi": 203, "girar": False,
                                  "etiquetas": [{"nombre": "", "codigo": "2000000000015", "copias": 3}]}
    # ... y el servidor de impresión lo acepta tal cual y arma la misma etiqueta
    assert ei.trabajo_etiquetas(r["trabajo_simple"])[1] == ei.tspl([CAFE | {"nombre": "Café"}], 50, 30, 3, 10)
    assert ei.trabajo_etiquetas(r["trabajo"])[0] == {"conexion": "usb", "direccion": "3nStar LDT124"} and b'"\xa21.500,00"' in ei.trabajo_etiquetas(r["trabajo"])[1]
    assert ei.trabajo_etiquetas(r["trabajo_zebra"])[1].count(b"^FD") == 2
    # vista previa: las barras del EAN-13 son las que dibuja el PDF (mismas tablas que reportlab)
    from reportlab.graphics.barcode.eanbc import Ean13BarcodeWidget as W
    s = "5901234123457"; paridad = W._lhconvert[s[0]]
    esperado = "101" + "".join(W._left[paridad[i]][int(c)] for i, c in enumerate(s[1:7])) + "01010" + "".join(W._right[int(c)] for c in s[7:]) + "101"
    assert r["bits"] == esperado and len(r["bits"]) == 95 and r["ean_malo"] == ""
    assert r["barras_ean"]["tipo"] == "ean13" and r["barras_ean"]["ancho"] == 95 + 22 and len(r["barras_ean"]["tramos"]) == 30 and r["barras_ean"]["tramos"][0] == {"x": 11, "w": 1}
    assert r["barras_128"] == {"tipo": "code128", "ancho": r["largo_128"] + 20, "tramos": 16} and r["largo_128"] == 11 * 4 + 13 and r["vacio"] == {"tipo": "", "ancho": 0, "tramos": []}


def test_e5_textos_del_cuadro_de_etiquetas_y_de_generar():
    items = _js("pages", "inventario", "items.js"); dlg = _js("pages", "inventario", "_etiquetas-dialogos.js")
    # acciones en lote y en «Más acciones»
    assert "{ label: '🖨 Etiquetas', kind: 'sec', handler: rows => this.abrirEtiquetas(rows) }" in items
    assert "{ label: '▥ Generar códigos de barras', kind: 'sec', handler: rows => this.abrirGenerar(rows) }" in items
    assert "{ label: 'Registrar códigos con el lector', kind: 'sec', handler: rows => this.abrirRegistrar(rows) }" in items
    assert '@click="etiquetas" title="Etiquetas con el nombre y el código de barras de los ítems que muestra la lista (con sus filtros y su búsqueda)' in items and ">Etiquetas con código de barras</a>" in items
    assert '@click="abrirGenerar(visibles())"' in items and ">Generar códigos de barras</a>" in items
    assert "etiquetas() { this.abrirEtiquetas(this.visibles()); }," in items and "visibles() { const t = this.$refs.tabla;" in items and '<DataTable ref="tabla"' in items
    assert '<DialogoEtiquetas v-if="etq" :productos="etq" @close="cerrarCodigos"></DialogoEtiquetas>' in items and '<DialogoGenerarCodigos v-if="generar" :productos="generar"' in items
    # la hoja de antes (un código «GF000123» que la caja no reconocía, en una página con un guion que no corría) ya no existe
    assert "'GF' +" not in items and "svgBarras" not in items and "window.print()" not in items and "text/html" not in items
    # el aviso de repetidos, con el texto pedido y el botón que filtra
    assert "(n === 1 ? 'Hay 1 código repetido' : 'Hay ' + n + ' códigos repetidos') + ': la caja toma el primero que encuentra'" in items
    assert '<button class="btn sm sec" @click="soloRepetidos=!soloRepetidos">' in items and "api('/api/productos/codigos/repetidos')" in items
    # el cuadro de etiquetas
    for texto in ('<Modal title="Etiquetas con código de barras" lg', "Copias para todos", ">Según existencias</button>", "Total: {{total}} {{total === 1 ? 'etiqueta' : 'etiquetas'}}", '<Field label="Formato">',
                  '<Field label="Medida de la etiqueta">', '<option value="personalizada">Personalizada</option>', '<option value="">Elegir al imprimir (PDF)</option>', "Vista previa",
                  ">Descargar PDF</button>", "{{trabajando ? 'Preparando…' : 'Imprimir'}}", 'title="Quitar de la lista"',
                  "n + ' productos no tienen código: se les genera uno al imprimir'", "'1 producto no tiene código: se le genera uno al imprimir'",
                  "'El envío directo necesita el programa de escritorio actualizado: se abre el PDF para imprimir a mano'"):
        assert texto in dlg, texto
    assert "recordar('etiquetas:formato', this.formato); recordar('etiquetas:medida', this.medida[0] + 'x' + this.medida[1]); recordar('etiquetas:impresora', this.impId);" in dlg   # recordados en este navegador
    assert "if (sabeEtiquetas(est)) {" in dlg and "await imprimirEtiquetas(imp, trabajoEtiquetas(imp, lista, this.formato, this.medida));" in dlg and "if (!descargar && directa(imp)) {" in dlg
    assert "await abrirArchivo('/api/productos/etiquetas', descargar ? 'etiquetas.pdf' : null, { items: lista.map(x => ({ id: x.id, copias: copiasDe(x.copias) })), formato: this.formato, ancho_mm: this.medida[0], alto_mm: this.medida[1], hoja: this.impId === 'carta' ? 'carta' : null, ...(imp && +imp.dpi ? { dpi: +imp.dpi } : {}) }, 'etiquetas.pdf');" in dlg
    assert "const g = await api('/api/productos/codigos/generar', { method: 'POST', body: { ids: faltan.map(x => x.id) } });" in dlg      # a los que no tienen, primero se les genera
    # el cuadro de generar: las dos opciones, la explicación de la segunda y la confirmación con el número de productos
    for texto in ("<b>Solo a los que no tienen</b>", "<b>A todos: reemplaza los que ya tienen</b>",
                  "El código anterior queda como código alterno: la caja lo sigue reconociendo. Las facturas nuevas llevarán el código nuevo.",
                  "if (!confirm('Se va a generar el código de barras de ' + n + (n === 1 ? ' producto' : ' productos')", "reemplazar: this.modo === 'todos'"):
        assert texto in dlg, texto
    # nada técnico a la vista en Ítems (TSPL y ZPL solo se nombran en la configuración de la impresora)
    assert "TSPL" not in dlg and "ZPL" not in dlg and "TSPL" not in items
    # la tabla de selección deja bajar los botones a otra línea cuando no caben
    assert ".selbar{display:flex;flex-wrap:wrap;" in (RAIZ / "app" / "static" / "ui.css").read_text(encoding="utf-8")


def test_e6_impresora_de_etiquetas_en_la_configuracion():
    cfg = _js("pages", "pos", "configuracion.js"); datos = _js("pages", "pos", "_datos.js"); agente = _js("pages", "pos", "_agente.js"); montos = _js("pages", "reportes", "_montos.js")
    assert "['etiquetas', 'Etiquetas de productos']]" in datos
    assert "import { MODELOS as MODELOS_ETQ, LENGUAJES as LENGUAJES_ETQ, MEDIDAS as MEDIDAS_ETQ," in cfg                       # la lista de modelos y medidas, de un solo lugar
    for texto in ("+ Impresora de etiquetas</button>", '<Field label="Modelo" req', '<option v-for="m in MODELOS_ETQ" :key="m.id" :value="m.id">{{m.nombre}}</option>',
                  '<Field label="Lenguaje de la impresora" req help="TSPL: 3nStar, TSC, Xprinter, Gprinter y casi todas las de etiquetas. ZPL: Zebra. Si no sabe cuál usa la suya, elija «Controlador de Windows (PDF)»',
                  '<Field label="Medida de la etiqueta"', '<Field label="Separación entre etiquetas (mm)"', '<Field label="Densidad (qué tan oscuro imprime)"',
                  ">Imprimir etiqueta de prueba</button>", "if (i.uso === 'etiquetas') return this.probarEtiqueta(i);", "f.separacion_mm = 2;",
                  "if (mod && +f.etq_ancho_mm > mod.ancho_max_mm) return toast('La ' + mod.nombre + ' imprime hasta ' + mod.ancho_max_mm + ' mm de ancho: elija una etiqueta más angosta', 'err');",
                  "alCambiarModelo() { const f = this.impForm, m = modeloDe(f.modelo); if (!m) return; f.lenguaje = m.lenguaje; f.dpi = m.dpi; f.densidad = m.densidad;",
                  "await abrirArchivo('/api/productos/etiquetas', null, { prueba: true, formato: 'nombre_codigo', ancho_mm: medida[0], alto_mm: medida[1], ...(+i.dpi ? { dpi: +i.dpi } : {}) }, 'etiquetas.pdf')"):
        assert texto in cfg, texto
    # el servicio de impresión: solo se le manda a quien dice que sabe de etiquetas, por la ruta de imprimir y sin órdenes de impresora
    assert "export function sabeEtiquetas(estado) { return !!(estado && estado.ok && estado.info && estado.info.etiquetas); }" in agente
    assert "return pedir('/imprimir', { impresora: { nombre: imp.nombre, conexion: imp.conexion, direccion: imp.direccion || '' }, etiquetas: trabajo });" in agente and "/raw" not in agente
    # la impresora de etiquetas no sale entre las de reportes (les llegaría un tiquete)
    assert "impresoras().filter(i => i.activa !== false && i.uso !== 'etiquetas' && porAgente(i))" in montos


COMPILAR_JS = r"""
import { readFileSync } from 'node:fs';
globalThis.document = { createElement: () => { const el = { _v: '', children: [{ getAttribute: () => el._attr }], set innerHTML(v) { el._v = v; const m = /foo="([^]*)">$/.exec(v); el._attr = m ? m[1].replace(/&quot;/g, '"') : v; }, get innerHTML() { return el._v; } }; return el; } };
const V = await import('./vue.mjs');
const VACIAS = new Set(['input', 'br', 'img', 'hr', 'col', 'meta', 'link']);
const out = {};
for (const ruta of process.argv.slice(2)) {
  const src = readFileSync(ruta, 'utf8'), plantillas = [...src.matchAll(/\btemplate: `([^`]*)`/g)].map(m => m[1]);
  out[ruta] = plantillas.map(tpl => {
    const errores = [], cuenta = {};
    if (tpl.includes('${')) errores.push('la plantilla lleva ${');
    try { V.compile(tpl, { onError: e => errores.push(String(e.code) + ' ' + (e.message || '')), onWarn: () => {} }); } catch (e) { errores.push(e.message); }
    const sinTexto = tpl.replace(/\{\{[^]*?\}\}/g, '');
    for (const m of sinTexto.matchAll(/<([A-Za-z][\w-]*)((?:"[^"]*"|'[^']*'|[^'">])*)>/g)) { if (VACIAS.has(m[1]) || m[2].trimEnd().endsWith('/')) continue; cuenta[m[1]] = (cuenta[m[1]] || 0) + 1; }
    for (const m of sinTexto.matchAll(/<\/([A-Za-z][\w-]*)>/g)) cuenta[m[1]] = (cuenta[m[1]] || 0) - 1;
    return { errores, desbalance: Object.entries(cuenta).filter(([, n]) => n !== 0), letras: tpl.length };
  });
}
console.log(JSON.stringify(out));
"""


def test_e5_las_plantillas_tocadas_compilan(tmp_path):
    """El compilador de Vue del proyecto, en Node: cada plantilla de las pantallas tocadas compila y sus etiquetas abren y cierran parejo."""
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    shutil.copy(JS / "vendor" / "vue.esm-browser.prod.min.js", tmp_path / "vue.mjs")
    (tmp_path / "compilar.mjs").write_text(COMPILAR_JS, encoding="utf-8")
    archivos = {"dialogos.js": ("pages", "inventario", "_etiquetas-dialogos.js"), "items.js": ("pages", "inventario", "items.js"), "item-form.js": ("pages", "inventario", "item-form.js"),
                "configuracion.js": ("pages", "pos", "configuracion.js")}
    for nombre, partes in archivos.items():
        (tmp_path / nombre).write_text(_js(*partes), encoding="utf-8")
    (tmp_path / "rota.js").write_text(_js(*archivos["dialogos.js"]).replace("{{resumen.texto}}", "{{resumen.texto(}}", 1).replace("<p class=\"small muted\" style=\"margin:0 0 12px\">", "<p><div>", 1), encoding="utf-8")
    r = subprocess.run([node, "compilar.mjs", *archivos, "rota.js"], capture_output=True, text=True, encoding="utf-8", timeout=120, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    o = json.loads(r.stdout)
    assert [len(o[n]) for n in archivos] == [3, 1, 1, 1]                                  # los tres cuadros, la lista, la ficha y la configuración
    for nombre in archivos:
        for p in o[nombre]:
            assert p["errores"] == [] and p["desbalance"] == [] and p["letras"] > 1500, (nombre, p)
    assert o["rota.js"][0]["errores"] and o["rota.js"][1]["desbalance"] == [["div", 1]]   # la comprobación sí ve una plantilla rota


# ================================================================================================ hallazgos de la revisión
def test_h1_un_codigo_generado_en_otra_empresa_no_empareja_otro_articulo(api):  # noqa: F811
    """El código generado lleva la marca de la empresa (3 dígitos de su cédula) y el id del ítem: dos empresas con la misma marca
    (o una balanza que usa ese rango) pueden dar el mismo código a artículos distintos. Un traslado, o un archivo de ítems de la
    otra empresa importado en modo «actualizar», no toma por ese código un ítem de aquí que se llama distinto."""
    from app import traslados
    from tests.test_358_b import _subir, _xlsx
    c = api
    jabon = _alta(c, "Jabón azul")
    assert c.post("/api/productos/codigos/generar", json={"ids": [jabon["id"]]}).json()["cambiados"] == 1
    cod = _propio(jabon["id"])                                       # el mismo que tendría el ítem con ese número en otra empresa con la misma marca
    with Session(engine_empresa(_eid())) as s:
        # el «Aceite 1L» de la otra empresa trae ese código: aquí es el jabón, así que no es él. Se crea, y sin el código (aquí ya es de otro)
        aceite, nuevo = traslados._producto_destino(s, _eid(), {"codigo": cod, "nombre": "Aceite 1L", "cabys": CABYS, "precio_unitario": 900})
        assert nuevo is True and aceite.id != jabon["id"] and aceite.nombre == "Aceite 1L" and aceite.codigo is None
        s.commit(); aceite_id = aceite.id
        # el traslado siguiente lo encuentra por el nombre
        p, nuevo = traslados._producto_destino(s, _eid(), {"codigo": cod, "nombre": "aceite 1l", "cabys": CABYS})
        assert nuevo is False and p.id == aceite_id
        # el mismo artículo (se llama igual) sí se empareja por su código generado, sin distinguir mayúsculas en el nombre
        p, nuevo = traslados._producto_destino(s, _eid(), {"codigo": cod, "nombre": "JABÓN AZUL", "cabys": CABYS})
        assert nuevo is False and p.id == jabon["id"]
        s.rollback()
    assert c.get("/api/productos/codigos/repetidos").json()["codigos"] == 0
    # importación en modo «actualizar» con el archivo de la otra empresa: la fila del aceite cambia el aceite (por su nombre), no el jabón;
    # la de un ítem que aquí no existe no entra (crearla repetiría el código) y dice de quién es el código
    fila = lambda nombre, codigo, precio: [nombre, codigo, CABYS, precio, "Unid", "Producto", "08", "CRC", "", "", "", "", ""]   # noqa: E731
    for simular in ("1", "0"):
        d = _subir(c, _xlsx([fila("Aceite 1L", cod, 2500), fila("Vinagre 500 ml", cod, 700)]), modo="actualizar", simular=simular).json()
        assert d["actualizados"] == 1 and d["creados"] == 0 and d["omitidos"] == 1, d
        assert d["errores"] == [f"Fila 3 (Vinagre 500 ml): Ya existe otro producto con el código {cod}: Jabón azul. Es un código generado, que puede repetirse entre empresas: "
                                "ese ítem no se cambió. Si es el mismo, póngale ese nombre en el archivo; si es otro, quite el código de la fila"], d
    assert _prod(c, jabon["id"])["precio"] == 1000 and _prod(c, aceite_id)["precio"] == 2500
    assert sorted(p["nombre"] for p in c.get("/api/productos").json()) == ["Aceite 1L", "Jabón azul"]
    # su propia fila (mismo nombre) se sigue actualizando por el código; en modo «crear» el código de otro se rechaza como siempre
    d = _subir(c, _xlsx([fila("jabón azul", cod, 1100)]), modo="actualizar").json()
    assert d["actualizados"] == 1 and not d["errores"] and _prod(c, jabon["id"])["precio"] == 1100
    d = _subir(c, _xlsx([fila("Vinagre 500 ml", cod, 700)])).json()
    assert d["creados"] == 0 and d["errores"] == [f"Fila 2 (Vinagre 500 ml): Ya existe otro producto con el código {cod}: Jabón azul; use el modo «actualizar» para cambiarlo"]
    # un código que no es generado (de fábrica) sigue siendo ese ítem aunque el archivo lo llame distinto
    arroz = _alta(c, "Arroz 1 kg", "7441001234567")
    d = _subir(c, _xlsx([fila("Arroz blanco de un kilo", "7441001234567", 950)]), modo="actualizar").json()
    assert d["actualizados"] == 1 and _prod(c, arroz["id"])["precio"] == 950
    assert etiquetas.codigo_generado(cod) and etiquetas.codigo_generado(f" {cod} ")
    assert not any(etiquetas.codigo_generado(x) for x in ("7441001234567", "2000000000016", "P100000000000", "CAF-500", "", None))   # de fábrica, verificador malo, texto
    assert etiquetas.codigo_generado("P456-100000000") and etiquetas.codigo_generado(" p456-100000000 ") and not etiquetas.codigo_generado("P45-100000000") and not etiquetas.codigo_generado("P456-")


def test_h2_el_codigo_del_proveedor_que_la_pantalla_ya_trae_puesto_no_frena_el_comprobante(api):  # noqa: F811
    """La pantalla llena el «Código» del ítem nuevo con el del proveedor y lo manda en crear.codigo: si ya es de otro ítem no es un código
    que escribió el usuario; el ítem se crea sin código y el comprobante entra al inventario (antes respondía 409 y no entraba nada)."""
    from tests.test_375_costeo import _registrar, _xml_proveedor
    c = api
    rec = _js("pages", "gastos", "recepcion.js")
    assert "nuevo: { nombre: (l.detalle || '').slice(0, 200), codigo: l.codigo || ''," in rec and "codigo: l.nuevo.codigo || null," in rec   # lo que manda la pantalla
    viejo = _alta(c, "Cemento de la casa", "cem-50")
    rid = _registrar(_eid(), _xml_proveedor(1))
    assert c.get(f"/api/recepcion/{rid}/lineas").json()["lineas"][0]["codigo"] == "CEM-50"             # el código del proveedor en la línea 1
    r = c.post(f"/api/recepcion/{rid}/inventario", json={"lineas": [{"numero": 1, "crear": {"nombre": "Cemento gris 50 kg", "codigo": "CEM-50", "cabys": CABYS, "precio": 9500}}]})
    assert r.status_code == 200 and r.json()["entradas"] == 1, r.text
    nuevo = _prod(c, r.json()["creados"][0]["id"])
    assert nuevo["nombre"] == "Cemento gris 50 kg" and nuevo["codigo"] is None                          # entra, sin el código que ya es de otro ítem
    assert _prod(c, viejo["id"])["codigo"] == "cem-50" and c.get("/api/productos/codigos/repetidos").json()["codigos"] == 0


def test_h3_la_subida_de_una_instalacion_no_pierde_el_codigo_que_se_puso_en_la_nube(api):  # noqa: F811
    """A un ítem del rango de una instalación local se le generó el código en la nube (con etiquetas ya impresas) y la instalación, que
    todavía no lo había bajado, sube el ítem entero con el código de antes: el de la nube queda como código alterno y se sigue leyendo."""
    from app import sinc
    c = api
    eid, pid = _eid(), 3 * 10_000_000 + 12
    with Session(engine_empresa(eid)) as s:
        s.add(Producto(id=pid, empresa_id=eid, nombre="Galleta X", codigo="7441000000012", cabys=CABYS, precio=500, inventariable=False))
        s.add(Producto(id=pid + 1, empresa_id=eid, nombre="Galleta Y", cabys=CABYS, precio=300, inventariable=False)); s.commit()
        local = s.get(Producto, pid).model_dump(); local_y = s.get(Producto, pid + 1).model_dump()       # como los tiene la instalación
    assert c.post("/api/productos/codigos/generar", json={"todos": True, "reemplazar": True}).json()["cambiados"] == 2
    de_nube, de_nube_y = _propio(pid), _propio(pid + 1)
    p = _prod(c, pid); assert p["codigo"] == de_nube and p["codigos_alternos"] == "7441000000012"

    def sube(*filas):
        with Session(engine_empresa(eid)) as s:
            out = sinc._aplicar_cambios_instalacion(s, _ctx(), eid, 3, "Caja local", {"productos": list(filas)})
        assert out["productos"] == len(filas) and out["errores"] == [], out
    # la caja cambia el precio y sube los ítems con lo que conoce: su código de antes (o ninguno) y sin códigos alternos
    sube({**local, "precio": 650}, {**local_y, "precio": 350})
    p = _prod(c, pid); assert p["precio"] == 650 and p["codigo"] == "7441000000012" and p["codigos_alternos"] == de_nube
    y = _prod(c, pid + 1); assert y["precio"] == 350 and y["codigo"] is None and y["codigos_alternos"] == de_nube_y
    with Session(engine_empresa(eid)) as s:                                                             # las etiquetas ya pegadas siguen encontrando el ítem
        assert etiquetas.producto_con_codigo(s, eid, de_nube).id == pid and etiquetas.producto_con_codigo(s, eid, de_nube_y).id == pid + 1
    # un programa anterior, que no conoce los códigos alternos (no los manda): igual
    with Session(engine_empresa(eid)) as s:
        g = s.get(Producto, pid); g.codigo = de_nube; g.codigos_alternos = "7441000000012"; s.add(g); s.commit()
    sube({k: v for k, v in local.items() if k != "codigos_alternos"} | {"precio": 700})
    p = _prod(c, pid); assert p["precio"] == 700 and p["codigo"] == "7441000000012" and p["codigos_alternos"] == de_nube
    # una subida que no cambia el código no agrega nada, y un ítem nuevo de la instalación entra como siempre
    sube({**local, "precio": 750, "codigos_alternos": de_nube}, {**local, "id": pid + 2, "nombre": "Galleta Z", "codigo": "GAL-Z"})
    p = _prod(c, pid); assert p["precio"] == 750 and p["codigo"] == "7441000000012" and p["codigos_alternos"] == de_nube
    z = _prod(c, pid + 2); assert z["codigo"] == "GAL-Z" and z["codigos_alternos"] is None


def test_h4_una_impresora_usb_sin_nombre_no_manda_las_etiquetas_a_la_predeterminada(monkeypatch):
    """Sin nombre, el envío por USB iba a la impresora predeterminada de Windows (la de tiquetes o la de la oficina), con las órdenes de
    la impresora de etiquetas como texto."""
    from app import escpos
    for direccion in ("", "   ", None):
        with pytest.raises(ValueError, match="Indique el nombre de la impresora de etiquetas en Windows"):
            ei.trabajo_etiquetas(_trabajo(direccion=direccion))
    enviados = []
    monkeypatch.setattr(escpos, "enviar", lambda impresora, datos: enviados.append(impresora))
    with pytest.raises(ValueError, match="Indique el nombre de la impresora de etiquetas en Windows"):
        escpos.ejecutar("imprimir", {"nombre": "Etiquetas", "conexion": "usb", "direccion": ""}, {"etiquetas": _trabajo(direccion="")})
    assert enviados == []                                                                              # nada salió hacia ninguna impresora
    escpos.ejecutar("imprimir", {"conexion": "usb", "direccion": "3nStar LDT124"}, {"etiquetas": _trabajo(direccion="")})   # el nombre puede venir solo en «impresora»
    assert enviados == [{"conexion": "usb", "direccion": "3nStar LDT124"}]
    # la pantalla no deja guardar la impresora de etiquetas por USB sin su nombre
    cfg = _js("pages", "pos", "configuracion.js")
    assert "if (etq && f.conexion === 'usb' && !(f.direccion || '').trim()) return toast('Indique el nombre de la impresora de etiquetas en Windows" in cfg
    assert cfg.index("if (etq && f.conexion === 'usb' && !(f.direccion || '').trim())") < cfg.index("if (!mock.puedeGuardar()) return;\n      const reg = { ...f,")


def test_h5_en_el_pdf_las_barras_miden_puntos_enteros_de_la_impresora():
    """El módulo (la barra más angosta) del PDF es un número entero de puntos de una impresora de 203 por pulgada, de 1 a 4, como en el
    envío directo: con una fracción (50 × 30 daba 3,4 puntos) el controlador sacaba unas barras de 3 puntos y otras de 4."""
    from pypdf import PdfReader
    punto = 72 / 203                                                 # un punto de la impresora, en puntos del PDF
    fuentes = [((f, m), a, h) for f, m, a, h in ei.FUENTES_TSPL]
    vistos = {}
    for ancho, alto in ei.MEDIDAS + ((20, 15), (110, 160), (45.5, 28)):
        for codigo in ("2000000001234", "TOR-38X2", "123456", "ABCDEFGHIJ-KLMNOPQRS"):
            try:
                pdf = etiquetas.pdf_etiquetas([{"nombre": "Café molido", "codigo": codigo, "precio": "", "copias": 1}], ancho, alto)
            except ValueError as ex:
                assert "no cabe en una etiqueta" in str(ex) and codigo == "ABCDEFGHIJ-KLMNOPQRS" and ancho <= 30, (ancho, alto, codigo)
                continue
            barras, _ = _geometria(PdfReader(io.BytesIO(pdf)).pages[0])
            anchos = [(b[1] - b[0]) / punto for b in barras]
            n = round(min(anchos))
            assert 1 <= n <= 4 and all(abs(a - round(a)) < 0.01 and round(a) % n == 0 for a in anchos), (ancho, alto, codigo, sorted(set(anchos)))
            x0, x1 = min(b[0] for b in barras), max(b[1] for b in barras)
            assert x0 >= 10 * n * punto - 0.01 and ancho * PT_MM - x1 >= 10 * n * punto - 0.01, (ancho, alto, codigo)     # con su zona quieta
            vistos[(ancho, alto, codigo)] = n
            if codigo == "2000000001234" and (ancho, alto) in ei.MEDIDAS:                              # el mismo módulo que el envío directo
                assert n == ei.plan_etiqueta("", codigo, "", ancho, alto, 203, fuentes)["n"], (ancho, alto)
    assert set(vistos.values()) == {1, 2, 3, 4}
    assert vistos[(50, 30, "2000000001234")] == 3 and vistos[(30, 20, "2000000001234")] == 2 and vistos[(20, 15, "2000000001234")] == 1 and vistos[(100, 50, "2000000001234")] == 4


def test_h6_si_el_navegador_bloquea_la_ventana_del_pdf_se_avisa(tmp_path):
    """«Imprimir» abre el PDF en una ventana nueva después de varias esperas; si para entonces el navegador la bloquea (window.open
    devuelve null), abrirArchivo lo dice en vez de callar: los cuadros lo muestran con su aviso de error."""
    r = _node(tmp_path, """
const abiertos = [], clics = [];
let ventana = {};
globalThis.localStorage = { getItem: () => 'tok', setItem() {}, removeItem() {} };
globalThis.fetch = async () => ({ ok: true, status: 200, blob: async () => ({}) });
URL.createObjectURL = () => 'blob:prueba'; URL.revokeObjectURL = () => {};
const { abrirArchivo } = await import('./js/api.js');
globalThis.setTimeout = () => 0;                                   // el que suelta el archivo al minuto: no hace falta esperarlo
globalThis.window = { open: (u, t) => { abiertos.push([u, t]); return ventana; } };
globalThis.document = { createElement: () => ({ click() { clics.push(this.download); } }) };
const out = {};
await abrirArchivo('/api/productos/etiquetas', null, { items: [] }); out.abre = abiertos.slice();
await abrirArchivo('/api/productos/etiquetas', 'etiquetas.pdf', { items: [] }); out.descarga = clics.slice(); out.ventanas = abiertos.length;
ventana = null;                                                      // el navegador bloquea la ventana nueva
try { await abrirArchivo('/api/productos/etiquetas', null, { items: [] }); out.bloqueada = 'sin aviso'; } catch (e) { out.bloqueada = e.message; }
await abrirArchivo('/api/productos/etiquetas', 'etiquetas.pdf', { items: [] }); out.descargas = clics.length;   // descargar no abre ventana: sigue igual
console.log(JSON.stringify(out));
""", archivos=(("api.js",),), falsos={"vendor/vue.esm-browser.prod.min.js": "export const reactive = x => x;\n"})
    assert r["abre"] == [["blob:prueba", "_blank"]] and r["descarga"] == ["etiquetas.pdf"] and r["ventanas"] == 1 and r["descargas"] == 2
    assert r["bloqueada"] == "El navegador bloqueó la ventana del archivo: use el botón de descargar, o permita las ventanas emergentes de este sitio y vuelva a intentarlo"
    # los dos lugares que abren el PDF de etiquetas piden que, si la ventana se bloquea, el archivo ya bajado quede en las descargas
    # (tests/test_424_pulido.py, U14) y siguen mostrando cualquier otro error con su aviso
    dlg = _js("pages", "inventario", "_etiquetas-dialogos.js"); cfg = _js("pages", "pos", "configuracion.js")
    assert "...(imp && +imp.dpi ? { dpi: +imp.dpi } : {}) }, 'etiquetas.pdf');\n        if (abierto === 'descargado') toast('El navegador no dejó abrir la ventana: el PDF quedó en sus descargas');\n      } catch (e) { toast(e.message, 'err'); }" in dlg
    assert "...(+i.dpi ? { dpi: +i.dpi } : {}) }, 'etiquetas.pdf') === 'descargado') toast('El navegador no dejó abrir la ventana: el PDF quedó en sus descargas'); } catch (e) { toast(e.message, 'err'); }" in cfg


def test_h7_el_cuadro_de_etiquetas_avisa_de_los_codigos_repetidos(tmp_path):
    """Un código que ya tienen dos ítems (de antes de la regla): la caja toma el primero que encuentra, así que la etiqueta de uno puede
    vender el otro. El cuadro de etiquetas lo avisa con los nombres."""
    r = _node(tmp_path, """
import { conCodigoRepetido } from './js/pages/inventario/_etiquetas.js';
const productos = [{ id: 1, nombre: 'Coca 600 ml', codigo: '7501055300846' }, { id: 2, nombre: 'Coca 3 L', codigo: ' 7501055300846 ' }, { id: 3, nombre: 'Pan', codigo: 'PAN-1' },
  { id: 4, nombre: 'Queso', codigo: 'que-1' }, { id: 5, nombre: 'Queso viejo', codigo: 'QUE-1' }, { id: 6, nombre: 'Sin código', codigo: null }, { id: 7, nombre: 'Otro sin', codigo: '' },
  { id: 8, nombre: 'Leche', codigo: 'LEC-2', codigos_alternos: 'PAN-1' }];
const item = id => { const p = productos.find(x => x.id === id); return { id: p.id, nombre: p.nombre, codigo: String(p.codigo || '').trim(), copias: 1 }; };
console.log(JSON.stringify({ uno: conCodigoRepetido([item(2), item(3)], productos), varios: conCodigoRepetido([1, 2, 3, 4, 6, 7, 8].map(item), productos).map(x => [x.id, x.otro]),
  ninguno: conCodigoRepetido([item(3), item(6), item(8)], productos), vacio: [conCodigoRepetido(null, productos), conCodigoRepetido([item(1)], null)] }));
""")
    assert r["uno"] == [{"id": 2, "nombre": "Coca 3 L", "codigo": "7501055300846", "otro": "Coca 600 ml"}]
    assert r["varios"] == [[1, "Coca 3 L"], [2, "Coca 600 ml"], [4, "Queso viejo"]]                    # sin distinguir mayúsculas ni espacios; sin código no cuenta
    assert r["ninguno"] == [] and r["vacio"] == [[], []]                                               # el código alterno de otro no es un repetido: gana el código
    dlg = _js("pages", "inventario", "_etiquetas-dialogos.js")
    assert "const r = conCodigoRepetido(this.conCopias, store.productos); if (!r.length) return '';" in dlg
    assert "'«' + r[0].nombre + '» tiene el mismo código que otro ítem («' + r[0].otro + '»)'" in dlg and "r.length + ' productos tienen el mismo código que otro ítem ('" in dlg
    assert "': la caja toma el primero que encuentra, así que la etiqueta puede vender el otro. Cambie el código antes de imprimir.'" in dlg
    assert '<div class="alert warn" v-if="avisoRepetidos" style="margin:10px 0 0">{{avisoRepetidos}}</div>' in dlg
