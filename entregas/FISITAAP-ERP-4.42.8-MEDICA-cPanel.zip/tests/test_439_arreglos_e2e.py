# -*- coding: utf-8 -*-
"""4.39, arreglos hechos DESPUÉS de la primera prueba de punta a punta (16 nov 2026). Cada punto tiene al menos una prueba que falla con el
código de antes del arreglo:

1. La ventana «Pedidos en línea» de la caja: tabla `tbl tbl-ventas`, celdas con `data-l` y la última `acciones-venta`; ui.css la muestra
   como tarjeta en el teléfono (a 375 px los botones quedaban fuera de la pantalla). Prueba de texto.
2. El contador del botón «🌐 Pedidos web»: aceptar o cancelar el único «nuevo» lo deja en 0 al instante (programa y web); si `online` cambió
   mientras se esperaba (revisarOnline) no se descuenta otra vez; si el pedido no era «nuevo», tampoco. 4.39 (duodécima vuelta): en ese caso
   se vuelve a leer el resumen una vez (esa consulta pudo contar todavía el pedido; ver tests/test_439_duodecima_vuelta.py).
3. En el programa, «Imprimir comanda» desde «Ver pedido» cierra el resumen; si la API falla, el resumen sigue abierto.
4. `cuentaRapidaGuardada`: tabla de verdad con la computada real.
5. `emitirCobro` real en Node: la cuenta guardada sin mesa manda su comanda una sola vez al cobrar; con mesa o con todo enviado, no.
   4.39 (segunda vuelta, R1): los pedidos ya no se excluyen; el pedido en línea real (platos enviados por pedidos.a_caja y el envío sin
   destino) no manda nada, y el plato que la cajera le agrega sí sale a cocina, una vez. El reclamo del cobro va antes de la comanda (H2).
6. La vista después de cobrar (vistaTrasCobro real de _datos.js y el cálculo nuevo de `rapida` extraído de caja.js).
7. GET /api/pedidos trae «comprobante» («Tiquete 0000000123» o «») con una sola consulta filtrada por empresa; y las dos pantallas de
   Ventas en línea lo muestran (data-comprobante).
Nada va a una impresora, a la red ni a un servidor de verdad: la API, el agente y las ventanas son funciones de la prueba. Solo @example.test."""
import json
import re
import uuid
from datetime import datetime, timezone

import pytest
from sqlmodel import Session

from app.db import Documento, engine_empresa
from tests.test_425_ultimos_pantallas import JS, _js, _tramo
from tests.test_431_misma_mesa_pantallas import _linea
from tests.test_432_caja_pedidos_web import _caja, _computadas, _metodos, _ventana
from tests.test_439_atras_plano import _correr as _correr_simple
from tests.test_439_cobro_venta_rapida import CASADO, POSTRE, _correr_439
from tests.test_439_pedidos_caja import _correr
from tests.test_exoneraciones import api  # noqa: F401  (fixture)
from tests.test_429_pedido_web_comanda import _eid, _montar_negocio, _pedido

CSS = JS.parent / "ui.css"


# ================================================================================================================ 1. la ventana en el teléfono
def test_ventana_pedidos_en_linea_es_tarjeta_en_el_telefono():
    v = _tramo(_caja(), '<Modal v-if="panelWeb"', '<Modal v-if="habCargo"')
    assert '<table class="tbl tbl-ventas" v-else-if="filasWeb.length">' in v, "la tabla de la ventana debe ser tbl-ventas (tarjeta en el teléfono)"
    for etiqueta in ("Hora", "Entrega", "Total", "Estado"):
        assert 'data-l="' + etiqueta + '"' in v, etiqueta
    assert '<td class="acciones-venta"><div class="row"' in v, "los botones van en la última celda, acciones-venta"
    for boton in ("Ver pedido", "Imprimir comanda", "Abrir para cobrar"):
        assert boton in v, boton
    css = CSS.read_text(encoding="utf-8")
    regla = _tramo(css, "@media (max-width:700px){.tbl-ventas thead{display:none}", "}}") + "}}"
    assert ".tbl-ventas,.tbl-ventas tbody,.tbl-ventas tr,.tbl-ventas td{display:block;width:100%}" in regla
    assert ".tbl-ventas td.acciones-venta .btn{flex:1" in regla and ".tbl-ventas td[data-l]::before{content:attr(data-l)" in regla


# ================================================================================================================ 2 y 3. contador y resumen
GUION_CONTADOR = r"""
const Q = { llamadas: [], toasts: [], sincs: [], lista: [], falla: null, hook: null, relee: 0 };
const sesion = { empresaInfo: {}, tipo: 'restaurante', tieneModulo: x => x === 'pedidos_online' };
const api = async (url, op) => {
  Q.llamadas.push([url, op ? op.method : 'GET']);
  if (url === '/api/pedidos') return Q.lista;
  if (/^\/api\/pedidos\/\d+\/estado$/.test(url)) { if (Q.hook) Q.hook(); if (Q.falla) throw new Error(Q.falla); return { id: 1, numero: 41, estado: op.body.estado, cuenta_espera_id: null }; }
  throw new Error('ruta ' + url);
};
const toast = (m, t) => Q.toasts.push([m, t]);
globalThis.uuid = () => 'u';
const C = new Function('sesion', 'api', 'toast', 'return { computed: {' + %(comp)s + '}, methods: {' + %(met)s + '} };')(sesion, api, toast);
function caja() {
  const vm = Object.assign({ online: { nuevos: 1, ultimo: 1, sinVer: 0 }, panelWeb: null, esperaCaja: [], pago: null, cobrando: false, cobroParcial: null, esRestaurante: true,
    esperaId: null, lineas: [], nombreEspera: '', nota: '', idem: 'i', sincronizar() { Q.sincs.push(1); }, volverAMesas() {}, recuperar() {},
    /* 4.39 (duodécima vuelta): si `online` cambió mientras se esperaba, se vuelve a leer el resumen (aquí solo se anota: el número no cambia) */
    revisarOnline() { Q.relee++; } });
  for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
  return vm;
}
const pasar = async () => { for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r)); };
const ACEP = { aceptarComo: async () => { if (Q.hook) Q.hook(); return true; } };   /* la web: el PUT lo hace el aceptador */
const o = {};
/* un caso: lado ('prog' | 'web'), accion ('aceptar' | 'cancelar'), estado del pedido, mover (revisarOnline reemplaza `online` mientras se espera), falla */
async function caso(lado, accion, estado, mover, falla) {
  sesion.empresaInfo = lado === 'prog' ? { es_local: true, pedidos_programa: true } : {};
  Q.llamadas = []; Q.toasts = []; Q.falla = falla || null; Q.hook = null; Q.relee = 0;
  Q.lista = [{ id: 1, numero: 41, estado }];
  const vm = caja(); vm.cargarAceptador = async () => { vm._acep = ACEP; return ACEP; }; vm._acep = ACEP;
  vm.abrirPanelWeb(); await pasar(); vm.online = { nuevos: 1, ultimo: 1, sinVer: 0 };       // abrir la ventana no toca el contador de la prueba
  if (mover) Q.hook = () => { vm.online = { nuevos: 1, ultimo: 2, sinVer: 0 }; };           // revisarOnline trajo otra consulta: ya cuenta lo que queda
  const p = vm.panelWeb.lista[0];
  if (accion === 'aceptar') { vm.verPedidoWeb(p); await vm.imprimirComandaWeb(p); }
  else { vm.verPedidoWeb(p); vm.abrirCancelarWeb(); vm.panelWeb.cancelar.motivo = 'El cliente llamó para cancelar'; await vm.cancelarWeb(p); }
  return { nuevos: vm.online.nuevos, ver: vm.panelWeb ? vm.panelWeb.ver : 'cerrada', toasts: Q.toasts.map(t => t[1]), relee: Q.relee };
}
for (const lado of ['prog', 'web']) {
  for (const accion of ['aceptar', 'cancelar']) {
    o[lado + '_' + accion] = {
      nuevo: await caso(lado, accion, 'nuevo'),
      cambio: await caso(lado, accion, 'nuevo', true),
      noNuevo: await caso(lado, accion, 'confirmado'),
    };
  }
}
o.prog_falla = await caso('prog', 'aceptar', 'nuevo', false, 'sin conexión');
o.web_ver = await caso('web', 'aceptar', 'nuevo');
console.log(JSON.stringify(o));
"""


def test_el_contador_del_boton_baja_al_aceptar_o_cancelar_el_nuevo(tmp_path):
    o = _correr(tmp_path, GUION_CONTADOR % {"comp": json.dumps(_computadas()), "met": json.dumps(_metodos())})
    for lado in ("prog", "web"):
        for accion in ("aceptar", "cancelar"):
            c = o[lado + "_" + accion]
            assert c["nuevo"]["nuevos"] == 0, (lado, accion, c)                 # antes: seguía en 1 (rojo) hasta 30 s
            assert c["cambio"]["nuevos"] == 1, (lado, accion, c)                # online cambió mientras se esperaba: no se descuenta otra vez
            assert c["noNuevo"]["nuevos"] == 1, (lado, accion, c)               # no era «nuevo»: no se descuenta
            # 4.39 (duodécima vuelta): si online cambió mientras se esperaba, esa consulta pudo contar todavía este pedido: se vuelve a leer el resumen una
            # vez (sin esperar; el número lo pone esa lectura, ver tests/test_439_duodecima_vuelta.py); si no cambió o no era «nuevo», no se lee otra vez
            assert c["cambio"]["relee"] == 1 and c["nuevo"]["relee"] == 0 and c["noNuevo"]["relee"] == 0, (lado, accion, c)
    # 3. el resumen: aceptado desde «Ver pedido» se cierra (en el programa y en la web); si la API falla, sigue abierto
    assert o["prog_aceptar"]["nuevo"]["ver"] is None and o["web_ver"]["ver"] is None, o
    assert o["prog_falla"]["ver"] == 1 and o["prog_falla"]["nuevos"] == 1 and o["prog_falla"]["toasts"] == ["err"], o["prog_falla"]
    assert o["prog_falla"]["relee"] == 0, o["prog_falla"]                    # 4.39 (duodécima vuelta): si falla, tampoco se vuelve a leer
    assert o["prog_cancelar"]["nuevo"]["ver"] is None


# ================================================================================================================ 4. cuentaRapidaGuardada
GUION_TABLA = r"""
const f = (new Function('return {' + %(src)s + '};'))().cuentaRapidaGuardada;
const base = () => ({ esRestaurante: true, vista: 'venta', mesaActual: null, esperaId: 5, cobroParcial: null, cuentaActual: { id: 5, nombre: 'Cuenta 5', lineas: [] } });
const con = (cambios, cuenta) => { const vm = { ...base(), ...cambios }; if (cuenta) vm.cuentaActual = { ...vm.cuentaActual, ...cuenta }; return f.call(vm); };
console.log(JSON.stringify({
  guardada: con({}), conMesaId: con({}, { mesa_id: 3 }), conMesasIds: con({}, { mesas_ids: [3, 4] }), mesasIdsVacio: con({}, { mesas_ids: [] }),
  pedido: con({}, { pedido: 9 }), pedidoId: con({}, { pedido_id: 9 }), parcial: con({ cobroParcial: { cuentaId: 5, parte: 1, de: 2 } }),
  conMesaActual: con({ mesaActual: { id: 3 } }), mostrador: con({ esRestaurante: false }), vistaMesas: con({ vista: 'mesas' }),
  sinEsperaId: con({ esperaId: null }), sinCuenta: con({ cuentaActual: null }) }));
"""


def test_cuenta_rapida_guardada_tabla_de_verdad(tmp_path):
    src = _linea(_caja(), "cuentaRapidaGuardada() {")
    o = _correr_simple(tmp_path, GUION_TABLA % {"src": json.dumps(src)})
    assert o["guardada"] is True and o["mesasIdsVacio"] is True, o
    # 4.39 (segunda vuelta, R1): la regla queda «toda cuenta guardada sin mesa manda a cocina, al cobrarla, sus platos sin enviar». Ya no
    # excluye los pedidos (c.pedido, c.pedido_id): el pedido para llevar o Express hecho en la caja nunca mandaba sus platos sin enviar, y
    # el pedido en línea llega de pedidos.a_caja con todo enviado (el envío no tiene destino, H1). Y la cuenta que ya no está en la lista
    # (cuentaActual null: otro equipo la cobró o la cerró) también entra, para que el cobro termine en cobroDeCuentaCerrada sin cobrar
    for k in ("pedido", "pedidoId", "sinCuenta"):
        assert o[k] is True, (k, o)
    for k in ("conMesaId", "conMesasIds", "parcial", "conMesaActual", "mostrador", "vistaMesas", "sinEsperaId"):
        assert o[k] is False, (k, o)


# ================================================================================================================ 5. emitirCobro con la cuenta guardada
def _casos_cobro() -> str:
    k = _caja()
    src = _linea(k, "cuentaRapidaGuardada() {")
    destino = _linea(k, "destinoDe(l) {")
    return """
// la computada real, con el resto de la caja del arnés (esRestaurante, cuentaActual, esperaId, mesaActual y vista ya están)
const RG = (new Function('return {' + @SRC@ + '};'))().cuentaRapidaGuardada;
// 4.39 (segunda vuelta): destinoDe real de caja.js (un plato va a la Cocina; el «Envío a domicilio», sin producto y servicio, a ninguna)
const DST = (new Function('mock', 'impresoraDe', 'return {' + @DST@ + '};'))({ get: () => ({}) }, () => COCINA).destinoDe;
// el «Envío a domicilio» como lo agrega app/pedidos.py (a_caja): sin producto, servicio, sin enviar y ronda 0
const ENVIO = () => ({ producto_id: null, detalle: 'Envío a domicilio', cantidad: 1, precio_unitario: 1000, tarifa: 13, descuento: 0, descuento_pct: 0, es_servicio: true, nota: '', enviado: null, ronda: 0 });
const IMPRESOS = [];   // lo que llegó a la Cocina en cada comanda
// la cuenta guardada con «Guardar y nueva venta», recuperada después (cargarCuenta pone rapida = false); su Casado ya salió a cocina.
// `envio`: la cuenta trae además el envío guardado (un pedido a domicilio)
async function guardada(cambios, todoEnviado, envio) {
  reiniciarCobro(); reiniciar(); IMPRESOS.length = 0;
  const a = venta(await equipo());
  Object.defineProperty(a, 'cuentaRapidaGuardada', { get() { return RG.call(this); }, configurable: true });
  a.productos = []; a.cats = []; a.destinoDe = DST.bind(a);
  a.cfg.imprimir_comanda = true; a.imprimirComanda = g => { const ls = []; for (const x of Object.values(g)) for (const l of x.ls) ls.push(l.detalle + '×' + l.cantidad); IMPRESOS.push(ls.sort()); };
  a.lineas.push({ ...CASADO(), enviado: new Date(Date.now() - 60000).toISOString(), ronda: 1 });
  if (envio) a.lineas.push(ENVIO());
  a.persistirCuenta(); await a.A.mock.guardarTodo();
  const id = a.esperaId;
  a.lineas = []; a.esperaId = null; a.cargarCuenta(a.espera.find(x => x.id === id));       // recuperada: rapida = false
  a.vista = 'venta'; a.mesaActual = null;
  if (!todoEnviado) a.lineas.push(POSTRE());
  a._cambios = cambios || {};
  return a;
}
const resumen = a => ({ hechos: hechos(), comandas: comandas(a), impresos: IMPRESOS.slice(), orden: orden(), avisos: deEste(a), rapida: a.rapida, guardada: a.cuentaRapidaGuardada });
const cobrarla = async a => { await a.abrirPago(); Object.assign(a.cuentaActual, a._cambios); await a.cobrar();   /* la cuenta ya tiene su mesa o su pedido */ await hastaLibre(); await a.A.mock.guardarTodo(); return resumen(a); };
const EN_LINEA = { pedido: 'domicilio', pedido_id: 9, pedido_numero: 41, canal: 'online' };
out.recuperada = await cobrarla(await guardada());
out.conMesa = await cobrarla(await guardada({ mesa_id: 3 }));
out.pedido = await cobrarla(await guardada(EN_LINEA, true, true));
out.pedidoConPlato = await cobrarla(await guardada(EN_LINEA, false, true));
out.todoEnviado = await cobrarla(await guardada({}, true));
""".replace("@SRC@", json.dumps(src)).replace("@DST@", json.dumps(destino))


def test_cobrar_cuenta_guardada_sin_mesa_manda_la_comanda_una_vez_en_node(tmp_path):
    r = _correr_439(tmp_path, _casos_cobro())
    x = r["recuperada"]
    assert x["rapida"] is False and x["guardada"] in (True, False), r                       # (tras cobrar la caja la deja como venta rápida: ver más abajo)
    assert x["comandas"] == ["Comanda 2 enviada a Cocina"] and x["impresos"] == [["Postre×1"]], r   # antes: ninguna, el plato se cobraba y no llegaba a cocina
    assert len(x["hechos"]) == 1 and x["hechos"][0][1] == CASADO + POSTRE and x["hechos"][0][2] == ["Casado×1", "Postre×1"], r   # se cobra la cuenta entera
    assert x["orden"] == ["/api/pos/cobro/reclamar", "/api/comprobantes", "/api/pos/cobro/soltar", "/api/pos/cobro/soltar"], r   # un reclamo, una emisión (H2: el reclamo va ANTES de la comanda)
    assert x["avisos"] == [], r
    m = r["conMesa"]
    assert m["comandas"] == [] and len(m["hechos"]) == 1 and m["hechos"][0][1] == CASADO + POSTRE, r   # una cuenta de mesa no manda comanda al cobrar
    # 4.39 (segunda vuelta, R1): el fixture de antes era irreal (un pedido en línea con un Postre sin enviar: pedidos.a_caja marca todos sus
    # platos como enviados). El caso real: los platos enviados y el «Envío a domicilio» sin enviar. No sale comanda (ni del envío) y se
    # cobra una vez con el envío
    envio = 1130.0                                                                          # 1000 + 13 % de IVA
    p = r["pedido"]
    assert p["comandas"] == [] and p["impresos"] == [] and p["avisos"] == [], r
    assert len(p["hechos"]) == 1 and p["hechos"][0][1] == CASADO + envio and p["hechos"][0][2] == ["Casado×1", "Envío a domicilio×1"], r
    # la cajera agregó un Postre a la cuenta del pedido: ese plato sí sale a cocina al cobrar (antes de R1 se cobraba y nunca llegaba), una vez
    pc = r["pedidoConPlato"]
    assert pc["comandas"] == ["Comanda 2 enviada a Cocina"] and pc["impresos"] == [["Postre×1"]] and pc["avisos"] == [], r   # el envío no va a cocina
    assert len(pc["hechos"]) == 1 and pc["hechos"][0][1] == CASADO + envio + POSTRE, r
    assert pc["hechos"][0][2] == ["Casado×1", "Envío a domicilio×1", "Postre×1"], r
    assert pc["orden"] == ["/api/pos/cobro/reclamar", "/api/comprobantes", "/api/pos/cobro/soltar", "/api/pos/cobro/soltar"], r
    e = r["todoEnviado"]
    assert e["comandas"] == [] and len(e["hechos"]) == 1 and e["hechos"][0][1] == CASADO, r   # todo estaba enviado: no hay comanda nueva


def test_la_condicion_de_la_comanda_al_cobrar_incluye_la_cuenta_guardada():
    k = _caja()
    i = k.index("async emitirCobro(otra) {")
    cuerpo = k[i:k.index("\n    },\n", i)]
    assert "if (this.esRestaurante && (this.esVentaRapida || this.cuentaRapidaGuardada) && !this.cobroParcial && this.lineas.some(" in cuerpo
    # la historia de la 4.37 (cobro doble): detrás de las guardas de la 4.39. Revisión de los arreglos: una cuenta que ya estaba en el servidor
    # pide su cobro ANTES de la comanda (si dos equipos la cobran a la vez, la comanda sale solo del que ganó); la venta rápida nueva, como antes
    # 4.39 (segunda vuelta, R2): el bloque ya no es de una línea: después de ganar el cobro se trae la lista (refrescar), se revisa si la cuenta
    # sigue, se junta lo de otro equipo (persistirCuenta + guardarTodo) y se compara (cobroCambiado); recién después sale la comanda
    i_abre = cuerpo.index("if (reclamar && mismoId && !alta0) {")
    i_pedido = cuerpo.index("rcPedido = true; try { rc = await this.reclamarCobro(lineasCobradas); } catch { rc = null; } if (rc && rc.ocupada) return this.cobroOcupado(rc);")
    i_refresca = cuerpo.index("mock.refrescar(['pos_espera'])")
    i_cerrada2 = cuerpo.index("if (!enEspera().some(v => v.id === esperaId)) { if (rc && rc.clave) this.soltarCobro(rc, false); return this.cobroDeCuentaCerrada(); }")
    i_junta = cuerpo.index("try { this.persistirCuenta(); await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]); }")
    i_cambio0 = cuerpo.index("const cambio0 = this.cobroCambiado(esperaId, lineasCobradas, total, alta0); if (cambio0) { if (rc && rc.clave) this.soltarCobro(rc, false); return cambio0; }")
    i_comanda = cuerpo.index("this.enviarComanda()")
    i_cambio = cuerpo.index("const cambio = this.cobroCambiado(esperaId, lineasCobradas, total, alta0);")
    assert cuerpo.index("this.cobroDeCuentaCerrada()") < cuerpo.index("const alta0 = ") < i_abre < i_pedido < i_refresca < i_cerrada2 < i_junta < i_cambio0 < i_comanda < i_cambio
    assert "if (cambio) { if (rc && rc.clave) this.soltarCobro(rc, false); return cambio; }" in cuerpo   # el cobro pedido queda libre si no se emite
    assert i_cambio < cuerpo.index("if (reclamar && !rcPedido) { try { rc = await this.reclamarCobro(lineasCobradas); }")
    c = _linea(k, "cuentaRapidaGuardada() {")
    # 4.39 (segunda vuelta, R1): ya no excluye los pedidos (toda cuenta guardada sin mesa manda sus platos sin enviar al cobrarla)
    assert "c.pedido" not in c and "pedido_id" not in c
    assert "!(c && (c.mesa_id || (Array.isArray(c.mesas_ids) && c.mesas_ids.length)))" in c and "!this.cobroParcial" in c and "!this.mesaActual" in c and "this.esperaId" in c


# ================================================================================================================ 6. la vista después de cobrar
GUION_VISTA = r"""
import { readFileSync } from 'node:fs';
const datos = readFileSync(process.argv[2], 'utf8');
const trozos = [/export const FORMAS_DECO[^\n]*\n/, /export function esDeco[^\n]*\n/, /export function vistaInicial[^]*?\n}\n/, /export function vistaTrasCobro[^]*?\n}\n/, /export function sinMesas[^\n]*\n/]
  .map(re => { const m = re.exec(datos); if (!m) throw new Error('falta ' + re); return m[0].replace(/^export /, ''); });
const { vistaTrasCobro } = new Function(trozos.join('\n') + '\nreturn { vistaTrasCobro };')();
const EXPR = %(expr)s, TRAS = %(tras)s;
const esVentaRapida = (new Function('return {' + %(evr)s + '};'))().esVentaRapida;
const calcular = new Function('vistaTrasCobro', 'cc', 'return ' + EXPR + ';');
const despues = new Function('vistaTrasCobro', 'rapida', TRAS);
const MESA = { id: 1, nombre: 'M1', forma: 'cuadrada' };
function caso(cfg, cuenta, mesaActual, rapidaAntes) {
  const vm = { cfg, esRestaurante: cfg.modo === 'restaurante', vista: 'venta', rapida: !!rapidaAntes, mesaActual: mesaActual || null, cuentaActual: cuenta };
  Object.defineProperty(vm, 'esVentaRapida', { get() { return esVentaRapida.call(this); } });
  const rapida = calcular.call(vm, vistaTrasCobro, cuenta);
  vm.mesaActual = null;                                                                    // emitirCobro limpia la venta antes de elegir la vista
  despues.call(vm, vistaTrasCobro, rapida);
  return [vm.vista, vm.rapida];
}
const rest = (inicio, mesas) => ({ modo: 'restaurante', inicio, mesas });
const o = {
  recuperada: caso(rest('venta', [MESA]), { id: 5 }),
  pedido: caso(rest('venta', [MESA]), { id: 6, pedido_id: 9 }),
  conMesaActual: caso(rest('venta', [MESA]), { id: 7, mesa_id: 1 }, MESA),
  mesaIdSinMesaActual: caso(rest('venta', [MESA]), { id: 7, mesa_id: 1 }),
  variasMesas: caso(rest('venta', [MESA]), { id: 8, mesas_ids: [1, 2] }),
  ventaRapida: caso(rest('venta', [MESA]), null, null, true),
  inicioMesas_recuperada: caso(rest('mesas', [MESA]), { id: 5 }),
  inicioMesas_rapida: caso(rest('mesas', [MESA]), null, null, true),
  inicioMesas_mesa: caso(rest('mesas', [MESA]), { id: 7, mesa_id: 1 }, MESA),
  sinMesas: caso(rest('mesas', []), { id: 5 }),
  sinMesas_venta: caso(rest('venta', []), { id: 5 }),
  mostrador: caso({ modo: 'mostrador', mesas: [] }, { id: 5 }),
};
console.log(JSON.stringify(o));
"""


def test_vista_despues_de_cobrar_una_cuenta_guardada_o_un_pedido(tmp_path):
    k = _caja()
    cuerpo = k[k.index("async emitirCobro(otra) {"):]
    cuerpo = cuerpo[:cuerpo.index("\n    },\n")]
    expr = re.search(r"rapida = (this\.esVentaRapida \|\| \(this\.esRestaurante && !this\.mesaActual && !\(cc && .*?\)\)\)\));", cuerpo)
    assert expr, "falta el cálculo nuevo de rapida en emitirCobro"
    tras = re.search(r"(if \(this\.esRestaurante\) this\.vista = vistaTrasCobro\(this\.cfg, rapida\);)[^\n]*\n\s*(if \(this\.esRestaurante && this\.vista === 'venta'\) this\.rapida = true;)", cuerpo)
    assert tras, "falta «si la vista quedó venta, rapida = true»"
    r = _correr_simple_con_archivo(tmp_path, GUION_VISTA % {"expr": json.dumps(expr.group(1)), "tras": json.dumps(tras.group(1) + "\n" + tras.group(2)),
                                                               "evr": json.dumps(_linea(k, "esVentaRapida() {"))})
    # caja con mesas e inicio «venta»: lo que no es de una mesa sigue en la venta rápida; lo de una mesa va al plano
    assert r["recuperada"] == ["venta", True], r                  # antes: ['mesas', False]
    assert r["pedido"] == ["venta", True], r
    assert r["ventaRapida"] == ["venta", True], r
    assert r["conMesaActual"] == ["mesas", False] and r["mesaIdSinMesaActual"] == ["mesas", False] and r["variasMesas"] == ["mesas", False], r
    # «Al entrar» = Mesas: siempre el plano
    assert r["inicioMesas_recuperada"] == ["mesas", False] and r["inicioMesas_mesa"] == ["mesas", False], r
    assert r["inicioMesas_rapida"][0] == "mesas", r                  # (rapida queda como estaba: solo cuenta en la vista de venta)
    # sin mesas, la venta; mostrador, la venta
    assert r["sinMesas"][0] == "venta" and r["sinMesas_venta"][0] == "venta" and r["mostrador"][0] == "venta", r
    assert r["sinMesas"][1] is True and r["sinMesas_venta"][1] is True, r


def _correr_simple_con_archivo(tmp_path, guion):
    import subprocess
    from tests.test_425_ultimos_pantallas import _nodo
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    (tmp_path / "vista.mjs").write_text(guion, encoding="utf-8")
    p = subprocess.run([node, "vista.mjs", str(JS / "pages" / "pos" / "_datos.js")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert p.returncode == 0, p.stderr[-3000:]
    return json.loads(p.stdout)


def test_las_tres_salidas_de_cobro_recalculan_la_vista_igual():
    k = _caja()
    assert k.count("if (this.esRestaurante && this.vista === 'venta') this.rapida = true;") == 3      # cobrar, habitación y venta sin conexión
    assert k.count("rapida = this.esVentaRapida || (this.esRestaurante && !this.mesaActual && !(") == 2  # emitirCobro y cargarAHabitacion
    assert "const rapida = !!c.rapida;" in k                                                              # sin conexión: viaja en la cola
    assert "rapida: " in _tramo(k, "ventaSinConexion(", "\n") or "rapida" in k[k.index("this.ventaSinConexion({"):k.index("this.ventaSinConexion({") + 1500]


# ================================================================================================================ 7. comprobante en la API y en las pantallas
def _documento(eid, empresa_id, tipo="04", consecutivo="00100001040000000123"):
    with Session(engine_empresa(eid)) as s:
        d = Documento(empresa_id=empresa_id, tipo_documento=tipo, clave=(uuid.uuid4().hex * 2)[:50], consecutivo=consecutivo,
                      fecha_emision=datetime.now(timezone.utc).isoformat(), estado="interno", origen_sinc="3")
        s.add(d); s.commit(); s.refresh(d)
        return d.id


def _enlazar(eid, pid, documento_id):
    from app import pedidos
    with Session(engine_empresa(eid)) as s:
        p = s.get(pedidos.Pedido, pid); p.documento_id = documento_id; s.add(p); s.commit()


def test_api_pedidos_trae_el_comprobante(api):  # noqa: F811
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    con = _pedido(api, slug, a, b, tel="88880001")
    sin = _pedido(api, slug, a, b, tel="88880002")
    ajeno = _pedido(api, slug, a, b, tel="88880003")
    fe = _pedido(api, slug, a, b, tel="88880004")
    _enlazar(eid, con["id"], _documento(eid, eid))
    _enlazar(eid, ajeno["id"], _documento(eid, eid + 999))                                 # el documento es de otra empresa
    _enlazar(eid, fe["id"], _documento(eid, eid, tipo="01", consecutivo="00100001010000000456"))
    r = api.get("/api/pedidos")
    assert r.status_code == 200, r.text
    por_id = {p["id"]: p for p in r.json()}
    assert por_id[con["id"]]["comprobante"] == "Tiquete 0000000123", por_id[con["id"]]
    assert por_id[sin["id"]]["comprobante"] == ""
    assert por_id[ajeno["id"]]["comprobante"] == "", "un documento de otra empresa no aparece"
    assert por_id[fe["id"]]["comprobante"] == "Factura electrónica 0000000456"
    assert all("comprobante" in p for p in por_id.values())


def test_api_pedidos_comprobante_con_una_sola_consulta_a_documento(api):  # noqa: F811
    from sqlalchemy import event
    eid, slug, a, b = _montar_negocio(api, {"modo": "restaurante"})
    ids = [_pedido(api, slug, a, b, tel="8888100" + str(i))["id"] for i in range(3)]
    for n, i in enumerate(ids):
        _enlazar(eid, i, _documento(eid, eid, consecutivo="0010000104000000%04d" % (700 + n)))
    consultas = []
    eng = engine_empresa(eid)
    def espia(conn, cursor, sentencia, *args):
        if "FROM documento" in sentencia.replace('"', "").lower().replace("from documento", "FROM documento"):
            consultas.append(sentencia)
    event.listen(eng, "before_cursor_execute", espia)
    try:
        assert api.get("/api/pedidos").status_code == 200
    finally:
        event.remove(eng, "before_cursor_execute", espia)
    assert len(consultas) == 1, consultas


def test_las_pantallas_de_ventas_en_linea_muestran_el_comprobante():
    lista = _js("fis/pages/pedidos.js")
    assert """<small v-if="f.origen === 'web' && f.p.comprobante" data-comprobante>{{f.p.comprobante}}</small>""" in lista
    assert _tramo(lista, "<td>{{dinero(f.total)}}", "</td>").count("data-comprobante") == 1                 # en la columna Total
    det = _js("fis/pages/pedido.js")
    assert """<p v-if="p.comprobante" data-comprobante>Comprobante: <strong>{{p.comprobante}}</strong></p>""" in det
    assert det.count("data-comprobante") == 1
    srv = (JS.parent.parent / "pedidos.py").read_text(encoding="utf-8")
    assert 'o["comprobante"] = ' in srv and "Documento.empresa_id == eid, Documento.id.in_(con_doc)" in srv
