"""3.60: paquete de reportes del cierre del día del hotel: PDF guardado en la carpeta de la empresa, lista de fechas, descarga,
validaciones y permisos."""
import types

from fastapi.testclient import TestClient
from sqlmodel import Session, select

import pytest

from app import auth
from app.config import DATA_DIR
from app.db import Empresa, engine, init_db


@pytest.fixture(autouse=True)
def _sin_superadmin_al_final():
    yield
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-360@example.test")).first()
        if u:
            s.delete(u); s.commit()


def _cliente(rol="Administrador"):
    from app.main import app
    init_db()
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-360@example.test")).first()
        if not u:
            u = auth.Usuario(correo="sa-360@example.test", nombre="SA 360", password_hash=auth.hash_password("Clave-Segura-360-QA!"), es_superadmin=True)
            s.add(u); s.commit(); s.refresh(u)
        e = s.exec(select(Empresa).where(Empresa.nombre == "Hotel 360 QA")).first()
        if not e:
            e = Empresa(nombre="Hotel 360 QA", numero_id="3-101-360360", actividad="551001", otras_senas="Playa", correo="hotel360@example.test", ambiente="sandbox", tipo_negocio="hospitalidad")
            s.add(e); s.commit(); s.refresh(e)
        s.expunge(e)
        sa = types.SimpleNamespace(id=u.id, correo=u.correo, es_superadmin=rol == "Administrador", nombre="SA", mfa_activo=True)
    ctx = auth.Contexto(sa, e, rol)
    app.dependency_overrides[auth.superadmin] = lambda: sa
    app.dependency_overrides[auth.solo_usuario] = lambda: sa
    app.dependency_overrides[auth.contexto] = lambda: ctx
    return TestClient(app), e, app


CUERPO = {"fecha": "2026-11-02", "usuario": "recepcion@example.test", "notas": "Noche tranquila",
          "resumen": {"ocupadas": 4, "total": 10, "pct": 40, "cargos": 250.5, "pagos": 180, "adr": 62.6, "revpar": 25.05, "llegadas": 2, "salidas": 1, "en_casa": 4, "no_show": 0, "creadas": 1, "porC": {"hospedaje": 250.5}, "porM": {"Tarjeta": 180}},
          "pendientes": [{"k": "sucias", "t": "Habitaciones sucias", "n": 2}],
          "kpis": [{"t": "Ocupación", "v": "4 de 10 · 40 %"}, {"t": "Cargos del día", "v": "$250,50"}],
          "secciones": [{"titulo": "Llegadas de hoy y de mañana · 2 fila(s)", "columnas": [{"key": "numero", "label": "Reserva"}, {"key": "huesped", "label": "Huésped"}],
                         "filas": [{"numero": "R-0001", "huesped": "Ana Mora"}, {"numero": "R-0002", "huesped": "Luis Rojas"}], "totales": [{"t": "Reservas", "v": "2"}]},
                        {"titulo": "Pendientes al cerrar · 1", "columnas": [{"key": "punto", "label": "Punto"}, {"key": "n", "label": "Cantidad", "num": True}], "filas": [{"punto": "Habitaciones sucias", "n": "2"}], "totales": []}]}


def test_paquete_se_genera_guarda_lista_y_descarga():
    c, e, app = _cliente()
    try:
        r = c.post("/api/hotel/cierre-paquete", json=CUERPO)
        assert r.status_code == 200, r.text
        j = r.json()
        assert j["ok"] and j["archivo"] == "cierre_2026-11-02.pdf" and j["bytes"] > 1000
        assert j["correo"] is None and j["correo_error"] is None          # sin correo del cierre configurado no se intenta enviar
        p = DATA_DIR / "empresas" / str(e.id) / "hotel_cierres" / "cierre_2026-11-02.pdf"
        assert p.is_file() and p.read_bytes()[:4] == b"%PDF"

        assert c.get("/api/hotel/cierre-paquete").json()["fechas"] == ["2026-11-02"]
        d = c.get("/api/hotel/cierre-paquete/2026-11-02")
        assert d.status_code == 200 and d.headers["content-type"].startswith("application/pdf") and d.content[:4] == b"%PDF"

        # volver a cerrar el mismo día reemplaza el PDF (no se acumulan)
        assert c.post("/api/hotel/cierre-paquete", json=CUERPO).status_code == 200
        assert c.get("/api/hotel/cierre-paquete").json()["fechas"] == ["2026-11-02"]

        assert c.get("/api/hotel/cierre-paquete/2026-01-01").status_code == 404
        assert c.get("/api/hotel/cierre-paquete/..%2Fx").status_code == 404
        assert c.post("/api/hotel/cierre-paquete", json={**CUERPO, "fecha": "ayer"}).status_code == 400
        assert c.post("/api/hotel/cierre-paquete", json={**CUERPO, "secciones": [{"titulo": "x", "columnas": [], "filas": []}]}).status_code == 400
    finally:
        app.dependency_overrides.clear()


def test_paquete_sin_reportes_solo_resumen():
    c, e, app = _cliente()
    try:
        r = c.post("/api/hotel/cierre-paquete", json={**CUERPO, "fecha": "2026-11-01", "secciones": [], "kpis": []})
        assert r.status_code == 200 and r.json()["bytes"] > 500
        assert "2026-11-01" in c.get("/api/hotel/cierre-paquete").json()["fechas"]
    finally:
        app.dependency_overrides.clear()


def test_rol_de_lectura_no_cierra_pero_ve_los_paquetes():
    c, e, app = _cliente("Solo lectura")
    try:
        assert c.post("/api/hotel/cierre-paquete", json=CUERPO).status_code == 403
        assert c.get("/api/hotel/cierre-paquete").status_code == 200       # ver_todo
    finally:
        app.dependency_overrides.clear()
