"""4.21: una empresa que NO factura electrónicamente quedaba atrapada entre dos pantallas (reportado en producción con una demo de
comida). Configuración › Empresa exigía actividad económica y dirección aunque se eligiera «No contribuyente», porque toda empresa nace
con la facturación electrónica encendida y nadie miraba el tipo; y Configuración › Facturación electrónica no dejaba apagar el
interruptor, porque ese guardado mandaba TODA la empresa y el servidor rechazaba la identificación guardada (una empresa nace sin ella).

Ahora: «No contribuyente» (06) queda sin facturación electrónica y no necesita actividad ni dirección; el interruptor tiene su propia
ruta (apagar no valida nada más; encender dice qué falta y dónde); vale para todos los tipos de negocio y para las demos; y los otros
bloqueos de quien no factura electrónicamente (nombre corto, llave de producción, identificación que no cabe en el número del comprobante,
CABYS obligatorio en el alta rápida de ítems y en las recetas) dejaron de detenerlo."""
import pathlib
import types

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth
from app.db import Empresa, engine, init_db

RAIZ = pathlib.Path(__file__).resolve().parents[1]
LINEAS = [{"cabys": "8399000009900", "detalle": "Casado", "cantidad": 1, "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]


def _empresa(nombre, **campos):
    """Empresa recién nacida, como las crea el sistema: tipo «cédula jurídica», sin identificación, sin actividad ni dirección y con la
    facturación electrónica encendida. Cada prueba la deja en ese estado antes de empezar."""
    init_db()
    base = dict(tipo_id="02", numero_id="", actividad="", otras_senas="", correo="", telefono=None, ambiente="sandbox", tipo_negocio="restaurante",
                factura_electronica=True, es_demo=False, usuario_hacienda=None, password_hacienda=None, p12_nombre=None, p12_pin=None, nombre_comercial=None, barrio=None)
    base.update(campos)
    with Session(engine) as s:
        e = s.exec(select(Empresa).where(Empresa.nombre == nombre)).first() or Empresa(nombre=nombre, numero_id="")
        for k, v in base.items():
            setattr(e, k, v)
        s.add(e); s.commit(); s.refresh(e); s.expunge(e)
    return e


def _guardada(e):
    """La empresa como quedó en la base (cada petición real la lee de ahí; en la prueba el contexto es fijo y hay que renovarlo)."""
    with Session(engine) as s:
        g = s.get(Empresa, e.id)
        s.expunge(g)
    return g


@pytest.fixture()
def entra():
    from app.main import app
    usuario = types.SimpleNamespace(id=None, correo="qa-421@example.test", es_superadmin=False, nombre="QA")

    def _entra(e, rol="Administrador"):
        ctx = auth.Contexto(usuario, _guardada(e), rol)
        app.dependency_overrides[auth.contexto] = lambda: ctx
        return TestClient(app)
    try:
        yield _entra
    finally:
        app.dependency_overrides.clear()


def _cuerpo(c, **cambios):
    """Lo que manda la pantalla de Empresa: todo lo guardado más lo que la persona cambió."""
    e = c.get("/api/empresa").json()
    campos = ("nombre", "nombre_comercial", "tipo_id", "numero_id", "actividad", "provincia", "canton", "distrito", "barrio", "otras_senas", "telefono", "correo",
              "sucursal", "terminal", "ambiente", "factura_electronica")
    cuerpo = {k: e.get(k) for k in campos}
    cuerpo.update({"actividad": cuerpo.get("actividad") or "", "provincia": cuerpo.get("provincia") or 1, "canton": cuerpo.get("canton") or 1, "distrito": cuerpo.get("distrito") or 1,
                   "sucursal": cuerpo.get("sucursal") or 1, "terminal": cuerpo.get("terminal") or 1, "password_hacienda": "***", "smtp_password": "***"})
    cuerpo.update(cambios)
    return cuerpo


def test_el_bucle_de_antes_ya_no_existe(entra):
    """El caso de producción, paso a paso: empresa recién creada, la persona elige «No contribuyente», pone su número y guarda."""
    e = _empresa("Demo de Comida QA 421")
    c = entra(e)
    assert c.get("/api/empresa").json()["factura_electronica"] is True
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="06", numero_id="201230123", correo="democomida421@example.test", telefono=40701198, confirma_sin_fe=True))
    assert r.status_code == 200, r.text
    assert r.json()["facturacion_apagada"] is True                       # la pantalla lo avisa
    g = _guardada(e)
    assert g.tipo_id == "06" and g.numero_id == "201230123" and g.factura_electronica is False
    assert (g.actividad or "") == "" and (g.otras_senas or "") == ""        # no se le pidió ni actividad ni dirección
    # volver a guardar no lo anuncia otra vez, y un «encendida» que llegue con la empresa completa (otra pantalla, una pestaña vieja) no la enciende
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, factura_electronica=True))
    assert r.status_code == 200 and r.json()["facturacion_apagada"] is False
    assert _guardada(e).factura_electronica is False
    # y ya puede vender: comprobante interno, sin Hacienda
    d = entra(e).post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS})
    assert d.status_code == 200, d.text
    assert d.json()["estado"] == "interno"


def test_el_interruptor_se_apaga_aunque_los_datos_guardados_esten_incompletos(entra):
    """Antes, apagar mandaba toda la empresa y el servidor contestaba «La identificación (cédula jurídica) debe tener 10 dígitos…»."""
    e = _empresa("Soda Sin Datos QA 421")
    c = entra(e)
    viejo = c.put("/api/empresa", json=_cuerpo(c, factura_electronica=False))
    assert viejo.status_code == 400 and "identificación" in viejo.json()["detail"]      # el camino de antes sigue validando todo (lo usan otras pantallas)
    assert _guardada(e).factura_electronica is True
    r = c.post("/api/empresa/facturacion-electronica", json={"activa": False})
    assert r.status_code == 200, r.text
    assert r.json() == {"ok": True, "factura_electronica": False}
    assert _guardada(e).factura_electronica is False
    assert entra(e).post("/api/empresa/facturacion-electronica", json={"activa": False}).status_code == 200      # repetirlo no falla
    # con la facturación apagada, Empresa ya no pide actividad ni dirección (solo una identificación válida para su tipo)
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="01", numero_id="101110111", correo="soda421@example.test"))
    assert r.status_code == 200, r.text
    assert r.json()["facturacion_apagada"] is False and _guardada(e).factura_electronica is False


def test_sin_identificacion_el_aviso_al_vender_dice_donde_completarla(entra):
    """Quien apaga el interruptor sin haber guardado nunca sus datos todavía no tiene identificación: al vender, el aviso dice qué falta
    y dónde, y ya no aconseja «apagar la facturación electrónica» a quien la tiene apagada."""
    e = _empresa("Soda Sin Cedula QA 421", factura_electronica=False)
    r = entra(e).post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS})
    assert r.status_code == 400
    d = r.json()["detail"]
    assert "Configuración › Empresa" in d and "apague" not in d and "consecutivo o la clave" not in d


def test_encender_dice_que_falta_y_donde(entra):
    e = _empresa("Soda Por Encender QA 421", factura_electronica=False)
    r = entra(e).post("/api/empresa/facturacion-electronica", json={"activa": True})
    assert r.status_code == 400
    d = r.json()["detail"]
    assert "Configuración › Empresa" in d and "número de identificación" in d and "actividad económica principal" in d and "dirección" in d
    assert _guardada(e).factura_electronica is False
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="01", numero_id="101110111", actividad="5610.0", otras_senas="Frente al parque central", correo="soda421b@example.test"))
    assert r.status_code == 200, r.text
    r = entra(e).post("/api/empresa/facturacion-electronica", json={"activa": True})
    assert r.status_code == 200, r.text
    assert _guardada(e).factura_electronica is True


def test_un_no_contribuyente_no_enciende_la_facturacion_electronica(entra):
    e = _empresa("Soda No Contribuyente QA 421", tipo_id="06", numero_id="201230123", factura_electronica=False, actividad="5610.0", otras_senas="Frente al parque central")
    r = entra(e).post("/api/empresa/facturacion-electronica", json={"activa": True})
    assert r.status_code == 400 and "No contribuyente" in r.json()["detail"]
    assert _guardada(e).factura_electronica is False


def test_quien_factura_electronicamente_sigue_con_sus_requisitos(entra):
    """Nada cambia para el contribuyente con la facturación electrónica encendida: sin actividad, sin dirección o con un nombre corto no guarda."""
    e = _empresa("Restaurante Contribuyente QA 421")
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="02", numero_id="3101421421", correo="rest421@example.test"))
    assert r.status_code == 400 and "otras señas" in r.json()["detail"].lower()
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="02", numero_id="3101421421", correo="rest421@example.test", otras_senas="Frente al parque central"))
    assert r.status_code == 400 and "actividad económica" in r.json()["detail"]
    r = c.put("/api/empresa", json=_cuerpo(c, nombre="Bar", tipo_id="02", numero_id="3101421421", correo="rest421@example.test", otras_senas="Frente al parque central", actividad="5610.0"))
    assert r.status_code == 400 and "nombre de la empresa" in r.json()["detail"]
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="02", numero_id="3101421421", correo="rest421@example.test", otras_senas="Frente al parque central", actividad="5610.0"))
    assert r.status_code == 200, r.text
    assert r.json()["facturacion_apagada"] is False and _guardada(e).factura_electronica is True
    # y en producción sigue necesitando su llave para emitir
    with Session(engine) as s:
        g = s.get(Empresa, e.id); g.ambiente = "produccion"; s.add(g); s.commit()
    r = entra(e).post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS})
    assert r.status_code == 400 and "llave criptográfica" in r.json()["detail"]
    with Session(engine) as s:
        g = s.get(Empresa, e.id); g.ambiente = "sandbox"; s.add(g); s.commit()


@pytest.mark.parametrize("tipo", sorted(auth.TIPOS_NEGOCIO))
@pytest.mark.parametrize("demo", [False, True])
def test_en_todos_los_tipos_de_negocio_y_en_las_demos(entra, tipo, demo):
    """El bloqueo no dependía del tipo de negocio: se comprueba la salida en cada uno, en empresa normal y en demo."""
    nombre = f"QA 421 {tipo} {'demo' if demo else 'normal'}"
    # camino 1: apagar el interruptor desde Ajustes
    e = _empresa(nombre, tipo_negocio=tipo, es_demo=demo)
    assert entra(e).post("/api/empresa/facturacion-electronica", json={"activa": False}).status_code == 200
    assert _guardada(e).factura_electronica is False
    # camino 2: empresa otra vez encendida y sin datos; elegir «No contribuyente» y guardar
    e = _empresa(nombre, tipo_negocio=tipo, es_demo=demo)
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="06", numero_id="201230123", correo=f"qa421{tipo}@example.test", confirma_sin_fe=True))
    assert r.status_code == 200, r.text
    g = _guardada(e)
    assert g.factura_electronica is False and g.tipo_id == "06"
    # y vende
    d = entra(e).post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS})
    assert d.status_code == 200, d.text
    assert d.json()["estado"] == "interno"


@pytest.mark.parametrize("numero", ["12345", "ABC123456789012345", "201230123"])
def test_la_identificacion_de_un_no_contribuyente_no_impide_vender(entra, numero):
    """La identificación va dentro del número de cada comprobante y ahí solo caben de 9 a 12 letras o dígitos: una más corta o más larga
    se guardaba bien y después no dejaba vender nada. El comprobante interno usa un relleno propio; la identificación se guarda tal cual."""
    e = _empresa(f"Soda Cedula {len(numero)} QA 421")
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="06", numero_id=numero, correo="cedula421@example.test", confirma_sin_fe=True))
    assert r.status_code == 200, r.text
    assert _guardada(e).numero_id == numero
    d = entra(e).post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS})
    assert d.status_code == 200, d.text
    doc = d.json()
    assert doc["estado"] == "interno" and len(doc["clave"]) == 50
    assert doc["clave"][9:21] == (numero.zfill(12) if 9 <= len(numero) <= 12 else f"{e.id:012d}")
    # vacía o con signos no se guarda
    c = entra(e)
    assert c.put("/api/empresa", json=_cuerpo(c, tipo_id="06", numero_id=" - ")).status_code == 400


def test_nombre_corto_y_ambiente_de_produccion_sin_llave(entra):
    """«Soda» (4 letras) no podía guardar nada: el mínimo de 5 es de Hacienda. Y con el ambiente en producción se le pedía la llave
    criptográfica para emitir un comprobante que no se firma."""
    e = _empresa("Soda", ambiente="produccion", nombre_comercial="Soda")
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="06", numero_id="201230123", correo="soda421c@example.test", barrio="Sur", otras_senas="Sur", confirma_sin_fe=True))
    assert r.status_code == 200, r.text
    g = _guardada(e)
    assert g.nombre == "Soda" and g.barrio == "Sur" and g.otras_senas == "Sur" and g.factura_electronica is False and g.ambiente == "produccion"
    d = entra(e).post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS})
    assert d.status_code == 200, d.text
    assert d.json()["estado"] == "interno"
    with Session(engine) as s:                              # el nombre de esta empresa choca con otras pruebas que buscan por nombre: se renombra
        g = s.get(Empresa, e.id); g.nombre = "Soda QA 421 usada"; g.ambiente = "sandbox"; s.add(g); s.commit()


def test_el_interruptor_pide_el_permiso_de_configurar(entra):
    e = _empresa("Soda Permisos QA 421")
    assert entra(e, "Cajero").post("/api/empresa/facturacion-electronica", json={"activa": False}).status_code == 403
    assert _guardada(e).factura_electronica is True


def test_pantallas_de_empresa_y_de_facturacion_electronica():
    js = (RAIZ / "app" / "static" / "js" / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    # Empresa: la actividad y la dirección solo se exigen a quien emite comprobantes electrónicos
    assert "exigeFiscal() { return !((this.e && this.e.factura_electronica === false) || this.f.tipo_id === '06'); }," in js
    assert "...(this.exigeFiscal ? [['actividad', 'Actividad económica principal'], ['otras_senas', 'Dirección']] : [])];" in js
    assert "apague la facturación electrónica en Ajustes (o elija «No contribuyente» si no está inscrita ante Hacienda)" in js     # el aviso dice cómo salir
    assert "const apagaFe = this.f.tipo_id === '06' && !(this.e && this.e.factura_electronica === false);" in js          # y se confirma antes de apagarla
    assert "if (apagaFe && !confirm('Como «No contribuyente», esta empresa quedará SIN facturación electrónica" in js
    assert "body: { ...cuerpoEmpresa(this.e, this.f), confirma_sin_fe: apagaFe } });" in js
    assert '<Field label="Actividad principal" :req="exigeFiscal"' in js and '<Field label="Dirección (otras señas)" :req="exigeFiscal"' in js
    assert "v-if=\"f.tipo_id === '06'\"" in js and "al guardar, la facturación electrónica queda apagada" in js
    assert "if (r && r.facturacion_apagada) { try { await sesion.restaurar(); }" in js
    assert "if (e.factura_electronica === false) return { txt: 'Apagada', k: 'info'," in js      # ya no dice «Incompleto: falta la llave» a quien no la necesita
    # Facturación electrónica: el interruptor va solo, por su ruta, y los otros botones de esa pantalla no lo cambian de paso
    assert "if (parte === 'fe') return this.guardarInterruptor();" in js
    gi = js[js.index("async guardarInterruptor() {"):js.index("async guardar(parte) {")]
    assert "await api('/api/empresa/facturacion-electronica', { method: 'POST', body: { activa } });" in gi and "cuerpoEmpresa" not in gi
    assert "this.f.factura_electronica = !this.e || this.e.factura_electronica !== false;" in gi
    # sin volver a montar la pantalla: lo escrito sin guardar en Conexión y en Correo saliente no se pierde
    assert "this.e.factura_electronica = activa;" in gi and "const info = sesion.empresaInfo; if (info) info.factura_electronica = activa;" in gi
    assert "sesion.restaurar" not in gi and "this.cargar()" not in gi and "store.cargar" not in gi
    assert "Movió el interruptor de facturación electrónica y todavía no lo ha guardado" in js
    assert "cambios.factura_electronica = this.e.factura_electronica !== false;" in js
    assert "Ese dato se corrige en Configuración › Empresa" in js
    assert "v-if=\"e && e.tipo_id === '06'\"" in js and "cambie primero el tipo de identificación" in js


def test_items_y_recetas_no_exigen_cabys_sin_facturacion_electronica():
    """El alta rápida de ítems y las recetas exigían el CABYS aunque el servidor ya lo aceptaba vacío sin facturación electrónica (3.93):
    un restaurante sin facturación electrónica no podía poner sus platos a la venta."""
    items = (RAIZ / "app" / "static" / "js" / "pages" / "inventario" / "items.js").read_text(encoding="utf-8")
    assert "import { store, sesion } from '../../app.js';" in items
    assert "if (!f.cabys && sesion.electronica) return toast('Indique el código CABYS', 'err');" in items
    assert "electronica() { return sesion.electronica; }," in items
    assert ":req=\"electronica && (f.tipo==='Producto'||f.tipo==='Servicio')\"" in items
    rec = (RAIZ / "app" / "static" / "js" / "pages" / "inventario" / "recetas.js").read_text(encoding="utf-8")
    assert "if (f.vender && cabys.length !== 13 && (sesion.electronica || cabys.length)) return toast(" in rec
    assert "electronica() { return sesion.electronica; }," in rec and '<Field label="Código CABYS" :req="electronica"' in rec
    comp = (RAIZ / "app" / "static" / "js" / "components.js").read_text(encoding="utf-8")          # el alta rápida de ítem dentro de facturas, cotizaciones y compras
    assert "import { store, rutaPermitida, sesion } from './app.js';" in comp
    assert "if (sesion.electronica ? !/^\\d{13}$/.test(f.cabys || '') : (f.cabys && !/^\\d{13}$/.test(f.cabys))) return toast(" in comp


def test_pasar_a_no_contribuyente_pide_confirmacion(entra):
    """Pasar a «No contribuyente» apaga la facturación electrónica, y eso nunca ocurre en silencio: un contribuyente que elige mal el tipo
    (o una pantalla que manda toda la empresa) dejaría de reportar sus ventas a Hacienda sin saberlo."""
    e = _empresa("Restaurante Que Factura QA 421", tipo_id="02", numero_id="3101421555", actividad="5610.0", otras_senas="Frente al parque central", correo="factura421@example.test")
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="06"))
    assert r.status_code == 409 and "confirme" in r.json()["detail"]
    g = _guardada(e)
    assert g.tipo_id == "02" and g.factura_electronica is True                      # no se guardó nada
    r = c.put("/api/empresa", json=_cuerpo(c, tipo_id="06", confirma_sin_fe=True))
    assert r.status_code == 200 and r.json()["facturacion_apagada"] is True
    assert _guardada(e).factura_electronica is False
    # ya apagada, los demás guardados no vuelven a pedir nada
    c = entra(e)
    assert c.put("/api/empresa", json=_cuerpo(c, telefono=22223333)).status_code == 200


def test_una_empresa_que_ya_era_no_contribuyente_y_estaba_encendida_no_se_apaga_sola(entra):
    """Datos anteriores a esta versión: tipo '06' con la facturación electrónica encendida. Guardar otra cosa (el correo saliente, desde
    otra pantalla) no la apaga a escondidas: el servidor dice dónde resolverlo."""
    e = _empresa("Soda Vieja QA 421", tipo_id="06", numero_id="201230999", actividad="5610.0", otras_senas="Frente al parque central", correo="vieja421@example.test")
    c = entra(e)
    r = c.put("/api/empresa", json=_cuerpo(c, telefono=22224444))
    assert r.status_code == 409 and "Configuración › Empresa" in r.json()["detail"]
    assert _guardada(e).factura_electronica is True
    assert c.post("/api/empresa/facturacion-electronica", json={"activa": False}).status_code == 200      # y siempre puede apagarla con el interruptor


def test_encender_revisa_tambien_lo_que_se_pudo_guardar_mas_corto(entra):
    e = _empresa("Soda Barrio Corto QA 421", tipo_id="01", numero_id="101110111", actividad="5610.0", otras_senas="Frente al parque central", correo="",
                 barrio="Sur", nombre_comercial="BK", factura_electronica=False)
    r = entra(e).post("/api/empresa/facturacion-electronica", json={"activa": True})
    assert r.status_code == 400
    d = r.json()["detail"]
    assert "el barrio" in d and "el nombre comercial" in d and "el correo" in d
    assert "número de identificación" not in d and "actividad" not in d
    assert _guardada(e).factura_electronica is False


def test_el_interruptor_baja_al_programa_local():
    """El interruptor no estaba entre los datos de la empresa que bajan de la nube a la computadora: una empresa apagada en la nube (o
    «No contribuyente») seguía «encendida» en el programa local."""
    from app import sinc
    assert "factura_electronica" in sinc.CAMPOS_EMPRESA and "tipo_id" in sinc.CAMPOS_EMPRESA
    assert "factura_electronica" not in sinc.NULABLES_EMPRESA               # falso baja (no es vacío); vacío nunca viaja
