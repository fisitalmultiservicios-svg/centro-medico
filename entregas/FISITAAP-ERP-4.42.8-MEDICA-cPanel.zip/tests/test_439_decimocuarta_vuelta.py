# -*- coding: utf-8 -*-
"""4.39, decimocuarta vuelta de los arreglos (17 nov 2026): lo que quedaba de V2 (la casilla de la cantidad en 0) y dos textos. Una prueba por
cada cambio, con los métodos reales de caja.js en Node: uno o dos «equipos» con el arnés y el servidor falso de
tests/test_431_cobro_reclamo_pantallas.py y las ayudas de las vueltas tercera a decimotercera (la casilla con la expresión real de la plantilla,
cuentaDeMesa real de _datos.js, destinoDe e impresoraDe reales, la Cocina como única impresora de comanda y cada comanda anotada).

- U1 quitar: con el plato ya enviado y la clave de anular, una línea en 0 recupera ANTES de pedir la clave la cantidad de la base (o 1) y, si es una
  línea partida (`de`) o marcada (promo_fija, promo_fija_de), también su 2x1 de la base; luego vuelve a calcular las promociones. Con la clave negada
  queda así; con la clave dada se quita. Antes la cantidad volvía después de negar la clave: mientras se esperaba la clave (la consulta al servidor),
  la sincronización veía el plato en 0 (lo sacaba con un aviso falso y la cuenta se borraba sin cobrar) o el reloj de las promociones le quitaba el
  2x1; y la cantidad volvía con el descuento calculado para otra cantidad (₡2 712,14 o ₡4 068 por dos Cervezas en 2x1, que son ₡2 034).
- U2 tecla: con F9, F8 o F4, sin la ventana de cobro, y el cursor en una casilla numérica, primero se sale de ella (blur: corre su «change»: el 0
  quita el plato o pide la clave; otra cantidad vuelve a calcular el 2x1) y, si tenía 0 o queda un plato en 0, no se sigue en esa pulsación. Antes se
  guardaba, se mandaba la comanda o se cobraba con el plato en 0: el servidor lo conservaba con un aviso falso, o se quitaba sin la clave; y F9 con
  3 Cervezas en la casilla cobraba con el 2x1 de 2 (₡3 051 en vez de ₡4 068,20). Con el cursor en el buscador, igual que antes.
- U3 fusionarAbierta: no junta (salvo el cobro) mientras el cursor está en una casilla numérica y hay un plato con cantidad en 0 o vacía. Antes la
  sincronización de siempre sacaba la línea con un aviso falso; la casilla con el cursor (la fila del carrito tenía :key="i") pasaba al plato
  siguiente y lo que se escribía iba a él, y al guardar el plato se borraba del servidor sin la clave (de Casado×2 y Café quedaba Café×3).
  4.39 (decimoquinta vuelta): desde la decimoquinta la fila usa :key="l" y la casilla se va con su plato (tests/test_439_decimoquinta_vuelta.py); la
  prueba de U3 sigue escribiendo en la casilla de la posición, como con la plantilla de antes de la decimoquinta.
- U4 confirmarDividir, partes iguales sin mesa: las cuentas «· parte k de n» no reciben líneas cuya parte redondea a 0 (al cobrarlas salía «La
  cuenta … cambió en otro equipo»). Lo cobrado es lo mismo.
- U5 «A dónde»: la mesa unida a esta misma cuenta dice «(unida a esta cuenta)» en vez de «(tiene cuenta abierta: se juntan)».
- U6 solo el comentario de V6 (contrato).
Cada caso que muestra el defecto corre también con los métodos de ANTES de esta vuelta: se sacan de caja.js con la decimocuarta vuelta deshecha
(DECIMOCUARTA y _caja_sin_decimocuarta de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la
vuelta), y «A dónde» con su expresión de antes. El cursor de la página es globalThis.document.activeElement (en Node no hay document: sin él,
fusionarAbierta junta como antes).
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json
import re

from tests.test_431_misma_mesa_pantallas import RAIZ, _js, _linea, _metodo, _tramo
from tests.test_439_decimotercera_vuelta import AYUDAS as AYUDAS13
from tests.test_439_decimotercera_vuelta import CASADO1, GUARDADA, LIMONADA1, QUITAR, _expresion, _extras
from tests.test_439_revision_arreglos import CASADO, LIMONADA, POSTRE, _caja
from tests.test_439_tercera_vuelta import DECIMOCUARTA, _caja_sin_decimocuarta, _caja_sin_decimoquinta
from tests.test_439_undecima_vuelta import _correr as _correr11

# los métodos de la caja que cambió la decimocuarta vuelta (además de «A dónde», en la plantilla); quitar es de una línea
CAMBIADOS = ("tecla(e) {", "fusionarAbierta(motivo) {", "async confirmarDividir() {")
# dónde está cada tripleta de DECIMOCUARTA, en orden (None: la plantilla)
DE_CADA = (QUITAR, "tecla(e) {", "fusionarAbierta(motivo) {", "async confirmarDividir() {", None, "async confirmarDividir() {")
AMBOS = ["Casado×1", "Postre×1"]
FALSO_M6 = "En otro equipo se quitó o cobró 1 plato de Mesa 6. La cuenta quedó como está ahora."
SUMO_M6 = "Se sumó 1 plato que agregó otro equipo a la cuenta de Mesa 6."
QUITAR_CERVEZA, QUITAR_POSTRE = "Quitar Cerveza ya enviado a cocina", "Quitar Postre ya enviado a cocina"
CANCELADA = "Cuenta cancelada: la mesa quedó libre"
# una línea como la anota `lin`: detalle, cantidad, % de descuento, monto (descuentoDe), promoción, promo_fija y la cantidad de promo_fija_de
CERVEZAS_2X1 = ["Cerveza", 2, 50, 1800, "2x1 cervezas", None, None]


def _antes14():
    """Los métodos de la caja que cambió la decimocuarta vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k0 = _caja_sin_decimocuarta()
    return (_linea(k0, QUITAR),) + tuple(_metodo(k0, c) for c in CAMBIADOS)


AYUDAS = r"""
// el evento de una tecla (lo que hace la caja con keydown) con su destino (e.target); devuelve si se llamó a preventDefault
const teclaEn = (vm, key, target) => { const ev = { key, pd: false, preventDefault() { this.pd = true; }, target }; vm.tecla(ev); return ev.pd; };
// la casilla de la cantidad de la línea `l` con el cursor: type number, su valor (el de la línea: v-model) y blur(), que corre su «change» con la
// expresión real de la plantilla (CASILLA), como el navegador al salir de ella; cuenta las veces
const casillaDe = (vm, l) => ({ type: 'number', blurs: 0, get value() { return String(l.cantidad ?? ''); }, blur() { this.blurs++; CASILLA.call(vm, l); } });
// el buscador de productos (type text) con el cursor
const buscador = () => ({ type: 'text', value: 'cer', blurs: 0, blur() { this.blurs++; } });
// el cursor de la página (document.activeElement); sin document, como en Node
const cursor = el => { globalThis.document = { activeElement: el }; };
const sinCursor = () => { delete globalThis.document; };
// una puerta: la promesa que la prueba suelta cuando quiere (la clave de anular retenida mientras «se consulta»)
const puerta = () => { let soltar; const p = new Promise(r => { soltar = r; }); return [p, soltar]; };
// cantidad, porcentaje y monto del descuento de la línea (como descuentoDe), y sus marcas del 2x1
const lin = (vm, l) => [l.detalle, l.cantidad, +l.descuento_pct || 0, r2(vm.descuentoDe(l)), l.promo || '', l.promo_fija ?? null, l.promo_fija_de ? l.promo_fija_de.cantidad : null];
const lins = vm => vm.lineas.map(l => lin(vm, l));
// los guardados que llegaron al servidor
const guardados = () => S.cuerpos.length;
// el 2x1 de las Cervezas, como lo dejó aplicarPromos al mandarlas a cocina
const DX1 = { descuento_pct: 50, promo: '2x1 cervezas' };
"""


def _mas():
    """Los métodos de ahora que estas pruebas usan además de los del arnés: «+» y «−» (cambiarCantidad) y cuentaDeMesaId («A dónde»)."""
    k = _caja()
    return (_linea(k, "async cambiarCantidad(l, delta) {"), _linea(k, "cuentaDeMesaId(id) {"))


def _correr(tmp_path, casos, antes=False):
    """El arnés de la decimotercera vuelta (la casilla de la plantilla, cuentaDeMesa real) con estas ayudas; con `antes`, quitar, tecla,
    fusionarAbierta y confirmarDividir como estaban antes de esta vuelta (la casilla de la cantidad no cambió). Al final se quita el cursor."""
    k = _caja()
    expr = _expresion(k)
    assert expr == _expresion(_caja_sin_decimocuarta())
    mesa = _tramo(_js("pages/pos/_datos.js"), "export function ocupaMesa(", "\nexport const MESA_BASE").replace("export function ", "function ")
    ayudas = AYUDAS13.replace("@CASILLA@", json.dumps(expr)).replace("@MESA_REAL@", json.dumps(mesa)) + AYUDAS
    return _correr11(tmp_path, ayudas + casos + "\nsinCursor();\n", antes=_extras() + _mas() + (_antes14() if antes else ()))


# ================================================================================================================ U1: la clave negada
CASOS_U1 = r"""
// la Mesa 6 con 2 Cervezas ya enviadas en 2x1 (₡2 034), guardada; A la abre (con la promoción vigente) y la caja pide la clave de anular, retenida en
// una puerta (la consulta al servidor). `previo`: «+» (a 3) o 1 en la casilla. Después escribe 0 en la casilla (corre su «change»: quitar). Mientras se
// espera la clave (`durante`): nada, la sincronización de siempre o el reloj de las promociones (aplicarPromos). Se suelta la clave (`clave`), A toca
// «Guardar cuenta» y después abre la Mesa 6 y la cobra
async function u1(previo, durante, clave) {
  const [id, a] = await cuenta(true, [{ ...CERVEZA(2), ...ENV(), ...DX1, descuento: 1800 }]);
  a.promosActivas = PROMO; a.cfg.clave_anular = '1234';
  const l = a.lineas[0], [p, soltar] = puerta(), pedidas = [];
  a.autorizar = async t => { pedidas.push([t, ...lin(a, l).slice(1, 4)]); return p; };
  if (previo === 'mas') await a.cambiarCantidad(l, 1); else await casilla(a, l, previo);
  const antes = lins(a);
  l.cantidad = 0; const q = CASILLA.call(a, l); await espera(20);
  const esperando = lins(a);
  if (durante === 'sinc') await a.sincronizar(); else if (durante === 'promos') a.aplicarPromos();
  const tras = { lineas: lins(a), avisos: avisos(a).slice(), srv: srv() };
  soltar(clave); await q;
  const fin = { lineas: lins(a), avisos: avisos(a).slice(), vista: a.vista };
  if (a.vista === 'venta') a.guardarCuenta();
  await a.A.mock.guardarTodo(); await hastaLibre();
  const guardada = { srv: srv(), avisos: avisos(a).slice() };
  await a.sincronizar(); a.abrirMesa(M6); a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { antes, pedidas, esperando, tras, fin, guardada, hechos: cobrados(a), suma: suma(), srv: srv() };
}
for (const previo of ['mas', 1]) for (const durante of ['nada', 'sinc', 'promos']) out[previo + '_' + durante] = await u1(previo, durante, false);
out.dada = await u1('mas', 'sinc', true);
"""
U1_NEGADAS = tuple(p + "_" + d for p in ("mas", "1") for d in ("nada", "sinc", "promos"))


def test_u1_con_la_clave_negada_el_plato_vuelve_a_su_cantidad_y_a_su_2x1_antes_de_pedirla_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U1)
    for k in U1_NEGADAS:
        x = r[k]
        # «+» deja 3 Cervezas al 33,33 % (el 2x1 de 3); 1 en la casilla, sin 2x1
        assert x["antes"] == ([["Cerveza", 3, 33.33, 1799.82, "2x1 cervezas", None, None]] if k.startswith("mas") else [["Cerveza", 1, 0, 0, "", None, None]]), (k, x)
        # el 0 en la casilla: la cantidad guardada (2) y su 2x1 vuelven ANTES de pedir la clave; mientras se espera, la sincronización no ve nada que juntar
        # (sin aviso, el servidor intacto) y el reloj de las promociones deja el 50 %
        assert x["pedidas"] == [[QUITAR_CERVEZA, 2, 50, 1800]] and x["esperando"] == [CERVEZAS_2X1], (k, x)
        assert x["tras"] == {"lineas": [CERVEZAS_2X1], "avisos": [], "srv": [["Mesa 6", ["Cerveza×2"], None]]}, (k, x)
        # la clave negada: así queda; se guarda y se cobran las 2 Cervezas al 50 % (₡2 034), una vez
        assert x["fin"] == {"lineas": [CERVEZAS_2X1], "avisos": [], "vista": "venta"}, (k, x)
        assert x["guardada"] == {"srv": [["Mesa 6", ["Cerveza×2"], None]], "avisos": [GUARDADA]}, (k, x)
        assert x["hechos"] == [["A", ["Cerveza×2"]]] and x["suma"] == 2034 and x["srv"] == [], (k, x)
    # la clave dada (con la sincronización en medio): el plato se quita y, como era el único, la cuenta se cancela; sin aviso falso, nada se cobra
    d = r["dada"]
    assert d["pedidas"] == [[QUITAR_CERVEZA, 2, 50, 1800]] and d["tras"]["avisos"] == [] and d["tras"]["srv"] == [["Mesa 6", ["Cerveza×2"], None]], d
    assert d["fin"] == {"lineas": [], "avisos": [CANCELADA], "vista": "mesas"} and d["guardada"]["srv"] == [] and d["hechos"] == [] and d["suma"] == 0, d

    # antes de esta vuelta: la clave se pedía con la línea en 0. Sin nada en medio, la cantidad volvía con el descuento de otra cantidad (con «+»: el
    # 33,33 % de 3, ₡2 712,14; con 1: sin 2x1, ₡4 068); con el reloj de las promociones en medio, sin 2x1 (₡4 068); con la sincronización en medio, la
    # línea salía con el aviso falso de otro equipo y, al guardar, la cuenta se borraba sin cobrar las Cervezas (₡2 034 que no se cobraron nunca)
    v = _correr(tmp_path / "antes", CASOS_U1, antes=True)
    for k in U1_NEGADAS:
        x = v[k]
        assert x["pedidas"][0][:2] == [QUITAR_CERVEZA, 0] and x["esperando"][0][1] == 0, (k, x)
    assert v["mas_nada"]["fin"]["lineas"] == [["Cerveza", 2, 33.33, 1199.88, "2x1 cervezas", None, None]] and v["mas_nada"]["suma"] == 2712.14, v["mas_nada"]
    for k in ("mas_promos", "1_nada", "1_promos"):
        assert v[k]["fin"]["lineas"] == [["Cerveza", 2, 0, 0, "", None, None]] and v[k]["hechos"] == [["A", ["Cerveza×2"]]] and v[k]["suma"] == 4068, (k, v[k])
    for k in ("mas_sinc", "1_sinc", "dada"):
        x = v[k]
        assert x["tras"]["lineas"] == [] and x["tras"]["avisos"] == [FALSO_M6] and x["tras"]["srv"] == [["Mesa 6", ["Cerveza×2"], None]], (k, x)
        assert x["guardada"]["srv"] == [] and x["hechos"] == [] and x["suma"] == 0, (k, x)


CASOS_U1_MARCAS = r"""
// la clave de anular se pide y se niega. (partida) una cuenta guardada sin mesa con 6 Cervezas ya enviadas en 2x1; A la abre y la parte en 3 partes
// iguales: le queda la parte 1 (2 Cervezas, línea partida: `de`). (fija) la Mesa 6 con dos líneas de 2 Cervezas en 2x1 de la misma comanda; A cobra la
// primera con «Dividir → Cobrar estos platos» y vuelve a abrir la mesa: la segunda queda marcada (promo_fija: su par se cobró). En las dos, A escribe 1
// en la casilla (el 2x1 se vuelve a calcular: sin promoción) y después 0 (quitar, con la clave negada); después cobra lo que hay en pantalla
async function u1m(que) {
  const E = ENV();
  const [id, a] = que === 'partida' ? await cuenta(false, [{ ...CERVEZA(6), ...E, ...DX1, descuento: 5400 }])
    : await cuenta(true, [{ ...CERVEZA(2), ...E, ...DX1, descuento: 1800 }, { ...CERVEZA(2), ...E, ...DX1, descuento: 1800 }]);
  a.promosActivas = PROMO; a.cfg.clave_anular = '1234'; const pedidas = []; a.autorizar = async t => { pedidas.push(t); return false; };
  await a.abrirDividir();
  if (que === 'partida') { a.dividir.modo = 'partes'; a.dividir.partes = 3; await a.confirmarDividir(); await a.A.mock.guardarTodo(); await hastaLibre(); }
  else { a.dividir.destino = 'cobrar'; a.dividir.sel = { 0: 2 }; await a.confirmarDividir(); await conPago(a); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); await a.sincronizar(); a.abrirMesa(M6); }
  const marcada = { lineas: lins(a), de: a.lineas.map(x => typeof x.de === 'string' && x.de !== ''), srv: srv(), suma: suma() };
  const l = a.lineas[0];
  await casilla(a, l, 1); const uno = lins(a);
  await casilla(a, l, 0); const cero = lins(a);
  a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  return { marcada, uno, cero, pedidas, hechos: cobrados(a), suma: suma(), srv: srv() };
}
out.partida = await u1m('partida');
out.fija = await u1m('fija');
"""


def test_u1_la_linea_partida_o_marcada_con_la_clave_negada_conserva_su_2x1_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U1_MARCAS)
    p, f = r["partida"], r["fija"]
    partes = [["Cuenta 1 · parte 2 de 3", ["Cerveza×2"], None], ["Cuenta 1 · parte 3 de 3", ["Cerveza×2"], None]]
    # la parte 1: una línea partida de 2 Cervezas al 50 %; con 1 en la casilla, sin 2x1; con 0 y la clave negada vuelve a 2 con el 2x1 con que se partió
    # (de la base) y se cobra ₡2 034; las partes 2 y 3 siguen en el servidor
    assert p["marcada"]["lineas"] == [CERVEZAS_2X1] and p["marcada"]["de"] == [True] and p["marcada"]["srv"] == [["Cuenta 1", ["Cerveza×2"], None]] + partes, p
    assert p["uno"] == [["Cerveza", 1, 0, 0, "", None, None]] and p["cero"] == [CERVEZAS_2X1] and p["pedidas"] == [QUITAR_CERVEZA], p
    assert p["hechos"] == [["A", ["Cerveza×2"]]] and p["suma"] == 2034 and p["srv"] == partes, p
    # la marcada: «Cobrar estos platos» cobró 2 Cervezas (₡2 034); la otra línea queda al 50 % con promo_fija 2. Con 1 se guarda la marca aparte
    # (promo_fija_de) y queda sin 2x1; con 0 y la clave negada vuelve la marca de la base y se cobra ₡2 034 (las 4 Cervezas en 2x1: ₡4 068)
    assert f["marcada"] == {"lineas": [["Cerveza", 2, 50, 1800, "2x1 cervezas", 2, None]], "de": [False], "srv": [["Mesa 6", ["Cerveza×2"], None]], "suma": 2034}, f
    assert f["uno"] == [["Cerveza", 1, 0, 0, "", None, 2]] and f["cero"] == [["Cerveza", 2, 50, 1800, "2x1 cervezas", 2, None]] and f["pedidas"] == [QUITAR_CERVEZA], f
    assert f["hechos"] == [["A", ["Cerveza×2"]], ["A", ["Cerveza×2"]]] and f["suma"] == 4068 and f["srv"] == [], f

    # antes de esta vuelta: solo volvía la cantidad, con el descuento de 1 Cerveza (ninguno): la parte 1 se cobraba a ₡4 068 y la línea marcada también
    # (₡6 102 por las 4 Cervezas)
    v = _correr(tmp_path / "antes", CASOS_U1_MARCAS, antes=True)
    assert v["partida"]["cero"] == [["Cerveza", 2, 0, 0, "", None, None]] and v["partida"]["suma"] == 4068 and v["partida"]["marcada"] == p["marcada"], v["partida"]
    assert v["fija"]["cero"] == [["Cerveza", 2, 0, 0, "", None, 2]] and v["fija"]["suma"] == 6102 and v["fija"]["marcada"] == f["marcada"], v["fija"]


# ================================================================================================================ U2: F4, F8 y F9 en la casilla
CASOS_U2 = r"""
// un solo equipo, la Mesa 6 guardada con Casado (ya enviado) y Postre (ya enviado; con F8, sin enviar y con una Limonada sin enviar). Con `clave` (false),
// la caja pide la clave de anular y se niega. Escribe 0 en la casilla del Postre y, con el cursor ahí, toca `key`. Si sigue en la cuenta sin la ventana de
// cobro, toca `key` otra vez, ya sin el cursor en la casilla. Si quedó la ventana de cobro abierta, cobra
const pantallaU2 = (a, pd) => ({ pd, vista: a.vista, pago: !!a.pago, platos: detalles(a), srv: srv(), impresos: quienes(a), avisos: avisos(a).filter(t => !t.startsWith('Comanda ')) });
async function u2(key, clave) {
  const f8 = key === 'F8';
  const [id, a] = await cuenta(true, [{ ...CASADO(), ...ENV() }, { ...POSTRE(), ...(f8 ? {} : ENV()) }, ...(f8 ? [LIMONADA()] : [])]);
  const pedidas = []; if (clave !== undefined) { a.cfg.clave_anular = '1234'; a.autorizar = async t => { pedidas.push(t); return clave; }; }
  const g0 = guardados(), l = a.lineas.find(x => x.detalle === 'Postre'); l.cantidad = 0; const c = casillaDe(a, l);
  const pd = teclaEn(a, key, c); await espera(30); await a.A.mock.guardarTodo(); await hastaLibre();
  const primera = { ...pantallaU2(a, pd), blurs: c.blurs, pedidas: pedidas.slice(), postre: l.cantidad, guardados: guardados() - g0 };
  let segunda = null;
  if (a.vista === 'venta' && !a.pago) { const pd2 = teclaEn(a, key, { type: undefined }); await espera(30); await a.A.mock.guardarTodo(); await hastaLibre(); segunda = { ...pantallaU2(a, pd2), guardados: guardados() - g0 }; }
  if (a.pago) { await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); }
  return { primera, segunda, hechos: cobrados(a), suma: suma() };
}
for (const key of ['F4', 'F8', 'F9']) out[key] = await u2(key);
out.F4_negada = await u2('F4', false);
out.F9_negada = await u2('F9', false);
// el 2x1: la venta rápida con 2 Cervezas en 2x1; escribe 3 en la casilla y, con el cursor ahí, toca F9; después cobra
{ nuevo(); const v = venta(await equipo()); v.promosActivas = PROMO; v.lineas.push(CERVEZA(2)); v.aplicarPromos(); const l = v.lineas[0];
  l.cantidad = 3; const c = casillaDe(v, l); const pd = teclaEn(v, 'F9', c); await conPago(v);
  out.dosxuno = { pd, blurs: c.blurs, pago: !!v.pago, lineas: lins(v), total: v.totales.total };
  if (v.pago) { await v.cobrar(); await hastaLibre(); await v.A.mock.guardarTodo(); } out.dosxuno.suma = suma(); }
// el buscador con el cursor (type text) y F8, en la Mesa 6 con Casado ya enviado y una Limonada sin enviar: la comanda sale en esa pulsación, sin blur
{ const [id, a] = await cuenta(true, [{ ...CASADO(), ...ENV() }, LIMONADA()]); const c = buscador();
  const pd = teclaEn(a, 'F8', c); await espera(30); await a.A.mock.guardarTodo(); await hastaLibre();
  out.buscador = { pd, blurs: c.blurs, impresos: quienes(a), srv: srv(), avisos: avisos(a).filter(t => !t.startsWith('Comanda ')) }; }
"""


def test_u2_f4_f8_y_f9_con_el_cursor_en_la_casilla_la_dejan_primero_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U2)
    # la primera pulsación deja la casilla (un blur: corre quitar; sin clave de anular el Postre sale de la pantalla) y, como tenía 0, no guarda, no manda
    # comanda ni abre el cobro; el servidor sigue igual
    for key, srv0, quedan in (("F4", AMBOS, CASADO1), ("F8", ["Casado×1", "Limonada×1", "Postre×1"], ["Casado×1", "Limonada×1"]), ("F9", AMBOS, CASADO1)):
        x = r[key]["primera"]
        assert x == {"pd": True, "vista": "venta", "pago": False, "platos": quedan, "srv": [["Mesa 6", srv0, None]], "impresos": [], "avisos": [], "blurs": 1,
                     "pedidas": [], "postre": 0, "guardados": 0}, (key, x)
    # la segunda pulsación hace lo de siempre, sin el Postre y sin aviso falso: F4 guarda; F8 manda la Limonada a cocina (y guarda); F9 abre el cobro
    # y se cobra el Casado
    s4, s8, s9 = r["F4"]["segunda"], r["F8"]["segunda"], r["F9"]["segunda"]
    assert s4["vista"] == "mesas" and s4["srv"] == [["Mesa 6", CASADO1, None]] and s4["avisos"] == [GUARDADA] and s4["guardados"] == 1, s4
    assert s8["impresos"] == [["A", LIMONADA1]] and s8["srv"] == [["Mesa 6", ["Casado×1", "Limonada×1"], None]] and s8["avisos"] == [], s8
    assert s9["pago"] is True and s9["avisos"] == [] and r["F9"]["hechos"] == [["A", CASADO1]] and r["F9"]["suma"] == CASADO, r["F9"]
    # con la clave de anular negada: el Postre vuelve a 1 y no se hace nada en esa pulsación; la segunda guarda (o cobra) la cuenta entera
    for key in ("F4_negada", "F9_negada"):
        x = r[key]["primera"]
        assert x["pedidas"] == [QUITAR_POSTRE] and x["postre"] == 1 and x["platos"] == AMBOS and x["guardados"] == 0 and x["pago"] is False and x["avisos"] == [], (key, x)
    assert r["F4_negada"]["segunda"]["srv"] == [["Mesa 6", AMBOS, None]] and r["F4_negada"]["segunda"]["avisos"] == [GUARDADA], r["F4_negada"]
    assert r["F9_negada"]["hechos"] == [["A", AMBOS]] and r["F9_negada"]["suma"] == CASADO + POSTRE, r["F9_negada"]
    # el 2x1: 3 Cervezas en la casilla y F9: al dejarla se calcula el 2x1 de 3 (33,33 %) y el cobro abre en esa pulsación; se cobran ₡4 068,20
    assert r["dosxuno"] == {"pd": True, "blurs": 1, "pago": True, "lineas": [["Cerveza", 3, 33.33, 1799.82, "2x1 cervezas", None, None]], "total": 4068.2,
                            "suma": 4068.2}, r["dosxuno"]
    # el cursor en el buscador: F8 manda la comanda en esa pulsación y no lo deja (sin blur)
    assert r["buscador"] == {"pd": True, "blurs": 0, "impresos": [["A", LIMONADA1]], "srv": [["Mesa 6", ["Casado×1", "Limonada×1"], None]], "avisos": []}, r

    # antes de esta vuelta: la tecla no miraba la casilla. F4 guardaba con el Postre en 0 (el servidor lo conservaba, con el aviso falso de otro equipo, y
    # la clave de anular ni se pedía); F8 mandaba la comanda y el servidor conservaba el Postre sin enviar; F9 abría el cobro con el aviso falso de que la
    # cuenta cambió y se cobraba sin el Postre aunque la clave de anular estuviera configurada (₡1 356 sin cobrar). El 2x1 se cobraba con el 50 % de 2
    # Cervezas (₡3 051). El buscador, igual
    v = _correr(tmp_path / "antes", CASOS_U2, antes=True)
    for key in ("F4", "F4_negada"):
        x = v[key]["primera"]
        assert x["vista"] == "mesas" and x["blurs"] == 0 and x["pedidas"] == [] and x["srv"] == [["Mesa 6", AMBOS, None]] and x["avisos"] == [FALSO_M6, GUARDADA], (key, x)
    x = v["F8"]["primera"]
    assert x["impresos"] == [["A", LIMONADA1]] and x["srv"] == [["Mesa 6", ["Casado×1", "Limonada×1", "Postre×1"], None]] and x["avisos"] == [FALSO_M6], x
    for key in ("F9", "F9_negada"):
        x = v[key]
        assert x["primera"]["pago"] is True and x["primera"]["pedidas"] == [] and x["primera"]["avisos"] == ["La cuenta de Mesa 6 cambió en otro equipo. Revise el total antes de cobrar."], (key, x)
        assert x["hechos"] == [["A", CASADO1]] and x["suma"] == CASADO, (key, x)
    assert v["dosxuno"]["blurs"] == 0 and v["dosxuno"]["lineas"] == [["Cerveza", 3, 50, 2700, "2x1 cervezas", None, None]] and v["dosxuno"]["suma"] == 3051, v["dosxuno"]
    assert v["buscador"] == r["buscador"], v["buscador"]


# ================================================================================================================ U3: la sincronización mientras se escribe
CASOS_U3 = r"""
// la Mesa 6 con 2 Casados y un Café ya enviados, abierta en A y en B. Con `otro`, B agrega una Limonada y la guarda. En A, la casilla del Casado tiene el
// cursor y la cantidad `q` ('' o 0: se está escribiendo); pasa la sincronización de siempre. Después A escribe 3 en la casilla de esa posición (con
// :key="i", como estaba la fila hasta la decimoquinta vuelta, la casilla con el cursor es la de esa posición) y sale de ella; pasa otra sincronización y A
// toca «Guardar cuenta»
const CAFE = () => plato('Café', 700, 5);
const escribir = (vm, i, q) => { const l = vm.lineas[i]; l.cantidad = q; return l; };
async function u3(q, otro) {
  const [id, a, b] = await cuenta(true, [{ ...conCant(CASADO(), 2), ...ENV() }, { ...CAFE(), ...ENV() }]);
  if (otro) { b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo(); }
  cursor(casillaDe(a, escribir(a, 0, q)));
  await a.sincronizar();
  const durante = { platos: detalles(a), orden: a.lineas.map(x => x.detalle), avisos: avisos(a).slice(), srv: srv() };
  const c3 = casillaDe(a, escribir(a, 0, 3)); cursor(null); c3.blur();
  const salir = detalles(a);
  await a.sincronizar(); const otra = { platos: detalles(a), avisos: avisos(a).slice() };
  a.guardarCuenta(); await a.A.mock.guardarTodo(); await hastaLibre();
  return { durante, salir, otra, srv: srv(), avisos: avisos(a) };
}
out.vacia = await u3('', false);
out.cero = await u3(0, false);
out.vacia_lim = await u3('', true);
// B agregó la Limonada. En A el Casado en 0 con el cursor en el buscador (o sin cursor), o con 3 en la casilla y el cursor todavía ahí: la sincronización
async function u3sin(donde) {
  const [id, a, b] = await cuenta(true, [{ ...conCant(CASADO(), 2), ...ENV() }, { ...CAFE(), ...ENV() }]);
  b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo();
  const l = escribir(a, 0, donde === 'tres' ? 3 : 0);
  cursor(donde === 'buscador' ? buscador() : donde === 'tres' ? casillaDe(a, l) : null);
  await a.sincronizar(); const r = { platos: detalles(a), avisos: avisos(a).slice() }; sinCursor(); return r;
}
for (const d of ['buscador', 'nada', 'tres']) out['sin_' + d] = await u3sin(d);
// el cobro: B agregó la Limonada; en A el Casado vacío con el cursor en su casilla. Con la lista ya traída, juntar para la sincronización y para el cobro
{ const [id, a, b] = await cuenta(true, [{ ...conCant(CASADO(), 2), ...ENV() }, { ...CAFE(), ...ENV() }]);
  b.lineas.push(LIMONADA()); b.persistirCuenta(); await b.A.mock.guardarTodo();
  cursor(casillaDe(a, escribir(a, 0, '')));
  await a.A.mock.refrescar(['pos_espera']); a.espera = a.A.mock.get('pos_espera', []);
  const sinc = a.fusionarAbierta('sinc'), tras = detalles(a), cobro = a.fusionarAbierta('cobro');
  out.cobro = { sinc, tras, cobro, platos: detalles(a) }; sinCursor(); }
"""


def test_u3_la_sincronizacion_no_junta_mientras_se_escribe_una_cantidad_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U3)
    for k, casado in (("vacia", "Casado×"), ("cero", "Casado×0"), ("vacia_lim", "Casado×")):
        x = r[k]
        # mientras se escribe, la sincronización no junta: la línea sigue en su lugar, sin aviso, y el servidor intacto (con la Limonada de B, si la agregó)
        srv0 = ["Café×1", "Casado×2"] + (["Limonada×1"] if k.endswith("_lim") else [])
        assert x["durante"] == {"platos": ["Café×1", casado], "orden": ["Casado", "Café"], "avisos": [], "srv": [["Mesa 6", srv0, None]]}, (k, x)
        # al salir con 3, el Casado queda en 3; la sincronización siguiente trae lo de B (con su aviso) y al guardar el servidor queda con Casado×3
        assert x["salir"] == ["Café×1", "Casado×3"], (k, x)
    assert r["vacia"]["otra"] == {"platos": ["Café×1", "Casado×3"], "avisos": []} and r["vacia"]["srv"] == [["Mesa 6", ["Café×1", "Casado×3"], None]], r["vacia"]
    assert r["cero"]["srv"] == r["vacia"]["srv"] and r["cero"]["avisos"] == [GUARDADA], r["cero"]
    lim = r["vacia_lim"]
    assert lim["otra"] == {"platos": ["Café×1", "Casado×3", "Limonada×1"], "avisos": [SUMO_M6]} and lim["avisos"] == [SUMO_M6, GUARDADA], lim
    assert lim["srv"] == [["Mesa 6", ["Café×1", "Casado×3", "Limonada×1"], None]], lim
    # sin el cursor en una casilla numérica (el buscador o ninguno), la sincronización junta como antes; con el cursor en la casilla y todas las cantidades
    # mayores que 0, también (llega la Limonada)
    for d in ("buscador", "nada"):
        assert r["sin_" + d] == {"platos": ["Café×1", "Limonada×1"], "avisos": [SUMO_M6, FALSO_M6]}, (d, r)
    assert r["sin_tres"] == {"platos": ["Café×1", "Casado×3", "Limonada×1"], "avisos": [SUMO_M6]}, r
    # el cobro junta siempre (la de la sincronización no)
    assert r["cobro"] == {"sinc": {"agregadas": 0, "quitadas": 0}, "tras": ["Café×1", "Casado×"], "cobro": {"agregadas": 1, "quitadas": 1}, "platos": ["Café×1", "Limonada×1"]}, r

    # antes de esta vuelta: la sincronización sacaba el Casado con el aviso falso de otro equipo; la casilla con el cursor pasaba al Café, el 3 iba a él y al
    # guardar el servidor quedaba con Café×3: los 2 Casados ya enviados se borraron sin la clave de anular
    v = _correr(tmp_path / "antes", CASOS_U3, antes=True)
    for k in ("vacia", "cero"):
        x = v[k]
        assert x["durante"] == {"platos": ["Café×1"], "orden": ["Café"], "avisos": [FALSO_M6], "srv": [["Mesa 6", ["Café×1", "Casado×2"], None]]}, (k, x)
        assert x["salir"] == ["Café×3"] and x["srv"] == [["Mesa 6", ["Café×3"], None]], (k, x)
    assert v["vacia_lim"]["durante"]["avisos"] == [SUMO_M6, FALSO_M6] and v["vacia_lim"]["srv"] == [["Mesa 6", ["Café×3", "Limonada×1"], None]], v["vacia_lim"]
    for d in ("buscador", "nada", "tres"):
        assert v["sin_" + d] == r["sin_" + d], (d, v)
    assert v["cobro"]["sinc"] == {"agregadas": 1, "quitadas": 1} and v["cobro"]["platos"] == r["cobro"]["platos"], v["cobro"]


# ================================================================================================================ U4: partes iguales sin mesa
CASOS_U4 = r"""
// una cuenta guardada sin mesa (`comercio`: en la caja de comercio) con Casado×1 y Postre×0,001 ya enviados; A la abre y la parte en 3 partes iguales
// (la parte del Postre redondea a 0). A cobra la parte 1 y otro equipo cobra cada una de las demás desde «Para llevar en espera»
async function u4(comercio) {
  const [id, a] = await cuenta(false, [{ ...CASADO(), ...ENV() }, { ...conCant(POSTRE(), 0.001), ...ENV() }]);
  if (comercio) a.esRestaurante = false;
  await a.abrirDividir(); a.dividir.modo = 'partes'; a.dividir.partes = 3; await a.confirmarDividir(); await a.A.mock.guardarTodo(); await hastaLibre();
  const partes = srv(), uno = detalles(a);
  a._alDia = 0; await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  const cobros = [];
  for (const c of S.items.slice()) {
    const v = venta(await equipo()); if (comercio) v.esRestaurante = false; await v.sincronizar(); v.recuperar(v.espera.find(x => x.id === c.id));
    const platos = detalles(v); v._alDia = 0; await v.abrirPago(); const pago = !!v.pago; if (v.pago) await v.cobrar(); await hastaLibre(); await v.A.mock.guardarTodo();
    cobros.push([c.nombre, platos, pago, avisos(v).filter(t => !t.startsWith('Tiquete '))]);
  }
  return { partes, uno, cobros, avisosA: avisos(a).filter(t => !t.startsWith('Tiquete ')), porPlato: porPlato(), suma: suma(), srv: srv() };
}
out.restaurante = await u4(false);
out.comercio = await u4(true);
"""
PARTE1 = ["Cuenta 1", ["Casado×0.334", "Postre×0.001"], None]
DIVIDIDA = "Cuenta dividida en 3 partes: esta es la parte 1; las demás están en «Para llevar en espera»"


def test_u4_las_partes_iguales_sin_mesa_no_pasan_lineas_en_0_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_U4)
    total = round((3500 + 1200 * 0.001) * 1.13, 2)
    for k in ("restaurante", "comercio"):
        x = r[k]
        # las partes 2 y 3 llevan solo el Casado (la parte del Postre redondea a 0); el Postre entero queda en la parte 1
        assert x["partes"] == [PARTE1, ["Cuenta 1 · parte 2 de 3", ["Casado×0.333"], None], ["Cuenta 1 · parte 3 de 3", ["Casado×0.333"], None]], (k, x)
        assert x["uno"] == PARTE1[1] and x["avisosA"] == [DIVIDIDA], (k, x)
        # al cobrarlas, sin aviso; lo cobrado es la cuenta (las cantidades exactas; el dinero, salvo el redondeo a céntimos de cada comprobante)
        assert x["cobros"] == [["Cuenta 1 · parte 2 de 3", ["Casado×0.333"], True, []], ["Cuenta 1 · parte 3 de 3", ["Casado×0.333"], True, []]], (k, x)
        assert x["porPlato"] == {"Casado": 1, "Postre": 0.001} and abs(x["suma"] - total) <= 0.03 and x["srv"] == [], (k, x)

    # antes de esta vuelta: las partes 2 y 3 llevaban Postre×0 y, al cobrarlas, salía «La cuenta de … cambió en otro equipo»; lo cobrado, lo mismo
    v = _correr(tmp_path / "antes", CASOS_U4, antes=True)
    for k in ("restaurante", "comercio"):
        x = v[k]
        assert x["partes"][1:] == [["Cuenta 1 · parte %d de 3" % n, ["Casado×0.333", "Postre×0"], None] for n in (2, 3)], (k, x)
        assert [c[3] for c in x["cobros"]] == [["La cuenta de Cuenta 1 · parte %d de 3 cambió en otro equipo. Revise el total antes de cobrar." % n] for n in (2, 3)], (k, x)
        assert x["porPlato"] == r[k]["porPlato"] and x["suma"] == r[k]["suma"], (k, x)


# ================================================================================================================ U5: «A dónde» con mesas unidas
def _opcion_mesa(k: str):
    """El v-if y las interpolaciones de la opción de cada mesa en «A dónde» («Dividir»): la etiqueta es solo interpolaciones."""
    i = k.index('<Field label="A dónde"')
    f = k[i:k.index("</Field>", i)]
    assert f.count('<template v-for="m in mesas" :key="m.id">') == 1
    op = f[f.index('<template v-for="m in mesas" :key="m.id">'):f.index("</template>")]
    vif = re.search(r'<option v-if="([^"]*)" :value="m.id">', op).group(1)
    texto = op[op.index(">", op.index("<option")) + 1:op.index("</option>")]
    partes = re.findall(r"\{\{(.*?)\}\}", texto)
    assert "".join("{{" + p + "}}" for p in partes) == texto and partes[0] == "m.nombre"
    return vif, partes


CASOS_U5 = r"""
// las etiquetas de las mesas en «A dónde» (la plantilla de ahora o la de antes), sobre ESE equipo; cuentaDeMesa, la de _datos.js (con las mesas unidas)
const OPC = new Function('m', 'with (this) { return (' + @VIF@ + ') ? String(' + @ETQ@.join(') + String(') + ') : null; }');
const etiquetas = vm => vm.mesas.map(m => OPC.call(vm, m)).filter(x => x !== null);
const M8 = { id: 8, nombre: 'Mesa 8' }, M9 = { id: 9, nombre: 'Mesa 9' };
// otro equipo: la Mesa 8 con su cuenta; la Mesa 6 con la Mesa 7 unida («Unir mesas»); la Mesa 9 libre
nuevo();
const g = venta(await equipo()); g.mesas = [M6, M7, M8, M9];
g.abrirMesa(M8); g.lineas.push({ ...LIMONADA(), ...ENV() }); g.persistirCuenta(); g.volverAMesas(true);
g.abrirMesa(M6); g.lineas.push({ ...CASADO(), ...ENV() }); g.persistirCuenta(); g.abrirUnir(); g.unir.sel = { 7: true }; g.confirmarUnir();
await g.A.mock.guardarTodo();
const a = venta(await equipo()); a.mesas = [M6, M7, M8, M9]; await a.sincronizar(); globalThis.cuentaDeMesa = mesaReal(a);
a.abrirMesa(M6); out.desde6 = { nombre: a.nombreEspera, etq: etiquetas(a) };
// desde la Mesa 7: abre la cuenta unida (lo que hace abrirMesa con cuentasDeMesa de _datos.js, que en el arnés no ve las mesas unidas)
const unida = a.espera.find(v => v.id === a.esperaId);
a.volverAMesas(true); a.cargarCuenta(unida); a.mesaActual = M7; a.nombreEspera = unida.nombre; a.vista = 'venta';
out.desde7 = { nombre: a.nombreEspera, etq: etiquetas(a) };
a.volverAMesas(true); a.abrirMesa(M9); out.desde9 = { cuenta: a.esperaId, etq: etiquetas(a) };
sinMesaReal();
"""


def _correr_u5(tmp_path, k):
    vif, partes = _opcion_mesa(k)
    return _correr(tmp_path, CASOS_U5.replace("@VIF@", json.dumps(vif)).replace("@ETQ@", json.dumps(partes)))


def test_u5_a_donde_marca_la_mesa_unida_a_esta_cuenta_en_node(tmp_path):
    r = _correr_u5(tmp_path / "ahora", _caja())
    juntan = "Mesa 8 (tiene cuenta abierta: se juntan)"
    # desde la Mesa 6 o la 7 (la misma cuenta, «Mesa 6 + Mesa 7»), la otra dice que está unida a esta cuenta; la Mesa 8, con su propia cuenta, que se
    # juntan; la Mesa 9, libre, solo su nombre
    assert r["desde6"] == {"nombre": "Mesa 6 + Mesa 7", "etq": ["Mesa 7 (unida a esta cuenta)", juntan, "Mesa 9"]}, r
    assert r["desde7"] == {"nombre": "Mesa 6 + Mesa 7", "etq": ["Mesa 6 (unida a esta cuenta)", juntan, "Mesa 9"]}, r
    # desde la Mesa 9 (una cuenta nueva) las mesas 6 y 7 son de otra cuenta: se juntan
    assert r["desde9"] == {"cuenta": None, "etq": ["Mesa 6 (tiene cuenta abierta: se juntan)", "Mesa 7 (tiene cuenta abierta: se juntan)", juntan]}, r

    # antes de esta vuelta: la mesa unida a esta misma cuenta decía «tiene cuenta abierta: se juntan» (al elegirla, V6 avisa que ya está unida)
    v = _correr_u5(tmp_path / "antes", _caja_sin_decimocuarta())
    assert v["desde6"]["etq"] == ["Mesa 7 (tiene cuenta abierta: se juntan)", juntan, "Mesa 9"] and v["desde7"]["etq"][0] == "Mesa 6 (tiene cuenta abierta: se juntan)", v
    assert v["desde9"] == r["desde9"], v


# ================================================================================================================ contrato
def _quitar14(k: str) -> str:
    """La línea entera de quitar y, si las tiene justo arriba, las dos líneas de su comentario de esta vuelta."""
    i = k.index("    " + QUITAR)
    j = k.rfind("    /* 4.39 (decimocuarta vuelta): la cantidad guardada", 0, i)
    return k[j if j >= 0 and k.count("\n", j, i) == 2 else i:k.index("\n", i)]


def test_contrato_de_la_decimocuarta_vuelta():
    # 4.39 (decimoquinta vuelta): «ahora» es caja.js sin la decimoquinta vuelta (la decimoquinta cambió la línea de U2 y devolvió a su línea el comentario
    # de la tercera vuelta que la seguía; su contrato está en tests/test_439_decimoquinta_vuelta.py)
    k, k0 = _caja_sin_decimoquinta(), _caja_sin_decimocuarta()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    qk, qk0 = _quitar14(k), _quitar14(k0)
    # cada tripleta de DECIMOCUARTA: «lo de ahora» está en caja.js las veces anotadas, en su método (o en la plantilla); «lo de antes» ya no está (salvo
    # dentro de «lo de ahora»: U2 agrega líneas después de la de la habitación, que sigue). Se deshacen en orden inverso: «lo de antes» de cada una está,
    # las veces anotadas, en caja.js con las que van después ya deshechas, y al final queda caja.js sin la vuelta. Los tres métodos y quitar cambiaron
    assert len(DECIMOCUARTA) == 6 and len(DE_CADA) == 6
    plantilla, estado = k[k.index("  template: `"):], k
    for (viejo, nuevo, veces), c in reversed(list(zip(DECIMOCUARTA, DE_CADA))):
        assert estado.count(nuevo) == veces and k.count(nuevo) == veces and k0.count(nuevo) == 0, nuevo[:120]
        estado = estado.replace(nuevo, viejo)
        assert estado.count(viejo) == veces and estado.count(nuevo) == 0, nuevo[:120]
        assert k.count(viejo) == (veces if viejo in nuevo else 0), nuevo[:120]
        donde = plantilla if c is None else qk if c == QUITAR else metodos[c]
        assert donde.count(nuevo) == veces, (c, nuevo[:120])
    assert estado == k0
    for c in metodos:
        assert metodos[c] != antes[c], c
    assert qk != qk0 and qk0.startswith("    " + QUITAR) and qk.startswith("    /* 4.39 (decimocuarta vuelta)")
    # fuera de ellos (y de «A dónde»), caja.js no cambió: ningún método nuevo (los arneses sacan los métodos por texto)
    u5a, u5b = DECIMOCUARTA[4][:2]
    resto, resto0 = k.replace(qk, "@QUITAR@").replace(u5b, "@DONDE@"), k0.replace(qk0, "@QUITAR@").replace(u5a, "@DONDE@")
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], "@" + c + "@"), resto0.replace(antes[c], "@" + c + "@")
    assert resto == resto0
    # lo de la vuelta lleva su comentario (U1, U2, U3 y U4; U5 está en la plantilla y U6 es el comentario de V6)
    assert k.count("4.39 (decimocuarta vuelta)") == 4 and k0.count("4.39 (decimocuarta vuelta)") == 0
    te, fa, cd = (metodos[c] for c in CAMBIADOS)
    # U1: con la clave de anular, la cantidad de la base (o 1) y, en una línea partida o marcada, su 2x1 de la base vuelven ANTES de pedir la clave, con las
    # promociones vueltas a calcular; con la clave negada, sale; con la dada, se quita como siempre (y se vuelve a calcular el 2x1 de las que quedan)
    for t in ("l.cantidad = b && +b.cantidad > 0 ? +b.cantidad : 1;", "for (const k of ['descuento_pct', 'descuento', 'promo', 'promo_fija', 'promo_fija_de'])",
              "this.aplicarPromos(); } if (!(await this.autorizar('Quitar ' + l.detalle + ' ya enviado a cocina'))) return; }",
              "this.lineas = this.lineas.filter(x => x !== l); this.aplicarPromos(); this.cuentaVacia(); }"):
        assert qk.count(t) == 1, t
    assert qk.index("l.cantidad = b && +b.cantidad > 0") < qk.index("await this.autorizar(") < qk.index("this.lineas = this.lineas.filter(x => x !== l);")
    assert "if (b && ((typeof l.de === 'string' && l.de !== '') || l.promo_fija || l.promo_fija_de))" in qk and "this._base.id === this.esperaId" in qk
    # U2: después de la guarda de la habitación y antes de las teclas; solo F9, F8 y F4, sin la ventana de cobro, con el cursor en una casilla numérica
    u2 = "if (['F9', 'F8', 'F4'].includes(e.key) && !this.pago && e.target && e.target.type === 'number' && typeof e.target.blur === 'function') { const v = e.target.value; e.target.blur(); if (!(+v > 0) || this.lineas.some(l => !(+l.cantidad > 0))) { e.preventDefault(); return; } }"
    assert te.count(u2) == 1 and te.index("if (this.habCargo &&") < te.index(u2) < te.index("if (e.key === 'F9')")
    assert te.index("const v = e.target.value;") < te.index("e.target.blur();")
    # el comentario de la tercera vuelta de la línea de la habitación quedó al final de la línea de U2 (así lo aplicó el guion de la vuelta: solo texto)
    assert te.split("\n")[1] == "      if (this.habCargo && ['F9', 'F10', 'F8', 'F4'].includes(e.key)) { e.preventDefault(); return; }"
    # U3: en la primera guarda de fusionarAbierta; nunca para el cobro
    u3 = "(!cobro && typeof document !== 'undefined' && document.activeElement && document.activeElement.type === 'number' && this.lineas.some(l => !(+l.cantidad > 0)))"
    assert fa.count(u3) == 1 and fa.index(u3) < fa.index("return nada;") < fa.index("const g0 = enEspera()")
    # U4: las cuentas «· parte k de n» sin líneas en 0; la parte 1 (quedan) sigue igual
    assert cd.count("parte.filter(x => x.cantidad > 0).map(x => ({ ...x }))") == 1 and cd.count("parte.map(x => ({ ...x }))") == 0
    assert _tramo(cd, "const quedan = ", "\n") == _tramo(antes["async confirmarDividir() {"], "const quedan = ", "\n")
    # U5: la mesa unida a esta cuenta en «A dónde»; U6: el comentario de V6 ya no dice que se duplicaba el plato
    assert plantilla.count("cuentaDeMesaId(m.id).id === esperaId ? ' (unida a esta cuenta)' : ' (tiene cuenta abierta: se juntan)'") == 1
    assert cd.count("antes avisaba en falso que los pasó y, al pasar todos, la cuenta se borraba sin cobrar */") == 1 and "antes se duplicaba el plato" not in k
    # las notas de la versión cuentan la vuelta: la mesa unida en el párrafo de «Dividir», «Cantidad en 0» (la clave negada, F4/F8/F9 sin salir de la casilla
    # y la sincronización mientras se escribe), Técnico (la decimocuarta vuelta) y las listas de pruebas; cada frase nueva una vez. 4.39 (decimoquinta
    # vuelta): la frase de la sincronización («Mientras se escribe una cantidad…») y el final de la lista de pruebas cambiaron en la decimoquinta: salen de
    # aquí y van al contrato de la decimoquinta
    notas = (RAIZ / "notas" / "4.39.md").read_text(encoding="utf-8")
    for t in ("Pasar platos a una mesa unida a la misma cuenta avisa que ya está unida, y en «A dónde» esa mesa dice «unida a esta cuenta» (antes decía que "
              "los había pasado, sin moverlos, con un aviso falso de un plato agregado en otro equipo; y al pasar todos, la cuenta se borraba sin cobrarla).",
              "- [arreglo] **Cantidad en 0.** Escribir 0 en la cantidad de un plato lo quita, como «✕» (con la clave de anular si ya se mandó a cocina; si no se "
              "da, el plato vuelve a su cantidad). Si después del 0 se toca F4, F8 o F9 sin salir de la casilla, primero se quita el plato (o se pide la clave) y "
              "hay que tocar la tecla otra vez.",
              "Decimocuarta vuelta: quitar devuelve la cantidad de la base (y las marcas del 2x1 de una línea partida o marcada) antes de pedir la clave; tecla "
              "deja la casilla numérica con F9, F8 y F4 y no sigue si tenía 0 o queda un plato en 0; fusionarAbierta no junta (salvo el cobro) mientras el "
              "cursor está en una casilla numérica con un plato en 0 o vacío; las partes iguales sin mesa no pasan líneas en 0; «A dónde» marca la mesa unida "
              "a esta cuenta.",
              "test_431_cobro_reclamo_pantallas.py, test_431_promos_2x1.py, test_432_caja_pedidos_web.py y test_49_revendedoras_caja.py."):
        assert notas.count(t) == 1, t
    # la decimocuarta va después de la decimotercera en Técnico
    assert notas.index("Decimotercera vuelta: aceptarWeb anota") < notas.index("Decimocuarta vuelta: quitar devuelve")
    # y ya no dicen lo de antes
    for t in ("(antes duplicaba el plato y, al pasar todos, la cuenta se borraba sin cobrarla)", "de test_439_segunda_vuelta.py a test_439_decimotercera_vuelta.py",
              "test_431_cobro_reclamo_pantallas.py, test_432_caja_pedidos_web.py", "(con la clave de anular si ya se mandó a cocina). Antes"):
        assert notas.count(t) == 0, t
