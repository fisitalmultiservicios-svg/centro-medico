# -*- coding: utf-8 -*-
"""4.25 (tanda 9c, pantallas): los últimos arreglos de pantallas que salieron de las pruebas de punta a punta 2 y 3 y de la revisión de la
9b (J1 a J13). Solo archivos de app/static/js. Donde se puede, la lógica corre en Node con los módulos de verdad y sustitutos mínimos de
los demás (como tests/test_425_impresion_local.py y tests/test_425_punta_a_punta.py); lo demás, por el texto de las pantallas.
Nada va a una impresora, a la red ni a un servidor."""
import json
import pathlib
import re
import shutil
import subprocess

import pytest

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")
TOCADOS = ("app.js", "conexion-local.js", "pages/conectar.js", "pages/configuracion/instalacion-local.js", "pages/reportes/_montos.js",
           "pages/reportes/reporte.js", "pages/reportes/revendedora.js", "pages/reportes/revendedoras.js", "pages/pos/_agente.js",
           "pages/pos/caja.js", "pages/pos/cierres.js", "pages/pos/configuracion.js", "pages/pos/reportes.js",
           "pages/inventario/_etiquetas-dialogos.js", "pages/inventario/items.js", "pages/inventario/item-form.js")


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def _nodo():
    return shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)


def _node(tmp_path, guion, archivos, falsos):
    """Corre un guion de Node sobre los archivos de app/static/js tal como están (los demás módulos, con un sustituto mínimo)."""
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    raiz = tmp_path / "js"
    for ruta, texto in (falsos or {}).items():
        (raiz / ruta).parent.mkdir(parents=True, exist_ok=True)
        (raiz / ruta).write_text(texto, encoding="utf-8")
    for rel in archivos:
        (raiz / rel).parent.mkdir(parents=True, exist_ok=True)
        (raiz / rel).write_text(_js(rel), encoding="utf-8")
    (tmp_path / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout.strip().splitlines()[-1])


# un componente montado sobre un objeto corriente: datos, computadas y métodos
MONTAR = """
function montar(C, extra) {
  const vm = Object.assign({ $emit() {}, $nextTick: f => f && f() }, extra || {});
  Object.assign(vm, C.data ? C.data.call(vm) : {});
  for (const [k, f] of Object.entries(C.computed || {})) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(C.methods || {})) vm[k] = typeof f === 'function' ? f.bind(vm) : f;
  return vm;
}
"""
MEMORIA = """
const mem = {};
globalThis.sessionStorage = { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } };
"""


# ================================================================================================================ J1
FALSO_API_J1 = """
export const money = v => String(v), fmt = v => String(v), fecha = v => String(v), hoy = () => '2026-11-11', toast = () => {}, abrirArchivo = async () => {};
export const monedas = { principal: () => ({ codigo: 'CRC' }) };
export const mock = { get: (k, d) => d };
export const api = async (url, opt) => globalThis.Q.api(url, opt);
"""


def test_j1_reportes_y_cierres_ofrecen_las_impresoras_como_valen_en_esta_computadora(tmp_path):
    r = _node(tmp_path, """
globalThis.Q = { pedidos: [], es_local: false, lista: [] };
Q.api = async (url) => { Q.pedidos.push(url); if (url === '/api/agente/estado') return { agente: 'FISITAAP ERP' }; if (url === '/api/agente/equipo') return { equipo: Q.eq, empresa_web: true }; throw new Error('?'); };
const M = await import('./js/pages/reportes/_montos.js');
const CAJA = { id: 1, nombre: 'Tiquetes Empresa', uso: 'comprobante', conexion: 'red', direccion: '127.0.0.1:9198', ancho: 80, activa: true };
const NAV = { id: 2, nombre: 'Caja del navegador', uso: 'comprobante', conexion: 'navegador', direccion: '', ancho: 80, activa: true };
const COCINA = { id: 3, nombre: 'Cocina', uso: 'comanda', conexion: 'navegador', direccion: '', activa: true };
const ETQ = { id: 4, nombre: 'Etiquetas Empresa', uso: 'etiquetas', conexion: 'red', direccion: '127.0.0.1:9199', activa: true };
const APAGADA = { id: 5, nombre: 'Vieja', uso: 'comprobante', conexion: 'usb', direccion: 'X', activa: false };
Q.lista = [CAJA, NAV, COCINA, ETQ, APAGADA];
Q.eq = { propias: [{ id: 'eq-t', nombre: 'Tiquetes solo aqui', uso: 'comprobante', conexion: 'red', direccion: '127.0.0.1:9102', activa: true },
                   { id: 'eq-e', nombre: 'Etiquetas solo aqui', uso: 'etiquetas', conexion: 'red', direccion: '127.0.0.2', activa: true }],
         ajustes: { '1': { conexion: 'red', direccion: '127.0.0.1:9101' }, '2': { conexion: 'usb', direccion: 'EPSON TM-T20' } }, tiquetes: 'eq-t', etiquetas: '' };
const d = i => [i.nombre, i.conexion, i.direccion];
const out = {};
// en la web: como antes (solo las de la empresa que ya son USB o de red) y no se pide nada
out.web = [await M.cargarImpresorasReporte(), M.impresorasReporte().map(d), Q.pedidos.slice()];
// en el programa: se carga lo de esta computadora y la lista sale como vale aquí; la elegida de esta computadora va primero
Q.es_local = true;
out.programa = [await M.cargarImpresorasReporte(), M.impresorasReporte().map(d), Q.pedidos.slice()];
// sin la de tiquetes elegida: las de la empresa (con sus ajustes) y las propias de tiquetes
Q.eq.tiquetes = ''; const A = await import('./js/pages/pos/_agente.js'); A.ponerEquipo(Q.eq);
out.sin_elegida = M.impresorasReporte().map(d);
// la función pura, con lo de esta computadora vacío: nada
out.vacio = M.impresorasReporteAqui(Q.lista, A, null);
console.log(JSON.stringify(out));
""", archivos=("pages/reportes/_montos.js", "pages/pos/_agente.js"),
        falsos={"api.js": FALSO_API_J1, "app.js": "export const sesion = { get empresaInfo() { return { es_local: globalThis.Q.es_local }; } };\n",
                "pages/pos/_datos.js": "export const impresoras = () => globalThis.Q.lista;\n"})
    assert r["web"] == [False, [["Tiquetes Empresa", "red", "127.0.0.1:9198"]], []], r
    assert r["programa"][0] is True and r["programa"][2] == ["/api/agente/estado", "/api/agente/equipo"], r
    assert r["programa"][1] == [["Tiquetes solo aqui", "red", "127.0.0.1:9102"], ["Tiquetes Empresa", "red", "127.0.0.1:9101"],
                                ["Caja del navegador", "usb", "EPSON TM-T20"]], r                     # la «del navegador» de la web aparece: aquí es USB
    assert r["sin_elegida"] == [["Tiquetes Empresa", "red", "127.0.0.1:9101"], ["Caja del navegador", "usb", "EPSON TM-T20"],
                                ["Tiquetes solo aqui", "red", "127.0.0.1:9102"]], r
    assert r["vacio"] == [], r
    m = _js("pages/reportes/_montos.js")
    # la lista de la web sigue igual y la impresión sigue cargando lo de esta computadora antes de imprimir (9b, U16)
    assert "return impresoras().filter(i => i.activa !== false && i.uso !== 'etiquetas' && porAgente(i));" in m
    assert "if (A.cargarEquipo) await A.cargarEquipo().catch(() => {});" in m
    # _agente.js se sigue cargando con import() dinámico (las pruebas viejas montan _montos.js con un _agente.js reducido)
    assert [x for x in m.splitlines() if x.startswith("import ") and "_agente.js" in x] == ["import { porAgente, imprimirAgente } from '../pos/_agente.js';"]
    for rel in ("pages/pos/reportes.js", "pages/pos/cierres.js"):
        p = _js(rel)
        assert "mounted() { cargarImpresorasReporte().then(() => { this.impsListas = true; }); }," in p, rel
        assert "impresorasLista() { return this.impsListas ? impresorasReporte() : []; }," in p, rel
        assert "impsListas: false" in p and "cargarImpresorasReporte } from '../reportes/_montos.js';" in p, rel
    # la impresión del reporte sigue pasando por la función única
    assert "if (A.impresoraAqui) impresora = A.impresoraAqui(impresora);" in m


# ================================================================================================================ J2 y J3
def _modulo_configuracion(tmp_path):
    """Las piezas puras de pos/configuracion.js (la constante, la regla y el método eqConPuerto), copiadas tal como están."""
    cfg = _js("pages/pos/configuracion.js")
    lineas = [x for x in cfg.splitlines() if x.startswith("export const ETQ_SIN_PUERTO") or x.startswith("export function etiquetaConPuerto")]
    metodo = _tramo(cfg, "    eqConPuerto(eq) {", "\n    },\n") + "\n    },\n"
    return "\n".join(lineas) + "\nexport const metodos = {\n" + metodo + "};\n"


def test_j2_la_impresora_de_etiquetas_por_red_no_acepta_puerto(tmp_path):
    (tmp_path / "js").mkdir()
    (tmp_path / "js" / "cfg.js").write_text(_modulo_configuracion(tmp_path), encoding="utf-8")
    r = _node(tmp_path, """
const M = await import('./js/cfg.js');
const out = {};
out.regla = [M.etiquetaConPuerto('etiquetas', 'red', '192.168.1.60:9101'), M.etiquetaConPuerto('etiquetas', 'red', '192.168.1.60'),
             M.etiquetaConPuerto('comprobante', 'red', '192.168.1.60:9101'), M.etiquetaConPuerto('etiquetas', 'usb', 'Zebra:1')];
const vm = { imps: [{ id: 4, uso: 'etiquetas' }, { id: 1, uso: 'comprobante' }], eq: null, eqConPuerto: M.metodos.eqConPuerto };
const caso = eq => vm.eqConPuerto(eq);
out.empresa_etq = caso({ propias: [], ajustes: { '4': { conexion: 'red', direccion: '192.168.1.60:9100' } } });
out.empresa_tiq = caso({ propias: [], ajustes: { '1': { conexion: 'red', direccion: '192.168.1.50:9101' } } });
out.empresa_bien = caso({ propias: [], ajustes: { '4': { conexion: 'red', direccion: '192.168.1.60' } } });
out.propia_etq = caso({ propias: [{ id: 'eq-e', uso: 'etiquetas', conexion: 'red', direccion: '10.0.0.5:9100' }], ajustes: {} });
out.propia_tiq = caso({ propias: [{ id: 'eq-t', uso: 'comprobante', conexion: 'red', direccion: '10.0.0.5:9101' }], ajustes: {} });
out.mensaje = M.ETQ_SIN_PUERTO;
console.log(JSON.stringify(out));
""", archivos=(), falsos={})
    assert r["regla"] == [True, False, False, False], r
    assert [r["empresa_etq"], r["empresa_tiq"], r["empresa_bien"], r["propia_etq"], r["propia_tiq"]] == [True, False, False, True, False], r
    assert r["mensaje"] == "La impresora de etiquetas por red se escribe solo con su dirección IP (sin «:puerto»)."
    cfg = _js("pages/pos/configuracion.js")
    # el formulario de una impresora solo de esta computadora y el guardado de lo de esta computadora
    assert "if (f.solo_aqui && etiquetaConPuerto(f.uso, f.conexion, (f.direccion || '').trim())) return toast(ETQ_SIN_PUERTO, 'err');" in cfg
    guardar = _tramo(cfg, "    async guardarEq() {", "    async probarAqui(i) {")
    assert guardar.index("if (this.eqConPuerto()) { toast(ETQ_SIN_PUERTO, 'err'); return false; }") < guardar.index("'/api/agente/equipo'")
    # las de tiquetes siguen aceptando el puerto (la regla de siempre)
    assert "if (f.conexion === 'red' && !/^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?$/.test((f.direccion || '').trim()))" in cfg


def test_j3_un_solo_nombre_para_cada_conexion_en_lo_que_solo_ve_el_programa():
    cfg = _js("pages/pos/configuracion.js")
    assert "const CONEXIONES_AQUI = [['', 'Igual que en la configuración'], ['usb', 'Impresora de Windows (USB)'], ['red', 'Por red (dirección IP)']];" in cfg
    assert "const CONEXIONES_PROPIA = [['usb', 'Impresora de Windows (USB)'], ['red', 'Por red (dirección IP)']];" in cfg
    assert "conexionesForm() { if (this.impForm && this.impForm.solo_aqui) return CONEXIONES_PROPIA;" in cfg
    # la tarjeta «En esta computadora» y la lista de las de esta computadora usan los nombres del programa
    tarjeta = _tramo(cfg, '<div id="cfg-equipo"', '<div id="cfg-restaurante"')
    assert "conexionTexto(" not in tarjeta and tarjeta.count("conexionAqui(i)") == 2
    assert "agente local" not in tarjeta.lower() and "instalable" not in tarjeta.lower()
    metodo = _tramo(cfg, "    conexionAqui(i) {", "\n")
    assert "'Impresora de Windows (USB)'" in metodo and "'Por red (dirección IP)'" in metodo and "agente" not in metodo
    # el formulario de una solo de esta computadora: «La imprime este programa.»; el de la empresa (lo que se ve en la web) sigue igual
    assert ":help=\"impForm.conexion==='navegador' ? 'No aplica: elige la impresora al imprimir' : impForm.solo_aqui ? 'La imprime este programa.' : 'La usará el agente local del instalable'\"" in cfg
    assert "export const CONEXIONES_IMPRESORA = [['navegador', 'Impresora del navegador'], ['usb', 'USB en la computadora (agente local)'], ['red', 'De red (agente local)']];" in _js("pages/pos/_datos.js")
    assert "elija «Impresora de Windows (USB)» o «Por red (dirección IP)»" in cfg


# ================================================================================================================ J4
def test_j4_el_aviso_no_repite_el_nombre_de_la_impresora(tmp_path):
    r = _node(tmp_path, """
const A = await import('./js/pages/pos/_agente.js');
const e = m => new Error(m);
console.log(JSON.stringify([
  A.avisoImpresion('No se imprimió en «Caja»: ', e('La impresora «Caja» no responde: revise que esté encendida y conectada a la red')),
  A.avisoImpresion('No se pudo imprimir en «Caja»: ', e('Windows no encuentra la impresora «Caja»')),
  A.avisoImpresion('No se imprimió en «Caja»: ', e('timed out')),
  A.avisoImpresion('No se imprimió: ', e('El agente de impresión no responde en esta computadora')),
  A.nombraImpresora('  La impresora «X» no responde'), A.nombraImpresora('Impresora apagada'),
]));
""", archivos=("pages/pos/_agente.js",), falsos={"api.js": "export const api = async () => ({}), fmt = v => String(v), fecha = v => String(v);\n"})
    assert r == ["La impresora «Caja» no responde: revise que esté encendida y conectada a la red", "Windows no encuentra la impresora «Caja»",
                 "No se imprimió en «Caja»: timed out", "No se imprimió: El agente de impresión no responde en esta computadora", True, False], r
    # la usan todas las pantallas que anteponían la impresora
    caja, cierres, cfg = _js("pages/pos/caja.js"), _js("pages/pos/cierres.js"), _js("pages/pos/configuracion.js")
    assert caja.count("toast(avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e) + '. Se abre") == 2
    assert "toast(avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e) + '. Se abre la colilla en el navegador.', 'err');" in cierres
    assert "toast(avisoImpresion('No se imprimió: ', e), 'err');" in cierres
    assert cfg.count("toast(avisoImpresion('No se pudo imprimir en «'") == 3
    assert "toast(avisoImpresion('No se imprimió: ', e), 'err');" in _js("pages/pos/reportes.js")
    dlg = _js("pages/inventario/_etiquetas-dialogos.js")
    assert dlg.count("toast(await avisoImpresion('No se imprimió en «' + imp.nombre + '»: ', e)") == 2
    for rel in ("pages/reportes/reporte.js", "pages/reportes/revendedora.js", "pages/reportes/revendedoras.js"):
        assert "catch (e) { toast(await avisoImpresion('No se imprimió' + (imp ? ' en «' + imp.nombre + '»' : '') + ': ', e), 'err'); }" in _js(rel), rel
    # en esas cuatro la ayuda se carga al usarla (las pruebas viejas las montan con un _agente.js o un _montos.js reducido)
    for rel in ("pages/inventario/_etiquetas-dialogos.js", "pages/reportes/reporte.js", "pages/reportes/revendedora.js", "pages/reportes/revendedoras.js"):
        assert "const A = await import('../pos/_agente.js'); if (A.avisoImpresion) return A.avisoImpresion(prefijo, e);" in _js(rel), rel
    # ya no queda ninguna pantalla que anteponga la impresora a mano
    for rel in TOCADOS:
        assert not re.search(r"toast\('No se (imprimió|pudo imprimir) en «' \+ [^)]*\+ '»: ' \+ e\.message", _js(rel)), rel


def test_j4_el_cuadro_de_etiquetas_con_el_agente_de_verdad(tmp_path):
    """El cuadro de etiquetas con pos/_agente.js de verdad: el servicio responde que la impresora no responde (ya la nombra)."""
    from tests.test_424_pulido import ARCHIVOS_CUADRO, FALSO_API, FALSO_APP, MONTAR as MONTAR_CUADRO
    r = _node(tmp_path, MONTAR_CUADRO.replace("const { DialogoEtiquetas }", "Q.api = async (url) => { if (url === '/api/agente/estado') return { agente: 'FISITAAP ERP', etiquetas: 1 }; const x = new Error('La impresora «Etiquetas bodega» no responde: revise que esté encendida y conectada a la red'); x.status = 500; throw x; };\nconst { DialogoEtiquetas }") + """
Q.mock.pos_impresoras = [IMP];
const vm = montar(PRODS); await vm.imprimir(false);
console.log(JSON.stringify({ toasts: Q.toasts, pdf: Q.abiertos.length }));
""", archivos=["/".join(x) for x in ARCHIVOS_CUADRO] + ["pages/pos/_agente.js"], falsos={"api.js": FALSO_API, "app.js": FALSO_APP})
    assert r["toasts"] == [["La impresora «Etiquetas bodega» no responde: revise que esté encendida y conectada a la red", "err"]] and r["pdf"] == 0, r


# ================================================================================================================ J5 y J6
FALSOS_ITEMS = {
    "api.js": """
export const toast = (m, t) => globalThis.Q.toasts.push([m, t || '']);
export const api = async (url, opt) => globalThis.Q.api(url, opt);
export const money = v => String(v), fmt = v => String(v), fmtCant = v => String(v), opts = () => [], CAT = {};
export const monedas = { principal: () => ({ codigo: 'CRC' }) };
export const mock = { get: (k, d) => d, set() {}, actualizar: (k, f, d) => { const x = {}; f(x); return x; } };
""",
    "app.js": "export const store = { poner() {}, quitar() {} };\nexport const sesion = { get empresaInfo() { return globalThis.Q.info; }, puede: () => true };\n",
    "pages/reportes/_montos.js": "export const exportarFilas = () => {};\n",
    "pages/inventario/_etiquetas.js": "export const normCodigo = x => x;\n",
    "pages/inventario/_etiquetas-dialogos.js": "export const DialogoRegistrarCodigos = {}, DialogoGenerarCodigos = {}, DialogoEtiquetas = {};\n",
}


def test_j5_acciones_en_bloque_dicen_por_que_y_no_esperan_por_cada_item_de_la_web(tmp_path):
    r = _node(tmp_path, MONTAR + """
const MSG = 'No se pudo guardar: este ítem se creó en la página web y sus cambios se guardan allá. Revise la conexión a internet e inténtelo de nuevo.';
globalThis.Q = { toasts: [], pedidos: [], info: { es_local: true, rango_items: 2 } };
// ítems de aquí: 20000001…; de la web: 1, 2, 3 (fuera del rango 2 = 20000000–29999999)
Q.api = async (url, opt) => { const id = +url.split('/').pop(); Q.pedidos.push([opt.method, id]); if (id < 10000000) { const e = new Error(MSG); e.status = 503; throw e; } return opt.method === 'DELETE' ? {} : { id, activo: opt.body.activo }; };
const C = (await import('./js/pages/inventario/items.js')).default;
const I = await import('./js/pages/inventario/items.js');
const vm = { cargar: async () => {}, extra: {} };                    // solo los métodos (los datos de la lista no hacen falta)
for (const [k, f] of Object.entries(C.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f;
vm.bodyDe = r => ({ nombre: r.nombre }); vm.cargar = async () => {};
const filas = [{ id: 1, nombre: 'Harina Web' }, { id: 20000001, nombre: 'Plato Local' }, { id: 2, nombre: 'Azúcar Web' }, { id: 3, nombre: 'Arroz Web' }];
const out = {};
await vm.activarVarios(filas, false); out.desactivar = [Q.toasts.pop(), Q.pedidos.splice(0)];
await vm.eliminarVarios(filas); out.eliminar = [Q.toasts.pop(), Q.pedidos.splice(0)];
// un error que no es de la web (por ejemplo un 409 de un ítem de aquí) no corta los demás
Q.api = async (url, opt) => { const id = +url.split('/').pop(); Q.pedidos.push([opt.method, id]); if (id === 20000001) throw new Error('Ya existe otro producto con el código X'); return { id }; };
await vm.activarVarios([{ id: 20000001 }, { id: 20000002 }], true); out.otro = [Q.toasts.pop(), Q.pedidos.splice(0)];
// todo bien: el aviso de siempre
await vm.activarVarios([{ id: 20000002 }], true); out.bien = Q.toasts.pop();
// en la web (sin rango_items) nada es «de la web»: se intentan todos
Q.info = { es_local: false };
out.web = [I.itemDeLaWeb(1), I.itemDeLaWeb(20000001)];
Q.info = { es_local: true, rango_items: 2 };
out.programa = [I.itemDeLaWeb(1), I.itemDeLaWeb(20000001), I.itemDeLaWeb(30000001), I.itemDeLaWeb(5, { es_local: true, rango_items: -1 })];
out.avisos = [I.avisoBloque('3 ítems activados', 0, 'x'), I.avisoBloque('0 ítems activados', 2, ''), I.avisoBloque('1 ítem activado', 1, '  Falló.  ')];
console.log(JSON.stringify(out));
""", archivos=("pages/inventario/items.js",), falsos=FALSOS_ITEMS)
    MSG = "No se pudo guardar: este ítem se creó en la página web y sus cambios se guardan allá. Revise la conexión a internet e inténtelo de nuevo."
    assert r["desactivar"][0] == ["1 ítem desactivado. 3 no se guardaron: " + MSG, "err"], r
    assert r["desactivar"][1] == [["PUT", 1], ["PUT", 20000001]], r                 # después del primero de la web, los demás de la web no se intentan
    assert r["eliminar"][0] == ["1 ítem eliminado. 3 no se guardaron: " + MSG, "err"], r
    assert r["eliminar"][1] == [["DELETE", 1], ["DELETE", 20000001]], r
    assert r["otro"] == [["1 ítem activado. 1 no se guardó: Ya existe otro producto con el código X", "err"], [["PUT", 20000001], ["PUT", 20000002]]], r
    assert r["bien"] == ["1 ítem activado", "ok"], r
    assert r["web"] == [False, False] and r["programa"] == [True, False, True, True], r
    assert r["avisos"] == ["3 ítems activados", "0 ítems activados. 2 no se guardaron.", "1 ítem activado. 1 no se guardó: Falló."], r
    # la misma cuenta que la ficha (item-form.js deLaWeb)
    ficha = _js("pages/inventario/item-form.js")
    assert "const r = sesion.empresaInfo?.es_local ? +(sesion.empresaInfo?.rango_items || 0) : 0; return !!(r && this.editando && (r < 0 || Math.floor(+this.params.id / 10000000) !== r));" in ficha


def test_j6_la_ficha_de_un_item_de_la_web_no_pide_quitar_la_imagen():
    ficha = _js("pages/inventario/item-form.js")
    assert "} else if (this.editando && !f.imagen && !this.deLaWeb) { try { await api(`/api/productos/${p.id}/imagen`, { method: 'DELETE' }); } catch {} }" in ficha
    assert ficha.count("{ method: 'DELETE' }") == 1


# ================================================================================================================ J7
FALSO_API_CONECTAR = """
export const toast = () => {};
export const api = async (url, opt) => {
  globalThis.Q.pedidos.push([url, opt && opt.body]);
  if (url === '/api/auth/estado') return {};
  if (url === '/api/sinc/conexion/seguimiento') return { estado: globalThis.Q.seguimiento || 'aprobada' };
  return { codigo: opt.body.codigo, nombre: 'Caja ' + opt.body.codigo, empresas: [] };
};
"""
FALSO_APP_CONECTAR = """
export const sesion = { empresa_id: null, puede: () => false };
export const conexion = { codigo: '', fijar(c) { this.codigo = c; }, limpiar() { this.codigo = ''; },
  leerPase() { return globalThis.Q.pase; }, fijarPase(p) { globalThis.Q.pase = p || null; } };
"""


def test_j7_un_codigo_nuevo_en_la_misma_pestana_sin_recargar(tmp_path):
    r = _node(tmp_path, MONTAR + """
globalThis.Q = { pedidos: [], pase: null };
globalThis.history = { replaceState() {} };
const C = (await import('./js/pages/conectar.js')).default;
const { conexion } = await import('./js/app.js');
const out = {};
const cambiar = async (vm, c) => { conexion.codigo = c; C.watch.codigoPestana.call(vm); await new Promise(r => setTimeout(r, 0)); };
for (const paso of ['listo', 'fin', 'aprobada']) {
  // la pestaña quedó en el «Listo», el final o el seguimiento de la computadora anterior (ABCD-EFGH)
  conexion.codigo = ''; Q.pase = 7; Q.pedidos = [];
  const vm = montar(C); vm.paso = paso; vm.consultado = 'ABCD-EFGH'; vm.aprobada = { pase: 7, nombre: 'Caja Dos' }; vm.final = 'x'; vm._t = setTimeout(() => { out.reloj = 'sigue'; }, 50);
  await cambiar(vm, 'JKLMNPQR');                                   // el enlace nuevo: solo cambia lo que va después de #
  out[paso] = [vm.paso, vm.escrito, Q.pase, vm.aprobada, vm._t, Q.pedidos.map(x => x[0] + ' ' + (x[1] && x[1].codigo))];
}
// el mismo código que ya se buscó, o mientras se escribe uno: nada cambia
const vm = montar(C); vm.paso = 'listo'; vm.consultado = 'JKLM-NPQR'; Q.pedidos = [];
await cambiar(vm, 'JKLM-NPQR'); out.mismo = [vm.paso, Q.pedidos.length];
const vm2 = montar(C); vm2.paso = 'buscar'; vm2.consultado = ''; await cambiar(vm2, 'WXYZ-2345'); out.buscando = [vm2.paso, Q.pedidos.length];
await new Promise(r => setTimeout(r, 80));
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/conectar.js",), falsos={"api.js": FALSO_API_CONECTAR, "app.js": FALSO_APP_CONECTAR})
    for paso in ("listo", "fin", "aprobada"):
        assert r[paso] == ["revisar", "JKLM-NPQR", None, None, None, ["/api/sinc/conexion/consultar JKLM-NPQR"]], (paso, r)
    assert "reloj" not in r                                          # el seguimiento de la anterior se detuvo
    assert r["mismo"] == ["listo", 0] and r["buscando"] == ["buscar", 0], r
    cn = _js("pages/conectar.js")
    assert "codigoPestana() { return conexion.codigo || ''; }," in cn and "watch: { codigoPestana() { this.alCambiarCodigo(); } }," in cn
    assert "alCambiarCodigo() { if (this.esPrograma || !this.codigoNuevo()) return; this.parar(); this.seguirConNuevo(); }," in cn


# ================================================================================================================ J8, J10, J11 y J13
FALSO_API_INSTALACION = """
export const toast = (m, t) => globalThis.Q.toasts.push([m, t || '']);
export const fechaHora = x => x;
export const api = async (url, opt) => { globalThis.Q.pedidos.push([url, opt && opt.body, !!(opt && opt.sinExpirar)]); return {}; };
"""
FALSO_APP_INSTALACION = """
export const sesion = { puede: () => true, get usuario() { return globalThis.Q.usuario; }, cerrar() {},
  async refrescarEmpresas() { globalThis.Q.refrescos++; return {}; } };
"""


def test_j8_j10_j11_instalacion_local_en_node(tmp_path):
    r = _node(tmp_path, MONTAR + MEMORIA + """
globalThis.Q = { toasts: [], pedidos: [], refrescos: 0, usuario: { de_nube: true } };
const C = (await import('./js/pages/configuracion/instalacion-local.js')).default;
const nuevo = (extra) => { const vm = montar(C, extra); vm.cargar = () => { Q.cargas = (Q.cargas || 0) + 1; }; return vm; };
const out = {};
// J8: «Conectar otra empresa» terminó: se vuelve a pedir la lista de empresas de la sesión (la empresa abierta no cambia)
let vm = nuevo(); vm.otra = true; vm.otraLista(); await new Promise(r => setTimeout(r, 0));
out.j8 = [vm.otra, Q.refrescos, Q.cargas];
// J10: la reconexión con sesión llegó a «Listo»: se pone al día la empresa de la sesión y el aviso de «revocada» se esconde
Q.refrescos = 0; vm = nuevo({ $refs: { cx: { v: { estado: 'lista', con_sesion: true, reconexion: true } } } });
vm.estadoConexion('lista'); out.j10 = [vm.cxLista, Q.refrescos, vm.enCurso];
vm.conexionLista({ con_sesion: true }); out.j10.push(vm.cxLista, Q.refrescos);
// sin con_sesion en la vista (servidor anterior): vale que se montó con sesión
Q.refrescos = 0; vm = nuevo({ $refs: { cx: { v: { estado: 'lista' } } } }); vm.estadoConexion('lista'); out.sin_marca = Q.refrescos;
// la vista dice que no sigue con sesión, o la cuenta es de esta computadora (queda retirada): no se pide nada
Q.refrescos = 0; vm = nuevo({ $refs: { cx: { v: { estado: 'lista', con_sesion: false } } } }); vm.estadoConexion('lista');
Q.usuario = { de_nube: false }; vm = nuevo({ $refs: { cx: { v: { estado: 'lista', con_sesion: true } } } }); vm.estadoConexion('lista');
out.sin_sesion = Q.refrescos; Q.usuario = { de_nube: true };
vm.estadoConexion('esperando'); out.esperando = vm.cxLista;
// J11: «Volver» con un intento en curso: el cancelar del componente, y la pestaña queda limpia
let cancelados = 0;
const cx = { v: { intento: 'xyz', estado: 'esperando' }, final: false, async cancelar() { cancelados++; delete mem['conexion:intento']; } };
mem['conexion:intento'] = 'xyz'; mem['conexion:otra'] = 'xyz';
vm = nuevo({ $refs: { otraCx: cx } }); vm.otra = true; vm.enCurso = true;
await vm.volverDeOtra(); out.j11 = [cancelados, vm.otra, vm.enCurso, { ...mem }, Q.pedidos.length];
// el componente todavía no retomó (sin vista): se cancela por la llave guardada de «otra empresa»
mem['conexion:intento'] = 'abc'; mem['conexion:otra'] = 'abc'; Q.pedidos = [];
vm = nuevo({ $refs: { otraCx: { v: null, final: false, parar() {} } } }); vm.otra = true;
await vm.volverDeOtra(); out.sin_vista = [vm.otra, { ...mem }, Q.pedidos];
// ya terminó («Listo»): no se cancela nada
mem['conexion:otra'] = ''; Q.pedidos = [];
vm = nuevo({ $refs: { otraCx: { v: { intento: 'q', estado: 'lista' }, final: false, async cancelar() { cancelados++; }, parar() {} } } }); vm.otra = true;
await vm.volverDeOtra(); out.lista = [cancelados, vm.otra, Q.pedidos.length];
console.log(JSON.stringify(out));
""", archivos=("pages/configuracion/instalacion-local.js",),
        falsos={"api.js": FALSO_API_INSTALACION, "app.js": FALSO_APP_INSTALACION, "conexion-local.js": "export default {};\n"})
    assert r["j8"] == [False, 1, 1], r
    assert r["j10"] == [True, 1, True, False, 2], r                     # en «Listo» tampoco se ofrece «Conectar otra empresa»
    assert r["sin_marca"] == 1 and r["sin_sesion"] == 0 and r["esperando"] is False, r
    assert r["j11"] == [1, False, False, {}, 0], r
    assert r["sin_vista"] == [False, {}, [["/api/sinc/local/conexion/cancelar", {"intento": "abc"}, True]]], r
    assert r["lista"] == [1, False, 0], r
    i = _js("pages/configuracion/instalacion-local.js")
    # J10: el paso final dice solo «Listo» (sin «Tengo un código») y el aviso amarillo se va con él
    assert '<a v-if="!cxLista" class="link small" style="display:inline-block;margin-top:12px;cursor:pointer" @click="conCodigo = true">Tengo un código</a>' in i
    assert '<div class="alert warn" v-if="est.revocada_en && !cxLista" style="margin-bottom:12px"><b>Esta instalación fue revocada en la nube</b>' in i
    assert '<ConexionLocal ref="cx" :web="web"' in i and i.count('<ConexionLocal ref="otraCx" ') == 2
    # J11: los dos «Volver» de «Conectar otra empresa» cancelan
    assert i.count('@click="volverDeOtra">Volver</a>') == 2 and '@click="otra = false">Volver</a>' not in i
    # J13: la confirmación de revocar ya no habla de un código nuevo
    quitar = _tramo(i, "    async quitar(i) {", "    async vincular() {")
    assert "salvo que un administrador la conecte de nuevo. Lo que ya subió se conserva." in quitar and "código nuevo" not in quitar
    aviso = _tramo(_js("app.js"), "    async responderAviso(a, respuesta) {", "    icono(it) {")
    assert "código nuevo" not in aviso and "vincul" not in aviso                # el «Revocar» de «¿reconoce esta computadora?» no lo decía


def test_j8_j10_la_sesion_se_pone_al_dia_sin_recargar():
    a = _js("app.js")
    m = _tramo(a, "  async refrescarEmpresas() {", "\n  },\n")
    assert "api('/api/auth/yo', { sinExpirar: true })" in m                        # la misma consulta de refrescarPermisos; un 401 no cierra nada aquí
    assert "if (!r || !r.usuario || r.usuario.id !== this.usuario?.id || r.empresa_id !== this.empresa_id) return null;" in m
    assert "if (Array.isArray(r.empresas) && JSON.stringify(r.empresas) !== JSON.stringify(this.empresas)) this.empresas = r.empresas;" in m and "iniciar(" not in m and "location" not in m
    assert "get empresaInfo() { return this.empresas.find(e => e.id === this.empresa_id) || null; }," in a   # la franja sale de la misma lista


# ================================================================================================================ J9, J10 y J12 (componente)
def test_j9_j10_j12_componente_de_conexion_en_node(tmp_path):
    r = _node(tmp_path, MONTAR + MEMORIA + """
globalThis.Q = { pedidos: [] };
globalThis.document = { visibilityState: 'visible', addEventListener() {}, removeEventListener() {} };
const C = (await import('./js/conexion-local.js')).default;
const props = p => Object.assign({ web: '', equipo: '', conSesion: false, boton: 'Conectar', otraEmpresa: false }, p);
const out = {};
// J9
const vm = montar(C, props());
out.j9 = [1, 2, 0, null, undefined].map(n => { vm.v = { estado: 'confirmar', intentos_restantes: n }; return vm.textoIntentos; });
// J10: con sesión → «Listo»
const con = montar(C, props({ conSesion: true })), sin = montar(C, props());
const vista = x => Object.assign({ estado: 'lista', intento: 'i' }, x);
con.v = vista({ con_sesion: true }); sin.v = vista({}); out.j10 = [con.sigueConSesion, sin.sigueConSesion];
con.v = vista({}); out.j10.push(con.sigueConSesion);                     // sin la marca: cómo se montó
con.v = vista({ con_sesion: false }); out.j10.push(con.sigueConSesion);
// J12: cada componente retoma solo un intento de su camino
const api = await import('./js/api.js');
const retoma = async (otra, marca) => { Q.pedidos = []; delete mem['conexion:otra']; if (marca) mem['conexion:otra'] = marca; const x = montar(C, props({ conSesion: true, otraEmpresa: otra })); x.programar = () => {}; await x.retomar('abc'); return Q.pedidos.length; };
out.j12 = [await retoma(true, 'abc'), await retoma(true, ''), await retoma(true, 'otro'), await retoma(false, ''), await retoma(false, 'abc'), await retoma(false, 'otro')];
console.log(JSON.stringify(out));
""", archivos=("conexion-local.js",), falsos={"api.js": "export const api = async (url, opt) => { globalThis.Q.pedidos.push(url); return { estado: 'esperando', intento: 'abc' }; };\n"})
    assert r["j9"] == ["Le queda 1 intento.", "Le quedan 2 intentos.", "Le quedan 0 intentos.", "", ""], r
    assert r["j10"] == [True, False, True, False], r
    assert r["j12"] == [1, 0, 0, 1, 0, 1], r
    cx = _js("conexion-local.js")
    assert '<span v-if="textoIntentos"> {{textoIntentos}}</span>' in cx and "Le quedan {{" not in cx
    assert "@click=\"entrar\">{{otraEmpresa || sigueConSesion ? 'Listo' : 'Entrar'}}</button>" in cx
    # la reconexión con sesión ya trae el texto completo del servidor (lista_reconexion): no se repite
    assert '{{v.mensaje}}<template v-if="!v.con_sesion"><template v-if="v.reconexion"> Cada persona tiene que entrar una vez' in cx
    assert "if (intentoDeOtra(id) !== !!this.otraEmpresa) return;" in _tramo(cx, "    async retomar(id) {", "    programar() {")
    # el navegador sigue guardando solo la llave del intento (la marca la escribe la pantalla de Instalación local, con la misma llave)
    assert re.findall(r"sessionStorage\.setItem\(([^;]*)\);", cx) == ["CLAVE_INTENTO, String(id)"]


# ================================================================================================================ sintaxis y finales de línea
def test_archivos_tocados_compilan_y_no_mezclan_finales_de_linea(tmp_path):
    node = _nodo()
    for rel in TOCADOS:
        b = (JS / rel).read_bytes()
        assert b.count(b"\r\n") in (0, b.count(b"\n")), rel
        if node:
            copia = tmp_path / (rel.replace("/", "_") + ".mjs")
            copia.write_bytes(b)
            r = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, encoding="utf-8", timeout=60)
            assert r.returncode == 0, (rel, r.stderr[-2000:])


def test_las_plantillas_tocadas_compilan(tmp_path):
    """El compilador de Vue del proyecto, en Node (el mismo guion de tests/test_424_etiquetas.py): cada plantilla tocada compila y sus
    etiquetas abren y cierran parejo."""
    from tests.test_424_etiquetas import COMPILAR_JS
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    shutil.copy(JS / "vendor" / "vue.esm-browser.prod.min.js", tmp_path / "vue.mjs")
    (tmp_path / "compilar.mjs").write_text(COMPILAR_JS, encoding="utf-8")
    con_plantilla = [x for x in TOCADOS if "template: `" in _js(x)]
    nombres = []
    for rel in con_plantilla:
        nombre = rel.replace("/", "_")
        (tmp_path / nombre).write_text(_js(rel), encoding="utf-8")
        nombres.append(nombre)
    r = subprocess.run([node, "compilar.mjs", *nombres], capture_output=True, text=True, encoding="utf-8", timeout=180, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    o = json.loads(r.stdout)
    assert len(con_plantilla) >= 12
    for nombre in nombres:
        assert o[nombre], nombre
        for p in o[nombre]:
            assert p["errores"] == [] and p["desbalance"] == [], (nombre, p)
