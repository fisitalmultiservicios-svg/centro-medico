# -*- coding: utf-8 -*-
"""4.29 (segunda parte, encargo C): una computadora recién conectada nace con dónde guardar el efectivo.

- B-1. Solo se siembra, nunca se pisa: si la computadora ya tiene el registro «bancos» (aunque esté vacío o sea distinto del de la web),
  no se toca.
- B-2. Sin registro «bancos», el programa recibe UNA vez las cuentas de la web (campo aparte «bancos_iniciales» de GET /api/sinc/catalogo,
  solo para el token de una instalación) y las guarda con saldo inicial 0 y la fecha de hoy; saldos y movimientos de la web no se copian.
- B-3. Si la web no manda cuentas (no tiene, o es una web anterior) y la empresa es de un tipo que en la web nace con «Caja general»
  (restaurante, comercio, hospitalidad: auth.crear_empresa), el programa la crea con modulos.cuenta_efectivo_inicial.
- B-4. El dato va FUERA de «registros»: un programa anterior no lo lee (ni lo aplica como «la nube manda»). «bancos» sigue sin viajar:
  no sube a la nube ni se comparte por la red del local.

La «nube» y la «computadora» son empresas del mismo proceso (como tests/test_49_local_sinc.py)."""
import pathlib

import pytest
from sqlmodel import Session

from app import auth, modulos, sinc
from app.config import ahora_cr
from app.db import Empresa, engine, engine_empresa
from test_49_local_sinc import H, NUBE, _admin_empresa, _Respuesta, _soltar_limite_vinculacion, c

RAIZ = pathlib.Path(__file__).resolve().parents[1]
WEB = [
    {"id": 1, "nombre": "Caja general", "tipo": "Efectivo", "moneda": "CRC", "numero": "", "saldo_inicial": 250000, "fecha_saldo": "2026-01-01", "saldo": 385000,
     "descripcion": "Efectivo del negocio", "principal": False, "cuenta_contable": "1101"},
    {"id": 2, "nombre": "BAC dólares", "tipo": "Banco", "moneda": "USD", "numero": "951 234 567", "saldo_inicial": 8500, "fecha_saldo": "2026-01-01",
     "descripcion": "Cuenta en dólares", "principal": True, "cuenta_contable": "1102"},
    {"id": 3, "nombre": "Banco de ejemplo", "tipo": "Banco", "moneda": "CRC", "numero": "1", "saldo_inicial": 1, "fecha_saldo": "2026-01-01", "ejemplo": True},
]
_n = [0]


def _empresa_local(**extra) -> int:
    """Una empresa «computadora» creada directo en la base (sin tipo: crear_empresa no le siembra Bancos)."""
    _n[0] += 1
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, f"Bancos429 QA {_n[0]}", f"bancos429-{_n[0]}@example.test", f"31014293{_n[0]:02d}", **extra)
        sc.commit(); sc.refresh(e)
        return e.id


def _bancos(eid: int):
    with Session(engine_empresa(eid)) as s:
        return modulos.leer(s, eid, "bancos", None)


def _version_bancos(eid: int):
    with Session(engine_empresa(eid)) as s:
        r = modulos._registro(s, eid, "bancos")
        return None if r is None else r.version


def _poner_bancos(eid: int, lista) -> None:
    with Session(engine_empresa(eid)) as s:
        sinc._escribir(s, eid, "bancos", lista); s.commit()


def _bajar(eid: int, cuerpo: dict, monkeypatch) -> dict:
    """La bajada del catálogo del programa (sinc._bajar) con la respuesta de la nube armada a mano."""
    class _Nube:
        def get(self, url, headers=None, timeout=None):
            assert url == NUBE + "/api/sinc/catalogo"
            return _Respuesta(200, {"empresa": {}, "registros": {}, **cuerpo})
    monkeypatch.setattr(sinc, "httpx", _Nube())
    cfg = {}
    with Session(engine_empresa(eid)) as s, Session(engine) as sc:
        sinc._bajar(s, sc, sc.get(Empresa, eid), cfg, NUBE, {}, 0)
    return cfg


def _esperadas(hoy: str) -> list:
    return [{"id": 1, "nombre": "Caja general", "tipo": "Efectivo", "moneda": "CRC", "numero": "", "descripcion": "Efectivo del negocio", "cuenta_contable": "1101",
             "principal": False, "saldo_inicial": 0, "fecha_saldo": hoy},
            {"id": 2, "nombre": "BAC dólares", "tipo": "Banco", "moneda": "USD", "numero": "951 234 567", "descripcion": "Cuenta en dólares", "cuenta_contable": "1102",
             "principal": True, "saldo_inicial": 0, "fecha_saldo": hoy}]


# ------------------------------------------------------------------------------------------------ lado nube
def test_la_nube_manda_sus_cuentas_en_un_campo_aparte_solo_a_la_instalacion(monkeypatch):
    eid, ta = _admin_empresa("-429c", "3101429399")
    _poner_bancos(eid, WEB)
    _soltar_limite_vinculacion()
    codigo = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": "Caja 429c"}).json()["codigo"]
    r = c.post("/api/sinc/canje", json={"codigo": codigo, "nombre": "Caja 429c"})
    assert r.status_code == 200, r.text
    tok = r.json()["token"]
    assert sinc.CAMPO_BANCOS_INICIALES not in r.json()                      # la vinculación no cambia: va en la bajada del catálogo
    cat = c.get("/api/sinc/catalogo", headers=H(tok)).json()
    # campo aparte, sin saldos, sin la fila de ejemplo; «bancos» NO va dentro de «registros»
    assert cat["bancos_iniciales"] == [{k: v for k, v in x.items() if k not in ("saldo_inicial", "fecha_saldo")} for x in _esperadas("")]
    assert "bancos" not in cat["registros"] and "movimientos" not in cat["registros"]
    assert all("saldo" not in x and "saldo_inicial" not in x and "ejemplo" not in x for x in cat["bancos_iniciales"])
    # a quien no es una instalación (la sesión de la administradora) no se le manda
    otro = c.get("/api/sinc/catalogo", headers=H(ta))
    assert otro.status_code == 200 and sinc.CAMPO_BANCOS_INICIALES not in otro.json()
    # web sin cuentas: lista vacía (el programa cae en «Caja general» si corresponde)
    with Session(engine_empresa(eid)) as s:
        r0 = modulos._registro(s, eid, "bancos")
        modulos.reemplazar(s, eid, "bancos", [], version=r0.version); s.commit()
    assert c.get("/api/sinc/catalogo", headers=H(tok)).json()["bancos_iniciales"] == []
    # un error al armar las cuentas no hace fallar la bajada del catálogo
    _poner_bancos(eid, WEB[:1])

    def _falla(*a, **k):
        raise RuntimeError("dato dañado")
    with monkeypatch.context() as m:
        m.setattr(sinc, "_cuentas_iniciales", _falla)
        r = c.get("/api/sinc/catalogo", headers=H(tok))
    assert r.status_code == 200 and r.json()["bancos_iniciales"] == [] and r.json()["registros"] is not None
    # «bancos» no se puede subir a la nube por /api/sinc/cambios (no está en CLAVES_OPERATIVAS)
    r = c.post("/api/sinc/cambios", headers=H(tok), json={"registros": {"bancos": {"items": [{"id": 20000001, "nombre": "Intrusa"}], "vivos": [20000001]}}})
    assert r.status_code == 200, r.text
    assert r.json()["registros"]["bancos"] == {"error": "Este registro no se sincroniza"}
    assert _bancos(eid) == WEB[:1]


def test_cuentas_iniciales_limpia_lo_que_recibe():
    lista = [{"id": 5, "nombre": "  Caja  ", "saldo": 9}, {"id": 5, "nombre": "Otra"}, {"nombre": "Caja"}, {"nombre": ""}, "x", None,
             {"id": True, "nombre": "Sin id", "moneda": "usd", "principal": "sí"}, {"id": 2 ** 60, "nombre": "Id enorme"}]
    out = sinc._cuentas_iniciales(lista)
    assert [x["nombre"] for x in out] == ["Caja", "Otra", "Sin id", "Id enorme"]
    assert [x["id"] for x in out] == [5, 6, 7, 8]                          # repetidos o inválidos: por encima de todos
    assert out[2]["moneda"] == "USD" and out[2]["principal"] is False and out[0]["tipo"] == "Banco"
    assert all(set(x) == {"id", *sinc.CAMPOS_BANCO_INICIAL} for x in out)
    assert sinc._cuentas_iniciales(None) == [] and sinc._cuentas_iniciales({"a": 1}) == []


# ------------------------------------------------------------------------------------------------ lado programa
def test_computadora_sin_bancos_recibe_las_cuentas_de_la_web_con_saldo_cero_una_sola_vez(monkeypatch):
    eid = _empresa_local()
    assert _bancos(eid) is None
    cfg = _bajar(eid, {"bancos_iniciales": sinc._cuentas_iniciales(WEB), "empresa": {"tipo_negocio": "restaurante"}}, monkeypatch)
    hoy = ahora_cr().date().isoformat()
    assert _bancos(eid) == _esperadas(hoy)
    assert cfg.get("ultima_bajada")
    v = _version_bancos(eid)
    # segunda bajada (la web cambió o agregó cuentas): no vuelve a sembrar ni duplica
    otra = sinc._cuentas_iniciales(WEB + [{"id": 9, "nombre": "Caja chica", "tipo": "Efectivo"}])
    _bajar(eid, {"bancos_iniciales": [dict(x, nombre=x["nombre"] + " web") for x in otra]}, monkeypatch)
    assert _bancos(eid) == _esperadas(hoy) and _version_bancos(eid) == v


@pytest.mark.parametrize("local", [[], [{"id": 7, "nombre": "Gaveta propia", "tipo": "Efectivo", "moneda": "CRC", "saldo_inicial": 1000, "fecha_saldo": "2026-05-01"}]])
def test_con_bancos_local_aunque_este_vacio_no_se_toca(monkeypatch, local):
    eid = _empresa_local()
    _poner_bancos(eid, local)
    v = _version_bancos(eid)
    for cuerpo in ({"bancos_iniciales": sinc._cuentas_iniciales(WEB)}, {"bancos_iniciales": [], "empresa": {"tipo_negocio": "restaurante"}},
                   {"empresa": {"tipo_negocio": "comercio"}}):
        _bajar(eid, cuerpo, monkeypatch)
        assert _bancos(eid) == local and _version_bancos(eid) == v


@pytest.mark.parametrize("tipo", ["restaurante", "comercio", "hospitalidad"])
@pytest.mark.parametrize("web_anterior", [False, True])
def test_web_sin_cuentas_y_empresa_con_caja_nace_caja_general(monkeypatch, tipo, web_anterior):
    eid = _empresa_local()
    cuerpo = {"empresa": {"tipo_negocio": tipo}} if web_anterior else {"bancos_iniciales": [], "empresa": {"tipo_negocio": tipo}}
    _bajar(eid, cuerpo, monkeypatch)
    b = _bancos(eid)
    assert [x["nombre"] for x in b] == ["Caja general"] and b[0]["tipo"] == "Efectivo" and b[0]["moneda"] == "CRC" and b[0]["saldo_inicial"] == 0
    v = _version_bancos(eid)
    _bajar(eid, {"bancos_iniciales": sinc._cuentas_iniciales(WEB)}, monkeypatch)    # después ya no cambia
    assert _bancos(eid) == b and _version_bancos(eid) == v


@pytest.mark.parametrize("tipo", [None, "facturacion", "servicios"])
def test_empresa_sin_punto_de_venta_no_recibe_nada_si_la_web_no_tiene_cuentas(monkeypatch, tipo):
    eid = _empresa_local()
    for cuerpo in ({"bancos_iniciales": []}, {}):
        _bajar(eid, {**cuerpo, "empresa": {"tipo_negocio": tipo}} if tipo else cuerpo, monkeypatch)
        assert _bancos(eid) is None


def test_empresa_sin_punto_de_venta_si_recibe_las_cuentas_que_tenga_la_web(monkeypatch):
    eid = _empresa_local()
    _bajar(eid, {"bancos_iniciales": sinc._cuentas_iniciales(WEB), "empresa": {"tipo_negocio": "facturacion"}}, monkeypatch)
    assert [x["nombre"] for x in _bancos(eid)] == ["Caja general", "BAC dólares"]


def test_un_fallo_al_sembrar_no_detiene_la_bajada(monkeypatch):
    eid = _empresa_local()

    def _falla(*a, **k):
        raise RuntimeError("disco")
    monkeypatch.setattr(sinc, "_cuentas_iniciales", _falla)
    cfg = _bajar(eid, {"bancos_iniciales": [{"id": 1, "nombre": "Caja"}], "registros": {"monedas": [{"id": 1, "codigo": "CRC"}]}}, monkeypatch)
    assert cfg.get("ultima_bajada") and _bancos(eid) is None
    with Session(engine_empresa(eid)) as s:
        assert modulos.leer(s, eid, "monedas", None) == [{"id": 1, "codigo": "CRC"}]


def test_un_programa_anterior_ignora_el_campo_nuevo(monkeypatch):
    """Un programa 4.16 a 4.28 solo lee de la respuesta las llaves que conoce (instalacion, empresa, correo_nube, credenciales_huella,
    usuarios, roles, clientes, productos, registros, existencias): el campo nuevo va fuera de «registros» y no lo aplica ni falla."""
    eid = _empresa_local()
    monkeypatch.setattr(sinc, "_sembrar_bancos", lambda s, e, j: "")      # el programa anterior no tiene la siembra
    cfg = _bajar(eid, {"bancos_iniciales": sinc._cuentas_iniciales(WEB), "registros": {"monedas": [{"id": 1, "codigo": "CRC"}]},
                       "empresa": {"tipo_negocio": "restaurante"}}, monkeypatch)
    assert cfg.get("ultima_bajada") and _bancos(eid) is None
    py = (RAIZ / "app" / "sinc.py").read_text(encoding="utf-8")
    bajar = py[py.index("def _bajar(s, sc"):py.index("def _guardar_cfg(")]
    assert 'registros = j.get("registros") or {}' in bajar                 # lo que el programa aplica como «la nube manda»
    assert "bancos" not in sinc.CLAVES_CATALOGO and sinc.CAMPO_BANCOS_INICIALES not in sinc.CLAVES_CATALOGO
    # el campo nuevo solo lo arma la nube (catalogo) y solo lo lee la siembra
    usos = [i for i in range(len(py)) if py.startswith("CAMPO_BANCOS_INICIALES", i)]
    assert len(usos) == 3                                                  # definición, catalogo() y _sembrar_bancos()
    nube = py[py.index('@router.get("/catalogo")'):py.index('@router.get("/credenciales")')]
    assert "extra[CAMPO_BANCOS_INICIALES] = _bancos_iniciales(s, eid)" in nube and "    if inst:" in nube


def test_el_registro_sembrado_no_sube_ni_viaja_por_la_red_del_local(monkeypatch):
    eid = _empresa_local()
    _bajar(eid, {"bancos_iniciales": sinc._cuentas_iniciales(WEB)}, monkeypatch)
    assert _bancos(eid)
    for lista in (sinc.CLAVES_CATALOGO, sinc.CLAVES_OPERATIVAS, sinc.CLAVES_RED, sinc.CLAVES_DEL_EQUIPO):
        assert "bancos" not in lista
    enviados = []
    monkeypatch.setattr(sinc, "_post", lambda url, cab, ruta, cuerpo: enviados.append(cuerpo) or {"registros": {}})
    rango = modulos.rango_propio(eid)
    with Session(engine_empresa(eid)) as s:
        sinc._subir_registros(s, eid, {}, NUBE, {}, rango)
        red = sinc._payload_red(s, eid, {"nombre": "Caja QA"}, {}, rango)
    assert all("bancos" not in (x.get("registros") or {}) for x in enviados)
    assert "bancos" not in ((red or {}).get("registros") or {})
