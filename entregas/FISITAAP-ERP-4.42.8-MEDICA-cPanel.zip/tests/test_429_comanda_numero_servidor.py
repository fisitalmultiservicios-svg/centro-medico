# -*- coding: utf-8 -*-
"""4.29 (servidor): número consecutivo de las comandas, POST /api/pos/comanda/numero (app/comandas.py).

- Números seguidos de uno en uno; «dia» vuelve a 1 cuando cambia la fecha de Costa Rica y «continuo» no.
- Dos pedidos a la vez nunca reciben el mismo número (hilos con sesiones propias, dos motores sobre el mismo archivo y peticiones
  HTTP simultáneas).
- Permisos: sin sesión 401; un rol sin punto de venta 403; Cajero y un rol propio con «pos» (salonero) sí. Plan vencido: 403.
- Cada empresa tiene su propia cuenta. Una base de una versión anterior (sin la tabla) abre sin error.
- El contador no viaja (sincronización y red del local) y un respaldo restaurado no lo atrasa."""
import json
import threading
from datetime import datetime

from sqlalchemy import text
from sqlmodel import Session

from app import comandas, config, db, planes, sinc
from app.db import engine_empresa
from tests.test_387_registros import H, _borrar, _empresa, c

URL = "/api/pos/comanda/numero"


def _pedir(tok, modo):
    return c.post(URL, json={"modo": modo}, headers=H(tok))


def _num(tok, modo):
    r = _pedir(tok, modo)
    assert r.status_code == 200, r.text
    return r.json()


def _nueva(sufijo, usuarios=None, roles=None):
    usuarios = usuarios or {"Administrador": f"admin.cmd{sufijo}.429@example.test"}
    eid, tok = _empresa(f"Comandas {sufijo} 429 QA", "restaurante", roles or {}, usuarios, sufijo)
    return eid, tok, list(usuarios.values())


def test_numeros_seguidos_por_modo_con_la_fecha_de_costa_rica():
    eid, tok, correos = _nueva("c1")
    try:
        t = tok["Administrador"]
        assert [_num(t, "continuo")["numero"] for _ in range(3)] == [1, 2, 3]
        d = _num(t, "dia")
        assert d == {"numero": 1, "modo": "dia", "fecha": comandas.hoy_cr()}
        assert _num(t, "dia")["numero"] == 2
        r = _num(t, "continuo")
        assert r == {"numero": 4, "modo": "continuo", "fecha": None}        # el del día no mueve el continuo
        assert comandas.ahora_cr is config.ahora_cr                          # la fecha de Costa Rica del proyecto
        assert comandas.hoy_cr() == config.ahora_cr().date().isoformat()
    finally:
        _borrar(eid, correos)


def test_modo_invalido_y_cuerpo_raro_400():
    eid, tok, correos = _nueva("c2")
    try:
        t = tok["Administrador"]
        for cuerpo in ({"modo": "semana"}, {"modo": ""}, {"modo": None}, {"modo": 1}, {}, [], "dia"):
            r = c.post(URL, json=cuerpo, headers=H(t))
            assert r.status_code == 400, (cuerpo, r.text)
            assert "comandas" in r.json()["detail"] and "Traceback" not in r.text
        r = c.post(URL, headers=H(t))                                           # sin cuerpo
        assert r.status_code == 400
        assert _num(t, "continuo")["numero"] == 1                               # los errores no consumen números
    finally:
        _borrar(eid, correos)


def test_permisos_de_la_caja():
    usuarios = {"Administrador": "admin.cmdc3.429@example.test", "Cajero": "cajero.cmdc3.429@example.test",
                "Vendedor": "vende.cmdc3.429@example.test", "Contador": "conta.cmdc3.429@example.test",
                "Solo lectura": "lee.cmdc3.429@example.test", "Salonero": "salon.cmdc3.429@example.test",
                "Bodega": "bodega.cmdc3.429@example.test"}
    eid, tok, correos = _nueva("c3", usuarios, {"Salonero": ["pos"], "Bodega": ["inventario"]})
    try:
        assert c.post(URL, json={"modo": "dia"}).status_code == 401                                   # sin sesión
        assert c.post(URL, json={"modo": "dia"}, headers=H("token-inventado")).status_code == 401
        for rol in ("Contador", "Solo lectura", "Bodega"):                                           # sin punto de venta
            r = _pedir(tok[rol], "dia")
            assert r.status_code == 403, (rol, r.text)
        vistos = [_num(tok[rol], "continuo")["numero"] for rol in ("Cajero", "Salonero", "Vendedor", "Administrador")]
        assert vistos == [1, 2, 3, 4]                                            # todas las cajas comparten el contador
        # plan vencido (solo consulta): la ruta es de escritura y no numera
        orig = planes.vencido
        planes.vencido = lambda e: True
        try:
            r = _pedir(tok["Cajero"], "continuo")
            assert r.status_code == 403 and r.json()["detail"]["codigo"] == "plan_vencido", r.text
        finally:
            planes.vencido = orig
        assert not URL.startswith(planes.RUTAS_LECTURA)
        assert _num(tok["Cajero"], "continuo")["numero"] == 5                   # el rechazo no consumió número
    finally:
        _borrar(eid, correos)


def test_otra_empresa_lleva_su_propia_cuenta():
    a, ta, ca = _nueva("c4")
    b, tb, cb = _nueva("c5")
    try:
        assert [_num(ta["Administrador"], "continuo")["numero"] for _ in range(3)] == [1, 2, 3]
        assert _num(tb["Administrador"], "continuo")["numero"] == 1
        assert _num(tb["Administrador"], "dia")["numero"] == 1
        assert _num(ta["Administrador"], "dia")["numero"] == 1
        assert _num(ta["Administrador"], "continuo")["numero"] == 4
    finally:
        _borrar(a, ca); _borrar(b, cb)


def test_el_modo_dia_vuelve_a_1_al_cambiar_la_fecha_y_el_continuo_no(monkeypatch):
    eid, tok, correos = _nueva("c6")
    try:
        t = tok["Administrador"]
        dia = {"v": datetime(2026, 11, 12, 23, 58, tzinfo=config.TZ_CR)}
        monkeypatch.setattr(comandas, "ahora_cr", lambda: dia["v"])
        assert [_num(t, "dia")["numero"] for _ in range(3)] == [1, 2, 3]
        assert _num(t, "continuo")["numero"] == 1
        dia["v"] = datetime(2026, 11, 13, 0, 1, tzinfo=config.TZ_CR)           # medianoche de Costa Rica
        r = _num(t, "dia")
        assert r == {"numero": 1, "modo": "dia", "fecha": "2026-11-13"}
        assert _num(t, "dia")["numero"] == 2
        assert _num(t, "continuo")["numero"] == 2
        dia["v"] = datetime(2026, 11, 14, 6, 0, tzinfo=config.TZ_CR)
        assert _num(t, "dia") == {"numero": 1, "modo": "dia", "fecha": "2026-11-14"}
        assert _num(t, "continuo")["numero"] == 3
    finally:
        _borrar(eid, correos)


def test_a_la_vez_nunca_repite_hilos_y_dos_motores():
    eid, tok, correos = _nueva("c7")
    try:
        ruta = db.EMPRESAS_DIR / f"empresa_{eid}.db"
        engine_empresa(eid)
        otro = db._nuevo_engine(f"sqlite:///{ruta}")                            # como otro proceso (Passenger) sobre el mismo archivo
        salida, errores, lock = {"dia": [], "continuo": []}, [], threading.Lock()
        inicio = threading.Barrier(8)

        def trabajar(i):
            eng = otro if i % 2 else engine_empresa(eid)
            try:
                inicio.wait()
                for k in range(15):
                    modo = "dia" if (i + k) % 2 else "continuo"
                    with Session(eng) as s:
                        n, _ = comandas.siguiente(s, eid, modo)
                    with lock:
                        salida[modo].append(n)
            except Exception as ex:  # noqa: BLE001
                errores.append(repr(ex))

        hilos = [threading.Thread(target=trabajar, args=(i,)) for i in range(8)]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join(120)
        otro.dispose()
        assert not errores, errores
        for modo, nums in salida.items():
            assert sorted(nums) == list(range(1, len(nums) + 1)), (modo, sorted(nums))
        assert len(salida["dia"]) + len(salida["continuo"]) == 120
    finally:
        _borrar(eid, correos)


def test_a_la_vez_por_http_dos_sesiones():
    usuarios = {"Administrador": "admin.cmdc8.429@example.test", "Cajero": "cajero.cmdc8.429@example.test"}
    eid, tok, correos = _nueva("c8", usuarios)
    try:
        from fastapi.testclient import TestClient
        from app.main import app
        nums, errores, lock = [], [], threading.Lock()
        inicio = threading.Barrier(6)

        def caja(t):
            cli = TestClient(app)
            try:
                inicio.wait()
                for _ in range(10):
                    r = cli.post(URL, json={"modo": "dia"}, headers=H(t))
                    assert r.status_code == 200, r.text
                    with lock:
                        nums.append(r.json()["numero"])
            except Exception as ex:  # noqa: BLE001
                errores.append(repr(ex))

        hilos = [threading.Thread(target=caja, args=(tok["Cajero" if i % 2 else "Administrador"],)) for i in range(6)]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join(120)
        assert not errores, errores
        assert sorted(nums) == list(range(1, 61))
    finally:
        _borrar(eid, correos)


def test_una_base_de_una_version_anterior_abre_sin_error():
    eid, tok, correos = _nueva("c9")
    try:
        with engine_empresa(eid).begin() as conn:                               # como una base de la 4.28: sin la tabla ni su huella
            conn.exec_driver_sql("DROP INDEX IF EXISTS ux_comanda_numero")
            conn.exec_driver_sql("DROP TABLE IF EXISTS comanda_numero")
            conn.exec_driver_sql("PRAGMA user_version = 0")
        eng, _ = db._engines.pop(eid)
        eng.dispose()
        assert comandas.leer_contador(db.EMPRESAS_DIR / f"empresa_{eid}.db") == []
        assert _num(tok["Administrador"], "dia")["numero"] == 1                 # se migra al abrir y numera
        with engine_empresa(eid).connect() as conn:
            idx = [r[1] for r in conn.exec_driver_sql("PRAGMA index_list(comanda_numero)")]
            assert "ux_comanda_numero" in idx
            assert conn.exec_driver_sql("PRAGMA user_version").scalar() == db.huella_esquema()
        assert any(t.name == "comanda_numero" for t in db.TABLAS_EMPRESA)
    finally:
        _borrar(eid, correos)


def test_el_contador_no_viaja_ni_por_la_sincronizacion_ni_por_la_red():
    import inspect
    fuente = inspect.getsource(sinc)
    assert "comanda_numero" not in fuente and "ComandaNumero" not in fuente
    for lista in (sinc.CLAVES_CATALOGO, sinc.CLAVES_OPERATIVAS, sinc.CLAVES_RED, sinc.CLAVES_DEL_EQUIPO):
        assert not any("comanda" in str(k) for k in lista), lista
    eid, tok, correos = _nueva("c0")
    try:
        for _ in range(4):
            _num(tok["Administrador"], "continuo")
        with Session(engine_empresa(eid)) as s:
            cuerpo = sinc._payload_red(s, eid, {"nombre": "Caja QA 429"}, {}, 0)
        assert "comanda" not in json.dumps(cuerpo or {}, default=str)
        # lo que otra computadora del local mande con ese nombre no se acepta como registro compartido
        assert "comanda_numero" not in sinc.CLAVES_RED
    finally:
        _borrar(eid, correos)


def test_restaurar_un_respaldo_no_atrasa_el_contador():
    from app import respaldo
    from app.db import Empresa, engine
    eid, tok, correos = _nueva("cb")
    try:
        t = tok["Administrador"]
        for _ in range(3):
            _num(t, "continuo"); _num(t, "dia")
        with Session(engine) as sc:
            e = sc.get(Empresa, eid); sc.expunge(e)
        zipf = respaldo.ejecutar_empresa(e, forzar=True)                          # respaldo con continuo 3 y dia 3
        for _ in range(4):
            _num(t, "continuo"); _num(t, "dia")                                   # ya van 7 y 7
        r = respaldo.restaurar_empresa(e, zipf)
        assert r["copiados"]["base"] == 1
        assert _num(t, "continuo")["numero"] == 8 and _num(t, "dia")["numero"] == 8
    finally:
        for x in respaldo.listar_empresa(eid):
            respaldo.eliminar_empresa(eid, x["nombre"])
        _borrar(eid, correos)


def test_restaurar_conserva_los_numeros_dados_mientras_se_copia_el_zip(monkeypatch):
    """El contador que se conserva se lee después de copiar la base del zip, no antes: los números que otro proceso dio mientras se
    copiaba no se repiten."""
    import shutil
    import sqlite3
    from app import respaldo
    from app.db import Empresa, EMPRESAS_DIR, engine
    eid, tok, correos = _nueva("cd")
    try:
        t = tok["Administrador"]
        for _ in range(3):
            _num(t, "continuo")
        with Session(engine) as sc:
            e = sc.get(Empresa, eid); sc.expunge(e)
        zipf = respaldo.ejecutar_empresa(e, forzar=True)                          # respaldo con continuo 3
        for _ in range(4):
            _num(t, "continuo")                                                   # ya van 7
        original = shutil.copyfileobj

        def copiar_y_numerar(src, dst, *a, **k):
            original(src, dst, *a, **k)
            if str(getattr(dst, "name", "")).endswith(".restaurando"):          # otro proceso da el 8 y el 9 sobre la base vieja
                cx = sqlite3.connect(str(EMPRESAS_DIR / f"empresa_{eid}.db"), timeout=30)
                try:
                    cx.execute("UPDATE comanda_numero SET ultimo = ultimo + 2 WHERE empresa_id = ? AND modo = 'continuo'", (eid,))
                    cx.commit()
                finally:
                    cx.close()
        monkeypatch.setattr(shutil, "copyfileobj", copiar_y_numerar)
        respaldo.restaurar_empresa(e, zipf)
        monkeypatch.setattr(shutil, "copyfileobj", original)
        assert _num(t, "continuo")["numero"] == 10
    finally:
        for x in respaldo.listar_empresa(eid):
            respaldo.eliminar_empresa(eid, x["nombre"])
        _borrar(eid, correos)


def test_conservar_toma_siempre_el_mayor():
    eid, tok, correos = _nueva("cc")
    try:
        with Session(engine_empresa(eid)) as s:
            comandas.siguiente(s, eid, "continuo")                       # restaurado: continuo 1
        with Session(engine_empresa(eid)) as s:
            s.execute(text("INSERT INTO comanda_numero (empresa_id, modo, fecha, ultimo) VALUES (:e, 'dia', '2026-11-12', 9)"), {"e": eid})
            s.commit()
        # lo que tenía el servidor: continuo 50; dia de un día anterior (no gana aunque el número sea mayor)
        assert comandas.conservar(eid, [("continuo", "", 50), ("dia", "2026-11-11", 80), ("raro", "", 3)]) == 1
        with Session(engine_empresa(eid)) as s:
            filas = dict(s.execute(text("SELECT modo, ultimo FROM comanda_numero WHERE empresa_id = :e"), {"e": eid}).all())
        assert filas == {"continuo": 50, "dia": 9}
        # el mismo día con un número mayor sí gana; un día más reciente también
        comandas.conservar(eid, [("dia", "2026-11-12", 12)])
        with Session(engine_empresa(eid)) as s:
            assert comandas.siguiente(s, eid, "dia", "2026-11-12") == (13, "2026-11-12")
        comandas.conservar(eid, [("dia", "2026-11-14", 2)])
        with Session(engine_empresa(eid)) as s:
            assert comandas.siguiente(s, eid, "dia", "2026-11-14") == (3, "2026-11-14")
        assert comandas.conservar(eid, []) == 0
    finally:
        _borrar(eid, correos)
