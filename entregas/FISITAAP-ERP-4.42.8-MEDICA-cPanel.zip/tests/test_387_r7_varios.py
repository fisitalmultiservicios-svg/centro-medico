"""3.87 (segunda ronda, r7_varios): arreglos pequeños que encontró la QA de regresión.
- g9-reg-01        El resumen sale con los mismos bytes en todos los procesos: Montos.menos ya no recorre un set (el orden de las
                   monedas de iva.debito.nativo e iva.neto.nativo dependía de la semilla de hash del proceso).
- facturacion-r5 /
  servicios-R5     GET /api/empresa/logo sin logo responde 204 (antes 404 y un error en la consola en Configuración › Empresa y
                   › Documentos); la pantalla solo pone la imagen con un 200.
- comercio-r6      Las filas de ejemplo de la plantilla de ítems (Excel y CSV) traen CABYS que existen en el catálogo oficial: la
                   plantilla tal cual se importa sin errores.
- F6               Correo de comprobantes sin respuesta de Hacienda: con uno solo, el texto va en singular.
- restaurante-r5   Al arrancar, un hilo prepara las rutas de la API (y, fuera de las pruebas, el tipo de cambio del día) para que
                   la primera visita no lo pague."""
import csv
import gzip
import io
import json
import os
import pathlib
import re
import subprocess
import sys
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, avisos_dueno, cabys as cabys_local, importacion_items, main
from app.db import Empresa, Producto, engine, engine_empresa, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent
JS = RAIZ / "app" / "static" / "js"
CATALOGO = RAIZ / "catalogos" / "cabys.csv.gz"
PW = "Clave-larga-387-r7-varios-QA"
c = TestClient(app)
H = lambda t: {"Authorization": "Bearer " + t}   # noqa: E731


def _empresa(nombre, sufijo, roles):
    """Empresa de prueba con usuarios @example.test de los roles pedidos ({rol: token}) y sus correos para limpiar."""
    init_db()
    tokens, correos = {}, []
    with Session(engine) as s:
        e = Empresa(nombre=nombre, numero_id="3101387" + sufijo, actividad="620100", otras_senas="QA 387", correo=f"emp{sufijo}.r7@example.test",
                    ambiente="sandbox", tipo_negocio="comercio")
        s.add(e); s.commit(); s.refresh(e)
        for rol in roles:
            correo = f"{rol.lower()}.{sufijo}.r7@example.test"
            u = auth.Usuario(correo=correo, nombre=rol + " QA", password_hash=auth.hash_password(PW), mfa_activo=True,
                             terminos_version=auth.TERMINOS_VERSION, terminos_fecha=datetime.now(timezone.utc), consiente_factura=True, paleta="turquesa")
            s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol=rol)); s.commit()
            tokens[rol] = auth._respuesta(s, u, e.id)["token"]
            correos.append(correo)
        eid = e.id
    return eid, tokens, correos


def _borrar(eid, correos):
    with Session(engine) as s:
        for correo in correos:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            if not u:
                continue
            for x in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                s.delete(x)
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == u.id)).all():
                s.delete(x)
            s.delete(u)
        e = s.get(Empresa, eid)
        if e:
            s.delete(e)
        s.commit()


def _correr(codigo, semilla, tmp_path):
    """Corre `codigo` en un proceso nuevo con la semilla de hash indicada y datos propios en tmp_path; devuelve el JSON de la última línea."""
    env = {**os.environ, "PYTHONHASHSEED": semilla, "FE_DATA_DIR": str(tmp_path), "FE_DB_URL": f"sqlite:///{(tmp_path / 'f.db').as_posix()}",
           "FE_COLA_HILO": "0", "FE_SINC_HILO": "0", "PYTHONDONTWRITEBYTECODE": "1", "FE_RESPALDOS_DIR": str(tmp_path / "respaldos")}
    for k in [k for k in env if k.startswith("FE_SMTP_")]:
        env.pop(k)
    env.pop("FE_CABYS_SINCRONO", None)
    r = subprocess.run([sys.executable, "-c", codigo], cwd=str(RAIZ), capture_output=True, text=True, timeout=240, env=env, encoding="utf-8")
    assert r.returncode == 0, r.stderr[-1500:]
    return json.loads(r.stdout.strip().splitlines()[-1])


# ----------------------------------------------------------------------------- g9-reg-01
CODIGO_MONTOS = (
    "import json\n"
    "from app.resumen import Montos\n"
    "a = Montos(500).sumar('CRC', 1000).sumar('USD', 10, 500).sumar('EUR', 5, 550)\n"
    "b = Montos(500).sumar('USD', 2, 500).sumar('JPY', 100, 3)\n"
    "print(json.dumps([list(a.menos(b).nativo), list(b.menos(a).nativo), list(Montos(500).menos(a).nativo), a.menos(b).nativo]))\n")

CODIGO_RESUMEN = (
    "import hashlib, json, types\n"
    "from fastapi.testclient import TestClient\n"
    "from sqlmodel import Session\n"
    "from app import auth, tipo_cambio\n"
    "from app.main import app\n"
    "from app.db import Documento, Empresa, engine, engine_empresa, init_db\n"
    "tipo_cambio.obtener = lambda forzar=False: {'venta': 505.0, 'compra': 500.0}     # sin red\n"
    "init_db()\n"
    "with Session(engine) as s:\n"
    "    e = Empresa(nombre='Orden 387', numero_id='3101387388', actividad='620100', ambiente='sandbox'); s.add(e); s.commit(); s.refresh(e)\n"
    "def doc(n, moneda, tc, tipo='01', total=1000.0, impuesto=115.04):\n"
    "    return Documento(empresa_id=e.id, tipo_documento=tipo, clave='506%05d%042d' % (e.id, n), consecutivo='00100001%s%010d' % (tipo, n),\n"
    "                     fecha_emision='2026-11-02T10:00:00-06:00', ambiente='sandbox', estado='aceptado', moneda=moneda, tipo_cambio=tc,\n"
    "                     total=total, impuesto=impuesto, condicion_venta='01')\n"
    "with Session(engine_empresa(e.id)) as s:\n"
    "    s.add(doc(1, 'CRC', 1)); s.add(doc(2, 'USD', 505.5)); s.add(doc(3, 'USD', 505.5, '03', 100.0, 11.5)); s.commit()\n"
    "u = types.SimpleNamespace(id=None, correo='orden387@example.test', es_superadmin=False, nombre='QA')\n"
    "app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(u, e, 'Administrador')\n"
    "r = TestClient(app).get('/api/resumen?periodo=rango&desde=2026-01-01&hasta=2026-12-31', headers={'Accept-Encoding': 'identity'})\n"
    "j = r.json()\n"
    "print(json.dumps({'status': r.status_code, 'sha': hashlib.sha256(r.content).hexdigest(), 'debito': list(j['iva']['debito']['nativo']),\n"
    "                  'neto': list(j['iva']['neto']['nativo']), 'valores': j['iva']}))\n")


def test_menos_conserva_el_orden_de_las_monedas_en_todos_los_procesos(tmp_path):
    for semilla in ("0", "1", "2", "3", "4", "5", "6", "7"):
        ab, ba, cero_a, valores = _correr(CODIGO_MONTOS, semilla, tmp_path)
        assert ab == ["CRC", "USD", "EUR", "JPY"], (semilla, ab)
        assert ba == ["USD", "JPY", "CRC", "EUR"], (semilla, ba)
        assert cero_a == ["CRC", "USD", "EUR"], (semilla, cero_a)
        assert valores == {"CRC": 1000.0, "USD": 8.0, "EUR": 5.0, "JPY": -100.0}, (semilla, valores)


def test_resumen_mismos_bytes_con_cualquier_semilla_de_hash(tmp_path):
    vistos = {}
    for semilla in ("0", "3"):
        d = tmp_path / semilla
        d.mkdir()
        vistos[semilla] = _correr(CODIGO_RESUMEN, semilla, d)
    for semilla, v in vistos.items():
        assert v["status"] == 200, v
        assert v["debito"] == ["CRC", "USD"] and v["neto"] == ["CRC", "USD"], (semilla, v["debito"], v["neto"])
    assert vistos["0"]["valores"] == vistos["3"]["valores"]
    assert vistos["0"]["sha"] == vistos["3"]["sha"], "el mismo resumen salió con bytes distintos según el proceso"


# ----------------------------------------------------------------------------- facturacion-r5 / servicios-R5
PNG_1X1 = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000154a24f5d0000000049454e44ae426082")


def test_logo_sin_subir_responde_204_y_con_logo_la_imagen():
    eid, tok, correos = _empresa("Logo R7 QA", "71", ["Administrador", "Contador"])
    try:
        for rol in ("Administrador", "Contador"):                 # Empresa (Administrador) y Documentos (también el Contador)
            r = c.get("/api/empresa/logo", headers=H(tok[rol]))
            assert r.status_code == 204 and r.content == b"", (rol, r.status_code, r.content[:80])
        r = c.post("/api/empresa/logo", headers=H(tok["Administrador"]), files={"archivo": ("logo.png", PNG_1X1, "image/png")})
        assert r.status_code == 200, r.text
        for rol in ("Administrador", "Contador"):
            r = c.get("/api/empresa/logo", headers=H(tok[rol]))
            assert r.status_code == 200 and r.headers["content-type"].startswith("image/png") and r.content == PNG_1X1, (rol, r.status_code)
        assert c.get("/api/empresa/logo").status_code == 401          # sin sesión sigue cerrado
    finally:
        (main.DATA_DIR / f"logo_empresa_{eid}.png").unlink(missing_ok=True)
        _borrar(eid, correos)


def test_pantallas_de_configuracion_solo_ponen_el_logo_con_200():
    """Con el 204, r.ok sería verdadero y la pantalla pondría una imagen rota: las dos secciones miran el código 200."""
    sec = (JS / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    assert sec.count("this.logo = r.status === 200 ? '/api/empresa/logo?v=' + Date.now() : null;") == 2
    assert "r.ok ? '/api/empresa/logo" not in sec


# ----------------------------------------------------------------------------- comercio-r6
def _oficiales():
    with gzip.open(CATALOGO, "rt", encoding="utf-8") as f:
        return {fila["codigo"]: fila for fila in csv.DictReader(f)}


def test_ejemplos_de_la_plantilla_con_cabys_del_catalogo_oficial():
    oficiales = _oficiales()
    malos = [e[2] for e in importacion_items.EJEMPLOS if e[2] not in oficiales]
    assert not malos, malos
    for e in importacion_items.EJEMPLOS:                           # la tarifa 08 (13 %) de la fila coincide con la del código
        assert e[6] == "08" and float(oficiales[e[2]]["impuesto"]) == 0.13, (e[0], e[2], oficiales[e[2]]["impuesto"])
    csv_js = re.search(r"plantilla\(\) \{\s*const csv = '([^']+)'", (JS / "pages" / "inventario" / "gestion.js").read_text(encoding="utf-8")).group(1)
    codigos = [ln.split(";")[2] for ln in csv_js.split("\\n")[1:]]
    assert len(codigos) == 3 and all(x in oficiales for x in codigos), codigos
    assert codigos == [e[2] for e in importacion_items.EJEMPLOS]     # la plantilla CSV y la de Excel traen los mismos ejemplos


def test_la_plantilla_de_excel_tal_cual_se_importa_sin_errores(monkeypatch):
    # el catálogo oficial del proyecto hace de catálogo local (el que rechaza un CABYS inexistente) solo en esta prueba: cargarlo en
    # la base compartida haría fallar a las demás pruebas, que crean ítems con códigos de juguete
    oficiales = _oficiales()
    monkeypatch.setattr(cabys_local, "disponible", lambda: True)
    monkeypatch.setattr(cabys_local, "obtener", lambda codigo: oficiales.get(codigo))
    eid, tok, correos = _empresa("Plantilla R7 QA", "72", ["Administrador"])
    try:
        t = tok["Administrador"]
        x = c.get("/api/productos/plantilla.xlsx", headers=H(t))
        assert x.status_code == 200, x.text
        r = c.post("/api/productos/importar", headers=H(t), data={"modo": "crear", "simular": "1"},
                   files={"archivo": ("plantilla-items.xlsx", x.content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")})
        assert r.status_code == 200, r.text
        j = r.json()
        assert j["creados"] == 3 and not j["errores"], j
        with Session(engine_empresa(eid)) as s:                    # simular no guarda nada
            assert s.exec(select(Producto).where(Producto.empresa_id == eid)).all() == []
    finally:
        _borrar(eid, correos)


# ----------------------------------------------------------------------------- F6
def test_correo_de_atascados_con_un_comprobante_en_singular():
    e = Empresa(id=987654, nombre="Avisos QA 387", nombre_comercial="Avisos QA 387", numero_id="3101000000", correo="dueno.avisos387@example.test")
    d = {"id": 41, "tipo": "Factura electrónica", "consecutivo": "00100001010000000001", "cliente": "Cliente QA", "monto": "₡11.300,00", "fecha": "03/11/2026"}
    asunto, html, texto = avisos_dueno.correo_atascados(e, [d])
    assert asunto.startswith("1 comprobante sin respuesta") and texto.startswith("Un comprobante sin respuesta")
    assert "Este comprobante sigue esperando a Hacienda" in texto and "se resuelve solo cuando" in texto
    assert "Este comprobante sigue esperando a Hacienda" in html and "Estos comprobantes" not in texto + html and "se resuelven solos" not in texto + html
    if avisos_dueno._enlace():                                     # con la dirección pública, el botón lleva a ese comprobante
        assert "Ver el comprobante" in html and avisos_dueno._enlace(41) in html and "Ver los comprobantes" not in html
    asunto, html, texto = avisos_dueno.correo_atascados(e, [d, {**d, "id": 42, "consecutivo": "00100001010000000002"}])
    assert asunto.startswith("2 comprobantes sin respuesta") and texto.startswith("Comprobantes sin respuesta")
    assert "Estos comprobantes siguen esperando a Hacienda" in texto and "se resuelven solos cuando" in texto and "Este comprobante" not in texto
    if avisos_dueno._enlace():
        assert "Ver los comprobantes" in html


# ----------------------------------------------------------------------------- restaurante-r5
CODIGO_ARRANQUE = (
    "import json, threading, time\n"
    "from fastapi import routing as fr\n"
    "from app import main\n"
    "fin = threading.Event()\n"
    "original = main._calentar\n"
    "def espia():\n"
    "    original(); fin.set()\n"
    "main._calentar = espia\n"
    "t = time.perf_counter(); main.arranque(); arranque_s = time.perf_counter() - t\n"
    "listo = fin.wait(120)\n"
    "cls = getattr(fr, '_IncludedRouter', None)\n"
    "inc = [r for r in main.app.router.routes if cls is not None and isinstance(r, cls)]\n"
    "print(json.dumps({'listo': listo, 'incluidos': len(inc), 'armados': sum(1 for r in inc if getattr(r, '_effective_candidates_version', None) is not None),\n"
    "                  'hilo_suelto': any(h.name == 'calentar-arranque' and not h.daemon for h in threading.enumerate())}))\n")


def test_arranque_prepara_las_rutas_en_un_hilo_antes_del_primer_usuario(tmp_path):
    """En un proceso nuevo: arranque() lanza el hilo y, cuando termina, todos los routers incluidos ya tienen armadas sus rutas (lo
    que la primera petición pagaba en frío). Si esta versión de FastAPI no arma las rutas en diferido, basta con que el hilo corra."""
    v = _correr(CODIGO_ARRANQUE, "0", tmp_path)
    assert v["listo"], v
    assert not v["hilo_suelto"], v
    if v["incluidos"]:
        assert v["armados"] == v["incluidos"], v


def test_calentar_responde_lo_mismo_y_el_tipo_de_cambio_solo_con_el_hilo_de_la_cola(monkeypatch):
    llamadas = []
    monkeypatch.setattr(main.tipo_cambio, "obtener", lambda forzar=False: llamadas.append(forzar) or {"venta": 505.0, "compra": 500.0})
    monkeypatch.setenv("FE_COLA_HILO", "0")                      # pruebas y QA aislada: no sale nada a la red
    main._calentar()
    assert llamadas == []
    monkeypatch.setenv("FE_COLA_HILO", "1")                      # producción: el tipo de cambio del día queda listo (sin forzar)
    main._calentar()
    assert llamadas == [False]
    r = c.get("/api/__calentar__")                                 # la ruta interna no existe: 404 como cualquier otra
    assert r.status_code == 404
    assert c.get("/api/sistema").status_code == 200
