"""3.87: TiKe (versión Servicios).
- El portal del cliente (/soporte/<slug>) abría en blanco: la plantilla de soporte.js tenía '\\n' dentro de una expresión y Vue no la
  compilaba. Ninguna plantilla escrita como template literal puede llevar una barra invertida sola antes de n, r o t.
- El portal trae sus propios colores, bordes y tipografía (soporte.css ya no depende de variables que tienda.css no define).
- Facturar desde el ticket y los contratos de soporte (cuota, tarifas, factura recurrente) exigen el permiso «facturar»: el Técnico de
  soporte («sin facturación ni caja») ya no crea borradores ni programa cobros.
- Facturar desde el ticket nunca cobra dos veces la misma hora ni las horas incluidas en la bolsa del contrato, aunque haya varios
  tickets o dos personas a la vez; si el borrador se elimina sin emitir, sus horas y repuestos vuelven a quedar por cobrar. Se puede
  cobrar más de lo anotado (hora mínima, tarifa fija, contrato por visitas): lo cobrado queda registrado y no se ofrece de nuevo.
- Solo quien configura la empresa apaga «ver contraseñas exige el código de dos pasos» (y queda en la auditoría).
- Cambiar o quitar una contraseña guardada exige el permiso de contraseñas y queda en la bitácora («cambiar», «eliminar»).
- Con la clave temporal del portal solo se puede cambiar la clave.
- Un ticket solo se asigna a quien atiende tickets."""
import json
import pathlib
import re
import sqlite3
import threading
import time

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, modulos, tike, tike_contratos as tc, tike_docs as td
from app.db import Empresa, engine, engine_empresa, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
CLAVE_PRUEBA = "Clave-larga-387-tike-qa"
SLUG = "soporte-qa387-tike"


# ------------------------------------------------------------------------------------------------- empresa, usuarios y roles de la prueba
@pytest.fixture
def qa():
    """Empresa de servicios con Administrador, Avanzado, Técnico de soporte (rol propio con «tike») y Vendedor, todos @example.test.
    qa.como(rol) cambia quién hace las llamadas. Al final se borra todo lo creado en la base central."""
    init_db()
    with Session(engine) as s:
        e = Empresa(nombre="Servicios TiKe 387 QA S.A.", numero_id="3101387701", actividad="620100", otras_senas="Oficina QA 387",
                    correo="tike387@example.test", ambiente="sandbox", tipo_negocio="servicios")
        s.add(e); s.commit(); s.refresh(e)
        s.add(auth.RolEmpresa(empresa_id=e.id, nombre="Técnico de soporte", descripcion="sin facturación ni caja", permisos=json.dumps(["tike"]))); s.commit()
        usuarios = {}
        for rol, correo in (("Administrador", "admin.tike387@example.test"), ("Avanzado", "avanzado.tike387@example.test"),
                            ("Técnico de soporte", "tecnico.tike387@example.test"), ("Vendedor", "vendedor.tike387@example.test")):
            u = auth.Usuario(correo=correo, nombre=correo.split("@")[0], password_hash=auth.hash_password(CLAVE_PRUEBA), terminos_version=auth.TERMINOS_VERSION, paleta="turquesa")
            s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol=rol)); s.commit(); s.refresh(u)
            usuarios[rol] = u
        for u in usuarios.values():
            s.refresh(u)
        s.refresh(e)
        ctxs = {rol: auth.Contexto(u, e, rol, permisos=auth.permisos_de_rol(s, e.id, rol)) for rol, u in usuarios.items()}
        correos = [u.correo for u in usuarios.values()]; eid = e.id

    class QA:
        pass
    q = QA(); q.eid = e.id; q.u = usuarios; q.actual = ctxs["Administrador"]

    def como(rol):
        q.actual = ctxs[rol]
        return q.c
    q.como = como
    app.dependency_overrides[auth.contexto] = lambda: q.actual
    q.c = TestClient(app)
    for k in [k for k in auth._intentos_ip if k.startswith("tike:")]:
        auth._intentos_ip.pop(k, None)
    try:
        yield q
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            for x in s.exec(select(auth.Usuario).where(auth.Usuario.correo.in_(correos))).all():  # type: ignore[attr-defined]
                for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == x.id)).all():
                    s.delete(m)
                for m in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == x.id)).all():
                    s.delete(m)
                s.delete(x)
            for r in s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == eid)).all():
                s.delete(r)
            for r in s.exec(select(tike.TikeSlug).where(tike.TikeSlug.empresa_id == eid)).all():
                s.delete(r)
            for r in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid)).all():
                s.delete(r)
            x = s.get(Empresa, eid)
            if x:
                s.delete(x)
            s.commit()


def _cliente(c, nombre, numero):
    r = c.post("/api/clientes", json={"nombre": nombre, "tipo_id": "02", "numero_id": numero, "correo": f"{numero}@example.test"})
    assert r.status_code == 200, r.text
    return r.json()


def _ticket(c, cliente_id, asunto, minutos, contrato_id=None):
    body = {"asunto": asunto, "cliente_id": cliente_id, "prioridad": "media"}
    if contrato_id is not None:
        body["contrato_id"] = contrato_id
    t = c.post("/api/tike/tickets", json=body).json()
    if minutos:
        assert c.post(f"/api/tike/tickets/{t['id']}/entradas", json={"tipo": "nota", "texto": "Trabajo", "minutos": minutos}).status_code == 200
    return t


def _contrato(c, cliente_id, cantidad, tarifa, inicio="2026-01-01"):
    r = c.post("/api/tike/contratos", json={"cliente_id": cliente_id, "nombre": "Bolsa QA", "tipo": "horas", "cantidad": cantidad, "periodo": "mensual", "tarifa_hora": tarifa,
                                            "cuota": 0, "inicio": inicio, "facturar_cuota": False})
    assert r.status_code == 200, r.text
    return r.json()


def _facturar(c, tid, **extra):
    return c.post(f"/api/tike/tickets/{tid}/facturar", json={"tipo_documento": "01", "incluir_horas": True, "incluir_items": True, "condicion_venta": "01", **extra})


# ------------------------------------------------------------------------------------------------- servicios:1 y :9 (portal)
def test_plantillas_sin_barra_invertida_sola():
    """Una barra invertida sola antes de n, r o t dentro de una plantilla `...` se vuelve un salto real antes de que Vue la compile; dentro
    de una cadena de una expresión rompe la página entera (el portal quedaba en blanco)."""
    inicio, sola = re.compile(r"template:\s*`"), re.compile(r"(?<!\\)(?:\\\\)*\\[nrt]")
    malos = []
    for f in sorted((RAIZ / "static" / "js").rglob("*.js")):
        if "vendor" in f.parts:
            continue
        src = f.read_text(encoding="utf-8")
        for m in inicio.finditer(src):
            i = j = m.end()
            while j < len(src) and src[j] != "`":
                j += 2 if src[j] == "\\" else 1
            for mm in sola.finditer(src[i:j]):
                malos.append(f"{f.name}:{src[:i + mm.start()].count(chr(10)) + 1}")
    assert not malos, malos
    js = (RAIZ / "static" / "js" / "soporte.js").read_text(encoding="utf-8")
    assert "{{textoDoc(d)}}" in js and "textoDoc(d) {" in js


def test_portal_con_estilos_propios(qa):
    css = (RAIZ / "static" / "soporte.css").read_text(encoding="utf-8")
    raiz = re.search(r":root\{([^}]*)\}", css)
    assert raiz, "soporte.css debe definir sus colores en :root"
    for var in ("--p:", "--line:", "--muted:"):
        assert var in raiz.group(1), var
    for regla in (".btn{", ".btn.sm{", ".btn.gris{", "label.f{", ".seg{", "body{"):
        assert regla in css, regla
    c = qa.c
    cfg = c.get("/api/tike/config").json()
    assert c.put("/api/tike/config", json={**cfg, "portal_activo": True, "slug": SLUG}).status_code == 200
    html = c.get(f"/soporte/{SLUG}").text
    assert 'href="/soporte.css"' in html and 'src="/js/soporte.js"' in html


# ------------------------------------------------------------------------------------------------- servicios:2 (permiso facturar)
def test_tecnico_sin_facturar_no_crea_borradores_ni_cobros(qa):
    c = qa.c
    cli = _cliente(c, "Cliente Permisos QA", "3101387702")
    ct = _contrato(c, cli["id"], 2, 20000)
    t = _ticket(c, cli["id"], "Revisión de red", 180)
    tec = qa.como("Técnico de soporte")
    assert tec.get(f"/api/tike/tickets/{t['id']}").status_code == 200                                     # sigue atendiendo el ticket
    assert tec.get(f"/api/tike/tickets/{t['id']}/facturar").status_code == 403
    assert _facturar(tec, t["id"]).status_code == 403
    nuevo = {"cliente_id": cli["id"], "tipo": "visitas", "cantidad": 2, "periodo": "mensual", "cuota": 30000, "facturar_cuota": True, "inicio": "2026-11-04"}
    assert tec.post("/api/tike/contratos", json=nuevo).status_code == 403
    assert tec.put(f"/api/tike/contratos/{ct['id']}", json={**nuevo, "tipo": "horas", "cuota": 1000}).status_code == 403
    assert tec.put(f"/api/tike/contratos/{ct['id']}", json={**nuevo, "tipo": "horas", "cuota": 0, "facturar_cuota": False}).status_code == 403
    assert tec.get("/api/tike/contratos").status_code == 200 and tec.get(f"/api/tike/contratos/{ct['id']}").status_code == 200
    with Session(engine_empresa(qa.eid)) as s:
        assert not s.exec(select(modulos.Borrador)).all() and not s.exec(select(modulos.Recurrente)).all()
    adm = qa.como("Administrador")                                                                       # el administrador sí
    assert _facturar(adm, t["id"]).status_code == 200
    assert adm.post("/api/tike/contratos", json=nuevo).json()["recurrente_id"]
    js = (RAIZ / "static/js/pages/tike/ticket.js").read_text(encoding="utf-8")
    assert "sesion.puede('facturar')" in js
    js = (RAIZ / "static/js/pages/tike/contratos.js").read_text(encoding="utf-8")
    assert js.count("sesion.puede('facturar')") >= 2


# ------------------------------------------------------------------------------------------------- servicios:3 (horas de más)
def test_no_cobra_dos_veces_la_misma_hora_ni_la_bolsa(qa):
    c = qa.c
    cli = _cliente(c, "Cliente Bolsa QA", "3101387703")
    otro = _cliente(c, "Cliente Sin Contrato QA", "3101387704")
    # Caso A: bolsa de 2 h a ₡20.000, ticket de 3 h y un repuesto de ₡5.000 → 1 h + repuesto una sola vez
    ca = _contrato(c, cli["id"], 2, 20000)
    ta = _ticket(c, cli["id"], "Servidor caído", 180)
    assert ta["contrato_id"] == ca["id"]
    assert c.post(f"/api/tike/tickets/{ta['id']}/items", json={"detalle": "Cable de red", "cantidad": 1, "precio_unitario": 5000}).status_code == 200
    p0 = c.get(f"/api/tike/tickets/{ta['id']}/facturar").json(); assert p0["horas"] == 1 and len(p0["items"]) == 1
    r = _facturar(c, ta["id"], cobrado_visto=p0["cobrado_marca"]); assert r.status_code == 200, r.text
    b1 = r.json(); assert abs(b1["total"] - 28250) < 1
    p = c.get(f"/api/tike/tickets/{ta['id']}/facturar").json(); assert p["horas"] == 0 and p["items"] == [] and p["ya_horas"] == 1
    assert _facturar(c, ta["id"]).status_code == 400                                                    # nada que facturar
    # otra persona tenía el diálogo abierto con la previa de antes: la misma hora otra vez no, se le pide abrirlo de nuevo
    r = _facturar(c, ta["id"], horas=1, incluir_items=False, cobrado_visto=p0["cobrado_marca"]); assert r.status_code == 409 and "vuelva a abrir" in r.json()["detail"]
    v = c.get(f"/api/tike/tickets/{ta['id']}").json(); assert v["por_cobrar"]["horas"] == 0 and v["por_cobrar"]["repuestos"] == 0
    r = c.put(f"/api/tike/tickets/{ta['id']}", json={"contrato_id": 0}); assert r.status_code == 400 and "elimine primero" in r.json()["detail"]   # borrador pendiente
    # el borrador se descarta sin emitir: la hora y el repuesto vuelven a quedar por cobrar
    assert c.delete(f"/api/borradores/{b1['borrador_id']}").json()["ok"]
    p = c.get(f"/api/tike/tickets/{ta['id']}/facturar").json(); assert p["horas"] == 1 and len(p["items"]) == 1
    b1 = _facturar(c, ta["id"]).json(); assert abs(b1["total"] - 28250) < 1
    # al emitir, el borrador se borra junto con la factura: eso NO devuelve las horas, y un borrador nuevo que reciba el mismo número
    # tampoco las libera al eliminarlo
    with Session(engine_empresa(qa.eid)) as s:
        s.delete(s.get(modulos.Borrador, b1["borrador_id"])); s.commit()
    otro_b = c.post("/api/borradores", json={"tipo_documento": "04", "lineas": [{"detalle": "Venta suelta", "cabys": "8313300000000", "cantidad": 1, "precio_unitario": 1000, "unidad_medida": "Sp", "codigo_tarifa": "08", "tarifa": 13}]})
    assert otro_b.status_code == 200, otro_b.text
    assert otro_b.json()["id"] == b1["borrador_id"]                                                      # SQLite reutilizó el número
    assert c.delete(f"/api/borradores/{otro_b.json()['id']}").json()["ok"]
    assert c.get(f"/api/tike/tickets/{ta['id']}/facturar").json()["horas"] == 0
    # ya facturado: el contrato sigue sin cambiarse, pero el mensaje ya no pide eliminar un borrador que no existe
    r = c.put(f"/api/tike/tickets/{ta['id']}", json={"contrato_id": 0}); assert r.status_code == 400 and "ya se facturaron" in r.json()["detail"], r.text
    # Caso B: bolsa de 2 h a ₡10.000 compartida por dos tickets de 3 h (6 h usadas, 4 h de excedente) → ₡45.200 con IVA, no ₡67.800
    cli_b = _cliente(c, "Cliente Dos Tickets QA", "3101387705")
    cb = _contrato(c, cli_b["id"], 2, 10000)
    t1 = _ticket(c, cli_b["id"], "Correo no sale", 180); t2 = _ticket(c, cli_b["id"], "Impresora", 180)
    assert c.get(f"/api/tike/contratos/{cb['id']}").json()["consumo"]["excedente"] == 4
    assert c.get(f"/api/tike/tickets/{t1['id']}/facturar").json()["horas"] == 3
    p2_antes = c.get(f"/api/tike/tickets/{t2['id']}/facturar").json(); assert p2_antes["horas"] == 3
    b_1 = _facturar(c, t1["id"]).json(); assert abs(b_1["total"] - 33900) < 1
    p2 = c.get(f"/api/tike/tickets/{t2['id']}/facturar").json(); assert p2["horas"] == 1                 # solo lo que falta del excedente
    # el diálogo del segundo ticket se abrió antes de cobrar el primero: sus 3 h ya no valen (la bolsa es la misma)
    assert _facturar(c, t2["id"], horas=3, cobrado_visto=p2_antes["cobrado_marca"]).status_code == 409
    b_2 = _facturar(c, t2["id"], horas=p2["horas"], cobrado_visto=p2["cobrado_marca"]).json(); assert abs(b_2["total"] - 11300) < 1
    assert abs(b_1["total"] + b_2["total"] - 45200) < 1
    assert c.get(f"/api/tike/tickets/{t1['id']}/facturar").json()["horas"] == 0 and c.get(f"/api/tike/tickets/{t2['id']}/facturar").json()["horas"] == 0
    # más trabajo en el periodo: solo la hora nueva
    c.post(f"/api/tike/tickets/{t2['id']}/entradas", json={"tipo": "nota", "texto": "Otra hora", "minutos": 60})
    assert c.get(f"/api/tike/tickets/{t1['id']}/facturar").json()["horas"] == 0 and c.get(f"/api/tike/tickets/{t2['id']}/facturar").json()["horas"] == 1
    # Caso C: sin contrato, 2 h a ₡15.000 una sola vez; cobro parcial deja el resto pendiente
    tc_ = _ticket(c, otro["id"], "Instalación", 120)
    assert tc_["contrato_id"] is None
    r = _facturar(c, tc_["id"], tarifa_hora=15000, horas=1.5); assert r.status_code == 200 and abs(r.json()["total"] - 1.5 * 15000 * 1.13) < 1
    assert c.get(f"/api/tike/tickets/{tc_['id']}/facturar").json()["horas"] == 0.5
    r = _facturar(c, tc_["id"], tarifa_hora=15000); assert abs(r.json()["total"] - 0.5 * 15000 * 1.13) < 1
    assert _facturar(c, tc_["id"], tarifa_hora=15000).status_code == 400
    with Session(engine_empresa(qa.eid)) as s:                                                           # lo cobrado queda registrado por borrador
        cobros = s.exec(select(tc.TicketCobro).where(tc.TicketCobro.ticket_id == tc_["id"])).all()
        assert sorted(x.minutos for x in cobros) == [30, 90] and all(x.borrador_id for x in cobros)


def test_se_puede_cobrar_mas_de_lo_anotado_sin_cobrarlo_dos_veces(qa):
    """Hora mínima en una visita de 30 min, tarifa fija en un ticket sin tiempo y horas a mano en un contrato por visitas: se cobran
    (como antes de 3.87) y lo cobrado queda registrado, así que no se ofrece otra vez."""
    c = qa.c
    cli = _cliente(c, "Cliente Hora Minima QA", "3101387710")
    t = _ticket(c, cli["id"], "Visita corta", 30); assert t["contrato_id"] is None
    r = _facturar(c, t["id"], horas=1, tarifa_hora=15000); assert r.status_code == 200, r.text
    assert abs(r.json()["total"] - 16950) < 1
    assert c.get(f"/api/tike/tickets/{t['id']}/facturar").json()["horas"] == 0
    c.post(f"/api/tike/tickets/{t['id']}/entradas", json={"tipo": "nota", "texto": "Otros 30 min", "minutos": 30})
    assert c.get(f"/api/tike/tickets/{t['id']}/facturar").json()["horas"] == 0                         # la hora mínima ya los cubría
    sin_tiempo = _ticket(c, cli["id"], "Instalación a precio fijo", 0)
    v = c.get(f"/api/tike/tickets/{sin_tiempo['id']}").json(); assert v["por_cobrar"]["horas"] == 0 and v["estado"] != "cerrado"
    assert _facturar(c, sin_tiempo["id"], horas=2, tarifa_hora=10000).status_code == 200
    cli_v = _cliente(c, "Cliente Visitas QA", "3101387711")
    cv = c.post("/api/tike/contratos", json={"cliente_id": cli_v["id"], "nombre": "Visitas QA", "tipo": "visitas", "cantidad": 2, "periodo": "mensual",
                                             "tarifa_visita": 25000, "cuota": 0, "inicio": "2026-01-01", "facturar_cuota": False}).json()
    tv = _ticket(c, cli_v["id"], "Visita fuera de horario", 45); assert tv["contrato_id"] == cv["id"]
    assert c.get(f"/api/tike/tickets/{tv['id']}/facturar").json()["horas"] == 0
    r = _facturar(c, tv["id"], horas=1, tarifa_hora=20000); assert r.status_code == 200, r.text
    with Session(engine_empresa(qa.eid)) as s:
        cobros = {x.ticket_id: x for x in s.exec(select(tc.TicketCobro)).all()}
        assert cobros[t["id"]].minutos == 60 and cobros[sin_tiempo["id"]].minutos == 120
        assert cobros[tv["id"]].minutos == 60 and cobros[tv["id"]].contrato_id is None and cobros[tv["id"]].periodo == ""
    js = (RAIZ / "static/js/pages/tike/ticket.js").read_text(encoding="utf-8")
    assert ':max="fact.horas"' not in js and "cobrado_visto: f.cobrado_marca" in js


def test_dos_cobros_a_la_vez_no_cobran_lo_mismo(qa, monkeypatch):
    """La escritura se toma antes de calcular lo pendiente aunque el ticket se haya actualizado en el mismo segundo (antes, si
    «actualizado» no cambiaba, SQLAlchemy no mandaba el UPDATE, no se bloqueaba nada y dos peticiones cobraban las mismas 2 h)."""
    from app.config import ahora_cr
    c = qa.c
    cli = _cliente(c, "Cliente Concurrencia QA", "3101387712")
    t = _ticket(c, cli["id"], "Dos clics", 120)
    c.get("/api/tike/config")                                                    # la configuración ya existe: la petición no la crea
    fijo = ahora_cr().replace(microsecond=0)
    monkeypatch.setattr(tc, "ahora_cr", lambda: fijo)
    con = sqlite3.connect(engine_empresa(qa.eid).url.database, timeout=30, isolation_level=None)
    res = {}
    hilo = threading.Thread(target=lambda: res.update(r=_facturar(c, t["id"], tarifa_hora=15000)))
    try:
        con.execute("UPDATE ticket SET actualizado = ? WHERE id = ?", (fijo.isoformat(timespec="seconds"), t["id"]))   # «en este mismo segundo»
        con.execute("BEGIN IMMEDIATE")                                           # otra petición tiene la escritura…
        hilo.start(); time.sleep(1.5)
        con.execute("INSERT INTO ticketcobro (empresa_id, ticket_id, contrato_id, periodo, minutos, items, borrador_id, borrador_marca, usuario, creado) "
                    "VALUES (?, ?, NULL, '', 120, '[]', NULL, '', 'otra persona', ?)", (qa.eid, t["id"], fijo.isoformat()))
        con.execute("COMMIT")                                                    # …y termina de cobrar las 2 h
    finally:
        con.close()
    hilo.join(60)
    assert res["r"].status_code == 400, res["r"].text                           # esta esperó su turno y ya no encuentra nada que cobrar
    with Session(engine_empresa(qa.eid)) as s:
        assert [x.minutos for x in s.exec(select(tc.TicketCobro).where(tc.TicketCobro.ticket_id == t["id"])).all()] == [120]
        assert not s.exec(select(modulos.Borrador)).all()


# ------------------------------------------------------------------------------------------------- servicios:4 (dos pasos para ver contraseñas)
def test_solo_quien_configura_apaga_dos_pasos_de_contrasenas(qa):
    c = qa.c
    cli = _cliente(c, "Cliente Claves QA", "3101387706")
    x = c.post("/api/tike/docs", json={"cliente_id": cli["id"], "tipo": "clave", "nombre": "Router principal QA", "datos": {"usuario": "admin"}, "secreto": "Original-QA-387"}).json()
    av = qa.como("Avanzado")
    r = av.post(f"/api/tike/docs/{x['id']}/revelar", json={"accion": "ver"}); assert r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_mfa"
    cfg = av.get("/api/tike/config").json(); assert cfg["claves_2fa"] is True
    for rol in ("Técnico de soporte", "Avanzado"):
        r = qa.como(rol).put("/api/tike/config", json={**cfg, "claves_2fa": False}); assert r.status_code == 403, (rol, r.text)
    assert qa.como("Técnico de soporte").put("/api/tike/config", json={**cfg, "firma": "Soporte QA"}).status_code == 200   # lo demás sí lo guarda
    assert qa.como("Avanzado").post(f"/api/tike/docs/{x['id']}/revelar", json={"accion": "ver"}).status_code == 403
    adm = qa.como("Administrador")
    cfg = adm.get("/api/tike/config").json(); assert cfg["claves_2fa"] is True and cfg["firma"] == "Soporte QA"
    assert adm.put("/api/tike/config", json={**cfg, "claves_2fa": False}).json()["claves_2fa"] is False
    with Session(engine) as s:
        assert s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == qa.eid, auth.Auditoria.accion == "tike_claves_2fa")).first()
    assert qa.como("Técnico de soporte").put("/api/tike/config", json={**cfg, "claves_2fa": True}).json()["claves_2fa"] is True   # encenderla sí
    js = (RAIZ / "static/js/pages/tike/configuracion.js").read_text(encoding="utf-8")
    assert "sesion.puede('configurar')" in js


# ------------------------------------------------------------------------------------------------- servicios:6 (cambiar contraseñas)
def test_cambiar_contrasena_exige_permiso_y_queda_en_bitacora(qa):
    c = qa.c
    cli = _cliente(c, "Cliente Docs QA", "3101387707")
    cfg = c.get("/api/tike/config").json(); c.put("/api/tike/config", json={**cfg, "claves_2fa": False})
    x = c.post("/api/tike/docs", json={"cliente_id": cli["id"], "tipo": "clave", "nombre": "Router principal QA", "datos": {"usuario": "admin"}, "secreto": "Original-QA-387"}).json()
    base = {"cliente_id": cli["id"], "tipo": "clave", "nombre": "Router principal QA", "datos": {"usuario": "admin", "notas": "Rack 2"}}
    tec = qa.como("Técnico de soporte")
    r = tec.put(f"/api/tike/docs/{x['id']}", json={**base, "secreto": "Cambiada-por-tecnico-QA"}); assert r.status_code == 403
    r = tec.put(f"/api/tike/docs/{x['id']}", json={**base, "secreto": None}); assert r.status_code == 200 and r.json()["datos"]["notas"] == "Rack 2"   # lo demás sí
    assert tec.post("/api/tike/docs", json={**base, "nombre": "Switch QA", "secreto": "Nueva-del-tecnico"}).status_code == 200                 # crear una nueva sí
    adm = qa.como("Administrador")
    assert adm.post(f"/api/tike/docs/{x['id']}/revelar", json={"accion": "ver"}).json()["secreto"] == "Original-QA-387"
    d = adm.put(f"/api/tike/docs/{x['id']}", json={**base, "secreto": "Rotada-QA-387"}).json()
    assert d["accesos"][0]["accion"] == "cambiar" and d["accesos"][0]["usuario"] == qa.u["Administrador"].nombre and d["usuario"] == qa.u["Administrador"].nombre
    assert adm.post(f"/api/tike/docs/{x['id']}/revelar", json={"accion": "ver"}).json()["secreto"] == "Rotada-QA-387"
    js = (RAIZ / "static/js/pages/tike/documentacion.js").read_text(encoding="utf-8")
    assert "form.tipo==='clave' && (!form.id || puedeClaves)" in js


def test_quitar_contrasena_exige_permiso_y_queda_en_bitacora(qa):
    c = qa.c
    cli = _cliente(c, "Cliente Quitar Clave QA", "3101387713")
    x = c.post("/api/tike/docs", json={"cliente_id": cli["id"], "tipo": "clave", "nombre": "Firewall QA", "datos": {"usuario": "admin"}, "secreto": "Original-QA-387"}).json()
    nota = c.post("/api/tike/docs", json={"cliente_id": cli["id"], "tipo": "procedimiento", "nombre": "Horario QA", "datos": {"contenido": "8 a 5"}}).json(); assert nota["id"]
    tec = qa.como("Técnico de soporte")
    r = tec.delete(f"/api/tike/docs/{x['id']}"); assert r.status_code == 403, r.text
    assert tec.delete(f"/api/tike/docs/{nota['id']}").status_code == 200                                 # lo que no es contraseña sí
    adm = qa.como("Administrador")
    assert any(e["id"] == x["id"] for e in adm.get(f"/api/tike/docs?cliente_id={cli['id']}").json())     # sigue en la ficha
    assert adm.delete(f"/api/tike/docs/{x['id']}").json()["ok"]
    with Session(engine_empresa(qa.eid)) as s:
        assert [a.accion for a in s.exec(select(td.AccesoClave).where(td.AccesoClave.elemento_id == x["id"])).all()] == ["eliminar"]
    with Session(engine) as s:
        assert s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == qa.eid, auth.Auditoria.accion == "tike_clave_eliminar")).first()
    js = (RAIZ / "static/js/pages/tike/documentacion.js").read_text(encoding="utf-8")
    assert "v-if=\"det.tipo!=='clave' || puedeClaves\">Quitar" in js


# ------------------------------------------------------------------------------------------------- servicios:10 (clave temporal del portal)
def test_clave_temporal_del_portal_solo_sirve_para_cambiarla(qa):
    c = qa.c
    cli = _cliente(c, "Cliente Portal QA", "3101387708")
    cfg = c.get("/api/tike/config").json()
    assert c.put("/api/tike/config", json={**cfg, "portal_activo": True, "slug": SLUG}).status_code == 200
    c.post("/api/tike/tickets", json={"asunto": "Ticket del cliente", "cliente_id": cli["id"]})
    acc = c.post("/api/tike/accesos", json={"correo": "portal.tike387@example.test", "cliente_id": cli["id"]}).json()
    temporal = acc["clave_temporal"]; assert temporal
    r = c.post(f"/api/soporte/{SLUG}/acceso", json={"correo": "portal.tike387@example.test", "clave": temporal}).json()
    assert r["debe_cambiar"] is True
    H = {"X-Portal": r["token"]}
    for metodo, ruta, body in (("get", "/tickets", None), ("get", "/docs", None), ("post", "/tickets", {"asunto": "Otro", "descripcion": "Algo pasa"})):
        resp = getattr(c, metodo)(f"/api/soporte/{SLUG}{ruta}", headers=H, **({"json": body} if body else {}))
        assert resp.status_code == 403 and resp.json()["detail"]["codigo"] == "cambiar_clave", (ruta, resp.text)
    assert c.post(f"/api/soporte/{SLUG}/clave", json={"clave_actual": temporal, "clave_nueva": "Nueva-clave-portal-387"}, headers=H).json()["ok"]
    assert len(c.get(f"/api/soporte/{SLUG}/tickets", headers=H).json()) == 1
    js = (RAIZ / "static" / "js" / "soporte.js").read_text(encoding="utf-8")
    # el portal pregunta siempre al servidor (una marca vieja del navegador no obliga a cambiar la clave) y borra la marca si le responde
    assert "if (this.acceso) return this.misTickets();" in js and "const dudosa = " in js and "codigo === 'cambiar_clave'" in js


# ------------------------------------------------------------------------------------------------- servicios:12 (asignar a quien atiende)
def test_solo_se_asigna_a_quien_atiende_tickets(qa):
    c = qa.c
    t = c.post("/api/tike/tickets", json={"asunto": "Asignación QA"}).json()
    r = c.post(f"/api/tike/tickets/{t['id']}/asignar", json={"tecnico_id": qa.u["Vendedor"].id}); assert r.status_code == 400 and "atiende" in r.json()["detail"]
    r = c.post("/api/tike/tickets", json={"asunto": "Nuevo asignado al vendedor", "tecnico_id": qa.u["Vendedor"].id}); assert r.status_code == 400
    for rol in ("Técnico de soporte", "Avanzado", "Administrador"):
        r = c.post(f"/api/tike/tickets/{t['id']}/asignar", json={"tecnico_id": qa.u[rol].id}); assert r.status_code == 200 and r.json()["tecnico_id"] == qa.u[rol].id, rol
    assert {x["id"] for x in c.get("/api/tike/tecnicos").json()} >= {qa.u[r].id for r in ("Técnico de soporte", "Avanzado", "Administrador")}
