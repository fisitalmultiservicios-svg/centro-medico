# -*- coding: utf-8 -*-
"""Segunda validación 4.32 · lente «el día del cliente» · hallazgo 1 (recetas de antes de conectar y existencias).

Esta prueba describe lo que DEBERÍA pasar y por eso FALLA con el código que se va a entregar: muestra el defecto.
Los dos lados son de verdad (dos empresas): el programa (terminal 3, protocolo 2, carga inicial en «reenlace») y la web.
  1. El cliente armó antes de conectar un ingrediente (carne, 10 en bodega), un plato (hamburguesa) y la receta del plato. La web nunca
     tuvo el registro «recetas» (por eso la 4.31 no se lo pisó: /api/sinc/catalogo solo manda los registros que existen).
  2. Primera subida: se pregunta a la web por el rango 0 (contesta «nunca») y suben los dos ítems con su existencia. La receta NO.
  3. El cajero vende 2 hamburguesas: el programa rebaja 2 de carne. El comprobante sube; la web, sin receta, rebaja el plato.
  4. Bajada siguiente (sinc._bajar_existencias con lo que de verdad tiene la web): la carne del programa vuelve a 10.
No cambia la aplicación.

f3 (arreglo): copia de proyecto432_val/tests/test_val_dia_del_cliente_r1.py con dos agregados, marcados «f3»: la web recibe también la
receta de la cola (como recibe las dos altas de ítems) y, mientras esa receta no tiene veredicto, la venta del plato espera (no sube).
Sin el arreglo falla igual que la original: la receta no entra a la cola."""
import json
from sqlalchemy import text
from sqlmodel import Session, select

from app import inventario, modulos, sinc, sinc_completar as sc, sinc_datos_programa as sdp
from app import sinc_datos_decl  # noqa: F401
from app.db import Producto, engine_empresa, init_db
from tests.test_432_primera_subida import T, _L, _cerrar, _doc, _empresa as _empresa_web, _programa

init_db()
CABYS = "1234567890123"


def _hay(s, pid, bid) -> float:
    s.expire_all()
    return float(inventario.existencia(s, pid, bid).cantidad or 0)


def test_r1_la_receta_de_antes_de_conectar_sube_y_la_bajada_no_deshace_el_consumo_de_ingredientes():
    prog = _programa("reenlace", reservado={"producto": 0, "cliente": 0})
    web = _empresa_web()
    problemas = []
    try:
        with Session(engine_empresa(prog)) as sp:
            sp.add(Producto(id=501, empresa_id=prog, nombre="Carne molida QA", cabys=CABYS, precio=0, es_venta=False))
            sp.add(Producto(id=502, empresa_id=prog, nombre="Hamburguesa QA", cabys=CABYS, precio=4000))
            sp.commit()
            sinc._escribir(sp, prog, "recetas", [{"id": 1, "producto_id": 502, "rendimiento": 1, "ingredientes": [{"producto_id": 501, "cantidad": 1}]}])
            sp.commit()
            bp = inventario.bodega_principal(sp, prog).id
            inventario.registrar_movimiento(sp, producto=sp.get(Producto, 501), bodega_id=bp, tipo="inicial", cantidad=10, fecha="2026-11-01", costo_unitario=100)
            sp.commit()
        with Session(engine_empresa(web)) as sw:
            assert modulos.leer(sw, web, "recetas", None) is None          # la web nunca tuvo recetas: el catálogo de la 4.31 no las mandaba
            bw = inventario.bodega_principal(sw, web).id
        assert bp == bw                                                    # la bodega principal es la misma en los dos lados (bajó de la web)

        # --- 2. la primera subida: la web contesta «nunca» a todo lo que se le pregunta
        preguntadas = []

        def web_nunca(refs):
            preguntadas.extend((r["tipo"], r["ref"]) for r in refs)
            return {"filas": [{"tipo": r["tipo"], "ref": r["ref"], "estado": "nunca", "v": None, "datos": None} for r in refs], "max_dado": {"producto": 0, "cliente": 0}}
        _L(sc.paso_filas, prog, pedir_filas=web_nunca)
        with Session(engine_empresa(prog)) as sp:
            cola = {(t, r, o) for t, r, o in sp.execute(text("SELECT tipo, ref, op FROM sinc_cambio")).all()}
            assert ("producto", "501", "alta") in cola and ("producto", "502", "alta") in cola      # los ítems sí suben
            alta_carne = sc.existencias_para_alta(sp, prog, 501, sc.pendiente_por_producto(sp, prog))
        if not [c for c in cola if c[0] == "receta"]:
            problemas.append("la receta hecha antes de conectar no entra a la primera subida (preguntadas a la web: %s)"
                             % sorted({t for t, _ in preguntadas}))
        # la web recibe las dos altas (mismo id) y la existencia de la carne, como sinc_datos._op_fila
        with Session(engine_empresa(web)) as sw:
            sw.add(Producto(id=501, empresa_id=web, nombre="Carne molida QA", cabys=CABYS, precio=0, es_venta=False))
            sw.add(Producto(id=502, empresa_id=web, nombre="Hamburguesa QA", cabys=CABYS, precio=4000)); sw.flush()
            sc.existencia_inicial(sw, web, sw.get(Producto, 501), alta_carne)
            sw.commit()
            # f3: y la receta de la cola (su alta va en la misma tanda, detrás de los ítems)
            with Session(engine_empresa(prog)) as sp:
                filas = [json.loads(dt)["fila"] for (dt,) in sp.execute(text("SELECT datos FROM sinc_cambio WHERE tipo = 'receta' AND op = 'alta'")).all()]
            if filas:
                sinc._escribir(sw, web, "recetas", filas)
                sw.commit()
            assert _hay(sw, 501, bw) == 10

        _L(sdp._guardar_estado, prog, completar="reenlace")                 # f3: la carga ya preguntó por el rango 0 (como paso_carga)

        # --- 3. un día de ventas: 2 hamburguesas en el programa (rebaja su receta) y el comprobante sube a la web
        with Session(engine_empresa(prog)) as sp, Session(engine_empresa(web)) as sw:
            d = _doc(sp, prog, [(502, "Hamburguesa QA", 2)], fecha="2026-11-14T12:00:00-06:00")
            inventario.descontar_por_venta(sp, prog, d.id, d.consecutivo, bp, [{"producto_id": 502, "cantidad": 2}], "2026-11-14", permitir_negativo=True)
            sp.commit()
            assert _hay(sp, 501, bp) == 8 and _hay(sp, 502, bp) == 0       # el programa rebajó la carne, no el plato
            # f3: mientras la receta no tiene veredicto de la web, la venta del plato espera; con el veredicto, sube
            sp.execute(text("UPDATE sinc_cambio SET estado = :h WHERE tipo = 'producto'"), {"h": sdp.HECHA}); sp.commit()   # los ítems ya tienen veredicto
            assert d.id in _L(sdp.documentos_en_espera, sp, prog, [d])     # la receta todavía no: la venta del plato espera
            sp.execute(text("UPDATE sinc_cambio SET estado = :h WHERE tipo = 'receta'"), {"h": sdp.HECHA}); sp.commit()
            assert d.id not in _L(sdp.documentos_en_espera, sp, prog, [d])
            dd = sinc._doc_a_dict(sp, d, con_xml=False)
            recibidos, errores = sinc._guardar_documentos(sw, web, [dd], "Caja 1")
            assert recibidos == [d.clave] and not errores
            d.sinc_en = "2026-11-14T18:00:05+00:00"; d.sinc_estado = d.estado; sp.add(d); sp.commit()   # ya subió (como _subir_documentos)

            # --- 4. la bajada siguiente, con lo que de verdad tiene la web (lo mismo que arma GET /api/sinc/catalogo)
            bodegas = sw.exec(select(inventario.Bodega).where(inventario.Bodega.empresa_id == web)).all()
            j = {"bodegas": [b.model_dump() for b in bodegas], "productos": [p.model_dump() for p in sw.exec(select(Producto)).all()],
                 "existencias": [{"producto_id": x.producto_id, "bodega_id": x.bodega_id, "cantidad": x.cantidad, "costo_promedio": x.costo_promedio}
                                 for x in sw.exec(select(inventario.Existencia)).all()]}
            ajustes = _L(sinc._bajar_existencias, sp, prog, j, T)
            carne, plato = _hay(sp, 501, bp), _hay(sp, 502, bp)
            if carne != 8 or plato != 0:
                problemas.append("después de vender 2 hamburguesas el programa tenía carne = 8 y plato = 0; la bajada siguiente hizo %s ajustes "
                                 "«Existencia igualada a la de la nube» y dejó carne = %g y plato = %g (web: carne = %g, plato = %g)"
                                 % (ajustes, carne, plato, _hay(sw, 501, bw), _hay(sw, 502, bw)))
        assert not problemas, " | ".join(problemas)
    finally:
        _cerrar(prog)
