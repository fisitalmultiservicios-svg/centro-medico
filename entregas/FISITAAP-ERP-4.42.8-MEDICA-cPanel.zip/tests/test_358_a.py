"""3.58 (frente A): programa local publicado en la nube y actualización automática del exe, aviso del primer ingreso al crear una
cuenta, aviso de cédula repetida y funciones en prueba por empresa."""
import hashlib
import json
import types

from fastapi.testclient import TestClient
from sqlmodel import Session, select

import pytest

from app import actualizacion_local, auth, planes
from app.db import Empresa, engine, init_db


@pytest.fixture(autouse=True)
def _sin_superadmin_al_final():
    """test_api.py exige que al empezar no exista ningún administrador del sistema: el que crea este archivo se quita al terminar."""
    yield
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-358@example.test")).first()
        if u:
            s.delete(u); s.commit()


def _superadmin(s):
    u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-358@example.test")).first()
    if not u:
        u = auth.Usuario(correo="sa-358@example.test", nombre="SA 358", password_hash=auth.hash_password("Clave-Segura-358-QA!"), es_superadmin=True)
        s.add(u); s.commit(); s.refresh(u)
    return u


def _cliente():
    from app.main import app
    init_db()
    with Session(engine) as s:
        sa = _superadmin(s)
        e = s.exec(select(Empresa).where(Empresa.nombre == "Sucursal 358 QA")).first()
        if not e:
            e = Empresa(nombre="Sucursal 358 QA", numero_id="3-101-358358", actividad="620100", otras_senas="Centro comercial, local 3", correo="sucursal358@example.test", ambiente="sandbox", tipo_negocio="comercio")
            s.add(e); s.commit(); s.refresh(e)
        s.expunge(e)
        sa = types.SimpleNamespace(id=sa.id, correo=sa.correo, es_superadmin=True, nombre="SA", mfa_activo=True)
    ctx = auth.Contexto(sa, e, "Administrador")
    app.dependency_overrides[auth.superadmin] = lambda: sa
    app.dependency_overrides[auth.solo_usuario] = lambda: sa
    app.dependency_overrides[auth.contexto] = lambda: ctx
    return TestClient(app), e, app


def test_programa_local_publicado(tmp_path, monkeypatch):
    c, e, app = _cliente()
    monkeypatch.setattr(actualizacion_local, "CARPETA_NUBE", tmp_path / "local")
    try:
        assert c.get("/api/local/version").json() == {"version": None}
        assert c.get("/api/local/descargar").status_code == 404
        assert c.get("/api/admin/local").json()["publicado"] is None
        # validaciones
        assert c.post("/api/admin/local/publicar", files={"archivo": ("x.exe", b"a" * 2048, "application/octet-stream")}, data={"version": "1.x"}).status_code == 400
        assert c.post("/api/admin/local/publicar", files={"archivo": ("x.txt", b"a" * 2048, "application/octet-stream")}, data={"version": "1.46"}).status_code == 400
        assert c.post("/api/admin/local/publicar", files={"archivo": ("x.exe", b"a" * 10, "application/octet-stream")}, data={"version": "1.46"}).status_code == 400
        datos = b"MZ" + b"programa de prueba " * 200
        r = c.post("/api/admin/local/publicar", files={"archivo": ("GrupoFacturaLocal.exe", datos, "application/octet-stream")}, data={"version": "1.46"})
        assert r.status_code == 200, r.text
        p = r.json()["publicado"]
        assert p["version"] == "1.46" and p["bytes"] == len(datos) and p["sha256"] == hashlib.sha256(datos).hexdigest()
        v = c.get("/api/local/version").json()
        assert v["version"] == "1.46" and v["sha256"] == p["sha256"] and v["archivo"] == "GrupoFacturaLocal.exe"
        d = c.get("/api/local/descargar")
        assert d.status_code == 200 and d.content == datos
        assert not (tmp_path / "local" / "GrupoFacturaLocal.exe.subiendo").exists()
        # comparación de versiones y pendiente/aplicar del lado del exe
        assert actualizacion_local.mas_nueva("1.46", "1.45") and actualizacion_local.mas_nueva("1.10", "1.9") and not actualizacion_local.mas_nueva("1.45", "1.45")
        carpeta = tmp_path / "pc"; carpeta.mkdir()
        assert actualizacion_local.pendiente(carpeta) is None
        (carpeta / actualizacion_local.NUEVO).write_bytes(datos)
        (carpeta / "actualizacion.json").write_text(json.dumps({"version": "1.46", "sha256": p["sha256"], "bytes": len(datos), "listo": True, "fecha": "2026-11-01"}), encoding="utf-8")
        monkeypatch.setenv("FE_VERSION_LOCAL", "1.45")
        assert actualizacion_local.pendiente(carpeta)["version"] == "1.46"
        monkeypatch.setenv("FE_VERSION_LOCAL", "1.46")
        assert actualizacion_local.pendiente(carpeta) is None                              # ya instalada: no se repite
        monkeypatch.setenv("FE_VERSION_LOCAL", "1.45")
        (carpeta / actualizacion_local.NUEVO).write_bytes(datos + b"x")                     # alterado: no se instala
        assert actualizacion_local.pendiente(carpeta) is None
        # revisar(): descarga desde la nube (cliente de pruebas en lugar de httpx) y verifica
        class _Resp:
            def __init__(self, r): self.r = r
            def raise_for_status(self): assert self.r.status_code == 200
            def json(self): return self.r.json()
            def iter_bytes(self, n): yield self.r.content
            def __enter__(self): return self
            def __exit__(self, *a): return False
        import httpx
        monkeypatch.setattr(httpx, "get", lambda url, timeout=None: _Resp(c.get(url.replace("http://nube.test", ""))))
        monkeypatch.setattr(httpx, "stream", lambda m, url, timeout=None: _Resp(c.get(url.replace("http://nube.test", ""))))
        r = actualizacion_local.revisar("1.45", carpeta, "http://nube.test")
        assert r == {"nueva": "1.46", "descargada": True, "error": None}, r
        assert (carpeta / actualizacion_local.NUEVO).read_bytes() == datos and actualizacion_local.pendiente(carpeta)["version"] == "1.46"
        assert actualizacion_local.revisar("1.46", carpeta, "http://nube.test")["nueva"] is None   # ya está al día
        assert "vinculada" in actualizacion_local.revisar("1.45", carpeta, "")["error"]
        # quitar lo publicado
        assert c.delete("/api/admin/local").status_code == 200 and c.get("/api/local/version").json()["version"] is None
        # en la nube no existe el estado del programa local
        assert c.get("/api/local/estado").status_code == 404 and c.post("/api/local/reiniciar").status_code == 404
    finally:
        app.dependency_overrides.clear()


def test_cuenta_aviso_cedula_y_funciones():
    c, e, app = _cliente()
    try:
        # aviso del primer ingreso al crear una cuenta
        r = c.post("/api/admin/cuentas", json={"correo": "nueva358@example.test", "password": "Temporal-Segura-358!", "nombre_empresa": "Nueva 358 QA", "numero_id": "3101358358", "nombre_contacto": "Dueña", "tipo_negocio": "facturacion"})
        assert r.status_code == 200, r.text
        assert "dos pasos" in r.json()["aviso"] and "términos" in r.json()["aviso"]
        # cédula repetida: compara sin guiones; no incluye nada con una cédula distinta ni vacía
        rep = c.get("/api/admin/cuentas/cedula", params={"numero": "3101358358"}).json()["empresas"]
        assert {x["nombre"] for x in rep} >= {"Sucursal 358 QA", "Nueva 358 QA"} and all(x["tipo_negocio"] for x in rep)
        assert c.get("/api/admin/cuentas/cedula", params={"numero": "3-101-358358"}).json()["empresas"]
        assert c.get("/api/admin/cuentas/cedula", params={"numero": "9999999999"}).json()["empresas"] == []
        assert c.get("/api/admin/cuentas/cedula", params={"numero": "   "}).json()["empresas"] == []
        # funciones en prueba
        cat = c.get("/api/admin/planes").json()
        assert "subdominio" in cat["funciones"] and cat["funciones"]["ia_acciones"]["nombre"]
        assert c.put(f"/api/admin/cuentas/{e.id}/funciones", json={"funciones": ["no_existe"]}).status_code == 400
        r = c.put(f"/api/admin/cuentas/{e.id}/funciones", json={"funciones": ["subdominio", "subdominio"]})
        assert r.status_code == 200 and r.json()["funciones"] == ["subdominio"] and r.json()["plan"]["funciones"] == ["subdominio"]
        with Session(engine) as s:
            e2 = s.get(Empresa, e.id)
            assert planes.funcion_activa(e2, "subdominio") and not planes.funcion_activa(e2, "ia_acciones")
            e.funciones = e2.funciones
        assert c.get("/api/plan").json()["funciones"] == ["subdominio"]
        assert c.put(f"/api/admin/cuentas/{e.id}/funciones", json={"funciones": []}).json()["funciones"] == []
        assert c.put("/api/admin/cuentas/999999/funciones", json={"funciones": []}).status_code == 404
    finally:
        app.dependency_overrides.clear()
