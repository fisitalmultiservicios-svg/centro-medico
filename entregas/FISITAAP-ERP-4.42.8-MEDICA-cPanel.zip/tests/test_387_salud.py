"""3.87: salud del sistema en la consola y empresas ocultas que se seguían viendo.
- El respaldo general (trae las bases de TODAS las empresas) solo lo crea, descarga o borra un administrador del sistema que las ve
  todas; al limitado no se le listan ni los generales ni los respaldos de sus empresas ocultas.
- Cédula repetida, registro de clientes (CSV) y auditoría sin lo que habla de las empresas ocultas (la auditoría filtra antes del
  límite).
- Tarjeta «Salud del sistema» (/api/admin/salud): cola y quién la corrió, cron, comprobantes sin respuesta, el último respaldo REAL,
  carpeta de respaldos dentro de la aplicación, advertencias del servidor sin claves; nunca secretos ni empresas ocultas.
- «Procesar ahora» con el mismo cerrojo que el cron; el cron queda anotado.
- Resumen diario por correo a los administradores del sistema (envío simulado: nunca un correo real), cada uno sin sus empresas ocultas.
- Empleados activos contra los incluidos en el extra de Recursos humanos en la consola (sin bloquear)."""
import json
import logging
import pathlib
import threading
from datetime import timedelta

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, cola, config, correo, modulos, planes, respaldo, salud, sitio
from app.config import ahora_cr
from app.db import EMPRESAS_DIR, Auditoria, Documento, Empresa, engine, engine_empresa, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent
P_CORREO, L_CORREO = "principal.salud387@example.test", "limitado.salud387@example.test"
SOLO_OCULTA, AMBAS = "solo.oculta.salud387@example.test", "ambas.salud387@example.test"
CORREOS = (P_CORREO, L_CORREO, SOLO_OCULTA, AMBAS)
CED_V, CED_O = "3101387501", "3101387502"
N_V, N_O = "Salud Visible 387 QA", "Salud Oculta 387 QA"


def _usuario(correo_):
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo_)).first()
        if u:
            s.expunge(u)
        return u


def _como(correo_):
    """La consola con este usuario: se reemplaza solo la sesión; la dependencia superadmin real (con las empresas ocultas) se ejecuta."""
    app.dependency_overrides[auth.solo_usuario] = lambda: _usuario(correo_)


@pytest.fixture
def consola():
    init_db()
    zips_antes = {p.name for p in respaldo.RESPALDOS_DIR.glob("facturacr_*.zip")} if respaldo.RESPALDOS_DIR.is_dir() else set()
    with Session(engine) as s:
        ev = auth.crear_empresa(s, N_V, "visible.salud387@example.test", CED_V).id
        eo = auth.crear_empresa(s, N_O, "oculta.salud387@example.test", CED_O).id
        for c_, sa, princ in ((P_CORREO, True, True), (L_CORREO, True, False), (SOLO_OCULTA, False, False), (AMBAS, False, False)):
            s.add(auth.Usuario(correo=c_, nombre=c_.split("@")[0], password_hash=auth.hash_password("Clave-larga-387-salud"), es_superadmin=sa,
                               admin_principal=princ, mfa_activo=True, debe_cambiar_password=False, terminos_version=auth.TERMINOS_VERSION,
                               empresas_ocultas=json.dumps([eo]) if c_ == L_CORREO else "[]"))
        s.commit()
        uid = {c_: s.exec(select(auth.Usuario).where(auth.Usuario.correo == c_)).first().id for c_ in CORREOS}
        s.add(auth.UsuarioEmpresa(usuario_id=uid[SOLO_OCULTA], empresa_id=eo, rol="Administrador"))
        s.add(auth.UsuarioEmpresa(usuario_id=uid[AMBAS], empresa_id=eo, rol="Vendedor"))
        s.add(auth.UsuarioEmpresa(usuario_id=uid[AMBAS], empresa_id=ev, rol="Vendedor"))
        s.commit()
    _como(P_CORREO)
    try:
        yield TestClient(app), ev, eo, uid
    finally:
        app.dependency_overrides.pop(auth.solo_usuario, None)
        with Session(engine) as s:
            for x in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id.in_(list(uid.values())))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id.in_(list(uid.values())))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for x in s.exec(select(auth.Usuario).where(auth.Usuario.correo.in_(CORREOS))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for x in s.exec(select(sitio.SolicitudContacto).where(sitio.SolicitudContacto.correo.like("%salud387@example.test"))).all():  # type: ignore[attr-defined]
                s.delete(x)
            for eid in (ev, eo):
                e = s.get(Empresa, eid)
                if e:
                    s.delete(e)
            s.commit()
        from app.db import _engines
        for eid in (ev, eo):
            hit = _engines.pop(eid, None)
            if hit is not None:
                hit[0].dispose()
            for suf in ("", "-wal", "-shm"):
                (EMPRESAS_DIR / f"empresa_{eid}.db{suf}").unlink(missing_ok=True)
            for r in respaldo.listar_empresa(eid):
                respaldo.eliminar_empresa(eid, r["nombre"])
        if respaldo.RESPALDOS_DIR.is_dir():
            for p in respaldo.RESPALDOS_DIR.glob("facturacr_*.zip"):
                if p.name not in zips_antes:
                    p.unlink(missing_ok=True)
        for f in (cola.ULTIMA_FILE, cola.CRON_FILE, salud.CONFIG, salud.MARCA_RESUMEN, respaldo.MARCA_DESCARGA):
            f.unlink(missing_ok=True)


# ----------------------------------------------------------------------------- admin_sistema:2 (respaldo general)
def test_respaldo_general_solo_lo_maneja_quien_ve_todas_las_empresas(consola):
    c, ev, eo, _ = consola
    r = c.post("/api/admin/respaldos"); assert r.status_code == 200, r.text
    nombre = r.json()["nombre"]
    with Session(engine) as s:
        e = s.get(Empresa, eo); s.expunge(e)
    de_oculta = respaldo.ejecutar_empresa(e, forzar=True).name           # la empresa oculta creó el suyo
    _como(L_CORREO)
    assert c.post("/api/admin/respaldos").status_code == 403
    assert c.get(f"/api/admin/respaldos/{nombre}").status_code == 403
    assert c.delete(f"/api/admin/respaldos/{nombre}").status_code == 403
    j = c.get("/api/admin/respaldos").json()
    assert j["respaldos"] == [] and j["general"] is False and j["ultimo_real"] is None and j["ultimo"] is None and j["ultima_descarga"] is None
    assert eo not in [x["empresa_id"] for x in j["empresas"]] and N_O not in json.dumps(j)
    assert c.get(f"/api/admin/respaldos/empresa/{eo}/{de_oculta}").status_code == 404
    # el super administrador: todo igual que antes, con el zip real más reciente y la descarga anotada
    _como(P_CORREO)
    j = c.get("/api/admin/respaldos").json()
    assert j["general"] is True and j["ultimo_real"] == respaldo.listar()[0] and nombre in [x["nombre"] for x in j["respaldos"]]
    assert eo in [x["empresa_id"] for x in j["empresas"]] and j["dentro_app"] is False
    d = c.get(f"/api/admin/respaldos/{nombre}"); assert d.status_code == 200 and d.content[:2] == b"PK"
    j = c.get("/api/admin/respaldos").json()
    assert j["ultima_descarga"]["nombre"] == nombre and j["ultima_descarga"]["por"] == P_CORREO
    assert any(x["accion"] == "respaldo_descargado" and nombre in (x["detalle"] or "") for x in c.get("/api/admin/auditoria?limite=50").json())
    assert c.delete(f"/api/admin/respaldos/{nombre}").status_code == 200


def test_empresa_oculta_ya_eliminada_no_limita_pero_sus_respaldos_viejos_no_se_entregan(consola):
    """La lista de ocultas no se depura al eliminar una empresa: ese id ya no limita al administrador (antes, 403 en el respaldo general y
    «limitado» en Salud para siempre), pero los generales de antes que todavía traen su base no se le listan ni se le entregan."""
    import zipfile
    c, ev, eo, uid = consola
    with Session(engine) as s:
        borrada = max(s.exec(select(Empresa.id)).all()) + 1000                       # un id que ya no existe
        u = s.get(auth.Usuario, uid[L_CORREO]); u.empresas_ocultas = json.dumps([borrada]); s.add(u); s.commit()
    respaldo.RESPALDOS_DIR.mkdir(parents=True, exist_ok=True)
    viejo, nuevo = "facturacr_20991231_235958.zip", "facturacr_20991231_235959.zip"   # el viejo trae la base de la eliminada
    for n, dentro in ((viejo, [f"data/empresas/empresa_{borrada}.db", "data/facturacr.db"]), (nuevo, ["data/facturacr.db"])):
        with zipfile.ZipFile(respaldo.RESPALDOS_DIR / n, "w") as z:
            for x in dentro:
                z.writestr(x, b"prueba 387")
    _como(L_CORREO)
    r = c.post("/api/admin/respaldos"); assert r.status_code == 200, r.text
    j = c.get("/api/admin/respaldos").json()
    nombres = [x["nombre"] for x in j["respaldos"]]
    assert j["general"] is True and nuevo in nombres and viejo not in nombres and r.json()["nombre"] in nombres
    assert c.get(f"/api/admin/respaldos/{nuevo}").status_code == 200
    assert c.get(f"/api/admin/respaldos/{viejo}").status_code == 403 and c.delete(f"/api/admin/respaldos/{viejo}").status_code == 403
    assert c.get("/api/admin/respaldos/facturacr_20991231_000000.zip").status_code == 404
    assert c.get("/api/admin/salud").json()["limitado"] is False
    assert c.delete(f"/api/admin/respaldos/{nuevo}").status_code == 200
    _como(P_CORREO)                                                              # el super administrador sí lo maneja
    assert c.get(f"/api/admin/respaldos/{viejo}").status_code == 200 and c.delete(f"/api/admin/respaldos/{viejo}").status_code == 200


# ----------------------------------------------------------------------------- admin_sistema:5 (cédula, CSV, auditoría)
def test_cedula_csv_y_auditoria_sin_empresas_ocultas(consola):
    c, ev, eo, uid = consola
    # filas de auditoría sin empresa que hablan de lo oculto (las crea el super administrador o el propio usuario)
    assert c.put(f"/api/admin/administradores/{uid[L_CORREO]}/empresas", json={"ocultas": [eo]}).status_code == 200   # «… no ve: Salud Oculta 387 QA»
    assert c.post(f"/api/admin/usuarios/{uid[SOLO_OCULTA]}/password", json={"password": "Clave-Larga-Segura-387-QA!"}).status_code == 200
    with Session(engine) as s:
        solo, ambas, p = (s.get(auth.Usuario, uid[x]) for x in (SOLO_OCULTA, AMBAS, P_CORREO))
        auth.auditar(s, "mfa_fallido", "Código MFA incorrecto", solo)
        auth.auditar(s, "login_fallido", "Correo o contraseña incorrectos", None, correo=SOLO_OCULTA)
        auth.auditar(s, "mfa_fallido", "Código MFA incorrecto", ambas)              # pertenece también a una visible: se sigue viendo
        auth.auditar(s, "prueba_387_hecha_en_visible", "Factura hecha cuando era vendedor de la visible", solo, ev)   # se sigue viendo
        for i in range(4):
            auth.auditar(s, "prueba_387_visible", f"visible {i}", p, ev)
        for i in range(5):                                                       # las más recientes son de la oculta
            auth.auditar(s, "prueba_387_oculta", f"oculta {i}", p, eo)
    _como(L_CORREO)
    assert c.get(f"/api/admin/cuentas/cedula?numero={CED_O}").json()["empresas"] == []
    assert [x["id"] for x in c.get(f"/api/admin/cuentas/cedula?numero={CED_V}").json()["empresas"]] == [ev]
    csv = c.get("/api/admin/registro-clientes"); assert csv.status_code == 200
    assert CED_O not in csv.text and N_O not in csv.text and CED_V in csv.text
    aud = c.get("/api/admin/auditoria?limite=1000").json()
    sin_empresa = [x for x in aud if x["empresa_id"] is None]
    texto = json.dumps(aud, ensure_ascii=False)
    assert N_O not in texto and SOLO_OCULTA not in json.dumps(sin_empresa, ensure_ascii=False)
    assert not [x for x in aud if x["empresa_id"] == eo] and not [x for x in sin_empresa if x["usuario_id"] == uid[SOLO_OCULTA]]
    assert any(x["usuario_id"] == uid[AMBAS] for x in aud) and any(x["accion"] == "prueba_387_visible" for x in aud)
    # lo que ese usuario hizo en la empresa visible no desaparece (antes el filtro por usuario también escondía esas filas)
    for q in ("limite=1000", f"limite=1000&empresa_id={ev}"):
        assert [x for x in c.get(f"/api/admin/auditoria?{q}").json() if x["accion"] == "prueba_387_hecha_en_visible" and x["empresa_id"] == ev], q
    tres = c.get("/api/admin/auditoria?limite=3").json()                         # el límite se aplica después del filtro
    assert [x["accion"] for x in tres] == ["prueba_387_visible"] * 3
    # el super administrador sigue viéndolo todo (registro completo del art. 5 incluido)
    _como(P_CORREO)
    assert {x["id"] for x in c.get(f"/api/admin/cuentas/cedula?numero={CED_O}").json()["empresas"]} == {eo}
    assert CED_O in c.get("/api/admin/registro-clientes").text
    texto = json.dumps(c.get("/api/admin/auditoria?limite=1000").json(), ensure_ascii=False)
    assert N_O in texto and SOLO_OCULTA in texto and "prueba_387_oculta" in texto


def test_auditoria_no_esconde_de_mas_ni_devuelve_menos(consola):
    """El nombre de la oculta se busca completo (no como pedazo del nombre de una visible), «Empresa N (…)» decide por el número y el
    límite se cumple aunque el filtro en Python quite muchas filas."""
    c, ev, eo, uid = consola
    mayor = f"Soda y {N_O} Demo"                                                  # una visible cuyo nombre contiene el de la oculta
    with Session(engine) as s:
        e = s.get(Empresa, ev); e.nombre_comercial = mayor; s.add(e); s.commit()
        p = s.get(auth.Usuario, uid[P_CORREO])
        se_ven = [("prueba_387_v_id", f"Empresa {ev} ({mayor} S.A.): 3 comprobantes de ejemplo borrados"),
                  ("prueba_387_v_mayor", f"Revisión de {mayor}"),
                  ("admin_sistema_empresas", f"otro.salud387@example.test no ve: {mayor}"),
                  ("prueba_387_v_pedazo", f"Revisión de {N_O}X")]
        no_se_ven = [("prueba_387_o_id", f"Empresa {eo} ({N_O} S.A.): 3 comprobantes de ejemplo borrados"),
                     ("prueba_387_o_nombre", f"Revisión de {N_O}."),
                     ("admin_sistema_empresas", f"otro.salud387@example.test no ve: Otra, {N_O}")]
        for acc, det in se_ven + no_se_ven:
            auth.auditar(s, acc, det, p)
        for i in range(3):
            auth.auditar(s, "prueba_387_v_ultimas", f"visible {i}", p, ev)
        for i in range(130):                                                     # más que una tanda: las más recientes nombran a la oculta
            auth.auditar(s, "prueba_387_o_nombre", f"Aviso {i} de {N_O}", p)
    _como(L_CORREO)
    aud = c.get("/api/admin/auditoria?limite=1000").json()
    dets = {x["detalle"] for x in aud}
    assert all(d in dets for _, d in se_ven), [d for _, d in se_ven if d not in dets]
    assert not [d for _, d in no_se_ven if d in dets] and not [x for x in aud if x["accion"] == "prueba_387_o_nombre"]
    assert [x["accion"] for x in c.get("/api/admin/auditoria?limite=3").json()] == ["prueba_387_v_ultimas"] * 3


# ----------------------------------------------------------------------------- idea 1: tarjeta «Salud del sistema»
def _doc(eid, estado, horas, n=1):
    with Session(engine) as s:
        e = s.get(Empresa, eid)
    with Session(engine_empresa(eid)) as se:
        for i in range(n):
            se.add(Documento(empresa_id=eid, tipo_documento="01", clave=f"506{eid}{estado}{i}387", consecutivo=f"0010000101{('firmado', 'enviado', 'error').index(estado)}{i:09d}", ambiente=e.ambiente,
                             fecha_emision=(ahora_cr() - timedelta(hours=horas)).isoformat(timespec="seconds"), estado=estado))
        se.commit()


def test_salud_del_sistema_sin_secretos_ni_empresas_ocultas(consola, monkeypatch, tmp_path):
    c, ev, eo, _ = consola
    _doc(ev, "firmado", 30); _doc(ev, "enviado", 2, n=2); _doc(eo, "error", 1)
    monkeypatch.setattr(config, "CRON_TOKEN", "token-secreto-salud-387-no-sale")
    salud.instalar_registro()
    logging.getLogger("app.prueba387").warning("Cola Hacienda, empresa %s, 00100001: fallo de prueba", eo)
    logging.getLogger("app.prueba387").warning("Prueba 387 con password=Secreto-387-QA y token: abcdef1234567890")
    j = c.get("/api/admin/salud").json()
    filas = {f["clave"]: f for f in j["filas"]}
    assert {"cola", "cron", "cron_token", "atascados", "respaldo", "respaldo_carpeta", "respaldo_descarga", "espacio", "version", "correo", "llaves",
            "advertencias", "resumen"} <= set(filas)
    assert all(f["estado"] in ("ok", "aviso", "mal", "info") for f in j["filas"]) and j["semaforo"] in ("ok", "aviso", "mal")
    x = next(a for a in j["atascados"] if a["empresa_id"] == ev)
    assert (x["firmado"], x["enviado"], x["error"]) == (1, 2, 0) and x["horas"] >= 29
    assert filas["atascados"]["estado"] == "mal" and eo in [a["empresa_id"] for a in j["atascados"]]
    assert j["puede_configurar"] is True and j["limitado"] is False and filas["cron_token"]["estado"] == "ok"
    texto = json.dumps(j, ensure_ascii=False)
    assert "token-secreto-salud-387-no-sale" not in texto and "Secreto-387-QA" not in texto and "abcdef1234567890" not in texto
    assert "AQUI_EL_TOKEN" in j["cron"]["comando"] and j["cron"]["token_definido"] is True and j["cron"]["url"].endswith("/api/cola/procesar")
    assert any("fallo de prueba" in a["mensaje"] for a in j["advertencias"])
    # el administrador limitado: sin la empresa oculta en ningún lado, sin el respaldo general ni los totales de la pasada
    _como(L_CORREO)
    j = c.get("/api/admin/salud").json()
    texto = json.dumps(j, ensure_ascii=False)
    assert eo not in [a["empresa_id"] for a in j["atascados"]] and N_O not in texto and "fallo de prueba" not in texto
    assert j["limitado"] is True and j["puede_configurar"] is False
    assert {f["clave"]: f for f in j["filas"]}["respaldo"]["estado"] == "info" and "respaldo_descarga" not in {f["clave"] for f in j["filas"]}
    # respaldo que falta de verdad (aunque la marca diga «hoy») y carpeta de respaldos dentro de la aplicación
    _como(P_CORREO)
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", tmp_path / "sin_respaldos")
    respaldo.MARCA.write_text(ahora_cr().isoformat(timespec="seconds"), encoding="utf-8")
    filas = {f["clave"]: f for f in c.get("/api/admin/salud").json()["filas"]}
    assert filas["respaldo"]["estado"] == "mal" and filas["respaldo_carpeta"]["estado"] == "ok"
    assert c.get("/api/admin/respaldos").json()["ultimo_real"] is None
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", config.BASE_DIR / "respaldos_qa_387_no_se_crea")
    assert respaldo.ubicacion_segura() is False
    filas = {f["clave"]: f for f in c.get("/api/admin/salud").json()["filas"]}
    assert filas["respaldo_carpeta"]["estado"] == "mal" and "FE_RESPALDOS_DIR=" in filas["respaldo_carpeta"]["accion"]
    j = c.get("/api/admin/respaldos").json()
    assert j["dentro_app"] is True and j["carpeta_sugerida"]
    assert not (config.BASE_DIR / "respaldos_qa_387_no_se_crea").exists()
    monkeypatch.setattr(respaldo, "RESPALDOS_DIR", config.DATA_DIR / "respaldos_dentro_de_data")
    assert respaldo.ubicacion_segura() is True                                   # dentro de data/ no se pierde al desplegar
    respaldo.MARCA.unlink(missing_ok=True)


def test_sin_sesion_no_hay_salud_y_ping_no_dice_nada():
    c = TestClient(app)
    assert c.get("/api/admin/salud").status_code == 401
    assert c.post("/api/admin/cola/procesar").status_code == 401
    assert c.put("/api/admin/salud/resumen", json={"activo": False}).status_code == 401
    r = c.get("/api/ping")
    assert r.status_code == 200 and r.json() == {"ok": True}
    assert salud._tapar("clave=abc123 PASSWORD: xyz Bearer abcdefghijklmnopqrstu") == "clave=*** PASSWORD: *** Bearer ***"
    # 3.87: claves cortas después de un espacio, dentro de una dirección y en el encabezado de autorización (van al correo diario)
    assert salud._tapar("login con password Hunter22 fallo") == "login con password *** fallo"
    assert salud._tapar("smtp://user:Secreta123@host:465 no responde") == "smtp://user:***@host:465 no responde"
    assert salud._tapar("Authorization Basic dXNlcjpwYXNz") == "Authorization Basic ***"
    assert salud._tapar("Token de Hacienda vencido; contraseña incorrecta") == "Token de Hacienda vencido; contraseña incorrecta"   # sin claves: igual


# ----------------------------------------------------------------------------- idea 2: cron verificable y «Procesar ahora»
def test_cola_anota_quien_la_corrio_y_procesar_ahora_usa_el_mismo_cerrojo(consola, monkeypatch):
    c, *_ = consola
    from app import main
    monkeypatch.setattr(cola, "_procesar_todas", lambda limite=50: {"empresas": 2, "hora": "x", "resultados": [
        {"enviados": 2, "aceptados": 1, "errores": 0}, {"enviados": 0, "aceptados": 0, "errores": 1}]})
    for f in (cola.ULTIMA_FILE, cola.CRON_FILE):
        f.unlink(missing_ok=True)
    assert cola.procesar_todas(origen="hilo")["empresas"] == 2
    d = cola.ultima_pasada()
    assert d["origen"] == "hilo" and (d["empresas"], d["enviados"], d["aceptados"], d["errores"]) == (2, 2, 1, 1) and d["duracion_ms"] >= 0
    assert cola.ultimo_cron() is None                                          # el hilo no es el cron
    cola.procesar_todas(origen="cron")
    assert cola.ultimo_cron()["origen"] == "cron" and cola.ultima_pasada()["origen"] == "cron"
    cola._pasada.acquire()                                                     # una pasada en curso: la segunda no corre
    try:
        assert cola.en_curso() and cola.procesar_todas(origen="consola") == {"omitido": "otra pasada de la cola está en curso"}
        assert c.post("/api/admin/cola/procesar").status_code == 409
    finally:
        cola._pasada.release()
    assert not cola.en_curso() and cola.ultima_pasada()["origen"] == "cron"
    # «Procesar ahora»: en un hilo, con origen consola y quién la pidió
    llamadas, hecho = [], threading.Event()
    monkeypatch.setattr(cola, "procesar_todas", lambda **kw: (llamadas.append(kw), hecho.set()))
    r = c.post("/api/admin/cola/procesar"); assert r.status_code == 200 and r.json()["iniciada"]
    assert hecho.wait(5) and llamadas[-1] == {"origen": "consola", "por": P_CORREO}
    # el endpoint del cron pasa origen «cron»
    monkeypatch.setattr(main, "CRON_TOKEN", "tok-salud-387")
    monkeypatch.setattr(cola, "procesar_todas", lambda **kw: llamadas.append(kw) or {"ok": True})
    assert TestClient(app).post("/api/cola/procesar", headers={"X-Cron-Token": "tok-salud-387"}).status_code == 200
    assert llamadas[-1] == {"origen": "cron"}
    g = c.get("/api/admin/cron-guia").json()
    assert "AQUI_EL_TOKEN" in g["comando"] and "tok-salud-387" not in json.dumps(g) and g["log"].endswith("cola.log")
    fuente = (RAIZ / "app" / "cola.py").read_text(encoding="utf-8")
    assert 'procesar_todas(origen="hilo")' in fuente


def test_pasada_real_de_la_cola_anota_y_manda_el_resumen(consola, monkeypatch):
    """La pasada de verdad (procesar_todas → _procesar_todas) anota quién la corrió y llama al resumen diario. Se simula todo lo que sale
    del servidor: Hacienda, buzones, correos, cobros y el respaldo; nunca se envía nada."""
    c, ev, eo, _ = consola
    from app import main, pedidos, publicidad, suscripcion, tike, tike_docs
    for mod, nombre in ((cola, "procesar_empresa"), (main, "procesar_recurrentes_todas"), (main, "leer_buzones_todas"), (main, "recordatorios_cobro_todas"),
                        (main, "hotel_diario_todas"), (planes, "recordatorios_vencimiento"), (suscripcion, "sincronizar_todas"), (publicidad, "procesar_seguro"),
                        (pedidos, "revisar_pagos_todas"), (tike, "leer_buzones_todas"), (tike_docs, "avisar_vencimientos_todas"), (respaldo, "diario")):
        monkeypatch.setattr(mod, nombre, lambda *a, **k: {"empresa_id": None, "enviados": 0, "aceptados": 0, "errores": 0})
    enviados = []
    monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: correo.ConfigSMTP("smtp.invalido.example.test", 465, None, None, "sistema@example.test"))
    monkeypatch.setattr(correo, "enviar", lambda cfg, para, asunto, html, texto, adj, cc=None: enviados.append((para[0], texto)))
    monkeypatch.setattr(salud, "HORA_RESUMEN", 0)
    for f in (salud.MARCA_RESUMEN, salud.CONFIG, cola.ULTIMA_FILE, cola.CRON_FILE):
        f.unlink(missing_ok=True)
    r = cola.procesar_todas(origen="consola", por=P_CORREO)
    assert "omitido" not in r, r
    u = cola.ultima_pasada()
    assert u["origen"] == "consola" and u["por"] == P_CORREO and cola.ultimo_cron() is None
    para = {p: t for p, t in enviados}
    assert P_CORREO in para and L_CORREO in para and N_O not in para[L_CORREO]
    assert salud.ultimo_resumen()["enviados"] >= 2
    assert cola.procesar_todas(origen="cron")["empresas"] >= 0 and len([p for p, _ in enviados if p == P_CORREO]) == 1   # una vez al día
    assert cola.ultimo_cron()["origen"] == "cron"


# ----------------------------------------------------------------------------- idea 9: resumen diario por correo
def test_resumen_diario_una_vez_al_dia_y_sin_empresas_ocultas(consola, monkeypatch):
    c, ev, eo, _ = consola
    # nunca un correo real: el servidor de correo es inventado y el envío se simula
    monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: correo.ConfigSMTP("smtp.invalido.example.test", 465, None, None, "sistema@example.test",
                                                                         copia="copia.empresa@example.test"))
    enviados = []

    def falso(cfg, para, asunto, html, texto):
        enviados.append({"cfg": cfg, "para": para, "asunto": asunto, "html": str(html), "texto": texto})
    hoy = ahora_cr().date()
    with Session(engine) as s:
        for eid, dias in ((ev, 2), (eo, 1)):
            e = s.get(Empresa, eid); e.prueba_hasta = (hoy + timedelta(days=dias)).isoformat(); s.add(e)
        s.add(sitio.SolicitudContacto(nombre="Solicitante Salud 387", empresa="Ferretería 387", correo="solicitante.salud387@example.test", telefono="88887777"))
        s.commit()
    salud.MARCA_RESUMEN.unlink(missing_ok=True)
    salud.CONFIG.unlink(missing_ok=True)                                       # sin archivo = encendido
    ahora = ahora_cr().replace(hour=7, minute=30)
    assert salud.resumen_diario(enviar=falso, ahora=ahora.replace(hour=6))["omitido"].startswith("antes de las")
    r = salud.resumen_diario(enviar=falso, ahora=ahora)
    assert r["enviados"] >= 2 and not r["errores"]
    mios = {x["para"][0]: x for x in enviados if x["para"][0] in (P_CORREO, L_CORREO)}
    assert set(mios) == {P_CORREO, L_CORREO} and len([x for x in enviados if x["para"][0] == P_CORREO]) == 1
    assert all(x["cfg"].copia is None and len(x["para"]) == 1 for x in enviados)   # nunca con copia al buzón de una empresa
    p, l_ = mios[P_CORREO], mios[L_CORREO]
    assert N_V in p["texto"] and N_O in p["texto"] and "Solicitante Salud 387" in p["texto"]
    assert N_V in l_["texto"] and N_O not in l_["texto"] + l_["html"] + l_["asunto"]
    for x in (p, l_):                                                           # del cliente, solo nombres y cantidades
        assert "solicitante.salud387@example.test" not in x["texto"] + x["html"] and "88887777" not in x["texto"] + x["html"]
    n = len(enviados)
    assert salud.resumen_diario(enviar=falso, ahora=ahora.replace(hour=11))["omitido"] == "ya se envió hoy" and len(enviados) == n
    # interruptor: solo el super administrador; apagado no sale
    _como(L_CORREO)
    assert c.put("/api/admin/salud/resumen", json={"activo": False}).status_code == 403
    _como(P_CORREO)
    assert c.put("/api/admin/salud/resumen", json={"activo": False}).json() == {"ok": True, "activo": False}
    salud.MARCA_RESUMEN.unlink(missing_ok=True)
    assert salud.resumen_diario(enviar=falso, ahora=ahora)["omitido"] == "apagado" and len(enviados) == n
    assert {f["clave"]: f for f in c.get("/api/admin/salud").json()["filas"]}["resumen"]["valor"] == "Apagado"
    # vista previa en la consola: no envía nada
    v = c.get("/api/admin/salud/resumen/vista").json()
    assert v["asunto"].startswith("Resumen del") and "<html" in v["html"] and len(enviados) == n
    # sin correo de la plataforma no se marca el día (lo intenta en la siguiente pasada)
    salud.CONFIG.unlink(missing_ok=True)
    monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: None)
    assert salud.resumen_diario(enviar=falso, ahora=ahora)["omitido"] == "sin correo de la plataforma" and salud.ultimo_resumen() is None


# ----------------------------------------------------------------------------- extras:11: empleados contra el plan
def test_empleados_activos_contra_el_limite_del_plan(consola, monkeypatch):
    c, ev, eo, _ = consola
    with Session(engine) as s:
        e = s.get(Empresa, ev); planes.asignar(e, {"plan": "fac_250", "extras": ["rrhh"]}); s.add(e)
        o = s.get(Empresa, eo); planes.asignar(o, {"plan": "fac_250", "extras": []}); s.add(o)
        s.commit()
    with Session(engine_empresa(ev)) as se:
        modulos.reemplazar(se, ev, "empleados", [{"id": i, "nombre": f"Empleado {i}", "activo": True} for i in range(1, 17)]
                           + [{"id": 17, "nombre": "Salió", "activo": False}])
        se.commit()
    cuentas = {x["id"]: x for x in c.get("/api/admin/cuentas").json()}
    assert cuentas[ev]["empleados"] == {"activos": 16, "incluidos": 10, "excedente": 6, "cargo": 6000}   # 3.90: 10 incluidos, ₡1.000 cada adicional
    assert cuentas[ev]["plan"]["empleados_incluidos"] == 10 and cuentas[ev]["plan"]["precio_empleado_extra"] == 1000
    assert cuentas[eo]["empleados"] is None and cuentas[eo]["plan"]["empleados_incluidos"] == 0     # sin Recursos humanos
    with Session(engine) as s:
        e = s.get(Empresa, ev); e.plan = None; s.add(e); s.commit(); s.refresh(e)
        assert planes.empleados_incluidos(e) == 0                                 # sin plan (todo encendido): sin límite
    # sin bloquear: el 18.º se guarda igual
    with Session(engine_empresa(ev)) as se:
        lista = modulos.leer(se, ev, "empleados", []) + [{"id": 18, "nombre": "Empleado 18", "activo": True}]
        modulos.reemplazar(se, ev, "empleados", lista, version=modulos._registro(se, ev, "empleados").version); se.commit()
        assert len(modulos.leer(se, ev, "empleados", [])) == 18
    # sin plan (todo encendido) y sin empleados: nada que mostrar (antes salía «Empleados: 0 activo(s)» en cada empresa así)
    with Session(engine) as s:
        o = s.get(Empresa, eo); o.plan = None; s.add(o); s.commit()
    assert {x["id"]: x for x in c.get("/api/admin/cuentas").json()}[eo]["empleados"] is None
    assert {x["id"]: x for x in c.get("/api/admin/cuentas").json()}[ev]["empleados"]["activos"] == 17   # sin límite, pero con el conteo (el 17 salió)
    # hotel: por habitación con el extra comprado, sí; paquete «todo incluido», sin cargo por empleado (pendiente de decidir)
    from types import SimpleNamespace
    hotel = dict(tipo_negocio="hospitalidad", extras='["rrhh"]', es_demo=False, prueba_hasta=None, modulos_ocultos="[]")
    assert planes.empleados_incluidos(SimpleNamespace(plan="hotel", **hotel)) == 10
    assert planes.empleados_incluidos(SimpleNamespace(plan="hotel_40", **hotel)) == 0
    assert planes.empleados_incluidos(SimpleNamespace(plan="hotel_50", **{**hotel, "extras": "[]"})) == 0
    # si el conteo de empleados falla, la consola no pierde el de documentos (antes iban en el mismo try y quedaba en 0)
    _doc(ev, "firmado", 1)

    def falla(e, s):
        raise RuntimeError("registro de empleados dañado")
    monkeypatch.setattr(planes, "empleados_plan", falla)
    x = {x["id"]: x for x in c.get("/api/admin/cuentas").json()}[ev]
    assert x["documentos"] == 1 and x["empleados"] is None


# ----------------------------------------------------------------------------- interfaz
def test_consola_trae_la_tarjeta_de_salud_y_rrhh_avisa():
    js = (RAIZ / "app/static/js/pages/admin.js").read_text(encoding="utf-8")
    for t in ("@click=\"verSalud\">Salud</button>", "/api/admin/salud", "/api/admin/cola/procesar", "Procesar ahora", "copiarCron", "AQUI_EL_TOKEN",
              "respaldos.ultimo_real", "respaldos.dentro_app", "FE_RESPALDOS_DIR=", "v-if=\"respaldos.general !== false\"", "guardarResumen",
              "c.empleados.excedente", "Salud del sistema:"):
        assert t in js, t
    assert "Último: {{respaldos.ultimo ? fechaHora(respaldos.ultimo)" not in js           # ya no confía en la marca
    rr = (RAIZ / "app/static/js/pages/rrhh/empleados.js").read_text(encoding="utf-8")
    assert "empleados_incluidos" in rr and "this.activos.length > inc" in rr and "import { sesion as sesionPlan } from '../../app.js';" in rr
