"""3.87: funciones nuevas para el dueño.
- Aviso por correo cuando Hacienda rechaza un comprobante de producción (o lo deja en error), con el motivo en palabras simples;
  una ráfaga se junta en un solo correo; los atascados más de 24 h se avisan una vez al día. Nunca en pruebas (sandbox), en la demo,
  con el interruptor apagado ni al anular a propósito. Si el correo falla, el comprobante queda igual.
- Cierre de caja (reporte Z) en PDF por correo a «Enviar el cierre a» de la caja (el destinatario lo fija la configuración, no la petición).
- Existencia mínima y máxima por ítem: Inventario › Por reponer con la cantidad sugerida y el proveedor habitual, aviso en el Inicio,
  orden de compra sugerida y la columna en la importación de ítems. Sin mínimo, nada cambia."""
import io
import pathlib
import types
import uuid
from datetime import timedelta

import pytest
from fastapi.testclient import TestClient
from openpyxl import Workbook, load_workbook
from sqlmodel import Session, select

from app import auth, avisos_dueno, correo, modulos, secretos, sitio
from app import main as m
from app.config import ahora_cr
from app.db import Auditoria, Documento, Empresa, Producto, engine, engine_empresa, init_db

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
CABYS = "2395100000100"


# ------------------------------------------------------------------------------------------------ apoyo
def _nueva_empresa(nombre, ambiente="produccion", **kw):
    init_db()
    with Session(engine) as s:
        e = Empresa(nombre=nombre, numero_id="3101" + str(uuid.uuid4().int)[:6], actividad="620100", otras_senas="Frente al parque central",
                    correo=kw.pop("correo", f"dueno.{uuid.uuid4().hex[:6]}@example.test"), ambiente=ambiente, **kw)
        s.add(e); s.commit(); s.refresh(e); s.expunge(e)
    return e


def _usuario(eid, correo_u, rol, **kw):
    with Session(engine) as s:
        u = auth.Usuario(correo=correo_u, nombre=correo_u.split("@")[0], password_hash="x", terminos_version=auth.TERMINOS_VERSION, **kw)
        s.add(u); s.commit(); s.refresh(u)
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol=rol)); s.commit()
        return u.id


def _limpiar(eids):
    with Session(engine) as s:
        for eid in eids:
            for x in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == eid)).all():
                u = s.get(auth.Usuario, x.usuario_id)
                s.delete(x)
                if u and u.correo.endswith("@example.test"):
                    s.delete(u)
            e = s.get(Empresa, eid)
            if e:
                s.delete(e)
        s.commit()
    avisos_dueno._fallo.clear(); avisos_dueno._revisado.clear()


def _doc(eid, estado="enviado", ambiente="produccion", tipo="04", horas=1, **kw):
    ahora = ahora_cr() - timedelta(hours=horas)
    with Session(engine_empresa(eid)) as s:
        n = 1 + len(s.exec(select(Documento.id).where(Documento.empresa_id == eid)).all())
        d = Documento(empresa_id=eid, tipo_documento=tipo, clave=str(uuid.uuid4().int)[:50].ljust(50, "0"), consecutivo=f"0010000104{n:010d}",
                      fecha_emision=ahora.isoformat(timespec="seconds"), fecha_envio=ahora.isoformat(timespec="seconds"), receptor_nombre="Cliente Aviso QA",
                      total=11300, moneda="CRC", estado=estado, ambiente=ambiente, **kw)
        s.add(d); s.commit(); s.refresh(d); s.expunge(d)
    return d


class _Hacienda:
    def __init__(self, consulta, envio=None):
        self.consulta, self.envio = consulta, envio

    def consultar(self, clave):
        return dict(self.consulta)

    def enviar(self, *a, **k):
        return dict(self.envio)


@pytest.fixture()
def correos(monkeypatch):
    """Envío simulado: el correo de la plataforma es un SMTP de mentira y correo.enviar solo anota (nunca sale nada)."""
    enviados = []
    monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: correo.ConfigSMTP("smtp.plataforma.example.test", 465, None, None, "avisos@example.test"))
    monkeypatch.setattr(correo, "enviar", lambda cfg, para, asunto, html, texto, adj, cc=None: enviados.append(
        types.SimpleNamespace(cfg=cfg, para=list(para), asunto=asunto, html=str(html), texto=texto, adjuntos=adj)))
    avisos_dueno._fallo.clear(); avisos_dueno._revisado.clear()
    return enviados


def _consultar(e, d, estado="rechazado", detalle="El teléfono del emisor no cumple con el formato requerido", monkeypatch=None):
    monkeypatch.setattr(m, "_cliente_hacienda", lambda emp: _Hacienda({"estado": estado, "status": 200, "detalle": detalle, "respuesta_xml": None}))
    with Session(engine_empresa(e.id)) as s:
        doc = s.get(Documento, d.id)
        m.consultar_documento(s, e, doc, sincrono=True)
        s.refresh(doc); s.expunge(doc)
        return doc


def _aviso_de(eid, did):
    with Session(engine_empresa(eid)) as s:
        return s.get(Documento, did).aviso_enviado


# ------------------------------------------------------------------------------------------------ aviso de rechazo
def test_rechazo_en_produccion_avisa_al_dueno_y_a_quien_factura(correos, monkeypatch):
    e = _nueva_empresa("Soda Aviso Rechazo QA", correo="dueno.rechazo@example.test")
    try:
        _usuario(e.id, "vendedora.rechazo@example.test", "Vendedor")                    # factura: recibe
        _usuario(e.id, "contador.rechazo@example.test", "Contador")                     # no factura ni configura: no recibe
        _usuario(e.id, "bloqueado.rechazo@example.test", "Administrador", bloqueado=True)
        d = _doc(e.id)
        doc = _consultar(e, d, monkeypatch=monkeypatch)
        assert doc.estado == "rechazado"                                                 # el estado se aplica igual que siempre
        assert len(correos) == 1
        c = correos[0]
        assert c.para == ["dueno.rechazo@example.test", "vendedora.rechazo@example.test"]
        assert c.cfg.host == "smtp.plataforma.example.test"                              # correo de la plataforma: llega sin SMTP propio
        assert doc.consecutivo in c.asunto and "Hacienda rechazó un comprobante" in c.html
        assert "8 dígitos" in c.html and "El teléfono del emisor" in c.html            # palabras simples + la respuesta original
        assert "Cliente Aviso QA" in c.html and "11.300,00" in c.html and "Ver el comprobante" in c.html
        assert f"/app/#/ventas/facturas/{d.id}" in c.html and "Configuración › Facturación electrónica" in c.texto
        assert (_aviso_de(e.id, d.id) or "").startswith("rechazado:")
        # consultarlo de nuevo (ya rechazado) no repite el aviso
        _consultar(e, d, monkeypatch=monkeypatch)
        assert len(correos) == 1
        with Session(engine) as s:
            assert s.exec(select(Auditoria).where(Auditoria.empresa_id == e.id, Auditoria.accion == "aviso_rechazo")).first()
    finally:
        _limpiar([e.id])


def test_error_al_enviar_tambien_avisa(correos, monkeypatch, tmp_path):
    e = _nueva_empresa("Comercio Error Envio QA", correo="dueno.error@example.test")
    try:
        d = _doc(e.id, estado="firmado", xml_nombre=f"qa387_{uuid.uuid4().hex[:8]}.xml")
        (m.XML_DIR / d.xml_nombre).write_bytes(b"<FacturaElectronica/>")
        monkeypatch.setattr(m, "_cliente_hacienda", lambda emp: _Hacienda({"estado": "no_encontrado", "status": 404},
                                                                              {"ok": False, "status": 400, "error": "El código de actividad no existe", "duplicado": False}))
        with Session(engine_empresa(e.id)) as s:
            doc = s.get(Documento, d.id)
            m.enviar_documento(s, e, doc, sincrono=True)
            assert doc.estado == "error"
        assert len(correos) == 1 and "Hacienda no recibió" in correos[0].asunto and "actividad económica" in correos[0].html
        (m.XML_DIR / d.xml_nombre).unlink(missing_ok=True)
    finally:
        _limpiar([e.id])


def test_sin_aviso_en_pruebas_demo_apagado_ni_al_anular(correos, monkeypatch):
    sb = _nueva_empresa("Empresa Sandbox Aviso QA", ambiente="sandbox")
    demo = _nueva_empresa("Empresa Demo Aviso QA", es_demo=True)
    apagado = _nueva_empresa("Empresa Aviso Apagado QA", aviso_rechazo=False)
    anula = _nueva_empresa("Empresa Anula QA")
    try:
        _consultar(sb, _doc(sb.id, ambiente="sandbox"), monkeypatch=monkeypatch)
        _consultar(demo, _doc(demo.id), monkeypatch=monkeypatch)
        d_apagado = _doc(apagado.id)
        assert _consultar(apagado, d_apagado, monkeypatch=monkeypatch).estado == "rechazado"
        assert correos == [] and _aviso_de(apagado.id, d_apagado.id) is None
        # anular a propósito (anular también pasa por «rechazado»): ni en el momento ni en la pasada de la cola
        from app.main import app
        d = _doc(anula.id, estado="error")
        app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo="qa.anula@example.test", es_superadmin=False, nombre="QA"), anula, "Administrador")
        try:
            r = TestClient(app).post(f"/api/comprobantes/{d.id}/anular")
            assert r.status_code == 200 and r.json()["estado"] == "rechazado"
        finally:
            app.dependency_overrides.clear()
        avisos_dueno.pasada(ahora_cr() + timedelta(hours=2))
        assert correos == [] and _aviso_de(anula.id, d.id) is None
    finally:
        _limpiar([sb.id, demo.id, apagado.id, anula.id])


def test_rafaga_de_rechazos_se_junta_en_un_correo(correos, monkeypatch):
    e = _nueva_empresa("Restaurante Rafaga QA", correo="dueno.rafaga@example.test")
    try:
        d1, d2, d3 = _doc(e.id), _doc(e.id), _doc(e.id)
        _consultar(e, d1, monkeypatch=monkeypatch)
        _consultar(e, d2, monkeypatch=monkeypatch)
        _consultar(e, d3, monkeypatch=monkeypatch)
        assert len(correos) == 1                                                        # el primero sale; los otros esperan
        assert (_aviso_de(e.id, d2.id) or "").startswith("pendiente:rechazado:")
        assert avisos_dueno.pasada(ahora_cr() + timedelta(minutes=2)) == [] and len(correos) == 1   # todavía dentro de la espera
        avisos_dueno.pasada(ahora_cr() + timedelta(minutes=11))
        assert len(correos) == 2 and "Hacienda rechazó 2 comprobantes" in correos[1].html
        assert d2.consecutivo in correos[1].html and d3.consecutivo in correos[1].html and d1.consecutivo not in correos[1].html
        assert (_aviso_de(e.id, d3.id) or "").startswith("rechazado:")
        avisos_dueno.pasada(ahora_cr() + timedelta(minutes=30))
        assert len(correos) == 2                                                        # nada se repite
    finally:
        _limpiar([e.id])


def test_si_el_correo_falla_el_comprobante_queda_igual_y_se_reintenta(correos, monkeypatch):
    e = _nueva_empresa("Comercio Correo Caido QA", correo="dueno.caido@example.test")
    try:
        def falla(*a, **k):
            raise correo.ErrorCorreo("No se pudo conectar con smtp.plataforma.example.test:465")
        bien = correo.enviar
        monkeypatch.setattr(correo, "enviar", falla)
        d = _doc(e.id)
        doc = _consultar(e, d, monkeypatch=monkeypatch)                                  # no lanza
        assert doc.estado == "rechazado" and doc.mensaje_hacienda.startswith("El teléfono")
        assert (_aviso_de(e.id, d.id) or "").startswith("pendiente:rechazado:")         # vuelve a pendiente
        with Session(engine) as s:
            assert s.exec(select(Auditoria).where(Auditoria.empresa_id == e.id, Auditoria.accion == "aviso_rechazo_fallido")).first()
        monkeypatch.setattr(correo, "enviar", bien)
        avisos_dueno.pasada(ahora_cr() + timedelta(minutes=5))
        assert correos == []                                                            # no se insiste enseguida contra un correo caído
        avisos_dueno.pasada(ahora_cr() + timedelta(minutes=40))
        assert len(correos) == 1 and (_aviso_de(e.id, d.id) or "").startswith("rechazado:")
    finally:
        _limpiar([e.id])


def test_sin_correo_de_plataforma_usa_el_de_la_empresa(correos, monkeypatch):
    e = _nueva_empresa("Comercio SMTP Propio QA", correo="dueno.smtp@example.test", smtp_host="smtp.empresa.example.test",
                       smtp_remitente="facturas@example.test", smtp_copia="archivo@example.test")
    try:
        monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: None)
        monkeypatch.setattr(secretos, "descifrar", lambda *a, **k: "clave")
        _consultar(e, _doc(e.id), monkeypatch=monkeypatch)
        assert len(correos) == 1 and correos[0].cfg.host == "smtp.empresa.example.test" and correos[0].cfg.copia is None
    finally:
        _limpiar([e.id])


def test_atascados_mas_de_un_dia_una_vez_al_dia(correos):
    e = _nueva_empresa("Hotel Atascados QA", correo="dueno.atascado@example.test")
    try:
        viejo = _doc(e.id, estado="enviado", horas=30)
        _doc(e.id, estado="firmado", horas=2)                                           # menos de 24 h: no
        _doc(e.id, estado="enviado", horas=30, ambiente="sandbox")                     # de pruebas: no
        ahora = ahora_cr()
        avisos_dueno.pasada(ahora)
        assert len(correos) == 1 and "sin respuesta de Hacienda" in correos[0].asunto and viejo.consecutivo in correos[0].html
        assert (_aviso_de(e.id, viejo.id) or "").startswith("atascado:")
        otro = _doc(e.id, estado="firmado", horas=26)
        avisos_dueno._revisado.clear()                                                  # como otro proceso: la marca del día está en la base
        avisos_dueno.pasada(min(ahora + timedelta(hours=1), ahora.replace(hour=23, minute=59, second=59)))   # 3.95: el mismo día aunque la prueba corra cerca de la medianoche
        assert len(correos) == 1                                                        # uno por día
        avisos_dueno.pasada(ahora + timedelta(days=1))
        assert len(correos) == 2 and otro.consecutivo in correos[1].html and viejo.consecutivo not in correos[1].html
    finally:
        _limpiar([e.id])


def test_interruptor_del_aviso(monkeypatch):
    from app.main import app
    e = _nueva_empresa("Empresa Interruptor QA")
    try:
        def ctx(rol):
            app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo="qa.int@example.test", es_superadmin=False, nombre="QA"), e, rol)
        c = TestClient(app)
        ctx("Vendedor")
        assert c.put("/api/empresa/aviso-rechazo", json={"activo": False}).status_code == 403
        ctx("Administrador")
        assert c.get("/api/empresa").json()["aviso_rechazo"] is True                  # encendido por defecto
        r = c.put("/api/empresa/aviso-rechazo", json={"activo": False})
        assert r.status_code == 200 and r.json()["aviso_rechazo"] is False
        with Session(engine) as s:
            assert s.get(Empresa, e.id).aviso_rechazo is False
    finally:
        app.dependency_overrides.clear()
        _limpiar([e.id])


def test_motivo_en_palabras_simples():
    assert "8 dígitos" in avisos_dueno.motivo_simple("El numero de Telefono del Receptor no es valido")
    assert "actividad económica" in avisos_dueno.motivo_simple("CodigoActividad no corresponde")
    assert "CABYS" in avisos_dueno.motivo_simple("El código CABYS 123 no existe")
    assert "no aceptó" in avisos_dueno.motivo_simple("")
    # 3.87 (revisión): textos comunes que caían en otro motivo
    assert "correo electrónico" in avisos_dueno.motivo_simple("El correo electrónico del receptor no es válido")
    assert "firma" not in avisos_dueno.motivo_simple("El comprobante firmado no cumple con el esquema").lower()
    assert "firma del comprobante" in avisos_dueno.motivo_simple("La firma digital no es válida")
    assert "IVA" not in avisos_dueno.motivo_simple("La línea respectiva no cumple con la regla exclusiva")
    assert "IVA" in avisos_dueno.motivo_simple("El IVA de la línea no corresponde")


# ------------------------------------------------------------------------------------------------ cierre de caja (Z) por correo
CIERRE = {"titulo": "Cierre de caja · Caja 1 · 05/11/2026", "subtitulo": "Cajero cajero.z@example.test", "periodo": "05/11/2026",
          "kpis": [{"t": "Ventas", "v": "3"}, {"t": "Total vendido", "v": "₡15.000,00"}, {"t": "Efectivo esperado", "v": "₡20.000,00"}, {"t": "Diferencia", "v": "₡-500,00"}],
          "secciones": [{"titulo": "Arqueo de efectivo", "columnas": [{"key": "d", "label": "Concepto"}, {"key": "v", "label": "Monto", "num": True}],
                         "filas": [{"d": "Efectivo esperado", "v": "₡20.000,00"}, {"d": "Efectivo contado", "v": "₡19.500,00"}]},
                        {"titulo": "Anulaciones (1)", "columnas": [{"key": "consecutivo", "label": "Comprobante"}, {"key": "total", "label": "Monto", "num": True}],
                         "filas": [{"consecutivo": "00100001040000000009", "total": "₡2.000,00"}]}],
          "nota": "Reporte de cierre (Z) del punto de venta."}


def _poner(eid, clave, datos):
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, clave, datos, version=modulos.versiones(s, eid).get(clave, 0)); s.commit()


def test_cierre_de_caja_por_correo(correos, monkeypatch):
    from app.main import app
    e = _nueva_empresa("Soda Cierre Z QA", ambiente="sandbox", smtp_host="smtp.soda.example.test", smtp_remitente="caja@example.test", tipo_negocio="restaurante")
    monkeypatch.setattr(secretos, "descifrar", lambda *a, **k: "clave")
    caja = {"id": 1, "caja": "Caja 1", "terminal_id": 1, "usuario": "cajero.z@example.test", "fecha": "2026-11-05", "estado": "Cerrada", "monto_inicial": 5000,
            "conteo": 19500, "diferencia": -500, "ventas": [], "retiros": []}
    _poner(e.id, "pos_cajas", [caja, {**caja, "id": 2, "estado": "Abierta", "diferencia": None}])
    _poner(e.id, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja 1", "correo_cierre": "dueno.z@example.test, socia.z@example.test"}]})

    def ctx(rol):
        app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo="cajero.z@example.test", es_superadmin=False, nombre="QA"), e, rol)
    c = TestClient(app)
    try:
        ctx("Cajero")
        r = c.post("/api/pos/cierres/correo", json={**CIERRE, "caja_id": 1, "para": "intruso@example.test"})   # «para» de la petición no cuenta
        assert r.status_code == 200, r.text
        assert r.json()["para"] == ["dueno.z@example.test", "socia.z@example.test"] and len(correos) == 1
        z = correos[0]
        assert z.para == ["dueno.z@example.test", "socia.z@example.test"] and "intruso" not in str(z.para)
        assert z.cfg.host == "smtp.soda.example.test" and z.cfg.copia is None             # el correo de la empresa
        assert "Cierre de caja" in z.asunto and "Caja 1" in z.asunto and "05/11/2026" in z.asunto
        assert "diferencia de" in z.html and "Total vendido" in z.html and "PDF adjunto" in z.html
        nombre, pdf_bytes, tipo, sub = z.adjuntos[0]
        assert nombre == "cierre_caja_1.pdf" and pdf_bytes.startswith(b"%PDF") and (tipo, sub) == ("application", "pdf")
        assert c.post("/api/pos/cierres/correo", json={**CIERRE, "caja_id": 2}).status_code == 409    # abierta
        assert c.post("/api/pos/cierres/correo", json={**CIERRE, "caja_id": 99}).status_code == 404
        # si el correo falla, la caja queda cerrada igual
        monkeypatch.setattr(correo, "enviar", lambda *a, **k: (_ for _ in ()).throw(correo.ErrorCorreo("servidor caído")))
        r = c.post("/api/pos/cierres/correo", json={**CIERRE, "caja_id": 1})
        assert r.status_code == 502 and "servidor caído" in r.json()["detail"]
        with Session(engine_empresa(e.id)) as s:
            assert next(x for x in modulos.leer(s, e.id, "pos_cajas", []) if x["id"] == 1)["estado"] == "Cerrada"
        # sin «Enviar el cierre a» no se envía; un rol sin punto de venta no puede
        _poner(e.id, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja 1", "correo_cierre": ""}]})
        r = c.post("/api/pos/cierres/correo", json={**CIERRE, "caja_id": 1})
        assert r.status_code == 400 and "Enviar el cierre a" in r.json()["detail"]
        ctx("Contador")
        assert c.post("/api/pos/cierres/correo", json={**CIERRE, "caja_id": 1}).status_code == 403
    finally:
        app.dependency_overrides.clear()
        _limpiar([e.id])


# ------------------------------------------------------------------------------------------------ existencia mínima y reposición
@pytest.fixture()
def tienda():
    from app.main import app
    e = _nueva_empresa("Perfumería Reponer QA", ambiente="sandbox", tipo_negocio="comercio")

    def ctx(rol):
        app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo="qa.reponer@example.test", es_superadmin=False, nombre="QA"), e, rol)
    ctx("Administrador")
    try:
        yield TestClient(app), e, ctx
    finally:
        app.dependency_overrides.clear()
        _limpiar([e.id])


def _prod(c, nombre, cantidad=None, **extra):
    r = c.post("/api/productos", json={"nombre": nombre, "cabys": CABYS, "precio": 10000, "tarifa": 13, "codigo_tarifa": "08", "costo": 4000, "cantidad_inicial": cantidad, **extra})
    assert r.status_code == 200, r.text
    return r.json()


def test_por_reponer_sugerido_proveedor_e_inicio(tienda):
    c, e, ctx = tienda
    _prod(c, "Perfume sin mínimo QA", 0)
    alertas = c.get("/api/inicio/alertas").json()["alertas"]
    assert not any("por reponer" in a["texto"] for a in alertas)                   # sin mínimo nada cambia
    assert c.get("/api/inventario/reponer").json() == {"con_minimo": 0, "items": []}
    a = _prod(c, "Perfume Rosa QA", 3, existencia_minima=5, existencia_maxima=12, codigo="PR-1")
    b = _prod(c, "Perfume Azul QA", 2, existencia_minima=2)
    _prod(c, "Perfume Verde QA", 10, existencia_minima=5)                         # por encima del mínimo
    plato = _prod(c, "Combo receta QA", 0, existencia_minima=5)                   # con receta: se reponen sus ingredientes
    serv = _prod(c, "Asesoría de aroma QA", None, existencia_minima=3, es_servicio=True, tipo="Servicio", cabys="8311000000000")
    assert serv["existencia_minima"] is None                                      # un servicio no lleva existencias
    inactivo = _prod(c, "Perfume viejo QA", 0, existencia_minima=1)
    assert c.put(f"/api/productos/{inactivo['id']}", json={"activo": False}).status_code == 200
    _poner(e.id, "recetas", [{"producto_id": plato["id"], "ingredientes": [{"producto_id": a["id"], "cantidad": 1}], "rendimiento": 1}])
    prov = c.post("/api/clientes", json={"nombre": "Distribuidora Aromas QA", "tipo": "Proveedor", "tipo_id": "02", "numero_id": "3101999888", "correo": "ventas.aromas@example.test"}).json()
    _poner(e.id, "proveedor_items", {"3101999888|c:pr-1": {"producto_id": a["id"], "emisor_id": "3101999888", "emisor": "DISTRIBUIDORA AROMAS", "actualizado": "2026-11-01T10:00:00"},
                                     "3101777666|c:x": {"producto_id": a["id"], "emisor_id": "3101777666", "emisor": "Proveedor viejo", "actualizado": "2026-01-01T10:00:00"}})
    r = c.get("/api/inventario/reponer").json()
    assert r["con_minimo"] == 3 and [x["producto_id"] for x in r["items"]] == [a["id"], b["id"]]
    ia, ib = r["items"]
    assert ia["existencia"] == 3 and ia["minimo"] == 5 and ia["maximo"] == 12 and ia["sugerido"] == 9 and ia["costo"] == 4000
    assert ia["proveedor"] == {"nombre": "Distribuidora Aromas QA", "identificacion": "3101999888", "contacto_id": prov["id"]}   # el más reciente
    assert ib["sugerido"] == 2 and ib["proveedor"] is None                       # sin máximo: hasta el doble del mínimo
    assert [x["producto_id"] for x in c.get(f"/api/inventario/reponer?ids={b['id']}").json()["items"]] == [b["id"]]
    alertas = c.get("/api/inicio/alertas").json()["alertas"]
    assert any(x["texto"].startswith("2 ítems por reponer") and x["enlace"] == "#/inventario/reponer" for x in alertas)
    # quitar el mínimo deja el ítem como antes
    assert c.put(f"/api/productos/{b['id']}", json={"existencia_minima": None}).json()["existencia_minima"] is None
    assert [x["producto_id"] for x in c.get("/api/inventario/reponer").json()["items"]] == [a["id"]]
    # validaciones y permisos
    assert c.post("/api/productos", json={"nombre": "Malo QA", "cabys": CABYS, "precio": 1, "existencia_minima": -1}).status_code == 400
    r = c.post("/api/productos", json={"nombre": "Malo dos QA", "cabys": CABYS, "precio": 1, "existencia_minima": 10, "existencia_maxima": 5})
    assert r.status_code == 400 and "máxima" in r.json()["detail"]
    ctx("Cajero")
    assert c.get("/api/inventario/reponer").status_code == 403
    ctx("Contador")
    assert c.get("/api/inventario/reponer").status_code == 200


def _xlsx(filas, cab):
    wb = Workbook(); ws = wb.active; ws.title = "Ítems"; ws.append(list(cab))
    for f in filas:
        ws.append(f)
    buf = io.BytesIO(); wb.save(buf)
    return buf.getvalue()


def test_importar_items_con_minimo(tienda):
    from app import importacion_items
    c, e, _ctx = tienda
    r = c.get("/api/productos/plantilla.xlsx")
    hoja = load_workbook(io.BytesIO(r.content))["Ítems"]
    assert [x.value for x in hoja[1]][-2:] == ["minimo", "maximo"] and hoja["N2"].value == 5
    cab = importacion_items.COLUMNAS
    fila = ["Colonia importada QA", "COL-1", CABYS, 9000, "Unid", "Producto", "08", "CRC", "Perfumes", 3000, "", 2, "no", 4, 10]
    sube = lambda datos, modo: c.post("/api/productos/importar", files={"archivo": ("items.xlsx", datos, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}, data={"modo": modo, "simular": "0"})
    assert sube(_xlsx([fila], cab), "crear").json()["creados"] == 1
    p = next(x for x in c.get("/api/productos").json() if x["codigo"] == "COL-1")
    assert p["existencia_minima"] == 4 and p["existencia_maxima"] == 10
    assert sube(_xlsx([fila[:13] + [6, ""]], cab), "actualizar").json()["actualizados"] == 1
    p = next(x for x in c.get("/api/productos").json() if x["codigo"] == "COL-1")
    assert p["existencia_minima"] == 6 and p["existencia_maxima"] == 10             # celda vacía: no cambia
    r = sube(_xlsx([fila[:13] + ["mucho", ""]], cab), "actualizar").json()
    assert r["actualizados"] == 0 and "no son números" in r["errores"][0]
    # sin las columnas nuevas (archivos de antes) todo sigue igual
    assert sube(_xlsx([["Colonia vieja QA", "COL-2", CABYS, 9000]], cab[:4]), "crear").json()["creados"] == 1
    assert next(x for x in c.get("/api/productos").json() if x["codigo"] == "COL-2")["existencia_minima"] is None


# ------------------------------------------------------------------------------------------------ interfaz (texto)
def _js(*partes):
    return (RAIZ / "static" / "js" / pathlib.Path(*partes)).read_text(encoding="utf-8")


def test_interfaz_de_las_tres_funciones():
    assert "{ label: 'Por reponer', to: '/inventario/reponer', permisos: ['inventario', 'gastos', 'catalogos'] }" in _js("menu.js")   # = la ruta del servidor
    assert "'/inventario/reponer': 'inventario/reponer'" in _js("app.js")
    rep = _js("pages", "inventario", "reponer.js")
    assert "/api/inventario/reponer" in rep and "'/gastos/ordenes/nueva?'" in rep and "sesion.puede('gastos')" in rep
    item = _js("pages", "inventario", "item-form.js")
    assert 'v-model="f.existencia_minima"' in item and "body.existencia_minima = inventariable ? cantMin(f.existencia_minima) : null" in item
    orden = _js("pages", "gastos", "orden-form.js")
    assert "if (this.params && this.params.reponer) await this.desdeReponer();" in orden and "'/api/inventario/reponer?'" in orden
    cierres = _js("pages", "pos", "cierres.js")
    assert "'/api/pos/cierres/correo'" in cierres and "if (cerrada) this.enviarCorreo(cerrada, true);" in cierres
    assert "marcar({ correo_z_pendiente: true })" in cierres and "'red.enLinea'(v)" in cierres and "titulo: 'Anulaciones ('" in cierres
    assert "correo_cierre: ''," in _js("pages", "pos", "_datos.js")
    assert 'v-model.trim="t.correo_cierre"' in _js("pages", "pos", "configuracion.js")
    assert "Sale por el correo saliente de la empresa" in _js("pages", "pos", "configuracion.js")                   # el cierre no va por la plataforma
    gestion = _js("pages", "inventario", "gestion.js")                                                              # CSV en el navegador: también mínimo y máximo
    assert "col(c, 'minimo', -1)" in gestion and "existencia_minima: esServ ? null : minimo, existencia_maxima: esServ ? null : maximo" in gestion
    sec = _js("pages", "configuracion", "seccion.js")
    assert "'/api/empresa/aviso-rechazo'" in sec and "Avisarme por correo si Hacienda rechaza un comprobante" in sec
    cola = (RAIZ / "cola.py").read_text(encoding="utf-8")
    assert "_avisos.pasada()" in cola


# ------------------------------------------------------------------------------------------------ 3.87: arreglos de la revisión
class _HiloEnElActo:
    """Reemplaza threading.Thread solo dentro de avisos_dueno: la tarea corre en el acto (la prueba no espera hilos)."""
    def __init__(self, target=None, daemon=None, **_k):
        self.target = target

    def start(self):
        self.target()


def test_rafaga_de_comprobantes_viejos_tambien_se_junta(correos, monkeypatch):
    """La espera entre avisos se mide con la marca del último aviso, no con la fecha de emisión: una cola detenida que se reanuda
    con comprobantes de hace más de 30 días no manda un correo por cada uno."""
    e = _nueva_empresa("Comercio Cola Atrasada QA", correo="dueno.atrasada@example.test")
    try:
        docs = [_doc(e.id, horas=24 * 40) for _ in range(5)]
        for d in docs:
            _consultar(e, d, estado="error", detalle="Hacienda no registra el comprobante después de 24 horas", monkeypatch=monkeypatch)
        assert len(correos) == 1                                                        # antes: 5 correos seguidos
        assert all((_aviso_de(e.id, d.id) or "").startswith("pendiente:error:") for d in docs[1:])
        avisos_dueno.pasada(ahora_cr() + timedelta(minutes=11))
        assert len(correos) == 2 and "Hacienda rechazó 4 comprobantes" in correos[1].html
        assert all(d.consecutivo in correos[1].html for d in docs[1:])
    finally:
        _limpiar([e.id])


def test_correo_de_la_plataforma_sin_copia_oculta(correos, monkeypatch):
    """El correo de la plataforma (la empresa de contacto del sitio) no lleva su copia oculta a los avisos de cada cliente."""
    monkeypatch.setattr(sitio, "_smtp", lambda s, cfg: correo.ConfigSMTP("smtp.plataforma.example.test", 465, None, None, "avisos@example.test",
                                                                          copia="archivo.plataforma@example.test"))
    e = _nueva_empresa("Comercio Copia Oculta QA", correo="dueno.copia@example.test")
    try:
        _consultar(e, _doc(e.id), monkeypatch=monkeypatch)
        assert len(correos) == 1 and correos[0].cfg.host == "smtp.plataforma.example.test" and correos[0].cfg.copia is None
    finally:
        _limpiar([e.id])


def test_cierre_z_nunca_sale_por_el_correo_de_la_plataforma(correos, monkeypatch):
    """Sin correo saliente propio el cierre no se envía, aunque haya correo de la plataforma: el destinatario lo elige la empresa y
    el texto lo manda el navegador (sería un relevo de correo con el nombre de la plataforma)."""
    from app.main import app
    e = _nueva_empresa("Prueba Gratis Cierre QA", ambiente="sandbox", tipo_negocio="comercio")      # sin smtp_host
    _poner(e.id, "pos_cajas", [{"id": 1, "caja": "Caja 1", "terminal_id": 1, "usuario": "x", "fecha": "2026-11-05", "estado": "Cerrada", "diferencia": 0}])
    _poner(e.id, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja 1", "correo_cierre": "tercero.uno@example.test, tercero.dos@example.test"}]})
    app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo="admin.gratis@example.test", es_superadmin=False, nombre="QA"), e, "Administrador")
    try:
        cuerpo = {**CIERRE, "caja_id": 1, "titulo": "Su cuenta será suspendida", "kpis": [{"t": "Verifique aquí", "v": "https://phish.example.test/login"}]}
        r = TestClient(app).post("/api/pos/cierres/correo", json=cuerpo)
        assert r.status_code == 400 and "correo saliente de la empresa" in r.json()["detail"]
        assert correos == []                                                            # nada salió por la plataforma
    finally:
        app.dependency_overrides.clear()
        _limpiar([e.id])


def test_instalacion_local_no_avisa_y_la_nube_avisa_lo_que_sube(correos, monkeypatch):
    """La instalación local no avisa (ni rechazos ni atascados): lo hace la nube, que también recibe los comprobantes que la
    instalación consultó y subió ya rechazados. Así el dueño recibe un solo correo por comprobante."""
    from app.main import app
    e = _nueva_empresa("Restaurante Instalacion Local QA", correo="dueno.local@example.test")
    try:
        # 1) en la instalación local: el rechazo y los atascados no mandan nada ni dejan marca
        monkeypatch.setattr(avisos_dueno, "MODO_LOCAL", True)
        d = _doc(e.id)
        assert _consultar(e, d, monkeypatch=monkeypatch).estado == "rechazado"
        atascado = _doc(e.id, estado="enviado", horas=30)
        avisos_dueno.pasada(ahora_cr() + timedelta(minutes=30))
        assert correos == [] and _aviso_de(e.id, d.id) is None and _aviso_de(e.id, atascado.id) is None
        monkeypatch.setattr(avisos_dueno, "MODO_LOCAL", False)
        with Session(engine_empresa(e.id)) as s:                                        # (en la nube ese ya se resolvió)
            x = s.get(Documento, atascado.id); x.estado = "aceptado"; s.add(x); s.commit()
        avisos_dueno._revisado.clear()
        # 2) en la nube: lo que sube la instalación
        monkeypatch.setattr(avisos_dueno, "threading", types.SimpleNamespace(Thread=_HiloEnElActo))
        app.dependency_overrides[auth.contexto] = lambda: auth.Contexto(types.SimpleNamespace(id=None, correo="admin.local@example.test", es_superadmin=False, nombre="QA"), e, "Administrador")
        c = TestClient(app)
        ahora = ahora_cr().isoformat(timespec="seconds")

        def sube(clave, consecutivo, estado, mensaje=None):
            doc = {"tipo_documento": "04", "clave": clave, "consecutivo": consecutivo, "fecha_emision": ahora, "receptor_nombre": "Cliente Local QA",
                   "moneda": "CRC", "tipo_cambio": 1, "total": 5650, "impuesto": 650, "estado": estado, "ambiente": "produccion", "mensaje_hacienda": mensaje,
                   "condicion_venta": "01", "otros_cargos": [], "lineas": []}
            r = c.post("/api/sinc/documentos", json={"terminal": "Caja 1", "documentos": [doc]})
            assert r.status_code == 200 and r.json()["recibidos"] == [clave], r.text
            with Session(engine_empresa(e.id)) as s:
                return s.exec(select(Documento).where(Documento.clave == clave)).first().id
        nueva = lambda: str(uuid.uuid4().int)[:50].ljust(50, "0")            # noqa: E731
        ka, kb, kc = nueva(), nueva(), nueva()
        sube(ka, "00100002040000000101", "enviado")
        assert correos == []                                                            # todavía sin respuesta: nada
        ida = sube(ka, "00100002040000000101", "rechazado", "El teléfono del emisor no cumple con el formato requerido")
        assert len(correos) == 1 and "00100002040000000101" in correos[0].asunto and "8 dígitos" in correos[0].html
        assert (_aviso_de(e.id, ida) or "").startswith("rechazado:")
        sube(ka, "00100002040000000101", "rechazado", "El teléfono del emisor no cumple con el formato requerido")
        assert len(correos) == 1                                                        # la misma subida otra vez: no se repite
        idb = sube(kb, "00100002040000000102", "error", "El código de actividad no existe")   # nuevo y ya con error: espera la ráfaga
        idc = sube(kc, "00100002040000000103", "rechazado", "Anulado por el usuario (nota de crédito)")
        assert len(correos) == 1 and (_aviso_de(e.id, idb) or "").startswith("pendiente:error:") and _aviso_de(e.id, idc) is None
        avisos_dueno.pasada(ahora_cr() + timedelta(minutes=11))
        assert len(correos) == 2 and "00100002040000000102" in correos[1].asunto and "00100002040000000103" not in correos[1].html
    finally:
        app.dependency_overrides.clear()
        _limpiar([e.id])


def test_inicio_solo_cuenta_los_por_reponer(tienda, monkeypatch):
    """El Inicio cuenta los ítems por reponer sin buscar el proveedor habitual ni recorrer los contactos (eso es de la pantalla)."""
    from app import compras_inventario
    c, e, _ctx = tienda
    _prod(c, "Perfume Conteo QA", 1, existencia_minima=4)

    def no_en_el_inicio(*a, **k):
        raise AssertionError("el Inicio no necesita el proveedor habitual")
    monkeypatch.setattr(compras_inventario, "relaciones", no_en_el_inicio)
    alertas = c.get("/api/inicio/alertas").json()["alertas"]
    assert any(x["texto"].startswith("1 ítem por reponer") for x in alertas)
    monkeypatch.undo()                                                                  # la pantalla Por reponer sí trae el detalle
    assert len(c.get("/api/inventario/reponer").json()["items"]) == 1
