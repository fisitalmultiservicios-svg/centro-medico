# -*- coding: utf-8 -*-
"""3.97: pago único del plan con tarjeta (sin pago automático): la orden queda pendiente, se confirma consultando a Tilopay
(nunca por la dirección de retorno), se registra una sola vez y extiende el plan un periodo."""
import types

import pytest
from sqlmodel import Session, select

from app import pagos_online, suscripcion
from app.auth import PagoPlan
from app.db import Empresa, engine, init_db


@pytest.fixture()
def empresa(tmp_path, monkeypatch):
    init_db()
    monkeypatch.setattr(suscripcion, "PENDIENTES", tmp_path / "pagos_unicos.json")
    monkeypatch.setattr(suscripcion, "credenciales", lambda: {"key": "k", "user": "u", "password": "p"})
    with Session(engine) as s:
        e = Empresa(nombre="Perfumeria Pago Unico QA", numero_id="3101397397", actividad="471101", otras_senas="QA 397", correo="pago397@example.test",
                    ambiente="sandbox", tipo_negocio="comercio", plan="pos_basico", precio_acordado=10619.47)
        s.add(e); s.commit(); s.refresh(e)
        eid = e.id
    yield eid
    with Session(engine) as s:
        for p in s.exec(select(PagoPlan).where(PagoPlan.empresa_id == eid)).all():
            s.delete(p)
        s.delete(s.get(Empresa, eid)); s.commit()


def test_pago_unico_se_confirma_con_tilopay_y_una_sola_vez(empresa, monkeypatch):
    pedidos = {}
    monkeypatch.setattr(pagos_online, "iniciar_pago", lambda cred, p, monto, redirect, correo: pedidos.setdefault("url", f"https://tilopay.example.test/{p.pago_orden}?m={monto}"))
    estado = {"aprobado": False}
    monkeypatch.setattr(pagos_online, "consultar", lambda cred, orden: {"aprobado": estado["aprobado"], "monto": 12000.0, "detalle": "" if estado["aprobado"] else None})
    ctx = types.SimpleNamespace(empresa=types.SimpleNamespace(id=empresa), puede=lambda p: True)
    req = types.SimpleNamespace(base_url="https://fisitaap.example.test/", headers={}, url=types.SimpleNamespace(scheme="https"))
    with Session(engine) as s:
        r = suscripcion.post_pago_unico({"correo": "dueno@example.test"}, req, ctx, s)
    orden = r["orden"]; assert r["monto"] == 12000.0 and orden.startswith(f"PL{empresa}-")
    with Session(engine) as s:
        e = s.get(Empresa, empresa)
        assert suscripcion.confirmar_unico(s, e, orden) == "pendiente"          # Tilopay todavía no lo aprueba: nada se registra
        assert not s.exec(select(PagoPlan).where(PagoPlan.empresa_id == empresa)).all()
        estado["aprobado"] = True
        resp = suscripcion.get_pago_unico_retorno(orden, s)
        assert "pago_unico=pagado" in resp.headers["location"]
        pagos = s.exec(select(PagoPlan).where(PagoPlan.empresa_id == empresa)).all()
        assert len(pagos) == 1 and pagos[0].referencia == orden and pagos[0].monto == 12000.0
        assert suscripcion.confirmar_unico(s, s.get(Empresa, empresa), orden) == "pagado"   # repetir no duplica
        assert len(s.exec(select(PagoPlan).where(PagoPlan.empresa_id == empresa)).all()) == 1
        assert s.get(Empresa, empresa).vence                                    # el plan queda con vencimiento
    # una orden inventada o de otra empresa no registra nada
    with Session(engine) as s:
        assert "pago_unico=rechazado" in suscripcion.get_pago_unico_retorno(f"PL{empresa}-0000-inventada", s).headers["location"]
