"""4.32, bloque B1 (lado web): el mecanismo único de app/sinc_datos.py con registros (contrato_432 §1 a §5, plan §2 y §9.2).

- Dato/declarar con las tres formas de escribir (todos, dueno, web) y sus reglas.
- El oyente: acumula por flush, decide en before_commit; reemplazar y fisitaap._reemplazar de 30 elementos sin cambios → 0 versiones y 0
  lápidas; versión creciente con dos sesiones; apagado sin la marca de sembrada; empresa vacía → conectar → crear → versión; lápida con foto;
  anotar_fila; un error nunca detiene el guardado; en el programa (réplica) entrega a sinc_datos_programa.anotar.
- La siembra por tramos y la marca.
- POST /api/sinc/datos (operaciones y goteo con cursor, siguiente_en, n_max) y POST /api/sinc/datos/accion; aplicar_op por elemento
  (aplicado, repetido, conflicto por grupo con la hora de la web, eliminado, renumerar, baja), copia de un dato «dueno» (no_dueno, nunca la
  tabla de trabajo), plan vencido, FE_SINC_DATOS=0 → 404.
- modulos.aplicar_elemento y modulos.aplicar_llave.
Las rutas se prueban con una aplicación propia que incluye solo sinc_datos.router (la inclusión en app/main.py es un cruce)."""
import json
import random
import secrets
from datetime import datetime, timedelta, timezone

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlmodel import Session

from app import auth, fisitaap, modulos, sinc, sinc_datos
from app import sinc_datos_decl  # noqa: F401  (declara «categoria»)
from app import sinc_diario
from app.db import engine, engine_empresa, init_db

init_db()
_app = FastAPI()
_app.include_router(sinc_datos.router)
c = TestClient(_app)
H = lambda t: {"Authorization": "Bearer " + t}   # noqa: E731
R = modulos.RANGO


@pytest.fixture(autouse=True)
def _encendido(monkeypatch):
    monkeypatch.setenv("FE_SINC_DATOS", "1")
    yield


@pytest.fixture
def declaraciones():
    """Declaraciones de prueba de las tres formas (se quitan al terminar: DATOS es de todo el proceso)."""
    def aceptar(s, eid, ctx, ref, datos, por):
        if ref == "ocupado":
            raise HTTPException(409, "Otro equipo ya lo tomó")
        modulos.aplicar_elemento(s, eid, "zz_webs", int(ref), {"estado": "aceptado", "por": por})
        s.commit()
        return {"ok": True, "ref": ref}
    nuevas = [sinc_datos.declarar(sinc_datos.Dato("zz_mod", registro="pos_modificadores", escribe="todos", viaja="dos")),
              sinc_datos.declarar(sinc_datos.Dato("zz_extra", registro="items_extra", forma="llave", escribe="todos", viaja="dos")),
              sinc_datos.declarar(sinc_datos.Dato("zz_caja", registro="zz_config", partir={"terminales": "id"}, escribe="todos", viaja="dos")),
              sinc_datos.declarar(sinc_datos.Dato("zz_cuenta", registro="zz_cuentas", escribe="dueno", dueno_de="rango", viaja="sube",
                                                  filtro=lambda x: bool(x.get("pedido_id")), etiqueta=lambda x: f"pedido:{x['pedido_id']}")),
              sinc_datos.declarar(sinc_datos.Dato("zz_web", registro="zz_webs", escribe="web", viaja="baja", acciones={"aceptar": aceptar}))]
    yield {d.tipo: d for d in nuevas}
    for d in nuevas:
        sinc_datos.DATOS.pop(d.tipo, None)
    sinc_datos._vigilados.clear()


def _empresa() -> int:
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "Mecanismo 432 QA", f"mec432-{random.randint(1, 10**9)}@example.test", "31010" + str(random.randint(10**4, 10**5 - 1)))
        return e.id


def _sembrada() -> int:
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        assert sinc_datos.sembrar(s, eid) is True
    return eid


def _lineas(eid: int, tipo: str = None) -> list:
    with Session(engine_empresa(eid)) as s:
        q = "SELECT id, tipo, ref, borrado, origen, huella, foto, datos, dueno, campos FROM sinc_dato WHERE tipo <> '_'" + (" AND tipo = :t" if tipo else "") + " ORDER BY id"
        return [dict(r._mapping) for r in s.execute(text(q), {"t": tipo}).all()]


def _maximo(eid: int) -> int:
    with Session(engine_empresa(eid)) as s:
        return int(s.execute(text("SELECT COALESCE(MAX(id), 0) FROM sinc_dato")).scalar())


def _cat(eid: int, *altas, bajas=()):
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "categorias", list(altas), list(bajas), [x["id"] for x in altas])


def _cambiar_cat(eid: int, x: dict):
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "categorias", [x], [], [])


def _instalacion(eid: int, terminal: int = 2) -> str:
    token = "fcr_" + secrets.token_urlsafe(32)
    with Session(engine) as sc:
        t = auth.TokenApi(empresa_id=eid, usuario_id=auth.TOKEN_EMPRESA, nombre="Instalación local · Caja QA", prefijo=token[:12],
                          hash=auth._hash_token_api(token), permisos=json.dumps([p for p in auth.PERMISOS_API if p != "ver_todo"]))
        sc.add(t); sc.commit(); sc.refresh(t)
        tid, pref = t.id, t.prefijo
    with Session(engine_empresa(eid)) as s:
        v = sinc._leer(s, eid, sinc.CLAVE_VINC, {})
        v.setdefault("instalaciones", []).append({"terminal": terminal, "nombre": "Caja QA", "token_id": tid, "prefijo": pref, "creado": "2026-11-13T00:00:00+00:00"})
        sinc._escribir(s, eid, sinc.CLAVE_VINC, v); s.commit()
    return token


def _cuerpo(autora: str = "2.qa1234", desde: int = 0, ops=(), hora_local: datetime = None, **extra) -> dict:
    return {"protocolo": 2, "version": "4.32", "autora": autora, "hora_local": (hora_local or datetime.now(timezone.utc)).isoformat(),
            "desde": desde, "epoca_web": None, "estacion_viva": False, "ops": list(ops), **extra}


def _cambio(n: int, ref: str, grupos: dict, base_v: int = 0, tipo: str = "categoria") -> dict:
    return {"n": n, "tipo": tipo, "ref": ref, "op": "cambio", "base_v": base_v, "datos": {"campos": grupos}, "por": "Caja 1 · Ana"}


# =================================================================================================================== declarar
def test_declarar_tres_formas_y_reglas():
    D = sinc_datos.Dato
    try:
        assert sinc_datos.declarar(D("zz_ok_todos", registro="zz_a")).forma_real == "elemento"
        assert sinc_datos.declarar(D("zz_ok_dueno", registro="zz_b", escribe="dueno", dueno_de="rango", viaja="sube")).escribe == "dueno"
        assert sinc_datos.declarar(D("zz_ok_web", registro="zz_c", escribe="web", viaja="baja", acciones={"x": print})).viaja == "baja"
        assert sinc_datos.declarar(D("zz_ok_parte", registro="zz_d", partir={"terminales": "id"})).forma_real == "parte"
        malas = [D("zz_ok_todos", registro="zz_e"),                                   # repetido
                 D("Mal", registro="zz_f"), D("_", registro="zz_f"),                    # nombre
                 D("zz_ma", registro="zz_f", modelo=auth.Usuario),                      # los dos
                 D("zz_mb"),                                                            # ninguno
                 D("zz_mc", registro="zz_f", escribe="dueno"),                          # sin dueno_de
                 D("zz_md", registro="zz_f", escribe="dueno", dueno_de="rango", viaja="baja"),
                 D("zz_me", registro="zz_f", escribe="web"),                            # web exige baja
                 D("zz_mf", registro="zz_f", acciones={"x": print}),                    # acciones solo con web
                 D("zz_mg", registro="zz_f", escribe="web", viaja="baja", copia_local=True),   # copia_local exige modelo
                 D("zz_mh", registro="zz_f", partir={"a": "id"}, forma="llave"),
                 D("zz_mi", registro="zz_f", escribe="dueno", dueno_de="rango", altas_bajas="web"),
                 D("zz_mj", modelo=auth.Usuario), D("zz_mk", registro="sinc_vinculacion"), D("zz_ml", registro="numeracion-01"),
                 D("zz_mm", registro="rrhh_planilla"), D("zz_mn", registro="pos_espera"), D("zz_mo", registro="equipo_impresion"),
                 D("zz_mp", registro="impuestos"), D("zz_mq", registro="empresa_extra")]
        for m in malas:
            with pytest.raises(ValueError):
                sinc_datos.declarar(m)
        assert sinc_datos.declarar(D("zz_mr", registro="pos_espera", escribe="dueno", dueno_de="rango", viaja="sube"))   # pos_espera solo con dueno
        assert sinc_datos.dato("categoria").registro == "categorias"
    finally:
        for t in [t for t in sinc_datos.DATOS if t.startswith("zz_ok_") or (t.startswith("zz_m") and len(t) == 5)]:
            sinc_datos.DATOS.pop(t, None)
        sinc_datos._vigilados.clear()


def test_huella_igual_para_float_entero_y_sin_extra():
    d = sinc_datos.dato("categoria")
    assert sinc_datos.huella(d, {"id": 1, "precio": 1500.0, "x": [2.0, {"y": 3.0}]}) == sinc_datos.huella(d, {"x": [2, {"y": 3}], "precio": 1500, "id": 1})
    assert sinc_datos.huella(d, {"a": 1.5}) != sinc_datos.huella(d, {"a": 1})
    e = sinc_datos.Dato("zz_h", registro="zz_h", extra={"_caja": print})
    assert sinc_datos.huella(e, {"a": 1, "_caja": 9}) == sinc_datos.huella(e, {"a": 1})


# =================================================================================================================== oyente
def test_oyente_apagado_sin_la_marca():
    eid = _empresa()
    _cat(eid, {"id": 1, "nombre": "Bebidas"})
    _cambiar_cat(eid, {"id": 1, "nombre": "Bebidas frías"})
    _cat(eid, bajas=[1])
    assert _lineas(eid) == []
    assert sinc_datos.oyente_modo(eid) == "apagado"


def test_empresa_vacia_conectar_crear_recibe_version():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        assert sinc_datos.sembrar(s, eid) is True                     # nada que sembrar: igual queda la marca
        assert s.execute(text("SELECT COUNT(*) FROM sinc_dato WHERE tipo = '_' AND ref = '_'")).scalar() == 1
    assert sinc_datos.sembrada(eid) and sinc_datos.oyente_modo(eid) == "autoridad"
    _cat(eid, {"id": 3, "nombre": "Postres"})
    (l,) = _lineas(eid)
    assert (l["tipo"], l["ref"], l["borrado"], l["origen"]) == ("categoria", "3", 0, 0)
    assert l["huella"] == sinc_datos.huella(sinc_datos.dato("categoria"), {"id": 3, "nombre": "Postres"})
    assert "nombre" in json.loads(l["campos"])


def test_version_creciente_con_dos_sesiones_intercaladas():
    eid = _sembrada()
    _cat(eid, {"id": 1, "nombre": "A"}, {"id": 2, "nombre": "B"})
    with Session(engine_empresa(eid)) as s1, Session(engine_empresa(eid)) as s2:
        modulos.aplicar_cambios(s1, eid, "categorias", [{"id": 1, "nombre": "A1"}], [], [])
        v1 = _maximo(eid)
        modulos.aplicar_cambios(s2, eid, "categorias", [{"id": 2, "nombre": "B1"}], [], [])
        v2 = _maximo(eid)
        modulos.aplicar_cambios(s1, eid, "categorias", [{"id": 2, "nombre": "B2"}], [], [])
        v3 = _maximo(eid)
    assert v1 < v2 < v3
    por_ref = {l["ref"]: l["id"] for l in _lineas(eid)}
    assert por_ref == {"1": v1, "2": v3}                              # una sola línea por dato: la última gana y recibe número nuevo


def test_reemplazar_30_sin_cambios_no_da_versiones_ni_lapidas(declaraciones):
    eid = _sembrada()
    grupos = [{"id": i, "nombre": f"Extra {i}", "opciones": [{"id": 100 + i, "nombre": "x"}]} for i in range(1, 31)]
    with Session(engine_empresa(eid)) as s:
        fisitaap._guardar_grupos(s, eid, grupos)                      # fisitaap._reemplazar → modulos.reemplazar → _escribir_coleccion
    assert len(_lineas(eid, "zz_mod")) == 30
    antes = _maximo(eid)
    with Session(engine_empresa(eid)) as s:
        fisitaap._guardar_grupos(s, eid, grupos)                      # borra, hace flush y recrea las 30 sin cambios
    with Session(engine_empresa(eid)) as s:
        r = modulos._registro(s, eid, "pos_modificadores")
        modulos.reemplazar(s, eid, "pos_modificadores", grupos, version=r.version)
    assert _maximo(eid) == antes
    assert not [l for l in _lineas(eid, "zz_mod") if l["borrado"]]
    # uno solo cambia: una sola versión
    grupos[4] = {**grupos[4], "nombre": "Extra cinco"}
    with Session(engine_empresa(eid)) as s:
        fisitaap._guardar_grupos(s, eid, grupos)
    nuevas = [l for l in _lineas(eid, "zz_mod") if l["id"] > antes]
    assert [l["ref"] for l in nuevas] == ["5"] and not nuevas[0]["borrado"]


def test_items_extra_llave_sin_cambios_y_con_uno(declaraciones):
    eid = _sembrada()
    extra = {str(p): {"extras": [p], "nota": "n"} for p in range(1, 31)}
    with Session(engine_empresa(eid)) as s:
        fisitaap._reemplazar(s, eid, "items_extra", extra); s.commit()
    assert len(_lineas(eid, "zz_extra")) == 30
    antes = _maximo(eid)
    with Session(engine_empresa(eid)) as s:
        fisitaap._reemplazar(s, eid, "items_extra", dict(extra)); s.commit()
    assert _maximo(eid) == antes
    extra["7"] = {"extras": [7, 8], "nota": "n"}
    del extra["9"]
    with Session(engine_empresa(eid)) as s:
        fisitaap._reemplazar(s, eid, "items_extra", extra); s.commit()
    nuevas = {l["ref"]: l for l in _lineas(eid, "zz_extra") if l["id"] > antes}
    assert set(nuevas) == {"7", "9"} and nuevas["9"]["borrado"] == 1 and json.loads(nuevas["9"]["foto"]) == {"extras": [9], "nota": "n"}


def test_lapida_con_foto_y_origen():
    eid = _sembrada()
    _cat(eid, {"id": 4, "nombre": "Sopas", "icono": "s"})
    _cat(eid, bajas=[4])
    (l,) = _lineas(eid)
    assert l["borrado"] == 1 and json.loads(l["foto"]) == {"id": 4, "nombre": "Sopas", "icono": "s"}
    # lo que se aplica desde una terminal lleva su origen
    with Session(engine_empresa(eid)) as s, sinc_diario.aplicando(3):
        modulos.aplicar_elemento(s, eid, "categorias", 30000001, {"nombre": "De la caja 3"}); s.commit()
    assert [x["origen"] for x in _lineas(eid) if x["ref"] == "30000001"] == [3]


def test_cambios_sin_flush_antes_del_commit_tambien_se_ven():
    eid = _sembrada()
    _cat(eid, {"id": 1, "nombre": "A"})
    antes = _maximo(eid)
    with Session(engine_empresa(eid)) as s:
        f = s.exec(modulos.select(modulos.RegistroItem).where(modulos.RegistroItem.empresa_id == eid, modulos.RegistroItem.clave == "categorias")).first()
        f.datos = json.dumps({"id": 1, "nombre": "A editada"}); s.add(f)
        s.commit()                                                    # sin flush previo: before_commit lo vacía antes de decidir
    assert _maximo(eid) > antes


def test_anotar_fila_para_un_update_crudo():
    eid = _sembrada()
    _cat(eid, {"id": 2, "nombre": "B"})
    antes = _maximo(eid)
    with Session(engine_empresa(eid)) as s:
        s.execute(text("UPDATE registroitem SET datos = :d WHERE empresa_id = :e AND clave = 'categorias' AND item_id = 2"),
                  {"d": json.dumps({"id": 2, "nombre": "B cruda"}), "e": eid})
        sinc_datos.anotar_fila(s, "categoria", 2)
        sinc_datos.anotar_fila(s, "no_declarado", 2)                  # no hace nada y no lanza
        s.commit()
    (l,) = [x for x in _lineas(eid) if x["ref"] == "2"]
    assert l["id"] > antes and l["huella"] == sinc_datos.huella(sinc_datos.dato("categoria"), {"id": 2, "nombre": "B cruda"})
    # sin anotar_fila el UPDATE crudo no se ve (por eso existe)
    with Session(engine_empresa(eid)) as s:
        s.execute(text("UPDATE registroitem SET datos = :d WHERE empresa_id = :e AND clave = 'categorias' AND item_id = 2"),
                  {"d": json.dumps({"id": 2, "nombre": "otra"}), "e": eid}); s.commit()
    assert [x["id"] for x in _lineas(eid) if x["ref"] == "2"] == [l["id"]]


def test_rollback_vacia_lo_acumulado():
    eid = _sembrada()
    _cat(eid, {"id": 1, "nombre": "A"})
    antes = _maximo(eid)
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_elemento(s, eid, "categorias", 1, {"nombre": "nunca"}); s.flush()
        assert s.info.get("sinc_tocado")
        s.rollback()
        assert not s.info.get("sinc_tocado")
        s.commit()
    assert _maximo(eid) == antes


def test_un_error_del_oyente_no_detiene_el_guardado(monkeypatch):
    eid = _sembrada()
    previos = sinc_datos.fallos()

    def falla(*a, **k):
        raise RuntimeError("prueba")
    monkeypatch.setattr(sinc_datos, "_versionar", falla)
    _cat(eid, {"id": 9, "nombre": "Se guarda igual"})
    with Session(engine_empresa(eid)) as s:
        assert [x["nombre"] for x in modulos.leer(s, eid, "categorias", [])] == ["Se guarda igual"]
    assert sinc_datos.fallos() == previos + 1


def test_conftest_apagado_el_oyente_sigue_en_las_sembradas(monkeypatch):
    """Contrato §5: con FE_SINC_DATOS=0 las rutas dan 404, pero el oyente sigue anotando en las empresas sembradas (al volver a encender
    no falta nada). Una empresa sin la marca (todas las de la suite vieja) queda como la 4.31."""
    eid = _sembrada()
    monkeypatch.setenv("FE_SINC_DATOS", "0")
    _cat(eid, {"id": 1, "nombre": "Con el interruptor apagado"})
    assert [l["ref"] for l in _lineas(eid)] == ["1"]
    otra = _empresa()
    _cat(otra, {"id": 1, "nombre": "Sin marca"})
    assert _lineas(otra) == []


def test_replica_entrega_a_la_cola_del_programa(monkeypatch, declaraciones):
    eid = _empresa()
    llamadas = []
    from app import sinc_datos_programa
    monkeypatch.setattr(sinc_datos_programa, "anotar", lambda s, e, t, r, a, d, por=None: llamadas.append((e, t, r, a, d)) or True)
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, sinc_datos.CLAVE_ESTADO, {"protocolo": 2, "epoca": "abcd"}, version=0)
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    assert sinc_datos.oyente_modo(eid) == "replica"
    _cat(eid, {"id": 1, "nombre": "A"})
    assert llamadas == [(eid, "categoria", "1", None, {"id": 1, "nombre": "A"})]
    _cambiar_cat(eid, {"id": 1, "nombre": "B"})
    assert llamadas[-1][3:] == ({"id": 1, "nombre": "A"}, {"id": 1, "nombre": "B"})
    grupos = [{"id": i, "nombre": f"G{i}"} for i in range(1, 31)]
    with Session(engine_empresa(eid)) as s:
        fisitaap._guardar_grupos(s, eid, grupos)
    n = len(llamadas)
    with Session(engine_empresa(eid)) as s:
        fisitaap._guardar_grupos(s, eid, grupos)                      # 30 sin cambios: nada que subir
    assert len(llamadas) == n
    monkeypatch.setattr(sinc, "MODO_LOCAL", False)
    assert sinc_datos.oyente_modo(eid) == "apagado"                   # la web sin la marca


# =================================================================================================================== siembra
def test_siembra_por_tramos_y_revision_final():
    eid = _empresa()
    _cat(eid, *[{"id": i, "nombre": f"C{i}"} for i in range(1, 6)])
    with Session(engine_empresa(eid)) as s:
        assert sinc_datos.sembrar(s, eid, tramo=2) is False
    assert len(_lineas(eid)) == 2 and not sinc_datos.sembrada(eid)
    _cambiar_cat(eid, {"id": 1, "nombre": "C1 cambiada entre tramos"})            # el oyente todavía no actúa (sin marca)
    _cat(eid, bajas=[2])
    with Session(engine_empresa(eid)) as s:
        assert sinc_datos.sembrar(s, eid, tramo=2) is False
        assert sinc_datos.sembrar(s, eid, tramo=2) is True
    lineas = {l["ref"]: l for l in _lineas(eid)}
    d = sinc_datos.dato("categoria")
    assert set(lineas) == {"1", "2", "3", "4", "5"}
    assert lineas["1"]["huella"] == sinc_datos.huella(d, {"id": 1, "nombre": "C1 cambiada entre tramos"})
    assert lineas["2"]["borrado"] == 1
    assert sinc_datos.sembrada(eid)
    with Session(engine_empresa(eid)) as s:
        assert sinc_datos.sembrar(s, eid) is True                     # ya sembrada: no hace nada


# =================================================================================================================== rutas
def test_rutas_apagadas_dan_404(monkeypatch):
    eid = _empresa()
    tok = _instalacion(eid)
    monkeypatch.setenv("FE_SINC_DATOS", "0")
    assert c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo()).status_code == 404
    assert c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "x", "ref": "1", "accion": "y"}).status_code == 404
    assert _lineas(eid) == [] and not sinc_datos.sembrada(eid)


def test_ruta_solo_instalaciones_y_cuerpo_validado():
    eid = _empresa()
    tok = _instalacion(eid, terminal=2)
    assert c.post("/api/sinc/datos", json=_cuerpo()).status_code == 401
    otra = _empresa()
    with Session(engine) as sc:                                       # token de la empresa sin ficha de instalación
        t = auth.TokenApi(empresa_id=otra, usuario_id=auth.TOKEN_EMPRESA, nombre="x", prefijo="fcr_qa432xyz", hash=auth._hash_token_api("fcr_qa432xyzsinficha"),
                          permisos=json.dumps(["facturar"]))
        sc.add(t); sc.commit()
    assert c.post("/api/sinc/datos", headers=H("fcr_qa432xyzsinficha"), json=_cuerpo()).status_code == 403
    r = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(autora="3.qa1234"))
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "autora"
    secreto = "valor-que-no-debe-volver"
    for cuerpo, codigo in ((_cuerpo(protocolo=1), "protocolo"), ({"protocolo": 2, "x": secreto}, "cuerpo"),
                           (_cuerpo(desde=-1), "cuerpo"), (_cuerpo(ops=[{"n": 1, "tipo": "categoria", "ref": secreto, "op": "otra"}]), "cuerpo"),
                           (_cuerpo(ops=[{"n": i, "tipo": "categoria", "ref": "1", "op": "baja"} for i in range(1, 102)]), "grande"),
                           (_cuerpo(reservar={"otra": 1}), "cuerpo")):
        r = c.post("/api/sinc/datos", headers=H(tok), json=cuerpo)
        assert r.status_code == 400 and r.json()["detail"]["codigo"] == codigo, r.text
        assert secreto not in r.text
    r = c.post("/api/sinc/datos", headers={**H(tok), "Content-Type": "application/json"}, content=json.dumps({**_cuerpo(), "relleno": "x" * 1_000_001}))
    assert r.status_code == 400 and r.json()["detail"]["codigo"] == "grande"


def test_primera_llamada_siembra_y_gotea_con_cursor(monkeypatch):
    monkeypatch.setenv("FE_DATOS_SEGUNDOS", "5")
    eid = _empresa()
    _cat(eid, {"id": 1, "nombre": "Bebidas"}, {"id": 2, "nombre": "Comidas"})
    tok = _instalacion(eid, terminal=2)
    r = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo())
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["protocolo"] == 2 and j["sembrando"] is False and j["mas"] is False and j["n_max"] == 0 and j["resultados"] == []
    assert j["pedidos_programa"] is False and j["siguiente_en"] in (5, 15) and len(j["epoca"]) >= 4
    assert [(f["tipo"], f["ref"], f["borrado"], f["datos"]["nombre"]) for f in j["filas"]] == [("categoria", "1", False, "Bebidas"), ("categoria", "2", False, "Comidas")]
    assert j["cursor"] == j["filas"][-1]["v"]
    assert all(f["tipo"] != "_" for f in j["filas"])
    # nada nuevo: el goteo sigue desde el cursor y la época no cambia
    j2 = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(desde=j["cursor"])).json()
    assert j2["filas"] == [] and j2["cursor"] == j["cursor"] and j2["epoca"] == j["epoca"]
    _cambiar_cat(eid, {"id": 2, "nombre": "Platos"})
    j3 = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(desde=j["cursor"])).json()
    assert [(f["ref"], f["datos"]["nombre"]) for f in j3["filas"]] == [("2", "Platos")] and j3["cursor"] > j["cursor"]
    from app import sinc_datos as sd
    assert sd.ULTIMA_LLAMADA[(eid, 2)][1] is False


def test_operaciones_aplicado_repetido_baja_y_renumerar():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    alta = {"n": 1, "tipo": "categoria", "ref": str(2 * R + 1), "op": "alta", "base_v": 0, "datos": {"fila": {"id": 2 * R + 1, "nombre": "De la caja"}}, "por": "Caja 1 · Ana"}
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[alta])).json()
    (res,) = j["resultados"]
    assert res["estado"] == "aplicado" and res["v"] and res["canonico"] == {"id": 2 * R + 1, "nombre": "De la caja"}
    assert j["n_max"] == 1
    with Session(engine_empresa(eid)) as s:
        assert {"id": 2 * R + 1, "nombre": "De la caja"} in modulos.leer(s, eid, "categorias", [])
    (l,) = [x for x in _lineas(eid) if x["ref"] == str(2 * R + 1)]
    assert l["origen"] == 2
    # el mismo (autora, n) otra vez: repetido, sin aplicar nada de nuevo
    antes = _maximo(eid)
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[alta])).json()
    assert j["resultados"][0]["estado"] == "repetido" and j["resultados"][0]["v"] == res["v"] and _maximo(eid) == antes
    # alta con un id que ya existe con otro contenido (o fuera de su rango): renumerar a un id nuevo de su rango
    _cat(eid, {"id": 7, "nombre": "De la web"})
    otra = {**alta, "n": 2, "ref": "7", "datos": {"fila": {"id": 7, "nombre": "Choca"}}}
    tercera = {**alta, "n": 3, "ref": str(2 * R + 1), "datos": {"fila": {"id": 2 * R + 1, "nombre": "Otra con el mismo id"}}}
    r2, r3 = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[otra, tercera])).json()["resultados"]
    assert r2["estado"] == "renumerar" and modulos.en_rango(int(r2["ref"]), 2) and r2["canonico"]["nombre"] == "Choca"
    assert r3["estado"] == "renumerar" and int(r3["ref"]) > int(r2["ref"])
    with Session(engine_empresa(eid)) as s:
        nombres = {x["id"]: x["nombre"] for x in modulos.leer(s, eid, "categorias", [])}
    assert nombres[7] == "De la web" and nombres[int(r2["ref"])] == "Choca" and nombres[2 * R + 1] == "De la caja"
    # baja: lápida con el origen de la terminal; el goteo la baja
    baja = {"n": 4, "tipo": "categoria", "ref": "7", "op": "baja", "base_v": 0, "datos": {}}
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[baja])).json()
    assert j["resultados"][0]["estado"] == "aplicado" and j["resultados"][0]["canonico"] is None
    f7 = [f for f in j["filas"] if f["ref"] == "7"][-1]
    assert f7["borrado"] is True and f7["datos"] is None and f7["origen"] == 2
    # cambiar lo que ya no existe: gana el borrado, queda anotado
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[_cambio(5, "7", {"nombre": [["De la web"], ["Revive"], datetime.now(timezone.utc).isoformat()]})])).json()
    assert j["resultados"][0]["estado"] == "rechazado" and j["resultados"][0]["motivo"] == "eliminado"
    with Session(engine_empresa(eid)) as s:
        assert s.execute(text("SELECT motivo FROM sinc_pisado WHERE ref = '7'")).scalars().all() == ["eliminado"]
        assert 7 not in {x["id"] for x in modulos.leer(s, eid, "categorias", [])}
    assert j["n_max"] == 5


def test_conflicto_por_grupo_gana_la_ultima_hora_de_la_web():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    _cat(eid, {"id": 5, "nombre": "Bebidas", "icono": "vaso"})
    ahora = datetime.now(timezone.utc)
    # «antes» igual a lo de la web: se aplica sin conflicto
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[_cambio(1, "5", {"icono": [["vaso"], ["copa"], ahora.isoformat()]})])).json()
    assert j["resultados"][0]["estado"] == "aplicado" and j["resultados"][0]["canonico"]["icono"] == "copa"
    # la web cambió el nombre DESPUÉS de que la caja (sin internet) lo cambiara: gana la web, lo de la caja queda anotado
    _cambiar_cat(eid, {"id": 5, "nombre": "Refrescos", "icono": "copa"})
    viejo = (ahora - timedelta(minutes=5)).isoformat()
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[_cambio(2, "5", {"nombre": [["Bebidas"], ["Bebidas frías"], viejo]})], hora_local=ahora)).json()
    res = j["resultados"][0]
    assert res["estado"] == "rechazado" and res["motivo"] == "conflicto" and res["canonico"]["nombre"] == "Refrescos"
    assert res["pisados"] == [{"campo": "nombre", "motivo": "conflicto", "perdio": ["Bebidas frías"]}]
    # cambio más nuevo que el de la web (reloj de la caja corregido por la llegada): gana la caja; lo de la web queda anotado
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[_cambio(3, "5", {"nombre": [["Bebidas"], ["Jugos"], datetime.now(timezone.utc).isoformat()]})])).json()
    assert j["resultados"][0]["estado"] == "aplicado" and j["resultados"][0]["canonico"]["nombre"] == "Jugos"
    # mitad y mitad: un grupo entra y otro pierde → fusionado
    _cambiar_cat(eid, {"id": 5, "nombre": "Jugos naturales", "icono": "copa"})
    mezcla = _cambio(4, "5", {"nombre": [["Jugos"], ["Jugos fríos"], viejo], "icono": [["copa"], ["jarra"], viejo]})
    res = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[mezcla], hora_local=ahora)).json()["resultados"][0]
    assert res["estado"] == "fusionado" and res["canonico"] == {"id": 5, "nombre": "Jugos naturales", "icono": "jarra"}
    with Session(engine_empresa(eid)) as s:
        filas = s.execute(text("SELECT campo, perdio, perdio_de, quedo_de FROM sinc_pisado WHERE ref = '5' AND motivo = 'conflicto' ORDER BY id")).all()
    assert [(f[0], json.loads(f[1])) for f in filas] == [("nombre", ["Bebidas frías"]), ("nombre", ["Refrescos"]), ("nombre", ["Jugos fríos"])]
    assert filas[0][2] == "Caja 1 · Ana" and filas[1][2] == "la página web"
    # «id» no es un grupo que un programa pueda cambiar
    res = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[_cambio(5, "5", {"id": [[5], [6], viejo]})])).json()["resultados"][0]
    assert res["canonico"]["id"] == 5


def test_dueno_copia_nunca_en_la_tabla_de_trabajo_y_no_dueno(declaraciones):
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    fila = {"id": 2 * R + 17, "pedido_id": 45, "lineas": [{"producto_id": 1, "cantidad": 2}], "estado": "listo"}
    copia = {"n": 1, "tipo": "zz_cuenta", "ref": str(2 * R + 17), "op": "copia", "base_v": 0, "datos": {"fila": fila}}
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[copia])).json()
    assert j["resultados"][0]["estado"] == "aplicado" and j["resultados"][0]["v"] and j["resultados"][0]["canonico"] is None
    (l,) = _lineas(eid, "zz_cuenta")
    assert json.loads(l["datos"]) == fila and l["dueno"] == 2 and l["origen"] == 2
    with Session(engine_empresa(eid)) as s:
        assert modulos.leer(s, eid, "zz_cuentas", None) is None                                    # nunca la tabla de trabajo
        assert s.execute(text("SELECT etiqueta FROM sinc_dato WHERE tipo = 'zz_cuenta'")).scalar() == "pedido:45"
    assert all(f["tipo"] != "zz_cuenta" for f in j["filas"])                                        # viaja «sube»: no baja
    # la misma copia otra vez: sin versión nueva
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[{**copia, "n": 2}])).json()
    assert j["resultados"][0]["estado"] == "aplicado" and j["resultados"][0]["v"] is None
    # una cuenta de otra terminal: no_dueno, anotado, nada escrito
    ajena = {**copia, "n": 3, "ref": str(3 * R + 17), "datos": {"fila": {**fila, "id": 3 * R + 17}}}
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[ajena])).json()
    assert j["resultados"][0]["estado"] == "rechazado" and j["resultados"][0]["motivo"] == "no_dueno"
    assert len(_lineas(eid, "zz_cuenta")) == 1
    with Session(engine_empresa(eid)) as s:
        assert s.execute(text("SELECT motivo FROM sinc_pisado WHERE tipo = 'zz_cuenta'")).scalars().all() == ["no_dueno"]
    # cobrada: la ausencia deja la lápida con la foto
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[{**copia, "n": 4, "datos": {"fila": None}}])).json()
    assert j["resultados"][0]["estado"] == "aplicado" and j["resultados"][0]["v"]
    (l,) = _lineas(eid, "zz_cuenta")
    assert l["borrado"] == 1 and json.loads(l["foto"]) == fila and l["datos"] is None
    # una op que no es «copia» sobre un dato «dueno»: no_valido
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[{**copia, "n": 5, "op": "alta"}])).json()
    assert j["resultados"][0]["motivo"] == "no_valido"


def test_web_baja_por_goteo_y_se_pide_por_accion(declaraciones):
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_elemento(s, eid, "zz_webs", 45, {"estado": "nuevo"}); s.commit()
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[{"n": 1, "tipo": "zz_web", "ref": "45", "op": "cambio", "datos": {"campos": {}}}])).json()
    assert j["resultados"][0]["estado"] == "rechazado" and j["resultados"][0]["motivo"] == "no_valido"           # el programa nunca escribe un dato «web»
    assert [(f["tipo"], f["ref"], f["datos"]["estado"]) for f in j["filas"]] == [("zz_web", "45", "nuevo")]
    r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "zz_web", "ref": "45", "accion": "aceptar", "datos": {}, "por": "Caja 1 · Ana"})
    assert r.status_code == 200, r.text
    assert r.json()["resultado"] == {"ok": True, "ref": "45"}
    assert [(f["tipo"], f["ref"], f["datos"]) for f in r.json()["filas"]] == [("zz_web", "45", {"estado": "aceptado", "por": "Caja 1 · Ana", "id": 45})]
    r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "zz_web", "ref": "ocupado", "accion": "aceptar", "datos": {}})
    assert r.status_code == 409 and r.json()["detail"] == "Otro equipo ya lo tomó"                                  # el texto de la ruta, tal cual
    for cuerpo in ({"tipo": "zz_web", "ref": "45", "accion": "inventada"}, {"tipo": "categoria", "ref": "1", "accion": "aceptar"},
                   {"tipo": "_carga", "ref": "_", "accion": "inventada"}):
        r = c.post("/api/sinc/datos/accion", headers=H(tok), json=cuerpo)
        assert r.status_code == 400 and r.json()["detail"] == "Esta acción no existe"
    r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "zz_web", "ref": "45", "accion": "aceptar", "datos": "x"})
    assert r.status_code == 400
    llamadas = []
    sinc_datos.accion_de_carga("zz_prueba", lambda s, e, ctx, ref, datos, por: llamadas.append((e, ref, por, ctx.por_programa)) or {"hecho": 1})
    try:
        r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "_carga", "ref": "_", "accion": "zz_prueba", "datos": {}, "por": "Caja\n1"})
        assert r.status_code == 200 and r.json() == {"resultado": {"hecho": 1}, "filas": []}
        assert llamadas == [(eid, "_", "Caja 1", "Caja 1")]
    finally:
        sinc_datos._ACCIONES_CARGA.pop("zz_prueba", None)


def _n_pisados(eid: int) -> int:
    with Session(engine_empresa(eid)) as s:
        return int(s.execute(text("SELECT COUNT(*) FROM sinc_pisado")).scalar())


def test_plan_vencido_reintentar_sin_anotar_y_tras_renovar_se_aplica(monkeypatch, declaraciones):
    """(I-2, n.º 17 y 4 de la revisión): con el plan vencido la op no se da por rechazada: «reintentar» para ella y todas las siguientes,
    sin sinc_cambio (n_max no avanza) ni sinc_pisado; renovado el plan, el reenvío de las mismas ops se aplica (no es «repetido»)."""
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    from app import planes
    monkeypatch.setattr(planes, "vencido", lambda e: True)
    ops = [{"n": 1, "tipo": "zz_cuenta", "ref": str(2 * R + 4), "op": "copia", "datos": {"fila": {"id": 2 * R + 4, "pedido_id": 2}}},
           {"n": 2, "tipo": "categoria", "ref": str(2 * R + 1), "op": "alta", "datos": {"fila": {"id": 2 * R + 1, "nombre": "x"}}},
           {"n": 3, "tipo": "zz_cuenta", "ref": str(2 * R + 2), "op": "copia", "datos": {"fila": {"id": 2 * R + 2, "pedido_id": 1}}}]
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=ops)).json()
    assert [(x["n"], x["estado"], x["motivo"]) for x in j["resultados"]] == [(1, "aplicado", None), (2, "reintentar", "plan_vencido"),
                                                                             (3, "reintentar", "plan_vencido")]
    assert j["n_max"] == 1 and _n_pisados(eid) == 0
    with Session(engine_empresa(eid)) as s:
        assert modulos.leer(s, eid, "categorias", None) in (None, [])
    r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "zz_web", "ref": "45", "accion": "aceptar", "datos": {}})
    assert r.status_code == 409 and "vencido" in r.json()["detail"]
    monkeypatch.setattr(planes, "vencido", lambda e: False)                    # renovado
    j2 = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=ops[1:])).json()
    assert [(x["n"], x["estado"]) for x in j2["resultados"]] == [(2, "aplicado"), (3, "aplicado")] and j2["n_max"] == 3
    with Session(engine_empresa(eid)) as s:
        assert [x["nombre"] for x in modulos.leer(s, eid, "categorias", [])] == ["x"]


def test_tipo_no_declarado_y_una_op_que_falla_es_pasajera(monkeypatch):
    """(I-2, n.º 19, 3 y 6 de la revisión): una excepción al aplicar no es un rechazo: «reintentar»/«error» para ella y las siguientes, sin
    anotarlas ni avanzar n_max; al reenviarlas sin el fallo se aplican. Un tipo no declarado sí es rechazo final."""
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    real = sinc_datos._op_todos
    falla = [True]

    def a_veces(s, eid_, d, ref, op, *a):
        if ref == str(2 * R + 5) and falla[0]:
            raise RuntimeError("prueba")
        return real(s, eid_, d, ref, op, *a)
    monkeypatch.setattr(sinc_datos, "_op_todos", a_veces)
    ops = [{"n": 1, "tipo": "inventado", "ref": "1", "op": "alta", "datos": {"fila": {}}},
           {"n": 2, "tipo": "categoria", "ref": str(2 * R + 5), "op": "alta", "datos": {"fila": {"id": 2 * R + 5, "nombre": "Bebidas"}}},
           {"n": 3, "tipo": "categoria", "ref": str(2 * R + 3), "op": "alta", "datos": {"fila": {"id": 2 * R + 3, "nombre": "Entra"}}}]
    j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=ops)).json()
    assert [(x["estado"], x["motivo"]) for x in j["resultados"]] == [("rechazado", "no_valido"), ("reintentar", "error"), ("reintentar", "error")]
    assert j["n_max"] == 1 and _n_pisados(eid) == 0
    with Session(engine_empresa(eid)) as s:
        assert modulos.leer(s, eid, "categorias", None) in (None, [])
    falla[0] = False
    j2 = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=ops[1:])).json()
    assert [x["estado"] for x in j2["resultados"]] == ["aplicado", "aplicado"] and j2["n_max"] == 3
    assert j2["resultados"][0]["canonico"]["nombre"] == "Bebidas"


# =================================================================================================================== modulos
def test_aplicar_elemento_con_su_id_sin_fusion_y_sin_confirmar(monkeypatch):
    eid = _empresa()

    class SinFusion:
        def __getattr__(self, k):
            raise AssertionError("aplicar_elemento no usa FUSIONES")
    monkeypatch.setitem(modulos.FUSIONES, "zz_cuentas_fus", SinFusion())
    with Session(engine_empresa(eid)) as s:
        assert modulos.aplicar_elemento(s, eid, "zz_cuentas_fus", 2 * R + 5, {"mesa": 1}) is True     # id de otro rango: se conserva
        assert modulos.aplicar_elemento(s, eid, "zz_cuentas_fus", 9, {"mesa": 2}) is True
        s.rollback()                                                                                   # no confirma
        assert modulos.leer(s, eid, "zz_cuentas_fus", None) is None
        assert modulos.aplicar_elemento(s, eid, "zz_cuentas_fus", 2 * R + 5, {"mesa": 1}) is True
        assert modulos.aplicar_elemento(s, eid, "zz_cuentas_fus", 9, {"mesa": 2}) is True
        s.commit()
        r = modulos._registro(s, eid, "zz_cuentas_fus")
        assert r.coleccion and r.ultimo_id == 9 and r.version == 2                                     # ultimo_id solo con el rango propio (0)
        assert modulos.aplicar_elemento(s, eid, "zz_cuentas_fus", 9, {"mesa": 2}) is False             # igual: nada
        assert modulos.aplicar_elemento(s, eid, "zz_cuentas_fus", 9, None) is True
        assert modulos.aplicar_elemento(s, eid, "zz_cuentas_fus", 9, None) is False
        assert modulos.aplicar_elemento(s, eid, "zz_nada", 1, None) is False
        s.commit()
        assert modulos.leer(s, eid, "zz_cuentas_fus", []) == [{"mesa": 1, "id": 2 * R + 5}]
        assert modulos._registro(s, eid, "zz_cuentas_fus").version == 3
        # un valor con lista de ids pasa a colección
        modulos.reemplazar(s, eid, "zz_lista", [], version=0)
        assert modulos.aplicar_elemento(s, eid, "zz_lista", 4, {"n": "cuatro"}) is True; s.commit()
        assert modulos._registro(s, eid, "zz_lista").coleccion and modulos.leer(s, eid, "zz_lista", []) == [{"n": "cuatro", "id": 4}]
        modulos.reemplazar(s, eid, "zz_obj", {"a": 1}, version=0)
        with pytest.raises(ValueError):
            modulos.aplicar_elemento(s, eid, "zz_obj", 1, {"x": 1})


def test_aplicar_llave_partes_y_resto():
    eid = _empresa()
    p = {"terminales": "id"}
    with Session(engine_empresa(eid)) as s:
        assert modulos.aplicar_llave(s, eid, "zz_extra", "152", None) is False                     # no existe y no hay valor
        assert modulos.aplicar_llave(s, eid, "zz_extra", "152", {"extras": [1]}) is True
        assert modulos.aplicar_llave(s, eid, "zz_extra", "153", {"extras": [2]}) is True
        assert modulos.aplicar_llave(s, eid, "zz_extra", "153", {"extras": [2]}) is False
        assert modulos.aplicar_llave(s, eid, "zz_extra", "152", None) is True
        s.commit()
        assert modulos.leer(s, eid, "zz_extra", None) == {"153": {"extras": [2]}}
        modulos.reemplazar(s, eid, "zz_cfg", {"terminales": [{"id": 1, "nombre": "Caja 1"}, {"id": 2, "nombre": "Caja 2"}], "moneda": "CRC"}, version=0)
        v0 = modulos._registro(s, eid, "zz_cfg").version
        assert modulos.aplicar_llave(s, eid, "zz_cfg", "terminales#2", {"id": 2, "nombre": "Barra"}, p) is True
        assert modulos.aplicar_llave(s, eid, "zz_cfg", "terminales#3", {"id": 3, "nombre": "Terraza"}, p) is True
        assert modulos.aplicar_llave(s, eid, "zz_cfg", "terminales#1", None, p) is True
        assert modulos.aplicar_llave(s, eid, "zz_cfg", "terminales#9", None, p) is False
        assert modulos.aplicar_llave(s, eid, "zz_cfg", "_", {"moneda": "USD", "terminales": ["no se toca"]}, p) is True
        s.commit()
        assert modulos.leer(s, eid, "zz_cfg", None) == {"moneda": "USD", "terminales": [{"id": 2, "nombre": "Barra"}, {"id": 3, "nombre": "Terraza"}]}
        assert modulos._registro(s, eid, "zz_cfg").version == v0 + 4
        with pytest.raises(ValueError):
            modulos.aplicar_llave(s, eid, "zz_cfg", "otras#1", {"id": 1})                         # sin partir
        modulos.aplicar_cambios(s, eid, "zz_col", [{"id": 1}], [], [1])
        with pytest.raises(ValueError):
            modulos.aplicar_llave(s, eid, "zz_col", "1", {"x": 1})


def test_parte_y_llave_en_el_oyente(declaraciones):
    eid = _sembrada()
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, "zz_config", {"terminales": [{"id": 1, "nombre": "Caja 1"}], "moneda": "CRC"}, version=0)
    assert {l["ref"] for l in _lineas(eid, "zz_caja")} == {"_", "terminales#1"}
    antes = _maximo(eid)
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_llave(s, eid, "zz_config", "terminales#2", {"id": 2, "nombre": "Barra"}, {"terminales": "id"}); s.commit()
    assert [l["ref"] for l in _lineas(eid, "zz_caja") if l["id"] > antes] == ["terminales#2"]      # solo la caja nueva


# =================================================================================================================== cruces C-1, C-7, C-8, C-9 y C-12
def test_c1_reenlazar_queda_registrada_al_importar_las_declaraciones():
    from app import sinc_completar
    assert sinc_datos._ACCIONES_CARGA.get("reenlazar") is sinc_completar.accion_reenlazar
    assert sinc_datos._accion("_carga", "reenlazar") is sinc_completar.accion_reenlazar


def test_c7_atiende_se_fija_solo_en_la_llamada_que_siembra(monkeypatch):
    from app import pedidos
    llamadas = []
    monkeypatch.setattr(pedidos, "fijar_atiende_al_sembrar", lambda s, e, t: llamadas.append((e, t)) or True)
    monkeypatch.setattr(pedidos, "reintentar_enlaces", lambda *a, **k: [])
    eid = _empresa()
    tok = _instalacion(eid, terminal=2)
    assert c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo()).status_code == 200
    assert llamadas == [(eid, 2)] and sinc_datos.sembrada(eid)
    assert c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo()).status_code == 200
    assert llamadas == [(eid, 2)]                                                                     # ya sembrada: no otra vez
    # ya sembrada antes de la primera llamada de la terminal: tampoco
    eid2 = _sembrada()
    tok2 = _instalacion(eid2, terminal=2)
    assert c.post("/api/sinc/datos", headers=H(tok2), json=_cuerpo()).status_code == 200
    assert llamadas == [(eid, 2)]


def test_c8_la_copia_y_la_lapida_de_una_cuenta_reintentan_el_enlace(monkeypatch, declaraciones):
    from app import pedidos
    previa = sinc_datos.DATOS.pop("cuenta", None)
    sinc_datos.declarar(sinc_datos.Dato("cuenta", registro="zz_cuentas2", escribe="dueno", dueno_de="rango", viaja="sube"))
    llamadas = []
    monkeypatch.setattr(pedidos, "reintentar_enlaces", lambda s, e, terminal=None, pedido_id=None: llamadas.append((e, terminal, pedido_id)) or [])
    try:
        eid = _sembrada()
        tok = _instalacion(eid, terminal=2)
        fila = {"id": 2 * R + 5, "pedido_id": 77, "estado": "abierta"}
        copia = {"n": 1, "tipo": "cuenta", "ref": str(2 * R + 5), "op": "copia", "base_v": 0, "datos": {"fila": fila}}
        assert c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[copia])).json()["resultados"][0]["estado"] == "aplicado"
        assert (eid, None, 77) in llamadas
        llamadas.clear()
        j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[{**copia, "n": 2, "datos": {"fila": None}}])).json()
        assert j["resultados"][0]["estado"] == "aplicado" and (eid, None, 77) in llamadas                # la lápida lee el pedido de la copia de antes
        llamadas.clear()
        sin = {**copia, "n": 3, "ref": str(2 * R + 6), "datos": {"fila": {"id": 2 * R + 6, "estado": "abierta"}}}
        ajena = {**copia, "n": 4, "ref": str(3 * R + 5), "datos": {"fila": {**fila, "id": 3 * R + 5}}}
        j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[sin, ajena])).json()
        assert [r["estado"] for r in j["resultados"]] == ["aplicado", "rechazado"]
        assert all(p is None for _e, _t, p in llamadas)                                                   # sin pedido o no_dueno: nada
        llamadas.clear()
        j = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[{**copia, "n": 5, "tipo": "zz_cuenta"}])).json()
        assert j["resultados"][0]["estado"] == "aplicado" and all(p is None for _e, _t, p in llamadas)  # solo el tipo «cuenta»
    finally:
        sinc_datos.DATOS.pop("cuenta", None)
        if previa is not None:
            sinc_datos.DATOS["cuenta"] = previa


def test_c9_la_accion_recibe_la_terminal_de_la_ficha():
    vistos = []
    sinc_datos.accion_de_carga("zz_terminal", lambda s, e, ctx, ref, datos, por: vistos.append(ctx.terminal_sinc) or {})
    try:
        eid = _sembrada()
        tok = _instalacion(eid, terminal=3)
        r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "_carga", "ref": "_", "accion": "zz_terminal", "datos": {}})
        assert r.status_code == 200 and vistos == [3]
    finally:
        sinc_datos._ACCIONES_CARGA.pop("zz_terminal", None)


def test_c12_bandera_datos_v2_solo_en_el_bloque_del_programa():
    import inspect
    fuente = inspect.getsource(auth._info_empresa)
    bloque = fuente[fuente.index("if aviso_local is not None:"):]
    assert 'd["datos_v2"] = _sdp.protocolo(e.id) == 2 and not _sdp.en_pausa(e.id)' in bloque
    assert 'd["datos_v2"] = False' in bloque
    assert fuente.index('d["datos_v2"]') > fuente.index("if aviso_local is not None:")


# =================================================================================================================== B2: la web completa
from types import SimpleNamespace  # noqa: E402

from app.db import Cliente, Producto  # noqa: E402

CABYS = "8311000000000"


def _prod(eid: int, nombre: str = "Café negro", **campos) -> int:
    with Session(engine_empresa(eid)) as s:
        p = Producto(empresa_id=eid, nombre=nombre, cabys=CABYS, precio=campos.pop("precio", 1500), **campos)
        s.add(p); s.commit(); s.refresh(p)
        return p.id


def _cli(eid: int, nombre: str = "Ana Mora", **campos) -> int:
    with Session(engine_empresa(eid)) as s:
        x = Cliente(empresa_id=eid, nombre=nombre, tipo_id="", numero_id="", **campos)
        s.add(x); s.commit(); s.refresh(x)
        return x.id


def _op(n: int, tipo: str, ref, op: str, datos: dict, base_v: int = 0) -> dict:
    return {"n": n, "tipo": tipo, "ref": str(ref), "op": op, "base_v": base_v, "datos": datos, "por": "Caja 2 · Luis"}


def _mandar(tok: str, *ops, **extra) -> dict:
    r = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=list(ops), **extra))
    assert r.status_code == 200, r.text
    return r.json()


def _pisados(eid: int, ref) -> list:
    with Session(engine_empresa(eid)) as s:
        return [tuple(f) for f in s.execute(text("SELECT campo, motivo FROM sinc_pisado WHERE ref = :r ORDER BY id"), {"r": str(ref)}).all()]


def test_b2_declaraciones_del_catalogo_y_del_punto_de_venta():
    D = sinc_datos.DATOS
    esperado = {"categoria": "categorias", "lista_precios": "listas_precios", "receta": "recetas", "item_extra": "items_extra", "caja": "pos_config",
                "impresora": "pos_impresoras", "promo_pos": "pos_promos", "promo": "fis_promociones", "modificador": "pos_modificadores"}
    for tipo, clave in esperado.items():
        assert D[tipo].registro == clave and D[tipo].escribe == "todos" and D[tipo].viaja == "dos", tipo
    assert D["producto"].modelo is Producto and D["cliente"].modelo is Cliente and D["producto"].alta == D["cliente"].alta == "rango"
    assert D["item_extra"].forma_real == "llave" and D["caja"].forma_real == "parte" and D["caja"].altas_bajas == "web"
    assert D["producto"].conjuntos == ("codigos_alternos",) and D["cliente"].conjuntos == ("direcciones",) and D["producto"].locales == ("imagen_nombre",)
    assert D["receta"].refs == {"producto_id": "producto", "ingredientes[].producto_id": "producto"}
    assert sinc_datos_decl.producto_con_historial is sinc_datos._fn(D["producto"].baja.split(":", 1)[1])


def test_b2_oyente_filas_nuevas_cambios_y_lapidas_de_producto_y_cliente():
    eid = _sembrada()
    pid = _prod(eid)                                                    # id automático: se anota después del flush
    cid = _cli(eid)
    (lp,), (lc,) = _lineas(eid, "producto"), _lineas(eid, "cliente")
    assert lp["ref"] == str(pid) and lc["ref"] == str(cid) and lp["origen"] == 0
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, pid); p.precio = 1600; s.add(p); s.commit()
    (lp2,) = _lineas(eid, "producto")
    assert lp2["id"] > lp["id"] and "precio" in json.loads(lp2["campos"]) and "nombre" in json.loads(lp2["campos"])
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, pid); p.precio = 1600; s.add(p); s.commit()     # sin cambio real: sin versión
    assert _lineas(eid, "producto")[0]["id"] == lp2["id"]
    with Session(engine_empresa(eid)) as s:
        s.delete(s.get(Producto, pid)); s.commit()
    (lp3,) = _lineas(eid, "producto")
    assert lp3["borrado"] and json.loads(lp3["foto"])["nombre"] == "Café negro"


def test_b2_oyente_pedido_y_update_crudo_de_pedidos():
    from app import pedidos, pedidos_programa  # noqa: F401  (declara «pedido»)
    eid = _sembrada()
    with Session(engine_empresa(eid)) as s:
        p = pedidos.Pedido(empresa_id=eid, numero=1, token="t" * 20, nombre="Ana", telefono="88888888", estado="nuevo")
        s.add(p); s.commit(); s.refresh(p)
        pid = p.id
    (l1,) = _lineas(eid, "pedido")
    with Session(engine_empresa(eid)) as s:
        assert pedidos._tomar_confirmacion(s, pid, "marca-qa") is True    # UPDATE crudo con anotar_fila
    (l2,) = _lineas(eid, "pedido")
    assert l2["id"] > l1["id"]


def test_b2_update_crudos_de_lo_declarado_llevan_anotar_fila():
    """grep: un UPDATE crudo nuevo sobre una tabla declarada (producto, cliente, pedido) sin anotar_fila en la misma función hace fallar
    esta prueba."""
    import ast
    import pathlib
    import re as _re
    tablas = {"producto": "Producto", "cliente": "Cliente", "pedido": "Pedido"}
    patron = _re.compile(r"UPDATE\s+(?:\{(" + "|".join(tablas.values()) + r")\.__tablename__\}|\"?(" + "|".join(tablas) + r")\"?\b)", _re.I)
    faltan, vistos = [], 0
    for archivo in sorted(pathlib.Path("app").glob("*.py")):
        fuente = archivo.read_text(encoding="utf-8")
        if "UPDATE" not in fuente:
            continue
        for nodo in ast.walk(ast.parse(fuente)):
            if isinstance(nodo, (ast.FunctionDef, ast.AsyncFunctionDef)):
                propio = ast.get_source_segment(fuente, nodo) or ""
                for hijo in ast.walk(nodo):                              # sin las funciones anidadas (se revisan solas)
                    if hijo is not nodo and isinstance(hijo, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        propio = propio.replace(ast.get_source_segment(fuente, hijo) or "\0", "")
                if patron.search(propio):
                    vistos += 1
                    if "anotar_fila(" not in propio:
                        faltan.append(f"{archivo.name}:{nodo.name}")
    assert vistos >= 4                                               # dirección del cliente, tomar, soltar y el rescate del pedido
    assert faltan == [], f"UPDATE crudo sin sinc_datos.anotar_fila: {faltan}"


def test_b2_direccion_del_cliente_anota_y_el_programa_usa_va_a_la_web():
    import inspect
    from app import main
    fuente = inspect.getsource(main.agregar_direccion_cliente)
    assert "_sinc.va_a_la_web(ctx.empresa.id, cid)" in fuente
    eid = _sembrada()
    cid = _cli(eid)
    (l1,) = _lineas(eid, "cliente")
    ctx = SimpleNamespace(empresa=SimpleNamespace(id=eid), puede=lambda p: True)
    with Session(engine_empresa(eid)) as s:
        main.agregar_direccion_cliente(cid, main.DireccionIn(nombre="Casa", detalle="100 m norte del parque"), ctx=ctx, s=s)
    (l2,) = _lineas(eid, "cliente")
    assert l2["id"] > l1["id"] and "direcciones" in json.loads(l2["campos"])


def test_b2_producto_alta_cambio_conflicto_validacion_y_codigos():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    otro = _prod(eid, "Té verde", codigo="750111")
    nuevo = 2 * R + 5
    fila = {"id": nuevo, "nombre": "Pan casero", "cabys": CABYS, "precio": 900, "codigo": "750222", "codigos_alternos": None}
    j = _mandar(tok, _op(1, "producto", nuevo, "alta", {"fila": fila}), _op(2, "producto", 3 * R + 1, "alta", {"fila": {**fila, "id": 3 * R + 1}}),
                _op(3, "producto", 777, "alta", {"fila": {**fila, "id": 777}}))
    r1, r2, r3 = j["resultados"]
    assert r1["estado"] == "aplicado" and r1["v"] and r1["canonico"]["nombre"] == "Pan casero" and r1["canonico"]["precio"] == 900
    assert r2["motivo"] == r3["motivo"] == "no_valido"                 # fuera de su rango; rango 0 sin carga inicial (C-3)
    with Session(engine_empresa(eid)) as s:
        assert s.get(Producto, 3 * R + 1) is None and s.get(Producto, 777) is None
    (l,) = [x for x in _lineas(eid, "producto") if x["ref"] == str(nuevo)]
    assert l["origen"] == 2
    ahora = datetime.now(timezone.utc).isoformat()
    # cambio de precio con su «antes» y código de barras repetido en la misma op: el precio entra, el código no (codigo_repetido)
    cam = _op(4, "producto", nuevo, "cambio", {"campos": {"precio": [[900, "CRC"], [950, "CRC"], ahora], "codigos": [["750222"], ["750111"], ahora]}})
    res = _mandar(tok, cam)["resultados"][0]
    assert res["estado"] == "fusionado" and res["canonico"]["precio"] == 950 and res["canonico"]["codigo"] == "750222"
    assert res["pisados"] == [{"campo": "codigos", "motivo": "codigo_repetido", "perdio": ["750111"]}]
    # solo el código repetido: rechazado con ese motivo
    res = _mandar(tok, _op(5, "producto", nuevo, "cambio", {"campos": {"codigos": [["750222"], ["750111"], ahora]}}))["resultados"][0]
    assert res["estado"] == "rechazado" and res["motivo"] == "codigo_repetido"
    # código alterno agregado en los dos lados: quedan los dos; el que ya usa otro ítem no entra
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, nuevo); p.codigos_alternos = "A-WEB"; s.add(p); s.commit()
    res = _mandar(tok, _op(6, "producto", nuevo, "cambio", {"campos": {}, "conjuntos": {"codigos_alternos": {"mas": ["A-CAJA", "750111"], "menos": []}}}))["resultados"][0]
    assert res["estado"] == "fusionado" and set(res["canonico"]["codigos_alternos"].split(",")) == {"A-WEB", "A-CAJA"}
    # validación de la pantalla: un nombre de 2 letras no entra y queda anotado
    res = _mandar(tok, _op(7, "producto", nuevo, "cambio", {"campos": {"nombre": [["Pan casero"], ["Pa"], ahora]}}))["resultados"][0]
    assert res["estado"] == "rechazado" and res["motivo"] == "no_valido" and res["canonico"]["nombre"] == "Pan casero"
    # conflicto: la web cambió el precio después del cambio de la caja → gana la web
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, nuevo); p.precio = 1000; s.add(p); s.commit()
    viejo = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
    res = _mandar(tok, _op(8, "producto", nuevo, "cambio", {"campos": {"precio": [[950, "CRC"], [990, "CRC"], viejo]}}))["resultados"][0]
    assert res["estado"] == "rechazado" and res["motivo"] == "conflicto" and res["canonico"]["precio"] == 1000
    assert ("codigos", "codigo_repetido") in _pisados(eid, nuevo) and ("precio", "conflicto") in _pisados(eid, nuevo)
    assert ("", "no_valido") in _pisados(eid, nuevo)
    with Session(engine_empresa(eid)) as s:
        assert s.get(Producto, otro).codigo == "750111"


def test_b2_baja_con_historia_y_sin_historia_y_foto_en_el_registro():
    from app import inventario
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    con, sin = _prod(eid, "Con ventas", codigo="111"), _prod(eid, "Sin ventas")
    con_c, sin_c = _cli(eid, "Con cobros"), _cli(eid, "Sin nada")
    with Session(engine_empresa(eid)) as s:
        b = inventario.bodega_principal(s, eid).id
        inventario.registrar_movimiento(s, producto=s.get(Producto, con), bodega_id=b, tipo="inicial", cantidad=3, fecha="2026-11-13", referencia="QA")
        inventario.existencia(s, sin, b)                              # una existencia en cero, sin movimientos
        s.add(modulos.Pago(empresa_id=eid, numero=1, cliente_id=con_c)); s.commit()
    j = _mandar(tok, *[_op(i + 1, t, r, "baja", {}) for i, (t, r) in enumerate((("producto", con), ("producto", sin), ("cliente", con_c), ("cliente", sin_c)))])
    assert [x["estado"] for x in j["resultados"]] == ["aplicado"] * 4
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, con)
        assert p.activo is False and p.codigo is None and s.get(Producto, sin) is None
        assert s.execute(text("SELECT COUNT(*) FROM existencia WHERE producto_id = :p"), {"p": sin}).scalar() == 0
        assert s.get(Cliente, con_c).activo is False and s.get(Cliente, sin_c) is None
        fila = s.execute(text("SELECT datos, por FROM sinc_cambio WHERE tipo = 'producto' AND ref = :r"), {"r": str(sin)}).first()
    assert json.loads(fila[0])["foto_web"]["nombre"] == "Sin ventas" and fila[1] == "Caja 2 · Luis"
    assert [x["borrado"] for x in _lineas(eid, "producto") if x["ref"] == str(sin)] == [True]


def test_b2_cliente_direcciones_como_conjunto_desde_los_dos_lados():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    casa = {"nombre": "Casa", "detalle": "100 m norte del parque", "enlace": ""}
    cid = _cli(eid, direcciones=json.dumps([casa]))
    trabajo = {"nombre": "Trabajo", "detalle": "Edificio azul, segundo piso", "enlace": ""}
    res = _mandar(tok, _op(1, "cliente", cid, "cambio", {"campos": {}, "conjuntos": {"direcciones": {"mas": [str(trabajo)], "menos": []}}}))["resultados"][0]
    assert res["estado"] == "fusionado"
    assert [d["nombre"] for d in json.loads(res["canonico"]["direcciones"])] == ["Casa", "Trabajo"]
    res = _mandar(tok, _op(2, "cliente", cid, "cambio", {"campos": {}, "conjuntos": {"direcciones": {"mas": [], "menos": [json.dumps(casa)]}}}))["resultados"][0]
    assert [d["nombre"] for d in json.loads(res["canonico"]["direcciones"])] == ["Trabajo"]


def test_b2_freno_de_bajas_solo_para_todos(monkeypatch, declaraciones):
    monkeypatch.setattr(sinc_datos, "FRENO_MINIMO", 2)
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    ids = [_prod(eid, f"Ítem {i}") for i in range(3)]
    j = _mandar(tok, *[_op(i + 1, "producto", p, "baja", {}) for i, p in enumerate(ids)])
    assert [(x["estado"], x["motivo"]) for x in j["resultados"]] == [("aplicado", None), ("aplicado", None), ("rechazado", "freno")]
    assert j["resultados"][2]["canonico"]["nombre"] == "Ítem 2" and ("", "freno") in _pisados(eid, ids[2])
    # la copia-ausencia de una cuenta (dueno) nunca pasa por el freno
    fila = {"id": 2 * R + 3, "pedido_id": 9}
    _mandar(tok, _op(4, "zz_cuenta", 2 * R + 3, "copia", {"fila": fila}))
    assert _mandar(tok, _op(5, "zz_cuenta", 2 * R + 3, "copia", {"fila": None}))["resultados"][0]["estado"] == "aplicado"


def test_b2_cajas_partidas_sin_altas_ni_bajas_desde_el_programa():
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja 1"}, {"id": 2, "nombre": "Caja 2"}], "propina": 10}, version=0)
    ahora = datetime.now(timezone.utc).isoformat()
    j = _mandar(tok, _op(1, "caja", "terminales#1", "cambio", {"campos": {"nombre": [["Caja 1"], ["Barra"], ahora]}}),
                _op(2, "caja", "terminales#2", "cambio", {"campos": {"nombre": [["Caja 2"], ["Terraza"], ahora]}}),
                _op(3, "caja", "terminales#3", "alta", {"fila": {"id": 3, "nombre": "Nueva"}}),
                _op(4, "caja", "terminales#2", "baja", {}),
                _op(5, "caja", "_", "cambio", {"campos": {"propina": [[10], [0], ahora]}}))
    assert [(x["estado"], x["motivo"]) for x in j["resultados"]] == [("aplicado", None), ("aplicado", None), ("rechazado", "no_valido"),
                                                                     ("rechazado", "no_valido"), ("aplicado", None)]
    with Session(engine_empresa(eid)) as s:
        cfg = modulos.leer(s, eid, "pos_config", None)
    assert [t["nombre"] for t in cfg["terminales"]] == ["Barra", "Terraza"] and cfg["propina"] == 0


def test_b2_filas_existe_borrado_nunca_y_max_dado(monkeypatch):
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    vivo, muerto = _prod(eid, "Vivo"), _prod(eid, "Muerto")
    with Session(engine_empresa(eid)) as s:
        s.delete(s.get(Producto, muerto)); s.commit()
    r = c.post("/api/sinc/datos/filas", headers=H(tok), json={"refs": [{"tipo": "producto", "ref": str(vivo)}, {"tipo": "producto", "ref": str(muerto)},
                                                                      {"tipo": "cliente", "ref": "40"}]})
    assert r.status_code == 200, r.text
    j = r.json()
    assert [(f["estado"], bool(f["v"])) for f in j["filas"]] == [("existe", True), ("borrado", True), ("nunca", False)]
    assert j["filas"][0]["datos"]["nombre"] == "Vivo" and j["filas"][1]["datos"] is None
    assert set(j["max_dado"]) == {"producto", "cliente"} and j["max_dado"]["producto"] >= vivo and j["epoca"]
    for malo in ({"refs": []}, {"refs": [{"tipo": "usuario", "ref": "1"}]}, {"refs": [{"tipo": "producto", "ref": 5}]}, {"refs": [{}] * 501}):
        r = c.post("/api/sinc/datos/filas", headers=H(tok), json=malo)
        assert r.status_code == 400 and r.json()["detail"]["codigo"] == "cuerpo"
    monkeypatch.setenv("FE_SINC_DATOS", "0")
    assert c.post("/api/sinc/datos/filas", headers=H(tok), json={"refs": [{"tipo": "producto", "ref": "1"}]}).status_code == 404


def test_b2_carga_inicial_alta_del_rango0_con_existencia():
    """C-3: un alta del rango 0 entra solo en la carga inicial (reserva hecha) de la única instalación, con su existencia."""
    from app import inventario
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    fila = {"id": 300, "nombre": "Del programa viejo", "cabys": CABYS, "precio": 500}
    sin_reserva = _mandar(tok, _op(1, "producto", 300, "alta", {"fila": fila}))["resultados"][0]
    assert sin_reserva["motivo"] == "no_valido"
    j = _mandar(tok, reservar={"producto": 400, "cliente": 10})
    assert j["reservado"]["producto"] == {"max_dado": 0}
    exist = [{"bodega_id": 999999, "cantidad": 7, "costo_promedio": 120, "pendiente": 7}]
    j = _mandar(tok, _op(2, "producto", 300, "alta", {"fila": fila, "existencias": exist}), _op(3, "producto", 401, "alta", {"fila": {**fila, "id": 401}}))
    assert [x["estado"] for x in j["resultados"]] == ["aplicado", "rechazado"]
    with Session(engine_empresa(eid)) as s:
        assert inventario.existencia(s, 300, inventario.bodega_principal(s, eid).id).cantidad == pytest.approx(7)


def test_b2_tope_diario_y_reservar_solo_items_y_clientes(monkeypatch):
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    r = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(reservar={"promo": 3}))
    assert r.status_code == 400 and r.json()["detail"]["codigo"] == "cuerpo"
    monkeypatch.setattr(sinc_datos, "MAX_OPS_DIA", 2)
    _cat(eid, {"id": 1, "nombre": "Uno"})
    ahora = datetime.now(timezone.utc).isoformat()
    _mandar(tok, _cambio(1, "1", {"nombre": [["Uno"], ["Dos"], ahora]}))
    r = c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(ops=[_cambio(2, "1", {"nombre": [["Dos"], ["Tres"], ahora]}),
                                                                   _cambio(3, "1", {"nombre": [["Tres"], ["Cuatro"], ahora]})]))
    assert r.status_code == 429
    assert c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo()).status_code == 200   # el goteo sigue


def test_b2_resiembra_por_huella_tras_volver_de_la_431(monkeypatch):
    eid = _sembrada()
    cambia, quita = _prod(eid, "Cambia"), _prod(eid, "Se quita")
    antes = {x["ref"]: x["id"] for x in _lineas(eid, "producto")}
    with Session(engine_empresa(eid)) as s:                            # la 4.31 no tenía oyente: SQL directo
        s.execute(text("UPDATE producto SET precio = 2222 WHERE id = :i"), {"i": cambia})
        s.execute(text("DELETE FROM producto WHERE id = :i"), {"i": quita})
        s.commit()
    nuevo = _prod(eid, "Nuevo en la 4.31")
    with Session(engine_empresa(eid)) as s:                            # creado sin oyente: sin línea
        s.execute(text("DELETE FROM sinc_dato WHERE tipo = 'producto' AND ref = :r"), {"r": str(nuevo)}); s.commit()
    assert str(nuevo) not in {x["ref"] for x in _lineas(eid, "producto")}
    monkeypatch.setenv("FE_SINC_RESEMBRAR", "1")
    sinc_datos._RESIEMBRA.pop(eid, None)
    with Session(engine_empresa(eid)) as s:
        assert sinc_datos.resembrar(s, eid, tramo=1) is False             # por tramos
        while not sinc_datos.resembrar(s, eid, tramo=1):
            pass
    lin = {x["ref"]: x for x in _lineas(eid, "producto")}
    assert lin[str(cambia)]["id"] > antes[str(cambia)] and not lin[str(cambia)]["borrado"]
    assert lin[str(quita)]["borrado"] and str(nuevo) in lin and not lin[str(nuevo)]["borrado"]
    tope = _maximo(eid)
    sinc_datos._RESIEMBRA.pop(eid, None)
    with Session(engine_empresa(eid)) as s:
        assert sinc_datos.resembrar(s, eid) is True
    assert _maximo(eid) == tope                                          # otra pasada sin diferencias: nada nuevo


def test_b2_bandera_pedidos_programa_solo_en_el_bloque_del_programa():
    import inspect
    fuente = inspect.getsource(auth._info_empresa)
    bloque = fuente[fuente.index("if aviso_local is not None:"):]
    assert 'd["pedidos_programa"] = bool(d["datos_v2"]) and bool(_sdp.estado(e.id).get("pedidos_programa"))' in bloque
    assert 'd["pedidos_programa"] = False' in bloque


# =================================================================================================================== revisión (grupo W)
def test_rev_ultima_llamada_en_la_base_para_todos_los_procesos(declaraciones):
    """(I-1, n.º 1 y 20): /datos guarda la última llamada en la base de la empresa (sinc_llamada): otro proceso, sin nada en su memoria, la
    ve con contacto_guardado. Se escribe como mucho cada 20 s, o antes si estacion_viva cambia. /datos/accion no pisa la estación con False."""
    eid = _sembrada()
    tok = _instalacion(eid, terminal=2)
    assert sinc_datos.contacto_guardado(eid, 2) is None                      # nunca llamó
    assert c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(estacion_viva=True)).status_code == 200
    sinc_datos.ULTIMA_LLAMADA.clear()                                        # otro proceso: memoria vacía
    hora, viva = sinc_datos.contacto_guardado(eid, 2)
    import time as _t
    assert viva is True and 0 <= _t.time() - hora < 30

    def guardada():
        with Session(engine_empresa(eid)) as s:
            return tuple(s.execute(text("SELECT hora, estacion_viva FROM sinc_llamada WHERE terminal = 2")).first())
    primera = guardada()
    c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(estacion_viva=True))
    assert guardada() == primera                                             # menos de 20 s y la misma estación: no escribe
    c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(estacion_viva=False))
    assert bool(guardada()[1]) is False                                      # la estación cambió: escribe ya
    c.post("/api/sinc/datos", headers=H(tok), json=_cuerpo(estacion_viva=True))
    with Session(engine_empresa(eid)) as s:                                  # hace 30 s
        s.execute(text("UPDATE sinc_llamada SET hora = hora - 30 WHERE terminal = 2")); s.commit()
    sinc_datos.ULTIMA_LLAMADA.clear()                                        # la acción cae en un proceso sin memoria
    r = c.post("/api/sinc/datos/accion", headers=H(tok), json={"tipo": "zz_web", "ref": "45", "accion": "aceptar", "datos": {}})
    assert r.status_code == 200, r.text
    sinc_datos.ULTIMA_LLAMADA.clear()
    hora2, viva2 = sinc_datos.contacto_guardado(eid, 2)
    assert viva2 is True and _t.time() - hora2 < 5                          # la acción renovó la hora sin apagar la estación


def test_rev_oyente_lee_el_registro_una_vez_por_pasada(monkeypatch):
    """(n.º 21): guardar items_extra con muchas llaves lee y parsea el registro una sola vez por pasada (no una por llave), con el mismo
    resultado: solo la llave cambiada recibe versión."""
    eid = _sembrada()
    extra = {str(p): {"extras": [p], "nota": "n"} for p in range(1, 61)}
    with Session(engine_empresa(eid)) as s:
        fisitaap._reemplazar(s, eid, "items_extra", extra); s.commit()
    assert len(_lineas(eid, "item_extra")) == 60
    antes = _maximo(eid)
    real, cuenta = sinc_datos._valor_registro, []

    def contar(conn, eid_, clave):
        if clave == "items_extra":
            cuenta.append(1)
        return real(conn, eid_, clave)
    monkeypatch.setattr(sinc_datos, "_valor_registro", contar)
    extra["7"] = {"extras": [7, 8], "nota": "n"}
    with Session(engine_empresa(eid)) as s:
        fisitaap._reemplazar(s, eid, "items_extra", extra); s.commit()
    nuevas = [l["ref"] for l in _lineas(eid, "item_extra") if l["id"] > antes]
    assert nuevas == ["7"]
    assert len(cuenta) <= 5, f"el oyente leyó items_extra {len(cuenta)} veces para 60 llaves"


def test_rev_sembrada_se_mira_en_la_base():
    """(n.º 11): otro proceso restauró un respaldo sin la marca: este proceso, que ya la había visto, no la da por buena."""
    eid = _sembrada()
    assert sinc_datos.sembrada(eid) and sinc_datos.oyente_modo(eid) == "autoridad"
    with Session(engine_empresa(eid)) as s:                                  # la base «restaurada» sin la marca (sin pasar por este proceso)
        s.execute(text("DELETE FROM sinc_dato WHERE tipo = '_' AND ref = '_'")); s.commit()
    assert sinc_datos.sembrada(eid) is False and sinc_datos.oyente_modo(eid) == "apagado"


def test_rev_purga_de_la_web_y_sus_indices():
    """(n.º 33): 90 días lo aplicado sin choques, 1 año lo demás, siempre la última de cada autora; sinc_pisado 365 días; índices."""
    eid = _sembrada()
    from datetime import timedelta as _td
    viejo = lambda d: (datetime.now(timezone.utc) - _td(days=d)).isoformat(timespec="seconds")   # noqa: E731
    limpio = json.dumps({"estado": "aplicado", "pisados": []}, ensure_ascii=False)
    filas = [(1, "aplicado", "cambio", limpio, viejo(100)),                  # se va (90 días)
             (2, "rechazado", "alta", json.dumps({"estado": "rechazado", "pisados": []}), viejo(100)),   # se queda (1 año)
             (3, "aplicado", "baja", limpio, viejo(100)),                    # baja: se queda
             (4, "rechazado", "alta", "{}", viejo(400)),                     # se va (más de 1 año)
             (5, "aplicado", "cambio", limpio, viejo(0)),                    # de hoy
             (6, "aplicado", "cambio", limpio, viejo(200))]                  # vieja, pero la última de la autora: se queda
    with Session(engine_empresa(eid)) as s:
        for n, est, op, res, cuando in filas:
            s.execute(text("INSERT INTO sinc_cambio (autora, n, tipo, ref, op, base_v, datos, estado, resultado, intentos, creado) "
                           "VALUES ('2.purga', :n, 'categoria', '1', :o, 0, '{}', :e, :r, 0, :c)"), {"n": n, "o": op, "e": est, "r": res, "c": cuando})
        for cuando in (viejo(400), viejo(5)):
            s.execute(text("INSERT INTO sinc_pisado (cuando, tipo, ref, motivo) VALUES (:c, 'categoria', '1', 'conflicto')"), {"c": cuando})
        s.execute(text("DROP INDEX IF EXISTS ix_sinc_cambio_creado")); s.commit()
        sinc_datos.purgar_web(s, eid, forzar=True)
        quedan = [n for (n,) in s.execute(text("SELECT n FROM sinc_cambio WHERE autora = '2.purga' ORDER BY n")).all()]
        pisados = s.execute(text("SELECT COUNT(*) FROM sinc_pisado")).scalar()
        indices = {r[1] for r in s.execute(text("PRAGMA index_list(sinc_cambio)")).all()} | {r[1] for r in s.execute(text("PRAGMA index_list(sinc_dato)")).all()}
    assert quedan == [2, 3, 5, 6] and pisados == 1
    assert {"ix_sinc_cambio_creado", "ix_sinc_dato_dueno"} <= indices
    with Session(engine_empresa(eid)) as s:                                  # las cuentas por terminal usan el índice de autora (sin LIKE)
        assert sinc_datos.ops_del_dia(s.connection(), 2) == 1 and sinc_datos.ops_del_dia(s.connection(), 22) == 0


def test_rev_tope_de_bytes_sin_content_length():
    """(n.º 37): el tope de 1 MB también se cumple cuando la petición no trae Content-Length."""
    from types import SimpleNamespace
    grande = _cuerpo(ops=[{"n": 1, "tipo": "categoria", "ref": "1", "op": "cambio", "datos": {"x": "a" * (sinc_datos.MAX_BYTES + 10)}}])
    with pytest.raises(HTTPException) as e:
        sinc_datos._validar_datos(grande, SimpleNamespace(headers={}))
    assert e.value.status_code == 400 and e.value.detail["codigo"] == "grande"
    assert sinc_datos._validar_datos(_cuerpo(), SimpleNamespace(headers={}))["protocolo"] == 2
