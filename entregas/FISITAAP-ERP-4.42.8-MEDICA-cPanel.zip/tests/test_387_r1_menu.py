"""3.87 (segunda ronda, grupo r1_menu): lo que un puesto no puede usar no aparece en su menú ni en las portadas, y escrito a mano
dice «Sin acceso» sin pedir datos al servidor; lo que sí puede usar no desaparece.
- F2, facturacion-r3, comercio-r3: Inventario › Por reponer abre con los mismos permisos que GET /api/inventario/reponer.
- comercio-r4: Solo lectura en Comercio y Hospitalidad ve las pantallas contables (el servidor ya le deja leerlas).
- comercio-r5, extras-F5, facturacion-r4, restaurante-r4: las secciones de Configuración piden lo mismo en la portada y en la ruta
  (una sola tabla, PERMISO_CONFIG, en menu.js); Respaldos pide configurar y usuarios; Traslados, los permisos de GET /api/traslados.
- comercio-r7: lo de Ventas en línea que el servidor guarda con 'catalogos' sale en el menú solo con 'catalogos'.
- hospitalidad-F5, servicios-R2/R3, extras-F3: Ingresos e Inventario no abren a los roles de un solo módulo (auth.PERMISOS_DOCUMENTOS).
Las reglas de la interfaz se leen de menu.js y se comparan con lo que el servidor responde de verdad a un rol por permiso. El
recorrido en el navegador (61 sesiones, antes y después) está en scratchpad/arreglos2/r1_menu_qa/menus_r1.py."""
import json
import pathlib
import re
import uuid
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth
from app.db import Empresa, engine, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
PW = "Clave-larga-387-r1-menu-QA"
H = lambda t: {"Authorization": "Bearer " + t}   # noqa: E731
# un rol propio por permiso (además de «ver», que lleva todo rol) y el Administrador, que también administra usuarios
UNO = ["escribir", "facturar", "cobros", "catalogos", "inventario", "gastos", "contabilidad", "reportes", "documentos", "configurar",
       "ver_todo", "pos", "rrhh", "tike", "limpieza", "mantenimiento", "seguridad"]


def _js(*partes):
    return (RAIZ / "static" / "js" / pathlib.Path(*partes)).read_text(encoding="utf-8")


def _lista(texto):
    return [x.strip().strip("'\"") for x in texto.split(",") if x.strip()]


def _reglas():
    """Las reglas nuevas de menu.js: permisos de documentos, rutas con varios permisos y la tabla de secciones de Configuración."""
    m = _js("menu.js")
    docs = re.search(r"const PERMISOS_DOCUMENTOS = \[([^\]]*)\];", m)
    alguno = re.search(r"const PERMISO_RUTA_ALGUNO = \[(.*?)\];\n", m, re.S)
    cfg = re.search(r"export const PERMISO_CONFIG = \{(.*?)\n\};", m, re.S)
    assert docs and alguno and cfg, "faltan PERMISOS_DOCUMENTOS, PERMISO_RUTA_ALGUNO o PERMISO_CONFIG en menu.js"
    rutas = {pre: _lista(ps) for pre, ps in re.findall(r"\['(/[^']+)', \[([^\]]*)\]\]", alguno.group(1))}
    tabla = {}
    for k, v in re.findall(r"'?([a-z-]+)'?: (\[[^\]]*\]|'[a-z_]+')", cfg.group(1)):
        tabla[k] = _lista(v.strip("[]"))
    return set(_lista(docs.group(1))), rutas, tabla


@pytest.fixture(scope="module")
def mundo():
    """Una empresa (sin plan: todos los módulos) con un rol propio por permiso y un Administrador; {nombre: (token, permisos)}."""
    init_db()
    suf = uuid.uuid4().hex[:6]
    correos, sesiones = [], {}
    with Session(engine) as s:
        e = Empresa(nombre=f"R1 menu {suf}", numero_id="3101387" + str(uuid.uuid4().int)[:3], actividad="551001", otras_senas="QA 387",
                    correo=f"r1menu.{suf}@example.test", ambiente="sandbox", tipo_negocio="comercio")
        s.add(e); s.commit(); s.refresh(e)
        roles = {f"Solo {p}": [p] for p in UNO}
        roles["Caja sin catálogos"] = ["pos", "cobros"]
        roles["Caja con catálogos"] = ["pos", "catalogos"]
        for n, p in roles.items():
            s.add(auth.RolEmpresa(empresa_id=e.id, nombre=n, permisos=json.dumps(p)))
        s.commit()
        for rol in list(roles) + ["Administrador"]:
            correo = f"r1.{re.sub(r'[^a-z]', '', rol.lower())}.{suf}@example.test"
            u = auth.Usuario(correo=correo, nombre=rol + " QA", password_hash=auth.hash_password(PW), mfa_activo=True,
                             terminos_version=auth.TERMINOS_VERSION, terminos_fecha=datetime.now(timezone.utc), consiente_factura=True, paleta="turquesa")
            s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol=rol)); s.commit()
            r = auth._respuesta(s, u, e.id)
            sesiones[rol] = (r["token"], set(r["permisos"]))
            correos.append(correo)
        eid = e.id
    yield TestClient(app), sesiones
    with Session(engine) as s:
        for correo in correos:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            if not u:
                continue
            for x in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                s.delete(x)
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == u.id)).all():
                s.delete(x)
            s.delete(u)
        for r in s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == eid)).all():
            s.delete(r)
        e = s.get(Empresa, eid)
        if e:
            s.delete(e)
        s.commit()


def test_rutas_con_los_permisos_que_pide_el_servidor(mundo):
    """Para cada rol, la ruta abre en la interfaz si y solo si el servidor le da los datos de esa pantalla (antes abría con 403)."""
    c, sesiones = mundo
    docs, rutas, tabla = _reglas()
    assert docs == set(auth.PERMISOS_DOCUMENTOS)                                   # espejo exacto del servidor
    casos = [  # (pantalla, petición del servidor que la llena, regla de la interfaz)
        ("#/ventas/facturas", "/api/comprobantes", lambda p: bool(p & docs)),
        ("#/inventario/bodegas", "/api/inventario/bodegas", lambda p: bool(p & docs)),
        ("#/inventario/reponer", "/api/inventario/reponer", lambda p: bool(p & docs) and bool(p & set(rutas["/inventario/reponer"]))),
        ("#/inventario/traslados", "/api/traslados", lambda p: bool(p & docs) and bool(p & set(rutas["/inventario/traslados"]))),
        ("#/configuracion/ia", "/api/ia/uso", lambda p: set(tabla["ia"]) <= p),
        ("#/configuracion/respaldos", "/api/respaldos", lambda p: set(tabla["respaldos"]) <= p),
    ]
    distintos = []
    for rol, (tk, permisos) in sesiones.items():
        cajero = "pos" in permisos and permisos <= {"ver", "pos"}                  # modo cajero: solo la caja (su regla va antes, en otra prueba)
        for pantalla, url, regla in casos:
            if cajero and not pantalla.startswith("#/configuracion/"):
                continue
            st = c.get(url, headers=H(tk)).status_code
            assert st in (200, 403), (rol, url, st)
            if (st == 200) != regla(permisos):
                distintos.append((rol, pantalla, st, regla(permisos)))
    assert not distintos, distintos
    # y no queda corto: lo que sí ven los puestos de siempre
    assert tabla["respaldos"] == ["configurar", "usuarios"] and tabla["usuarios"] == ["usuarios"]
    assert set(rutas["/inventario/reponer"]) == {"inventario", "gastos", "catalogos", "ver_todo"}


def test_ventas_en_linea_pide_catalogos_donde_el_servidor_lo_pide(mundo):
    c, sesiones = mundo
    m = _js("menu.js")
    claves = set(_lista(re.search(r"const CLAVES_CATALOGOS = \[([^\]]*)\];", m).group(1)))
    assert {"productos", "extras", "opcionales", "combos", "promociones", "cupones", "publicar", "configuracion", "contenido", "delivery"} == claves
    assert not claves & {"resumen", "bienvenida", "pedidos", "express-pendientes", "clientes-historial", "fidelizacion", "contactos", "kpis"}   # consulta: siguen con pos
    assert "permiso: CLAVES_CATALOGOS.includes(clave) ? 'catalogos' : 'pos' });" in m
    assert "{ label: 'Catálogo web', permiso: 'catalogos', children: [" in m      # el grupo entero (no queda vacío en el menú lateral)
    # el servidor: editar la página y los cupones exige catálogos (pedidos.gestion y promociones.gestion)
    sin, con = sesiones["Caja sin catálogos"][0], sesiones["Caja con catálogos"][0]
    assert c.get("/api/tarjetas", headers=H(sin)).status_code == 403 and c.get("/api/tarjetas", headers=H(con)).status_code == 200
    assert c.put("/api/pedidos/negocio", json={}, headers=H(sin)).status_code == 403
    assert c.put("/api/pedidos/negocio", json={}, headers=H(con)).status_code != 403


def test_una_sola_tabla_para_la_portada_y_la_ruta():
    m, hub = _js("menu.js"), _js("pages", "configuracion", "hub.js")
    assert "import { PERMISO_CONFIG } from '../../menu.js';" in hub and "export { PERMISO_CONFIG };" in hub
    assert "export const PERMISO_CONFIG = {" not in hub                             # no hay una segunda copia que se desfase
    _, _, tabla = _reglas()
    # toda sección que existe tiene regla: en PERMISO_CONFIG o en PERMISO_RUTA (contabilidad-*, marcas)
    sec = _js("pages", "configuracion", "seccion.js")
    bloque = sec[sec.index("const SECCIONES = {"):sec.index("};", sec.index("const SECCIONES = {"))]
    slugs = set(re.findall(r"'([a-z-]+)': Sec", bloque)) | set(re.findall(r"[\s{]([a-z]+): Sec", bloque))
    reglas_ruta = re.findall(r"\['/configuracion/([a-z-]+)', '[a-z_]+'", m)
    sin_regla = sorted(x for x in slugs if x not in tabla and not any(x.startswith(r) for r in reglas_ruta))
    assert len(slugs) > 30 and not sin_regla, sin_regla
    # y toda opción de la portada que es una sección también
    grupos = hub[hub.index("export const GRUPOS = ["):hub.index("];", hub.index("export const GRUPOS = ["))]
    opciones = {x.split("?")[0] for x in re.findall(r"\['([a-z][a-z-]*(?:\?[^']*)?)', '", grupos)}
    assert not sorted(x for x in opciones if x not in tabla and not any(x.startswith(r) for r in reglas_ruta)), opciones   # marcas y contabilidad-*: PERMISO_RUTA


def test_orden_de_las_reglas_en_rutaPermitidaDe():
    m = _js("menu.js")
    cuerpo = m[m.index("export function rutaPermitidaDe(s, path) {"):]
    cuerpo = cuerpo[:cuerpo.index("\n}\n")]
    i = {k: cuerpo.index(k) for k in ("modoCajeroDe(s) &&", "rutaSinModuloDe(s, path)", "!PERMISOS_DOCUMENTOS.some(p => s.puede(p))) return false;",
                                      "of PERMISO_RUTA_ALGUNO) if (path.startsWith(pre)) return perms.some(p => s.puede(p));",
                                      "if (seccion) return [].concat(seccion).every(p => p === 'ver' || s.puede(p));", "of PERMISO_RUTA)")}
    orden = sorted(i, key=i.get)
    assert orden[:2] == ["modoCajeroDe(s) &&", "rutaSinModuloDe(s, path)"] and orden[-1] == "of PERMISO_RUTA)", orden   # caja, versión y plan primero
    assert "if (/^\\/(ventas|inventario)(\\/|$)/.test(path) && !PERMISOS_DOCUMENTOS" in cuerpo


def test_contabilidad_en_comercio_y_hotel_se_ve_con_ver_todo():
    m = _js("menu.js")
    linea = next(x for x in m.splitlines() if "...por['Contabilidad'].children.map" in x)
    assert "permisos: ['contabilidad']" in linea and "permiso: 'contabilidad'" not in linea
    # hijoOkDe deja pasar ver_todo con «permisos» (y no con un «permiso» de hoja): por eso se cambia la forma, no la regla
    assert "if (c.permisos) return c.permisos.some(p => s.puede(p)) || s.puede('ver_todo');" in m
    # Solo lectura lee lo contable en el servidor (su descripción lo promete)
    assert "ver_todo" in {p for p, rs in auth.PERMISOS.items() if "Solo lectura" in rs} and "contabilidad" in auth.DESCRIPCION_ROLES["Solo lectura"]


def test_invitar_al_contador_y_traslados_sin_pantallas_que_no_abren():
    rep = _js("pages", "reportes", "hub.js")
    assert "<div class=\"alert info\" v-if=\"puedeFin() && puede('usuarios')\"" in rep    # el botón lleva a Usuarios, que pide 'usuarios'
    tras = _js("pages", "inventario", "traslados.js")
    assert "sesion.puede('inventario') && sesion.puede('facturar') ? api('/api/traslados/destinos').catch(() => []) : []" in tras
    srv = (RAIZ / "traslados.py").read_text(encoding="utf-8")
    assert 'if not (ctx.puede("inventario") and ctx.puede("facturar")):\n        raise HTTPException(403, "Para trasladar inventario' in srv
