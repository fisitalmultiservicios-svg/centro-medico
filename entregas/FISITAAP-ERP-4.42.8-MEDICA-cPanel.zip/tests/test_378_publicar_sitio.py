"""3.78: (1) la página del negocio se publica desde Ventas en línea › Mi página › Publicar y dominio (al embeber FISITAAP en 3.74 la
pantalla vieja «Mi página», la única con Publicar, dirección, buscadores, píxeles y dominio, dejó de abrirse); (2) el sitio público
lleva la marca FISITAAP ERP, el inicio nuevo y las páginas Ventas en línea y Hotel."""
import io
import re

from app.config import BASE_DIR
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)
from tests.test_pedidos import _publicar


def _static(*partes):
    return io.open(BASE_DIR.joinpath("app", "static", *partes), encoding="utf-8").read()


def test_pantalla_publicar_en_ventas_en_linea(api):  # noqa: F811
    c = api
    r = c.get("/js/fis/pages/publicar.js"); assert r.status_code == 200
    js = r.text
    for clave in ("Publicar", "Despublicar", "n.slug", "n.seo_titulo", "n.google_id", "n.pixel_meta", "n.dominio", "dominio/verificar", "n.galeria", "n.nosotros", "guardarNegocio"):
        assert clave in js, clave
    assert "fis('publicar', 'Publicar y dominio')" in _static("js", "menu.js")
    assert "'/fisitaap/pagina': '/publicar'" in _static("js", "app.js")
    assert "publicar: { m: 'publicar', titulo: 'Publicar y dominio' }" in _static("js", "fis", "app.js")
    assert "tieneFuncion(f)" in _static("js", "fis", "sesion.js")
    assert 'href="#/publicar"' in _static("js", "fis", "pages", "contenido.js") and ".fis-tabs" in _static("fisitaap", "fis.css")


def test_publicar_y_despublicar_abren_o_cierran_la_pagina(api):  # noqa: F811
    c = api
    r = _publicar(c, slug="pub-378-qa", activo=True); assert r.status_code == 200, r.text
    assert r.json()["activo"] is True and c.get("/pub-378-qa").status_code == 200
    assert c.get("/api/publico/pub-378-qa").status_code == 200
    r = _publicar(c, slug="pub-378-qa", activo=False); assert r.status_code == 200, r.text
    assert r.json()["activo"] is False and c.get("/api/publico/pub-378-qa").status_code == 404


def test_sitio_publico_con_marca_fisitaap_erp(api):  # noqa: F811
    c = api
    inicio = c.get("/").text
    assert "Un ERP. Muchas posibilidades." in inicio and "/fisitaap/assets/fisitapp-logo.webp" in inicio and 'class="erp-by">by Brillante Agencia' in inicio
    assert "grupo<b>factura" not in inicio and "og-grupo-factura" not in inicio and "og-fisitaap-erp.jpg" in inicio
    assert 'href="/ventas-en-linea"' in inicio and 'href="/hotel"' in inicio and "Se adapta a su tipo de negocio" in inicio
    for ruta, h1 in (("/ventas-en-linea", "Reciba pedidos en línea sin pagar comisiones por pedido"), ("/hotel", "Recepción, reservaciones y ama de llaves con factura electrónica")):
        r = c.get(ruta); assert r.status_code == 200, ruta
        assert h1 in r.text and "{{" not in r.text, ruta
        for img in re.findall(r'src="(/img/sitio/[^"]+)"', r.text):
            assert c.get(img).status_code == 200, img
    sm = c.get("/sitemap.xml"); assert sm.status_code == 200 and "/ventas-en-linea" in sm.text and "/hotel" in sm.text
    css = c.get("/landing.css").text
    assert "--osc:#1f4965" in css and "--p:#237658" in css and ".erp-tag" in css and ".tipos{" in css and "#0f766e" not in css
    sprite = _static("img", "sitio", "marca", "iconos.svg")
    for ident in ("tienda", "cama", "herramienta", "mundo", "camion", "calendario"):
        assert f'id="{ident}"' in sprite, ident
    assert c.get("/img/sitio/og-fisitaap-erp.jpg").status_code == 200 and c.get("/img/fisitaap-icono-512.png").status_code == 200
