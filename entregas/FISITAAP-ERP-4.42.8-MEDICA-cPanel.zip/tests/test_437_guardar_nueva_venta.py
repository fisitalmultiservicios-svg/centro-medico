# -*- coding: utf-8 -*-
"""4.37, soporte de un restaurante (14 nov 2026), Itzen: «se ocupa un botón de nueva venta también ahí para pasarse a otra y que deje
guardada la pendiente». En la caja de restaurante, en la venta rápida, «Guardar cuenta» pasaba al plano de Mesas. Ahora, en la venta
rápida, el botón dice «Guardar y nueva venta»: guarda la cuenta en espera y deja otra venta rápida limpia. F4 sin platos abre las
cuentas guardadas. Dentro de una mesa nada cambia.
4.38: la cuenta recuperada vuelve a trabajarse como antes de la 4.37 (la 4.37 la dejaba en la venta rápida y su cobro pasaba por la
comanda automática de la venta rápida: ver test_438_recuperar_queda_como_antes_de_la_437); la venta nueva sale sin cupón, puntos ni
autorización; el número de «Cuenta N» no se repite."""
import json
import shutil
import subprocess

import pytest

from tests.test_425_ultimos_pantallas import JS, _js, _nodo, _tramo


def _metodo(t, firma):
    return _tramo(t, "    " + firma, "\n    },") + "\n    }"


def _linea(t, firma):
    return _tramo(t, "    " + firma, "\n").split("   //")[0].strip().rstrip(",")


def _computada(t, nombre):
    return _tramo(t, "    " + nombre + "() {", "\n").split("//")[0].split("/*")[0].strip().rstrip(",")


def _correr(tmp_path, guion):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    (tmp_path / "prueba.mjs").write_text(guion, encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout)


def test_guardar_en_la_venta_rapida_deja_otra_venta_rapida_y_en_la_mesa_vuelve_al_plano(tmp_path):
    t = _js("pages/pos/caja.js")
    metodos = [_metodo(t, "guardarCuenta() {"), _metodo(t, "ponerEnEspera() {"), _metodo(t, "recuperar(v) {"),
               _linea(t, "nuevaVentaRapida() {"), _linea(t, "ventaSinMesa() {"), _linea(t, "cargarCuenta(v) {")]
    computadas = [_computada(t, n) for n in ("esVentaRapida", "enMesas", "cuentaActual", "esperaCaja", "esperaSinMesa", "esperaRapida")]
    guion = """
const avisos = [];
globalThis.toast = (m, k) => avisos.push(m);
globalThis.uuid = () => 'u' + Math.random();
globalThis.confirm = () => true;
globalThis.ponerLids = () => {};
const C = { %s };
const M = { %s };
function caja(estado) {
  const vm = Object.assign({ vista: 'venta', mesaActual: null, rapida: true, esperaId: null, nombreEspera: '', espera: [], lineas: [], nota: '',
    clienteId: null, servicio: false, servicioPctCuenta: null, parteNueva: false, salonero: '', cobroParcial: null, modalEspera: false, idem: 'x',
    esRestaurante: true, cfg: { id: 1, modo: 'restaurante', cliente_defecto_id: 9 }, mesas: [{ id: 4, nombre: 'Mesa 4' }], llamadas: [],
    $nextTick: f => f && f(), $refs: {},
    volverAMesas(s) { this.llamadas.push('mesas'); this.lineas = []; this.esperaId = null; this.mesaActual = null; this.vista = 'mesas'; },
    persistirCuenta() { const id = this.esperaId || this.espera.length + 1, nombre = this.nombreEspera || ('Cuenta ' + id);
      this.espera = [...this.espera.filter(v => v.id !== id), { id, nombre, terminal_id: this.cfg.id, mesa_id: this.mesaActual ? this.mesaActual.id : undefined, lineas: this.lineas.map(l => ({ ...l })) }]; return nombre; },
    descartarVacia() { this.llamadas.push('descartar'); return false; },
    bajaCuenta(id) { this.llamadas.push('baja ' + id); this.espera = this.espera.filter(v => v.id !== id); },
    baseDe() { return null; }, tomarBase() {}, aplicarPromos() {},
  }, estado || {});
  for (const [n, f] of Object.entries(C)) Object.defineProperty(vm, n, { get: f.bind(vm) });
  for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
  return vm;
}
const plato = n => ({ producto_id: n, detalle: 'Plato ' + n, cantidad: 1, precio_unitario: 1000 });
const foto = vm => ({ vista: vm.vista, rapida: vm.esVentaRapida, mesas: vm.enMesas, lineas: vm.lineas.length, esperaId: vm.esperaId,
  guardadas: vm.esperaSinMesa.length, boton: vm.esperaRapida.length, modal: vm.modalEspera, llamadas: vm.llamadas.slice(), cliente: vm.clienteId });
const o = {};

// 1. venta rápida con platos: «Guardar y nueva venta» guarda y deja otra venta rápida limpia
let a = caja(); a.lineas.push(plato(1)); a.nota = 'sin cebolla'; a.guardarCuenta(); o.rapida1 = foto(a); o.rapida1_nota = a.nota;
a.lineas.push(plato(2)); a.guardarCuenta(); o.rapida2 = foto(a); o.rapida2_nombres = a.espera.map(v => v.nombre);

// 2. F4 sin platos en la venta rápida: con cuentas guardadas abre la lista; sin ninguna, solo avisa
a.guardarCuenta(); o.f4_con = foto(a);
let b = caja(); avisos.length = 0; b.guardarCuenta(); o.f4_sin = foto(b); o.f4_sin_aviso = avisos.slice();

// 3. (4.38) recuperar una sin mesa desde la venta rápida: se trabaja como antes de la 4.37 (no es venta rápida: el cobro no manda
//    la comanda automática de la venta rápida) y guardarla vuelve al plano
a.modalEspera = true; a.recuperar(a.espera.find(v => v.id === 1)); o.recuperada = foto(a);
a.lineas.push(plato(3)); a.guardarCuenta(); o.recuperada_guardada = foto(a); o.recuperada_lineas = a.espera.find(v => v.id === 1).lineas.length;

// 4. recuperada y vaciada: se da de baja y vuelve al plano, como antes
a.recuperar(a.espera.find(v => v.id === 2)); a.lineas = []; a.guardarCuenta(); o.vaciada = foto(a);

// 4b. la venta rápida que se guarda con un cupón, puntos o una autorización: la venta nueva sale sin ellos
let g = caja({ cupon: { codigo: 'HOLA' }, puntos: { cliente_id: 3, puntos: 10 }, autorizado: { usuario: 'sup@example.test' } });
g.lineas.push(plato(1)); g.guardarCuenta(); o.sin_cupon = [g.cupon, g.puntos, g.autorizado, g.vista, g.esVentaRapida];

// 5. desde el plano: la recuperada queda como antes («Mesas» marcado) y guardar vuelve al plano
let c = caja({ vista: 'mesas', rapida: false, espera: [{ id: 7, nombre: 'Ana', terminal_id: 1, lineas: [plato(1)] }] });
c.recuperar(c.espera[0]); o.plano_recuperada = foto(c); c.guardarCuenta(); o.plano_guardada = foto(c);

// 6. una cuenta de mesa recuperada desde la venta rápida abre la mesa (no es venta rápida)
let d = caja({ espera: [{ id: 8, nombre: 'Mesa 4', terminal_id: 1, mesa_id: 4, lineas: [plato(1)] }] });
d.recuperar(d.espera[0]); o.mesa_recuperada = foto(d);

// 7. dentro de una mesa: «Guardar cuenta» vuelve al plano como siempre
let e = caja({ mesaActual: { id: 4, nombre: 'Mesa 4' }, rapida: false }); e.lineas.push(plato(1)); e.guardarCuenta(); o.mesa = foto(e);

// 8. caja de mostrador: guardar solo pone en espera (ni plano ni venta rápida nueva)
let f = caja({ esRestaurante: false, cfg: { id: 1, modo: 'mostrador' } }); f.lineas.push(plato(1)); f.guardarCuenta(); o.mostrador = foto(f); o.mostrador_espera = f.espera.length;
console.log(JSON.stringify(o));
""" % (",\n".join("  " + c for c in computadas), ",\n".join("  " + m.strip() for m in metodos))
    o = _correr(tmp_path, guion)
    r1 = o["rapida1"]
    assert (r1["vista"], r1["rapida"], r1["mesas"], r1["lineas"], r1["esperaId"]) == ("venta", True, False, 0, None), r1
    assert r1["guardadas"] == 1 and r1["boton"] == 1 and "mesas" not in r1["llamadas"] and r1["cliente"] == 9, r1
    assert o["rapida1_nota"] == ""
    assert o["rapida2"]["boton"] == 2 and o["rapida2"]["vista"] == "venta" and o["rapida2_nombres"] == ["Cuenta 1", "Cuenta 2"], o
    assert o["f4_con"]["modal"] is True and o["f4_con"]["vista"] == "venta" and o["f4_con"]["guardadas"] == 2, o["f4_con"]
    assert o["f4_sin"]["modal"] is False and o["f4_sin"]["vista"] == "venta" and o["f4_sin"]["llamadas"] == [], o["f4_sin"]
    assert o["f4_sin_aviso"] == ["No hay cuentas guardadas en esta caja"]
    rc = o["recuperada"]
    assert (rc["vista"], rc["rapida"], rc["mesas"], rc["lineas"], rc["esperaId"], rc["modal"]) == ("venta", False, True, 1, 1, False), rc
    rg = o["recuperada_guardada"]
    assert (rg["vista"], rg["lineas"], rg["esperaId"]) == ("mesas", 0, None) and "mesas" in rg["llamadas"], rg
    assert o["recuperada_lineas"] == 2
    v = o["vaciada"]
    assert v["vista"] == "mesas" and v["esperaId"] is None and "baja 2" in v["llamadas"] and v["guardadas"] == 1, v
    assert o["sin_cupon"] == [None, None, None, "venta", True], o["sin_cupon"]
    assert o["plano_recuperada"]["rapida"] is False and o["plano_recuperada"]["mesas"] is True, o["plano_recuperada"]
    assert o["plano_guardada"]["vista"] == "mesas" and "mesas" in o["plano_guardada"]["llamadas"], o["plano_guardada"]
    assert o["mesa_recuperada"]["rapida"] is False and o["mesa_recuperada"]["mesas"] is True, o["mesa_recuperada"]
    assert o["mesa"]["vista"] == "mesas" and "mesas" in o["mesa"]["llamadas"], o["mesa"]
    assert o["mostrador"]["vista"] == "venta" and o["mostrador"]["llamadas"] == [] and o["mostrador"]["lineas"] == 0 and o["mostrador_espera"] == 1, o


def test_el_boton_cambia_de_nombre_solo_en_la_venta_rapida():
    t = _js("pages/pos/caja.js")
    assert ('<button class="btn sec" @click="guardarCuenta" :disabled="!lineas.length && !esperaId" data-guardar-cuenta '
            ":title=\"esVentaRapida ? 'Guardar esta venta en espera y empezar otra venta rápida (F4). La encuentra en «Para llevar en espera».' "
            ": 'Guardar la cuenta y volver al plano (F4)'\">{{esVentaRapida ? 'Guardar y nueva venta' : 'Guardar cuenta'}}</button>") in t
    assert t.count("data-guardar-cuenta") == 1
    acciones = _tramo(t, '<div class="pos-acciones" v-if="esRestaurante"', "</div>")      # solo en las acciones de la caja de restaurante
    assert "data-guardar-cuenta" in acciones
    # F4 sigue llamando a guardarCuenta en la venta del restaurante y abre «En espera» en las demás; 4.38: nada con el cobro abierto
    assert ("else if (e.key === 'F4') { e.preventDefault(); if (this.pago || this.cobrando) return; "
            "if (this.esRestaurante && this.vista === 'venta') this.guardarCuenta(); else this.modalEspera = true; }") in t


def test_438_recuperar_queda_como_antes_de_la_437():
    """4.38: la revisión halló que dejar en la venta rápida una cuenta recuperada hacía pasar su cobro por la comanda automática de la
    venta rápida (4.29), después de tomar el total y antes del reclamo: con dos equipos se podía cobrar dos veces o meter en el tiquete un
    plato agregado por otro equipo, y un pedido a domicilio mandaba a cocina «Envío a domicilio». recuperar vuelve a ser el de la 4.36."""
    t = _js("pages/pos/caja.js")
    r = _metodo(t, "recuperar(v) {")
    assert r == ("    recuperar(v) {\n"
                 "      if (this.lineas.length && !confirm('El carrito actual se reemplaza por «' + v.nombre + '». ¿Continuar?')) return;\n"
                 "      if (v.terminal_id && this.cfg && v.terminal_id !== this.cfg.id) return toast('Esa cuenta pertenece a otra caja', 'err');\n"
                 "      if (this.esperaId && this.esperaId !== v.id && !this.lineas.length) this.descartarVacia();\n"
                 "      this.cargarCuenta(v); this.mesaActual = v.mesa_id ? this.mesas.find(m => m.id === v.mesa_id) || null : null; this.modalEspera = false; this.vista = 'venta'; this.idem = uuid();\n"
                 "    }").replace("\n", "\r\n" if "\r\n" in t else "\n")
    assert "enRapida" not in t


def test_438_el_nombre_cuenta_n_no_se_repite(tmp_path):
    """4.38: con «Guardar y nueva venta», encadenar ventas sin nombre es lo normal; el número de «Cuenta N» era cuentas abiertas + 1 y se
    repetía después de cobrar una. Ahora es el mayor entre eso y el mayor N abierto, más 1."""
    t = _js("pages/pos/caja.js")
    linea = _tramo(t, "      const nombre = (this.nombreEspera || '').trim() ||", "\n")
    expr = linea.split("const nombre = ", 1)[1].split("   /*")[0].strip().rstrip(";")
    guion = """
function nombre(espera, nombreEspera) { const self = { espera, nombreEspera }; return (function () { return %s; }).call(self); }
const c = n => ({ nombre: n });
console.log(JSON.stringify({
  vacia: nombre([]),
  una: nombre([c('Cuenta 1')]),
  hueco: nombre([c('Cuenta 2')]),                         // se cobró la 1: antes daba «Cuenta 2» otra vez
  mesas: nombre([c('Mesa 4'), c('Barra 1')]),             // como antes: abiertas + 1
  mezcla: nombre([c('Mesa 4'), c('Cuenta 5'), c('Ana')]),
  con_nombre: nombre([c('Cuenta 1')], '  Juan '),
  raro: nombre([c('Cuenta 3b'), c('cuenta 9'), c(null)]),
}));
""" % expr
    o = _correr(tmp_path, guion)
    assert o == {"vacia": "Cuenta 1", "una": "Cuenta 2", "hueco": "Cuenta 3", "mesas": "Cuenta 3", "mezcla": "Cuenta 6",
                 "con_nombre": "Juan", "raro": "Cuenta 4"}, o


def test_guardar_no_cambia_lo_que_se_guarda():
    t = _js("pages/pos/caja.js")
    g = _metodo(t, "guardarCuenta() {")
    assert "this.ponerEnEspera();" in g and "this.persistirCuenta" not in g          # se guarda igual que antes (ponerEnEspera → persistirCuenta)
    p = _metodo(t, "ponerEnEspera() {")
    assert "const nombre = this.persistirCuenta();" in p


def test_caja_compila_y_no_mezcla_finales_de_linea(tmp_path):
    from tests.test_424_etiquetas import COMPILAR_JS
    node = _nodo()
    b = (JS / "pages/pos/caja.js").read_bytes()
    assert b.count(b"\r\n") in (0, b.count(b"\n"))
    if not node:
        pytest.skip("sin Node.js en este equipo")
    copia = tmp_path / "caja.mjs"
    copia.write_bytes(b)
    r = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, encoding="utf-8", timeout=60)
    assert r.returncode == 0, r.stderr[-2000:]
    shutil.copy(JS / "vendor" / "vue.esm-browser.prod.min.js", tmp_path / "vue.mjs")
    (tmp_path / "compilar.mjs").write_text(COMPILAR_JS, encoding="utf-8")
    (tmp_path / "pages_pos_caja.js").write_bytes(b)
    r = subprocess.run([node, "compilar.mjs", "pages_pos_caja.js"], capture_output=True, text=True, encoding="utf-8", timeout=180, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    o = json.loads(r.stdout)
    assert o["pages_pos_caja.js"]
    for p in o["pages_pos_caja.js"]:
        assert p["errores"] == [] and p["desbalance"] == [], p
