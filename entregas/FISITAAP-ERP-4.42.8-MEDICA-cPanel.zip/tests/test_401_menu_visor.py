# -*- coding: utf-8 -*-
"""4.1: Contactos como submenú (clientes, proveedores, ambos), «Reportes» dentro de cada módulo, estado de resultados con barra
de meses (acumulado o mensual) y visor de documentos dentro del sistema."""
import pathlib
import re

from app import main

JS = pathlib.Path(main.__file__).parent / "static" / "js"


def _leer(p):
    return (JS / p).read_text(encoding="utf-8")


def test_menu_contactos_y_reportes_por_modulo():
    m = _leer("menu.js")
    for tipo in ("Cliente", "Proveedor", "Ambos"):
        assert f"to: '/contactos?tipo={tipo}'" in m
    for mod in ("ingresos", "compras", "contactos", "inventario", "bancos", "contabilidad"):
        assert f"to: '/reportes/de-{mod}'" in m
    assert "{ label: 'Reportes', to: '/rrhh/informes' }" in m


def test_reportes_de_cada_modulo_existen_en_el_catalogo():
    h = _leer("pages/reportes/hub.js")
    assert "export const MODULO_REPORTES" in h and "export function reportesModulo(mod)" in h
    slugs = set(re.findall(r"slug: '([a-z0-9-]+)'", h))
    bloque = h[h.index("export const MODULO_REPORTES"):h.index("export function reportesModulo")]
    usados = {s for linea in bloque.splitlines() if "slugs:" in linea for s in re.findall(r"'([a-z0-9-]+)'", linea.split("slugs:", 1)[1])}
    assert usados and usados <= slugs, usados - slugs     # ningún reporte del menú de un módulo apunta a algo que no existe
    c = _leer("pages/reportes/categoria.js")
    assert "reportesModulo(this.modulo)" in c


def test_contactos_pestana_ambos():
    l = _leer("pages/contactos/lista.js")
    assert "Ambos: 'ambos'" in l and "if (this.tab === 'ambos')" in l and "'params.tipo'(v)" in l


def test_estado_resultados_barra_de_meses():
    r = _leer("pages/reportes/reporte.js")
    assert "erModo: 'acumulado'" in r and "porMes()" in r
    assert 'value="acumulado" v-model="erModo"' in r and 'value="mensual" v-model="erModo"' in r
    assert "'Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Set','Oct','Nov','Dic'" in r
    assert "? 'Mes de ' + mes" in r and "'Acumulado a ' + mes" in r and "'Del ' + fecha(c.desde)" in r
    assert "elegirMes(i + 1)" in r and "mesSel()" in r and "aplicarMes()" in r      # barra de meses en todos los reportes, con rango de fechas
    assert "const SIN_DESDE = ['balance-general'," in r                               # el estado por mes también acepta un rango


def test_visor_de_documentos():
    a = _leer("api.js")
    assert "export async function verDocumento(url, titulo, nombre)" in a
    assert "Abrir aparte" in a and "Descargar" in a and "URL.revokeObjectURL" in a
    assert ".textContent = titulo" in a            # el título nunca se inserta como HTML
    m = re.search(r"const DOC_RE = (/.+/);", a)
    assert m
    patron = m.group(1)[1:-1].replace(r"\/", "/")
    for url in ("/api/comprobantes/12/pdf", "/api/recepcion/5/pdf", "/api/recepcion/5/xml", "/api/comprobantes/12/xml?tipo=respuesta"):
        assert re.match(patron, url), url
    for url in ("/api/reportes/xlsx", "/api/comprobantes", "/api/plan/pago-unico"):
        assert not re.match(patron, url), url
    assert "verDocumento('/api/recepcion/' + x.rid + '/pdf'" in _leer("pages/reportes/reporte.js")


def test_reportes_en_moneda_principal():
    r = _leer("pages/reportes/reporte.js")
    assert "monedaRep: ''" in r and "this.princ = monedas.principal().codigo" in r and 'v-model="monedaSel"' in r
    assert "if (SIN_SELECTOR.has(this.slug)) return this.princ;" in r
    s = _leer("pages/contabilidad/saldos-iniciales.js")
    assert "money(v) { return money(v, monedas.principal().codigo); }" in s


def test_contactos_con_submenu_y_reportes_en_cada_modulo():
    m = _leer("menu.js")
    assert "{ label: 'Lista de clientes', to: '/contactos?tipo=Cliente' }" in m and "to: '/reportes/de-clientes'" in m
    assert "{ label: 'Lista de proveedores', to: '/contactos?tipo=Proveedor' }" in m and "to: '/reportes/de-proveedores'" in m
    assert "to: '/reportes/de-ambos'" in m and "to: '/reportes/de-pos'" in m
    assert m.count("{ label: 'Reportes', to: '/hotel/reportes' }") == 2 and "{ label: 'Reportes', to: '/tike/reportes' }" in m
    h = _leer("pages/reportes/hub.js")
    for mod in ("clientes", "proveedores", "ambos", "pos"):
        assert f"  {mod}: {{ nombre:" in h
    a = _leer("app.js")
    assert "function puntajeRuta(to, path, qs)" in a and ":activo=\"toActivo\"" in a and "this.qs = qs || ''" in a


def test_estados_por_moneda_y_documentos_importados():
    r = _leer("pages/reportes/reporte.js")
    assert "export function asientosEnMoneda(as, mon, princ, desde, hasta)" in r and "ASIENTOS_MON.has(this.slug)" in r
    assert "debito: +l.debito_doc || 0" in r                       # montos originales del documento, sin redondeos de otra moneda
    au = _leer("pages/contabilidad/automaticos.js")
    assert "function dual(gen, moneda)" in au and "moneda_doc: moneda" in au and "_forzada = moneda;" in au
    assert "param.contabilizar_importados === true && !periodoCerrado(" in au
    assert "contabilizar_importados: false" in _leer("pages/contabilidad/parametros.js")
    assert 'v-model="p.contabilizar_importados"' in _leer("pages/configuracion/seccion.js")
