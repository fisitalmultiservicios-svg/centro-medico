# -*- coding: utf-8 -*-
"""3.91: modo mixto de Ventas en línea: página pública + catálogo para revendedoras. El público ve el catálogo y compra a precio
normal (sin crédito); la revendedora entra con su código personal y ve los precios de su lista; su teléfono no entra sin código."""
from tests.test_exoneraciones import api  # noqa: F401
from tests.test_pedidos import _eid, _productos, _publicar
from tests.test_379_mayorista import _registros


def test_publico_y_revendedoras_a_la_vez(api):  # noqa: F811
    c = api; _eid()
    a, b, _oculto, _agotado = _productos(c)
    cli = c.post("/api/clientes", json={"nombre": "Revendedora Mixta", "tipo": "Cliente", "tipo_id": "01", "numero_id": "303330391", "celular": 87003911, "limite_credito": 20000}).json()
    _registros(c, listas_precios=[{"id": 1, "nombre": "General", "principal": True, "tipo": "Valor"}, {"id": 2, "nombre": "Mayorista", "tipo": "Valor", "activa": True}],
               items_extra={str(a["id"]): {"listas": [{"lista_id": 2, "valor": 3000}]}}, contactos_extra={str(cli["id"]): {"lista_precios_id": 2}},
               pos_config={"terminales": [{"id": 1, "nombre": "Caja QA", "modo": "restaurante", "mesas": []}]})
    r = _publicar(c, slug="mixto-391-qa", activo=True, mayorista=True, mayorista_codigo="perfu391", mayorista_credito=True, mayorista_mixto=True)
    assert r.status_code == 200 and r.json()["mayorista_mixto"] is True, r.text
    # el público ve el catálogo con el precio normal, y las fotos sin firma
    d = c.get("/api/publico/mixto-391-qa").json()
    assert not d.get("privado") and d["mayorista"] is False and d["mayorista_mixto"] is True and d["items"]
    pa = next(i for i in d["items"] if i["id"] == a["id"]); assert pa["precio"] != 3390.0
    # el público pide sin cuenta a precio normal; a crédito no
    r = c.post("/api/publico/mixto-391-qa/pedido", json={"nombre": "Cliente Normal", "telefono": "87009391", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 2}]})
    assert r.status_code == 200 and r.json()["a_credito"] is False and r.json()["lineas"][0]["precio_unitario"] != 3000.0, r.text
    r = c.post("/api/publico/mixto-391-qa/pedido", json={"nombre": "Cliente Normal", "telefono": "87009391", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 2}], "pago": "credito"})
    assert r.status_code in (400, 401, 403), r.text
    # un teléfono que no es de revendedora crea su acceso normal, sin código
    r = c.post("/api/publico/mixto-391-qa/cliente/acceso", json={"telefono": "87009392", "pin": "1234", "nombre": "Cliente Con Cuenta"})
    assert r.status_code == 200 and not r.json().get("contacto"), r.text
    # el teléfono de la revendedora no entra sin su código personal
    assert c.post("/api/publico/mixto-391-qa/cliente/acceso", json={"telefono": "87003911", "pin": "1234", "nombre": "Intrusa"}).status_code == 403
    personal = next(x for x in c.get("/api/pedidos/revendedoras").json() if x["contacto_id"] == cli["id"])["codigo"]
    r = c.post("/api/publico/mixto-391-qa/cliente/acceso", json={"telefono": "87003911", "pin": "1234", "codigo": personal}); assert r.status_code == 200, r.text
    h = {"X-Cliente": r.json()["token"]}
    d = c.get("/api/publico/mixto-391-qa", headers=h).json()
    assert d["mayorista"] is True and d["cliente"]["lista"] == "Mayorista"
    assert next(i for i in d["items"] if i["id"] == a["id"])["precio"] == 3390.0       # 3.000 de su lista + 13 %
    r = c.post("/api/publico/mixto-391-qa/pedido", json={"nombre": "Ana", "telefono": "87003911", "tipo": "recoger", "lineas": [{"producto_id": a["id"], "cantidad": 1}], "pago": "credito"}, headers=h)
    assert r.status_code == 200 and r.json()["a_credito"] is True and r.json()["lineas"][0]["precio_unitario"] == 3000.0, r.text
    # la pantalla de Ventas en línea trae el interruptor
    assert "n.mayorista_mixto" in c.get("/js/fis/pages/publicar.js").text and "d.mayorista_mixto" in c.get("/js/tienda.js").text
