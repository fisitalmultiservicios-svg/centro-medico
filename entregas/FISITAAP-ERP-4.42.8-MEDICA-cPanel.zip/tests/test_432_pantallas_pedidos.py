# -*- coding: utf-8 -*-
"""4.32, bloque B7 (pantallas), parte «pedidos»: fis/pages/pedidos.js y fis/pages/configuracion.js (plan reingenieria_432 §4.3, §4.6 a §4.8).

- Pedidos: con atiende > 0 se oculta «Aceptar» y sale la insignia; «Esperando a…»; «Aceptar y atenderlo aquí»; el rescate del administrador con su
  confirmación; en el programa con `pedidos_programa` la franja, aceptar sin imprimir (la estación saca la comanda), los textos «Esto se hace en
  la página web.» y los mensajes del servidor tal como llegan.
- Configuración: «Los pedidos en línea los atiende» con su ruta propia (nunca dentro del guardado general) y el aviso para elegir.
- Compatibilidad: sin la bandera, todo igual que la 4.31 (ninguna consulta ni texto nuevo).
Nada va a la red ni a un servidor: el servidor es una función de la prueba (patrón de test_431_estacion_pantallas.py)."""
import re

from tests.test_425_ultimos_pantallas import _js, _node
from tests.test_431_estacion_pantallas import BASE, FALSOS_PED, _pedidos_js

PED = _js("fis/pages/pedidos.js")
CONF = _js("fis/pages/configuracion.js")

RESCATE = "La computadora «Caja 2» no se conecta desde hace 3 horas. Si la atiende aquí y allá ya la cobraron sin conexión, se cobraría dos veces. ¿Atenderla aquí de todos modos?"

# ---------------------------------------------------------------------------------------------------------------- textos y reglas de escritura
TEXTOS_PED = [
    "Aquí ve los pedidos de los últimos días. Se aceptan y se cobran en este programa. Para verificar un SINPE, asignar una entrega o ver pedidos anteriores, use la página web.",
    "Esto se hace en la página web.", "Confirmando con la página web…",
    "aceptado: ya está en la caja y su comanda sale sola en unos segundos.",
    "Lo atiende «{{nombreAtiende(f.p)}}»", "Esperando a «{{nombreAtiende(f.p)}}»: el pedido todavía no entra a esa caja.",
    "Aceptar y atenderlo aquí", "Este pedido lo atiende «{{nombreAtiende(f.p)}}»: cóbrelo allá.",
]
TEXTOS_CONF = [
    "Los pedidos en línea los atiende", "La página web", "El programa de «{{o.nombre}}»",
    "Los pedidos aceptados pasan a la caja de esa computadora: su comanda sale allá y se cobran allá. En la página web se siguen viendo y aceptando.",
    "Esto se hace en la página web.",
]


def test_textos_exactos_y_sin_palabras_tecnicas():
    for x in TEXTOS_PED:
        assert x in PED, x
    for x in TEXTOS_CONF:
        assert x in CONF, x
    assert "Sin conexión con la página web" not in PED and "Pedido #" in PED    # los de conexión y cobros los manda el servidor: se muestran como llegan
    for txt in (PED, CONF):
        nuevo = "\n".join(l for l in txt.splitlines() if "4.32" in l or "data-" in l or "enProg" in l)
        assert not re.search(r"sincroniz|token|\bAPI\b|servidor", re.sub(r"//.*", "", nuevo.replace("/api/", ""))), nuevo[:200]
        assert "v-html" not in txt
        assert not re.search(r'@(click|submit\.prevent|change)="if\b', txt)
        assert not re.search(r"//\s*$", txt, re.M)


def test_ruta_propia_y_nunca_en_el_guardado_general():
    assert "api('/api/pedidos/negocio/atiende', { method: 'PUT', body: { terminal:" in CONF
    g = CONF.split("async guardar() {")[1].split("async cambiarAvisos")[0]
    assert "atiende" not in g.replace("sesion.recargarNegocio", "")                    # el guardado general no manda ni lee quién atiende
    assert "this.n = await guardarNegocio(n," in g
    assert "/api/pedidos/negocio/atiende" not in PED and "/atender-aqui" in PED


# ---------------------------------------------------------------------------------------------------------------- pedidos.js
def _falsos():
    f = dict(FALSOS_PED)
    f["fis/pages/pedidos.js"] = _pedidos_js()
    f["pages/pos/_agente_real.js"] = _js("pages/pos/_agente.js")
    return f


MONTAR_PED = r"""
Q.sesionFis = {};
const P = (await import('./js/fis/pages/pedidos.js')).default;
const montar = () => { const vm = Object.assign({ params: { query: {} } }, P.data.call({ params: { query: {} } })); for (const [k, f] of Object.entries(P.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true }); for (const [k, f] of Object.entries(P.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f; return vm; };
const sesionPara = (info, extra) => { for (const k of Object.keys(Q.sesionFis)) delete Q.sesionFis[k]; Object.assign(Q.sesionFis, { menu: true, negocio: { terminal_id: 1, activo: true }, empresaInfo: info, fisica: true, tieneModulo: () => false, sucursalActual: null, nombreUsuario: 'Ana QA', puede: () => true }, extra || {}); };
"""


def test_pedidos_banderas_atiende_y_programa(tmp_path):
    r = _node(tmp_path, BASE + MONTAR_PED + r"""
const fila = (p, estado) => ({ origen: 'web', id: p.id, estado: estado || p.estado, p });
const out = {};
sesionPara({});                                                                    // 4.31: sin bandera
let vm = montar();
out.sinBandera = [vm.enProg, vm.enWeb, vm.conProgramaElegido, vm.esperandoCaja({ id: 1, estado: 'confirmado' }), vm.lejos({ id: 1 }), vm.soloWebFila(fila({ id: 1, estado: 'confirmado', pago_medio: 'sinpe' }))];
sesionPara({ es_local: false }, { negocio: { activo: true, atiende_terminal: 5 } });   // la página web con un programa elegido
vm = montar();
const p = { id: 2, estado: 'confirmado', atiende: 5, atiende_nombre: 'Caja 2' };
out.web = [vm.enProg, vm.enWeb, vm.conProgramaElegido, vm.puedeRescatar, vm.esperandoCaja(p), vm.esperandoCaja({ ...p, estado: 'en_preparacion' }), vm.esperandoCaja({ ...p, documento_id: 9 }), vm.lejos(p), vm.nombreAtiende(p), vm.nombreAtiende({ atiende: 5 })];
sesionPara({ es_local: true, datos_v2: true });                                    // el programa sin pedidos_programa: como la 4.31
vm = montar(); out.progSin = [vm.enProg, vm.enWeb, vm.esperandoCaja(p), vm.lejos(p)];
sesionPara({ es_local: true, datos_v2: true, pedidos_programa: true }, { fisica: true, tieneModulo: m => m === 'entregas' });
vm = montar();
out.prog = [vm.enProg, vm.enWeb, vm.esperandoCaja(p), vm.lejos(p), vm.soloWebFila(fila({ id: 3, estado: 'confirmado', pago_medio: 'sinpe', pago_estado: 'sinpe_pendiente', tipo: 'recoger' })),
  vm.soloWebFila(fila({ id: 4, estado: 'confirmado', tipo: 'domicilio', pago_estado: 'aprobado' })), vm.soloWebFila(fila({ id: 5, estado: 'confirmado', tipo: 'recoger', pago_estado: 'aprobado' })), vm.soloWebFila(fila({ id: 6, estado: 'cancelado', pago_medio: 'sinpe' }))];
sesionPara({ es_local: false }, { puede: () => false }); out.sinPermiso = montar().puedeRescatar;
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_comandas.js",), falsos=_falsos())
    assert r["sinBandera"] == [False, True, False, False, False, False], r
    assert r["web"] == [False, True, True, True, True, False, False, True, "Caja 2", "otra computadora"], r
    assert r["progSin"] == [False, False, False, False], r
    assert r["prog"] == [True, False, False, False, True, True, False, False], r
    assert r["sinPermiso"] is False, r


def test_pedidos_aceptar_en_el_programa_no_imprime_y_muestra_lo_que_llega(tmp_path):
    r = _node(tmp_path, BASE + MONTAR_PED + r"""
const out = {};
Q.llamadas = [];
let modo = 'bien';
Q.api = async (url, opt) => {
  Q.llamadas.push((opt && opt.method || 'GET') + ' ' + url + (opt && opt.body ? ' ' + JSON.stringify(opt.body) : ''));
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) {
    if (modo === 'sinRed') throw Object.assign(new Error('Sin conexión con la página web: el pedido no se aceptó. Revise el internet o acéptelo desde la página web.'), { status: 409 });
    if (modo === 'espera') throw Object.assign(new Error('Confirmando con la página web…'), { status: 409 });
    return { id: 11, numero: 7, estado: 'confirmado', atiende: 3, atiende_nombre: 'Caja 1', cuenta_espera_id: 55, mensaje: modo === 'sinMensaje' ? undefined : 'Pedido #7 aceptado: ya está en la caja y su comanda sale sola en unos segundos.' };
  }
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  if (url.startsWith('/api/pos/comanda/pendientes?pedido_id=')) return { ahora: new Date().toISOString(), copias: [{ pedido_id: 11, estado: 'cerrada', lineas: [] }] };
  if (url.startsWith('/api/registros/') || url === '/api/pedidos/resumen') return { datos: [], comandas_pendientes: 0 };
  if (url.startsWith('/api/productos')) return [];
  throw new Error('llamada inesperada ' + url);
};
sesionPara({ es_local: true, datos_v2: true, pedidos_programa: true });
let vm = montar();
const aceptar = async m => { modo = m; limpiar(); const p = { id: 11, numero: 7, estado: 'nuevo' }; const ok = await vm.aceptar(p); return { ok, toasts: Q.toasts.slice(), llamadas: Q.llamadas.slice(), quedo: Object.keys(vm.aceptando).length }; };
out.bien = await aceptar('bien');
out.sinMensaje = await aceptar('sinMensaje');
out.sinRed = await aceptar('sinRed');
out.espera = await aceptar('espera');
// la misma pantalla con una sola pulsación a la vez
modo = 'bien'; limpiar(); const p2 = { id: 12, numero: 8, estado: 'nuevo' }; const a = vm.aceptar(p2), b = vm.aceptar(p2); out.doble = [await a, await b];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_comandas.js",), falsos=_falsos())
    ok = "Pedido #7 aceptado: ya está en la caja y su comanda sale sola en unos segundos."
    b = r["bien"]
    assert b["ok"] is True and b["toasts"] == [[ok, "ok"]] and b["quedo"] == 0, r
    assert b["llamadas"][0] == 'PUT /api/pedidos/11/estado {"estado":"confirmado"}', r                    # sin reclama: la pantalla no reclama ni imprime la comanda
    assert "GET /api/pos/comanda/pendientes?pedido_id=11" in b["llamadas"], r
    assert r["sinMensaje"]["toasts"] == [[ok, "ok"]], r                                                    # sin el campo mensaje el texto sale igual
    assert r["sinRed"]["ok"] is False and r["sinRed"]["toasts"] == [["Sin conexión con la página web: el pedido no se aceptó. Revise el internet o acéptelo desde la página web.", "err"]], r
    assert r["espera"]["toasts"] == [["Confirmando con la página web…", "err"]] and r["espera"]["quedo"] == 0, r
    assert r["doble"] == [True, False], r


def test_pedidos_sin_bandera_aceptar_es_el_de_la_431_y_aqui_lo_manda(tmp_path):
    r = _node(tmp_path, BASE + MONTAR_PED + r"""
const out = {};
Q.api = async (url, opt) => {
  Q.llamadas.push((opt && opt.method || 'GET') + ' ' + url + (opt && opt.body ? ' ' + JSON.stringify(opt.body) : ''));
  if (url.startsWith('/api/pedidos/') && url.endsWith('/estado')) return { id: 21, numero: 9, estado: 'en_preparacion', cuenta_espera_id: 5 };
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  if (url === '/api/registros/pos_config') return { datos: Q.cfg };
  if (url === '/api/registros/pos_impresoras') return { datos: [] };
  if (url === '/api/registros/categorias' || url === '/api/registros/items_extra') return { datos: [] };
  if (url.startsWith('/api/productos')) return [];
  if (url.startsWith('/api/pos/comanda/pendientes')) return { copias: [], ahora: new Date().toISOString() };
  throw new Error('llamada inesperada ' + url);
};
sesionPara({ es_local: false }, { negocio: { terminal_id: 1, activo: true, atiende_terminal: 4 } });
const vm = montar();
limpiar(); await vm.aceptar({ id: 21, numero: 9, estado: 'nuevo' }); out.normal = Q.llamadas.filter(x => x.startsWith('PUT'));
limpiar(); await vm.aceptarComo({ id: 21, numero: 9, estado: 'nuevo' }, { aqui: true }); out.aqui = Q.llamadas.filter(x => x.startsWith('PUT'));
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_comandas.js",), falsos=_falsos())
    assert r["normal"] == ['PUT /api/pedidos/21/estado {"estado":"confirmado","reclama":true}'], r
    assert r["aqui"] == ['PUT /api/pedidos/21/estado {"estado":"confirmado","reclama":true,"aqui":true}'], r


def test_pedidos_rescate_pide_confirmar_y_solo_entonces_atiende_aqui(tmp_path):
    r = _node(tmp_path, BASE + MONTAR_PED + r"""
const out = {};
let respuesta = 'confirmar';
Q.api = async (url, opt) => {
  Q.llamadas.push((opt && opt.method || 'GET') + ' ' + url + (opt && opt.body ? ' ' + JSON.stringify(opt.body) : ''));
  if (url === '/api/pedidos/31/atender-aqui') {
    if (!opt.body.confirmo) {
      if (respuesta === 'espera') throw Object.assign(new Error('La computadora «Caja 2» se conectó hace 1 minuto: el pedido sigue en su caja. Si pasan 15 minutos sin que se conecte, podrá atenderlo aquí.'), { status: 409, detail: 'texto' });
      if (respuesta === 'cobrado') throw Object.assign(new Error('El pedido ya tiene comprobante: anule esa venta desde la caja o cobre lo que falta'), { status: 409, detail: 'texto' });
      throw Object.assign(new Error('__R__'), { status: 409, detail: { codigo: 'confirmar', mensaje: '__R__' } });
    }
    return { id: 31, numero: 12, estado: 'confirmado', atiende: 0, cuenta_espera_id: 70 };
  }
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  if (url === '/api/registros/pos_config') return { datos: Q.cfg };
  if (url === '/api/registros/pos_impresoras') return { datos: [] };
  if (url === '/api/registros/categorias' || url === '/api/registros/items_extra') return { datos: [] };
  if (url.startsWith('/api/productos')) return [];
  if (url.startsWith('/api/pos/comanda/pendientes')) return { copias: [], ahora: new Date().toISOString() };
  throw new Error('llamada inesperada ' + url);
};
sesionPara({ es_local: false }, { negocio: { terminal_id: 1, activo: true } });
const vm = montar();
const caso = async (resp, responder) => { respuesta = resp; Q.responder = responder; limpiar(); const p = { id: 31, numero: 12, estado: 'confirmado', atiende: 5, atiende_nombre: 'Caja 2' }; const ok = await vm.atenderAqui(p); return { ok, preguntas: Q.preguntas.slice(), toasts: Q.toasts.map(x => x[0]), posts: Q.llamadas.filter(x => x.startsWith('POST')), libre: !vm.atendiendo[31] }; };
out.no = await caso('confirmar', false);
out.si = await caso('confirmar', true);
out.espera = await caso('espera', true);
out.cobrado = await caso('cobrado', true);
console.log(JSON.stringify(out));
process.exit(0);
""".replace("__R__", RESCATE), archivos=("pages/pos/_comandas.js",), falsos=_falsos())
    no = r["no"]
    assert no["ok"] is False and no["preguntas"] == [RESCATE] and no["posts"] == ['POST /api/pedidos/31/atender-aqui {"confirmo":false}'] and no["libre"], r
    si = r["si"]
    assert si["preguntas"] == [RESCATE] and si["posts"] == ['POST /api/pedidos/31/atender-aqui {"confirmo":false}', 'POST /api/pedidos/31/atender-aqui {"confirmo":true,"reclama":true}'], r
    for k in ("espera", "cobrado"):                                                                         # el 409 del servidor se muestra tal cual y no se pregunta nada
        assert r[k]["ok"] is False and r[k]["preguntas"] == [] and len(r[k]["toasts"]) == 1 and len(r[k]["posts"]) == 1 and r[k]["libre"], r
    assert r["espera"]["toasts"][0].startswith("La computadora «Caja 2» se conectó hace 1 minuto"), r


def test_pedidos_plantilla_oculta_aceptar_con_atiende_y_ofrece_lo_nuevo():
    t = PED.split("template: `")[1]
    assert "<form v-if=\"!(+f.p.atiende > 0) && (f.estado === 'nuevo'" in t                    # «Aceptar» oculto con atiende > 0
    assert "<form v-if=\"conProgramaElegido && f.estado === 'nuevo'\" @submit.prevent=\"aceptarComo(f.p, { aqui: true })\">" in t
    assert "v-if=\"puedeRescatar && lejos(f.p) &&" in t and "@click=\"atenderAqui(f.p)\"" in t
    assert '<small v-if="enProg && aceptando[f.id]"' in t and 'data-confirmando' in t                    # mientras espera a la página web
    assert "<section v-if=\"enProg\" class=\"card admin-card\" data-franja-programa>" in t
    assert "<template v-if=\"!enProg && f.p.pago_medio === 'sinpe'" in t                          # verificar SINPE no se ofrece en el programa
    assert "v-else-if=\"!enProg && ['confirmado','en_preparacion','listo']" in t                  # Asignar a Express tampoco
    assert "sesion.negocio.activo && !enProg\" class=\"btn btn-light\" type=\"button\" :disabled=\"pausando\"" in t   # configurar la tienda (pausar) tampoco
    # sin la bandera nada de esto se ve: todo cuelga de enProg, de enWeb o de un atiende > 0 que la 4.31 no manda
    for m in re.findall(r'data-(franja-programa|solo-web|atiende|espera|rescate|aceptar-aqui|cobrar-alla)', t):
        assert m


# ---------------------------------------------------------------------------------------------------------------- configuracion.js
FALSOS_CONF = {
    "api.js": "export const api = (u, o) => globalThis.Q.api(u, o), toast = (m, t) => globalThis.Q.toasts.push([m, t || '']), red = { enLinea: true };\n",
    "avisos.js": "export const avisosActivos = () => false, permisoAvisos = () => 'default', activarAvisos = async () => true, desactivarAvisos = () => {};\n",
    "fis/sesion.js": "export const sesion = globalThis.Q.sesionFis;\n",
    "pages/fisitaap/_negocio.js": "export const cargarNegocio = async () => globalThis.Q.negocio(), DIAS = ['L','M','X','J','V','S','D'];\nexport const guardarNegocio = async (n, extra) => { globalThis.Q.llamadas.push('GUARDAR_GENERAL ' + JSON.stringify(Object.keys(n).filter(k => k.startsWith('atiende')))); return n; };\n",
}


def _falsos_conf():
    t = CONF.replace("from '/js/api.js'", "from '../../api.js'").replace("from '/js/pages/fisitaap/_negocio.js'", "from '../../pages/fisitaap/_negocio.js'").replace("from '/js/avisos.js'", "from '../../avisos.js'")
    assert "'/js/" not in t
    return {**FALSOS_CONF, "fis/pages/configuracion.js": t}


def test_configuracion_los_pedidos_en_linea_los_atiende(tmp_path):
    r = _node(tmp_path, BASE + r"""
Q.sesionFis = {};
const C = (await import('./js/fis/pages/configuracion.js')).default;
const montar = () => { const vm = Object.assign({ params: {} }, C.data.call({})); for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => (f.get || f).call(vm), set: v => f.set && f.set.call(vm, v), configurable: true }); for (const [k, f] of Object.entries(C.methods)) vm[k] = typeof f === 'function' ? f.bind(vm) : f; return vm; };
const out = {};
const neg = (extra) => () => ({ nombre: 'X', horarios: [], redes: {}, acepta_domicilio: true, atiende_terminal: null, atiende_nombre: '', atiende_opciones: [], ...extra });
const sesionPara = info => { for (const k of Object.keys(Q.sesionFis)) delete Q.sesionFis[k]; Object.assign(Q.sesionFis, { empresaInfo: info, empresa_id: 7, puede: () => true, nombreNegocio: 'N', empresa: {}, negocio: { atiende_terminal: null }, recargarNegocio: async () => {} }); };
Q.api = async (url, opt) => {
  Q.llamadas.push((opt && opt.method || 'GET') + ' ' + url + (opt && opt.body ? ' ' + JSON.stringify(opt.body) : ''));
  if (url === '/api/fisitaap/ajustes') return { metodos_pago: ['Efectivo'] };
  if (url === '/api/registros/pos_config') return { datos: { terminales: [] } };
  if (url === '/api/pedidos/negocio/atiende') { if (Q.falla) throw new Error('Esa computadora no está conectada a la empresa: elija otra o la página web'); return opt.body.terminal ? { atiende_terminal: opt.body.terminal, atiende_nombre: 'Caja 2' } : { atiende_terminal: null, atiende_nombre: '' }; }
  throw new Error('llamada inesperada ' + url);
};
const montado = async (info, n) => { sesionPara(info); Q.negocio = neg(n); limpiar(); const vm = montar(); await vm.cargar(); return vm; };
// 4.31: sin computadoras conectadas ni bandera: ni la opción ni el aviso ni el texto
let vm = await montado({ es_local: false }, {}); out.nada = [vm.mostrarAtiende, vm.avisoAtiende, vm.enProg];
vm = await montado({ es_local: true, datos_v2: true }, {}); out.progSin = [vm.mostrarAtiende, vm.enProg];
// la página web con un programa conectado y sin elegir: se ve la opción y el aviso
vm = await montado({ es_local: false }, { atiende_opciones: [{ terminal: 3, nombre: 'Caja 1' }, { terminal: 5, nombre: 'Caja 2' }] });
out.aviso = [vm.mostrarAtiende, vm.avisoAtiende, vm.atiende];
limpiar(); await vm.cambiarAtiende('5'); out.elegir = { llamadas: Q.llamadas.slice(), toasts: Q.toasts.slice(), atiende: vm.atiende, n: vm.n.atiende_terminal, ses: Q.sesionFis.negocio.atiende_terminal, aviso: vm.avisoAtiende };
limpiar(); await vm.guardar(); out.guardado = Q.llamadas.filter(x => x.includes('negocio/atiende')).length; out.guardadoGeneral = Q.llamadas.filter(x => x.startsWith('GUARDAR_GENERAL'));
limpiar(); await vm.cambiarAtiende(''); out.web = { llamadas: Q.llamadas.slice(), atiende: vm.atiende, ses: Q.sesionFis.negocio.atiende_terminal };
Q.falla = true; limpiar(); await vm.cambiarAtiende('3'); out.error = { toasts: Q.toasts.slice(), atiende: vm.atiende }; Q.falla = false;
// ya elegido antes: el aviso no vuelve
vm = await montado({ es_local: false }, { atiende_terminal: 5, atiende_nombre: 'Caja 2', atiende_opciones: [{ terminal: 5, nombre: 'Caja 2' }] }); out.elegido = [vm.mostrarAtiende, vm.avisoAtiende, vm.atiende];
// el programa con pedidos_programa: solo el texto
vm = await montado({ es_local: true, datos_v2: true, pedidos_programa: true }, {}); out.prog = [vm.enProg, vm.mostrarAtiende];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=(), falsos=_falsos_conf())
    assert r["nada"] == [False, False, False] and r["progSin"] == [False, False], r
    assert r["aviso"] == [True, True, ""], r
    e = r["elegir"]
    assert e["llamadas"] == ['PUT /api/pedidos/negocio/atiende {"terminal":5}'] and e["toasts"] == [["Datos guardados.", "ok"]], r
    assert e["atiende"] == 5 and e["n"] == 5 and e["ses"] == 5 and e["aviso"] is False, r
    assert r["guardado"] == 0 and r["guardadoGeneral"] == ["GUARDAR_GENERAL [\"atiende_terminal\",\"atiende_nombre\",\"atiende_opciones\"]"], r   # el guardado general nunca llama a la ruta propia
    assert r["web"] == {"llamadas": ['PUT /api/pedidos/negocio/atiende {"terminal":null}'], "atiende": "", "ses": None}, r
    assert r["error"] == {"toasts": [["Esa computadora no está conectada a la empresa: elija otra o la página web", "err"]], "atiende": ""}, r
    assert r["elegido"] == [True, False, 5], r
    assert r["prog"] == [True, False], r


def test_pedidos_cancelar_en_el_programa_muestra_el_texto_que_llega_y_en_la_web_el_de_siempre(tmp_path):
    r = _node(tmp_path, BASE + MONTAR_PED + r"""
const out = {};
let modo = 'pago';
Q.api = async (url, opt) => {
  if (url.endsWith('/estado')) {
    if (modo === 'cobros') throw Object.assign(new Error('Este pedido ya tiene cobros en esta caja: anule la venta antes de cancelarlo.'), { status: 409 });
    return { id: 41, numero: 5, estado: 'cancelado', mensaje: modo === 'pago' ? 'Cancelado. El pago en línea se devuelve desde la página web o desde su cuenta de Tilopay.' : undefined };
  }
  if (url.startsWith('/api/pedidos?')) return [];
  if (url === '/api/registros/pos_espera') return { datos: [] };
  throw new Error('llamada inesperada ' + url);
};
const cancelar = async (info, m) => { modo = m; sesionPara(info); const vm = montar(); limpiar(); const ok = await vm.estadoWeb({ id: 41, estado: 'confirmado' }, 'cancelado', 'Cliente no contesta'); return [ok, Q.toasts.slice()]; };
out.prog = await cancelar({ es_local: true, datos_v2: true, pedidos_programa: true }, 'pago');
out.progSinMensaje = await cancelar({ es_local: true, datos_v2: true, pedidos_programa: true }, 'normal');
out.cobros = await cancelar({ es_local: true, datos_v2: true, pedidos_programa: true }, 'cobros');
out.web = await cancelar({ es_local: false }, 'pago');
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("pages/pos/_comandas.js",), falsos=_falsos())
    assert r["prog"] == [True, [["Cancelado. El pago en línea se devuelve desde la página web o desde su cuenta de Tilopay.", "ok"]]], r
    assert r["progSinMensaje"] == [True, [["Pedido actualizado.", "ok"]]], r
    assert r["cobros"] == [False, [["Este pedido ya tiene cobros en esta caja: anule la venta antes de cancelarlo.", "err"]]], r
    assert r["web"] == [True, [["Pedido actualizado.", "ok"]]], r                         # la página web no cambia: la 4.31
