# -*- coding: utf-8 -*-
"""4.25 (X2, lado nube): el programa local valida en la web el ingreso de cada persona con su cuenta de la web.

Rutas de la nube para el token de una instalación (se reconoce sin pasar por contexto()): POST /api/sinc/ingreso, POST
/api/sinc/ingreso/dos-pasos, POST /api/sinc/usuario y POST /api/sinc/usuarios. Contestan siempre 200 con el sobre fijo
{servicio: «fisitaap-ingreso», ingreso, motivo, mensaje, …}, salvo la señal explícita de una instalación revocada. Los topes son por
instalación (no por conexión de internet) y quien no es de la empresa del token recibe lo mismo que una contraseña mala.

Aquí se llaman las rutas directo con un token de instalación real (canje de un código, como en tests/test_425_xml_lote.py)."""
import logging
import pathlib
import time

import pytest
from sqlmodel import Session, select

from app import auth, sinc
from app.db import Auditoria, engine, engine_empresa
from test_49_local_sinc import NUBE, H, PW, _admin_empresa, _bloquear_en_nube, _modo_local, _soltar_limite_vinculacion, _vincular, c

CABECERA = {sinc.CABECERA_INGRESO: str(sinc.PROTOCOLO_INGRESO)}
_SUPERADMINES: list = []


@pytest.fixture(autouse=True)
def _sin_superadmin_al_final():
    """test_api.py exige que al empezar no exista ningún administrador del sistema: los que crea este archivo se quitan al terminar."""
    yield
    with Session(engine) as sc:
        for correo in _SUPERADMINES:
            u = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            if u:
                for m in sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                    sc.delete(m)
                sc.delete(u)
        sc.commit()
    _SUPERADMINES.clear()


def _canje(ta: str, nombre: str = "Caja") -> tuple[str, int]:
    _soltar_limite_vinculacion()
    codigo = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": nombre}).json()["codigo"]
    j = c.post("/api/sinc/canje", json={"codigo": codigo, "nombre": nombre}).json()
    return j["token"], j["terminal"]


def _persona(eid, nombre: str, rol: str = "Cajero", pw: str = PW, **campos) -> tuple[int, str]:
    correo = f"{nombre}@example.test"
    if campos.get("es_superadmin"):
        _SUPERADMINES.append(correo)
    with Session(engine) as sc:
        u = auth.Usuario(correo=correo, nombre=nombre, password_hash=auth.hash_password(pw), terminos_version=auth.TERMINOS_VERSION, **campos)
        sc.add(u); sc.commit(); sc.refresh(u)
        if eid:
            sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol=rol)); sc.commit()
        return u.id, correo


def _usuario(uid: int) -> auth.Usuario:
    with Session(engine) as sc:
        return sc.get(auth.Usuario, uid)


def _limpiar_intentos() -> None:
    with Session(engine) as sc:
        for x in sc.exec(select(auth.IntentoIp)).all():
            sc.delete(x)
        sc.commit()


def _ingreso(tok: str, correo: str, pw: str = PW) -> dict:
    r = c.post("/api/sinc/ingreso", headers=H(tok), json={"correo": correo, "password": pw})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["servicio"] == "fisitaap-ingreso"
    return j


def _dos_pasos(tok: str, token: str, codigo: str) -> dict:
    r = c.post("/api/sinc/ingreso/dos-pasos", headers=H(tok), json={"token": token, "codigo": codigo})
    assert r.status_code == 200, r.text
    return r.json()


def _empresa_sola(sufijo: str, cedula: str) -> int:
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "Ingreso425 QA" + sufijo, f"ingreso425{sufijo}@example.test", cedula)
        sc.commit(); sc.refresh(e)
        return e.id


# ------------------------------------------------------------------------------------------------------------------------------
def test_ingreso_bueno_devuelve_la_ficha_y_anota_la_instalacion():
    eid, ta = _admin_empresa("-i1", "3101425101")
    tok, terminal = _canje(ta, "Caja 1")
    uid, correo = _persona(eid, "cajero.i1", pin_hash=auth.hash_password("4826"))
    with Session(engine) as sc:
        sesiones_antes = len(sc.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid)).all())
    j = _ingreso(tok, correo)
    assert j["ingreso"] == "ok" and j["motivo"] is None and j["empresa_bloqueada"] is False, j
    f = j["usuario"]
    u = _usuario(uid)
    assert f["correo"] == correo and f["password_hash"] == u.password_hash and f["pin_hash"] == u.pin_hash   # ya puede guardarse ahí
    assert f["mfa"] == "" and f["mfa_entrar"] is False and f["temporal"] is False and f["rol"] == "Cajero" and "mfa_rrhh" in f
    assert "mfa_secret" not in f and "mfa_respaldo" not in f
    assert u.ultimo_acceso is not None
    with Session(engine) as sc:
        a = sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == "login_programa")).all()
        assert a and a[-1].detalle == f"Programa local «Caja 1» (terminal {terminal})" and a[-1].empresa_id == eid
        t = sc.exec(select(auth.TokenApi).where(auth.TokenApi.prefijo == tok[:12])).first()
        assert sc.exec(select(auth.IngresoPrograma).where(auth.IngresoPrograma.token_id == t.id, auth.IngresoPrograma.usuario_id == uid)).first()
        # sin sesión en la web
        assert len(sc.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid)).all()) == sesiones_antes
    # un segundo ingreso no duplica la fila de la instalación
    assert _ingreso(tok, correo)["ingreso"] == "ok"
    with Session(engine) as sc:
        assert len(sc.exec(select(auth.IngresoPrograma).where(auth.IngresoPrograma.usuario_id == uid)).all()) == 1


def test_quien_no_es_de_la_empresa_recibe_lo_mismo_que_una_contrasena_mala():
    eid, ta = _admin_empresa("-i2", "3101425102")
    tok, _ = _canje(ta)
    _, correo = _persona(eid, "cajero.i2")
    otra = _empresa_sola("-i2b", "3101425112")
    _, ajena = _persona(otra, "ajena.i2", rol="Administrador")                 # contraseña CORRECTA, pero de otra empresa
    _, sa = _persona(eid, "sa.i2", rol="Administrador", es_superadmin=True)    # administrador del sistema, aunque sea miembro
    mala = _ingreso(tok, correo, "Otra-Clave-Mala-2026")
    assert mala["ingreso"] == "rechazado" and mala["motivo"] == "credenciales" and "usuario" not in mala and "token" not in mala
    for x in (_ingreso(tok, "nadie.i2@example.test"), _ingreso(tok, ajena), _ingreso(tok, sa)):
        assert x == mala, x
    # cuentan en el contador de la instalación y no se limpian
    with Session(engine) as sc:
        t = sc.exec(select(auth.TokenApi).where(auth.TokenApi.prefijo == tok[:12])).first()
        for k in (ajena, sa):
            assert len(sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "login_fallo_prog", auth.IntentoIp.ip == f"inst{t.id}|{k}")).all()) == 1
    assert _ingreso(tok, ajena)["motivo"] == "credenciales"
    with Session(engine) as sc:
        assert len(sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "login_fallo_prog", auth.IntentoIp.ip == f"inst{t.id}|{ajena}")).all()) == 2
    # un cuerpo raro tampoco da otra cosa
    r = c.post("/api/sinc/ingreso", headers=H(tok), json=["no", "es", "un", "objeto"])
    assert r.status_code == 200 and r.json()["motivo"] == "credenciales"


def test_cinco_fallos_dejan_en_espera_solo_esa_instalacion_y_ese_correo():
    eid, ta = _admin_empresa("-i3", "3101425103")
    tok, _ = _canje(ta, "Caja A")
    tok2, _ = _canje(ta, "Caja B")
    _, correo = _persona(eid, "cajero.i3")
    _, otro = _persona(eid, "otro.i3")
    for _ in range(5):
        assert _ingreso(tok, correo, "Clave-Mala-i3-2026")["motivo"] == "credenciales"
    j = _ingreso(tok, correo)
    assert j["ingreso"] == "rechazado" and j["motivo"] == "espera" and "minutos" in j["mensaje"], j
    assert _ingreso(tok, otro)["ingreso"] == "ok"                     # otro correo en la misma instalación
    assert _ingreso(tok2, correo)["ingreso"] == "ok"                  # el mismo correo en otra instalación
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW})   # y en la web
    assert r.status_code == 200 and r.json().get("token"), r.text
    # un correo que no existe también queda en espera tras 5 fallos (misma respuesta exista o no)
    for _ in range(5):
        _ingreso(tok, "fantasma.i3@example.test")
    assert _ingreso(tok, "fantasma.i3@example.test")["motivo"] == "espera"
    _limpiar_intentos()


def test_los_topes_de_la_web_no_impiden_entrar_por_la_instalacion():
    eid, ta = _admin_empresa("-i4", "3101425104")
    tok, _ = _canje(ta)
    _, correo = _persona(eid, "cajero.i4")
    for _ in range(5):                                                 # 5 fallos web desde la misma conexión, con su correo
        assert c.post("/api/auth/login", json={"correo": correo, "password": "Clave-Mala-Web-i4"}).status_code == 401
    for _ in range(30):                                                # y el tope de 30 por conexión
        c.post("/api/auth/login", json={"correo": "x.i4@example.test", "password": "x"})
    assert c.post("/api/auth/login", json={"correo": correo, "password": PW}).status_code == 429
    assert _ingreso(tok, correo)["ingreso"] == "ok"
    _limpiar_intentos()


def test_bloqueado_temporal_y_dos_pasos_que_faltan():
    eid, ta = _admin_empresa("-i5", "3101425105")
    tok, _ = _canje(ta)
    _, bloq = _persona(eid, "bloqueado.i5", bloqueado=True)
    _, temp = _persona(eid, "temporal.i5", debe_cambiar_password=True)
    _, admin = _persona(eid, "admin.i5", rol="Administrador")          # su rol exige los dos pasos y no los tiene
    j = _ingreso(tok, bloq)
    assert j["ingreso"] == "rechazado" and j["motivo"] == "bloqueado" and "bloqueada" in j["mensaje"]
    assert _ingreso(tok, bloq, "Clave-Mala-i5-2026")["motivo"] == "credenciales"     # sin la contraseña no se sabe que está bloqueado
    j = _ingreso(tok, temp)
    assert j["motivo"] == "temporal" and "fisitaap.com" in j["mensaje"] and "usuario" not in j
    j = _ingreso(tok, admin)
    assert j["motivo"] == "dos_pasos_falta" and "Mi perfil" in j["mensaje"] and "usuario" not in j


def test_dos_pasos_con_token_propio_de_la_instalacion():
    eid, ta = _admin_empresa("-i6", "3101425106")
    tok, _ = _canje(ta, "Caja 1")
    tok2, _ = _canje(ta, "Caja 2")
    secreto = auth.nuevo_secreto()
    uid, correo = _persona(eid, "jefa.i6", rol="Administrador", mfa_activo=True, mfa_secret=auth._cifrar_mfa(secreto))
    j = _ingreso(tok, correo)
    assert j["ingreso"] == "dos_pasos" and j["token"] and "usuario" not in j and "password_hash" not in str(j)
    token = j["token"]
    # el token del segundo paso no sirve en la web ni con otra instalación
    assert c.post("/api/auth/mfa/verificar", json={"token_mfa": token, "codigo": auth.codigo_totp(secreto)}).status_code == 401
    assert _dos_pasos(tok2, token, auth.codigo_totp(secreto))["motivo"] == "vencido"
    # el token de la web tampoco sirve aquí
    web = auth.firmar({"tipo": "mfa", "uid": uid}, 300)
    assert _dos_pasos(tok, web, auth.codigo_totp(secreto))["motivo"] == "vencido"
    # código malo
    j = _dos_pasos(tok, token, "000000" if auth.codigo_totp(secreto) != "000000" else "111111")
    assert j["ingreso"] == "rechazado" and j["motivo"] == "codigo" and "usuario" not in j
    assert _usuario(uid).mfa_fallidos == 1
    # código bueno: entra con su ficha y la huella de los dos pasos (nunca el secreto)
    codigo = auth.codigo_totp(secreto, time.time() + 30)
    j = _dos_pasos(tok, token, codigo)
    assert j["ingreso"] == "ok", j
    f = j["usuario"]
    assert f["mfa"] and f["mfa_entrar"] is True and f["mfa_rrhh"] is True and f["password_hash"] == _usuario(uid).password_hash
    assert secreto not in str(j) and _usuario(uid).mfa_secret not in str(j) and "mfa_secret" not in f
    # el mismo código otra vez
    j = _dos_pasos(tok, token, codigo)
    assert j["motivo"] == "codigo" and "ya se usó" in j["mensaje"]
    # la huella cambia si cambia el secreto
    with Session(engine) as sc:
        u = sc.get(auth.Usuario, uid); u.mfa_secret = auth._cifrar_mfa(auth.nuevo_secreto()); sc.add(u); sc.commit()
        assert sinc._huella_mfa(sc.get(auth.Usuario, uid)) != f["mfa"]
    _limpiar_intentos()


def test_token_de_persona_sin_token_y_revocada():
    eid, ta = _admin_empresa("-i7", "3101425107")
    tok, terminal = _canje(ta)
    uid, correo = _persona(eid, "cajero.i7")
    with Session(engine) as sc:                                         # token de integración de una persona (no de instalación)
        sc.add(auth.TokenApi(empresa_id=eid, usuario_id=uid, nombre="Integración QA", prefijo="fcr_qa425pers", hash=auth._hash_token_api("fcr_qa425persona"),
                             permisos='["ver"]')); sc.commit()
    for cab in (H("fcr_qa425persona"), {}, H("fcr_" + "x" * 40), H(ta)):
        r = c.post("/api/sinc/ingreso", headers=cab, json={"correo": correo, "password": PW})
        assert r.status_code == 200 and r.json()["ingreso"] == "sin_acceso" and r.json()["motivo"] == "token" and "usuario" not in r.json(), r.text
    assert c.post("/api/sinc/usuarios", headers=H("fcr_qa425persona"), json={}).json()["ingreso"] == "sin_acceso"
    # revocada: la señal explícita de siempre, en las cuatro rutas
    assert c.delete(f"/api/sinc/instalaciones/{terminal}", headers=H(ta)).status_code == 200
    for ruta, cuerpo in (("/api/sinc/ingreso", {"correo": correo, "password": PW}), ("/api/sinc/ingreso/dos-pasos", {"token": "x", "codigo": "1"}),
                         ("/api/sinc/usuario", {"correo": correo}), ("/api/sinc/usuarios", {})):
        r = c.post(ruta, headers=H(tok), json=cuerpo)
        assert r.status_code == 401 and r.json()["detail"]["codigo"] == sinc.CODIGO_REVOCADA, r.text
    with Session(engine) as sc:                                         # sus validaciones se borran con la revocación
        t = sc.exec(select(auth.TokenApi).where(auth.TokenApi.prefijo == tok[:12])).first()
        assert not sc.exec(select(auth.IngresoPrograma).where(auth.IngresoPrograma.token_id == t.id)).all()


def test_empresa_bloqueada_la_ruta_contesta_igual():
    eid, ta = _admin_empresa("-i8", "3101425108")
    tok, _ = _canje(ta)
    _, correo = _persona(eid, "cajero.i8")
    _bloquear_en_nube(eid, True)
    try:
        assert c.get("/api/sinc/catalogo", headers=H(tok)).status_code == 403          # contexto() la frena
        j = _ingreso(tok, correo)
        assert j["ingreso"] == "ok" and j["empresa_bloqueada"] is True and j["usuario"]["correo"] == correo
        assert _ingreso(tok, correo, "Clave-Mala-i8-2026")["motivo"] == "credenciales"
        j = c.post("/api/sinc/usuarios", headers=H(tok), json={}).json()
        assert j["ingreso"] == "ok" and j["empresa_bloqueada"] is True and any(x["correo"] == correo for x in j["usuarios"])
    finally:
        _bloquear_en_nube(eid, False)


def test_politica_de_hash_por_instalacion():
    eid, ta = _admin_empresa("-i9", "3101425109")
    tok, _ = _canje(ta, "Caja 1")
    tok2, _ = _canje(ta, "Caja 2")
    uid, correo = _persona(eid, "cajero.i9", pin_hash=auth.hash_password("5937"))
    _, sin_pin = _persona(eid, "sinpin.i9")
    real = _usuario(uid)

    def fila(lista, k):
        return next(x for x in lista if x["correo"] == k)
    # una instalación que no avisa que valida en línea (versión anterior) recibe todo como hoy
    cat = c.get("/api/sinc/catalogo", headers=H(tok)).json()
    assert fila(cat["usuarios"], correo)["password_hash"] == real.password_hash and fila(cat["usuarios"], correo)["pin_hash"] == real.pin_hash
    assert all("mfa_secret" not in x and "mfa_respaldo" not in x and {"mfa", "mfa_entrar", "mfa_rrhh", "temporal"} <= set(x) for x in cat["usuarios"])
    # la que avisa: quien no ha entrado en línea en ella baja con el hash inservible (no vacío: no la saca de la empresa)
    cat = c.get("/api/sinc/catalogo", headers={**H(tok), **CABECERA}).json()
    assert fila(cat["usuarios"], correo)["password_hash"] == sinc.HASH_INSERVIBLE and fila(cat["usuarios"], correo)["pin_hash"] == sinc.HASH_INSERVIBLE
    assert fila(cat["usuarios"], sin_pin)["pin_hash"] is None
    assert not auth.verificar_password(PW, sinc.HASH_INSERVIBLE) and not auth.verificar_password("", sinc.HASH_INSERVIBLE)
    # la cabecera sola no deja marca: sin ella vuelve a recibir los hash (la marca la pone un ingreso en línea aceptado, más abajo)
    assert fila(c.get("/api/sinc/catalogo", headers=H(tok)).json()["usuarios"], correo)["password_hash"] == real.password_hash
    # las rutas nuevas aplican la política siempre
    j = c.post("/api/sinc/usuarios", headers=H(tok), json={}).json()
    assert j["ingreso"] == "ok" and j["sin_cambios"] is False and fila(j["usuarios"], correo)["password_hash"] == sinc.HASH_INSERVIBLE
    huella = j["huella"]
    j2 = c.post("/api/sinc/usuarios", headers=H(tok), json={"huella": huella}).json()
    assert j2["sin_cambios"] is True and "usuarios" not in j2 and j2["huella"] == huella
    f = c.post("/api/sinc/usuario", headers=H(tok), json={"correo": correo}).json()
    assert f["miembro"] is True and f["usuario"]["password_hash"] == sinc.HASH_INSERVIBLE
    # después de entrar en línea en ESA instalación baja el real (y solo en esa)
    assert _ingreso(tok, correo)["ingreso"] == "ok"
    cat = c.get("/api/sinc/catalogo", headers=H(tok)).json()
    assert fila(cat["usuarios"], correo)["password_hash"] == real.password_hash and fila(cat["usuarios"], correo)["pin_hash"] == real.pin_hash
    assert fila(cat["usuarios"], sin_pin)["password_hash"] == sinc.HASH_INSERVIBLE
    j3 = c.post("/api/sinc/usuarios", headers=H(tok), json={"huella": huella}).json()
    assert j3["sin_cambios"] is False and fila(j3["usuarios"], correo)["password_hash"] == real.password_hash
    assert c.post("/api/sinc/usuario", headers=H(tok), json={"correo": correo}).json()["usuario"]["password_hash"] == real.password_hash
    j4 = c.post("/api/sinc/usuarios", headers=H(tok2), json={}).json()
    assert fila(j4["usuarios"], correo)["password_hash"] == sinc.HASH_INSERVIBLE
    # la ficha de alguien que no es de la empresa: lo mismo exista o no
    otra = _empresa_sola("-i9b", "3101425119")
    _, ajena = _persona(otra, "ajena.i9")
    _, sa = _persona(eid, "sa.i9", rol="Administrador", es_superadmin=True)
    vistas = [c.post("/api/sinc/usuario", headers=H(tok), json={"correo": k}).json() for k in (ajena, sa, "nadie.i9@example.test")]
    assert all(v["ingreso"] == "ok" and v["miembro"] is False and v["usuario"] is None for v in vistas)
    assert vistas[0] == vistas[1] == vistas[2]
    # los administradores del sistema nunca bajan
    assert all(x["correo"] != sa for x in c.post("/api/sinc/usuarios", headers=H(tok), json={}).json()["usuarios"])


def test_temporal_baja_en_la_ficha():
    eid, ta = _admin_empresa("-i10", "3101425110")
    tok, _ = _canje(ta)
    _, temp = _persona(eid, "temporal.i10", debe_cambiar_password=True)
    f = c.post("/api/sinc/usuario", headers=H(tok), json={"correo": temp}).json()["usuario"]
    assert f["temporal"] is True and f["password_hash"] == sinc.HASH_INSERVIBLE


def test_con_un_programa_local_real_las_rutas_no_existen(monkeypatch):
    eid, ta = _admin_empresa("-i11", "3101425111")
    tok, _ = _canje(ta)
    _, correo = _persona(eid, "cajero.i11")
    rutas = (("/api/sinc/ingreso", {"correo": correo, "password": PW}), ("/api/sinc/ingreso/dos-pasos", {"token": "x", "codigo": "123456"}),
             ("/api/sinc/usuario", {"correo": correo}), ("/api/sinc/usuarios", {}))
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    for ruta, cuerpo in rutas:
        assert c.post(ruta, headers=H(tok), json=cuerpo).status_code == 404, ruta
    monkeypatch.delenv("FE_MODO_LOCAL")
    for ruta, cuerpo in rutas:
        r = c.post(ruta, headers=H(tok), json=cuerpo)
        assert r.status_code == 200 and r.json()["servicio"] == "fisitaap-ingreso", ruta


def test_ni_el_registro_ni_la_auditoria_tienen_la_contrasena_ni_el_codigo(caplog):
    eid, ta = _admin_empresa("-i12", "3101425112")
    tok, _ = _canje(ta)
    mala = "Clave-Secreta-Mala-i12-QA"
    secreto = auth.nuevo_secreto()
    _, correo = _persona(eid, "jefe.i12", rol="Administrador", mfa_activo=True, mfa_secret=auth._cifrar_mfa(secreto))
    _, cajero = _persona(eid, "cajero.i12")
    with Session(engine) as sc:
        desde = max([a.id for a in sc.exec(select(Auditoria)).all()] or [0])
    malo = "000000" if auth.codigo_totp(secreto) != "000000" else "111111"
    with caplog.at_level(logging.DEBUG):
        _ingreso(tok, cajero, mala)
        _ingreso(tok, "nadie.i12@example.test", mala)
        _ingreso(tok, cajero)
        token = _ingreso(tok, correo)["token"]
        _dos_pasos(tok, token, malo)
        bueno = auth.codigo_totp(secreto, time.time() + 30)
        assert _dos_pasos(tok, token, bueno)["ingreso"] == "ok"
        c.post("/api/sinc/ingreso", headers={**H(tok), "Content-Type": "application/json"}, content=b"{no es json " + mala.encode())
    texto = caplog.text
    for x in (mala, PW, bueno, malo, secreto):
        assert x not in texto
    with Session(engine) as sc:
        filas = sc.exec(select(Auditoria).where(Auditoria.id > desde)).all()
        assert any(a.accion == "login_fallido" for a in filas) and any(a.accion == "mfa_fallido" for a in filas)
        for a in filas:
            for x in (mala, PW, bueno, secreto):
                assert x not in (a.detalle or "") and x not in (a.correo or "")
    _limpiar_intentos()


# ------------------------------------------------------------------------------------------------------------------------------
# Correcciones de la revisión de las tandas 1 y 2
def _marcada(eid: int, tok: str = "") -> bool:
    """La marca permanente ingreso_en_linea de la instalación de ese token (o de cualquiera de la empresa) en sinc_vinculacion."""
    with Session(engine_empresa(eid)) as s:
        v = sinc._leer(s, eid, sinc.CLAVE_VINC, {})
    return any(i.get("ingreso_en_linea") for i in v.get("instalaciones", []) if not tok or i.get("prefijo") == tok[:12])


def test_la_cabecera_sola_no_marca_la_instalacion():
    """Con solo el token (copiado de una computadora) no se puede dejar marcada la instalación: la cabecera vale para esa respuesta y
    nada más. La marca permanente la pone un ingreso en línea aceptado (token y contraseña válida)."""
    eid, ta = _admin_empresa("-i13", "3101425113")
    tok, _ = _canje(ta)
    uid, correo = _persona(eid, "cajero.i13")
    _, otro = _persona(eid, "otro.i13")
    real = _usuario(uid).password_hash

    def baja(cab: dict, k: str = correo) -> str:
        return next(x for x in c.get("/api/sinc/catalogo", headers=cab).json()["usuarios"] if x["correo"] == k)["password_hash"]
    assert baja({**H(tok), **CABECERA}) == sinc.HASH_INSERVIBLE         # quien avisa recibe la política en ESA respuesta
    assert _marcada(eid, tok) is False
    assert baja(H(tok)) == real                                         # el programa anterior, sin cabecera, sigue bajando los hash
    assert _ingreso(tok, correo, "Clave-Mala-i13-2026")["motivo"] == "credenciales"
    assert _marcada(eid, tok) is False and baja(H(tok)) == real         # una contraseña mala tampoco la marca
    assert _ingreso(tok, correo)["ingreso"] == "ok"
    assert _marcada(eid, tok) is True                                   # ya entró alguien en línea por ella: no se deshace
    assert baja(H(tok)) == real and baja(H(tok), otro) == sinc.HASH_INSERVIBLE
    _limpiar_intentos()


def test_el_ingreso_del_programa_no_cuenta_como_conexion_conocida_en_la_web():
    """El ingreso aceptado desde una instalación se audita con una acción propia: la web no toma esa conexión (la del local, que
    comparte el wifi de clientes) como una desde donde la persona ya entró."""
    eid, ta = _admin_empresa("-i14", "3101425114")
    tok, terminal = _canje(ta, "Caja 1")
    uid, correo = _persona(eid, "cajera.i14")
    assert _ingreso(tok, correo)["ingreso"] == "ok"
    with Session(engine) as sc:
        assert not sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == "login")).all()
        a = sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == "login_programa")).all()
        assert len(a) == 1 and a[0].ip and a[0].detalle == f"Programa local «Caja 1» (terminal {terminal})"
    # desde esa misma conexión, una contraseña mala en la web sigue sumando al contador por correo (conexión desconocida)
    assert c.post("/api/auth/login", json={"correo": correo, "password": "Clave-Mala-Web-i14"}).status_code == 401
    with Session(engine) as sc:
        assert len(sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "login_cuenta", auth.IntentoIp.ip == correo)).all()) == 1
    _limpiar_intentos()
    # Configuración › Historial de operaciones la muestra con su nombre
    js = (pathlib.Path(__file__).resolve().parents[1] / "app" / "static" / "js" / "pages" / "configuracion" / "seccion.js").read_text(encoding="utf-8")
    assert "login_programa: ['Plataforma', 'Inicio de sesión en el programa local']" in js


def test_muchos_ingresos_buenos_seguidos_no_dejan_en_espera_a_la_instalacion(monkeypatch):
    """El tope general de una instalación (todas las cajas y tabletas que entran por esa computadora) es propio y mucho más alto que el
    de una conexión de la web, y al pasarlo el sobre dice «tope», no la «espera» de un correo."""
    eid, ta = _admin_empresa("-i15", "3101425115")
    tok, _ = _canje(ta)
    _, correo = _persona(eid, "cajero.i15")
    _, otro = _persona(eid, "otro.i15")
    for n in range(auth.LIMITE_IP[0] + 1):                              # 31 ingresos BUENOS seguidos
        j = _ingreso(tok, correo)
        assert j["ingreso"] == "ok", (n, j)
    assert sinc.TOPE_INGRESO[0] >= 10 * auth.LIMITE_IP[0] and sinc.TOPE_INGRESO[1] == auth.LIMITE_IP[1]
    monkeypatch.setattr(sinc, "TOPE_INGRESO", (auth.LIMITE_IP[0] + 3, sinc.TOPE_INGRESO[1], sinc.TOPE_INGRESO[2]))
    assert _ingreso(tok, otro)["ingreso"] == "ok"
    assert _ingreso(tok, "nadie.i15@example.test")["motivo"] == "credenciales"     # quien no es de la empresa gasta el mismo cupo
    for k in (correo, "nadie.i15@example.test"):
        j = _ingreso(tok, k)
        assert j["ingreso"] == "rechazado" and j["motivo"] == "tope" and j["mensaje"] and "usuario" not in j, j
    with Session(engine) as sc:                                         # el tope no es un fallo de nadie
        assert not sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave.in_(("login_fallo", "login_fallo_prog")), auth.IntentoIp.ip.endswith("|" + correo))).all()
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW})         # y la web no se entera
    assert r.status_code == 200 and r.json().get("token"), r.text
    _limpiar_intentos()


def test_el_programa_solo_avisa_si_puede_validar_en_linea(monkeypatch):
    """El programa manda la cabecera (y la nube le aplica la política de hash) solo si puede validar en línea: su dirección guardada es
    sinc.URL_NUBE. Conectado a otra dirección no manda la contraseña a nadie (D-J), así que tiene que seguir bajando los hash."""
    eid_a, ta = _admin_empresa("-i16n", "3101425116")
    eid_b, tb = _admin_empresa("-i16l", "3101425126")
    uid, correo = _persona(eid_a, "cajero.i16")
    real = _usuario(uid).password_hash
    shim = _modo_local(monkeypatch)
    _vincular(monkeypatch, ta, tb, "Caja 16")
    vistos, get = [], shim.get

    def espia(url, headers=None, timeout=None):
        r = get(url, headers=headers, timeout=timeout)
        if url.endswith("/api/sinc/catalogo"):
            vistos.append((dict(headers or {}), r.json()))
        return r

    def bajo() -> str:
        return next(x for x in vistos[-1][1]["usuarios"] if x["correo"] == correo)["password_hash"]
    monkeypatch.setattr(shim, "get", espia)
    monkeypatch.setattr(sinc, "INGRESO_EN_LINEA", True)
    monkeypatch.setattr(sinc, "URL_NUBE", "https://fisitaap.com")       # conectada a otra dirección (NUBE: la escribieron a mano)
    assert not sinc._valida_en_linea({"url": NUBE}) and sinc._valida_en_linea({"url": "https://FISITAAP.com/ "})
    assert not sinc.sincronizar(eid_b)["ultimo_error"]
    assert sinc.CABECERA_INGRESO not in vistos[-1][0] and bajo() == real and _usuario(uid).password_hash == real
    monkeypatch.setattr(sinc, "URL_NUBE", "")                           # FE_NUBE_URL dudosa: sin dirección a la cual validar
    assert not sinc.sincronizar(eid_b)["ultimo_error"]
    assert sinc.CABECERA_INGRESO not in vistos[-1][0] and bajo() == real and _usuario(uid).password_hash == real
    assert _marcada(eid_a) is False
    # conectada a la dirección de la web (no importan las mayúsculas ni la barra final): avisa y la nube le aplica la política
    monkeypatch.setattr(sinc, "URL_NUBE", NUBE.replace("nube", "NUBE"))
    monkeypatch.setattr(sinc, "_bajar_usuarios", lambda *a, **k: None)  # nube y computadora comparten la tabla de usuarios en las pruebas
    assert not sinc.sincronizar(eid_b)["ultimo_error"]
    assert vistos[-1][0].get(sinc.CABECERA_INGRESO) == str(sinc.PROTOCOLO_INGRESO) and bajo() == sinc.HASH_INSERVIBLE
    assert _marcada(eid_a) is False                                     # y aun así la marca no la pone la cabecera
    monkeypatch.setattr(sinc, "INGRESO_EN_LINEA", False)                # el programa de hoy (todavía no pide el ingreso a la nube)
    assert not sinc.sincronizar(eid_b)["ultimo_error"]
    assert sinc.CABECERA_INGRESO not in vistos[-1][0] and bajo() == real


def test_pin_sin_activar_en_esta_computadora_lo_dice_y_no_cuenta_fallo(monkeypatch):
    """El PIN de quien todavía no entró en línea en esta computadora baja inservible (D-E): el programa se lo explica en lugar de
    «Correo o PIN incorrectos», y no le suma fallos (no hay PIN que adivinar)."""
    eid, _ = _admin_empresa("-i17", "3101425117")
    uid, correo = _persona(eid, "cajera.i17", pin_hash=sinc.HASH_INSERVIBLE, de_nube=True)
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    for _ in range(auth.MAX_INTENTOS + 1):
        r = c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "4827"})
        assert r.status_code == 403 and "token" not in r.json(), r.text
        assert r.json()["detail"] == "Entre una vez con su correo y contraseña en esta computadora (con internet) para activar su PIN aquí"
    with Session(engine) as sc:
        assert not sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "login_fallo", auth.IntentoIp.ip.endswith("|" + correo))).all()
    # quien no existe o no tiene PIN: lo de siempre
    r = c.post("/api/auth/pin/entrar", json={"correo": "nadie.i17@example.test", "pin": "4827"})
    assert r.status_code == 401 and r.json()["detail"] == "Correo o PIN incorrectos"
    # con su PIN ya activado aquí (bajó el hash real) entra como antes
    with Session(engine) as sc:
        u = sc.get(auth.Usuario, uid); u.pin_hash = auth.hash_password("4827"); sc.add(u); sc.commit()
    assert c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "9999"}).status_code == 401
    r = c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "4827"})
    assert r.status_code == 200 and r.json().get("token"), r.text
    _limpiar_intentos()


def test_las_fichas_y_la_bajada_de_usuarios_tienen_topes_aparte_que_no_niegan_la_entrada(monkeypatch):
    """La ficha de una persona (PIN de caja) y la bajada de usuarios del ciclo no comparten cupo, y al pasarse contestan «sin_acceso»
    con motivo «tope» (el programa sigue con lo guardado), nunca «rechazado»."""
    eid, ta = _admin_empresa("-i18", "3101425118")
    tok, _ = _canje(ta)
    _, correo = _persona(eid, "salonero.i18")
    assert sinc.LIMITE_FICHA[0] > sinc.LIMITE_USUARIOS[0]
    monkeypatch.setattr(sinc, "LIMITE_FICHA", (3, 300))
    monkeypatch.setattr(sinc, "LIMITE_USUARIOS", (2, 300))

    def ficha() -> dict:
        return c.post("/api/sinc/usuario", headers=H(tok), json={"correo": correo}).json()

    def bajada() -> dict:
        return c.post("/api/sinc/usuarios", headers=H(tok), json={}).json()
    for _ in range(3):
        assert ficha()["ingreso"] == "ok"
    for _ in range(2):                                                  # las fichas no le gastaron el cupo a la bajada del ciclo
        assert bajada()["ingreso"] == "ok"
    for j in (ficha(), bajada()):
        assert j["servicio"] == "fisitaap-ingreso" and j["ingreso"] == "sin_acceso" and j["motivo"] == "tope" and j["mensaje"], j
        assert "usuario" not in j and "usuarios" not in j and "miembro" not in j
    assert _ingreso(tok, correo)["ingreso"] == "ok"                     # el ingreso con contraseña no depende de esos topes
    _limpiar_intentos()


def test_una_conexion_escrita_a_mano_no_toca_los_contadores_de_la_instalacion(monkeypatch):
    """P3 (revisión de las tandas 1 y 2): con sujeto los contadores usan claves propias («login_prog», «login_fallo_prog», «mfa_prog»).
    Detrás de un proxy que deja pasar la cabecera, una dirección escrita a mano igual a «inst<id>» ya no deja en espera a la instalación."""
    eid, ta = _admin_empresa("-i19", "3101425120")
    tok, _ = _canje(ta)
    _, correo = _persona(eid, "cajero.i19")
    _limpiar_intentos()
    with Session(engine) as sc:
        t = sc.exec(select(auth.TokenApi).where(auth.TokenApi.prefijo == tok[:12])).first()
    falsa = {"cf-connecting-ip": f"inst{t.id}"}
    monkeypatch.setenv("FE_CLOUDFLARE", "1")
    for _ in range(auth.MAX_INTENTOS):                                  # 5 contraseñas malas «desde» inst<id> con el correo del cajero
        assert c.post("/api/auth/login", headers=falsa, json={"correo": correo, "password": "Clave-Mala-i19-2026"}).status_code == 401
    for _ in range(auth.LIMITE_IP[0]):                                  # y el tope general de esa «conexión»
        c.post("/api/auth/login", headers=falsa, json={"correo": "x.i19@example.test", "password": "x"})
    assert c.post("/api/auth/login", headers=falsa, json={"correo": correo, "password": PW}).status_code == 429
    monkeypatch.delenv("FE_CLOUDFLARE")
    j = _ingreso(tok, correo)
    assert j["ingreso"] == "ok", j
    with Session(engine) as sc:
        claves = {x.clave for x in sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.ip.startswith(f"inst{t.id}"))).all()}
    assert "login_prog" in claves and "login" in claves and "login_fallo" in claves      # la web escribió las suyas; la instalación, las propias
    assert auth.clave_contador("mfa", f"inst{t.id}") == "mfa_prog" and auth.clave_contador("mfa", None) == "mfa"
    assert {"login_prog", "mfa_prog"} <= set(auth.CLAVES_PERSISTENTES)
    _limpiar_intentos()
