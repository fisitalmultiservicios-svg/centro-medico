"""3.86: la marca del producto es «FISITAAP by Brillante Agencia» (antes «FISITAAP ERP»): nombre del sistema (también cuando la
consola o la variable guardaron el nombre de antes), firma junto al logo en pantallas y correos, y ningún texto visible con la marca
vieja. IT Core Sync S.R.L. sigue como operador del servicio en los pies legales."""
import json
import os
import pathlib

from app import config, correo_diseno

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
TECNICOS = {"agente_local.py", "escpos.py", "hotel.py"}          # identificadores técnicos que no ve el cliente


def _con_sistema(d):
    ruta = config.DATA_DIR / "sistema.json"
    antes = ruta.read_text(encoding="utf-8") if ruta.exists() else None
    if d is None:
        ruta.unlink(missing_ok=True)
    else:
        ruta.write_text(json.dumps(d), encoding="utf-8")
    config._sistema_cache.clear()
    return ruta, antes


def _restaurar(ruta, antes):
    if antes is None:
        ruta.unlink(missing_ok=True)
    else:
        ruta.write_text(antes, encoding="utf-8")
    config._sistema_cache.clear()


def test_nombre_del_sistema_nuevo_y_el_viejo_guardado_pasa_al_nuevo(monkeypatch):
    monkeypatch.delenv("FE_NOMBRE_SISTEMA", raising=False)
    ruta, antes = _con_sistema(None)
    try:
        assert config.nombre_sistema() == "FISITAAP by Brillante Agencia"
        _con_sistema({"nombre": "FISITAAP ERP", "eslogan": "x"})
        assert config.nombre_sistema() == "FISITAAP by Brillante Agencia"      # el de antes, guardado en la consola
        _con_sistema({"nombre": "Otra Marca QA"})
        assert config.nombre_sistema() == "Otra Marca QA"                      # un nombre elegido a propósito se respeta
        _con_sistema(None)
        monkeypatch.setenv("FE_NOMBRE_SISTEMA", "FISITAAP ERP")
        assert config.nombre_sistema() == "FISITAAP by Brillante Agencia"
    finally:
        _restaurar(ruta, antes)


def test_correo_de_la_plataforma_lleva_la_firma_y_el_operador():
    config._sistema_cache.clear()
    html = correo_diseno.armar(correo_diseno.plataforma(), titulo="Prueba 386", asunto="Prueba 386", parrafos_txt=["Hola"])
    assert "by Brillante Agencia" in html and "IT Core Sync S.R.L." in html and "FISITAAP ERP" not in html


def test_ningun_texto_visible_con_la_marca_vieja_y_el_logo_con_la_firma():
    viejos = []
    for ruta in RAIZ.rglob("*"):
        if ruta.suffix not in (".py", ".js", ".html", ".css", ".json", ".webmanifest") or "vendor" in ruta.parts or ruta.name in TECNICOS:
            continue
        texto = ruta.read_text(encoding="utf-8", errors="ignore")
        if ruta.name == "config.py":
            texto = texto.replace('NOMBRES_VIEJOS = {"FISITAAP ERP"}', "").replace("(antes «FISITAAP ERP»)", "")
        if "FISITAAP ERP" in texto or '<span class="erp-tag">ERP</span>' in texto:
            viejos.append(str(ruta.relative_to(RAIZ)))
    assert not viejos, viejos
    for rel in ("static/js/pages/login.js", "static/js/app.js", "static/js/fis/app.js", "sitio_web/base.html", "static/js/motorizado.js"):
        assert 'class="erp-by">by Brillante Agencia</span>' in (RAIZ / rel).read_text(encoding="utf-8"), rel
    assert "Un servicio de" in (RAIZ / "static/js/pages/login.js").read_text(encoding="utf-8")
    assert "Desarrollado por" not in (RAIZ / "static/js/pages/login.js").read_text(encoding="utf-8")
