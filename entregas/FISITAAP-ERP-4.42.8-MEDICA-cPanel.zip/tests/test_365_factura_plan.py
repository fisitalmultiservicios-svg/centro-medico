"""3.65: factura automática del cobro del plan. Cada pago del plan registrado (a mano o por Tilopay) emite un comprobante desde la
empresa facturadora al cliente, lo deja cobrado y lo anota en el pago; sin configuración no pasa nada; un fallo queda en el pago y
se reintenta desde Administración."""
import types

from fastapi.testclient import TestClient
from sqlmodel import Session, select

import pytest

from app import auth, factura_plan, planes
from app.db import Cliente, Documento, Empresa, Producto, engine, engine_empresa, init_db


@pytest.fixture()
def escenario():
    from app.main import app  # noqa: F401  registra tablas
    init_db()
    with Session(engine) as s:
        fe = s.exec(select(Empresa).where(Empresa.nombre == "Proveedor del Sistema QA S.A.")).first()
        if not fe:
            fe = auth.crear_empresa(s, "Proveedor del Sistema QA S.A.", "fact365@example.test", "3101365365", nombre_comercial="Proveedor QA", provincia=1, canton=1, distrito=1,
                                    otras_senas="Oficina central, San José (QA)", actividad="620100", telefono=22223333, es_demo=True, factura_electronica=False, correo_automatico=False)
        e2 = s.exec(select(Empresa).where(Empresa.nombre == "Cliente del Plan QA S.A.")).first()
        if not e2:
            e2 = auth.crear_empresa(s, "Cliente del Plan QA S.A.", "cliente365@example.test", "3101365366", nombre_comercial="Cliente Plan QA", provincia=1, canton=1, distrito=1,
                                    otras_senas="Local comercial (QA)", actividad="471101", telefono=22224444, tipo_negocio="facturacion")
        e2.plan = "fac_250"; s.add(e2); s.commit(); s.refresh(fe); s.refresh(e2)
        fe_id, e2_id = fe.id, e2.id
    with Session(engine_empresa(fe_id)) as se:
        prod = se.exec(select(Producto).where(Producto.empresa_id == fe_id, Producto.nombre == "Plan mensual FISITAAP ERP")).first()
        if not prod:
            prod = Producto(empresa_id=fe_id, codigo="PLAN", nombre="Plan mensual FISITAAP ERP", cabys="8314100000000", precio=9900, es_servicio=True, unidad_medida="Sp", tipo="Servicio", inventariable=False)
            se.add(prod); se.commit(); se.refresh(prod)
        prod_id = prod.id
    factura_plan.guardar_config({"activo": True, "empresa_id": fe_id, "producto_id": prod_id, "cuenta": ""})
    try:
        yield fe_id, e2_id, prod_id
    finally:
        factura_plan.guardar_config({})


def _pagar(e2_id, monto=11187, medio="transferencia"):
    with Session(engine) as s:
        e2 = s.get(Empresa, e2_id)
        p = planes.registrar_pago(s, e2, {"monto": monto, "meses": 1, "medio": medio, "referencia": "ref-qa"}, usuario="admin-qa@example.test")
        s.refresh(p)
        return p


def test_pago_del_plan_emite_factura_cobrada(escenario):
    fe_id, e2_id, prod_id = escenario
    p = _pagar(e2_id)
    assert p.factura_documento_id and p.factura_consecutivo and p.factura_empresa_id == fe_id and not p.factura_error
    with Session(engine_empresa(fe_id)) as se:
        d = se.get(Documento, p.factura_documento_id)
        cli = se.exec(select(Cliente).where(Cliente.empresa_id == fe_id, Cliente.numero_id == "3101365366")).first()
    assert d and d.tipo_documento == "01" and d.estado == "interno" and abs(d.total - 11187) < 0.01   # facturadora sin FE: comprobante interno
    assert cli and d.cliente_id == cli.id and cli.nombre == "Cliente del Plan QA S.A."
    assert abs((d.pagado or 0) - d.total) < 0.01                                                  # quedó cobrada
    # segundo pago: otra factura distinta
    p2 = _pagar(e2_id, medio="tarjeta Tilopay")
    assert p2.factura_documento_id and p2.factura_documento_id != p.factura_documento_id and p2.factura_consecutivo != p.factura_consecutivo


def test_sin_configuracion_no_factura_y_error_se_reintenta(escenario):
    fe_id, e2_id, prod_id = escenario
    factura_plan.guardar_config({"activo": False, "empresa_id": fe_id, "producto_id": prod_id})
    p = _pagar(e2_id)
    assert p.factura_documento_id is None and p.factura_error is None
    # ítem inexistente: el pago se registra igual y el error queda anotado
    factura_plan.guardar_config({"activo": True, "empresa_id": fe_id, "producto_id": 999999})
    p = _pagar(e2_id)
    assert p.factura_documento_id is None and p.factura_error and "ítem" in p.factura_error.lower()
    # se corrige la configuración y se reintenta desde Administración
    factura_plan.guardar_config({"activo": True, "empresa_id": fe_id, "producto_id": prod_id})
    from app.main import app
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-365@example.test")).first()
        if not u:
            u = auth.Usuario(correo="sa-365@example.test", nombre="SA 365", password_hash=auth.hash_password("Clave-Segura-365-QA!"), es_superadmin=True)
            s.add(u); s.commit(); s.refresh(u)
        sa = types.SimpleNamespace(id=u.id, correo=u.correo, es_superadmin=True, nombre="SA", mfa_activo=True)
    app.dependency_overrides[auth.superadmin] = lambda: sa
    try:
        c = TestClient(app)
        r = c.post(f"/api/admin/cuentas/{e2_id}/pagos/{p.id}/facturar")
        assert r.status_code == 200, r.text
        assert r.json()["factura_consecutivo"] and r.json()["factura_error"] is None
        assert c.post(f"/api/admin/cuentas/{e2_id}/pagos/{p.id}/facturar").json()["factura_documento_id"] == r.json()["factura_documento_id"]   # no se factura dos veces
        assert c.post(f"/api/admin/cuentas/{e2_id}/pagos/999999/facturar").status_code == 404
        cfg = c.get("/api/admin/factura-plan").json()
        assert cfg["activo"] and cfg["empresa_id"] == fe_id and any(i["id"] == prod_id for i in cfg["items"])
        assert c.put("/api/admin/factura-plan", json={"activo": True, "empresa_id": fe_id, "producto_id": None}).status_code == 400
        assert c.put("/api/admin/factura-plan", json={"activo": True, "empresa_id": fe_id, "producto_id": prod_id, "cuenta": ""}).status_code == 200
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "sa-365@example.test")).first()
            if u:
                s.delete(u); s.commit()
