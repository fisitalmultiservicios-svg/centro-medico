"""3.87: la pulga del administrador del sistema.
- Sin empresa elegida, el logo, «Mi espacio» y las rutas de negocio llevan a la consola (antes abrían el Inicio de una empresa inexistente
  con «No se pudo cargar el resumen: Seleccione una empresa» y el menú completo de Facturación).
- Si el administrador del sistema también es miembro de la empresa con un rol menor (Cajero), el servidor le da los permisos de
  Administrador, igual que la sesión que ve la interfaz (antes le negaba, por ejemplo, los borradores).
- El respaldo diario se rehace si la marca dice «hoy» pero el archivo de hoy ya no está."""
import pathlib

from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, respaldo
from app.db import Empresa, engine, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
CORREO = "sa.cajero.387@example.test"


def test_sin_empresa_la_interfaz_vuelve_a_la_consola():
    js = (RAIZ / "static/js/app.js").read_text(encoding="utf-8")
    assert "const SIN_EMPRESA = new Set(['/admin', '/configuracion/perfil']);" in js
    assert "if (!this.empresa_id) return this.esAdmin ? '/admin' : '/inicio';" in js            # logo y «Mi espacio»
    assert "sesion.esAdmin && !sesion.empresa_id && !SIN_EMPRESA.has(limpio)) { location.hash = '/admin'; return; }" in js
    assert '<aside class="sidebar" :class="{open: mobileOpen}" v-if="sesion.empresa_id">' in js   # sin empresa no hay menú de negocio
    inicio = (RAIZ / "static/js/pages/inicio.js").read_text(encoding="utf-8")
    assert "if (!sesion.empresa_id) { this.cargando = false; return; }" in inicio


def test_administrador_del_sistema_que_tambien_es_cajero_tiene_todo():
    init_db()
    with Session(engine) as s:
        e = s.exec(select(Empresa).where(Empresa.nombre == "Empresa SA 387 QA S.A.")).first()
        if not e:
            e = Empresa(nombre="Empresa SA 387 QA S.A.", numero_id="3101387387", actividad="731001", otras_senas="Oficina 387",
                        correo="emp387@example.test", ambiente="sandbox")
            s.add(e); s.commit(); s.refresh(e)
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == CORREO)).first()
        if not u:
            u = auth.Usuario(correo=CORREO, nombre="SA Cajero QA", password_hash=auth.hash_password("Clave-larga-387-qa"), es_superadmin=True,
                             mfa_activo=True, terminos_version=auth.TERMINOS_VERSION, paleta="turquesa")
            s.add(u); s.commit(); s.refresh(u)
        if not s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id, auth.UsuarioEmpresa.empresa_id == e.id)).first():
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol="Cajero")); s.commit()
        r = auth._respuesta(s, u, e.id)
    try:
        assert r["rol"] == "Administrador" and "configurar" in r["permisos"]            # lo que ve la interfaz
        c = TestClient(app)
        h = {"Authorization": "Bearer " + r["token"]}
        b = c.get("/api/borradores", headers=h)                                       # el Cajero no tiene borradores; el administrador del sistema sí
        assert b.status_code == 200, b.text
        assert c.get("/api/recurrentes", headers=h).status_code == 200
    finally:
        with Session(engine) as s:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == CORREO)).first()
            for m in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                s.delete(m)
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == u.id)).all():
                s.delete(x)
            s.delete(u); s.commit()


def test_respaldo_diario_se_rehace_si_falta_el_archivo_de_hoy():
    init_db()
    hoy = respaldo.ahora_cr()
    respaldo.RESPALDOS_DIR.mkdir(parents=True, exist_ok=True)
    for p in respaldo.RESPALDOS_DIR.glob(f"facturacr_{hoy:%Y%m%d}_*.zip"):
        p.unlink()
    respaldo.MARCA.write_text(hoy.isoformat(timespec="seconds"), encoding="utf-8")   # la marca dice «hoy» pero no hay archivo
    hecho = respaldo.diario()
    assert hecho is not None and hecho.exists()
    assert respaldo.diario() is None                                               # ya está el de hoy: no se repite
