# -*- coding: utf-8 -*-
"""4.2: cierre de caja a ciegas con corte por medio de pago, entradas y pagos a proveedores desde la caja; aviso de reinicio pendiente
(la versión de la pantalla contra la del programa en marcha); mensajes de Hacienda que dicen qué dato falla; el comprobante interno
(sin facturación electrónica) no se detiene por los datos del contacto."""
import pathlib
import re

from fastapi.testclient import TestClient
from pydantic import ValidationError

from app import auth, main, version
from app.db import Cliente
from app.fe.modelos import Ubicacion
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

JS = pathlib.Path(main.__file__).parent / "static" / "js"


def test_version_en_ejecucion_y_aviso_de_reinicio():
    assert version.EN_EJECUCION == version.actual()["version"] and not version.falta_reiniciar()
    viejo = version.EN_EJECUCION
    try:
        version.EN_EJECUCION = "0.1"                       # archivos nuevos con el programa anterior en marcha
        assert version.falta_reiniciar()
    finally:
        version.EN_EJECUCION = viejo
    m = re.search(r"export const VERSION_APP = '([^']+)'", (JS / "app.js").read_text(encoding="utf-8"))
    assert m and m.group(1) == version.actual()["version"]           # la pantalla, NOVEDADES y el servidor van juntos
    assert f"const VERSION = 'app-v{m.group(1)}'" in (JS.parent / "sw-app.js").read_text(encoding="utf-8")
    from app.db import init_db
    init_db()                                          # la prueba también corre sola
    r = TestClient(main.app).get("/api/auth/estado")
    assert r.status_code == 200 and r.json()["version"] == version.EN_EJECUCION and r.json()["archivos"] == version.actual()["version"]


def test_mensaje_de_hacienda_dice_el_dato():
    try:
        Ubicacion(provincia=1, canton=1, distrito=1, otras_senas="abc")
    except ValidationError as ex:
        assert main._explicar_hacienda(ex) == "Dirección exacta (otras señas): debe tener al menos 5 caracteres"
    else:
        raise AssertionError("debía fallar")


def test_contacto_con_datos_malos_no_detiene_el_comprobante_interno():
    c = Cliente(empresa_id=1, nombre="Al", tipo_id="01", numero_id="12", direccion="SJ", correo="x@")
    p = main._parte_cliente_laxa(c)
    assert p.nombre == "Al (cliente)" and p.ubicacion is None


def test_empresa_sin_direccion_con_facturacion_electronica(api):  # noqa: F811
    e = main.app.dependency_overrides[auth.contexto]().empresa
    antes = (e.otras_senas, e.factura_electronica)
    lin = [{"detalle": "Servicio QA", "cantidad": 1, "precio_unitario": 1000, "cabys": "8399000000000", "unidad_medida": "Sp", "es_servicio": True}]
    try:
        e.otras_senas, e.factura_electronica = "abc", True
        r = api.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": lin})
        assert r.status_code == 400 and "Faltan datos de la empresa" in r.text and "Dirección exacta (otras señas): debe tener al menos 5 caracteres" in r.text, r.text
        e.factura_electronica = False                      # sin facturación electrónica la misma venta sale como comprobante interno
        r = api.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": lin})
        assert r.status_code == 200 and r.json()["estado"] == "interno", r.text
    finally:
        e.otras_senas, e.factura_electronica = antes


def test_caja_a_ciegas_con_corte_entradas_y_pagos():
    d = (JS / "pages/pos/_datos.js").read_text(encoding="utf-8")
    assert "cierre_ciego: true" in d and "export function corteCaja(c, r)" in d and "export function registrarEntrada(cajaId, entrada)" in d
    assert "esperadoMedio:" in d and "pagos_proveedor: pagosProveedor" in d and "sesion.puede('ver_todo') || sesion.puede('configurar')" in d
    k = (JS / "pages/pos/caja.js").read_text(encoding="utf-8")
    assert "+ Entrada" in k and "− Salida" in k and "Pago a proveedor" in k and "'#/pos/cierres?cerrar=' + caja.id" in k
    assert 'v-if="verMontosCaja"' in k and "verMontosCaja()" in k and "async registrarPagoProveedor(reg, compraId)" in k
    z = (JS / "pages/pos/cierres.js").read_text(encoding="utf-8")
    assert "Hacer el corte y cerrar" in z and "Contar por billetes y monedas" in z and "Corte por medio de pago" in z
    assert "declarado, declarado_bancos: declaradoBancos, cierre_ciego: !!k.ciego" in z and "this.columnasTodas.filter(c => !['total', 'esperado', 'dif'].includes(c.key))" in z
    assert 't.cierre_ciego' in (JS / "pages/pos/configuracion.js").read_text(encoding="utf-8")


def test_colilla_del_cierre_y_datafono_por_banco():
    a = (JS / "pages/pos/_agente.js").read_text(encoding="utf-8")
    assert "export function docColilla(" in a and "'A = declarado por el cajero · B = según el sistema'" in a and "'FALTANTE TOTAL'" in a and "'EXCEDENTE TOTAL'" in a
    z = (JS / "pages/pos/cierres.js").read_text(encoding="utf-8")
    assert "async imprimirColilla(c, { deLaCaja = false } = {})" in z and "if (cerrada && o.auto) this.imprimirColilla(cerrada, { deLaCaja: true });" in z and "⎙ Colilla" in z   # 4.41: la que sale sola al cerrar es la de la caja
    assert "A · Cajero" in z and "B · Sistema" in z and "declarado_bancos: declaradoBancos" in z and "Cierre del datáfono por banco" in z
    assert '<template v-if="!opc(resultado).corte">' in z   # 4.41: el corte lo ve el cajero solo si la caja lo permite (tests/test_441_cierre_ciego.py)
