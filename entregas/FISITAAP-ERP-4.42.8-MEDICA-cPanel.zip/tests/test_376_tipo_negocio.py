"""3.76: cambiar el tipo de negocio desde la consola enciende los módulos del tipo nuevo (los apagados «por tipo» al crear la
empresa se recalculan). Antes una empresa creada como Facturación seguía sin punto de venta ni ventas en línea al pasar a
Restaurante. Se prueban las 20 transiciones (de cada tipo a cada otro) y el ciclo completo en una misma empresa."""
import itertools
import json
import types

import pytest
from sqlmodel import Session

from app import auth, planes
from app.db import Empresa, engine
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

TIPOS = ("facturacion", "comercio", "restaurante", "hospitalidad", "servicios")
# lo que cada tipo tiene que ver con «sin plan (todo encendido)»; lo demás nace apagado por tipo
ESPERADO = {
    "facturacion": {"pos": False, "pedidos_online": False, "hotel_completo": False, "tike": True, "contabilidad": True, "rrhh": True},   # TiKe es extra disponible en Facturación
    "comercio": {"pos": True, "pedidos_online": True, "hotel_completo": False, "contabilidad": True},
    "restaurante": {"pos": True, "pedidos_online": True, "entregas": True, "hotel_completo": False},
    "hospitalidad": {"pos": True, "hotel_completo": True, "pedidos_online": True},
    "servicios": {"tike": True, "pos": False, "hotel_completo": False, "contabilidad": True},
}


def _como_superadmin(app):
    app.dependency_overrides[auth.superadmin] = lambda: types.SimpleNamespace(id=None, correo="admin-qa@example.test", es_superadmin=True, nombre="Admin QA")


def _fijar(eid, tipo):
    with Session(engine) as s:
        e = s.get(Empresa, eid)
        e.tipo_negocio = tipo; e.modulos_ocultos = json.dumps(planes.ocultos_por_tipo(tipo)); s.add(e); s.commit()


def _modulos(eid):
    with Session(engine) as s:
        e = s.get(Empresa, eid)
        return e.tipo_negocio, planes.modulos_de(e), json.loads(e.modulos_ocultos or "[]")


def _verificar(eid, tipo):
    t, m, ocultos = _modulos(eid)
    assert t == tipo
    assert ocultos == planes.ocultos_por_tipo(tipo), (tipo, ocultos)
    for modulo, debe in ESPERADO[tipo].items():
        assert (modulo in m) is debe, (tipo, modulo, sorted(m))


@pytest.mark.parametrize("origen,destino", [(a, b) for a, b in itertools.product(TIPOS, TIPOS) if a != b])
def test_todas_las_transiciones(api, origen, destino):  # noqa: F811
    from app.main import app
    c = api
    eid = app.dependency_overrides[auth.contexto]().empresa.id
    _fijar(eid, origen)
    _verificar(eid, origen)
    _como_superadmin(app)
    try:
        r = c.post(f"/api/admin/cuentas/{eid}/tipo", json={"tipo_negocio": destino})
        assert r.status_code == 200, r.text
        assert r.json()["tipo_negocio"] == destino
    finally:
        app.dependency_overrides.pop(auth.superadmin, None)
    _verificar(eid, destino)


def test_ciclo_completo_y_tipo_invalido(api):  # noqa: F811
    from app.main import app
    c = api
    eid = app.dependency_overrides[auth.contexto]().empresa.id
    _fijar(eid, "facturacion")
    _como_superadmin(app)
    try:
        for tipo in TIPOS[1:] + TIPOS[:1]:                       # comercio → restaurante → hospitalidad → servicios → facturación
            assert c.post(f"/api/admin/cuentas/{eid}/tipo", json={"tipo_negocio": tipo}).status_code == 200
            _verificar(eid, tipo)
        assert c.post(f"/api/admin/cuentas/{eid}/tipo", json={"tipo_negocio": "otro"}).status_code == 400
        assert c.post("/api/admin/cuentas/999999/tipo", json={"tipo_negocio": "comercio"}).status_code == 404
    finally:
        app.dependency_overrides.pop(auth.superadmin, None)
