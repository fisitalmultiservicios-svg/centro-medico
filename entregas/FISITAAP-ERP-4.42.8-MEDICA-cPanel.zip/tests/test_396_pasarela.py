# -*- coding: utf-8 -*-
"""3.96: al guardar la configuración de Tilopay la consola recibe lo mismo que al verla (con aviso_url): antes mostraba el aviso
de FE_URL_PUBLICA aunque la variable estuviera definida."""
import inspect

from app import suscripcion


def test_guardar_y_ver_devuelven_aviso_url(monkeypatch):
    monkeypatch.setattr(suscripcion, "URL_PUBLICA", "https://fisitaap.com")
    assert suscripcion._pasarela_salida()["aviso_url"] is True
    assert "return _pasarela_salida()" in inspect.getsource(suscripcion.admin_guardar_pasarela)
    assert "return _pasarela_salida()" in inspect.getsource(suscripcion.admin_ver_pasarela)
