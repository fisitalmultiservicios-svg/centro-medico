# -*- coding: utf-8 -*-
"""4.39, quinta vuelta de los arreglos de la comanda automática al cobrar (16 nov 2026). Una prueba por cada cambio, con los métodos
reales de caja.js en dos (o tres) «equipos» (el arnés y el servidor falso de tests/test_431_cobro_reclamo_pantallas.py, con el prefijo de
tests/test_439_revision_arreglos.py y las ayudas de tests/test_439_tercera_vuelta.py y tests/test_439_cuarta_vuelta.py: destinoDe e
impresoraDe reales, la Cocina como única impresora de comanda y cada comanda anotada).

- V1 la marca de otro equipo (fusionarAbierta y persistirCuenta) y la espera del bucle (emitirCobro y reclamarHab) solo cuentan platos que
  van a cocina (destinoDe) con una marca de envío de hace menos de 10 s: el «Envío a domicilio» que llegó enviado o una comanda de hace un
  minuto ya no hacen esperar 4 s; una comanda de recién, sí.
- V2 emitirCobro en una mesa (sin el bloque de la venta rápida), con el cobro ya pedido: si un plato que aquí está sin enviar ya figura
  enviado en el servidor con marca reciente (otro equipo tocó «Comanda» con la ventana de cobro ya abierta aquí), espera 4 s y la comanda
  de ese equipo sale. Sin otro equipo no espera; con todo enviado ni siquiera trae la lista.
- V3 reclamarHab: lo mismo al cargar una mesa a la habitación, en tramos de 200 ms (al cerrar la ventana deja de esperar y no carga).
- V4 cobrarParte y confirmarDividir («Cobrar estos platos»): esperan la comanda de otro equipo antes de partir la cuenta (o avisan y no
  dividen). Los casos con otro equipo están en tests/test_439_cuarta_vuelta.py (test_v4_...); aquí, sin otro equipo no se espera, y con los
  métodos de antes de esta vuelta se ve el defecto (la comanda de B no salía).
- V5 abrirPago con la ventana de la habitación y una parte en cobro: la parte vuelve a la cuenta (no queda colgada).
- V6 abrirDividir no abre con el cobro, la habitación o una parte abiertos después de su espera; abrirCargoHab no abre con «Dividir».
- V7 F9 no abre el cobro completo con «Dividir» abierto (y «Cobrar la parte 1» después cobra una vez).
- V8 emitirCobro: si el cobro se cerró mientras se esperaba cobroPermitido (modo cajero), sale sin quedar «cobrando» ni dar TypeError.
- V9 alDiaCuentaNueva: la cuenta abierta desde «Para llevar en espera» con el nombre automático repetido pasa al número siguiente, también
  en pantalla; con nombre propio no.
- V10 seguirIds: el aviso de la cuenta rehecha dice su nombre («Cuenta 1»), no «la cuenta de la cuenta».
Cada caso corre también, cuando muestra el defecto, con los métodos de ANTES de esta vuelta: se sacan de caja.js con la quinta vuelta deshecha
(QUINTA y _caja_sin_quinta de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la vuelta).
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import _linea, _metodo
from tests.test_439_cuarta_vuelta import AVISO_DIVIDIR, AVISO_DIVIDIR_7, CASOS_PARTE, UNO_Y_UNO
from tests.test_439_cuarta_vuelta import _correr as _correr4
from tests.test_439_revision_arreglos import COMANDA, EMITIR, RECLAMAR, SOLTAR
from tests.test_439_tercera_vuelta import AMBOS, FOLIOS, QUINTA, RECIENTE, REFRESCAR15, TERMINE, _caja_sin_quinta, _caja_sin_sexta

# los métodos que cambió la quinta vuelta (cada tripleta de QUINTA está en uno de ellos); abrirDividir es de una línea
CAMBIADOS = ("persistirCuenta(devolverId) {", "fusionarAbierta(motivo) {", "async alDiaCuentaNueva(id) {", "seguirIds(key, cambios) {",
             "async reclamarHab() {", "async cobrarParte(n) {", "async confirmarDividir() {", "async abrirPago() {", "async emitirCobro(otra) {",
             "async abrirCargoHab() {", "tecla(e) {")
DIVIDIR = "async abrirDividir() {"
NO_SALIERON_M6 = "No salieron en la comanda: Casado, Postre. En otro equipo ya se habían quitado o cobrado de Mesa 6."
NO_SALIO_M6 = "No salió en la comanda: Casado. En otro equipo ya se había quitado o cobrado de Mesa 6."
DOS_Y_DOS = ["Casado×2", "Postre×2"]


def _antes():
    """Los métodos que cambió la quinta vuelta, como estaban antes de ella: van al final de la fuente y pisan a los de ahora."""
    k = _caja_sin_quinta()
    return tuple(_metodo(k, c) for c in CAMBIADOS) + (_linea(k, DIVIDIR),)


AYUDAS = r"""
const AVISO_DIVIDIR = @AVISO_DIVIDIR@, AVISO_DIVIDIR_7 = @AVISO_DIVIDIR_7@;
// 4.39 (séptima vuelta, X6): el aviso de «Dividir» con su texto de ahora o con el de antes (las versiones «de antes» dan el de antes); cada prueba
// dice cuál espera
const avisosDividir = vm => avisos(vm).filter(t => t === AVISO_DIVIDIR || t === AVISO_DIVIDIR_7);
// una marca de envío de hace un minuto (una comanda que ya salió hace rato)
const VIEJA = () => new Date(Date.now() - 60000).toISOString();
// cuántas veces trae ESE equipo la lista de cuentas (mock.refrescar)
const listas = vm => { const o = { n: 0 }, r0 = vm.A.mock.refrescar; vm.A.mock.refrescar = function (...x) { o.n++; return r0.apply(this, x); }; return o; };
// el estado de la pantalla con «Dividir»; la Mesa 6 con 2 Casados y 2 Postres
const est = vm => ({ ...estado(vm), dividir: !!vm.dividir });
const DOS_Y_DOS = () => [{ ...CASADO(), cantidad: 2 }, { ...POSTRE(), cantidad: 2 }];
const quienes = a => IMPRESOS.map(x => [quien(x[0], a), x[1]]);
const cobrados = a => hechos().map(h => [quien(h[0], a), h[2]]);
"""


def _correr(tmp_path, casos, antes=()):
    return _correr4(tmp_path, AYUDAS.replace("@AVISO_DIVIDIR@", json.dumps(AVISO_DIVIDIR)).replace("@AVISO_DIVIDIR_7@", json.dumps(AVISO_DIVIDIR_7)) + casos, antes=antes)


# ================================================================================================================ V1: qué hace esperar
CASOS_V1 = r"""
// la cuenta guardada sin mesa, abierta en A y en B; A le agrega un Postre (sin guardar: sale a cocina al cobrar). B toca «Comanda»:
//  envio: el Casado ya estaba enviado (hace un minuto) y B solo tiene por mandar el «Envío a domicilio» (no va a cocina)
//  vieja: B manda el Casado y su comanda sale; la marca de envío del servidor queda de hace un minuto (como si A cobrara un minuto después)
//  reciente: B manda el Casado y su comanda sale (la marca es de ahora)
// A cobra según @VIA@: sinc (sincroniza y abre el cobro: la marca de fusionarAbierta), bucle (el cobro ya estaba abierto: el bucle de emitirCobro)
// o hab (con la ventana de la habitación abierta: el bucle de reclamarHab)
async function v1(que, via) {
  const id = await guardada(que === 'envio' ? [{ ...CASADO(), enviado: VIEJA(), ronda: 1 }, ENVIO()] : [CASADO()]);
  const a = await abierta(id), b = await abierta(id); HOJAS.length = 0;
  a.lineas.push(POSTRE());
  if (via === 'bucle') await a.abrirPago(); else if (via === 'hab') a.habCargo = HAB();
  await b.enviarComanda(); await b.A.mock.guardarTodo();
  if (que === 'vieja') { const c = S.items.find(x => x.id === id); for (const l of c.lineas) if (l.enviado) l.enviado = VIEJA(); S.version++; }
  if (via === 'sinc') { await a.sincronizar(); await a.abrirPago(); }
  const marca0 = !!a._marcaAjena && a._marcaAjena.id === id;
  const t0 = Date.now(); if (via === 'hab') await cargar(a); else await a.cobrar(); const t = Date.now() - t0;
  const marca = !!a._marcaAjena && a._marcaAjena.id === id;
  await hastaLibre(); await a.A.mock.guardarTodo();
  return { t, marca0, marca, impresos: quienes(a), hechos: cobrados(a), folios: folios(), hojas: HOJAS.slice(), servidor: servidor(), libre: libre(), pago: !!a.pago, hab: !!a.habCargo };
}
for (const que of @QUE@) out[que] = await v1(que, @VIA@);
"""
CON_ENVIO = ["Casado×1", "Envío a domicilio×1", "Postre×1"]
FOLIOS_ENVIO = ["Casado (Cuenta 1)", "Envío a domicilio (Cuenta 1)", "Postre (Cuenta 1)"]


def _v1(r, que, via, espera):
    x = r[que]
    if espera:
        assert x["t"] >= 3500, (que, via, x)                                                             # la espera de 4 s
    else:
        assert x["t"] < 2000, (que, via, x)
    # lo demás no cambia: la comanda de B (si mandó un plato), la del Postre al cobrar (o cargar) y un comprobante (o un cargo)
    impresos = [["A", ["Postre×1"]]] if que == "envio" else [["B", ["Casado×1"]], ["A", ["Postre×1"]]]
    assert x["impresos"] == impresos and x["servidor"] == [] and x["libre"] is True and x["pago"] is False and x["hab"] is False, (que, via, x)
    if via == "hab":
        assert x["hechos"] == [] and x["folios"] == (FOLIOS_ENVIO if que == "envio" else ["Casado (Cuenta 1)", "Postre (Cuenta 1)"]), (que, via, x)
    else:
        assert x["hechos"] == [["A", CON_ENVIO if que == "envio" else ["Casado×1", "Postre×1"]]] and x["folios"] == [], (que, via, x)


@pytest.mark.parametrize("via", ["sinc", "bucle", "hab"])
def test_v1_solo_espera_por_platos_de_cocina_con_comanda_reciente_en_node(tmp_path, via):
    casos = CASOS_V1.replace("@VIA@", json.dumps(via))
    r = _correr(tmp_path / "ahora", casos.replace("@QUE@", json.dumps(["envio", "vieja", "reciente"])))
    # el envío (sin destino) o una comanda de hace un minuto: ni marca ni espera
    for que in ("envio", "vieja"):
        assert r[que]["marca0"] is False and r[que]["marca"] is False, (que, r[que])
        _v1(r, que, via, espera=False)
    # una comanda de recién: la marca (al sincronizar, o al juntar en el bucle) y la espera de 4 s
    assert r["reciente"]["marca"] is True and r["reciente"]["marca0"] is (via == "sinc"), r["reciente"]
    _v1(r, "reciente", via, espera=True)

    # antes de esta vuelta: el envío o la comanda vieja también dejaban la marca y hacían esperar 4 s
    v = _correr(tmp_path / "antes", casos.replace("@QUE@", json.dumps(["envio", "vieja"])), antes=_antes())
    for que in ("envio", "vieja"):
        assert v[que]["marca"] is True, (que, v[que])
        _v1(v, que, via, espera=True)


# ================================================================================================================ V2 y V3: la mesa
CASOS_MESA = r"""
// la Mesa 6 con el Casado guardado sin enviar (o, con `enviada`, ya enviado hace un minuto), abierta en A y en B. A abre la ventana de cobro (o, con
// `hab`, la de la habitación); con `otro`, B toca «Comanda» con su revisión lenta (1,5 s) y, en cuanto su guardado llegó al servidor, A cobra (o
// toca «Cargar»). `cierra`: a los 1,5 s de tocar «Cargar», A cierra la ventana de la habitación; después cobra en la caja
async function mesaCobro(o) {
  const [id, a, b] = await mesaGuardada([o.enviada ? { ...CASADO(), enviado: VIEJA(), ronda: 1 } : CASADO()]); HOJAS.length = 0;
  if (o.hab) a.habCargo = HAB(); else await a.abrirPago();
  const lis = listas(a);
  let pb = null, suelta = () => {};
  if (o.otro) { suelta = lento(b, 1500); pb = b.enviarComanda(); await hasta(() => enviadaEnServidor(id)); }
  const t0 = Date.now(); let tc = null;
  if (o.cierra) { a.habCargo.reserva_id = 1; const p = a.cargarAHabitacion(); await espera(1500); const t1 = Date.now(); a.habCargo = null; await p; tc = Date.now() - t1; }
  else if (o.hab) await cargar(a); else await a.cobrar();
  const t = Date.now() - t0, consultas = lis.n;
  if (pb) await pb; suelta(); await hastaLibre(); await a.A.mock.guardarTodo(); await b.A.mock.guardarTodo();
  const r = { t, tc, consultas, impresos: quienes(a), noSalioB: noSalio(b), hechos: cobrados(a), folios: folios(), hojas: HOJAS.slice(), servidor: servidor().map(x => x.platos),
    orden: orden(a.nEq), libre: libre(), fin: est(a) };
  if (o.cierra) { await a.abrirPago(); if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo(); r.luego = { hechos: cobrados(a), impresos: quienes(a), folios: folios(), servidor: servidor() }; }
  return r;
}
"""
CASOS_V2 = CASOS_MESA + r"""
out.otro = await mesaCobro({ otro: true });
out.solo = await mesaCobro({});
out.enviada = await mesaCobro({ enviada: true });
"""
CASOS_V3 = CASOS_MESA + r"""
out.otro = await mesaCobro({ hab: true, otro: true });
out.cierra = await mesaCobro({ hab: true, otro: true, cierra: true });
out.solo = await mesaCobro({ hab: true });
"""


def test_v2_la_mesa_con_el_cobro_abierto_espera_la_comanda_de_otro_equipo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V2)
    o = r["otro"]
    # una comanda (la de B, que encontró la cuenta abierta) y un comprobante (el de A), con la espera de 4 s; A trajo la lista una vez.
    # 4.39 (sexta vuelta, W11): y otra después de esperar, para juntar lo que B guardó mientras tanto (si la cuenta cambió, no se cobra)
    assert o["impresos"] == [["B", ["Casado×1"]]] and o["noSalioB"] == [] and o["hechos"] == [["A", ["Casado×1"]]], o
    assert o["servidor"] == [] and o["libre"] is True and o["fin"]["pago"] is False and o["consultas"] == 2, o
    assert 3900 <= o["t"] < 7000 and o["orden"][:2] == [RECLAMAR, EMITIR] and COMANDA not in o["orden"], o
    s = r["solo"]
    # sin otro equipo: trae la lista una vez y no espera (en una mesa el cobro no manda comanda)
    assert s["t"] < 2000 and s["consultas"] == 1 and s["impresos"] == [] and s["hechos"] == [["A", ["Casado×1"]]] and s["servidor"] == [], s
    e = r["enviada"]
    # con todo enviado: ni trae la lista ni espera
    assert e["t"] < 2000 and e["consultas"] == 0 and e["impresos"] == [] and e["hechos"] == [["A", ["Casado×1"]]] and e["servidor"] == [], e

    # emitirCobro de antes: A cobraba sin esperar y cerraba la cuenta; la revisión de B ya no la encontraba: cobrado y nunca en cocina
    v = _correr(tmp_path / "antes", CASOS_V2, antes=_antes())
    vo = v["otro"]
    assert vo["t"] < 2000 and vo["impresos"] == [] and vo["noSalioB"] == [NO_SALIO_M6] and vo["hechos"] == [["A", ["Casado×1"]]] and vo["consultas"] == 0, vo


def test_v3_la_mesa_a_la_habitacion_espera_la_comanda_de_otro_equipo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V3)
    o, s = r["otro"], r["solo"]
    # una comanda (la de B) y un cargo (el de A), con la espera de 4 s. La lista se trae las mismas veces que sin otro equipo (una para la
    # revisión de V3 y una después del cargo) y, 4.39 (sexta vuelta, W11), una más después de esperar, para juntar lo que B guardó mientras
    # tanto (si la cuenta cambió, no se carga nada)
    assert o["impresos"] == [["B", ["Casado×1"]]] and o["noSalioB"] == [] and o["folios"] == ["Casado (Mesa 6)"] and o["hechos"] == [], o
    assert o["servidor"] == [] and o["libre"] is True and o["fin"]["hab"] is False and 3900 <= o["t"] < 7000 and o["consultas"] == s["consultas"] + 1, o
    assert o["orden"] == [RECLAMAR, SOLTAR], o
    c = r["cierra"]
    # cerrar la ventana durante la espera la corta: no carga, suelta el cobro pedido; la comanda de B sale y después se cobra una vez en la caja
    assert c["tc"] < 600 and c["folios"] == [] and c["orden"] == [RECLAMAR, SOLTAR] and c["libre"] is True and c["servidor"] == [["Casado×1"]], c
    assert c["impresos"] == [["B", ["Casado×1"]]] and c["fin"]["hab"] is False and c["fin"]["habEnCurso"] is False, c
    assert c["luego"]["hechos"] == [["A", ["Casado×1"]]] and c["luego"]["folios"] == [] and c["luego"]["impresos"] == [["B", ["Casado×1"]]] and c["luego"]["servidor"] == [], c
    # sin otro equipo no espera (en una mesa el cargo no manda comanda)
    assert s["t"] < 2000 and s["folios"] == ["Casado (Mesa 6)"] and s["impresos"] == [] and s["servidor"] == [], s

    # reclamarHab de antes: A cargaba sin esperar; la comanda de B no salía (cargado y nunca en cocina). Sin la revisión de V3, una consulta
    # menos (solo la de después del cargo)
    v = _correr(tmp_path / "antes", CASOS_V3, antes=_antes())
    vo = v["otro"]
    assert vo["t"] < 2000 and vo["impresos"] == [] and vo["noSalioB"] == [NO_SALIO_M6] and vo["folios"] == ["Casado (Mesa 6)"], vo
    assert s["consultas"] == v["solo"]["consultas"] + 1, (s, v["solo"])
    # y cerrar la ventana a los 1,5 s ya no servía: el cargo estaba hecho
    assert v["cierra"]["folios"] == ["Casado (Mesa 6)"] and v["cierra"]["impresos"] == [], v["cierra"]


# ================================================================================================================ V4: «Cobrar parte» y «Dividir»
CASOS_V4_SOLO = r"""
// sin otro equipo: la Mesa 6 con 2 Casados y 2 Postres sin enviar, solo en A: «Cobrar parte 1 de 2», «Dividir» en 2 partes iguales o «Dividir →
// Cobrar estos platos» con un Casado y un Postre; se cobra
for (const como of ['parte', 'partes', 'dividir']) {
  const [id, a] = await mesaGuardada(DOS_Y_DOS());
  if (como !== 'parte') await a.abrirDividir();
  const t0 = Date.now();
  if (como === 'parte') await a.cobrarParte(2);
  else if (como === 'partes') { a.dividir.modo = 'partes'; a.dividir.partes = 2; await a.confirmarDividir(); }
  else { a.dividir.destino = 'cobrar'; a.dividir.sel = { 0: 1, 1: 1 }; await a.confirmarDividir(); }
  await conPago(a); const t = Date.now() - t0, parcial = !!a.cobroParcial;
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out[como] = { t, parcial, hechos: cobrados(a), impresos: impresos(), avisos: avisosDividir(a), srv: srv(), fin: est(a), libre: libre() };   // 4.39 (séptima vuelta): los dos textos
}
"""


def test_v4_sin_otro_equipo_cobrar_parte_y_dividir_no_esperan_en_node(tmp_path):
    r = _correr(tmp_path, CASOS_V4_SOLO)
    for como in ("parte", "partes", "dividir"):
        x = r[como]
        assert x["t"] < 2000 and x["parcial"] is True and x["avisos"] == [] and x["hechos"] == [["A", UNO_Y_UNO]] and x["impresos"] == [], (como, x)
        partes = None if como == "dividir" else {"total": 2, "cobradas": 1}
        assert x["srv"] == [["Mesa 6", UNO_Y_UNO, partes]] and x["fin"]["pago"] is False and x["fin"]["parcial"] is False and x["libre"] is True, (como, x)


@pytest.mark.parametrize("como", ["parte", "partes", "dividir"])
def test_v4_antes_la_comanda_de_otro_equipo_no_salia_en_node(tmp_path, como):
    """Los casos de tests/test_439_cuarta_vuelta.py (test_v4_...) con los métodos de antes de esta vuelta: A partía la cuenta enseguida y la
    revisión de B ya no encontraba sus platos: la parte se cobraba, lo demás quedaba marcado como enviado y nada llegaba a cocina."""
    v = _correr(tmp_path, CASOS_PARTE.replace("@COMO@", json.dumps(como)).replace("@AVISO@", json.dumps(AVISO_DIVIDIR)), antes=_antes())["r"]
    assert v["impresos"] == [] and v["noSalioB"] == [NO_SALIERON_M6] and v["hechos"] == [["A", UNO_Y_UNO]] and v["avisos"] == [], v
    assert v["ms"] < 2500, v                                                                            # sin esperar


# ================================================================================================================ V5, V6 y V7: «Dividir», cobro y habitación
CASOS_V567 = r"""
// (lista_hab) el caso del revisor: se toca «Dividir» (la lista tarda: abrirDividir espera alDiaParaCobrar) y mientras tanto «Habitación»; «Cargar»
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  const suelta = lento(a, 400);
  const pd = a.abrirDividir(); await espera(60); await a.abrirCargoHab(); const medio = est(a);
  await pd; suelta(); const tras = est(a);
  await cargar(a);
  out.lista_hab = { medio, tras, fin: est(a), folios: folios(), hechos: hechos().length, impresos: impresos(), srv: srv(), libre: libre() }; }
// (dividir_hab) con «Dividir» abierto se toca «Habitación»: no se abre; se cierra «Dividir», se abre la habitación y se carga
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  await a.abrirDividir(); await a.abrirCargoHab(); const tras = est(a);
  a.dividir = null; await a.abrirCargoHab(); const luego = est(a);
  await cargar(a);
  out.dividir_hab = { tras, luego, avisos: conTexto(a, TERMINE), fin: est(a), folios: folios(), hechos: hechos().length, impresos: impresos(), srv: srv() }; }
// (hab_espera) «Habitación» espera cobroPermitido (lento) y mientras tanto se abre «Dividir»; después «Cobrar estos platos» (el Casado) y se cobra.
// Los dos platos ya estaban enviados a cocina (hace un minuto)
{ const id = await guardada([{ ...CASADO(), enviado: VIEJA(), ronda: 1 }, { ...POSTRE(), enviado: VIEJA(), ronda: 1 }]); const a = await abierta(id);
  const cp0 = a.cobroPermitido; a.cobroPermitido = async acc => { if (acc === 'cargar a la habitación') await espera(300); return cp0(acc); };
  const ph = a.abrirCargoHab(); await espera(30); await a.abrirDividir(); await ph; const tras = est(a);
  a.cobroPermitido = cp0;
  a.dividir.destino = 'cobrar'; a.dividir.sel = { 0: 1 }; await a.confirmarDividir(); await conPago(a); const parte = est(a);
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.hab_espera = { tras, parte, fin: est(a), hechos: cobrados(a), folios: folios(), impresos: impresos(), srv: srv(), libre: libre() }; }
// (f9) la Mesa 6 con 2 Casados y 2 Postres: con «Dividir» abierto, F9; después «Cobrar la parte 1» de 2 y se cobra (con los métodos de antes, si
// quedó abierto el cobro completo, «Cobrar» lo cobra)
{ const [id, a] = await mesaGuardada(DOS_Y_DOS());
  await a.abrirDividir(); const f9 = tecla(a, 'F9'); await espera(100); const tras = est(a);
  a.dividir.modo = 'partes'; a.dividir.partes = 2; await a.confirmarDividir(); await conPago(a); const parte = est(a);
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.f9 = { f9, tras, parte, fin: est(a), hechos: cobrados(a), srv: srv(), libre: libre() }; }
// (v5) simulado: «Dividir → Cobrar estos platos» (el Casado) espera cobroPermitido (lento) y mientras tanto aparece la ventana de la habitación
// (abrirCargoHab ya no la abre con «Dividir»): la cuenta se parte y abrirPago, con la habitación abierta, devuelve la parte a la cuenta; «Cargar»
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  await a.abrirDividir(); a.dividir.destino = 'cobrar'; a.dividir.sel = { 0: 1 };
  const cp0 = a.cobroPermitido; a.cobroPermitido = async acc => { if (acc === 'cobrar') await espera(300); return cp0(acc); };
  const pd = a.confirmarDividir(); await espera(50); a.habCargo = HAB(); await pd; await espera(100); await hastaLibre(); await a.A.mock.guardarTodo(); await hastaLibre();
  a.cobroPermitido = cp0; const tras = est(a), s1 = srv();
  await cargar(a);
  out.v5 = { tras, s1, fin: est(a), folios: folios(), hechos: hechos().length, impresos: impresos(), srv: srv(), libre: libre() }; }
"""
INTACTA = [["Cuenta 1", AMBOS, None]]


def test_v5_v6_v7_dividir_cobro_y_habitacion_cruzados_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V567)
    x = r["lista_hab"]
    # la habitación se abrió mientras «Dividir» esperaba la lista: «Dividir» ya no se abre encima; un cargo y una comanda, con la cuenta entera
    assert x["medio"]["hab"] is True and x["tras"]["hab"] is True and x["tras"]["dividir"] is False and x["tras"]["pago"] is False, x
    assert x["folios"] == FOLIOS and x["hechos"] == 0 and x["impresos"] == [AMBOS] and x["srv"] == [] and x["libre"] is True and x["fin"]["dividir"] is False, x
    d = r["dividir_hab"]
    # con «Dividir» abierto, «Habitación» avisa y no abre; cerrado «Dividir», abre y se carga una vez
    assert d["tras"]["dividir"] is True and d["tras"]["hab"] is False and d["avisos"] == [TERMINE] and d["luego"]["hab"] is True, d
    assert d["folios"] == FOLIOS and d["hechos"] == 0 and d["impresos"] == [AMBOS] and d["srv"] == [], d
    h = r["hab_espera"]
    # «Dividir» se abrió mientras la habitación esperaba: la habitación no se abre; «Cobrar estos platos» cobra el Casado una vez y el Postre
    # queda en la cuenta (los dos ya estaban en cocina: ninguna comanda)
    assert h["tras"]["dividir"] is True and h["tras"]["hab"] is False and h["parte"]["parcial"] is True and h["parte"]["hab"] is False, h
    assert h["hechos"] == [["A", ["Casado×1"]]] and h["folios"] == [] and h["impresos"] == [] and h["srv"] == [["Cuenta 1", ["Postre×1"], None]] and h["libre"] is True, h
    f = r["f9"]
    # F9 con «Dividir» abierto no abre el cobro completo; «Cobrar la parte 1» abre la parte y se cobra una vez (la mitad)
    assert f["f9"] is True and f["tras"]["pago"] is False and f["tras"]["dividir"] is True, f
    assert f["parte"]["parcial"] is True and f["parte"]["dividir"] is False and f["hechos"] == [["A", UNO_Y_UNO]], f
    assert f["srv"] == [["Mesa 6", UNO_Y_UNO, {"total": 2, "cobradas": 1}]] and f["fin"]["pago"] is False and f["libre"] is True, f
    v5 = r["v5"]
    # la parte vuelve a la cuenta (ni parte colgada ni ventana de cobro) y se carga entera, una vez
    assert v5["tras"] == {**v5["tras"], "pago": False, "parcial": False, "hab": True, "dividir": False, "platos": AMBOS} and v5["s1"] == INTACTA, v5
    assert v5["folios"] == FOLIOS and v5["hechos"] == 0 and v5["impresos"] == [AMBOS] and v5["srv"] == [] and v5["libre"] is True, v5

    # antes de esta vuelta: «Dividir» se abría encima de la habitación (y la habitación encima de «Dividir»); F9 abría el cobro completo debajo
    # de «Dividir» y «Cobrar la parte 1» no hacía nada: «Cobrar» cobraba la cuenta entera; la parte quedaba colgada (sin ventana de cobro)
    v = _correr(tmp_path / "antes", CASOS_V567, antes=_antes())
    assert v["lista_hab"]["tras"]["hab"] is True and v["lista_hab"]["tras"]["dividir"] is True, v["lista_hab"]
    assert v["dividir_hab"]["tras"]["hab"] is True and v["dividir_hab"]["tras"]["dividir"] is True and v["dividir_hab"]["avisos"] == [], v["dividir_hab"]
    assert v["hab_espera"]["tras"]["hab"] is True and v["hab_espera"]["tras"]["dividir"] is True, v["hab_espera"]
    vf = v["f9"]
    assert vf["tras"]["pago"] is True and vf["tras"]["dividir"] is True and vf["parte"]["parcial"] is False and vf["hechos"] == [["A", DOS_Y_DOS]], vf
    assert v["v5"]["tras"]["parcial"] is True and v["v5"]["tras"]["pago"] is False and v["v5"]["s1"] == [["Cuenta 1", ["Postre×1"], None]], v["v5"]


CASOS_LISTA_F9 = r"""
// la Mesa 6 con 2 Casados y 2 Postres, solo en A. Se toca «Dividir» (la lista tarda: abrirDividir espera alDiaParaCobrar) y, mientras tanto, F9:
// todavía no hay «Dividir» abierto, así que F9 abre el cobro (abrirPago también espera la lista). Después, si «Dividir» quedó abierto, «Cobrar la
// parte 1» de 2; y si hay una ventana de cobro, «Cobrar»
{ const [id, a] = await mesaGuardada(DOS_Y_DOS());
  const suelta = lento(a, 400);
  const pd = a.abrirDividir(); await espera(60); const f9 = tecla(a, 'F9'); await pd; await espera(700); suelta(); const tras = est(a);
  if (a.dividir) { a.dividir.modo = 'partes'; a.dividir.partes = 2; await a.confirmarDividir(); await conPago(a); }
  const parte = est(a);
  if (a.pago) await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.r = { f9, tras, parte, fin: est(a), hechos: cobrados(a), srv: srv(), libre: libre() }; }
"""


# 4.39 (quinta vuelta): era un defecto real (xfail estricto). V6 hace que «Dividir» no se abra si al terminar su espera ya está abierto el cobro, y
# V7 que F9 no abra el cobro con «Dividir» ya abierto; pero F9 (o «Cobrar») tocado MIENTRAS «Dividir» espera la lista (hasta 1,5 s) abría el cobro
# completo: abrirPago también espera la lista (alDiaParaCobrar), terminaba después de abrirDividir y no miraba si «Dividir» se abrió mientras
# tanto. Quedaban las dos ventanas a la vez; «Cobrar la parte 1» no hacía nada y «Cobrar» cobraba la cuenta entera (Casado ×2 y Postre ×2).
# 4.39 (sexta vuelta, W1): abrirPago, después de sus esperas, no abre el cobro con «Dividir» abierto (dio XPASS). Ahora es una prueba normal con
# lo que se espera: solo «Dividir» queda abierto y «Cobrar la parte 1» de 2 cobra la mitad, una vez. Más casos (y la versión de antes, donde se
# ve el defecto) en tests/test_439_sexta_vuelta.py
def test_f9_mientras_dividir_espera_la_lista_en_node(tmp_path):
    r = _correr(tmp_path, CASOS_LISTA_F9)["r"]
    assert r["f9"] is True and r["tras"]["dividir"] is True and r["tras"]["pago"] is False and r["tras"]["parcial"] is False, r   # solo «Dividir»
    assert r["tras"]["platos"] == DOS_Y_DOS and r["tras"]["cobrando"] is False and r["tras"]["enCurso"] is False, r
    assert r["parte"]["parcial"] is True and r["parte"]["pago"] is True and r["parte"]["dividir"] is False and r["parte"]["platos"] == UNO_Y_UNO, r
    assert r["hechos"] == [["A", UNO_Y_UNO]] and r["libre"] is True and r["fin"]["pago"] is False and r["fin"]["parcial"] is False, r   # la mitad, una vez
    assert r["srv"] == [["Mesa 6", UNO_Y_UNO, {"total": 2, "cobradas": 1}]], r


# ================================================================================================================ V8: el cobro cerrado mientras se espera el turno
CASOS_V8 = r"""
// modo cajero: «Cobrar» espera cobroPermitido (lento: se toma el turno) y mientras tanto la cajera cierra el cobro (Cancelar); después vuelve a
// abrirlo y cobra
{ const id = await guardada([CASADO(), POSTRE()]); const a = await abierta(id);
  await a.abrirPago();
  const cp0 = a.cobroPermitido; a.cobroPermitido = async acc => { if (acc === 'cobrar') await espera(300); return cp0(acc); };
  let error = null; const pc = a.cobrar().catch(e => { error = String((e && e.message) || e); }); await espera(50); a.cerrarPago(); await pc;
  const tras = { ...est(a), error, hechos: hechos().length, impresos: impresos(), orden: orden(a.nEq) };
  a.cobroPermitido = cp0;
  await a.abrirPago(); await a.cobrar(); await hastaLibre(); await a.A.mock.guardarTodo();
  out.v8 = { tras, fin: est(a), hechos: cobrados(a), impresos: impresos(), servidor: servidor(), libre: libre() }; }
"""


def test_v8_el_cobro_cerrado_mientras_se_espera_el_turno_no_traba_la_caja_en_node(tmp_path):
    x = _correr(tmp_path / "ahora", CASOS_V8)["v8"]
    t = x["tras"]
    # sale sin error y sin quedar «cobrando»; nada se emitió ni se mandó a cocina; la cuenta sigue en pantalla
    assert t["error"] is None and t["cobrando"] is False and t["enCurso"] is False and t["pago"] is False and t["platos"] == AMBOS, t
    assert t["hechos"] == 0 and t["impresos"] == [] and t["orden"] == [], t
    # después se cobra normal: una comanda y un comprobante
    assert x["hechos"] == [["A", AMBOS]] and x["impresos"] == [AMBOS] and x["servidor"] == [] and x["libre"] is True and x["fin"]["cobrando"] is False, x

    # emitirCobro de antes: seguía con el cobro cerrado: TypeError, la caja quedaba «cobrando» y el segundo cobro no hacía nada
    v = _correr(tmp_path / "antes", CASOS_V8, antes=_antes())["v8"]
    assert v["tras"]["error"] is not None and "tipo_documento" in v["tras"]["error"] and v["tras"]["cobrando"] is True, v
    assert v["hechos"] == [] and v["fin"]["cobrando"] is True, v


# ================================================================================================================ V9 y V10: el nombre de la cuenta rehecha
CASOS_V9 = r"""
// G guarda una cuenta con el Casado («Cuenta 1», o «Ana»); A la abre desde «Para llevar en espera» (en pantalla, el nombre de la cuenta) y manda
// la comanda; B la cobra; C hace otra venta rápida con el Postre y manda su comanda (para C no hay otra abierta: otra «Cuenta 1», u otra «Ana»); A,
// sin sincronizar, agrega la Limonada y toca «Comanda»: el servidor rehace la cuenta de A con otro id. Después todos sincronizan; A agrega un
// Postre y guarda
async function v9(nombre) {
  nuevo(); const g = venta(await equipo()); if (nombre) g.nombreEspera = nombre; g.lineas.push(CASADO()); g.guardarCuenta(); await g.A.mock.guardarTodo();
  const id1 = S.items[0].id;
  const a = venta(await equipo()), b = venta(await equipo());
  await a.sincronizar(); a.recuperar(a.espera.find(x => x.id === id1)); const nombre0 = a.nombreEspera;
  await a.enviarComanda(); await a.A.mock.guardarTodo();
  await b.sincronizar(); b.recuperar(b.espera.find(x => x.id === id1)); await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  const c = venta(await equipo()); if (nombre) c.nombreEspera = nombre; c.lineas.push(POSTRE()); await c.enviarComanda(); await c.A.mock.guardarTodo();
  a.lineas.push(LIMONADA()); await a.enviarComanda(); await a.A.mock.guardarTodo();
  await a._alDiaNueva; await a.A.mock.guardarTodo();
  const r = { id1, nombre0, idA: a.esperaId, nombreA: a.nombreEspera, enServidor: nombres() };
  await b.sincronizar(); await c.sincronizar(); await a.sincronizar();
  Object.assign(r, { nombreA2: a.nombreEspera, enA: nombres(a), enB: nombres(b), enC: nombres(c), servidor: servidor().map(x => [x.nombre, x.platos]) });
  a.lineas.push(POSTRE()); a.persistirCuenta(); await a.A.mock.guardarTodo();
  r.luego = nombres(); r.nombreA3 = a.nombreEspera;
  return r;
}
out.automatico = await v9('');
out.propio = await v9('Ana');
// V10: la venta rápida manda la comanda del Casado (queda guardada como «Cuenta 1», sin nombre en pantalla); B la cobra; A, sin sincronizar,
// agrega la Limonada y toca «Comanda»: el aviso de la cuenta rehecha
{ nuevo(); const a = venta(await equipo()), b = venta(await equipo());
  a.lineas.push(CASADO()); await a.enviarComanda(); await a.A.mock.guardarTodo(); const id1 = a.esperaId;
  await b.sincronizar(); b.recuperar(b.espera.find(x => x.id === id1)); await b.abrirPago(); await b.cobrar(); await hastaLibre(); await b.A.mock.guardarTodo();
  a.lineas.push(LIMONADA()); await a.enviarComanda(); await a.A.mock.guardarTodo(); await a._alDiaNueva;
  out.v10 = { nombreA: a.nombreEspera, avisos: avisos(a).filter(t => t.startsWith('La cuenta de ')), servidor: servidor().map(x => [x.nombre, x.platos]) }; }
"""
REHECHA = "La cuenta de {0} se cobró o se cerró en otro equipo mientras usted agregaba platos. Lo que agregó quedó en {0} como cuenta nueva."


def test_v9_v10_el_nombre_de_la_cuenta_rehecha_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_V9)
    x = r["automatico"]
    # la cuenta rehecha de A (id 3) repetía «Cuenta 1» (la de C, id 2) y en pantalla tenía ese mismo nombre automático (la abrió desde «Para
    # llevar en espera»): pasa a «Cuenta 3» (la regla de la 4.38) en pantalla, en el servidor y en los otros equipos, y el guardado siguiente
    # lo conserva
    renombrada = [[2, "Cuenta 1"], [3, "Cuenta 3"]]
    assert x["nombre0"] == "Cuenta 1" and x["idA"] == 3 and x["nombreA"] == "Cuenta 3" and x["nombreA2"] == "Cuenta 3" and x["nombreA3"] == "Cuenta 3", x
    assert x["enServidor"] == renombrada and x["enA"] == renombrada and x["enB"] == renombrada and x["enC"] == renombrada and x["luego"] == renombrada, x
    assert x["servidor"] == [["Cuenta 1", ["Postre×1"]], ["Cuenta 3", ["Limonada×1"]]], x
    y = r["propio"]
    # con nombre propio no se renombra (la regla es solo para «Cuenta N»)
    ana = [[2, "Ana"], [3, "Ana"]]
    assert y["nombre0"] == "Ana" and y["nombreA"] == "Ana" and y["enServidor"] == ana and y["enB"] == ana and y["luego"] == ana and y["nombreA3"] == "Ana", y
    z = r["v10"]
    # V10: el aviso con el nombre de la cuenta (la venta rápida guardada no tiene nombre en pantalla)
    assert z["avisos"] == [REHECHA.format("Cuenta 1")] and z["servidor"] == [["Cuenta 1", ["Limonada×1"]]], z

    # antes de esta vuelta: quedaban dos «Cuenta 1» abiertas (y A seguía con «Cuenta 1» en pantalla); el aviso decía «La cuenta de la cuenta»
    v = _correr(tmp_path / "antes", CASOS_V9, antes=_antes())
    assert v["automatico"]["enServidor"] == [[2, "Cuenta 1"], [3, "Cuenta 1"]] and v["automatico"]["nombreA"] == "Cuenta 1", v["automatico"]
    assert v["automatico"]["enB"] == [[2, "Cuenta 1"], [3, "Cuenta 1"]] and v["automatico"]["luego"] == [[2, "Cuenta 1"], [3, "Cuenta 1"]], v["automatico"]
    assert v["v10"]["avisos"] == [REHECHA.format("la cuenta")], v["v10"]


# ================================================================================================================ contrato
def test_contrato_de_la_quinta_vuelta():
    # 4.39 (sexta vuelta): «ahora» es caja.js sin la sexta vuelta (la sexta cambió líneas de varios de estos métodos: las marcas, los bucles, V2, V3,
    # V4, V4b, abrirPago, emitirCobro, alDiaCuentaNueva); lo de la sexta está en tests/test_439_sexta_vuelta.py
    k, k0 = _caja_sin_sexta(), _caja_sin_quinta()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    metodos[DIVIDIR] = "    " + _linea(k, DIVIDIR)
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    antes[DIVIDIR] = "    " + _linea(k0, DIVIDIR)
    # cada tripleta de QUINTA: «lo de ahora» está en caja.js las veces anotadas, todas dentro de los métodos cambiados; cada método cambió
    for viejo, nuevo, veces in QUINTA:
        assert k.count(nuevo) == veces and k0.count(viejo) >= veces and k0.count(nuevo) == 0, nuevo[:120]
        assert sum(m.count(nuevo) for m in metodos.values()) == veces, nuevo[:120]
    for c in metodos:
        assert metodos[c] != antes[c], c
    # fuera de ellos, caja.js no cambió
    resto, resto0 = k, k0
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c].strip(), ""), resto0.replace(antes[c].strip(), "")
    assert resto == resto0
    # V1: la condición de «reciente» en las dos marcas, los dos bucles y las cuatro revisiones nuevas; el refresco corto en las cuatro revisiones
    assert k.count(RECIENTE) == 8 and k0.count(RECIENTE) == 0 and k.count(REFRESCAR15) == 4
    e, rh = metodos["async emitirCobro(otra) {"], metodos["async reclamarHab() {"]
    # V8: justo después de esperar el turno y antes de «cobrando»
    assert e.index("if (!(await this.cobroPermitido('cobrar'))) { this.cerrarPago(); return; }") < e.index("\n      if (!this.pago) return;") < e.index("this.cobrando = true;")
    # V2: con el cobro ya pedido (después del reclamo de la cuenta guardada) y antes de emitir; la espera, de 4 s
    v2 = e.index("if (reclamar && !rcPedido && rc && rc.clave && this.esRestaurante && !this.cobroParcial && esperaId !== null")
    assert e.index("if (reclamar && !rcPedido) { try { rc = await this.reclamarCobro(lineasCobradas); }") < v2 < e.index("let doc = null, body = null;")
    assert e.index("await new Promise(r => setTimeout(r, 4000)); }", v2) < e.index("let doc = null, body = null;")
    # V3: en la mesa, después de la revisión de la venta rápida y antes de cargar; la espera en tramos de 200 ms (ninguna de 4 s de una vez)
    assert rh.index("if (this.cobroCambiado(id0, lineas0, total0, false, true)) return;") < rh.index("const idM = this.esperaId,") < rh.index("this._habSigue = true; this.cargarAHabitacion();")
    assert "for (let i = 0; i < 20 && this.habCargo === hc && this.esperaId === idM; i++) await new Promise(r => setTimeout(r, 200));" in rh and "setTimeout(r, 4000)" not in rh
    # V4: «Cobrar parte» espera y vuelve a juntar antes de la última revisión y de partir
    cp = metodos["async cobrarParte(n) {"]
    assert cp.index("await this.alDiaParaCobrar();") < cp.index("let hasta = ma && ma.id === id0 ? ma.t + 4000 : 0;") < cp.index("this._alDia = 0; await this.alDiaParaCobrar(true);") \
        < cp.index("if (this.cobroParcial || this.esperaId !== id0 || this.habCargo || this.pago) return;") < cp.index("this.lineas = resto; const id = this.persistirCuenta(true);")
    # V4: «Cobrar estos platos»: el aviso (con la marca y «Dividir» cerrado) va antes de pedir el turno y de partir
    cd = metodos["async confirmarDividir() {"]
    assert cd.index("this._marcaAjena = { id: id1, t: Date.now() }; if (this.dividir === d) this.dividir = null; return toast('" + AVISO_DIVIDIR + "', 'err');") \
        < cd.index("if (!(await this.cobroPermitido('cobrar'))) return; if (this.dividir !== d) return;")
    # V5: la primera línea de abrirPago devuelve la parte; la misma puerta sigue después de las esperas (cuarta vuelta)
    ap = metodos["async abrirPago() {"]
    assert ap.split("\n")[1].startswith("      if (this.habCargo) { if (this.cobroParcial) this.cerrarPago(); return; }") and ap.count("if (this.habCargo) { if (this.cobroParcial) this.cerrarPago(); return; }") == 2
    # V6: abrirDividir, después de su espera; abrirCargoHab, antes y después de la suya
    assert metodos[DIVIDIR].index("await this.alDiaParaCobrar();") < metodos[DIVIDIR].index("if (!this.lineas.length || this.dividir || this.pago || this.habCargo || this.cobroParcial) return;")
    ah = metodos["async abrirCargoHab() {"]
    assert ah.split("\n")[1].startswith("      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial || this.dividir) return toast('" + TERMINE + "', 'err');")
    assert ah.index("await this.cobroPermitido('cargar a la habitación')") < ah.index("      if (this.pago || this.cobrando || this._cobroEnCurso || this.cobroParcial || this.dividir) return;   ")
    # V7
    assert "if (e.key === 'F9') { e.preventDefault(); if (this.pago) this.cobrar(); else if (this.vista === 'venta' && !this.dividir) this.abrirPago(); }" in metodos["tecla(e) {"]
    # V9: también con el nombre automático en pantalla, que se cambia antes de guardar el nombre nuevo
    ad = metodos["async alDiaCuentaNueva(id) {"]
    assert "|| this.nombreEspera === cn.nombre) && this.espera.some(" in ad
    assert ad.index("if (this.esperaId === id && this.nombreEspera === cn.nombre) this.nombreEspera = nombre;") < ad.index("this.actualizarCuenta(id, x => ({ ...x, nombre }));")
    # V10
    assert "const m = (viejo === abierta ? this.nombreEspera || enviadas.get(viejo) : enviadas.get(viejo)) || 'la cuenta';" in metodos["seguirIds(key, cambios) {"]
