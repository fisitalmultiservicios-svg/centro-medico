"""3.87 (segunda ronda, r5_hotel): hotel, nota de crédito sin facturación electrónica y portal de soporte.
- hospitalidad F1/F2  Las plantillas de Vue solo ven lo que el componente expone (data, computed, methods, props, setup, inject
                      y las globales de la aplicación). La ficha de reserva llamaba hoyHotel sin exponerla y quedaba en blanco;
                      la Agenda de servicios › «Hoy» lanzaba TypeError. El detector revisa TODAS las plantillas de app/static/js.
- hospitalidad F3     Solo lectura (ver_todo) lee Seguridad, Lavandería y Preventivo sin poder escribirlos; el tablero de
                      Ama de llaves no pide el minibar a quien no puede cargarlo.
- facturacion-r1      Con la facturación electrónica apagada la nota de crédito interna se emite desde la pantalla, rebaja el
                      saldo de la factura y lo devuelve al anularla; la pantalla solo envía a Hacienda lo firmado.
- servicios-R1        La cabecera del portal de soporte se acomoda en el celular (no se sale de la pantalla)."""
import json
import pathlib
import re
import types
import uuid
from datetime import datetime, timezone

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, modulos
from app.db import Empresa, engine, engine_empresa, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"
RAIZ_JS = RAIZ / "static" / "js"


def _js(*partes):
    return (RAIZ_JS / pathlib.Path(*partes)).read_text(encoding="utf-8")


# ============================================================================= F1/F2: detector de plantillas
# Vue compila la plantilla en el navegador y resuelve cada nombre contra el componente, no contra los import del módulo:
# una función importada (o del módulo) que la plantilla llama sin exponerla da «X is not a function» y la pantalla queda en
# blanco. Se revisan los nombres que la plantilla LLAMA, los que usa como objeto (x.y, x[...]: TypeError si no existen) y los
# manejadores sin paréntesis (@click="guardar": botón muerto). Los textos, comentarios y expresiones regulares no cuentan.
ID = r"[A-Za-z_$][\w$]*"
PALABRAS = {"if", "for", "while", "switch", "return", "typeof", "new", "function", "in", "of", "instanceof", "void", "delete",
            "await", "catch", "with", "do", "else", "case", "throw", "yield", "async", "super", "this", "true", "false", "null",
            "undefined", "arguments"}
# globales que Vue 3 deja usar en una plantilla (GLOBALS_ALLOWED de @vue/shared)
GLOBALES_VUE = set("Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,"
                   "encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt,console,"
                   "Error,Symbol".split(","))


def mascara(src):
    """El código con textos, comentarios, expresiones regulares y el texto de los template literal en blanco (mismo largo),
    y {inicio: fin} de cada template literal (posición de la comilla invertida de apertura → la de cierre + 1)."""
    m, n, i = list(src), len(src), 0
    pila, plantillas, previo = [], {}, ""          # pila: [inicio, profundidad de llaves dentro de ${ }] de cada `…` abierto

    def blanco(a, b):
        for k in range(a, min(b, n)):
            if m[k] != "\n":
                m[k] = " "
    while i < n:
        c = src[i]
        if pila and not pila[-1][1]:               # dentro del texto de un template literal
            if c == "\\":
                blanco(i, i + 2); i += 2
            elif c == "`":
                plantillas[pila.pop()[0]] = i + 1; i += 1; previo = ")"
            elif src.startswith("${", i):
                pila[-1][1] = 1; i += 2; previo = "{"
            else:
                blanco(i, i + 1); i += 1
            continue
        if c in "'\"":
            j = i + 1
            while j < n and src[j] not in (c, "\n"):
                j += 2 if src[j] == "\\" else 1
            blanco(i + 1, j); i = j + 1; previo = ")"
        elif c == "`":
            pila.append([i, 0]); i += 1
        elif src.startswith("//", i):
            j = src.find("\n", i); j = n if j < 0 else j
            blanco(i, j); i = j
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2); j = n if j < 0 else j + 2
            blanco(i, j); i = j
        elif c == "/" and (previo in ("", "return", "typeof") or previo in "(,=:[!&|?{};+-*%<>~^"):
            j, clase = i + 1, False
            while j < n and src[j] != "\n" and (src[j] != "/" or clase):
                if src[j] == "\\":
                    j += 1
                elif src[j] in "[]":
                    clase = src[j] == "["
                j += 1
            blanco(i + 1, j); i = j + 1; previo = ")"
        elif c.isspace():
            i += 1
        else:
            if pila and c in "{}":
                pila[-1][1] += 1 if c == "{" else -1
                if not pila[-1][1]:                # cierra el ${ }: sigue el texto del template literal
                    i += 1
                    continue
            mo = re.match(r"[\w$]+", src[i:i + 80])
            previo = mo.group(0) if mo else c
            i += len(previo) if mo else 1
    return "".join(m), plantillas


def _pares(cod):
    pila, out = [], {}
    for k, c in enumerate(cod):
        if c in "{[(":
            pila.append(k)
        elif c in "}])" and pila:
            out[pila.pop()] = k
    return out


def _entradas(cod, a, b):
    """Tramos (ini, fin) de las entradas de primer nivel del objeto o arreglo literal que abre en a y cierra en b."""
    out, prof, ini = [], 0, a + 1
    for k in range(a + 1, b):
        if cod[k] in "{[(":
            prof += 1
        elif cod[k] in "}])":
            prof -= 1
        elif cod[k] == "," and not prof:
            out.append((ini, k)); ini = k + 1
    out.append((ini, b))
    return [(x, y) for x, y in out if cod[x:y].strip()]


def _clave(src, cod, x, y):
    """(nombre, tipo, posición) de una entrada de objeto; tipo: 'metodo' (posición del «(»), 'clave' (del valor), 'atajo' o 'spread'."""
    t = cod[x:y]
    x0, t = x + len(t) - len(t.lstrip()), t.strip()
    if t.startswith("..."):
        return t[3:].strip(), "spread", None
    mo = re.match(r"(?:(?:async|get|set)\s+)*\*?\s*(" + ID + r")\s*\(", t)
    if mo:
        return mo.group(1), "metodo", x0 + mo.end() - 1
    mo = re.match(r"(" + ID + r")\s*:", t)
    if mo:
        return mo.group(1), "clave", x0 + mo.end()
    mo = re.match(r"(['\"])[^'\"]*\1\s*:", src[x0:y])
    if mo:
        return mo.group(0)[1:].split(mo.group(1))[0], "clave", x0 + mo.end()
    mo = re.fullmatch(r"(" + ID + r")(\s*=.*)?", t, re.S)
    return (mo.group(1), "atajo", None) if mo else (None, None, None)


def _sig(cod, k):
    while k < len(cod) and cod[k].isspace():
        k += 1
    return k


def _claves_de(src, cod, pr, k):
    """Claves del objeto literal que abre en k, y si tiene un ...spread (lo que trae no se puede saber)."""
    nombres, spread = set(), False
    for x, y in _entradas(cod, k, pr[k]):
        nom, tipo, _ = _clave(src, cod, x, y)
        spread |= tipo == "spread"
        if nom and tipo != "spread":
            nombres.add(nom)
    return nombres, spread


def expuestos(src, cod, pr, a, b):
    """Lo que el componente (objeto literal entre a y b) expone a su plantilla, y si quedó algo sin resolver."""
    nombres, opaco = set(), False
    for x, y in _entradas(cod, a, b):
        nom, tipo, v = _clave(src, cod, x, y)
        if tipo == "spread":
            opaco = True
        elif nom in ("methods", "computed", "props", "inject") and tipo == "clave":
            k = _sig(cod, v)
            if cod[k] == "{":
                n2, sp = _claves_de(src, cod, pr, k)
                nombres |= n2; opaco |= sp
            elif cod[k] == "[" and nom in ("props", "inject"):
                nombres |= set(re.findall(r"['\"](" + ID + r")['\"]", src[k:pr[k]]))
            else:
                opaco = True
        elif nom in ("data", "setup"):
            if tipo != "metodo" or cod[_sig(cod, pr[v] + 1)] != "{":   # data: () => …, setup: function… (no se usan hoy)
                opaco = True
                continue
            k = _sig(cod, pr[v] + 1)
            hubo = False
            for mo in re.finditer(r"(?<![\w$.])return\b", cod[k:pr[k]]):
                p = k + mo.end()
                j, arriba = _sig(cod, p), cod[k + 1:p].count("{") == cod[k + 1:p].count("}")
                if cod[j] == "{":
                    n2, sp = _claves_de(src, cod, pr, j)
                    nombres |= n2; opaco |= sp; hubo = True
                elif arriba and cod[j] not in ";}":   # return de una variable en el cuerpo: no se sabe qué trae
                    opaco = True
            opaco |= not hubo
    return nombres, opaco


RE_ATRIB = re.compile(r"""\s(v-[\w:.\-\[\]]+|[:@#][\w.\-\[\]:]*)\s*=\s*(?:"([^"]*)"|'([^']*)')""")
RE_TEXTO = re.compile(r"'(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\"")
RE_REGEX = re.compile(r"(?:^|(?<=[(,=:!&|?{\[;]))\s*/(?![/*])(?:\\.|\[[^\]]*\]|[^/\\\n])+/[a-z]*")
RE_FLECHA = re.compile(r"\(([^()]*)\)\s*=>|(" + ID + r")\s*=>")
RE_USO = re.compile(r"(?<![\w$.])(" + ID + r")(?![\w$])\s*(?=\(|\.(?!\.)|\[)")   # x(…), x.y o x[…]


def _cocinar(t):
    """El texto del template literal tal como llega a Vue: sin barras de escape y sin las interpolaciones ${…}."""
    out, i, n = [], 0, len(t)
    while i < n:
        if t[i] == "\\" and i + 1 < n:
            out.append({"n": "\n", "t": "\t", "r": "\r"}.get(t[i + 1], t[i + 1])); i += 2
        elif t.startswith("${", i):
            prof, i = 1, i + 2
            while i < n and prof:
                prof += {"{": 1, "}": -1}.get(t[i], 0); i += 1
        else:
            out.append(t[i]); i += 1
    return "".join(out)


def usados(plantilla):
    """(nombres que la plantilla llama o usa como objeto, nombres locales de v-for, v-slot y funciones flecha)."""
    plantilla = _cocinar(plantilla)
    exprs, locales = [], set()
    for mo in RE_ATRIB.finditer(plantilla):
        attr, val = mo.group(1), mo.group(2) if mo.group(2) is not None else mo.group(3)
        if attr == "v-for":
            mm = re.match(r"\s*(.*?)\s+(?:in|of)\s+(.*)$", val, re.S)
            if mm:
                locales |= set(re.findall(ID, mm.group(1))); val = mm.group(2)
        elif attr.startswith("#") or attr.startswith("v-slot"):
            locales |= set(re.findall(ID, RE_TEXTO.sub("", val)))
            continue
        elif attr.startswith(("@", "v-on")) and re.fullmatch(r"\s*" + ID + r"\s*", val):
            val = val.strip() + "()"                  # @click="guardar": se llama al hacer clic
        exprs.append(val)
    exprs += re.findall(r"\{\{(.*?)\}\}", plantilla, re.S)
    nombres = set()
    for e in exprs:
        e = RE_REGEX.sub(" 0", RE_TEXTO.sub("''", e))
        for mo in RE_FLECHA.finditer(e):
            locales |= set(re.findall(ID, mo.group(1) or mo.group(2) or ""))
        nombres |= set(RE_USO.findall(e))
    return nombres, locales


def _globales(rel, src, textos):
    """Las globalProperties de la aplicación que monta el archivo: fis/ (fis/app.js), las que montan la suya (soporte.js,
    tienda.js…) o la principal (app.js)."""
    app_js = "fis/app.js" if rel.startswith("fis/") else rel if "createApp(" in src else "app.js"
    return set(re.findall(r"globalProperties\.(" + ID + r")\s*=", src if app_js == rel else textos.get(app_js, "")))


def sin_exponer(rel, src, textos):
    """[(línea, [nombres])] de las plantillas del archivo que usan algo que su componente no expone."""
    cod, plantillas = mascara(src)
    pr = _pares(cod)
    llaves = sorted((a, b) for a, b in pr.items() if cod[a] == "{")
    del_modulo = set()
    for mo in re.finditer(r"^import\s*\{([^}]*)\}", src, re.M):
        del_modulo |= {x.split(" as ")[-1].strip() for x in mo.group(1).split(",") if x.strip()}
    del_modulo |= set(re.findall(r"^(?:export\s+)?(?:async\s+)?(?:function\s*\*?\s*|const\s+|let\s+)(" + ID + r")", cod, re.M))
    out = []
    for mo in re.finditer(r"(?<![\w$.])template\s*:\s*`", cod):
        ini = mo.end() - 1
        fin = plantillas.get(ini)
        enc = [(a, b) for a, b in llaves if a < mo.start() < b]
        if fin is None or not enc:
            continue
        a, b = enc[-1]                                      # el objeto literal más cercano que contiene «template:»
        exp, opaco = expuestos(src, cod, pr, a, b)
        nombres, locales = usados(src[ini + 1:fin - 1])
        faltan = {x for x in nombres - exp - locales - PALABRAS - GLOBALES_VUE - _globales(rel, src, textos) if not x.startswith("$")}
        if opaco:                                           # un ...spread podría traerlos: solo los del módulo que no figuran
            faltan = {x for x in faltan if x in del_modulo and not re.search(r"(?<![\w$.])" + re.escape(x) + r"\s*[:,}(]", cod[a:b])}
        if faltan:
            out.append((src.count("\n", 0, mo.start()) + 1, sorted(faltan)))
    return out


def _textos_js():
    return {str(f.relative_to(RAIZ_JS)).replace("\\", "/"): f.read_text(encoding="utf-8")
            for f in sorted(RAIZ_JS.rglob("*.js")) if "vendor" not in f.relative_to(RAIZ_JS).parts}


def test_plantillas_no_usan_lo_que_el_componente_no_expone():
    textos = _textos_js()
    hallados, total = {}, 0
    for rel, src in textos.items():
        total += len(re.findall(r"(?<![\w$.])template\s*:\s*`", src))
        malos = sin_exponer(rel, src, textos)
        if malos:
            hallados[rel] = malos
    assert total > 150, total                                   # revisa de verdad las pantallas (218 plantillas en 3.87)
    assert not hallados, hallados


def test_ficha_de_reserva_y_agenda_exponen_hoyHotel():
    textos = _textos_js()
    for rel in ("pages/hotel/reserva-form.js", "pages/hotel/servicios.js"):
        src = textos[rel]
        assert re.search(r"\{\{[^}]*hoyHotel\(\)|=\"[^\"]*hoyHotel\(\)", src), rel   # la plantilla la usa
        assert sin_exponer(rel, src, textos) == [], rel
        # sin exponerla (como hasta 3.87) el detector la marca: es la falla que dejaba la ficha en blanco
        antes = re.sub(r"(setup\(\) \{ return \{ hoy, )hoyHotel, ", r"\1", src)
        assert antes != src and any("hoyHotel" in n for _, n in sin_exponer(rel, antes, textos)), rel


def test_detector_de_plantillas_sin_falsos_positivos_ni_omisiones():
    textos = {"app.js": "app.config.globalProperties.puede = p => p;\n"}
    malo = """import { hoy, hoyHotel, sesion, money } from './api.js';
const util = () => 1;
export default {
  props: ['fila'],
  data() { const x = 1; return { lista: [], abierto: false, ESTADOS: {} }; },
  computed: { total() { return 1; } },
  methods: { guardar() {}, async quitar(i) {} },
  template: `<div v-if="sesion.puede('x')">{{hoyHotel()}} {{ money(total) }} <b :title="'texto(sin) llamar()'">x</b>
    <button @click="borrar">B</button><button @click.stop="guardar">G</button><i @click="quitar(1)"></i>
    <p v-for="(it, i) in lista" :key="i">{{ it.nombre(1) }} {{ fila.x }} {{ ESTADOS[it] }}</p>
    <Tabla><template #default="{ row: r, abrir }"><a @click="abrir(r)">{{ r.n }}</a></template></Tabla>
    <span v-if="/^ab+c/.test(x)">{{ lista.map(z => z.n).join(', ') }} {{ Math.round(total) }} {{ puede('v') }} {{ util() }}</span>
    <a :href="\\'#/x\\'">{{ abierto ? \\"si(no)\\" : 'no' }}</a>`,
  setup() { return { hoy, money }; },
};"""
    assert sin_exponer("pages/x.js", malo, textos) == [(8, ["borrar", "hoyHotel", "sesion", "util"])]
    bueno = malo.replace("return { hoy, money }", "return { hoy, hoyHotel, sesion, money, util }").replace("guardar() {}", "guardar() {}, borrar() {}")
    assert sin_exponer("pages/x.js", bueno, textos) == []


# ============================================================================= F3: Solo lectura en Seguridad, Lavandería y Preventivo
PW = "Clave-larga-387-r5-hotel-QA"
c = TestClient(app)
H = lambda t: {"Authorization": "Bearer " + t}   # noqa: E731
CLAVES_HOTEL = ("hotel_seg_bitacora", "hotel_seg_visitantes", "hotel_seg_incidentes", "hotel_seg_objetos", "hotel_lavanderia", "hotel_preventivo")
DATOS_HOTEL = {
    "hotel_config": {"activo": True, "nombre": "Hotel Lectura r5 QA", "moneda": "USD"},
    "hotel_seg_bitacora": [{"id": 1, "hora": "2026-11-05T08:00:00", "usuario": "seguridad", "tipo": "ronda", "texto": "Ronda QA"}],
    "hotel_seg_visitantes": [{"id": 1, "nombre": "Visitante QA", "documento": "1-1111-1111", "entrada": "2026-11-05T09:00:00", "salida": None}],
    "hotel_seg_incidentes": [{"id": 1, "numero": "SG-0001", "tipo": "otro", "estado": "abierto", "descripcion": "Incidente QA"}],
    "hotel_seg_objetos": [{"id": 1, "numero": "OP-0001", "descripcion": "Llaves QA", "estado": "guardado"}],
    "hotel_lavanderia": {"blancos": [{"id": 1, "nombre": "Sábana QA", "bodega": 10}], "prendas": []},
    "hotel_preventivo": [{"id": 1, "nombre": "Filtros de aire QA", "alcance": "area", "area": "Lobby", "cada": 30, "proxima": "2026-11-08", "activo": True}],
}


def _hotel_con_roles(roles_propios, usuarios):
    init_db()
    tok = {}
    with Session(engine) as s:
        e = Empresa(nombre="Hotel Lectura r5 QA", numero_id="3101387591", actividad="551001", otras_senas="QA 387", correo="hotel.r5@example.test",
                    ambiente="sandbox", tipo_negocio="hospitalidad")
        s.add(e); s.commit(); s.refresh(e)
        for n, p in roles_propios.items():
            s.add(auth.RolEmpresa(empresa_id=e.id, nombre=n, permisos=json.dumps(p)))
        s.commit()
        for rol, correo in usuarios.items():
            u = auth.Usuario(correo=correo, nombre=rol + " QA", password_hash=auth.hash_password(PW), mfa_activo=True,
                             terminos_version=auth.TERMINOS_VERSION, terminos_fecha=datetime.now(timezone.utc), consiente_factura=True, paleta="turquesa")
            s.add(u); s.commit(); s.refresh(u)
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol=rol)); s.commit()
            tok[rol] = auth._respuesta(s, u, e.id)["token"]
        eid = e.id
    with Session(engine_empresa(eid)) as s:
        for clave, valor in DATOS_HOTEL.items():
            r = modulos._registro(s, eid, clave)
            modulos.reemplazar(s, eid, clave, valor, (r.version or 0) if r else None)
    return eid, tok


def _borrar(eid, correos):
    with Session(engine) as s:
        for correo in correos:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            if not u:
                continue
            for x in s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                s.delete(x)
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == u.id)).all():
                s.delete(x)
            s.delete(u)
        for r in s.exec(select(auth.RolEmpresa).where(auth.RolEmpresa.empresa_id == eid)).all():
            s.delete(r)
        e = s.get(Empresa, eid)
        if e:
            s.delete(e)
        s.commit()


def test_solo_lectura_lee_seguridad_lavanderia_y_preventivo_sin_escribirlos():
    correos = {"Administrador": "admin.r5hotel@example.test", "Solo lectura": "lectura.r5hotel@example.test", "Contador": "contador.r5hotel@example.test",
               "Camarera": "camarera.r5hotel@example.test", "Técnico": "tecnico.r5hotel@example.test", "Seguridad": "seguridad.r5hotel@example.test"}
    eid, tok = _hotel_con_roles({"Camarera": ["limpieza"], "Técnico": ["mantenimiento"], "Seguridad": ["seguridad"]}, correos)
    try:
        for clave in CLAVES_HOTEL:
            for rol in ("Solo lectura", "Contador", "Administrador"):
                r = c.get(f"/api/registros/{clave}", headers=H(tok[rol]))
                assert r.status_code == 200, (rol, clave, r.text)          # antes: 403 para Solo lectura (pantallas «vacías»)
                assert r.json()["datos"] == DATOS_HOTEL[clave], (rol, clave)
            # leer no es escribir: el PUT y los cambios siguen pidiendo el permiso del módulo
            v = c.get(f"/api/registros/{clave}", headers=H(tok["Solo lectura"])).json()["version"]
            assert c.put(f"/api/registros/{clave}", headers=H(tok["Solo lectura"]), json={"datos": DATOS_HOTEL[clave], "version": v}).status_code == 403, clave
            if isinstance(DATOS_HOTEL[clave], list):
                cuerpo = {"upserts": [{**DATOS_HOTEL[clave][0], "id": 99}], "deletes": [], "nuevos": [99]}
                assert c.post(f"/api/registros/{clave}/cambios", headers=H(tok["Solo lectura"]), json=cuerpo).status_code == 403, clave
        regs = (c.get("/api/arranque", headers=H(tok["Solo lectura"])).json().get("registros") or {}).get("datos") or {}
        assert all(clave in regs for clave in CLAVES_HOTEL), sorted(k for k in regs if k.startswith("hotel_"))
        # los roles de un solo módulo siguen viendo solo el suyo
        esperado = {"Camarera": {"hotel_lavanderia"}, "Técnico": {"hotel_preventivo"},
                    "Seguridad": {"hotel_seg_bitacora", "hotel_seg_visitantes", "hotel_seg_incidentes", "hotel_seg_objetos"}}
        for rol, suyas in esperado.items():
            for clave in CLAVES_HOTEL:
                assert c.get(f"/api/registros/{clave}", headers=H(tok[rol])).status_code == (200 if clave in suyas else 403), (rol, clave)
        # el minibar sigue siendo de quien lo carga; el tablero de Ama de llaves ya no se lo pide a Solo lectura (403 en la consola)
        assert c.get("/api/hotel/minibar", headers=H(tok["Solo lectura"])).status_code == 403
        assert c.get("/api/hotel/minibar", headers=H(tok["Camarera"])).status_code == 200
    finally:
        _borrar(eid, correos.values())
    assert "if (this.puedeEscribir) this.cargarMinibar();" in _js("pages", "hotel", "limpieza.js")


# ============================================================================= facturacion-r1: nota de crédito interna
LINEAS = [{"cabys": "8399000009900", "detalle": "Asesoría", "cantidad": 1, "precio_unitario": 10000, "tarifa": 13, "codigo_tarifa": "08"}]


@pytest.fixture()
def sin_fe():
    init_db()
    suf = uuid.uuid4().hex[:6]
    with Session(engine) as s:
        e = Empresa(nombre=f"Interna NC r5 {suf} QA", numero_id="3101" + str(uuid.uuid4().int)[:6], actividad="620100", otras_senas="Oficina de pruebas",
                    correo=f"nc.r5.{suf}@example.test", ambiente="sandbox", tipo_negocio="facturacion", factura_electronica=False)
        s.add(e); s.commit(); s.refresh(e); s.expunge(e)
    permisos = {p for p, rs in auth.PERMISOS.items() if "Administrador" in rs} - {"pos"}     # como en Facturación: el plan no trae la caja
    ctx = auth.Contexto(types.SimpleNamespace(id=None, correo=f"qa-nc-r5-{suf}@example.test", es_superadmin=False, nombre="QA"), e, "Administrador", None, permisos)
    app.dependency_overrides[auth.contexto] = lambda: ctx
    try:
        yield TestClient(app), e.id
    finally:
        app.dependency_overrides.clear()
        with Session(engine) as s:
            em = s.get(Empresa, e.id)
            if em:
                s.delete(em); s.commit()


def _doc(cl, did, cid):
    return next(x for x in cl.get(f"/api/comprobantes?cliente_id={cid}").json() if x["id"] == did)


def _con_saldo(cl, cid):
    return [x["id"] for x in cl.get(f"/api/comprobantes?cliente_id={cid}&con_saldo=1").json()]


def test_nc_interna_rebaja_el_saldo_y_lo_devuelve_al_anularla(sin_fe):
    cl, eid = sin_fe
    cli = cl.post("/api/clientes", json={"nombre": "Cliente NC interna r5", "tipo": "Cliente", "tipo_id": "01", "numero_id": "109870772", "correo": "cli.nc.r5@example.test"}).json()
    f = cl.post("/api/comprobantes", json={"tipo_documento": "01", "cliente_id": cli["id"], "condicion_venta": "02", "plazo_credito": 30, "medio_pago": "04", "lineas": LINEAS}).json()
    assert f.get("estado") == "interno", f
    ref = {"referencia_clave": f["clave"], "referencia_fecha": f["fecha_emision"], "referencia_codigo": "01"}
    r = cl.post("/api/comprobantes", json={"tipo_documento": "03", "cliente_id": cli["id"], "condicion_venta": "01", "lineas": [{**LINEAS[0], "precio_unitario": 4000}],
                                           **ref, "referencia_razon": "Devolución parcial"})
    assert r.status_code == 200, r.text
    nc = r.json()
    assert nc["estado"] == "interno"
    assert abs((_doc(cl, f["id"], cli["id"])["acreditado"] or 0) - nc["total"]) < 0.01   # antes quedaba en 0: la factura seguía debiendo el total
    assert f["id"] in _con_saldo(cl, cli["id"])                                        # parcial: aún con saldo
    with Session(engine_empresa(eid)) as s:                                            # el recálculo completo (al arrancar) da lo mismo
        modulos.recalcular_acreditado(s, eid)
    assert abs((_doc(cl, f["id"], cli["id"])["acreditado"] or 0) - nc["total"]) < 0.01
    assert cl.post(f"/api/comprobantes/{nc['id']}/anular").status_code == 200          # anular la nota interna devuelve el saldo
    assert (_doc(cl, f["id"], cli["id"])["acreditado"] or 0) == 0
    r = cl.post("/api/comprobantes", json={"tipo_documento": "03", "cliente_id": cli["id"], "condicion_venta": "01", "lineas": LINEAS, **ref, "referencia_razon": "Anulación"})
    assert r.status_code == 200, r.text
    assert f["id"] not in _con_saldo(cl, cli["id"])                                    # la nota por el total la deja sin saldo


def test_nota_form_ofrece_internas_y_solo_envia_lo_firmado():
    js = _js("pages", "ventas", "nota-form.js")
    assert "const referenciable = d => d.estado === 'aceptado' || (!sesion.electronica && d.estado === 'interno');" in js
    assert "['01', '04', '09'].includes(d.tipo_documento) && referenciable(d)); }" in js        # la lista «Factura de venta asociada»
    assert "if (!referenciable(d)) return toast(" in js                                        # la entrada desde la factura (?factura=)
    assert "if (emitir && d.estado === 'firmado') { try { await api(`/api/comprobantes/${d.id}/enviar`" in js   # ni la interna ni la sin firma
    assert js.count("d.estado === 'aceptado'") == 1                                            # solo en referenciable


# ============================================================================= servicios-R1: cabecera del portal en el celular
def test_cabecera_del_portal_envuelve_en_el_celular():
    js = _js("soporte.js")
    i = js.index("<template v-else-if=\"vista==='lista'\">")
    cab = js[i:js.index("Salir</button></div></div>", i)]
    assert '<div class="sp-card" style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><div style="min-width:0;overflow-wrap:anywhere">' in cab
    assert '<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm" @click="abrirNuevo">+ Ticket</button>' in cab
