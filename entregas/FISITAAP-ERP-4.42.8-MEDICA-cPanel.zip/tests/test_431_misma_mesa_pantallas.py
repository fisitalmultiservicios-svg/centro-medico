# -*- coding: utf-8 -*-
"""4.31, la misma mesa abierta en dos equipos sin perder platos: pantallas (diseño exe430/diseno_mesa.md, 4.1 a 4.9 en lo de JavaScript,
5 y 7; pruebas P-1 lado JS, P-2 a P-6 y P-9).

- pos/_fusion.js corre en Node tal cual (no importa nada): los casos compartidos con app/fusion_cuentas.py (tests/test_431_fusion_casos.json)
  dan exactamente lo esperado, y las ayudas de la pantalla hacen lo que dicen.
- api.js real: la condición de una baja viaja solo con esa baja (y se reenvía si el envío falló), `_fusion` sale de la copia al confirmarse
  el envío y, si el servidor unió o conservó algo, la clave se vuelve a bajar.
- caja.js: los métodos reales (persistirCuenta, sincronizar, abrirMesa, enviarComanda, volverAMesas, cobrarParte, abrirPago, cerrarPago,
  cuentaVacia, borrarEspera, moverA, agregar…) en dos «equipos», cada uno con su api.js y su _fusion.js, contra un servidor falso que
  aplica la regla del servidor (la de _fusion.js, igual a la de Python por P-1) o la de antes («hoy»).
- cocina.js: «aplicar» solo manda las marcas de la cocina.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json
import pathlib

import pytest

from tests.test_425_ultimos_pantallas import _node

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
CASOS = RAIZ / "tests" / "test_431_fusion_casos.json"
VUE = {"vendor/vue.esm-browser.prod.min.js": "export const reactive = x => x;\n"}


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


def _metodo(txt: str, cabeza: str) -> str:
    return _tramo(txt, "    " + cabeza, "\n    },\n").strip() + "\n    }"


def _linea(txt: str, cabeza: str) -> str:
    return _tramo(txt, "    " + cabeza, "\n").strip().split("   /*")[0].split("   //")[0].strip().rstrip(",")


# ================================================================================================================ P-1 (lado JS)
COMPARAR = r"""
const esObj = v => v !== null && typeof v === 'object' && !Array.isArray(v);
// igualdad profunda de JSON: números por valor, sin importar el orden de las claves; una clave ausente no es lo mismo que una en null
function igual(a, b) {
  if (typeof a === 'number' && typeof b === 'number') return a === b;
  if (Array.isArray(a) || Array.isArray(b)) return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((x, i) => igual(x, b[i]));
  if (esObj(a) || esObj(b)) { if (!esObj(a) || !esObj(b)) return false; const ka = Object.keys(a).sort(), kb = Object.keys(b).sort(); return igual(ka, kb) && ka.every(k => igual(a[k], b[k])); }
  return a === b;
}
const copia = v => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
"""


def test_p1_casos_compartidos_con_el_servidor_en_node(tmp_path):
    if not CASOS.exists():
        pytest.skip("todavía no están los casos compartidos (los escribe la parte del servidor)")
    datos = json.loads(CASOS.read_text(encoding="utf-8"))
    r = _node(tmp_path, COMPARAR + """
const F = await import('./js/pages/pos/_fusion.js');
const d = %s;
const out = [];
for (const c of d.casos) {
  let ok = false, extra = '';
  if (c.funcion === 'unir') {
    const [res, f] = F.unir(copia(c.guardada), copia(c.nueva));
    ok = igual(res, c.esperado) && f === c.fusiono;
    if (ok && c.repetible) { const [res2] = F.unir(copia(c.esperado), copia(c.nueva)); ok = igual(res2, c.esperado); extra = ok ? '' : 'no repetible'; }
    if (!ok && !extra) extra = JSON.stringify([res, f]).slice(0, 400);
  } else if (c.funcion === 'cerrar') { const x = F.cerrarCuenta(copia(c.guardada), copia(c.condicion)); ok = igual(x, c.esperado); if (!ok) extra = JSON.stringify(x).slice(0, 400); }
  else if (c.funcion === 'recrear') { const x = F.recrearCuenta(copia(c.nueva), c.id_viejo, c.id_nuevo); ok = igual(x, c.esperado); if (!ok) extra = JSON.stringify(x).slice(0, 400); }
  else if (c.funcion === 'poner_lids') { const x = F.ponerLids(copia(c.cuenta)); ok = igual(x, c.esperado); if (!ok) extra = JSON.stringify(x).slice(0, 400); }
  else extra = 'función desconocida';
  out.push([c.funcion + ':' + c.nombre, ok, extra]);
}
console.log(JSON.stringify(out));
""" % json.dumps(datos), archivos=("pages/pos/_fusion.js",), falsos={})
    malos = [x for x in r if not x[1]]
    assert len(r) == len(datos["casos"]) and not malos, malos


def test_p1_ayudas_de_la_pantalla_en_node(tmp_path):
    r = _node(tmp_path, COMPARAR + """
const F = await import('./js/pages/pos/_fusion.js'), G = await import('./js/pages/pos/_fusion.js?otro');
const out = {};
// el módulo no importa nada y da un equipo por carga
out.equipos = [F.EQUIPO.startsWith('e'), F.EQUIPO !== G.EQUIPO, F.nuevoLid().startsWith('l'), F.nuevoLid() !== F.nuevoLid(), F.CAMPOS_MARCA];
// redondeo «mitad hacia arriba» sobre el número escrito (como Decimal(str(x)) en Python)
out.redondeo = [F.redondear(2.675), F.redondear(1.005), F.redondear(0.125), F.redondear(1.0049999), F.redondear(-2.675), F.redondear(1.6669999999999998, 3), F.redondear('x')];
// lid determinista: producto entero o detalle, enviado, índice solo entre las que no tienen lid, desempate :d, repetido
const c = F.ponerLids({ id: 6, lineas: [{ producto_id: 1, detalle: 'Casado', enviado: 'E' }, { lid: 'h:6:1:E:0' , producto_id: 1 }, { producto_id: 1, detalle: 'Casado', enviado: 'E' }, { producto_id: null, detalle: 'Envío' }, { lid: 'lX' }, { lid: 'lX' }] });
out.lids = c.lineas.map(l => l.lid);
// diferencia: nuevas, quitadas con su cantidad y los campos que cambiaron
const base = [{ lid: 'a', cantidad: 1, nota: '' }, { lid: 'b', cantidad: 2 }, { lid: 'c', cantidad: 1, listo: 'x' }];
out.dif = F.diferencia(base, [{ lid: 'a', cantidad: 3, nota: 'sin sal' }, { lid: 'c', cantidad: 1 }, { lid: 'd', cantidad: 1 }]);
// conFusion acumula solo un _fusion de ESTE equipo todavía sin confirmar; una línea agregada y quitada antes de subir ya no es nueva
const p1 = { _fusion: F.conFusion(null, { nuevas: ['n1', 'n2'], quitadas: { q1: 2 }, campos: { a: ['nota'] } }, ['nota'], 'caja') };
const f2 = F.conFusion(p1, { nuevas: ['n3'], quitadas: { n2: 1 }, campos: { a: ['cantidad'] } }, ['nombre'], 'cocina');
out.acumula = [f2.v, f2.equipo === F.EQUIPO, f2.origen, f2.nuevas, f2.quitadas, f2.campos, f2.cuenta];
const ajeno = F.conFusion({ _fusion: { ...p1._fusion, equipo: G.EQUIPO } }, { nuevas: ['n3'], quitadas: {}, campos: {} }, [], 'caja');
out.ajeno = [ajeno.nuevas, ajeno.quitadas, ajeno.cuenta];
// conFusionDe: lo que cambió una función sobre la cuenta (sin lineas, actualizado ni _fusion en `cuenta`)
const x = { id: 6, nombre: 'Mesa 6', actualizado: 'h1', total: 10, lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: 'E' }] };
const y = F.conFusionDe(x, { ...x, mesa_id: 8, actualizado: 'h2', lineas: x.lineas.map(l => ({ ...l, comanda: 7 })) }, 'caja');
out.conFusionDe = [y._fusion.nuevas, y._fusion.campos, y._fusion.cuenta, y.lineas[0].lid];
// condición de una baja: {v: 1, quitadas: {lid: cantidad}} (las líneas sin lid reciben el determinista de la cuenta)
out.condicion = F.condicionDe(6, [{ lid: 'a', cantidad: 2 }, { producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: 'E' }]);
// base de la pantalla y lid de las líneas en pantalla sin lid
const b = F.tomarBaseDe({ id: 6, nombre: 'Mesa 6', _fusion: { v: 1 }, lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: 'E' }] });
out.base = [b.id, b.existia, b.lineas.map(l => l.lid), 'lineas' in b.cuenta, '_fusion' in b.cuenta, F.tomarBaseDe({ id: 7, lineas: [] }, false).existia];
out.baseDe = [F.baseDeCuenta(b, 6, null) === b, F.baseDeCuenta(b, 7, { id: 7, lineas: [] }).id, F.baseDeCuenta(null, 7, null), [...F.lidsDeBase(b, 6)], [...F.lidsDeBase(b, 7)]];
const prev = F.ponerLids({ id: 6, lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: 'E' }] });
const pant = [{ producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: 'E' }, { producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: null }, { lid: 'lYa', cantidad: 1 }];
F.lidsPantalla(pant, prev);
out.pantalla = [pant[0].lid, pant[1].lid.startsWith('l'), pant[2].lid];
// en el lugar: el mismo objeto para cada lid que sigue; las que llegan al final; sin las que salieron; claves quitadas
const o1 = { lid: 'a', cantidad: 1, listo: 'x' }, o2 = { lid: 'b', cantidad: 1 };
const nuevas = F.aplicarEnLugar([o1, o2], [{ lid: 'a', cantidad: 2 }, { lid: 'c', cantidad: 1 }]);
out.lugar = [nuevas[0] === o1, nuevas.length, o1, nuevas[1].lid];
out.cambio = F.contarCambio([o1, o2], [{ lid: 'a' }, { lid: 'c' }, { lid: 'd' }]);
// recreada: solo por número
out.recreada = [F.esRecreadaDe({ recreada_de: 6 }, 6), F.esRecreadaDe({ recreada_de: '6' }, 6), F.esRecreadaDe({}, 6)];
console.log(JSON.stringify(out));
""", archivos=("pages/pos/_fusion.js",), falsos={})
    assert r["equipos"] == [True, True, True, True, ["preparando", "listo", "entregado", "impreso", "comanda"]], r
    assert r["redondeo"] == [2.68, 1.01, 0.13, 1.0, -2.68, 1.667, 0], r
    assert r["lids"] == ["h:6:1:E:0:1", "h:6:1:E:0", "h:6:1:E:1", "h:6:Envío::0", "lX", "lX:1"], r
    assert r["dif"] == {"nuevas": ["d"], "quitadas": {"b": 2}, "campos": {"a": ["cantidad", "nota"], "c": ["listo"]}}, r
    assert r["acumula"] == [1, True, "caja", ["n1", "n3"], {"q1": 2, "n2": 1}, {"a": ["cantidad", "nota"]}, ["nombre", "nota"]], r
    assert r["ajeno"] == [["n3"], {}, []], r
    assert r["conFusionDe"] == [[], {"h:6:1:E:0": ["comanda"]}, ["mesa_id"], "h:6:1:E:0"], r
    assert r["condicion"] == {"v": 1, "quitadas": {"a": 2, "h:6:1:E:0": 1}}, r
    assert r["base"] == [6, True, ["h:6:1:E:0"], False, False, False], r
    assert r["baseDe"] == [True, 7, None, ["h:6:1:E:0"], []], r
    assert r["pantalla"] == ["h:6:1:E:0", True, "lYa"], r
    assert r["lugar"] == [True, 2, {"lid": "a", "cantidad": 2}, "c"], r
    assert r["cambio"] == {"agregadas": 2, "quitadas": 1}, r
    assert r["recreada"] == [True, False, False], r


# ================================================================================================================ P-9 (api.js real)
SERVIDOR_API = r"""
globalThis.localStorage = { getItem: () => null, setItem() {}, removeItem() {}, key: () => null, length: 0 };
const R = globalThis.R = { cuerpos: [], extra: null, fallar: false, ver: { pos_espera: 1, compras: 1 }, gets: 0, frenar: null };
const resp = (j, status = 200) => ({ ok: status < 400, status, headers: { get: () => null }, json: async () => j });
globalThis.fetch = async (url, opt) => {
  const m = (opt && opt.method) || 'GET', body = opt && opt.body ? JSON.parse(opt.body) : null;
  const clave = decodeURIComponent(url.split('/')[3] || '');
  if (url === '/api/registros/versiones') return resp({ ...R.ver });
  if (m === 'GET' && url.startsWith('/api/registros/')) { R.gets++; return resp({ datos: [], version: R.ver[clave], ultimo_id: 9 }); }
  if (url.endsWith('/cambios')) {
    R.cuerpos.push({ url, body });
    if (R.frenar) await R.frenar;
    if (R.fallar) { R.fallar = false; return resp(null, 500); }
    R.ver[clave]++; return resp({ version: R.ver[clave], remap: {}, ultimo_id: 9, ...(R.extra || {}) });
  }
  return resp(null);
};
"""


def test_p9_api_condiciones_y_fusion_en_node(tmp_path):
    r = _node(tmp_path, SERVIDOR_API + """
const A = await import('./js/api.js');
const c = (id, extra) => ({ id, nombre: 'Mesa ' + id, lineas: [{ lid: 'l' + id, cantidad: 1 }], ...(extra || {}) });
await A.mock.cargar({ datos: { pos_espera: [c(1), c(2), c(3), c(4), c(5)], compras: [{ id: 1 }] }, versiones: { pos_espera: 1, compras: 1 }, topes: {}, rango: 0 });
const out = {}, ultimo = () => R.cuerpos[R.cuerpos.length - 1];
const COND = { v: 1, quitadas: { l2: 1 } };
// 1) la baja con condición la lleva; la baja sin condición y las demás claves, el cuerpo de siempre
A.mock.condicionBaja('pos_espera', 2, COND);
A.mock.set('pos_espera', A.mock.get('pos_espera').filter(x => x.id !== 2 && x.id !== 3)); await A.mock.guardarTodo();
out.baja = [Object.keys(ultimo().body).sort(), ultimo().body.deletes, ultimo().body.condiciones];
A.mock.set('compras', []); await A.mock.guardarTodo();
out.otra_clave = Object.keys(ultimo().body).sort();
// 2) al confirmarse el envío, `_fusion` sale de la copia y de la base (un envío siguiente no lo vuelve a mandar)
A.mock.set('pos_espera', A.mock.get('pos_espera').map(x => (x.id === 1 ? { ...x, nota: 'a', _fusion: { v: 1, origen: 'caja', nuevas: [] } } : x))); await A.mock.guardarTodo();
out.con_fusion = ['_fusion' in ultimo().body.upserts[0], A.mock.get('pos_espera').some(x => '_fusion' in x)];
A.mock.set('pos_espera', [...A.mock.get('pos_espera'), c(7)]); await A.mock.guardarTodo();
out.sin_reenvio = ultimo().body.upserts.map(x => x.id);
// 3) con un guardado más nuevo esperando, ese conserva su `_fusion` (lo incluye) y se manda después
let soltar; R.frenar = new Promise(res => { soltar = res; });
A.mock.set('pos_espera', A.mock.get('pos_espera').map(x => (x.id === 1 ? { ...x, nota: 'b', _fusion: { v: 1, origen: 'caja', nuevas: ['n1'] } } : x)));
const p = A.mock.guardarTodo(); await new Promise(res => setTimeout(res, 20));
A.mock.set('pos_espera', A.mock.get('pos_espera').map(x => (x.id === 1 ? { ...x, nota: 'c', _fusion: { v: 1, origen: 'caja', nuevas: ['n1', 'n2'] } } : x)));
R.frenar = null; soltar(); await p;
out.esperando = (A.mock.get('pos_espera').find(x => x.id === 1)._fusion || {}).nuevas || null;
await A.mock.guardarTodo();
out.despues = [ultimo().body.upserts[0]._fusion.nuevas, '_fusion' in A.mock.get('pos_espera').find(x => x.id === 1)];
// 4) sin conservados ni fusionados la versión sigue al día (no se baja la clave); con ellos, la próxima sincronización la baja
let g = R.gets; await A.mock.refrescar(['pos_espera']); out.sin_campos = R.gets - g;
R.extra = { fusionados: [1] }; A.mock.set('pos_espera', A.mock.get('pos_espera').map(x => (x.id === 1 ? { ...x, nota: 'd' } : x))); await A.mock.guardarTodo(); R.extra = null;
g = R.gets; await A.mock.refrescar(['pos_espera']); out.fusionados = R.gets - g;
await A.mock.cargar({ datos: { pos_espera: [c(1), c(4), c(5)] }, versiones: { pos_espera: R.ver.pos_espera }, topes: {}, rango: 0 });
R.extra = { conservados: [5] }; A.mock.set('pos_espera', A.mock.get('pos_espera').filter(x => x.id !== 5)); await A.mock.guardarTodo(); R.extra = null;
g = R.gets; await A.mock.refrescar(['pos_espera']); out.conservados = R.gets - g;
// 5) si el envío falla, la condición se reenvía con la baja; ya enviada, no se repite
await A.mock.cargar({ datos: { pos_espera: [c(1), c(4)] }, versiones: { pos_espera: R.ver.pos_espera }, topes: {}, rango: 0 });
const COND4 = { v: 1, quitadas: { l4: 1 } };
A.mock.condicionBaja('pos_espera', 4, COND4); R.fallar = true;
A.mock.set('pos_espera', A.mock.get('pos_espera').filter(x => x.id !== 4)); out.fallo = [await A.mock.guardarTodo(), ultimo().body.condiciones];
A.mock.set('pos_espera', A.mock.get('pos_espera')); await A.mock.guardarTodo();
out.reenvio = [ultimo().body.deletes, ultimo().body.condiciones];
A.mock.set('pos_espera', A.mock.get('pos_espera').filter(x => x.id !== 1)); await A.mock.guardarTodo();
out.ya_no = [ultimo().body.deletes, 'condiciones' in ultimo().body];
// 6) una condición cuyo elemento vuelve a guardarse (upsert) se descarta
await A.mock.cargar({ datos: { pos_espera: [c(8)] }, versiones: { pos_espera: R.ver.pos_espera }, topes: {}, rango: 0 });
A.mock.condicionBaja('pos_espera', 8, COND); A.mock.set('pos_espera', [c(8, { nota: 'x' })]); await A.mock.guardarTodo();
A.mock.set('pos_espera', []); await A.mock.guardarTodo();
out.descartada = [ultimo().body.deletes, 'condiciones' in ultimo().body];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=("api.js",), falsos=VUE)
    assert r["baja"] == [["condiciones", "deletes", "nuevos", "upserts"], [2, 3], {"2": {"v": 1, "quitadas": {"l2": 1}}}], r
    assert r["otra_clave"] == ["deletes", "nuevos", "upserts"], r                       # el cuerpo de siempre
    assert r["con_fusion"] == [True, False] and r["sin_reenvio"] == [7], r
    assert r["esperando"] == ["n1", "n2"] and r["despues"] == [["n1", "n2"], False], r
    assert r["sin_campos"] == 0 and r["fusionados"] == 1 and r["conservados"] == 1, r
    assert r["fallo"] == [False, {"4": {"v": 1, "quitadas": {"l4": 1}}}], r
    assert r["reenvio"] == [[4], {"4": {"v": 1, "quitadas": {"l4": 1}}}] and r["ya_no"] == [[1], False], r
    assert r["descartada"] == [[8], False], r


# ================================================================================================================ caja.js en dos equipos
def _fuente_caja() -> str:
    k = _js("pages/pos/caja.js")
    partes = [
        _tramo(k, "    persistirCuenta(devolverId) {", "    ponerEnEspera() {").strip().rstrip(","),   # con los métodos nuevos de 4.31
        _metodo(k, "seguirIds(key, cambios) {"), _linea(k, "cargarCuenta(v) {"), _metodo(k, "abrirMesa(m) {"), _metodo(k, "enviarComanda() {"),
        _metodo(k, "volverAMesas(sinPreguntar) {"), _metodo(k, "descartarVacia() {"), _metodo(k, "cuentaVacia() {"), _metodo(k, "async sincronizar() {"),
        _metodo(k, "agregar(p, cantidad = 1, opciones = null) {"), _metodo(k, "async cobrarParte(n) {"), _metodo(k, "cerrarPago() {"),
        _metodo(k, "async abrirPago() {"), _linea(k, "async borrarEspera(v) {"), _metodo(k, "moverA(m) {"), _linea(k, "totalDe(lineas, servicio, pct) {"),
        _metodo(k, "comandaNumerada(modo,"), _metodo(k, "ponerNumeroComanda(e, n) {"),   # 4.31 corrección: la comanda que se revisa antes de imprimir
    ]
    return ",\n".join(partes)


ARNES_MESA = r"""
globalThis.localStorage = { getItem: () => null, setItem() {}, removeItem() {}, key: () => null, length: 0 };
const copia = v => JSON.parse(JSON.stringify(v));
const espera = ms => new Promise(r => setTimeout(r, ms));
const r2 = n => Math.round((+n || 0) * 100) / 100;
const SRV = await import('./js/pages/pos/_fusion.js?servidor');
const S = globalThis.S = { items: [], ultimo: 0, version: 1, modo: 'nuevo', cuerpos: [], lento: false, perder: false };
const resp = j => ({ ok: true, status: 200, headers: { get: () => null }, json: async () => j });
const sinF = x => { const { _fusion, ...r } = x; return r; };
// el servidor: como modulos.aplicar_cambios (altas con remap; gana el último y la baja sin condición en modo «hoy»; con la regla en «nuevo»)
function aplicar(body) {
  const remap = {}, conservados = [], fusionados = [], nuevos = new Set((body.nuevos || []).map(String)), conds = body.condiciones || {};
  const siguiente = () => Math.max(S.ultimo, 0, ...S.items.map(y => y.id)) + 1;
  for (let x of body.upserts || []) {
    const i = S.items.findIndex(y => y.id === x.id);
    if (nuevos.has(String(x.id))) {
      x = sinF(x);
      if (i >= 0 || x.id <= S.ultimo) { const n = siguiente(); remap[String(x.id)] = n; x = { ...x, id: n }; }
      S.items.push(x); S.ultimo = Math.max(S.ultimo, x.id); continue;
    }
    if (S.modo === 'hoy') { if (i >= 0) S.items[i] = sinF(x); continue; }
    if (i >= 0) { const [res, f] = SRV.unir(S.items[i], x); S.items[i] = res; if (f) fusionados.push(x.id); continue; }
    const j = S.items.findIndex(y => SRV.esRecreadaDe(y, x.id));
    if (j >= 0) { const [res] = SRV.unir(S.items[j], { ...x, id: S.items[j].id }); S.items[j] = res; remap[String(x.id)] = res.id; fusionados.push(res.id); continue; }
    const n = siguiente(), rec = SRV.recrearCuenta(x, x.id, n);
    if (rec) { S.items.push(rec); S.ultimo = n; remap[String(x.id)] = n; fusionados.push(n); }
  }
  for (const id of body.deletes || []) {
    const i = S.items.findIndex(y => String(y.id) === String(id)); if (i < 0) continue;
    if (S.modo === 'nuevo' && conds[String(id)]) { const resto = SRV.cerrarCuenta(S.items[i], conds[String(id)]); if (resto) { S.items[i] = resto; conservados.push(id); continue; } }
    S.items.splice(i, 1);
  }
  S.version++;
  return { version: S.version, remap, ultimo_id: S.ultimo, ...(conservados.length ? { conservados } : {}), ...(fusionados.length ? { fusionados } : {}) };
}
globalThis.fetch = async (url, opt) => {
  const m = (opt && opt.method) || 'GET', body = opt && opt.body ? JSON.parse(opt.body) : null;
  if (url === '/api/registros/versiones') { if (S.lento) await espera(5000); return resp({ pos_espera: S.version }); }
  if (url === '/api/registros/pos_espera' && m === 'GET') return resp({ datos: copia(S.items), version: S.version, ultimo_id: S.ultimo });
  if (url === '/api/registros/pos_espera/cambios') {
    S.cuerpos.push(copia(body)); const r = aplicar(copia(body));
    if (S.perder) { S.perder = false; throw new TypeError('Failed to fetch'); }   // el servidor lo guardó, pero la respuesta se perdió
    return resp(r);
  }
  return resp(null);
};
const FN = Object.keys(SRV);
const NOMBRES = ['mock', 'toast', 'sesion', 'enEspera', 'uuid', 'r2', 'cuentasDeMesa', 'esDeco', 'servicioDeMesa', 'cajaPorId', 'cajaAbierta', 'promos', 'store', 'api', 'monedas', 'fmtCant', 'precioPara', 'confirm', 'revisarEstacion', 'avisarSiPendiente', 'guardarResumen', 'iniciarEstacion', 'pararEstacion', 'porAgente', 'pedirNumeroComanda', ...FN];   // 4.31: la estación de comandas no es de esta prueba
const NUMERO = globalThis.NUMERO = { siguiente: 76 };   /* el número de comanda que da el servidor (sin red) */
const FUENTE = %(fuente)s;
const SESION = { usuario: { correo: 'caja-431@example.test', nombre: 'Caja' }, empresaInfo: {} }, STORE = { clientes: [], productos: [] };
let nEquipo = 0;
// un equipo: su propio api.js y su propio _fusion.js (otro EQUIPO), con los métodos reales de caja.js
async function equipo() {
  const n = ++nEquipo, A = await import('./js/api.js?equipo=' + n), F = await import('./js/pages/pos/_fusion.js?equipo=' + n);
  await A.mock.cargar({ datos: { pos_espera: copia(S.items) }, versiones: { pos_espera: S.version }, topes: { pos_espera: S.ultimo }, rango: 0 });
  const toasts = [], enEsp = () => A.mock.get('pos_espera', []) || [];
  const M = new Function(...NOMBRES, 'return {' + FUENTE + '};')(A.mock, (m, t) => toasts.push([m, t || '']), SESION, enEsp, () => 'u' + Math.random(), r2,
    id => enEsp().filter(x => x.mesa_id === id), () => false, () => 0, () => null, () => null, () => [], STORE, async () => ({}), A.monedas, v => String(v), p => +p.precio || 0, () => true, () => {}, () => false, () => {}, () => {}, () => {},
    imp => !!imp && imp.conexion === 'usb', async () => ++NUMERO.siguiente, ...FN.map(k => F[k]));
  const vm = { espera: enEsp(), esperaId: null, nombreEspera: '', mesaActual: null, lineas: [], parteNueva: false, clienteId: null, nota: '', servicio: false, servicioPctCuenta: null,
    salonero: '', cfg: { id: 1, nombre: 'Caja salón', modo: 'restaurante', imprimir_comanda: false, cliente_defecto_id: null }, cobroParcial: null, pago: null, cobrando: false, dividir: null,
    unir: null, mover: null, lineaNota: null, modSel: null, pedido: null, habCargo: null, sincronizando: false, sync: 0, caja: null, promosLista: [], vista: 'mesas', rapida: true, idem: 'i',
    numerarComanda: '', esRestaurante: true, servicioPct: 0, cliente: null, prepago: null, $refs: {}, $nextTick: f => f && f(),
    destinoDe: () => null, imprimirComanda() {}, aplicarPromos() {}, descuentoDe: () => 0, oiLinea: () => ({ monto: 0, base: 0 }), tarifaNeta: l => +l.tarifa || 0,
    cobroPermitido: async () => true, abrirApertura() {}, gruposDe: () => [], stock: () => null, saldoFiado: async () => [], autorizar: async () => true,
    toasts, A, F };
  Object.defineProperty(vm, 'totales', { get() { let t = 0, it = 0; for (const l of this.lineas) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); t += m + m * (+l.tarifa || 0) / 100; it += +l.cantidad || 0; } return { total: r2(t), sub: 0, desc: 0, iva: 0, otros: 0, servicio: 0, items: it }; } });
  Object.defineProperty(vm, 'cuentaActual', { get() { return this.esperaId ? this.espera.find(v => v.id === this.esperaId) || null : null; } });
  Object.defineProperty(vm, 'cuentaCobro', { get() { if (this.esperaId) return this.cuentaActual; const cp = this.cobroParcial; return cp ? this.espera.find(v => v.id === cp.cuentaId) || null : null; } });
  for (const [k, f] of Object.entries(M)) vm[k] = f.bind(vm);
  A.mock.alCambiarIds((k, c) => vm.seguirIds(k, c));
  return vm;
}
const plato = (d, precio, pid, cant) => ({ producto_id: pid, detalle: d, cantidad: cant || 1, precio_unitario: precio, tarifa: 13, descuento: 0, descuento_pct: 0, nota: '', enviado: null, ronda: 0 });
const CASADO = () => plato('Casado', 3500, 1), LIMONADA = () => plato('Limonada', 1500, 2), POSTRE = () => plato('Postre', 1200, 3);
const M6 = { id: 6, nombre: 'Mesa 6' };
const comanda = async vm => { vm.enviarComanda(); vm.volverAMesas(false); await vm.A.mock.guardarTodo(); };
const mesas = async vm => { vm.volverAMesas(false); await vm.A.mock.guardarTodo(); };
const reiniciar = modo => Object.assign(S, { items: [], ultimo: 0, version: 1, modo: modo || 'nuevo', cuerpos: [], lento: false, perder: false });
// la Mesa 6 con esos platos (guardada por A); B y A la tienen abierta
async function mesaAbierta(platos, modo) {
  reiniciar(modo);
  const a = await equipo(), b = await equipo();
  a.abrirMesa(M6); for (const p of platos) a.lineas.push(p); await comanda(a);
  await b.sincronizar(); b.abrirMesa(M6); await a.sincronizar(); a.abrirMesa(M6);
  return [a, b];
}
const servidor = () => S.items.map(x => ({ id: x.id, nombre: x.nombre, mesa: x.mesa_id, platos: (x.lineas || []).map(l => l.detalle + '×' + l.cantidad), total: x.total }));
const avisos = vm => vm.toasts.map(t => t[0]);
const hasta = async f => { for (let i = 0; i < 100 && !f(); i++) await espera(10); };
const out = {};
"""


def _correr_mesa(tmp_path, guion):
    return _node(tmp_path, ARNES_MESA % {"fuente": json.dumps(_fuente_caja())} + guion + "\nconsole.log(JSON.stringify(out));\nprocess.exit(0);\n",
                 archivos=("api.js", "pages/pos/_fusion.js"), falsos=VUE)


TOTAL_3 = 3955 + 1695 + 1356        # Casado + Limonada + Postre con 13 % de IVA


def test_p2_p3_escenario_de_hoy_en_node(tmp_path):
    """P-2: A guarda Casado; B y A abren la Mesa 6; B agrega Limonada; A agrega Postre (atrasado o al día). Queda una sola cuenta con los
    tres. P-3: «Comanda» y «Mesas» guardan dos veces y sale un solo envío con lo acumulado; confirmado, la copia ya no tiene `_fusion`."""
    r = _correr_mesa(tmp_path, """
for (const [nombre, alDia, modo] of [['atrasado', false, 'nuevo'], ['al_dia', true, 'nuevo'], ['hoy_atrasado', false, 'hoy']]) {
  const [a, b] = await mesaAbierta([CASADO()], modo);
  b.lineas.push(LIMONADA()); await comanda(b);
  let antes = null;
  if (alDia) { await a.sincronizar(); antes = a.lineas.map(l => l.detalle); }
  const envios = S.cuerpos.length;
  a.lineas.push(POSTRE()); a.enviarComanda(); a.volverAMesas(false); await a.A.mock.guardarTodo();
  const cuerpo = S.cuerpos[S.cuerpos.length - 1];
  await b.sincronizar(); b.abrirMesa(M6);
  out[nombre] = { servidor: servidor(), b: b.lineas.map(l => l.detalle), antes, avisosA: avisos(a), envios: S.cuerpos.length - envios,
    nuevas: cuerpo.upserts[0]._fusion ? cuerpo.upserts[0]._fusion.nuevas.length : null, copiaA: a.A.mock.get('pos_espera').some(x => '_fusion' in x) };
}
""")
    for nombre in ("atrasado", "al_dia"):
        x = r[nombre]
        assert x["servidor"] == [{"id": 1, "nombre": "Mesa 6", "mesa": 6, "platos": ["Casado×1", "Limonada×1", "Postre×1"], "total": TOTAL_3}], (nombre, x)
        assert x["b"] == ["Casado", "Limonada", "Postre"], (nombre, x)
        assert x["envios"] == 1 and x["nuevas"] == 1 and x["copiaA"] is False, (nombre, x)          # P-3: un solo envío; sin `_fusion` al confirmarse
    assert r["al_dia"]["antes"] == ["Casado", "Limonada"], r                                         # A ya veía la Limonada
    assert "Se sumó 1 plato que agregó otro equipo a la cuenta de Mesa 6." in r["al_dia"]["avisosA"], r          # 4.31 corrección: singular
    assert r["atrasado"]["avisosA"] == ["Comanda 1 enviada", "Comanda 2 enviada"], r                 # nada más: lo une el servidor
    assert r["hoy_atrasado"]["servidor"][0]["platos"] == ["Casado×1", "Postre×1"], r                 # con el servidor de antes se pierde: hace falta el servidor


def test_p4_no_resucita_ni_pisa_lo_cobrado_en_node(tmp_path):
    r = _correr_mesa(tmp_path, """
// B quita la Limonada y guarda; A atrasado guarda el Postre: la Limonada no vuelve
let [a, b] = await mesaAbierta([CASADO(), LIMONADA()]);
b.lineas = b.lineas.filter(l => l.detalle !== 'Limonada'); await mesas(b);
a.lineas.push(POSTRE()); await comanda(a);
out.quitada = servidor();
// B cobra solo la Limonada (la cuenta queda con el resto, como «cobrar ahora solo esos»); A atrasado guarda: no vuelve ni se cobra dos veces
[a, b] = await mesaAbierta([CASADO(), LIMONADA()]);
b.lineas = b.lineas.filter(l => l.detalle !== 'Limonada'); b.persistirCuenta(true); await b.A.mock.guardarTodo();
a.lineas.push(POSTRE()); await comanda(a);
out.solo_esos = servidor();
// P-4 bis: A guarda el Postre (confirmado); B cobra el Postre; A vuelve a abrir la mesa desde su copia (sin sincronizar), agrega Limonada
[a, b] = await mesaAbierta([CASADO()]);
a.lineas.push(POSTRE()); await comanda(a);
await b.sincronizar(); b.abrirMesa(M6); b.lineas = b.lineas.filter(l => l.detalle !== 'Postre'); b.persistirCuenta(true); await b.A.mock.guardarTodo();
a.abrirMesa(M6); out.bis_copia = a.lineas.map(l => l.detalle); a.lineas.push(LIMONADA()); await comanda(a);
out.bis = servidor();
// P-4 bis con reenvío: el servidor guarda el Postre de A pero la respuesta se pierde; B cobra el Postre; A reenvía: no vuelve
[a, b] = await mesaAbierta([CASADO()]);
a.lineas.push(POSTRE()); S.perder = true; a.enviarComanda(); a.volverAMesas(false); out.perdido = await a.A.mock.guardarTodo();
out.perdido_fusion = a.A.mock.get('pos_espera').some(x => '_fusion' in x);
await b.sincronizar(); b.abrirMesa(M6); b.lineas = b.lineas.filter(l => l.detalle !== 'Postre'); b.persistirCuenta(true); await b.A.mock.guardarTodo();
a.abrirMesa(M6); a.lineas.push(LIMONADA()); await comanda(a);
out.reenvio = servidor(); out.reenvio_nuevas = S.cuerpos[S.cuerpos.length - 1].upserts[0]._fusion.nuevas.length;
// B cobra la parte 1 de 2; A, con la mesa abierta desde antes, cambia la nota de la cuenta y toca Mesas
const cobroDeParte = async (vm, doc) => {   // lo que hace emitirCobro con un cobro por partes (sin el comprobante)
  const cp = vm.cobroParcial;
  vm.actualizarCuenta(cp.cuentaId, x => ({ ...x, cobros: [...(x.cobros || []), { doc_id: doc, consecutivo: 'T' + doc, monto: 1, parte: cp.parte }], partes: x.partes ? { ...x.partes, cobradas: (+x.partes.cobradas || 0) + 1 } : x.partes }));
  const c = vm.espera.find(x => x.id === cp.cuentaId);
  if (c && !(c.lineas || []).length) { await Promise.race([vm.A.mock.guardarTodo(), espera(3000)]); vm.bajaCuenta(cp.cuentaId, vm.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), c.nombre, true); }
  vm.cobroParcial = null; vm.pago = null; await vm.A.mock.guardarTodo();
};
[a, b] = await mesaAbierta([plato('Casado', 3500, 1, 2)]);
await b.cobrarParte(2); out.parte_pago = [b.cobroParcial.parte, b.cobroParcial.de, b.lineas.map(l => l.cantidad)]; await cobroDeParte(b, 101);
a.nota = 'Cumpleaños'; await mesas(a);
out.partes_nota = S.items.map(x => [x.lineas.map(l => l.cantidad), x.cobros.map(c => c.doc_id), x.partes, x.nota]);
await b.sincronizar(); b.abrirMesa(M6); await b.cobrarParte(2); out.parte2 = [b.cobroParcial.parte, b.cobroParcial.de];
// B cobra por partes; A atrasado guarda el Postre: cantidades a la mitad y el Postre sumado
[a, b] = await mesaAbierta([plato('Casado', 3500, 1, 2)]);
await b.cobrarParte(2); await cobroDeParte(b, 102);
a.lineas.push(POSTRE()); await comanda(a);
out.partes_postre = servidor();
// A cierra un cobro por partes sin cobrar: los platos vuelven a la cuenta (en una sola línea)
[a, b] = await mesaAbierta([plato('Casado', 3500, 1, 2)]);
await a.cobrarParte(2);
/* 4.31 (sexta vuelta, M1): este arnés contesta {} al pedir el cobro (sin «ganada»): no se sabe si otro equipo la cobró y la parte no vuelve */
await a.cerrarPago(); await a.A.mock.guardarTodo(); out.sin_respuesta = [!!a.pago, a.cobroParcial && a.cobroParcial.parte, S.items.map(x => x.lineas.map(l => l.detalle + '×' + l.cantidad))];
a.reclamarCobro = async () => null;   /* un servidor sin la ruta del cobro: como siempre */
await a.cerrarPago(); await a.A.mock.guardarTodo();   /* 4.31 (quinta vuelta): antes pregunta al servidor qué se cobró */
out.cerrar_pago = S.items.map(x => [x.lineas.map(l => l.detalle + '×' + l.cantidad), x.partes]);
""")
    assert [x["platos"] for x in r["quitada"]] == [["Casado×1", "Postre×1"]], r
    assert [x["platos"] for x in r["solo_esos"]] == [["Casado×1", "Postre×1"]], r
    assert r["bis_copia"] == ["Casado", "Postre"] and [x["platos"] for x in r["bis"]] == [["Casado×1", "Limonada×1"]], r
    assert r["perdido"] is False and r["perdido_fusion"] is True, r
    assert [x["platos"] for x in r["reenvio"]] == [["Casado×1", "Limonada×1"]] and r["reenvio_nuevas"] == 2, r
    assert r["parte_pago"] == [1, 2, [1]], r
    assert r["partes_nota"] == [[[1], [101], {"total": 2, "cobradas": 1}, "Cumpleaños"]], r
    assert r["parte2"] == [2, 2], r                                                                   # el siguiente cobro es «parte 2 de 2»
    assert [x["platos"] for x in r["partes_postre"]] == [["Casado×1", "Postre×1"]], r
    assert r["sin_respuesta"] == [True, 1, [["Casado×1"]]], r                                       # sexta vuelta: sin respuesta clara, sigue abierta
    assert r["cerrar_pago"] == [[["Casado×2"], None]], r


def test_p5_no_rompe_en_node(tmp_path):
    r = _correr_mesa(tmp_path, """
// mover de mesa: otro equipo guarda con la mesa vieja y queda la nueva
let [a, b] = await mesaAbierta([CASADO()]);
b.moverA({ id: 8, nombre: 'Mesa 8' }); await b.A.mock.guardarTodo();
a.lineas.push(POSTRE()); await comanda(a);
out.mover = servidor();
// 4.31 corrección (b): lo mismo con A al día (sincroniza antes de guardar): la mesa, la nota y el salonero que puso B pasan a la pantalla
// de A y su guardado ya no los deshace
[a, b] = await mesaAbierta([CASADO()]);
b.moverA({ id: 8, nombre: 'Mesa 8' }); b.nota = 'Alergia al maní'; b.salonero = 'Luis'; b.persistirCuenta(); await b.A.mock.guardarTodo();
await a.sincronizar(); out.mover_pantalla = [a.mesaActual && a.mesaActual.id, a.nombreEspera, a.nota, a.salonero];
a.lineas.push(POSTRE()); await comanda(a);
out.mover_al_dia = S.items.map(x => [x.mesa_id, x.nombre, x.nota, x.salonero, x.lineas.map(l => l.detalle)]);
// y lo que A sí cambió en su pantalla se manda (no lo pisa lo del otro equipo)
[a, b] = await mesaAbierta([CASADO()]);
b.nota = 'De B'; b.persistirCuenta(); await b.A.mock.guardarTodo();
a.salonero = 'Ana'; await a.sincronizar(); await mesas(a);
out.mover_propio = S.items.map(x => [x.nota, x.salonero]);
// agregar el mismo producto a una línea ya guardada (sin enviar) va en una línea aparte; a una línea nueva de la pantalla, se suma
reiniciar();
const c = await equipo(); c.abrirMesa(M6);
const COCA = { id: 5, nombre: 'Coca', precio: 1000, tarifa: 13 };
c.agregar(COCA); c.agregar(COCA); out.nueva = c.lineas.map(l => l.cantidad);
c.persistirCuenta(); await c.A.mock.guardarTodo(); c.volverAMesas(true); c.abrirMesa(M6); c.agregar(COCA); out.guardada = c.lineas.map(l => l.cantidad);   /* «Guardar cuenta» sin enviar */
c.agregar(COCA); out.guardada2 = c.lineas.map(l => l.cantidad);
// pedido en línea con prepago: lo que agrega la caja no le quita lo pagado ni el enlace con el pedido
reiniciar();
S.items = [{ id: 3, nombre: 'Pedido #9 · Ana', mesa_id: 6, terminal_id: 1, canal: 'online', pedido_id: 9, pedido_numero: 9, prepago: { monto: 5000, online: 5000 }, credito: false, puntos_canjeados: 0, cupon: null,
  lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 1, precio_unitario: 3500, tarifa: 13, enviado: 'E', ronda: 1 }], total: 3955 }]; S.ultimo = 3;
const p = await equipo(); p.abrirMesa(M6); p.lineas.push(POSTRE()); await comanda(p);
out.pedido = S.items.map(x => [x.canal, x.pedido_id, x.prepago, x.lineas.map(l => l.detalle), '_fusion' in x]);
// alta (dos equipos crean a la vez la primera cuenta, T1): sin `_fusion` y cada uno con su cuenta
reiniciar();
const e1 = await equipo(), e2 = await equipo();
e1.abrirMesa({ id: 1, nombre: 'Mesa 1' }); e1.lineas.push(CASADO()); e2.abrirMesa({ id: 5, nombre: 'Mesa 5' }); e2.lineas.push(LIMONADA());
e1.enviarComanda(); e2.enviarComanda();
out.altas = [S.cuerpos.length, ...(await Promise.all([e1.A.mock.guardarTodo(), e2.A.mock.guardarTodo()]))];
out.altas_srv = [servidor().map(x => [x.id, x.nombre]), S.cuerpos.every(c => c.upserts.every(u => !('_fusion' in u))), avisos(e2)];
""")
    assert r["mover"] == [{"id": 1, "nombre": "Mesa 8", "mesa": 8, "platos": ["Casado×1", "Postre×1"], "total": 3955 + 1356}], r
    assert r["mover_pantalla"] == [8, "Mesa 8", "Alergia al maní", "Luis"], r
    assert r["mover_al_dia"] == [[8, "Mesa 8", "Alergia al maní", "Luis", ["Casado", "Postre"]]], r
    assert r["mover_propio"] == [["De B", "Ana"]], r
    assert r["nueva"] == [2] and r["guardada"] == [2, 1] and r["guardada2"] == [2, 2], r
    assert r["pedido"] == [["online", 9, {"monto": 5000, "online": 5000}, ["Casado", "Postre"], False]], r
    assert r["altas"] == [0, True, True], r
    assert r["altas_srv"] == [[[1, "Mesa 1"], [2, "Mesa 5"]], True, ["Comanda 1 enviada"]], r


def test_p6_bajas_y_cobro_con_un_plato_agregado_en_medio_en_node(tmp_path):
    r = _correr_mesa(tmp_path, """
// (a) A abre la Mesa 6 = [Casado]; B agrega Limonada y Comanda; A quita el Casado: la cuenta queda con la Limonada y A recibe el aviso
let [a, b] = await mesaAbierta([CASADO()]);
b.lineas.push(LIMONADA()); await comanda(b);
a.lineas = []; a.cuentaVacia(); await a.A.mock.guardarTodo();
const AVISO_A = 'Mientras se cobraba o se cerraba Mesa 6, otro equipo le agregó 1 plato. Quedó en la mesa sin cobrar.';
await hasta(() => avisos(a).includes(AVISO_A));
out.a = { servidor: servidor(), condicion: S.cuerpos[S.cuerpos.length - 1].condiciones, avisos: avisos(a) };
// (b) B cobra la última parte y A había agregado Postre: la baja conserva el Postre
reiniciar();
S.items = [{ id: 1, nombre: 'Mesa 6', mesa_id: 6, terminal_id: 1, lineas: [{ lid: 'lC', producto_id: 1, detalle: 'Casado', cantidad: 1, precio_unitario: 3500, tarifa: 13, enviado: 'E', ronda: 1 }],
  partes: { total: 2, cobradas: 1 }, cobros: [{ doc_id: 100, consecutivo: 'T100' }], total: 3955 }]; S.ultimo = 1;
a = await equipo(); b = await equipo(); a.abrirMesa(M6); b.abrirMesa(M6);
await b.cobrarParte(2); await b.A.mock.guardarTodo();
a.lineas.push(POSTRE()); await comanda(a);
const cp = b.cobroParcial;
b.actualizarCuenta(cp.cuentaId, x => ({ ...x, cobros: [...(x.cobros || []), { doc_id: 101, consecutivo: 'T101' }], partes: { ...x.partes, cobradas: 2 } }));
const cb = b.espera.find(x => x.id === cp.cuentaId); if (cb && !(cb.lineas || []).length) { await Promise.race([b.A.mock.guardarTodo(), espera(3000)]); b.bajaCuenta(cp.cuentaId, b.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), cb.nombre, true); }   /* como emitirCobro (lo cobrado en esta parte) */
b.cobroParcial = null; await b.A.mock.guardarTodo(); await hasta(() => avisos(b).some(t => t.startsWith('Mientras se cobraba')));
out.b = { servidor: servidor(), cobros: S.items.map(x => x.cobros.map(c => c.doc_id)), partes: S.items.map(x => x.partes), avisos: avisos(b).filter(t => t.startsWith('Mientras')) };
// (c) B cobra y manda la baja; el Postre de A llega DESPUÉS: queda en una cuenta nueva de la Mesa 6 y A lo sabe; un reenvío no crea otra
[a, b] = await mesaAbierta([CASADO()]);
a.lineas.push(POSTRE()); a.enviarComanda();                       // el envío de A sale a los 300 ms
b.bajaCuenta(b.esperaId, b.lineas.map(l => ({ lid: l.lid, cantidad: l.cantidad })), 'Mesa 6'); await b.A.mock.guardarTodo();
await a.A.mock.guardarTodo();
const envioA = S.cuerpos[S.cuerpos.length - 1];
out.c = { servidor: servidor(), recreada_de: S.items.map(x => x.recreada_de), esperaA: a.esperaId, avisos: avisos(a).filter(t => t.startsWith('La cuenta de')) };
await hasta(() => a.lineas.length === 1); out.c.pantalla = a.lineas.map(l => l.detalle); out.c.plano = a.espera.map(x => [x.id, x.total]);   /* sin esperar la sincronización de 15 s */
aplicar(copia(envioA)); out.c.reenvio = servidor().length;
// (d) B abre el cobro con Cerveza ×1; A la sube a ×2 y guarda; B emite por 1: queda una Cerveza en la mesa
[a, b] = await mesaAbierta([plato('Cerveza', 1500, 4)]);
const cobradas = b.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad }));
a.lineas[0].cantidad = 2; await mesas(a);
b.bajaCuenta(b.esperaId, cobradas, 'Mesa 6'); await b.A.mock.guardarTodo();
out.d = S.items.map(x => x.lineas.map(l => [l.detalle, l.cantidad, l.lid.endsWith('~1')]));
// (e) antes de cobrar: A agregó Postre; B con la cuenta abierta toca Cobrar: el total ya lo incluye y sale el aviso
[a, b] = await mesaAbierta([CASADO()]);
a.lineas.push(POSTRE()); await comanda(a);
await b.abrirPago();
out.e = { monto: b.pago && b.pago.medios[0].monto, platos: b.lineas.map(l => l.detalle), avisos: avisos(b).filter(t => t.startsWith('La cuenta de')) };
// (e) con el servidor tardando 5 s, el cobro abre a los 1,5 s con la copia local
[a, b] = await mesaAbierta([CASADO()]);
a.lineas.push(POSTRE()); await comanda(a);
S.lento = true; let t0 = Date.now(); await b.abrirPago(); const ms = Date.now() - t0; S.lento = false;
out.e_lento = { monto: b.pago && b.pago.medios[0].monto, rapido: ms >= 1400 && ms < 3000 };
// (f) borrarEspera con un plato agregado en medio: la cuenta queda con ese plato
[a, b] = await mesaAbierta([CASADO()]);
b.lineas.push(LIMONADA()); await comanda(b);
a.volverAMesas(true); await a.borrarEspera(a.espera.find(x => x.id === 1)); await a.A.mock.guardarTodo();
out.f = servidor();
""")
    a = r["a"]
    assert [x["platos"] for x in a["servidor"]] == [["Limonada×1"]] and list(a["condicion"]) == ["1"], r
    assert "Mientras se cobraba o se cerraba Mesa 6, otro equipo le agregó 1 plato. Quedó en la mesa sin cobrar." in a["avisos"], r
    b = r["b"]
    assert [x["platos"] for x in b["servidor"]] == [["Postre×1"]] and b["cobros"] == [[100, 101]] and b["partes"] == [{"total": 2, "cobradas": 2}], r
    assert b["avisos"] == ["Mientras se cobraba o se cerraba Mesa 6, otro equipo le agregó 1 plato. Quedó en la mesa sin cobrar."], r
    c = r["c"]
    assert [x["platos"] for x in c["servidor"]] == [["Postre×1"]] and c["recreada_de"] == [1] and c["esperaA"] == 2 and c["reenvio"] == 1, r
    assert c["avisos"] == ["La cuenta de Mesa 6 se cobró o se cerró en otro equipo mientras usted agregaba platos. Lo que agregó quedó en Mesa 6 como cuenta nueva."], r
    # 4.31 corrección (f): junto al aviso, la pantalla y el plano ya muestran solo lo que quedó en la cuenta nueva (no lo ya cobrado)
    assert c["pantalla"] == ["Postre"] and c["plano"] == [[2, 1356]], r
    assert r["d"] == [[["Cerveza", 1, True]]], r
    assert r["e"] == {"monto": 3955 + 1356, "platos": ["Casado", "Postre"], "avisos": ["La cuenta de Mesa 6 cambió en otro equipo. Revise el total antes de cobrar."]}, r
    assert r["e_lento"] == {"monto": 3955, "rapido": True}, r
    assert [x["platos"] for x in r["f"]] == [["Limonada×1"]], r


# ================================================================================================================ correcciones de la 4.31
def test_comanda_desde_una_pantalla_atrasada_en_node(tmp_path):
    """Prueba en navegador (alta): B tenía la Mesa 6 abierta con la Limonada guardada sin enviar; A la quitó; B, sin sincronizar, agrega el
    Postre y toca «Comanda». Antes el Bar imprimía la Limonada, que no quedaba en la cuenta, y nadie avisaba. Ahora la caja espera a que el
    servidor guarde la cuenta (3 s como mucho) e imprime solo lo que sigue en ella, con el aviso en el momento; si no se puede saber,
    imprime todo y esos platos quedan en la cuenta como pedido nuevo (nunca un plato impreso que no se cobra)."""
    r = _correr_mesa(tmp_path, """
const COCINA = { id: 'c', nombre: 'Cocina', conexion: 'usb' };
const imprimeEn = (vm, lista) => { vm.cfg.imprimir_comanda = true; vm.destinoDe = () => COCINA; vm.imprimirComanda = (g, ronda, d) => { for (const x of Object.values(g)) for (const l of x.ls) lista.push(l.detalle + (d && d.numero ? ' #' + d.numero : '')); }; };
async function atrasada() {
  const [a, b] = await mesaAbierta([CASADO()]);
  a.lineas.push(LIMONADA()); await mesas(a);                                     // la Limonada queda guardada sin enviar
  await b.sincronizar();                                                         // B la ve (guardada, sin enviar)
  await a.sincronizar(); a.abrirMesa(M6); a.lineas = a.lineas.filter(l => l.detalle !== 'Limonada'); await mesas(a);   // A la quita
  return [a, b];
}
// sin número de comanda
let [a, b] = await atrasada();
out.b_ve = b.lineas.map(l => [l.detalle, !!l.enviado]);
let impresos = []; imprimeEn(b, impresos);
b.lineas.push(POSTRE()); let p = b.enviarComanda(); out.promesa = typeof (p && p.then); await p; await b.A.mock.guardarTodo();
out.sin_numero = { impresos, servidor: servidor().map(x => x.platos), pantalla: b.lineas.map(l => l.detalle), avisos: avisos(b).slice(-2) };
// con número de comanda: lo mismo, y el número va solo en lo que sale
[a, b] = await atrasada();
impresos = []; imprimeEn(b, impresos); b.numerarComanda = 'dia';
b.lineas.push(POSTRE()); await b.enviarComanda(); await b.A.mock.guardarTodo();
out.con_numero = { impresos, servidor: servidor().map(x => x.platos), avisos: avisos(b).slice(-2), comanda: S.items[0].lineas.map(l => [l.detalle, l.comanda || null]) };
// todo lo de la comanda ya no estaba: no se imprime nada ni dice «enviada»
[a, b] = await atrasada();
impresos = []; imprimeEn(b, impresos);
p = b.enviarComanda(); await p; await b.A.mock.guardarTodo();
out.nada = { impresos, servidor: servidor().map(x => x.platos), avisos: avisos(b).slice(-1) };
// una comanda de platos nuevos (sin nada guardado sin enviar) sale como siempre, en el acto
[a, b] = await mesaAbierta([CASADO()]);
impresos = []; imprimeEn(b, impresos);
b.lineas.push(POSTRE()); const r0 = b.enviarComanda(); out.en_el_acto = [r0 === undefined, impresos.slice(), avisos(b).slice(-1)];
await b.A.mock.guardarTodo();
// no se puede saber (el servidor no contesta las versiones en 3 s): sale todo y la Limonada queda en la cuenta como pedido nuevo
[a, b] = await atrasada();
impresos = []; imprimeEn(b, impresos);
b.lineas.push(POSTRE()); S.lento = true; const t0 = Date.now(); p = b.enviarComanda(); await p; const ms = Date.now() - t0;
await espera(400); await b.A.mock.guardarTodo();
out.sin_saber = { impresos, ms: ms >= 2900 && ms < 4500, servidor: servidor().map(x => x.platos), lids: S.items[0].lineas.map(l => l.lid), quitados: S.items[0].lids_quitados, avisos: avisos(b).slice(-1) };
""")
    assert r["b_ve"] == [["Casado", True], ["Limonada", False]], r
    assert r["promesa"] == "function", r
    s = r["sin_numero"]
    assert s["impresos"] == ["Postre"], r                                                           # la Limonada no sale
    assert s["servidor"] == [["Casado×1", "Postre×1"]] and s["pantalla"] == ["Casado", "Postre"], r
    assert s["avisos"] == ["No salió en la comanda: Limonada. En otro equipo ya se había quitado o cobrado de Mesa 6.", "Comanda 2 enviada a Cocina"], r
    c = r["con_numero"]
    assert c["impresos"] == ["Postre #77"] and c["servidor"] == [["Casado×1", "Postre×1"]], r
    assert c["avisos"] == ["No salió en la comanda: Limonada. En otro equipo ya se había quitado o cobrado de Mesa 6.", "Comanda N.º 77 enviada a Cocina"], r
    assert c["comanda"] == [["Casado", None], ["Postre", 77]], r
    n = r["nada"]
    assert n["impresos"] == [] and n["servidor"] == [["Casado×1"]], r
    assert n["avisos"] == ["No salió en la comanda: Limonada. En otro equipo ya se había quitado o cobrado de Mesa 6."], r
    assert r["en_el_acto"] == [True, ["Postre"], ["Comanda 2 enviada a Cocina"]], r
    x = r["sin_saber"]
    assert x["impresos"] == ["Limonada", "Postre"] and x["ms"] is True, r
    assert x["servidor"] == [["Casado×1", "Postre×1", "Limonada×1"]], r                            # lo impreso queda en la cuenta
    assert x["lids"][2] not in x["quitados"] and x["avisos"] == ["Comanda 2 enviada a Cocina"], r


def test_correcciones_de_la_misma_mesa_en_node(tmp_path):
    r = _correr_mesa(tmp_path, """
// (c) dos equipos parten a la vez la misma línea (Casado ×2, «cobrar parte 1 de 2» en los dos): queda un solo resto, no dos
let [a, b] = await mesaAbierta([plato('Casado', 3500, 1, 2)]);
await Promise.all([a.cobrarParte(2), b.cobrarParte(2)]); await Promise.all([a.A.mock.guardarTodo(), b.A.mock.guardarTodo()]);
out.partir_doble = S.items.map(x => x.lineas.map(l => [l.detalle, l.cantidad, typeof l.de === 'string']));
// un segundo toque de «Cobrar parte» mientras se espera a la red no vuelve a partir ni junta la parte con la cuenta
[a, b] = await mesaAbierta([plato('Casado', 3500, 1, 2)]);
await Promise.all([b.cobrarParte(2), b.cobrarParte(2)]); await b.A.mock.guardarTodo();
out.doble_toque = [S.items.map(x => x.lineas.map(l => l.cantidad)), b.cobroParcial && [b.cobroParcial.parte, b.cobroParcial.de], b.lineas.map(l => l.cantidad), avisos(b).filter(t => t.includes('se juntaron'))];
// el alta que hizo esta pantalla, ya confirmada: si otro equipo cobra la cuenta y lo agregado queda en una cuenta nueva, también avisa
reiniciar();
a = await equipo(); a.abrirMesa(M6); a.lineas.push(CASADO()); a.enviarComanda(); await a.A.mock.guardarTodo();
b = await equipo(); b.abrirMesa(M6); b.bajaCuenta(b.esperaId, b.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), 'Mesa 6', true); await b.A.mock.guardarTodo();
a.lineas.push(POSTRE()); a.enviarComanda(); await a.A.mock.guardarTodo(); await hasta(() => a.lineas.length === 1);
out.alta_propia = { avisos: avisos(a).filter(t => t.startsWith('La cuenta de')), servidor: servidor().map(x => [x.id, x.platos]), pantalla: a.lineas.map(l => l.detalle) };
// el total del plano: lo corrige solo una pantalla que calcula como la cuenta guardada (con la exoneración elegida aquí, no)
[a, b] = await mesaAbierta([CASADO()]);
S.items[0].total = 9999; S.version++;
let n0 = S.cuerpos.length; a.exoAplica = true; await a.sincronizar(); await a.A.mock.guardarTodo(); const conExo = S.cuerpos.length - n0;
n0 = S.cuerpos.length; a.servicio = true; a.exoAplica = false; await a.sincronizar(); await a.A.mock.guardarTodo(); const otroServicio = S.cuerpos.length - n0;
n0 = S.cuerpos.length; a.servicio = false; await a.sincronizar(); await a.A.mock.guardarTodo();
out.total_plano = [conExo, otroServicio, S.cuerpos.length - n0, S.items[0].total];
// (g) en plural: dos platos de otro equipo
[a, b] = await mesaAbierta([CASADO()]);
b.lineas.push(LIMONADA(), POSTRE()); await comanda(b);
await a.sincronizar(); out.plural = avisos(a).slice(-1);
b.abrirMesa(M6); b.lineas = b.lineas.filter(l => l.detalle === 'Casado'); await mesas(b);
await a.sincronizar(); out.plural_quitadas = avisos(a).slice(-1);
// (d) cobro de un pedido en línea con prepago mientras otro equipo le agrega un plato: la cuenta que queda no se lleva lo ya pagado,
// tampoco cuando la pantalla atrasada vuelve a guardar
reiniciar();
S.items = [{ id: 3, nombre: 'Pedido #9 · Ana', mesa_id: 6, terminal_id: 1, canal: 'online', pedido_id: 9, pedido_numero: 9, prepago: { monto: 5000, online: 5000 }, cupon: 'QA10', puntos_canjeados: 20, credito: false,
  lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 1, precio_unitario: 3500, tarifa: 13, enviado: 'E', ronda: 1 }], total: 3955 }]; S.ultimo = 3;
a = await equipo(); b = await equipo(); a.abrirMesa(M6); b.abrirMesa(M6);
a.lineas.push(LIMONADA()); await comanda(a);
b.bajaCuenta(b.esperaId, b.lineas.map(l => ({ lid: l.lid, cantidad: +l.cantidad })), 'Pedido #9 · Ana', true); await b.A.mock.guardarTodo();
out.prepago = S.items.map(x => [x.lineas.map(l => l.detalle), x.prepago, x.cupon, x.puntos_canjeados, x.pedido_id]);
a.abrirMesa(M6); a.lineas.push(POSTRE()); await comanda(a);                     /* A con su copia de antes del cobro (todavía con el prepago) */
out.prepago_despues = S.items.map(x => [x.lineas.map(l => l.detalle), x.prepago, x.cupon, x.puntos_canjeados]);
""")
    assert r["partir_doble"] == [[["Casado", 1, True]]], r                                          # antes: dos restos (2 Casados)
    assert r["doble_toque"] == [[[1]], [1, 2], [1], []], r
    a = r["alta_propia"]
    assert a["avisos"] == ["La cuenta de Mesa 6 se cobró o se cerró en otro equipo mientras usted agregaba platos. Lo que agregó quedó en Mesa 6 como cuenta nueva."], r
    assert a["servidor"] == [[2, ["Postre×1"]]] and a["pantalla"] == ["Postre"], r
    assert r["total_plano"] == [0, 0, 1, 3955], r                                                  # antes: también con exoneración o con otro servicio
    assert r["plural"] == ["Se sumaron 2 platos que agregó otro equipo a la cuenta de Mesa 6."], r
    assert r["plural_quitadas"] == ["En otro equipo se quitaron o cobraron 2 platos de Mesa 6. La cuenta quedó como está ahora."], r
    assert r["prepago"] == [[["Limonada"], None, None, 0, 9]], r
    assert r["prepago_despues"] == [[["Limonada", "Postre"], None, None, 0]], r


def test_2x1_con_el_mismo_producto_en_lineas_aparte_en_node(tmp_path):
    """Revisión (media): con la «línea aparte» de la misma mesa, dos Cervezas ×1 ya no reciben el 2x1 que la 4.29 daba a una Cerveza ×2. El
    2x1 se calcula sobre la cantidad de todas las líneas que antes iban juntas (mismo producto, sin nota ni precio a mano, sin enviar o
    enviadas en la misma comanda); lo demás, por línea como siempre."""
    k = _js("pages/pos/caja.js")
    r = _node(tmp_path, """
const r2 = n => Math.round((+n || 0) * 100) / 100;
const M = new Function('r2', 'return {' + %s + '};')(r2);
const vm = { promosActivas: [{ tipo: '2x1', nombre: '2x1 cervezas', productos: [4] }],
  descuentoDe(l) { const m = (+l.cantidad || 0) * (+l.precio_unitario || 0); return Math.max(0, Math.min(m, l.descuento_pct ? m * (+l.descuento_pct) / 100 : (+l.descuento || 0))); } };
vm.aplicarPromos = M.aplicarPromos.bind(vm);
const cerveza = (c, extra) => ({ producto_id: 4, detalle: 'Cerveza', cantidad: c, precio_unitario: 1800, descuento: 0, descuento_pct: 0, nota: '', enviado: null, ronda: 0, ...(extra || {}) });
const caso = ls => { vm.lineas = ls; vm.aplicarPromos(); return ls.map(l => [l.descuento_pct, l.promo || '', l.descuento]); };
console.log(JSON.stringify({
  aparte: caso([cerveza(1, { lid: 'lA' }), cerveza(1, { lid: 'lB' })]),
  misma_comanda: caso([cerveza(1, { enviado: 'E1', ronda: 1 }), cerveza(1, { enviado: 'E1', ronda: 1 })]),
  otra_comanda: caso([cerveza(1, { enviado: 'E1', ronda: 1 }), cerveza(1)]),
  con_nota: caso([cerveza(1), cerveza(1, { nota: 'sin hielo' })]),
  una: caso([cerveza(2)]),
  tres: caso([cerveza(1), cerveza(1), cerveza(1)]),
  otro_producto: caso([cerveza(1), { ...cerveza(1), producto_id: 5, detalle: 'Agua' }]),
}));
""" % json.dumps(_metodo(k, "aplicarPromos(forzar) {")), archivos=(), falsos={})
    dos = [50, "2x1 cervezas", 900]
    assert r["aparte"] == [dos, dos] and r["misma_comanda"] == [dos, dos], r                        # antes: [0, '', 0] en las dos
    assert r["otra_comanda"] == [[0, "", 0], [0, "", 0]] and r["con_nota"] == [[0, "", 0], [0, "", 0]], r   # como la 4.29: no iban juntas
    assert r["una"] == [[50, "2x1 cervezas", 1800]], r
    assert r["tres"] == [[33.33, "2x1 cervezas", 599.94]] * 3, r
    assert r["otro_producto"] == [[0, "", 0], [0, "", 0]], r


# ================================================================================================================ cocina.js: «aplicar»
def test_cocina_aplicar_solo_manda_sus_marcas_en_node(tmp_path):
    k = _js("pages/pos/cocina.js")
    aplicar = _metodo(k, "async aplicar(cuentaId, fn) {")
    assert "await import('./_fusion.js').catch(() => null)" in aplicar and "F.conFusionDe(F.ponerLids(v), fn(v), 'cocina')" in aplicar
    assert (JS / "pages/pos/_fusion.js").exists()
    fuente = aplicar.replace("import('./_fusion.js')", "cargarFusion()")
    r = _node(tmp_path, """
const F = await import('./js/pages/pos/_fusion.js');
const Q = { datos: {} };
const mock = { puedeGuardar: () => true, refrescar: async () => [], get: (k, d) => (k in Q.datos ? JSON.parse(JSON.stringify(Q.datos[k])) : d), actualizar(k, f, d) { Q.datos[k] = f(this.get(k, d)); return Q.datos[k]; } };
const M = new Function('mock', 'cargarFusion', 'return {' + %s + '};')(mock, () => Promise.resolve(F));
const vm = { reloj: 0 }; vm.aplicar = M.aplicar.bind(vm);
Q.datos.pos_espera = [{ id: 6, nombre: 'Mesa 6', lineas: [{ producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: 'E', ronda: 1 }] }];
await vm.aplicar(6, v => ({ ...v, estado: 'listo', lineas: v.lineas.map(x => ({ ...x, listo: 'h', cantidad: 9 })) }));
const enviado = Q.datos.pos_espera[0];
// el servidor tiene además un plato que la caja acaba de agregar: queda, con la marca y sin la cantidad que «cambió» la cocina
const guardada = { id: 6, nombre: 'Mesa 6', lineas: [{ lid: 'h:6:1:E:0', producto_id: 1, detalle: 'Casado', cantidad: 1, enviado: 'E', ronda: 1 }, { lid: 'lP', producto_id: 3, detalle: 'Postre', cantidad: 1 }] };
const [res] = F.unir(guardada, enviado);
console.log(JSON.stringify({ fusion: enviado._fusion, res: res.lineas.map(l => [l.detalle, l.cantidad, l.listo || null]), estado: res.estado }));
""" % json.dumps(fuente), archivos=("pages/pos/_fusion.js",), falsos={})
    f = r["fusion"]
    assert f["origen"] == "cocina" and f["nuevas"] == [] and f["quitadas"] == {} and f["campos"] == {"h:6:1:E:0": ["cantidad", "listo"]} and f["cuenta"] == ["estado"], r
    assert r["res"] == [["Casado", 1, "h"], ["Postre", 1, None]] and r["estado"] == "listo", r


# ================================================================================================================ textos y contrato
def test_textos_y_contrato_de_las_pantallas():
    k, a, c, f = _js("pages/pos/caja.js"), _js("api.js"), _js("pages/pos/cocina.js"), _js("pages/pos/_fusion.js")
    assert "from './_fusion.js';" in k and "import" not in "\n".join(x for x in f.splitlines() if x.startswith("import"))
    assert not any(x.startswith("import ") for x in f.splitlines())                                   # _fusion.js no importa nada
    for texto in ("'Se sumó 1 plato que agregó otro equipo a la cuenta de ' + m + '.'", "'Se sumaron ' + a + ' platos que agregó otro equipo a la cuenta de ' + m + '.'",
                  "'En otro equipo se quitó o cobró 1 plato de ' + m + '. La cuenta quedó como está ahora.'",
                  "'En otro equipo se quitaron o cobraron ' + q + ' platos de ' + m + '. La cuenta quedó como está ahora.'",
                  "'La cuenta de ' + (this.nombreEspera || 'la cuenta') + ' cambió en otro equipo. Revise el total antes de cobrar.'",
                  "'Mientras se cobraba o se cerraba ' + ", "'1 plato. Quedó en la mesa sin cobrar.' : k + ' platos. Quedaron en la mesa sin cobrar.'",
                  "' se cobró o se cerró en otro equipo mientras usted agregaba platos. Lo que agregó quedó en ' + m + ' como cuenta nueva.'",
                  "'No salió en la comanda: ' + nombres + '. En otro equipo ya se había quitado o cobrado de ' + m + '.'",
                  "'No salieron en la comanda: ' + nombres + '. En otro equipo ya se habían quitado o cobrado de ' + m + '.'"):
        assert texto in k, texto
    # 4.31 corrección (g): los avisos de la misma mesa ya no dicen «plato(s)» ni pegan la mesa al número
    for viejo in ("' plato(s) que agregó otro equipo.'", "'Se sumaron a la cuenta de ' + ", "' plato(s). Quedaron en la mesa sin cobrar.'", "' plato(s) de ' + "):
        assert viejo not in k, viejo
    # las once actualizaciones de UNA cuenta pasan por actualizarCuenta y las bajas por bajaCuenta (salvo las de las ventas encoladas antes)
    assert k.count("this.actualizarCuenta(") >= 11 and k.count("this.bajaCuenta(") >= 10
    assert k.count("mock.actualizar('pos_espera', l => (l || []).filter(") == 2                      # «todo pasado» sin api nueva y la cola vieja
    assert "for (const k of ['preparando', 'listo', 'entregado', 'impreso'])" in k                     # test_46_revision
    # 4.31 corrección: la última parte se cierra con lo cobrado en ella (si el guardado que quitaba esos platos no llegó, igual se cierra) y como cobro
    assert "await Promise.race([mock.guardarTodo(), new Promise(r => setTimeout(r, 3000))]).catch(() => {}); this.bajaCuenta(cp.cuentaId, lineasCobradas, c.nombre, true);" in k
    # las bajas que vienen de un cobro llevan la marca (la cuenta conservada no se queda con lo ya pagado en línea)
    for x in ("if (idFin) { this.bajaCuenta(idFin, lineasBaja, nombreEspera, true); }", "if (esperaId) this.bajaCuenta(esperaId, lineas, nombreEspera, true);",
              "if (c.esperaId) this.bajaCuenta(c.esperaId, v.espera_quitadas || [], c.nombreEspera, true);", "this.bajaCuenta(v.espera_id, v.espera_quitadas, v.espera, true);"):
        assert x in k, x
    assert "condicionDe(id, lineas, cobro === true)" in k
    # cargar a la habitación: los platos sin lid reciben el suyo antes de armar la condición (como al cobrar)
    hab = _tramo(k, "    cargarAHabitacion() {", "\n    },\n")
    assert hab.index("if (this.esperaId) lidsPantalla(this.lineas, this.cuentaActual);") < hab.index("lineas =this.lineas.map(x => ({ ...x }));"), hab
    # el resto de una línea partida lleva la marca de origen en los tres lugares (cobrar parte, partes iguales, cobrar o pasar solo esos)
    assert "restoDe(l, Math.round(" in _metodo(k, "async cobrarParte(n) {")
    div = _metodo(k, "async confirmarDividir() {")
    assert div.count("lid: 'l' + uuid(), de: l.lid }") == 2 and "mov.map(({ de, ...x }) => ({ ...x, lid: 'l' + uuid() }))" in div
    # api.js: solo con los campos nuevos
    assert "condicionBaja(key, id, cond) {" in a and "if (Object.keys(condiciones).length) cuerpo.condiciones = condiciones;" in a
    assert "Array.isArray(r.conservados) && r.conservados.length) || (Array.isArray(r.fusionados) && r.fusionados.length)) _reg.ver[key] = null;" in a
    assert "_reg.conds = {}" in a and a.count("_reg.conds = {};") == 2
    assert "await mock.refrescar(['pos_espera'], { sinCorte: true }); } catch {}" in c
