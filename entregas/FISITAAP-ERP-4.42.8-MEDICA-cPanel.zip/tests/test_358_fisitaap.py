"""3.58 · núcleo FISITAAP: SINPE Móvil con comprobante (pedido, comprobante del cliente, verificación del negocio y prepago en la caja),
presentación catálogo o menú, Mi página completa (Nosotros, galería, tema, fuente, buscadores, píxeles con su política de seguridad),
dominio propio y subdominio (la raíz del host muestra la página del negocio y la primera visita verifica el dominio)."""
from sqlmodel import Session

from app import modulos, pedidos
from app.db import engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture)
from tests.test_pedidos import _eid, _productos, _publicar

PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 64


def test_pagina_completa_dominio_y_pixeles(api):  # noqa: F811
    c = api; eid = _eid()
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja QA", "modo": "restaurante", "mesas": []}]})
        modulos.reemplazar(s, eid, "categorias", [{"id": 1, "nombre": "Platos"}, {"id": 2, "nombre": "Bebidas"}])
    a, b, oculto, agotado = _productos(c)
    # validaciones de lo nuevo
    assert _publicar(c, slug="pagina-qa", google_id="abc").status_code == 400
    assert _publicar(c, slug="pagina-qa", pago_sinpe=True).status_code == 400                       # SINPE sin número
    assert _publicar(c, slug="pagina-qa", dominio="pruebas.local").status_code == 400               # el dominio del sistema no
    assert _publicar(c, slug="pagina-qa", dominio="otro.pruebas.local").status_code == 400          # el subdominio se da solo
    assert _publicar(c, slug="pagina-qa", presentacion="lista").status_code == 400
    r = _publicar(c, slug="pagina-qa", presentacion="menu", pago_sinpe=True, sinpe_numero="8888-9999", sinpe_nombre="Soda QA S.A.", nosotros="Somos una soda\nfamiliar.", tema="oscuro", fuente="inter",
                  seo_titulo="Soda QA · Comida casera", seo_descripcion="Casados y refrescos", seo_palabras="soda, casados", google_id="g-abc123", pixel_meta="123456789012345", dominio="https://www.sodaqa.cr/")
    assert r.status_code == 200, r.text
    n = r.json()
    assert n["dominio"] == "sodaqa.cr" and n["dominio_verificado"] is None and n["google_id"] == "G-ABC123" and n["sinpe_numero"] == "88889999" and n["presentacion"] == "menu"
    assert n["url"].endswith("/pagina-qa") and n["url_publica"] == n["url"] and n["host_base"] == "pruebas.local" and n["url_subdominio"] == "https://pagina-qa.pruebas.local"
    # datos públicos
    d = c.get("/api/publico/pagina-qa").json()
    assert d["presentacion"] == "menu" and d["sinpe"] == {"numero": "88889999", "nombre": "Soda QA S.A."} and d["nosotros"].startswith("Somos") and d["tema"] == "oscuro" and d["fuente"] == "inter" and d["galeria"] == []
    # página: tema, fuente, buscadores, píxeles y su política de seguridad
    r = c.get("/t/pagina-qa"); h = r.text
    assert r.status_code == 200 and 'data-tema="oscuro"' in h and 'data-fuente="inter"' in h and "<title>Soda QA · Comida casera</title>" in h and 'name="keywords"' in h
    assert 'name="gf:google" content="G-ABC123"' in h and 'name="gf:meta" content="123456789012345"' in h and "/js/pixel.js" in h and "application/ld+json" in h and '"telephone": "+50688887777"' in h
    assert "googletagmanager.com" in r.headers["content-security-policy"] and "X-Pagina-Pixeles" not in r.headers
    assert "googletagmanager.com" not in c.get("/app/").headers.get("content-security-policy", "")
    # sin píxeles: política normal
    assert _publicar(c, slug="pagina-qa", dominio="www.sodaqa.cr").status_code == 200
    r = c.get("/t/pagina-qa"); assert "googletagmanager.com" not in r.headers["content-security-policy"] and "pixel.js" not in r.text
    # dominio propio: la raíz de ese host es la página del negocio y la primera visita lo verifica
    assert pedidos.negocio_de_host("www.sodaqa.cr") == (eid, "pagina-qa") and pedidos.negocio_de_host("pagina-qa.pruebas.local") == (eid, "pagina-qa")
    assert pedidos.negocio_de_host("pruebas.local") is None and pedidos.negocio_de_host("nadie.pruebas.local") is None and pedidos.negocio_de_host("otro.cr") is None
    r = c.get("/", headers={"host": "www.sodaqa.cr"}); assert r.status_code == 200 and "tienda.js" in r.text
    r = c.get("/", headers={"host": "pagina-qa.pruebas.local"}); assert r.status_code == 200 and "tienda.js" in r.text
    assert "tienda.js" not in c.get("/", headers={"host": "pruebas.local"}).text
    n = c.get("/api/pedidos/negocio").json()
    assert n["dominio_verificado"] and n["url_publica"] == "https://sodaqa.cr"
    assert "https://sodaqa.cr/#pedido=" in pedidos._url_seguimiento("pagina-qa", type("P", (), {"token": "tk"})(), type("N", (), {"dominio": "sodaqa.cr", "dominio_verificado": "x"})())
    r = c.post("/api/pedidos/negocio/dominio/verificar", json={}); assert r.status_code == 200 and r.json()["estado"] in ("sin_dns", "apunta", "otro")
    # quitar el dominio
    assert _publicar(c, slug="pagina-qa", dominio="").status_code == 200 and pedidos.negocio_de_host("www.sodaqa.cr") is None
    # galería: subir, ver en público y quitar
    r = c.post("/api/pedidos/negocio/galeria", files={"archivo": ("local.png", PNG, "image/png")}); assert r.status_code == 200, r.text
    g = r.json()["galeria"]; assert len(g) == 1 and g[0]["nombre"].startswith(f"galeria_{eid}_")
    assert c.get(f"/api/pedidos/negocio/galeria/{g[0]['nombre']}").status_code == 200
    pub = c.get("/api/publico/pagina-qa").json()["galeria"]; assert len(pub) == 1 and c.get(pub[0]).status_code == 200
    assert c.post("/api/pedidos/negocio/galeria", files={"archivo": ("x.gif", PNG, "image/gif")}).status_code == 400
    assert c.delete(f"/api/pedidos/negocio/galeria/{g[0]['nombre']}").json()["galeria"] == [] and c.get(pub[0]).status_code == 404


def test_sinpe_con_comprobante(api):  # noqa: F811
    c = api; eid = _eid()
    with Session(engine_empresa(eid)) as s:
        modulos.reemplazar(s, eid, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja QA", "modo": "restaurante", "mesas": []}]})
    a, b, oculto, agotado = _productos(c)
    assert _publicar(c, slug="sinpe-qa").status_code == 200
    lineas = [{"producto_id": a["id"], "cantidad": 1}]
    body = {"nombre": "Luis Mora", "telefono": "87001234", "tipo": "recoger", "lineas": lineas, "pago": "sinpe"}
    assert c.post("/api/publico/sinpe-qa/pedido", json=body).status_code == 400                     # el negocio no ofrece SINPE
    assert c.post("/api/publico/sinpe-qa/pedido", json={**body, "pago": "cheque"}).status_code == 400
    assert _publicar(c, slug="sinpe-qa", pago_sinpe=True, sinpe_numero="88889999", sinpe_nombre="Soda QA").status_code == 200
    r = c.post("/api/publico/sinpe-qa/pedido", json=body); assert r.status_code == 200, r.text
    p = r.json()
    assert p["estado"] == "nuevo" and p["pago_medio"] == "sinpe" and p["pago_estado"] == "sinpe_pendiente" and p["pago_monto"] == 4520.0 and p["sinpe"] == {"comprobante": False, "referencia": "", "verificado": None}
    assert any(x["id"] == p["id"] for x in c.get("/api/pedidos").json())                            # en la bandeja (no espera pago)
    # el cliente sube el comprobante
    assert c.post(f"/api/publico/sinpe-qa/pedido/{p['token']}/sinpe", files={"archivo": ("c.txt", b"hola", "text/plain")}).status_code == 400
    r = c.post(f"/api/publico/sinpe-qa/pedido/{p['token']}/sinpe", files={"archivo": ("comprobante.jpg", PNG, "image/jpeg")}, data={"referencia": " 2024 5566 "})
    assert r.status_code == 200, r.text
    assert r.json()["sinpe"] == {"comprobante": True, "referencia": "2024 5566", "verificado": None}
    assert c.get(f"/api/pedidos/{p['id']}/sinpe/comprobante").status_code == 200
    # el negocio verifica: queda pagado y, al confirmar, la caja lo ve con el prepago
    assert c.put(f"/api/pedidos/{p['id']}/sinpe", json={"verificado": True}).status_code == 200
    v = c.get("/api/pedidos").json(); v = next(x for x in v if x["id"] == p["id"])
    assert v["pago_estado"] == "aprobado" and v["pago_monto"] == 4520.0 and v["a_pagar"] == 0 and v["sinpe"]["verificado"]
    assert c.put(f"/api/pedidos/{p['id']}/sinpe", json={"verificado": True}).status_code == 400     # ya verificado
    assert c.post(f"/api/publico/sinpe-qa/pedido/{p['token']}/sinpe", files={"archivo": ("c.jpg", PNG, "image/jpeg")}).status_code == 400   # ya verificado
    r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "confirmado"}); assert r.status_code == 200, r.text
    with Session(engine_empresa(eid)) as s:
        cuenta = next(x for x in modulos.leer(s, eid, "pos_espera", []) if x.get("pedido_id") == p["id"])
    assert cuenta["prepago"]["online"] == 4520.0 and cuenta["prepago"]["monto"] == 4520.0 and cuenta["prepago"]["referencia"] == "2024 5566"
    # cancelar un pedido pagado por SINPE: el reembolso lo hace el negocio
    r = c.put(f"/api/pedidos/{p['id']}/estado", json={"estado": "cancelado", "motivo": "Prueba"}); assert r.status_code == 200, r.text
    assert r.json()["pago_estado"] == "reembolso_pendiente" and "banco" in r.json()["pago_detalle"]
    # otro pedido: confirmado antes de verificar y luego rechazado el comprobante → la caja cobra todo
    p2 = c.post("/api/publico/sinpe-qa/pedido", json={**body, "telefono": "87005678"}).json()
    assert c.put(f"/api/pedidos/{p2['id']}/estado", json={"estado": "confirmado"}).status_code == 200
    assert c.put(f"/api/pedidos/{p2['id']}/sinpe", json={"verificado": True}).status_code == 200
    with Session(engine_empresa(eid)) as s:
        cuenta = next(x for x in modulos.leer(s, eid, "pos_espera", []) if x.get("pedido_id") == p2["id"])
    assert cuenta["prepago"]["online"] == 4520.0
    p3 = c.post("/api/publico/sinpe-qa/pedido", json={**body, "telefono": "87009999"}).json()
    r = c.put(f"/api/pedidos/{p3['id']}/sinpe", json={"verificado": False, "motivo": "No aparece"}); assert r.status_code == 200
    assert r.json()["pago_estado"] == "rechazado" and r.json()["a_pagar"] == 4520.0
    assert c.post(f"/api/publico/sinpe-qa/pedido/{p3['token']}/sinpe", files={"archivo": ("c.jpg", PNG, "image/jpeg")}).status_code == 200   # puede subir otro
