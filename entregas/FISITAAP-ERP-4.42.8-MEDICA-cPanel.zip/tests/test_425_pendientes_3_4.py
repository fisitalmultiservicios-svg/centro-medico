# -*- coding: utf-8 -*-
"""4.25 (X2, encargo 4b): pendientes de la revisión de las tandas 3 y 4 del programa local.

- D-N (Q1): «la web manda» sobre los dos pasos de una persona solo cuando la web ya habló de ella en esta computadora (nube_validado).
  Mientras tanto sus dos pasos siguen como en la 4.24 (se le exigen y se activan aquí).
- Q2: sin respuesta de la web, en una computadora que valida en línea contra una web 4.25 o posterior, lo guardado solo vale a quien
  ya entró aquí una vez con internet.
- Q3, Q4, Q8: PIN de caja con contraseña temporal en la web, sin ficha fresca de la web y con dos pasos de la web sin exigirlos.
- Q5: la franja de usuarios atrasados se calla cuando la sincronización sale antes de bajarlos por una razón con su propio aviso.
- Q6: «¿Olvidó su contraseña?» lleva a la web solo si alguna empresa vinculada valida en línea.
- Q7: franja de Recursos humanos para quien la web le administra los dos pasos.
- Q9: Host por IP literal, localhost o el nombre de esta computadora.
- Q10: traer_archivos (un comprobante) revisa la clave y los nombres antes de pedir o escribir.

Nube y computadora corren en el mismo proceso (ver tests/test_49_local_sinc.py y tests/test_425_ingreso_programa.py)."""
import base64
import logging
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import httpx
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, sinc
from app.db import Empresa, engine, engine_empresa
from app.main import app
from test_49_local_sinc import NUBE, PW, H, _poner_cfg, _Respuesta, c
from test_425_ingreso_programa import (FICHA, INGRESO, _entrar, _ficha, _hace, _llamadas, _pareja, _persona, _poner, _sesion_de, _sobre,
                                       _solo_estas, _ultima_auditoria, _usuario)

JS = Path(sinc.__file__).parent / "static" / "js"
MENSAJE_ACTIVAR = "Debe activar la verificación en dos pasos antes de continuar (Mi perfil)"


def _con_empresa(token: str, eid: int) -> str:
    r = c.post("/api/auth/empresa", headers=H(token), json={"empresa_id": eid})
    assert r.status_code == 200, r.text
    return r.json()["token"]


def _sin_fallos(correo: str) -> bool:
    with Session(engine) as sc:
        return not sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave == "login_fallo", auth.IntentoIp.ip.endswith("|" + correo))).all()


def _pin(correo: str, pin: str):
    return c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": pin})


# ------------------------------------------------------------------------------------------------------------------------- Q1 (D-N)
def test_q1_la_web_manda_sobre_los_dos_pasos_solo_cuando_ya_hablo_de_la_persona(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-q1", "3101425701", "3101425702")
    uid, correo = _persona(eid_a, "duena.q1", rol="Administrador", local=eid_b)      # viene de la nube, sin dos pasos aquí
    assert _usuario(uid).nube_validado is None
    # (a) la computadora nunca consulta a la web (otra dirección, o FE_NUBE_URL dudosa): como en la 4.24, se le exigen los dos pasos aquí
    for url in ("https://fisitaap.com", ""):
        monkeypatch.setattr(sinc, "URL_NUBE", url)
        r = _entrar(correo)
        assert r.status_code == 200, (url, r.text)
        j = r.json()
        assert j["usuario"]["sin_nube"] is True and j["usuario"]["nube_manda"] is False and j["usuario"]["de_nube"] is True
        assert j["usuario"]["mfa_obligatorio"] is True and j["usuario"]["mfa_exigido_rol"] is True and j["usuario"]["dos_pasos_en_web"] is False
        t = _con_empresa(j["token"], eid_b)
        r = c.get("/api/sinc/local/aviso", headers=H(t))
        assert r.status_code == 403 and r.json()["detail"] == MENSAJE_ACTIVAR, r.text
        r = c.post("/api/auth/mfa/activar", headers=H(t))                  # y los puede activar aquí
        assert r.status_code == 200 and r.json().get("secreto"), r.text
        assert r.json().get("detail") != auth.MENSAJE_SOLO_WEB_MFA
    _poner(uid, mfa_secret=None, mfa_activo=False)
    with Session(engine) as sc:                                             # Recursos humanos con la regla de siempre
        u = sc.get(auth.Usuario, uid)
        assert auth._viene_de_nube(u) and not auth._nube_manda(u)
        assert auth._rrhh_cubierto(u, "Administrador", sc, eid_b) == auth.rrhh_con_mfa(u, "Administrador", sc, eid_b)
    # (b) después de un ingreso aceptado en línea (nube_validado): valen las reglas de la web
    monkeypatch.setattr(sinc, "URL_NUBE", NUBE)
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("ok", usuario=_ficha(uid, rol="Administrador")))
    r = _entrar(correo)
    assert r.status_code == 200, r.text
    j = r.json()
    assert _usuario(uid).nube_validado is not None
    assert j["usuario"]["nube_manda"] is True and j["usuario"]["mfa_obligatorio"] is False and j["usuario"]["mfa_exigido_rol"] is False
    t = _con_empresa(j["token"], eid_b)
    assert c.get("/api/sinc/local/aviso", headers=H(t)).status_code == 200    # la web no se los exige
    r = c.post("/api/auth/mfa/activar", headers=H(t))
    assert r.status_code == 400 and r.json()["detail"] == auth.MENSAJE_SOLO_WEB_MFA
    _poner(uid, mfa_entrar_nube=True)                                       # la web se los exige y no los tiene
    r = c.get("/api/sinc/local/aviso", headers=H(t))
    assert r.status_code == 403 and r.json()["detail"] == auth.MENSAJE_FALTA_MFA_WEB
    _poner(uid, mfa_entrar_nube=False)
    with Session(engine) as sc:                                             # Recursos humanos según la membresía
        m = sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid, auth.UsuarioEmpresa.empresa_id == eid_b)).first()
        m.mfa_rrhh_nube = True; sc.add(m); sc.commit()
        u = sc.get(auth.Usuario, uid)
        assert auth._nube_manda(u) and auth._rrhh_cubierto(u, "Administrador", sc, eid_b) is True
        assert auth._rrhh_cubierto(u, "Administrador", sc, eid_a) is False      # de esa empresa la web no dijo nada
    # (c) en el sitio web (ganchos sin instalar) nada cambia: ni la regla ni la respuesta
    monkeypatch.setattr(auth, "ingreso_nube", None)
    monkeypatch.setattr(auth, "dos_pasos_nube", None)
    with Session(engine) as sc:
        u = sc.get(auth.Usuario, uid)
        assert not auth._viene_de_nube(u) and not auth._nube_manda(u)
    uid2, correo2 = _persona(eid_a, "cajero.q1", local=eid_b, nube_validado=datetime.now(timezone.utc))
    r = _entrar(correo2)
    assert r.status_code == 200 and "nube_manda" not in r.json()["usuario"] and "de_nube" not in r.json()["usuario"], r.text


# ------------------------------------------------------------------------------------------------------------------------- Q2 (D-I)
def test_q2_sin_internet_lo_guardado_solo_vale_a_quien_ya_entro_en_linea_aqui(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-q2", "3101425703", "3101425704")
    uid, correo = _persona(eid_a, "cajero.q2", local=eid_b)                # nunca entró en línea aquí, con su hash real (antes de la 4.25)
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    _poner_cfg(eid_b, version_nube="4.25")                                  # la web ya es 4.25: tuvo que entrar una vez con internet
    r = _entrar(correo)
    assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_VALIDAR_AQUI and "token" not in r.json(), r.text
    assert _sin_fallos(correo)                                              # no cuenta fallo
    assert _entrar(correo, "Clave-Mala-q2-2026").status_code == 401          # la contraseña mala: lo de siempre (antes del 403)
    _poner_cfg(eid_b, version_nube="4.26")
    assert _entrar(correo).status_code == 403
    # una web anterior (o sin versión anotada), otra dirección o sin vinculación: rige lo de siempre
    for v in ("4.24", None):
        _poner_cfg(eid_b, version_nube=v)
        r = _entrar(correo)
        assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is True, (v, r.text)
    _poner_cfg(eid_b, version_nube="4.25")
    with monkeypatch.context() as m:
        m.setattr(sinc, "URL_NUBE", "https://fisitaap.com")
        r = _entrar(correo)
        assert r.status_code == 200 and r.json()["aviso_ingreso"] == sinc.OTRA_DIRECCION
    with monkeypatch.context() as m:
        _solo_estas(m)
        assert _entrar(correo).status_code == 200
    # quien ya entró en línea aquí sí entra sin internet
    _poner(uid, nube_validado=datetime.now(timezone.utc))
    r = _entrar(correo)
    assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is True, r.text
    # la web no atendió (502) cuenta igual que sin internet
    _, correo2 = _persona(eid_a, "mesera.q2", local=eid_b)
    shim.por_ruta[INGRESO] = _Respuesta(502, None, "<html>Bad gateway</html>")
    assert _entrar(correo2).json()["detail"] == sinc.SIN_VALIDAR_AQUI


# ------------------------------------------------------------------------------------------------------------------------- PIN
def test_q3_pin_con_contrasena_temporal_en_la_web_no_entra(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-q3", "3101425705", "3101425706")
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    pin = auth.hash_password("4827")
    uid, correo = _persona(eid_a, "cajera.q3", local=eid_b, pin_hash=pin)
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, pin_hash=pin, temporal=True)))
    assert _pin(correo, "1111").status_code == 401                         # primero se compara el PIN
    r = _pin(correo, "4827")
    assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJES_INGRESO["temporal"] and "token" not in r.json(), r.text
    assert _usuario(uid).temporal_nube
    shim.por_ruta[FICHA] = httpx.ConnectError("sin red")                    # sin internet vale lo guardado: tampoco
    assert _pin(correo, "4827").json()["detail"] == sinc.MENSAJES_INGRESO["temporal"]
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, pin_hash=pin, temporal=False)))
    assert _pin(correo, "4827").status_code == 200                         # ya la cambió en la web


def test_q4_pin_sin_ficha_fresca_abre_sesion_marcada_sin_nube(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-q4", "3101425707", "3101425708")
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    pin = auth.hash_password("4827")
    uid, correo = _persona(eid_a, "cajero.q4", local=eid_b, pin_hash=pin)
    detalle = "PIN de caja: sin confirmar con la web, validado con lo guardado en esta computadora"
    # con ficha fresca: como hoy
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, pin_hash=pin)))
    r = _pin(correo, "4827")
    assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is False and _sesion_de(r.json()["token"]).sin_nube is False, r.text
    assert _ultima_auditoria(uid, "login").detalle != detalle
    # sin internet, la web que no atiende, o una computadora que no valida en línea
    casos = (("sin internet", httpx.ConnectError("sin red"), NUBE), ("no atiende", _Respuesta(502, None, "x"), NUBE),
             ("otra dirección", None, "https://fisitaap.com"))
    for caso, resp, url in casos:
        with monkeypatch.context() as m:
            m.setattr(sinc, "URL_NUBE", url)
            if resp is not None:
                shim.por_ruta[FICHA] = resp
            antes = _llamadas(shim, FICHA)
            r = _pin(correo, "4827")
            assert r.status_code == 200, (caso, r.text)
            assert r.json()["usuario"]["sin_nube"] is True and _sesion_de(r.json()["token"]).sin_nube is True, caso
            assert _ultima_auditoria(uid, "login").detalle == detalle, caso
            if caso == "otra dirección":
                assert _llamadas(shim, FICHA) == antes
    # una cuenta creada en esta computadora no pide ficha y no se marca
    _, correo2 = _persona(0, "cajero-local.q4", local=eid_b, de_nube=False, pin_hash=pin)
    r = _pin(correo2, "4827")                                              # 4.25 (tanda 6, E-13): su empresa está vinculada: ya no entra
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "cuenta_local", r.text
    monkeypatch.setenv("FE_LOCAL_ADMIN", "1")                               # modo soporte: como antes
    r = _pin(correo2, "4827")
    monkeypatch.delenv("FE_LOCAL_ADMIN")
    assert r.status_code == 200 and r.json()["usuario"]["sin_nube"] is False, r.text


def test_q8_pin_con_dos_pasos_de_la_web_aunque_la_web_no_los_exija(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-q8", "3101425709", "3101425710")
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    pin = auth.hash_password("4827")
    uid, correo = _persona(eid_a, "cajera.q8", local=eid_b, pin_hash=pin)
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, pin_hash=pin, mfa="huella-q8", mfa_entrar=False)))
    r = _pin(correo, "4827")
    assert r.status_code == 403 and "solo para usuarios de caja" in r.json()["detail"] and "token" not in r.json(), r.text
    u = _usuario(uid)
    assert u.mfa_nube == "huella-q8" and not u.mfa_entrar_nube and not u.mfa_activo


# ------------------------------------------------------------------------------------------------------------------------- Q5
def test_q5_usuarios_atrasados_callado_con_la_instalacion_revocada_o_la_empresa_bloqueada(monkeypatch):
    monkeypatch.setattr(sinc, "URL_NUBE", NUBE)
    monkeypatch.setattr(sinc, "INGRESO_EN_LINEA", True)
    cfg = {"vinculado": True, "url": NUBE, "usuarios_bajada": _hace(30)}
    assert sinc.usuarios_atrasados(cfg) is True
    assert sinc.usuarios_atrasados({**cfg, "revocada_en": _hace(5)}) is False
    assert sinc.usuarios_atrasados(cfg, bloqueada=True) is False
    assert sinc.usuarios_atrasados({**cfg, "sin_conexion_desde": _hace(5)}) is False
    # en la franja de la pantalla
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-q5", "3101425711", "3101425712")
    _poner_cfg(eid_b, usuarios_bajada=_hace(30))
    with Session(engine_empresa(eid_b)) as s, Session(engine) as sc:
        e = sc.get(Empresa, eid_b)
        assert sinc.franja_local(s, e)["usuarios_atrasados"] is True
        e.bloqueada = True                                                  # solo en memoria: no se guarda
        assert sinc.franja_local(s, e)["usuarios_atrasados"] is False
        sc.rollback()
    _poner_cfg(eid_b, revocada_en=_hace(5))
    try:
        with Session(engine_empresa(eid_b)) as s, Session(engine) as sc:
            assert sinc.franja_local(s, sc.get(Empresa, eid_b))["usuarios_atrasados"] is False
            assert sinc._estado_local(s, eid_b)["usuarios_atrasados"] is False
    finally:
        _poner_cfg(eid_b, revocada_en=None)


# ------------------------------------------------------------------------------------------------------------------------- Q6
def test_q6_olvido_su_contrasena_local_si_ninguna_empresa_valida_en_linea(monkeypatch):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-q6", "3101425713", "3101425714")
    assert c.get("/api/auth/estado").json()["pagina_web"] == NUBE
    monkeypatch.setattr(sinc, "URL_NUBE", "https://fisitaap.com")          # ninguna empresa vinculada a esa dirección
    assert c.get("/api/auth/estado").json()["pagina_web"] is None
    monkeypatch.setattr(sinc, "URL_NUBE", NUBE)
    real = sinc._cfg_local
    monkeypatch.setattr(sinc, "_cfg_local", lambda s, eid: {**real(s, eid), "revocada_en": "2026-01-01T00:00:00+00:00"})   # todas revocadas
    assert sinc.estado_ingreso()["pagina_web"] is None
    monkeypatch.setattr(sinc, "_cfg_local", lambda s, eid: {**real(s, eid), "vinculado": False})                          # sin vincular
    assert sinc.estado_ingreso()["pagina_web"] is None
    # la pantalla de ingreso tiene las dos ramas; ActivarMfaWeb aguanta un None
    lg = (JS / "pages" / "login.js").read_text(encoding="utf-8")
    assert 'v-if="!setup && paginaWeb"' in lg and "v-else-if=\"!setup\"" in lg and "@click=\"modo='recuperar'\">¿Olvidó su contraseña?" in lg
    assert "paginaWeb() { return (this.estado && this.estado.pagina_web) || ''; }" in lg
    a = (JS / "app.js").read_text(encoding="utf-8")
    assert "this.paginaWeb = (j && j.pagina_web) || '';" in a and '<a v-if="paginaWeb" class="btn"' in a


# ------------------------------------------------------------------------------------------------------------------------- Q7
def test_q7_franja_de_recursos_humanos_manda_a_la_pagina_web():
    a = (JS / "app.js").read_text(encoding="utf-8")
    enlace = '''<a v-if="!sesion.usuario?.nube_manda" :href="'#' + RUTA_RRHH_MFA">Activarla en Mi perfil</a>'''
    assert a.count(enlace) == 2                                             # en Inicio y en la tarjeta «Sin acceso»
    web = "<span v-else>Se activa en la página web, en Mi perfil<template v-if=\"paginaWebRrhh\">: <a :href=\"paginaWebRrhh + '/app/#/configuracion/perfil'\" target=\"_blank\" rel=\"noopener\">abrir la página web</a></template>.</span>"
    assert a.count(enlace + web) == 2
    assert "paginaWebRrhh: '' }; }," in a
    assert "'sesion.usuario.nube_manda': { immediate: true, async handler(v) { if (!v || this.paginaWebRrhh) return; try { const j = await api('/api/auth/estado');" in a
    assert "this.paginaWebRrhh = (j && j.pagina_web) || '';" in a


# ------------------------------------------------------------------------------------------------------------------------- Q9
def test_q9_host_por_ip_literal_localhost_o_el_nombre_del_equipo(monkeypatch):
    llamadas = []

    def nombre():
        llamadas.append(1)
        return "CAJA1.oficina.example"

    monkeypatch.setattr(sinc.socket, "gethostname", nombre)
    monkeypatch.setitem(sinc._EQUIPO, "v", None)
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    lan = TestClient(app, client=("192.168.1.50", 50000))
    for host in ("10.8.0.5:8020", "192.168.77.3", "[::1]:8020", "[fe80::1]:8020", "127.0.0.1", "localhost:8020", "caja1:8020", "CAJA1",
                 "caja1.local:8020", "Caja1.Local"):
        r = lan.get("/api/auth/estado", headers={"Host": host})
        assert r.status_code == 200, (host, r.text)
    for host in ("evil.example", "evil.example:8020", "nombre.evil.example", "caja1.evil.example", "caja1.local.evil.example", "caja10:8020",
                 "caja1.oficina.example", "10.8.0.5.evil.example", "999.1.1.1", ""):
        r = lan.get("/api/auth/estado", headers={"Host": host})
        assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_HOST, (host, r.text)
    assert len(llamadas) == 1                                               # el nombre se calcula una vez, no en cada petición
    # Origin distinto sigue rechazado; el mismo pasa
    r = lan.post("/api/auth/login", headers={"Host": "caja1:8020", "Origin": "http://evil.example:8020"}, json={"correo": "x@example.test", "password": "y"})
    assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_ORIGEN
    r = lan.post("/api/auth/login", headers={"Host": "10.8.0.5:8020", "Origin": "http://10.8.0.6:8020"}, json={"correo": "x@example.test", "password": "y"})
    assert r.status_code == 403 and r.json()["detail"] == sinc.MENSAJE_ORIGEN
    assert lan.get("/api/auth/estado", headers={"Host": "caja1:8020", "Origin": "http://caja1:8020"}).status_code == 200
    # un equipo cuyo nombre no se puede saber: solo IP y localhost
    monkeypatch.setattr(sinc.socket, "gethostname", lambda: "")
    monkeypatch.setitem(sinc._EQUIPO, "v", None)
    assert lan.get("/api/auth/estado", headers={"Host": "caja1:8020"}).status_code == 403
    assert lan.get("/api/auth/estado", headers={"Host": ".local"}).status_code == 403
    assert lan.get("/api/auth/estado", headers={"Host": "10.8.0.5:8020"}).status_code == 200
    assert not hasattr(sinc, "_ips_propias") and not hasattr(sinc, "_DIR_CACHE")


# ------------------------------------------------------------------------------------------------------------------------- Q10
def test_q10_traer_archivos_revisa_la_clave_y_los_nombres(monkeypatch, tmp_path, caplog):
    eid_a, ta, eid_b, tb, shim = _pareja(monkeypatch, "-q10", "3101425715", "3101425716")
    carpeta = tmp_path / "xml"
    carpeta.mkdir()
    monkeypatch.setattr(sinc, "XML_DIR", carpeta)
    clave = "5" * 50
    ruta = f"/api/sinc/xml/{clave}"
    xml, resp = b"<FacturaElectronica>" + clave.encode() + b"</FacturaElectronica>", b"<MensajeHacienda>" + clave.encode() + b"</MensajeHacienda>"
    shim.por_ruta[ruta] = _Respuesta(200, {"xml_b64": base64.b64encode(xml).decode(), "respuesta_b64": base64.b64encode(resp).decode()})

    def doc(k=clave, x=None, r=None):
        return SimpleNamespace(clave=k, xml_nombre=x if x is not None else f"{k}.xml", respuesta_nombre=r if r is not None else f"{k}_respuesta.xml")

    # nombres que salen de la carpeta, con separadores, unidad o ruta absoluta: no se pide ni se escribe nada
    for x, r in (("../fuera.xml", None), ("sub/x.xml", None), ("..\\fuera.xml", None), ("C:\\x.xml", None), ("C:x.xml", None), ("/abs.xml", None),
                 ("..", None), (f"{clave}.xml", "../fuera_respuesta.xml"), (f"{clave}.xml", "a\\b.xml"), (".oculto.xml", None)):
        antes = len(shim.llamadas)
        sinc.traer_archivos(eid_b, doc(x=x, r=r))
        assert len(shim.llamadas) == antes, (x, r)
    # claves que no son de 50 dígitos
    for k in ("123", "../" + "1" * 47, "5" * 49 + "a", "5" * 51):
        antes = len(shim.llamadas)
        sinc.traer_archivos(eid_b, doc(k=k, x=f"{clave}.xml", r=f"{clave}_respuesta.xml"))
        assert len(shim.llamadas) == antes, k
    assert list(carpeta.iterdir()) == [] and not (tmp_path / "fuera.xml").exists() and not (tmp_path / "fuera_respuesta.xml").exists()
    # la clave y los nombres buenos: se pide una vez y se escribe dentro de la carpeta, por temporal y renombrado (sin .tmp que quede)
    sinc.traer_archivos(eid_b, doc())
    assert _llamadas(shim, ruta) == 1
    assert (carpeta / f"{clave}.xml").read_bytes() == xml and (carpeta / f"{clave}_respuesta.xml").read_bytes() == resp
    assert not list(carpeta.glob(".*.tmp"))
    # el registro no copia el contenido ni el texto de la respuesta
    (carpeta / f"{clave}.xml").unlink()
    shim.por_ruta[ruta] = httpx.ConnectError("MARCA-Q10-respuesta")
    with caplog.at_level(logging.DEBUG):
        sinc.traer_archivos(eid_b, doc())
    assert "MARCA-Q10" not in caplog.text and not (carpeta / f"{clave}.xml").exists()
    # la ayuda del lote sigue con los nombres de siempre
    assert sinc._guardar_xml(clave, xml) == f"{clave}.xml" and sinc._guardar_xml(clave, resp, respuesta=True) == f"{clave}_respuesta.xml"
