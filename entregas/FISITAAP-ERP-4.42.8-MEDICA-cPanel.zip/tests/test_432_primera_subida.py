"""4.32 (bloque B6, parte web): la primera subida del cliente real (plan §5.3, contrato §2.6 y §3.6), app/sinc_completar.py.

Reserva con max_dado (solo ítems y clientes), altas del rango 0 solo con prueba de ser de la computadora, existencia inicial con lo pendiente
sumado (y que la venta retenida, al subir, deja las dos existencias iguales), reenlace de líneas, comprobantes y cobros sin mover inventario,
elementos de registro con id nuevo y las dos heurísticas de la lista de choques. Funciones puras sobre bases de empresa de prueba: sin red."""
import random
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from sqlalchemy import text
from sqlmodel import Session, select

from app import auth, inventario, modulos, sinc, sinc_completar as sc
from app.db import Cliente, Documento, DocumentoLinea, Producto, engine, engine_empresa, init_db

init_db()

PREFIJO = "fcr_b6pruebaA"
OTRO = "fcr_b6pruebaB"


def _empresa() -> int:
    with Session(engine) as s0:
        e = auth.crear_empresa(s0, "Primera subida 432 QA", f"b6-{random.randint(1, 10**9)}@example.test", "31010" + str(random.randint(10**4, 10**5 - 1)))
        return e.id


def _vinc(s, eid: int, *otras: str) -> dict:
    """Ficha sinc_vinculacion con la instalación de PREFIJO (terminal 3) y, si se piden, otras vigentes."""
    v = {"instalaciones": [{"terminal": 3, "nombre": "Caja 1", "prefijo": PREFIJO}]
         + [{"terminal": 4 + i, "nombre": f"Caja {i + 2}", "prefijo": p} for i, p in enumerate(otras)], "retiradas": []}
    modulos.reemplazar(s, eid, sinc.CLAVE_VINC, v, version=(modulos._registro(s, eid, sinc.CLAVE_VINC) or SimpleNamespace(version=0)).version)
    s.commit()
    return v


def _inst(v: dict) -> dict:
    return v["instalaciones"][0]


def _ctx(eid: int, prefijo: str = PREFIJO):
    return SimpleNamespace(empresa=SimpleNamespace(id=eid), token_api=SimpleNamespace(prefijo=prefijo, id=1), por_programa=None)


def _producto(s, eid: int, nombre: str, **k) -> int:
    p = Producto(empresa_id=eid, nombre=nombre, cabys="1234567890123", precio=1000, **k)
    s.add(p); s.commit(); s.refresh(p)
    return p.id


def _cliente(s, eid: int, nombre: str, **k) -> int:
    c = Cliente(empresa_id=eid, nombre=nombre, tipo_id="", numero_id="", **k)
    s.add(c); s.commit(); s.refresh(c)
    return c.id


def _clave() -> str:
    return "506" + "".join(random.choice("0123456789") for _ in range(47))


def _doc(s, eid: int, lineas: list, *, origen=None, fecha="2026-11-01T10:00:00-06:00", cliente_id=None, estado="interno", sinc_en=None, tipo="04") -> Documento:
    d = Documento(empresa_id=eid, tipo_documento=tipo, clave=_clave(), consecutivo="0010000104" + str(random.randint(10**9, 10**10 - 1)), fecha_emision=fecha, estado=estado,
                  origen_sinc=origen, cliente_id=cliente_id, sinc_en=sinc_en)
    s.add(d); s.flush()
    for i, (pid, det, cant) in enumerate(lineas, 1):
        s.add(DocumentoLinea(documento_id=d.id, numero=i, producto_id=pid, cabys="1234567890123", detalle=det, cantidad=cant, unidad_medida="Unid",
                             precio_unitario=1000))
    s.commit(); s.refresh(d)
    return d


def _ultimo(s, tabla: str) -> int:
    return int(s.execute(text("SELECT ultimo FROM sinc_id_propio WHERE tabla = :t AND rango = 0"), {"t": tabla}).scalar_one())


# ----------------------------------------------------------------------------------------------------------------- reservar / max_dado
def test_reservar_devuelve_max_dado_y_la_web_ya_no_usa_esos_ids():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        v = _vinc(s, eid)
        a = _producto(s, eid, "Café")
        _producto(s, eid, "Té")
        c = _cliente(s, eid, "Ana")
        alto_p = a + 1
        r = sc.reservar(s, eid, _inst(v), v, {"producto": 812, "cliente": 140, "categoria": 9})
        assert r == {"producto": {"max_dado": alto_p}, "cliente": {"max_dado": c}}   # leído ANTES de reservar; «categoria» no se reserva
        assert _ultimo(s, "producto") == 812 and _ultimo(s, "cliente") == 140
        nuevo = _producto(s, eid, "Hecho en la web después de reservar")
        assert nuevo == 813                                                        # nunca un id que el programa tiene
        assert _cliente(s, eid, "Beto") == 141
        # un reintento (respuesta perdida) devuelve el mismo max_dado de la primera vez
        assert sc.reservar(s, eid, _inst(v), v, {"producto": 812, "cliente": 140}) == r
        # max_dado de solo lectura (para /datos/filas): el de la reserva, y no cambia el contador
        assert sc.max_dado(s, eid, _inst(v)) == {"producto": alto_p, "cliente": c}
        assert _ultimo(s, "producto") == 813


def test_reservar_solo_con_la_unica_instalacion_vigente():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        v = _vinc(s, eid, OTRO)
        _producto(s, eid, "Café")
        antes = _ultimo(s, "producto")
        assert sc.reservar(s, eid, _inst(v), v, {"producto": 900}) == {}
        assert _ultimo(s, "producto") == antes
        assert sc.unica_vigente(v, _inst(v)) is False
        v1 = _vinc(s, eid)
        assert sc.unica_vigente(v1, _inst(v1)) is True
        assert sc.unica_vigente(v1, {"terminal": 9, "prefijo": OTRO}) is False


def test_reservar_crea_la_tabla_y_la_fila_si_faltan_y_rechaza_valores_raros():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        v = _vinc(s, eid)
        s.execute(text("CREATE TABLE IF NOT EXISTS sinc_id_propio (tabla TEXT NOT NULL, rango INTEGER NOT NULL, ultimo INTEGER NOT NULL, PRIMARY KEY (tabla, rango))"))
        s.execute(text("DELETE FROM sinc_id_propio")); s.commit()
        r = sc.reservar(s, eid, _inst(v), v, {"producto": 50, "cliente": modulos.RANGO, "x": 3})
        assert r == {"producto": {"max_dado": 0}}                                  # cliente fuera del rango 0: no se toca
        assert _ultimo(s, "producto") == 50
        assert s.execute(text("SELECT COUNT(*) FROM sinc_id_propio WHERE tabla = 'cliente'")).scalar_one() == 0


def test_max_dado_sin_reserva_es_el_vivo():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        v = _vinc(s, eid)
        a = _producto(s, eid, "Café")
        assert sc.max_dado(s, eid, _inst(v))["producto"] == a
        assert sc.max_dado(s, eid)["cliente"] >= 0


# ----------------------------------------------------------------------------------------------------------------- altas del rango 0
def test_alta_rango0_solo_en_la_carga_inicial_de_la_unica_instalacion():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        v = _vinc(s, eid)
        ya = _producto(s, eid, "Ya en la web")
        inst = _inst(v)
        assert sc.revisar_alta_rango0(s, eid, inst, v, "producto", 300) == "no_valido"     # sin reserva: no es su carga inicial
        sc.reservar(s, eid, inst, v, {"producto": 500, "cliente": 50})
        assert sc.revisar_alta_rango0(s, eid, inst, v, "producto", 300) is None
        assert sc.revisar_alta_rango0(s, eid, inst, v, "cliente", "40") is None
        assert sc.revisar_alta_rango0(s, eid, inst, v, "producto", 501) == "no_valido"     # más de lo reservado: la web podría darlo
        assert sc.revisar_alta_rango0(s, eid, inst, v, "producto", ya) == "no_valido"      # la web ya lo tiene: es un choque
        assert sc.revisar_alta_rango0(s, eid, inst, v, "producto", 3 * modulos.RANGO + 1) == "no_valido"
        assert sc.revisar_alta_rango0(s, eid, inst, v, "categoria", 7) == "no_valido"
        v2 = _vinc(s, eid, OTRO)
        assert sc.revisar_alta_rango0(s, eid, _inst(v2), v2, "producto", 300) == "no_valido"   # ya no es la única
        # con lápida en sinc_dato: nada con lápida revive
        s.execute(text("CREATE TABLE IF NOT EXISTS sinc_dato (id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT, ref TEXT, borrado BOOLEAN)"))
        s.execute(text("INSERT INTO sinc_dato (tipo, ref, borrado) VALUES ('producto', '300', 1)")); s.commit()
        assert sc.revisar_alta_rango0(s, eid, inst, v, "producto", 300) == "eliminado"


def test_prueba_de_es_local_y_veredicto_de_filas():
    usados = {12}
    assert sc.es_de_esta_computadora(12, usados, 500) is True          # (1) vendido aquí antes de conectar
    assert sc.es_de_esta_computadora(501, set(), 500) is True          # (2) id mayor que max_dado
    assert sc.es_de_esta_computadora(40, set(), 500) is False          # la web repartió ese número: ¿eliminado allá?
    assert sc.es_de_esta_computadora(0, usados, 0) is False
    assert sc.es_de_esta_computadora(modulos.RANGO + 2, set(), 0) is False
    assert sc.clasificar("nunca", 12, usados, 500) == "subir"
    assert sc.clasificar("nunca", 40, usados, 500) == "eliminado_web"
    assert sc.clasificar("existe", 40, usados, 500, igual=True) == "igual"
    assert sc.clasificar("existe", 40, usados, 500) == "choque"
    assert sc.clasificar("borrado", 12, usados, 500) == "borrado"
    assert sc.clasificar("raro", 12, usados, 500) == "esperar"


def test_usados_antes_de_vincular_solo_comprobantes_de_esta_computadora():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        a, b, c = _producto(s, eid, "A"), _producto(s, eid, "B"), _producto(s, eid, "C")
        ana, beto = _cliente(s, eid, "Ana"), _cliente(s, eid, "Beto")
        _doc(s, eid, [(a, "A", 1)], fecha="2026-10-01T10:00:00-06:00", cliente_id=ana)
        _doc(s, eid, [(b, "B", 1)], fecha="2026-11-10T10:00:00-06:00", cliente_id=beto)          # después de conectar
        _doc(s, eid, [(c, "C", 1)], fecha="2026-10-01T10:00:00-06:00", origen="nube")           # bajó de la web
        u = sc.usados_antes_de_vincular(s, eid, "2026-11-05T16:00:00+00:00")
        assert u == {"producto": {a}, "cliente": {ana}}
        assert sc.usados_antes_de_vincular(s, eid, None) == {"producto": set(), "cliente": set()}


# ----------------------------------------------------------------------------------------------------------------- existencias
def test_existencia_inicial_usa_registrar_movimiento_tipo_inicial():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        pid = _producto(s, eid, "Harina", costo=500)
        bod = inventario.bodega_principal(s, eid).id
        p = s.get(Producto, pid)
        n = sc.existencia_inicial(s, eid, p, [{"bodega_id": bod, "cantidad": 10, "costo_promedio": 450.0}, {"bodega_id": 99999, "cantidad": 2, "costo_promedio": 450.0},
                                              {"bodega_id": bod, "cantidad": "x"}, "basura"])
        s.commit()
        assert n == 1                                                   # n.º 26: la bodega que la web no tiene NO se suma a la principal
        ex = inventario.existencia(s, pid, bod)
        assert ex.cantidad == pytest.approx(10) and ex.costo_promedio == pytest.approx(450)
        movs = s.exec(select(inventario.MovimientoInventario).where(inventario.MovimientoInventario.producto_id == pid)).all()
        assert [(m.tipo, m.cantidad, m.referencia) for m in movs] == [("inicial", 10, sc.REFERENCIA_INICIAL)]
        assert s.exec(select(inventario.CapaCosto).where(inventario.CapaCosto.producto_id == pid)).first().cantidad == pytest.approx(10)
        # repetida (reintento): no suma otra vez
        assert sc.existencia_inicial(s, eid, s.get(Producto, pid), [{"bodega_id": bod, "cantidad": 10, "costo_promedio": 450}]) == 0
        # negativa (vendido sin existencia) y servicio
        neg = _producto(s, eid, "Queso")
        assert sc.existencia_inicial(s, eid, s.get(Producto, neg), [{"bodega_id": bod, "cantidad": -3, "costo_promedio": 0}]) == 1
        s.commit()
        assert inventario.existencia(s, neg, bod).cantidad == pytest.approx(-3)
        serv = _producto(s, eid, "Envío", es_servicio=True, inventariable=False)
        assert sc.existencia_inicial(s, eid, s.get(Producto, serv), [{"bodega_id": bod, "cantidad": 5}]) == 0


def test_existencia_del_alta_con_lo_pendiente_sumado_deja_iguales_los_dos_lados():
    """Programa: existencia 10, vende 3 (comprobante interno sin subir) → 7. El alta lleva 10 (7 + 3 pendientes). La web registra 10; al
    subir el comprobante retenido, la web descuenta 3 (sinc._guardar_documentos) → 7 en los dos lados. Sin sumar lo pendiente quedaría 4."""
    prog, web = _empresa(), _empresa()
    with Session(engine_empresa(prog)) as sp, Session(engine_empresa(web)) as sw:
        pid = _producto(sp, prog, "Pan")
        bp = inventario.bodega_principal(sp, prog).id
        inventario.registrar_movimiento(sp, producto=sp.get(Producto, pid), bodega_id=bp, tipo="ajuste", cantidad=10, fecha="2026-11-01", costo_unitario=200)
        sp.commit()
        d = _doc(sp, prog, [(pid, "Pan", 3)])
        inventario.descontar_por_venta(sp, prog, d.id, d.consecutivo, bp, [{"producto_id": pid, "cantidad": 3}], "2026-11-01", permitir_negativo=True)
        sp.commit()
        # un comprobante que ya subió (sinc_en) no cuenta como pendiente
        d2 = _doc(sp, prog, [(pid, "Pan", 1)], sinc_en="2026-11-01T00:00:00+00:00")
        inventario.descontar_por_venta(sp, prog, d2.id, d2.consecutivo, bp, [{"producto_id": pid, "cantidad": 1}], "2026-11-01", permitir_negativo=True)
        sp.commit()
        assert inventario.existencia(sp, pid, bp).cantidad == pytest.approx(6)
        pend = sc.pendiente_por_producto(sp, prog)
        assert pend == {(pid, bp): 3}
        alta = sc.existencias_para_alta(sp, prog, pid, pend)
        assert alta == [{"bodega_id": bp, "cantidad": 9, "costo_promedio": 200, "pendiente": 3}]
        # la web: alta con el mismo id y su existencia
        bw = inventario.bodega_principal(sw, web).id
        sw.add(Producto(id=pid, empresa_id=web, nombre="Pan", cabys="1234567890123", precio=1000)); sw.flush()
        sc.existencia_inicial(sw, web, sw.get(Producto, pid), [{**x, "bodega_id": bw} for x in alta])
        sw.commit()
        # sube el comprobante retenido
        dd = sinc._doc_a_dict(sp, d, con_xml=False)
        dd["bodega_id"] = bw
        recibidos, errores = sinc._guardar_documentos(sw, web, [dd], "Caja 1")
        assert recibidos == [d.clave] and not errores
        sw.expire_all(); sp.expire_all()
        assert inventario.existencia(sw, pid, bw).cantidad == pytest.approx(inventario.existencia(sp, pid, bp).cantidad) == pytest.approx(6)


def test_pendiente_cuenta_ingredientes_de_receta_y_no_rechazados():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        plato, carne = _producto(s, eid, "Hamburguesa", inventariable=False), _producto(s, eid, "Carne")
        modulos.reemplazar(s, eid, "recetas", [{"id": plato, "producto_id": plato, "ingredientes": [{"producto_id": carne, "cantidad": 2}], "rendimiento": 1}], version=0)
        b = inventario.bodega_principal(s, eid).id
        d = _doc(s, eid, [(plato, "Hamburguesa", 2)])
        inventario.descontar_por_venta(s, eid, d.id, d.consecutivo, b, [{"producto_id": plato, "cantidad": 2}], "2026-11-01", permitir_negativo=True)
        r = _doc(s, eid, [(carne, "Carne", 5)], estado="rechazado")
        s.add(inventario.MovimientoInventario(empresa_id=eid, fecha="2026-11-01", producto_id=carne, bodega_id=b, tipo="venta", cantidad=-5, documento_id=r.id))
        s.commit()
        assert sc.pendiente_por_producto(s, eid) == {(carne, b): 4}


# ----------------------------------------------------------------------------------------------------------------- reenlazar
def _web_con_ventas_viejas():
    eid = _empresa()
    s = Session(engine_empresa(eid))
    v = _vinc(s, eid)
    item, otro = _producto(s, eid, "Item local que subió"), _producto(s, eid, "Otro item de la web")
    cli = _cliente(s, eid, "Cliente local")
    vacia = _doc(s, eid, [(None, "Item local que subió", 1), (otro, "Item local pisado", 1), (None, "Sin item", 1)], origen="Caja 1")
    vacia.receptor_nombre = "Cliente local"; s.add(vacia); s.commit(); s.refresh(vacia)
    de_web = _doc(s, eid, [(None, "Hecho en la web", 1)], origen=None)
    pago = modulos.Pago(empresa_id=eid, numero=1, cliente_id=None, cliente_nombre="Cliente local", origen_sinc="3:5:1730000000", monto=1000)
    pago_otro = modulos.Pago(empresa_id=eid, numero=2, cliente_id=None, cliente_nombre="Cliente local", origen_sinc="7:5:1730000000", monto=1000)
    s.add(pago); s.add(pago_otro); s.commit()
    return eid, s, v, item, otro, cli, vacia, de_web


def test_reenlazar_llena_solo_lo_vacio_y_no_mueve_inventario():
    eid, s, v, item, otro, cli, vacia, de_web = _web_con_ventas_viejas()
    try:
        movs_antes = s.exec(select(inventario.MovimientoInventario)).all()
        datos = {"comprobantes": [{"clave": vacia.clave, "lineas": [{"numero": 1, "producto_id": item}, {"numero": 2, "producto_id": item},
                                                                     {"numero": 3, "producto_id": 9999999}], "cliente_id": cli},
                                  {"clave": de_web.clave, "lineas": [{"numero": 1, "producto_id": item}], "cliente_id": cli},
                                  {"clave": _clave(), "lineas": [], "cliente_id": None}],
                 "cobros": [{"referencia": "3:5:1730000000", "cliente_id": cli}, {"referencia": "7:5:1730000000", "cliente_id": cli}]}
        r = sc.accion_reenlazar(s, eid, _ctx(eid), "_", datos, "Caja 1 · Ana")
        assert (r["lineas"], r["comprobantes"], r["cobros"]) == (1, 1, 1)
        assert r["choques"] == [{"tipo": "linea", "clave": vacia.clave, "numero": 2, "web": otro, "programa": item}]
        assert len(r["faltan"]) == 1
        s.expire_all()
        lineas = {ln.numero: ln.producto_id for ln in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == vacia.id)).all()}
        assert lineas == {1: item, 2: otro, 3: None}                     # la 2 apunta a otro ítem: no se toca; la 3: el ítem no existe
        assert s.get(Documento, vacia.id).cliente_id == cli
        assert s.get(Documento, de_web.id).cliente_id is None            # emitido en la web: no es de ningún programa
        assert s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == de_web.id)).first().producto_id is None
        pagos = {p.origen_sinc: p.cliente_id for p in s.exec(select(modulos.Pago)).all()}
        assert pagos == {"3:5:1730000000": cli, "7:5:1730000000": None}  # el de otra terminal no se toca
        assert s.exec(select(inventario.MovimientoInventario)).all() == movs_antes   # sin inventario
        # idempotente
        r2 = sc.accion_reenlazar(s, eid, _ctx(eid), "_", datos, None)
        assert (r2["lineas"], r2["comprobantes"], r2["cobros"]) == (0, 0, 0)
    finally:
        s.close()


def test_reenlazar_choque_de_cliente_y_validaciones():
    eid, s, v, item, otro, cli, vacia, de_web = _web_con_ventas_viejas()
    try:
        otro_cli = _cliente(s, eid, "Otro")
        vacia.cliente_id = otro_cli; s.add(vacia); s.commit()
        r = sc.accion_reenlazar(s, eid, _ctx(eid), "_", {"comprobantes": [{"clave": vacia.clave, "lineas": [], "cliente_id": cli}]}, None)
        assert r["comprobantes"] == 0 and r["choques"] == [{"tipo": "comprobante", "clave": vacia.clave, "web": otro_cli, "programa": cli}]
        with pytest.raises(HTTPException) as e:
            sc.accion_reenlazar(s, eid, _ctx(eid), "_", {"comprobantes": "x"}, None)
        assert e.value.status_code == 400
        with pytest.raises(HTTPException) as e:
            sc.accion_reenlazar(s, eid, _ctx(eid, "fcr_desconocid"), "_", {"comprobantes": []}, None)
        assert e.value.status_code == 403
    finally:
        s.close()


def test_reenlazar_queda_registrada_como_accion_de_carga():
    assert sc.ACCIONES_CARGA["reenlazar"] is sc.accion_reenlazar


# ----------------------------------------------------------------------------------------------------------------- elementos de registro
def test_id_nuevo_elemento_del_rango_de_la_terminal_sin_repetir():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        t = 3
        assert sc.id_nuevo_elemento(s, eid, "fis_promociones", t) == t * modulos.RANGO + 1
        modulos.aplicar_cambios(s, eid, "fis_promociones", [{"id": 4, "nombre": "2x1 web"}], [], [4])
        modulos.aplicar_sinc(s, eid, "fis_promociones", [{"id": t * modulos.RANGO + 7, "nombre": "de la caja"}], None, t)
        s.commit()
        assert sc.id_nuevo_elemento(s, eid, "fis_promociones", t) == t * modulos.RANGO + 8
        s.execute(text("CREATE TABLE IF NOT EXISTS sinc_dato (id INTEGER PRIMARY KEY AUTOINCREMENT, tipo TEXT, ref TEXT, borrado BOOLEAN)"))
        s.execute(text("INSERT INTO sinc_dato (tipo, ref, borrado) VALUES ('promo', :r, 1)"), {"r": str(t * modulos.RANGO + 20)}); s.commit()
        assert sc.id_nuevo_elemento(s, eid, "fis_promociones", t) == t * modulos.RANGO + 21     # nunca cae sobre una lápida


def test_cambiar_id_elemento_en_el_programa():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        modulos.aplicar_cambios(s, eid, "fis_promociones", [{"id": 4, "nombre": "2x1 local"}, {"id": 5, "nombre": "Otra"}], [], [4, 5])
        nuevo = 3 * modulos.RANGO + 1
        assert sc.cambiar_id_elemento(s, eid, "fis_promociones", 4, nuevo) is True
        s.commit()
        assert {x["id"]: x["nombre"] for x in modulos.leer(s, eid, "fis_promociones", [])} == {5: "Otra", nuevo: "2x1 local"}
        assert sc.cambiar_id_elemento(s, eid, "fis_promociones", 5, nuevo) is False              # el nuevo ya existe
        assert sc.cambiar_id_elemento(s, eid, "fis_promociones", 99, nuevo + 1) is False         # el viejo no existe


# ----------------------------------------------------------------------------------------------------------------- heurísticas
def test_heuristica_de_lineas_por_nombre_normalizado():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        bien, pisado, combo = _producto(s, eid, "Café con leche"), _producto(s, eid, "Arroz cantonés"), _producto(s, eid, "Papas")
        _doc(s, eid, [(bien, "CAFE  con  LECHE (sin azúcar)", 1), (pisado, "Batido de fresa", 2), (pisado, "Batido de fresa (grande)", 1),
                      (combo, "Papas · Combo 1", 1)])
        _doc(s, eid, [(bien, "Otra cosa", 1)], origen="nube")             # bajado de la web: no cuenta con solo_locales
        r = sc.heuristica_lineas(s, eid)
        assert r == [{"tipo": "producto", "ref": str(pisado), "nombre": "Arroz cantonés", "en_ventas": "Batido de fresa", "ventas": 2, "coinciden": 0}]
        assert sc.normal("Café  con-Leche!") == "cafe con leche"


def test_heuristica_recetas_y_extras():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        sin_nada = _producto(s, eid, "Hamburguesa")
        con_receta = _producto(s, eid, "Pizza")
        con_extra = _producto(s, eid, "Hot dog")
        por_grupo = _producto(s, eid, "Batido", categoria="Bebidas")
        sin_opciones = _producto(s, eid, "Agua")
        modulos.reemplazar(s, eid, "recetas", [{"id": con_receta, "producto_id": con_receta, "ingredientes": [], "rendimiento": 1}], version=0)
        modulos.reemplazar(s, eid, "items_extra", {str(con_extra): {"modificadores": [1]}}, version=0)
        modulos.reemplazar(s, eid, "pos_modificadores", [{"id": 1, "nombre": "Tamaño", "categorias": ["Bebidas"], "productos": []}], version=0)
        _doc(s, eid, [(sin_nada, "Hamburguesa (queso, sin cebolla)", 1), (sin_nada, "Hamburguesa (tocineta)", 1), (con_receta, "Pizza (extra queso)", 1),
                      (con_extra, "Hot dog (mostaza)", 1), (por_grupo, "Batido (grande)", 1), (sin_opciones, "Agua", 1)])
        assert sc.heuristica_recetas_extras(s, eid) == [{"tipo": "producto", "ref": str(sin_nada), "nombre": "Hamburguesa", "ventas_con_opciones": 2}]


# ================================================================================================================= LADO PROGRAMA (días 6-7)
import contextlib  # noqa: E402
import json  # noqa: E402

from app import secretos  # noqa: E402
from app import sinc_diario as diario  # noqa: E402
from app import sinc_datos as sd  # noqa: E402
try:
    from app import sinc_datos_decl  # noqa: F401,E402
except ImportError:
    pass
from app import sinc_datos_programa as sdp  # noqa: E402

T = 3
VINCULADA = "2026-11-05T12:00:00+00:00"


def _programa(carga: str = "pendiente", **estado) -> int:
    """Empresa de un programa conectado (terminal 3) con el protocolo 2 y la carga en `carga`."""
    with Session(engine) as s0:
        e = auth.crear_empresa(s0, "Primera subida programa QA", f"b6p-{random.randint(1, 10**9)}@example.test", "31013" + str(random.randint(10**4, 10**5 - 1)))
        eid, clave = e.id, e.clave_cifrada
    with Session(engine_empresa(eid)) as s:
        sinc._escribir(s, eid, sinc.CLAVE_LOCAL, {"vinculado": True, "url": "http://nube432b6", "token": secretos.cifrar(clave, "fcr_prueba_b6"),
                                                  "terminal": T, "vinculada_en": VINCULADA})
        s.commit()
    sdp.olvidar(eid)                                    # sin fijar_rango: los datos de la prueba nacen en el rango 0, como los de antes de conectar
    orig = sinc.MODO_LOCAL
    sinc.MODO_LOCAL = True
    try:
        sdp.pasar_a_protocolo_2(eid)
        sdp._guardar_estado(eid, releyendo=False, carga=carga, **estado)
    finally:
        sinc.MODO_LOCAL = orig
    return eid


def _cerrar(eid: int) -> None:
    modulos._rangos.pop(eid, None)
    sdp.olvidar(eid)


def _altas(eid: int) -> list:
    with Session(engine_empresa(eid)) as s:
        return [(t, r, json.loads(d)) for t, r, d in s.connection().execute(text("SELECT tipo, ref, datos FROM sinc_cambio WHERE op = 'alta' ORDER BY id")).all()]


def _sinc_dato(eid: int, tipo: str, ref, v: int = 900, borrado: bool = False) -> None:
    with Session(engine_empresa(eid)) as s:
        s.connection().execute(text("INSERT INTO sinc_dato (tipo, ref, v, campos, origen, borrado, huella, cambiado) VALUES (:t, :r, :v, '{}', 0, :b, '', '')"),
                               {"t": tipo, "r": str(ref), "v": v, "b": borrado})
        s.commit()


@contextlib.contextmanager
def _local():
    """Como en el programa (FE_MODO_LOCAL=1) solo mientras corre lo que se prueba: los datos de la prueba se crean antes, sin el oyente."""
    orig = sinc.MODO_LOCAL
    sinc.MODO_LOCAL = True
    try:
        yield
    finally:
        sinc.MODO_LOCAL = orig


def _L(fn, *a, **k):
    with _local():
        return fn(*a, **k)


def _alta_en_cola(eid: int, ref, estado: str) -> None:
    with Session(engine_empresa(eid)) as s:
        s.connection().execute(text("INSERT INTO sinc_cambio (autora, n, tipo, ref, op, base_v, datos, por, estado, resultado, intentos, creado) "
                                    "VALUES ('3.abcd', 1, 'producto', :r, 'alta', 0, '{}', NULL, :e, NULL, 0, '')"), {"r": str(ref), "e": estado})
        s.commit()


# ----------------------------------------------------------------------------------------------------------------- lista de choques
def test_lista_de_choques_en_tabla_propia_una_fila_por_dato():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        assert sc.lista_choques(s, eid) == []
        sc.anotar_choque(s, "eliminado_web", "producto", 7, "Té frío")
        sc.anotar_choque(s, "eliminado_web", "producto", 7, "Té frío helado")         # repetida: se actualiza, no se duplica
        sc.avisar_renumerado(s, "promo", 4, 3 * modulos.RANGO + 1, "2x1")
        s.commit()
        lista = sc.lista_choques(s, eid)
    assert [(x["clase"], x["tipo"], x["ref"], x["nombre"]) for x in lista] == [
        ("eliminado_web", "producto", "7", "Té frío helado"), ("renumerado", "promo", str(3 * modulos.RANGO + 1), "2x1")]
    assert lista[0]["texto"].startswith("¿Eliminado en la página web?") and lista[1]["detalle"] == {"antes": "4"}


def test_guardar_heuristicas_pasa_las_dos_a_la_lista():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        pisado, sin_receta = _producto(s, eid, "Arroz cantonés"), _producto(s, eid, "Hamburguesa")
        _doc(s, eid, [(pisado, "Batido de fresa", 1), (sin_receta, "Hamburguesa (queso)", 1)])
        assert sc.guardar_heuristicas(s, eid) == 2
        s.commit()
        assert {(x["clase"], x["ref"]) for x in sc.lista_choques(s, eid)} == {("pisado_antes", str(pisado)), ("sin_receta", str(sin_receta))}


# ----------------------------------------------------------------------------------------------------------------- retención
def test_retencion_durante_la_carga_inicial_con_el_gancho_de_sinc_datos_programa():
    assert sc.retencion in sdp._retenciones and sc.paso_carga in sdp._pasos_carga          # registrados al importar sinc_completar
    eid = _programa("filas")
    try:
        with Session(engine_empresa(eid)) as s:
            local, conocido, ingred, plato = (_producto(s, eid, "Local"), _producto(s, eid, "Conocido"), _producto(s, eid, "Harina"),
                                              _producto(s, eid, "Pan"))
            cli, cli_conocido = _cliente(s, eid, "Ana"), _cliente(s, eid, "Beto")
            terminal = T * modulos.RANGO + 5
            s.add(Producto(id=terminal, empresa_id=eid, nombre="De la terminal", cabys="1234567890123", precio=1)); s.commit()
            modulos.reemplazar(s, eid, "recetas", [{"id": plato, "producto_id": plato, "ingredientes": [{"producto_id": ingred, "cantidad": 1}],
                                                    "rendimiento": 1}], version=0)
            s.commit()
        for tipo, i in (("producto", conocido), ("producto", plato), ("cliente", cli_conocido)):
            _sinc_dato(eid, tipo, i)
        with Session(engine_empresa(eid)) as s:
            d_local = _doc(s, eid, [(local, "Local", 1)])
            d_receta = _doc(s, eid, [(plato, "Pan", 1)])                                  # el ingrediente es del rango 0 sin versión
            d_cliente = _doc(s, eid, [(conocido, "Conocido", 1)], cliente_id=cli)
            libres = [_doc(s, eid, [(conocido, "Conocido", 1)], cliente_id=cli_conocido), _doc(s, eid, [(terminal, "De la terminal", 1)])]
            docs = [d_local, d_receta, d_cliente] + libres
            esperan = {d_local.id, d_receta.id, d_cliente.id}
            assert _L(sc.retencion, s, eid) == {"producto": {local, ingred}, "cliente": {cli}}
            assert _L(sdp.documentos_en_espera, s, eid, docs) == esperan
        sdp._guardar_estado(eid, carga="reenlace")                                   # la pregunta del rango 0 todavía no se hizo
        with Session(engine_empresa(eid)) as s:
            assert _L(sdp.documentos_en_espera, s, eid, docs) == esperan
        sdp._guardar_estado(eid, completar="reenlace")                               # ya encoló sus altas: las retiene sinc_datos_programa
        with Session(engine_empresa(eid)) as s:
            assert _L(sc.retencion, s, eid) == {} and _L(sdp.documentos_en_espera, s, eid, docs) == set()
        sdp._guardar_estado(eid, carga="filas", pausa_desde="2026-11-13T00:00:00+00:00")   # en pausa sube como la 4.31
        with Session(engine_empresa(eid)) as s:
            assert _L(sc.retencion, s, eid) == {}
    finally:
        _cerrar(eid)


def test_retencion_vacia_con_el_protocolo_de_la_431_y_con_la_carga_hecha():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        p = _producto(s, eid, "Local")
        d = _doc(s, eid, [(p, "Local", 1)])
        assert _L(sc.retencion, s, eid) == {} and _L(sdp.documentos_en_espera, s, eid, [d]) == set()
    eid = _programa("hecha")
    try:
        with Session(engine_empresa(eid)) as s:
            assert _L(sc.retencion, s, eid) == {}
    finally:
        _cerrar(eid)


# ----------------------------------------------------------------------------------------------------------------- reserva y existencias del alta
def test_pedido_reserva_y_al_reservar():
    eid = _programa("pendiente")
    try:
        with Session(engine_empresa(eid)) as s:
            _producto(s, eid, "A")
            b, c = _producto(s, eid, "B"), _cliente(s, eid, "Ana")
            s.add(Producto(id=T * modulos.RANGO + 9, empresa_id=eid, nombre="Terminal", cabys="1234567890123", precio=1)); s.commit()
        assert _L(sc.pedido_reserva, eid) == {"producto": b, "cliente": c}         # solo el rango 0
        _L(sc.al_reservar, eid, {"producto": {"max_dado": 790}, "cliente": {"max_dado": "x"}})
        assert sdp.estado(eid)["reservado"] == {"producto": 790} and sdp.estado(eid)["carga"] == "pendiente"   # «carga» la mueve P2
        _L(sc.al_reservar, eid, {"producto": {"max_dado": 1}})                     # una respuesta posterior no lo cambia
        assert sdp.estado(eid)["reservado"] == {"producto": 790}
        sdp._guardar_estado(eid, carga="filas")
        assert _L(sc.pedido_reserva, eid) is None
    finally:
        _cerrar(eid)
    eid = _programa("pendiente")
    try:
        _L(sc.al_reservar, eid, {})                                                  # no es la única instalación
        assert sdp.estado(eid)["reservado"] == {}
    finally:
        _cerrar(eid)


def test_completar_ops_agrega_la_existencia_con_lo_pendiente():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        p = _producto(s, eid, "Café", inventariable=True)
        bid = inventario.bodega_principal(s, eid).id
        prod = s.get(Producto, p)
        inventario.registrar_movimiento(s, producto=prod, bodega_id=bid, tipo="inicial", cantidad=10, fecha="2026-11-01", costo_unitario=100, referencia="x")
        s.commit()
        d = _doc(s, eid, [(p, "Café", 3)])
        inventario.registrar_movimiento(s, producto=s.get(Producto, p), bodega_id=bid, tipo="venta", cantidad=-3, fecha="2026-11-01", documento_id=d.id,
                                        referencia="v")
        s.commit()
        ops = [{"tipo": "producto", "ref": str(p), "op": "alta", "datos": {"fila": {"id": p}}},
               {"tipo": "producto", "ref": str(T * modulos.RANGO + 1), "op": "alta", "datos": {"fila": {}}},
               {"tipo": "producto", "ref": str(p), "op": "cambio", "datos": {"campos": {}}},
               {"tipo": "cliente", "ref": "5", "op": "alta", "datos": {"fila": {}}}]
        sc.completar_ops(s, eid, ops)
    assert ops[0]["datos"]["existencias"] == [{"bodega_id": bid, "cantidad": 10.0, "costo_promedio": 100.0, "pendiente": 3.0}]
    assert ops[0]["datos"]["fila"] == {"id": p}
    assert all("existencias" not in o["datos"] for o in ops[1:])


# ----------------------------------------------------------------------------------------------------------------- /filas del rango 0
def test_paso_carga_pregunta_el_rango_0_y_decide_con_la_prueba_de_es_local():
    eid = _programa("reenlace", reservado={"producto": 5})
    try:
        with Session(engine_empresa(eid)) as s:
            ids = [_producto(s, eid, f"P{i}") for i in range(8)]
            usado, eliminado, igual, otro, borrado = ids[:5]
            alto = _producto(s, eid, "Nuevo")                                         # id mayor que max_dado (5)
            cli = _cliente(s, eid, "Ana")
            terminal = T * modulos.RANGO + 7
            s.add(Producto(id=terminal, empresa_id=eid, nombre="Del rango propio", cabys="1234567890123", precio=1)); s.commit()
            _doc(s, eid, [(usado, "P0", 1)], cliente_id=cli, fecha="2026-11-01T10:00:00-06:00")   # antes de vincular: prueba (1)
            _doc(s, eid, [(eliminado, "P1", 1)], fecha="2026-11-10T10:00:00-06:00")             # después: no es prueba
            contenido_igual = sdp.contenido_local(s, eid, sd.dato("producto"), str(igual))
        assert max(ids[:5]) <= 5 < alto
        for p in ids[5:]:
            _sinc_dato(eid, "producto", p)                                            # ya los conoce de la web: no son candidatos
        vistas = []
        res = {str(usado): ("nunca", None), str(eliminado): ("nunca", None), str(alto): ("nunca", None),
               str(igual): ("existe", contenido_igual), str(otro): ("existe", {**contenido_igual, "id": otro, "nombre": "Otro de la web"}),
               str(borrado): ("borrado", None)}

        def web(refs):
            vistas.extend(refs)
            filas = []
            for r in refs:
                est, datos = res.get(r["ref"], ("nunca", None)) if r["tipo"] == "producto" else ("nunca", None)
                filas.append({"tipo": r["tipo"], "ref": r["ref"], "estado": est, "v": None if est == "nunca" else 950, "datos": datos})
            return {"filas": filas, "max_dado": {"producto": 5, "cliente": 0}, "epoca": "w1"}

        def accion(*a):
            return {"resultado": {}, "filas": []}

        assert _L(sc.paso_carga, eid, pedir_filas=web, pedir_accion=accion) is False      # las altas todavía sin veredicto
        assert ("cliente", str(cli)) in {(r["tipo"], r["ref"]) for r in vistas}
        assert not ({str(p) for p in ids[5:]} | {str(terminal)}) & {r["ref"] for r in vistas if r["tipo"] == "producto"}
        assert {(t, r) for t, r, _ in _altas(eid)} == {("producto", str(usado)), ("producto", str(alto))}   # el cliente no: sin reserva
        with Session(engine_empresa(eid)) as s:
            choques = {(x["clase"], x["tipo"], x["ref"]) for x in sc.lista_choques(s, eid)}
            assert choques == {("eliminado_web", "producto", str(eliminado)), ("choque", "producto", str(otro)), ("no_subio", "cliente", str(cli))}
            assert s.get(Producto, eliminado) is not None                            # el «eliminado» sigue aquí y no sube
            assert s.get(Producto, otro).nombre == "P3"                              # el choque no se pisa aquí
            assert s.get(Producto, borrado) is None                                  # con lápida y sin historia: la baja de siempre
            assert s.connection().execute(text("SELECT v FROM sinc_dato WHERE tipo = 'producto' AND ref = :r"), {"r": str(igual)}).scalar() == 950
        assert sdp.estado(eid)["completar"] == "reenlace"
        vistas.clear()
        assert _L(sc.paso_carga, eid, pedir_filas=web, pedir_accion=accion) is False and vistas == []   # no vuelve a preguntar
    finally:
        _cerrar(eid)


def test_candidatos_del_rango_0_sin_version_ni_operacion_pendiente():
    eid = _programa("reenlace")
    try:
        promo = sd.Dato("zz_promo_b6", registro="zz_promos_b6")                     # sin declarar: solo para candidatos(tipos=...)
        with Session(engine_empresa(eid)) as s:
            modulos.reemplazar(s, eid, "zz_promos_b6", [{"id": 3, "nombre": "2x1"}, {"id": 5, "nombre": "3x2"}, {"id": 6, "nombre": "Vista"},
                                                       {"id": T * modulos.RANGO + 4, "nombre": "Propia"}], version=0)
            s.commit()
        _sinc_dato(eid, "zz_promo_b6", 6)
        with Session(engine_empresa(eid)) as s:
            s.connection().execute(text("INSERT INTO sinc_cambio (autora, n, tipo, ref, op, base_v, datos, por, estado, resultado, intentos, creado) "
                                        "VALUES ('3.abcd', 1, 'zz_promo_b6', '5', 'alta', 0, '{}', NULL, 'enviada', NULL, 1, '')"))
            s.commit()
            assert [(d.tipo, r) for d, r in sc.candidatos(s, eid, [promo])] == [("zz_promo_b6", "3")]
    finally:
        _cerrar(eid)


def test_paso_carga_sin_conexion_sigue_donde_estaba():
    eid = _programa("reenlace", reservado={"producto": 0})
    try:
        with Session(engine_empresa(eid)) as s:
            _producto(s, eid, "A")

        def sin_red(refs):
            raise sdp.SinConexionWeb("prueba")

        assert _L(sc.paso_carga, eid, pedir_filas=sin_red) is False
        assert sdp.estado(eid).get("completar") is None and _altas(eid) == []
        sdp._guardar_estado(eid, pausa_desde="2026-11-13T00:00:00+00:00")            # en pausa no da el paso
        assert _L(sc.paso_carga, eid, pedir_filas=lambda refs: pytest.fail("no debía preguntar")) is False
    finally:
        _cerrar(eid)


def test_paso_carga_no_hace_nada_con_el_protocolo_de_la_431():
    eid = _empresa()
    assert _L(sc.paso_carga, eid, pedir_filas=lambda r: pytest.fail("no"), pedir_accion=lambda *a: pytest.fail("no")) is False
    assert _L(sc.pedido_reserva, eid) is None


# ----------------------------------------------------------------------------------------------------------------- reenlace
def test_paso_reenlace_espera_las_altas_y_despues_reenlaza():
    eid = _programa("reenlace", completar="reenlace")
    try:
        with Session(engine_empresa(eid)) as s:
            p, cli = _producto(s, eid, "Café"), _cliente(s, eid, "Ana")
            subido = _doc(s, eid, [(p, "Café", 1), (None, "Varios", 1)], cliente_id=cli, sinc_en="2026-11-02T00:00:00")
            subido.receptor_nombre = "Ana"; s.add(subido); s.commit(); s.refresh(subido)
            _doc(s, eid, [(p, "Café", 1)], sinc_en=None)                              # no ha subido: sube por su camino
            _doc(s, eid, [(p, "Café", 1)], origen="nube", sinc_en="2026-11-02T00:00:00")   # vino de la web
            pago = modulos.Pago(empresa_id=eid, cliente_id=cli, cliente_nombre="Ana", monto=1000, fecha="2026-11-02")
            s.add(pago); s.commit(); s.refresh(pago)
            ref_pago, clave = diario.ref_pago(pago), subido.clave
        _alta_en_cola(eid, p, "abierta")
        llamadas = []

        def accion(eid_, tipo, ref, accion_, datos, por):
            llamadas.append((tipo, ref, accion_, datos))
            return {"resultado": {"lineas": 1, "comprobantes": 1, "cobros": 1, "faltan": [],
                                  "choques": [{"tipo": "linea", "clave": clave, "numero": 1, "web": 77, "programa": p}]}, "filas": []}

        assert _L(sc.paso_carga, eid, pedir_accion=accion) is False and llamadas == []   # alta sin veredicto: espera
        with Session(engine_empresa(eid)) as s:
            s.connection().execute(text("UPDATE sinc_cambio SET estado = 'hecha'")); s.commit()
        assert _L(sc.paso_carga, eid, pedir_accion=accion) is True
        assert len(llamadas) == 1 and llamadas[0][:3] == ("_carga", "_", "reenlazar")
        datos = llamadas[0][3]
        assert datos["comprobantes"] == [{"clave": clave, "lineas": [{"numero": 1, "producto_id": p}], "cliente_id": cli}]
        assert datos["cobros"] == [{"referencia": ref_pago, "cliente_id": cli}]
        assert sdp.estado(eid)["completar"] == "hecha"
        with Session(engine_empresa(eid)) as s:
            assert [(x["clase"], x["tipo"], x["ref"]) for x in sc.lista_choques(s, eid)] == [("reenlace", "linea", f"{clave}#1")]
        assert _L(sc.paso_carga, eid, pedir_accion=accion) is True and len(llamadas) == 1   # hecha: no repite
    finally:
        _cerrar(eid)


def test_lotes_de_reenlace_respetan_el_tope():
    datos = {"comprobantes": [{"clave": str(i) * 50, "lineas": [], "cliente_id": i} for i in range(10)], "cobros": [{"referencia": "3:1:2", "cliente_id": 1}]}
    lotes = sc.lotes_reenlace(datos, tope=300)
    assert sum(len(x["comprobantes"]) for x in lotes) == 10 and sum(len(x["cobros"]) for x in lotes) == 1
    assert len(lotes) > 1 and all(len(json.dumps(x)) < 600 for x in lotes)
    assert sc.lotes_reenlace({"comprobantes": [], "cobros": []}) == []


# ----------------------------------------------------------------------------------------------------- relectura de la carga inicial (S10)
def _relectura(eid: int, tipo: str, ref, datos, v: int = 900) -> bool:
    fila = {"tipo": tipo, "ref": str(ref), "v": v, "borrado": datos is None, "datos": datos, "campos": {}, "dueno": None, "origen": 0}
    with _local(), Session(engine_empresa(eid)) as s, diario.aplicando(0):
        ok = sdp.aplicar_canonico(s, eid, fila, motivo_pisado="programa_anterior")
        s.commit()
    return ok


def _choques(eid: int) -> dict:
    with Session(engine_empresa(eid)) as s:
        return {(x["clase"], x["tipo"], x["ref"]): x["detalle"] for x in sc.lista_choques(s, eid)}


@pytest.mark.parametrize("lapida", [False, True])
def test_relectura_conserva_la_promocion_local_con_id_nuevo_y_la_sube_por_las_filas_propias(lapida):
    eid = _programa("pendiente")
    try:
        with Session(engine_empresa(eid)) as s:
            modulos.reemplazar(s, eid, "fis_promociones", [{"id": 1, "nombre": "Promo local QA", "activa": True}], version=0)
            s.commit()
        assert _relectura(eid, "promo", 1, None if lapida else {"id": 1, "nombre": "Promo web QA", "activa": True}) is True
        with Session(engine_empresa(eid)) as s:
            promos = modulos.leer(s, eid, "fis_promociones", [])
            locales = [x for x in promos if x.get("nombre") == "Promo local QA"]
            assert len(locales) == 1 and T * modulos.RANGO < locales[0]["id"] < (T + 1) * modulos.RANGO      # no se perdió: id del rango propio
            nuevo = locales[0]["id"]
            assert [x.get("nombre") for x in promos if x.get("id") == 1] == ([] if lapida else ["Promo web QA"])
            assert ("promo", str(nuevo)) in sdp._refs_propias(s, eid, T)             # la carga «filas» lo pregunta y lo da de alta con ese id
        assert _choques(eid)[("renumerado", "promo", str(nuevo))] == {"antes": "1"}
    finally:
        _cerrar(eid)


def test_relectura_de_un_registro_de_catalogo_anota_el_local_pisado_con_su_contenido():
    eid = _programa("pendiente")
    try:
        with Session(engine_empresa(eid)) as s:
            modulos.reemplazar(s, eid, "pos_promos", [{"id": 1, "nombre": "2x1 local QA"}], version=0)
            s.commit()
        assert _relectura(eid, "promo_pos", 1, {"id": 1, "nombre": "2x1 web QA"}) is True
        with Session(engine_empresa(eid)) as s:
            assert [x.get("nombre") for x in modulos.leer(s, eid, "pos_promos", [])] == ["2x1 web QA"]    # la web gana, como en la 4.31
        det = _choques(eid)[("pisado_carga", "promo_pos", "1")]
        assert det["programa"]["nombre"] == "2x1 local QA" and det["web"]["nombre"] == "2x1 web QA"
    finally:
        _cerrar(eid)


def test_relectura_fuera_de_la_carga_o_con_version_previa_no_renumera():
    for carga, previa in (("hecha", False), ("pendiente", True)):
        eid = _programa(carga)
        try:
            with Session(engine_empresa(eid)) as s:
                modulos.reemplazar(s, eid, "fis_promociones", [{"id": 1, "nombre": "Promo local QA"}], version=0)
                s.commit()
            if previa:
                _sinc_dato(eid, "promo", 1, v=0)                                     # época nueva de la web: ya vino de allá
            assert _relectura(eid, "promo", 1, {"id": 1, "nombre": "Promo web QA"}) is True
            with Session(engine_empresa(eid)) as s:
                assert [x.get("nombre") for x in modulos.leer(s, eid, "fis_promociones", [])] == ["Promo web QA"]
            assert not any(c == "renumerado" for c, _, _ in _choques(eid))
        finally:
            _cerrar(eid)


# ----------------------------------------------------------------------------------------------------- cierre S10 (revisión adversaria)
def _ops_de(eid: int, tipo: str, ref) -> list:
    with Session(engine_empresa(eid)) as s:
        return [o for (o,) in s.connection().execute(text("SELECT op FROM sinc_cambio WHERE tipo = :t AND ref = :r"), {"t": tipo, "r": str(ref)}).all()]


@pytest.mark.parametrize("baja", [False, True])
def test_cambio_o_baja_de_la_promocion_local_durante_la_carga_no_se_encola_ni_cae_sobre_la_de_la_web(baja):
    eid = _programa("pendiente")
    try:
        with Session(engine_empresa(eid)) as s:
            modulos.reemplazar(s, eid, "fis_promociones", [{"id": 1, "nombre": "Promo local QA", "activa": True}], version=0)
            s.commit()
        with _local(), Session(engine_empresa(eid)) as s:          # el usuario la toca en la ventana de la carga
            if baja:
                modulos.aplicar_cambios(s, eid, "fis_promociones", [], [1], [])
            else:
                modulos.aplicar_cambios(s, eid, "fis_promociones", [{"id": 1, "nombre": "Promo local QA", "activa": False}], [], [])
            s.commit()
        assert _ops_de(eid, "promo", 1) == []                       # en la web el 1 es OTRA promoción: ni «cambio» ni «baja» con base 0
        assert _relectura(eid, "promo", 1, {"id": 1, "nombre": "Promo web QA", "activa": True}) is True
        with Session(engine_empresa(eid)) as s:
            promos = sorted(modulos.leer(s, eid, "fis_promociones", []), key=lambda x: x["id"])
        if baja:
            assert promos == [{"id": 1, "nombre": "Promo web QA", "activa": True}]
        else:
            assert promos[0] == {"id": 1, "nombre": "Promo web QA", "activa": True}
            assert len(promos) == 2 and promos[1]["nombre"] == "Promo local QA" and promos[1]["activa"] is False
            assert T * modulos.RANGO < promos[1]["id"] < (T + 1) * modulos.RANGO
    finally:
        _cerrar(eid)


def test_cambio_de_la_promocion_local_fuera_de_la_carga_si_se_encola():
    eid = _programa("hecha")
    try:
        with Session(engine_empresa(eid)) as s:
            modulos.reemplazar(s, eid, "fis_promociones", [{"id": 1, "nombre": "Promo local QA", "activa": True}], version=0)
            s.commit()
        with _local(), Session(engine_empresa(eid)) as s:
            modulos.aplicar_cambios(s, eid, "fis_promociones", [{"id": 1, "nombre": "Promo local QA", "activa": False}], [], [])
            s.commit()
        assert _ops_de(eid, "promo", 1) == ["cambio"]
    finally:
        _cerrar(eid)


def test_choque_con_detalle_grande_se_lee_entero_en_la_lista():
    eid = _programa("pendiente")
    try:
        grande = {"nombre": "Tallas local QA", "opciones": [{"producto_id": i, "nombre": f"opción local QA número {i}"} for i in range(80)]}
        with Session(engine_empresa(eid)) as s:
            sc.anotar_choque(s, "pisado_carga", "modificador", 1, "Tallas local QA", {"programa": grande, "web": {"nombre": "Tallas web QA"}})
            s.commit()
        det = _choques(eid)[("pisado_carga", "modificador", "1")]
        assert det["programa"] == grande and det["web"]["nombre"] == "Tallas web QA"
    finally:
        _cerrar(eid)


# ================================================================================================= revisión 4.32, grupo E (primera subida)
def test_rev5_reenlace_programa_salta_y_anota_lo_que_hoy_es_otro():
    """n.º 5: la venta vieja de «Hamburguesa» y la factura de Juan no se mandan con el número que hoy es «Café» y «María»; van a la lista."""
    eid = _programa("reenlace", completar="reenlace")
    try:
        with Session(engine_empresa(eid)) as s:
            cafe, pan = _producto(s, eid, "Café"), _producto(s, eid, "Pan")
            maria, ana = _cliente(s, eid, "María"), _cliente(s, eid, "Ana")
            d = _doc(s, eid, [(cafe, "Hamburguesa", 1), (pan, "Pan (tostado)", 1)], cliente_id=maria, sinc_en="2026-11-02T00:00:00")
            d.receptor_nombre = "Juan"; s.add(d)
            s.get(Cliente, ana).numero_id = "1-0101-0101"
            s.add(modulos.Pago(empresa_id=eid, numero=1, cliente_id=maria, cliente_nombre="Juan", monto=1000, fecha="2026-11-02"))
            s.add(modulos.Pago(empresa_id=eid, numero=2, cliente_id=ana, cliente_nombre="Ana María", cliente_cedula="101010101", monto=1000, fecha="2026-11-02"))
            s.commit()
            clave = d.clave
        llamadas = []

        def accion(eid_, tipo, ref, accion_, datos, por):
            llamadas.append(datos)
            return {"resultado": {"lineas": 1, "comprobantes": 0, "cobros": 1, "faltan": [], "choques": []}, "filas": []}

        assert _L(sc.paso_carga, eid, pedir_accion=accion) is True
        datos = llamadas[0]
        assert datos["comprobantes"] == [{"clave": clave, "lineas": [{"numero": 2, "producto_id": pan}], "cliente_id": None}]
        assert [c["cliente_id"] for c in datos["cobros"]] == [ana]                  # por la cédula
        assert "saltados" not in datos
        with Session(engine_empresa(eid)) as s:
            ch = {(x["clase"], x["tipo"], x["ref"]): x for x in sc.lista_choques(s, eid)}
        assert ch[("reenlace_nombre", "producto", str(cafe))]["detalle"] == {"en_ventas": "Hamburguesa", "ventas": 1}
        assert ch[("reenlace_nombre", "cliente", str(maria))]["detalle"] == {"en_ventas": "Juan", "comprobantes": 1, "cobros": 1}
        assert ch[("reenlace_nombre", "producto", str(cafe))]["texto"]
    finally:
        _cerrar(eid)


def test_rev5_reenlace_web_no_llena_con_otro_y_lo_devuelve_como_choque():
    eid, s, v, item, otro, cli, vacia, de_web = _web_con_ventas_viejas()
    try:
        ajeno = _cliente(s, eid, "María")
        datos = {"comprobantes": [{"clave": vacia.clave, "lineas": [{"numero": 3, "producto_id": item}], "cliente_id": ajeno}],
                 "cobros": [{"referencia": "3:5:1730000000", "cliente_id": ajeno}]}
        r = sc.accion_reenlazar(s, eid, _ctx(eid), "_", datos, None)
        assert (r["lineas"], r["comprobantes"], r["cobros"]) == (0, 0, 0)
        assert {(c["tipo"], c.get("motivo")) for c in r["choques"]} == {("linea", "nombre"), ("comprobante", "nombre"), ("cobro", "nombre")}
        s.expire_all()
        assert s.get(Documento, vacia.id).cliente_id is None
        assert {ln.numero: ln.producto_id for ln in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == vacia.id)).all()}[3] is None
    finally:
        s.close()


def test_rev35_cobros_de_antes_de_conectar_solo_con_la_unica_instalacion():
    eid = _empresa()
    s = Session(engine_empresa(eid))
    try:
        _vinc(s, eid, OTRO)                                                         # dos instalaciones vigentes
        cli = _cliente(s, eid, "Ana")
        s.add(modulos.Pago(empresa_id=eid, numero=1, cliente_id=None, cliente_nombre="Ana", origen_sinc="0:9:1730000000", monto=1000))
        s.add(modulos.Pago(empresa_id=eid, numero=2, cliente_id=None, cliente_nombre="Ana", origen_sinc="3:9:1730000000", monto=1000))
        s.commit()
        r = sc.accion_reenlazar(s, eid, _ctx(eid), "_", {"cobros": [{"referencia": "0:9:1730000000", "cliente_id": cli},
                                                                     {"referencia": "3:9:1730000000", "cliente_id": cli}]}, None)
        assert r["cobros"] == 1
        s.expire_all()
        assert {p.origen_sinc: p.cliente_id for p in s.exec(select(modulos.Pago)).all()} == {"0:9:1730000000": None, "3:9:1730000000": cli}
    finally:
        s.close()


def test_rev25_un_vacio_suelto_no_es_firme_y_la_carga_espera():
    eid = _programa("pendiente")
    try:
        with Session(engine_empresa(eid)) as s:
            _producto(s, eid, "A")
        _L(sc.al_reservar, eid, None)                                               # sin «reservado» (error en la web): nada
        assert "reservado" not in sdp.estado(eid)
        _L(sc.al_reservar, eid, {})
        assert _L(sc.pedido_reserva, eid) is not None                              # se vuelve a pedir
        sdp._guardar_estado(eid, carga="reenlace")
        assert _L(sc.paso_carga, eid, pedir_filas=lambda r: pytest.fail("no debía preguntar todavía")) is False
        assert _L(sc.pedido_reserva, eid) is not None
        _L(sc.al_reservar, eid, {"producto": {"max_dado": 7}})                     # la buena reemplaza al {}
        assert sdp.estado(eid)["reservado"] == {"producto": 7} and _L(sc.pedido_reserva, eid) is None
        _L(sc.al_reservar, eid, {})                                                 # y ya no se cambia
        assert sdp.estado(eid)["reservado"] == {"producto": 7}
    finally:
        _cerrar(eid)
    eid = _programa("reenlace")
    try:
        _L(sc.al_reservar, eid, {})
        _L(sc.al_reservar, eid, {})                                                 # repetido: es firme («no es la única instalación»)
        assert sc.reserva_lista(sdp.estado(eid)) and _L(sc.pedido_reserva, eid) is None
        vistas = []
        _L(sc.paso_carga, eid, pedir_filas=lambda r: vistas.append(r) or {"filas": [], "max_dado": {}}, pedir_accion=lambda *a: {"resultado": {}})
        assert sdp.estado(eid)["completar"] in ("reenlace", "hecha")
    finally:
        _cerrar(eid)


def test_rev27_reservar_no_agranda_ni_acepta_un_numero_absurdo():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        v = _vinc(s, eid)
        _producto(s, eid, "Uno")
        assert sc.reservar(s, eid, _inst(v), v, {"producto": 9_999_999}) == {}     # no reserva: la web seguiría creando ítems
        assert _ultimo(s, "producto") < 1000
        r = sc.reservar(s, eid, _inst(v), v, {"producto": 50})
        assert _ultimo(s, "producto") == 50
        assert sc.reservar(s, eid, _inst(v), v, {"producto": 9_000}) == r          # reintento: misma respuesta, el contador no se mueve
        assert _ultimo(s, "producto") == 50


def test_rev26_bodega_que_la_web_no_tiene_solo_aporta_lo_pendiente_y_se_anota():
    eid = _empresa()
    with Session(engine_empresa(eid)) as s:
        pid = _producto(s, eid, "Arroz", costo=500)
        bod = inventario.bodega_principal(s, eid).id
        n = sc.existencia_inicial(s, eid, s.get(Producto, pid), [{"bodega_id": bod, "cantidad": 10, "costo_promedio": 450.0, "pendiente": 0},
                                                                 {"bodega_id": 99999, "cantidad": 32, "costo_promedio": 450.0, "pendiente": 2}])
        s.commit()
        assert n == 1 and inventario.existencia(s, pid, bod).cantidad == pytest.approx(12)   # 10 + lo retenido de Cocina; los 30 de Cocina no
    eid = _programa("reenlace", reservado={"producto": 0})
    try:
        with Session(engine_empresa(eid)) as s:
            pid = _producto(s, eid, "Arroz")
            bp = inventario.bodega_principal(s, eid).id
            cocina = inventario.Bodega(empresa_id=eid, nombre="Cocina")
            s.add(cocina); s.commit(); s.refresh(cocina)
            for b, q in ((bp, 10), (cocina.id, 30)):
                inventario.registrar_movimiento(s, producto=s.get(Producto, pid), bodega_id=b, tipo="ajuste", cantidad=q, fecha="2026-11-01", costo_unitario=100)
            sc.recordar_bodegas_web(s, eid, [bp])
            s.commit()

        def web(refs):
            return {"filas": [{"tipo": r["tipo"], "ref": r["ref"], "estado": "nunca"} for r in refs], "max_dado": {"producto": 0, "cliente": 0}}

        _L(sc.paso_carga, eid, pedir_filas=web, pedir_accion=lambda *a: {"resultado": {}})
        assert ("producto", str(pid)) in {(t_, r) for t_, r, _ in _altas(eid)}
        with Session(engine_empresa(eid)) as s:
            ch = {(x["clase"], x["tipo"], x["ref"]): x for x in sc.lista_choques(s, eid)}
        assert ch[("bodega_sin_web", "producto", str(pid))]["detalle"] == {"bodegas": [{"bodega": "Cocina", "cantidad": 30}]}
    finally:
        _cerrar(eid)


# ======================================================================================================================
# Validación f3: las recetas hechas aquí antes de conectar suben en la primera subida; si chocan, a la lista de choques con su contenido
# ======================================================================================================================
def test_f3_receta_que_choca_va_a_la_lista_con_su_contenido_y_la_libre_sube():
    eid = _programa("reenlace", reservado={"producto": 0, "cliente": 0})
    try:
        with Session(engine_empresa(eid)) as s:
            plato, otro, libre = _producto(s, eid, "Plato QA"), _producto(s, eid, "Otro QA"), _producto(s, eid, "Libre QA")
            sinc._escribir(s, eid, "recetas", [
                {"id": 1, "producto_id": plato, "rendimiento": 1, "ingredientes": []},       # la web tiene otra receta con el número 1
                {"id": 2, "producto_id": otro, "rendimiento": 1, "ingredientes": []},        # la web ya tiene (aquí, con versión) la del mismo plato
                {"id": 3, "producto_id": libre, "rendimiento": 1, "ingredientes": []},       # nadie la tiene: sube
                {"id": 9, "producto_id": otro, "rendimiento": 2, "ingredientes": []}])       # la de la web (bajó en la relectura)
            s.commit()
        _sinc_dato(eid, "receta", 9)
        web_1 = {"id": 1, "producto_id": 777, "rendimiento": 1, "ingredientes": []}

        def web(refs):
            return {"filas": [{"tipo": r["tipo"], "ref": r["ref"], "estado": "existe" if (r["tipo"], r["ref"]) == ("receta", "1") else "nunca",
                               "v": 5 if (r["tipo"], r["ref"]) == ("receta", "1") else None,
                               "datos": web_1 if (r["tipo"], r["ref"]) == ("receta", "1") else None} for r in refs],
                    "max_dado": {"producto": 0, "cliente": 0}}

        cuentas = _L(sc.paso_filas, eid, pedir_filas=web)
        assert cuentas["choque"] == 2
        recetas_en_cola = {r for t_, r, o in _altas(eid) if t_ == "receta"}
        assert recetas_en_cola == {"3"}                                              # solo la libre sube, con su número
        with Session(engine_empresa(eid)) as s:
            ch = {(x["clase"], x["tipo"], x["ref"]): x for x in sc.lista_choques(s, eid)}
            assert ch[("choque", "receta", "1")]["detalle"] == {"programa": {"id": 1, "producto_id": plato, "rendimiento": 1, "ingredientes": []},
                                                                "web": web_1}
            assert ch[("choque", "receta", "2")]["detalle"]["programa"]["producto_id"] == otro
            assert _L(sc.retencion, s, eid).get("producto", set()) >= {libre}      # la venta del plato con receta en camino espera
    finally:
        _cerrar(eid)


def test_f3_relectura_no_renumera_recetas_las_deja_en_la_lista():
    eid = _programa("reenlace")
    try:
        d = sd.dato("receta")
        local = {"id": 4, "producto_id": 11, "rendimiento": 1, "ingredientes": []}
        web = {"id": 4, "producto_id": 12, "rendimiento": 1, "ingredientes": []}
        with Session(engine_empresa(eid)) as s:
            assert _L(sc.conservar_en_relectura, s, eid, d, "4", local, web) is False   # no se renumera: quedaría repetida en la web
            s.commit()
            ch = {(x["clase"], x["tipo"], x["ref"]): x for x in sc.lista_choques(s, eid)}
        assert ch[("pisado_carga", "receta", "4")]["detalle"] == {"programa": local, "web": web}
        assert "receta" in {x.tipo for x in sc._tipos_carga()}
    finally:
        _cerrar(eid)
