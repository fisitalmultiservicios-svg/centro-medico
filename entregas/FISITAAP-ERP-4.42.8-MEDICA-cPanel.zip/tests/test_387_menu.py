"""3.87: menú, entrada por rol, Inicio y tarjeta de acceso denegado (grupo g3a_menu de la QA 3.87).
- El administrador del sistema dentro de una empresa ve lo que trae el plan: sesion.puede() usa la lista de permisos que manda el
  servidor (ya sin contabilidad, rrhh, reportes, pos ni tike si el plan no los trae). Antes intentaba guardar el catálogo contable
  en empresas sin Contabilidad y salían avisos rojos con 403.
- TiKe e «Importar y actualizar ítems» ya no se abren con ver_todo ni sin catálogos (el servidor los niega); Ingresos pide facturar,
  cobros o ver_todo; Servicios no repite Ingresos y Bancos dentro de Contabilidad; el modo cajero solo ve los pedidos de Ventas en
  línea; Express pendientes y Zonas de envío solo con el extra Entregas.
- Inicio no pide /api/resumen a quien el servidor se lo niega; el técnico de soporte entra a TiKe, un rol solo de planillas a RRHH,
  el Vendedor de restaurante a la caja y Seguridad sin Hotel completo al Inicio.
Las pruebas de la interfaz son de texto (no hay motor de JavaScript en el entorno); el recorrido en el navegador está en
scratchpad/arreglos/g3a_menu_qa/verif_menu.py."""
import json
import pathlib
import re
import uuid

from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, planes
from app.db import Empresa, engine, init_db
from app.main import app

RAIZ = pathlib.Path(__file__).resolve().parent.parent / "app"


def _js(*partes):
    return (RAIZ / "static" / "js" / pathlib.Path(*partes)).read_text(encoding="utf-8")


def test_administrador_del_sistema_con_empresa_recibe_los_permisos_del_plan():
    """Lo que la interfaz usa ahora en sesion.puede(): con empresa elegida, la lista del servidor filtrada por plan."""
    init_db()
    suf = uuid.uuid4().hex[:6]
    correo = f"sa.menu.{suf}@example.test"
    with Session(engine) as s:
        sin = auth.crear_empresa(s, f"Comercio sin conta 387 {suf}", f"sin.{suf}@example.test", tipo_negocio="comercio")
        sin.plan = "pos_basico"; s.add(sin)
        con = auth.crear_empresa(s, f"Comercio con conta 387 {suf}", f"con.{suf}@example.test", tipo_negocio="comercio")
        con.plan = "pos"; con.extras = json.dumps(["contabilidad"]); s.add(con)
        s.commit(); s.refresh(sin); s.refresh(con)
        u = auth.Usuario(correo=correo, nombre="SA menu QA", password_hash=auth.hash_password("Clave-larga-387-menu"), es_superadmin=True,
                         mfa_activo=True, terminos_version=auth.TERMINOS_VERSION, paleta="turquesa")
        s.add(u); s.commit(); s.refresh(u)
        r_sin = auth._respuesta(s, u, sin.id)
        r_con = auth._respuesta(s, u, con.id)
        r_consola = auth._respuesta(s, u, None)
        ids = (sin.id, con.id)
    try:
        p = set(r_sin["permisos"])
        assert not ({"contabilidad", "rrhh", "reportes", "tike"} & p), p             # lo que el plan pos_basico no trae
        assert {"ver_todo", "pos", "configurar", "catalogos", "gastos", "usuarios"} <= p  # todo lo demás, como el Administrador
        info = next(e for e in r_sin["empresas"] if e["id"] == ids[0])
        assert "contabilidad" not in info["plan"]["modulos"]
        assert {"contabilidad", "reportes"} <= set(r_con["permisos"])                   # con el extra, vuelve
        assert r_consola["permisos"] == []                                              # sin empresa: la interfaz da todo por esAdmin
        c = TestClient(app)
        cuerpo = {"datos": [{"id": 1, "cuenta": "1-01", "nombre": "Caja"}]}
        r = c.put("/api/registros/catalogo", headers={"Authorization": "Bearer " + r_sin["token"]}, json=cuerpo)
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_modulo", r.text   # la escritura que la interfaz ya no intenta
        assert c.put("/api/registros/catalogo", headers={"Authorization": "Bearer " + r_con["token"]}, json=cuerpo).status_code == 200
    finally:
        with Session(engine) as s:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            for x in s.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == u.id)).all():
                s.delete(x)
            s.delete(u)
            for eid in ids:
                s.delete(s.get(Empresa, eid))
            s.commit()


def test_sesion_puede_respeta_el_plan_tambien_para_el_administrador_del_sistema():
    js = _js("app.js")
    assert "puede(p) { if (this.esAdmin && !(this.empresa_id && this.permisos.length)) return true; return this.permisos.includes(p); }," in js
    assert "puede(p) { return this.esAdmin || this.permisos.includes(p); }" not in js
    fis = _js("fis", "sesion.js")                                       # Ventas en línea usa el mismo criterio
    assert "puede(p) { if (this.esAdmin && !(this.empresa_id && this.permisos.length)) return true; return this.permisos.includes(p); }," in fis
    # el catálogo contable se siembra solo con puede('contabilidad'), que ahora ya trae el plan
    assert "if (sesion.puede('contabilidad')) {" in _js("pages", "contabilidad", "catalogo.js")


def test_entrada_por_rol():
    js = _js("app.js")
    assert "if (this.puede('seguridad') && this.tieneModulo('hotel_completo')) return '/hotel/seguridad';" in js
    assert "if ((this.tipo === 'comercio' || this.tipo === 'restaurante') && this.puede('pos')) return '/pos/caja';" in js
    assert "if (!this.puede('facturar') && !this.puede('cobros')) { const r = ['/tike/tablero', '/rrhh/empleados'].find(x => rutaPermitidaDe(this, x)); if (r) return r; }" in js
    # el rol sugerido de Servicios no factura ni cobra: entra a TiKe
    assert auth.ROLES_POR_TIPO["servicios"][0][0] == "Técnico de soporte" and auth.ROLES_POR_TIPO["servicios"][0][2] == ["tike"]


def test_tarjeta_de_acceso_denegado_da_una_sola_causa():
    js = _js("app.js")
    i = js.index('<div v-if="page && !permitida" class="page">')
    tarjeta = js[i:js.index("Ir al inicio</a>", i)]
    assert "{{otroTipo ? 'No disponible en su versión' : sinModulo ? 'No incluido en su plan' : 'Sin acceso'}}" in tarjeta
    # una sola cadena v-if / v-else-if / v-else: versión, plan, rol (antes el v-else del rol colgaba solo de otroTipo)
    # 4.7: una causa más en la misma cadena: rol con Recursos humanos sin la verificación en dos pasos (candado)
    assert re.findall(r'<p class="muted" (v-[a-z-]+)', tarjeta) == ["v-if", "v-else-if", "v-else-if", "v-else"]
    assert "sesion.rrhhConCandado && path.startsWith('/rrhh')" in tarjeta
    assert tarjeta.index('v-if="otroTipo"') < tarjeta.index('v-else-if="sinModulo"') < tarjeta.index("Su rol no tiene acceso")


def test_reglas_del_menu():
    m = _js("menu.js")
    assert "['/tike', 'tike', true]" in m and "['/inventario/gestion', 'catalogos', true]" in m              # ver_todo no abre TiKe ni importar
    assert "['rrhh', 'facturar', 'pos', 'configurar', 'tike'].includes(it.permiso)" in m
    assert "{ label: 'Importar y actualizar ítems', to: '/inventario/gestion', permiso: 'catalogos' }" in m
    assert "{ label: 'Ingresos', ico: '↗', permisos: ['facturar', 'cobros', 'ver_todo'], children: [" in m
    assert "{ ...fis('express-pendientes', 'Express pendientes'), tipos: ['restaurante'], modulo: 'entregas' }" in m
    assert "{ ...fis('delivery', 'Zonas de envío'), modulo: 'entregas' }" in m
    assert "const CLAVES_CAJA = ['pedidos', 'express-pendientes'];" in m
    assert "(c.permiso === 'pos' && (!c.clave || CLAVES_CAJA.includes(c.clave)))" in m
    assert "if (l === 'Contabilidad' && tipo !== 'facturacion' && tipo !== 'servicios') return conta(tipo === 'hospitalidad');" in m
    # los enlaces de Ítems › Más acciones a la pantalla de importar, solo con catálogos
    items = _js("pages", "inventario", "items.js")
    assert items.count('v-if="puede(\'catalogos\')" style="display:block;padding:8px 10px;text-decoration:none;color:inherit" href="#/inventario/gestion"') == 2
    # «0 ítems actualizados» en verde ya no sale cuando no se guardó ninguno
    g = _js("pages", "inventario", "gestion.js")
    assert "if (ok) { this.masivo = false; toast(ok + ' ítems actualizados'" in g and "toast(ok + ' ítems actualizados', 'ok');" not in g


def test_inicio_no_pide_el_resumen_a_quien_no_lo_ve():
    ini = _js("pages", "inicio.js")
    assert "veResumen() { return sesion.puede('reportes') || sesion.puede('ver_todo'); }," in ini
    assert "if (this.veResumen) {" in ini and "} else this.r = null;" in ini
    assert '<div class="erp-page-tools" v-if="veResumen">' in ini and '<div class="dash" v-if="r || !veResumen">' in ini
    assert "if (sesion.inicio !== '/inicio') { this.cargando = false; return; }" in ini              # montada un instante al saltar de pantalla
    assert "if (sesion.puede('ver_todo')) api('/api/ia/config')" in ini                               # /api/ia/resumen exige ver_todo
    # mismo criterio que el servidor (main.py, GET /api/resumen)
    main = (RAIZ / "main.py").read_text(encoding="utf-8")
    assert 'if not (ctx.puede("reportes") or ctx.puede("ver_todo")):            # Solo lectura también lo ve (R131)' in main


def test_portada_mas_liviana():
    ini = _js("pages", "inicio.js")
    assert "from './hotel/_datos.js'" not in ini and "import('./hotel/_datos.js')" in ini               # el hotel solo en Hospitalidad
    assert "if (sesion.tipo === 'hospitalidad') import('./hotel/_datos.js')" in ini
    # las alertas salen junto con el resumen, no después
    i = ini.index("async cargar() {")
    cuerpo = ini[i:ini.index("    },", i)]
    assert cuerpo.index("api('/api/inicio/alertas')") < cuerpo.index("api('/api/resumen?")
    html = (RAIZ / "static" / "app" / "index.html").read_text(encoding="utf-8")
    assert '<link rel="modulepreload" href="/js/iconos.js">' in html and '<link rel="modulepreload" href="/js/menu.js">' in html
    assert planes.MODULOS  # el módulo de planes sigue importando
