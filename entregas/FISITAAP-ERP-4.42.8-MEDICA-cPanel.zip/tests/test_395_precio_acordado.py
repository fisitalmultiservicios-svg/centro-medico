# -*- coding: utf-8 -*-
"""3.95: precio acordado (fijo) por empresa: el administrador del sistema elige los paquetes y pone el precio; la empresa lo ve en
su plan y es el monto del cobro con tarjeta. Pagan el Administrador, el Avanzado y el Contador."""
import types

from fastapi import HTTPException
import pytest

from app import planes, suscripcion


def _empresa(**k):
    base = {"plan": "pos_basico", "extras": '["pedidos_online"]', "tipo_negocio": "comercio", "habitaciones": 0, "cajas": 0, "docs_extra": 0,
            "limite_usuarios": 0, "vence": None, "plan_inicio": None, "prueba_hasta": None, "es_demo": False, "funciones": None, "modulos_ocultos": None,
            "precio_acordado": None, "precio_acordado_nota": ""}
    base.update(k)
    return types.SimpleNamespace(**base)


def test_precio_de_lista_y_precio_acordado():
    e = _empresa()
    lista = suscripcion.monto_plan(e)
    assert lista["sin_iva"] == 19900 and not lista.get("acordado")          # 9.900 + Ventas en línea 10.000
    planes.asignar(e, {"plan": "pos_basico", "extras": ["pedidos_online", "rrhh"], "precio_acordado": 15000, "precio_acordado_nota": "Paquete perfumería"})
    m = suscripcion.monto_plan(e)
    assert m["acordado"] is True and m["sin_iva"] == 15000 and m["total"] == 16950 and m["nombre"] == "Paquete perfumería"
    assert planes.info(e)["precio_acordado"] == 15000
    planes.asignar(e, {"plan": "pos_basico", "extras": ["pedidos_online"], "precio_acordado": None})      # vacío = vuelve a la lista
    assert not suscripcion.monto_plan(e).get("acordado") and e.precio_acordado is None
    with pytest.raises(HTTPException):
        planes.asignar(e, {"plan": "pos_basico", "extras": [], "precio_acordado": -5})


def _ctx(perms):
    return types.SimpleNamespace(puede=lambda p: p in perms)


def test_quien_paga_el_plan():
    admin = {"usuarios", "ver_todo", "escribir", "configurar"}
    avanzado = {"ver_todo", "escribir", "facturar"}
    contador = {"ver_todo", "escribir", "contabilidad"}
    for perms in (admin, avanzado, contador):
        suscripcion._puede_pagar(_ctx(perms))
    for perms in ({"ver", "ver_todo"}, {"ver", "escribir", "facturar", "pos"}, {"ver", "pos"}):      # Solo lectura, Vendedor, Cajero
        with pytest.raises(HTTPException):
            suscripcion._puede_pagar(_ctx(perms))
