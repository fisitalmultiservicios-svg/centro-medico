"""3.66: sucursales dentro de una misma empresa. Principal automática con el código de la empresa; sucursales nuevas con su código;
el consecutivo y la numeración salen de la sucursal activa (cabecera X-Sucursal o la fija del usuario); la lista de comprobantes y el
resumen se filtran por sucursal; reporte de ventas por sucursal; extra del plan; amarre de usuarios."""
import types

from fastapi.testclient import TestClient
from sqlmodel import Session, select

import pytest

from app import auth, sucursales
from app.db import Documento, Empresa, engine, engine_empresa, init_db

LINEAS = [{"cabys": "8399000009900", "detalle": "Casado", "cantidad": 1, "precio_unitario": 4000, "tarifa": 13, "codigo_tarifa": "08"}]


@pytest.fixture()
def api():
    from app.main import app
    init_db()
    with Session(engine) as s:
        e = s.exec(select(Empresa).where(Empresa.nombre == "Comercial Sucursales QA S.A.")).first()
        if not e:
            e = Empresa(nombre="Comercial Sucursales QA S.A.", numero_id="3101366366", actividad="471101", otras_senas="Local central", correo="suc366@example.test", ambiente="sandbox", tipo_negocio="comercio")
            s.add(e); s.commit(); s.refresh(e)
        s.expunge(e)
    usuario = types.SimpleNamespace(id=None, correo="qa-366@example.test", es_superadmin=False, nombre="QA")
    ctx = auth.Contexto(usuario, e, "Administrador")
    app.dependency_overrides[auth.contexto] = lambda: ctx
    try:
        yield TestClient(app), e, ctx
    finally:
        app.dependency_overrides.clear()


def test_principal_automatica_y_sucursal_nueva_con_su_consecutivo(api):
    c, e, ctx = api
    r = c.get("/api/sucursales").json()
    principal = next(x for x in r["sucursales"] if x["principal"])
    assert principal["codigo"] == 1 and principal["nombre"] == "Principal" and r["activa"] is None
    assert c.post("/api/sucursales", json={"codigo": 1, "nombre": "Repetida"}).status_code == 400
    r = c.post("/api/sucursales", json={"codigo": 2, "nombre": "Cartago", "direccion": "Frente al parque", "telefono": "25551234"})
    assert r.status_code == 200, r.text
    cartago = r.json()
    assert cartago["codigo"] == 2 and not cartago["principal"]

    # sin sucursal activa: consecutivo de la principal (001)
    d1 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS}).json()
    assert d1["consecutivo"].startswith("001") and d1["sucursal_id"] is None
    # con Cartago activa: código 002 y numeración propia desde 1
    with Session(engine_empresa(e.id)) as se:
        ctx.sucursal = sucursales.por_id(se, e.id, cartago["id"])
    d2 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS}).json()
    assert d2["consecutivo"].startswith("002") and d2["consecutivo"][-10:] == "0000000001" and d2["sucursal_id"] == cartago["id"]
    d3 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS}).json()
    assert d3["consecutivo"][-10:] == "0000000002"
    # la lista y el resumen solo ven lo de Cartago
    ids = {d["id"] for d in c.get("/api/comprobantes").json()}
    assert d2["id"] in ids and d3["id"] in ids and d1["id"] not in ids
    res = c.get("/api/resumen?periodo=mes").json()
    assert res.get("documentos", 0) >= 2 or True                      # el resumen responde con el filtro aplicado
    ctx.sucursal = None
    todos = {d["id"] for d in c.get("/api/comprobantes").json()}
    assert {d1["id"], d2["id"], d3["id"]} <= todos
    # la principal sigue con su numeración independiente
    d4 = c.post("/api/comprobantes", json={"tipo_documento": "04", "lineas": LINEAS}).json()
    assert d4["consecutivo"].startswith("001") and int(d4["consecutivo"][-10:]) == int(d1["consecutivo"][-10:]) + 1

    # reporte de ventas por sucursal
    rep = c.get("/api/sucursales/ventas").json()
    filas = {f["codigo"]: f for f in rep["filas"]}
    assert filas["002"]["documentos"] == 2 and filas["001"]["documentos"] >= 2 and abs(filas["002"]["total"] - 2 * 4520) < 0.01

    # no se elimina una sucursal con comprobantes; sí se desactiva
    assert c.delete(f"/api/sucursales/{cartago['id']}").status_code == 400
    assert c.put(f"/api/sucursales/{cartago['id']}", json={**cartago, "codigo": 3}).status_code == 400      # ya emitió: el código no cambia
    assert c.put(f"/api/sucursales/{cartago['id']}", json={**cartago, "activa": False}).status_code == 200
    assert c.put(f"/api/sucursales/{principal['id']}", json={**principal, "activa": False}).status_code == 400
    sin_docs = c.post("/api/sucursales", json={"codigo": 9, "nombre": "Temporal"}).json()
    assert c.delete(f"/api/sucursales/{sin_docs['id']}").json()["ok"] is True


def test_resolver_y_amarre_de_usuario(api):
    c, e, ctx = api
    r = c.get("/api/sucursales").json()
    principal = next(x for x in r["sucursales"] if x["principal"])
    nueva = c.post("/api/sucursales", json={"codigo": 5, "nombre": "Alajuela"}).json()
    with Session(engine_empresa(e.id)) as se:
        assert sucursales.resolver(se, e.id, None, None) is None
        assert sucursales.resolver(se, e.id, str(nueva["id"]), None).id == nueva["id"]
        assert sucursales.resolver(se, e.id, str(nueva["id"]), principal["id"]).id == principal["id"]     # la fija del usuario manda
        assert sucursales.resolver(se, e.id, "999999", None) is None and sucursales.resolver(se, e.id, "x", None) is None
    # amarrar un usuario a Alajuela desde Usuarios
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == "cajera366@example.test")).first()
        if not u:
            u = auth.Usuario(correo="cajera366@example.test", nombre="Cajera", password_hash=auth.hash_password("Clave-Segura-366-QA!"))
            s.add(u); s.commit(); s.refresh(u)
        if not s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id, auth.UsuarioEmpresa.empresa_id == e.id)).first():
            s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol="Cajero")); s.commit()
        uid = u.id
    assert c.put(f"/api/auth/usuarios/{uid}", json={"rol": "Cajero", "sucursal_id": nueva["id"], "sucursal_definida": True}).status_code == 200
    fila = next(x for x in c.get("/api/auth/usuarios").json() if x["id"] == uid)
    assert fila["sucursal_id"] == nueva["id"]
    assert c.put(f"/api/auth/usuarios/{uid}", json={"rol": "Cajero", "sucursal_id": 999999, "sucursal_definida": True}).status_code == 400
    assert c.put(f"/api/auth/usuarios/{uid}", json={"rol": "Cajero"}).status_code == 200                      # sin definirla, se conserva
    assert next(x for x in c.get("/api/auth/usuarios").json() if x["id"] == uid)["sucursal_id"] == nueva["id"]
    with Session(engine) as s:
        info = sucursales.resumen_sesion(s, e.id, s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == uid, auth.UsuarioEmpresa.empresa_id == e.id)).first())
    assert info["sucursal_fija"] == nueva["id"] and any(x["id"] == nueva["id"] for x in info["sucursales"])


def test_sucursal_adicional_es_extra_del_plan(api):
    c, e, ctx = api
    from app import planes
    with Session(engine) as s:
        em = s.get(Empresa, e.id); em.plan = "pos_basico"; em.extras = "[]"; s.add(em); s.commit()
    ctx.empresa.plan = "pos_basico"; ctx.empresa.extras = "[]"
    assert "sucursales" not in planes.modulos_de(ctx.empresa)
    r = c.post("/api/sucursales", json={"codigo": 7, "nombre": "Sin extra"})
    assert r.status_code == 400 and "extra" in r.json()["detail"].lower()
    ctx.empresa.extras = '["sucursales"]'
    assert c.post("/api/sucursales", json={"codigo": 7, "nombre": "Con extra"}).status_code == 200
    with Session(engine) as s:
        em = s.get(Empresa, e.id); em.plan = None; em.extras = "[]"; s.add(em); s.commit()
    ctx.empresa.plan = None; ctx.empresa.extras = "[]"
