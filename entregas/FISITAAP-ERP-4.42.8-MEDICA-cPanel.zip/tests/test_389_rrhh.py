# -*- coding: utf-8 -*-
"""3.89: avisos de la planilla del SPEC de RRHH que no cambian montos: salario bajo la base mínima contributiva de la CCSS
y parámetros de referencia de otro año."""
import pathlib

from app import rrhh

P = rrhh.parametros_efectivos(None)
EMP = {"id": 1, "nombre": "Ana", "fecha_ingreso": "2021-03-15", "jornada": "diurna", "modo_salario": "hora", "salario_hora": 2500, "categoria": "TOSC", "hijos": 0}


def test_aviso_de_base_minima_contributiva_sin_cambiar_montos():
    normal = rrhh.calcular_nomina(EMP, P, "mensual")
    assert normal["bajo_base_minima"] is False and normal["base_minima"] == 333328
    medio = {**EMP, "jornada": "medio_tiempo", "salario_hora": 1500}           # 4 h × 30 días × ₡1.500 = ₡180.000 al mes
    r = rrhh.calcular_nomina(medio, P, "mensual")
    assert r["bajo_base_minima"] is True
    sin = rrhh.calcular_nomina(medio, {**P, "base_minima": {}}, "mensual")
    assert sin["bajo_base_minima"] is False
    assert r["total_obrero"] == sin["total_obrero"] and r["neto"] == sin["neto"]     # solo avisa: el cálculo no cambia


def test_planilla_dice_el_anio_de_los_parametros_y_la_pantalla_avisa():
    res = rrhh.calcular_planilla([{"empleado": EMP}], P, "mensual")
    assert res["anio_parametros"] == 2026
    js = (pathlib.Path(rrhh.__file__).parent / "static/js/pages/rrhh/planilla.js").read_text(encoding="utf-8")
    assert "avisosCalculo" in js and "res.anio_parametros" in js     # 4.7: el aviso de base mínima de la fila lo da el servidor (avisos)
