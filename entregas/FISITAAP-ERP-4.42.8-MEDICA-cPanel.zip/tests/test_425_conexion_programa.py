# -*- coding: utf-8 -*-
"""4.25 (tanda 6, X1b, lado del PROGRAMA): conectar esta computadora con la cuenta de la web y retiro de las cuentas locales.

El programa pide un pase a la web con el sha256 de un secreto que vive solo en su memoria, sondea, muestra la empresa y quién aprobó,
pide «Sí, es mi empresa» con el número de comprobación que muestra la página (E-1, E-4) y aplica la instalación con el candado del ciclo
de sincronización (E-9). Las cuentas creadas en la computadora dejan de entrar en cuanto su empresa se vinculó (E-13) y las rutas que
crean cuentas responden 403 «solo_web» en el programa real (FE_MODO_LOCAL=1), salvo en modo soporte (FE_LOCAL_ADMIN=1).

Nube y computadora corren en el MISMO proceso y comparten la tabla de usuarios: la recogida trae a la administradora de la «nube» con
el hash inservible, pero ella ya tiene un hash utilizable y E-11 solo le actualiza el rol y el bloqueo (su contraseña no cambia). Las
pruebas apagan el hilo de sondeo (sinc.HILO_CONEXION) y dan los pasos con la ruta de estado; «sin estrenar» se sustituye (la base
compartida tiene sesiones de otras pruebas) y la computadora «solo ve» las empresas creadas en cada prueba."""
import json
import logging
import secrets
import time
from datetime import datetime, timezone
from types import SimpleNamespace

import httpx
import pytest
from sqlmodel import Session, SQLModel, create_engine, select

from app import auth, sinc
from app.db import Auditoria, Empresa, engine, engine_empresa
from test_49_local_sinc import NUBE, PW, H, _admin_empresa, _cfg, _modo_local_ingreso, _poner_cfg, _Respuesta, _vincular, c
from test_425_conexion_nube import _aprobar, _limpiar_limitador, _pase, _poner_pase, _vinc

_BASE = [0]
_BORRAR: list = []                   # correos de usuarios que esta prueba crea y no deben quedar (administradores del sistema)
REVOCADA = _Respuesta(403, {"detail": {"codigo": sinc.CODIGO_REVOCADA, "mensaje": "Esta instalación fue revocada"}})


def _soltar_programa() -> None:
    sinc._conexiones.clear()
    sinc._VINC_ALGUNA.clear()
    with auth._lock_ip:
        for k in [k for k in auth._intentos_ip if k.startswith("conexion_local:")]:
            auth._intentos_ip.pop(k, None)


@pytest.fixture(autouse=True)
def _limpieza():
    _limpiar_limitador()
    _soltar_programa()
    with Session(engine) as sc:
        _BASE[0] = max([e.id for e in sc.exec(select(Empresa)).all()] or [0])
    yield
    _soltar_programa()
    _limpiar_limitador()
    with Session(engine) as sc:
        nuevas = [e.id for e in sc.exec(select(Empresa).where(Empresa.id > _BASE[0])).all()]
        for correo in _BORRAR:
            u = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()
            if u is not None:
                for m in sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id)).all():
                    sc.delete(m)
                sc.delete(u)
        sc.commit()
    _BORRAR.clear()
    for eid in nuevas:                       # otras pruebas buscan empresas vinculadas en la base compartida
        try:
            with Session(engine_empresa(eid)) as s:
                cfg = sinc._cfg_local(s, eid)
                if cfg.get("vinculado"):
                    cfg.update({"vinculado": False, "token": None})
                    sinc._escribir(s, eid, sinc.CLAVE_LOCAL, cfg); s.commit()
        except Exception:  # noqa: BLE001
            pass
        sinc._fijas.pop(eid, None); sinc._inst_estado.pop(eid, None)
        from app import modulos
        modulos._rangos.pop(eid, None)


def _programa(monkeypatch, sin_estrenar: bool = True, retencion: int = 0):
    """El programa (sinc.MODO_LOCAL, httpx a la nube simulada, URL_NUBE = NUBE) sin hilos; sin_estrenar sustituye a _sin_estrenar; la
    computadora solo ve como «vacías» las empresas creadas en esta prueba."""
    shim = _modo_local_ingreso(monkeypatch)
    monkeypatch.setattr(sinc, "HILO_CONEXION", False)
    monkeypatch.setattr(sinc, "INTERVALO_LOCAL", 0)
    monkeypatch.setattr(sinc, "SEGUNDOS_RETENCION", retencion)
    monkeypatch.setattr(sinc, "_version_sistema", lambda: "4.25")
    if sin_estrenar:
        monkeypatch.setattr(sinc, "_sin_estrenar", lambda sc: True)
    real, base = sinc._vacias, _BASE[0]
    monkeypatch.setattr(sinc, "_vacias", lambda sc: [e for e in real(sc) if e.id > base])
    return shim


def _iniciar(nombre: str = "Caja 1", cab=None):
    return c.post("/api/sinc/local/conexion/iniciar", headers=cab or {}, json={"nombre": nombre})


def _estado(intento: str, cab=None):
    return c.post("/api/sinc/local/conexion/estado", headers=cab or {}, json={"intento": intento})


def _confirmar(intento: str, numero: str, es_mia: bool = True, cab=None):
    return c.post("/api/sinc/local/conexion/confirmar", headers=cab or {}, json={"intento": intento, "numero": numero, "es_mia": es_mia})


def _llamadas(shim, ruta: str) -> list:
    return [x for x in shim.llamadas if x[1] == ruta]


def _membresias(eid: int) -> list:
    with Session(engine) as sc:
        return sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == eid)).all()


def _usuario(correo: str):
    with Session(engine) as sc:
        return sc.exec(select(auth.Usuario).where(auth.Usuario.correo == correo)).first()


def _vivas(eid_nube: int) -> list:
    """Las instalaciones de conexión de la empresa de la nube con su token sin revocar."""
    salida = []
    with Session(engine) as sc:
        for i in _vinc(eid_nube).get("instalaciones", []):
            t = sc.get(auth.TokenApi, int(i.get("token_id") or 0))
            if t is not None and not t.revocado:
                salida.append(i)
    return salida


def _conectar(monkeypatch, shim, ta: str, eid_nube: int, cab=None, nombre: str = "Caja 1") -> dict:
    """Camino completo desde el programa: iniciar, aprobar en la web, confirmar con el número. Devuelve la vista final."""
    r = _iniciar(nombre, cab)
    assert r.status_code == 200, r.text
    j = r.json()
    a = _aprobar(ta, j["codigo"], eid_nube).json()
    assert a.get("estado") == "aprobado", a
    v = _estado(j["intento"], cab).json()
    assert v["estado"] == "confirmar", v
    v = _confirmar(j["intento"], a["numero"], cab=cab).json()
    assert v["estado"] == "lista", v
    return {**v, "intento": j["intento"], "codigo": j["codigo"], "numero": a["numero"]}


# ------------------------------------------------------------------------------------------------------------- funciones puras
def test_misma_computadora_funcion_pura(monkeypatch):
    def req(cliente, **cab):
        return SimpleNamespace(client=SimpleNamespace(host=cliente), url=SimpleNamespace(scheme="http"),
                               headers={k.replace("_", "-"): v for k, v in cab.items()})
    assert sinc._misma_computadora(req("127.0.0.1", host="127.0.0.1:8020")) is True
    assert sinc._misma_computadora(req("::1", host="[::1]:8020", origin="http://[::1]:8020", sec_fetch_site="same-origin")) is True
    assert sinc._misma_computadora(req("127.0.0.1", host="localhost:8020", sec_fetch_site="none")) is True
    # desde otra dirección, aunque diga X-Forwarded-For: 127.0.0.1 (el programa no lee cabeceras de proxy)
    assert sinc._misma_computadora(req("192.168.1.20", host="127.0.0.1:8020", x_forwarded_for="127.0.0.1")) is False
    assert sinc._misma_computadora(req("192.168.1.20", host="192.168.1.20:8020")) is False
    assert sinc._misma_computadora(req("127.0.0.1", host="evil.example:8020")) is False              # página ajena que apunta a 127.0.0.1
    assert sinc._misma_computadora(req("127.0.0.1", host="127.0.0.1:8020", origin="http://evil.example")) is False
    assert sinc._misma_computadora(req("127.0.0.1", host="127.0.0.1:8020", origin="http://127.0.0.1:9999")) is False
    assert sinc._misma_computadora(req("127.0.0.1", host="127.0.0.1:8020", sec_fetch_site="cross-site")) is False
    assert sinc._misma_computadora(req("127.0.0.1")) is False                                          # sin Host
    # el cliente de las pruebas vale solo dentro de las pruebas
    assert sinc._misma_computadora(req("testclient", host="testserver")) is True
    monkeypatch.delenv(sinc.VAR_PRUEBAS)
    assert sinc._misma_computadora(req("testclient", host="testserver")) is False


def test_sin_estrenar_funcion_pura():
    """Base temporal propia: sin nadie; con una empresa vacía; con un miembro que no puede entrar (hash inservible); con uno que sí; con
    una sesión abierta alguna vez (o un ingreso en la auditoría)."""
    e2 = create_engine("sqlite://")
    SQLModel.metadata.create_all(e2, tables=[auth.Usuario.__table__, auth.UsuarioEmpresa.__table__, auth.Sesion.__table__, Auditoria.__table__])
    with Session(e2) as sc:
        assert sinc._sin_estrenar(sc) is True
        u = auth.Usuario(correo="a@example.test", nombre="A", password_hash=sinc.HASH_INSERVIBLE, de_nube=True)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=1, rol="Administrador")); sc.commit()
        assert sinc._sin_estrenar(sc) is True                              # nadie puede entrar todavía
        u.password_hash = auth.hash_password(PW); sc.add(u); sc.commit()
        assert sinc._sin_estrenar(sc) is False
        u.password_hash = sinc.HASH_INSERVIBLE; sc.add(u); sc.commit()
        sc.add(Auditoria(accion="login", usuario_id=u.id)); sc.commit()
        assert sinc._sin_estrenar(sc) is False                             # alguien entró alguna vez
    with Session(e2) as sc:
        for a in sc.exec(select(Auditoria)).all():
            sc.delete(a)
        sc.add(auth.Sesion(sid="s-1", usuario_id=1)); sc.commit()
        assert sinc._sin_estrenar(sc) is False


# --------------------------------------------------------------------------------------------------------------- conexión
def test_computadora_sin_estrenar_inicia_espera_confirma_y_queda_conectada(monkeypatch, caplog):
    caplog.set_level(logging.DEBUG)
    eid_n, ta = _admin_empresa("-cp1", "3101425601")
    duena = "duena-sinc49-cp1@example.test"
    hash_antes = _usuario(duena).password_hash
    shim = _programa(monkeypatch)
    respuestas = []
    r = _iniciar("Caja 1")
    assert r.status_code == 200, r.text
    j = r.json(); respuestas.append(r.text)
    assert set(j) == {"intento", "codigo", "segundos", "vence", "url", "web"} and j["url"] == NUBE + "/app/#/conectar?c=" + j["codigo"]
    st = sinc._conexiones[j["intento"]]
    secreto = st["secreto"]
    ini = _llamadas(shim, "/api/sinc/conexion/iniciar")[-1][2]
    assert "secreto" not in ini and ini["secreto_hash"] == sinc._hash(secreto) and ini["cedula"] is None and ini["nombre"] == "Caja 1"
    v = _estado(j["intento"]); respuestas.append(v.text)
    assert v.status_code == 200 and v.json()["estado"] == "esperando"
    a = _aprobar(ta, j["codigo"], eid_n).json()
    numero = a["numero"]
    v = _estado(j["intento"]); respuestas.append(v.text)
    v = v.json()
    assert v["estado"] == "confirmar" and v["empresa"]["numero_id"] == "3101425601" and v["aprobo"]["correo"] == duena and "numero" not in v
    antes = len(_vivas(eid_n))
    r = _confirmar(j["intento"], numero); respuestas.append(r.text)
    v = r.json()
    assert v["estado"] == "lista" and v["bajada"] is False and "Listo" in v["mensaje"], v
    eid_l = v["empresa_id"]
    assert eid_l != eid_n and eid_l > _BASE[0]
    cfg = _cfg(eid_l)
    assert cfg["vinculado"] and cfg["url"] == NUBE and cfg["origen"] == "conexion" and cfg["aprobo"] == duena
    mids = [m.id for m in _membresias(eid_l)]
    assert cfg["primera"] == {"membresias": mids} and len(mids) == 1
    assert _usuario(duena).password_hash == hash_antes                      # E-11: su hash utilizable no se toca
    assert len(_vivas(eid_n)) == antes + 1
    with Session(engine) as sc:
        e = sc.get(Empresa, eid_l)
        assert e.numero_id == "3101425601" and e.terminal == cfg["terminal"]
        fila = sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid_l, Auditoria.accion == "sinc_local_vinculada")).first()
        assert fila is not None and "aprobada en la página web por " + duena in fila.detalle and fila.correo == duena
        auditoria = " ".join(str(x.detalle) for x in sc.exec(select(Auditoria).where(Auditoria.empresa_id.in_([eid_l, eid_n]))).all())
    from app import modulos                                                  # la empresa nace sin plantillas (sin tipo de negocio)
    with Session(engine_empresa(eid_l)) as s:
        assert not modulos.leer(s, eid_l, "pos_cajas", []) and not modulos.leer(s, eid_l, "cuentas", [])
    token = sinc.secretos.descifrar(e.clave_cifrada, cfg["token"])
    # nada de secretos en las respuestas al navegador, el registro ni la auditoría
    for texto in respuestas + [caplog.text, auditoria, json.dumps(cfg)]:
        assert secreto not in texto and token not in texto
    assert all(k not in json.dumps(sinc._vista(st)) for k in ("secreto", "token", "credenciales"))
    assert st["secreto"] is None and st["j"] is None and st["numero"] is None


def test_iniciar_desde_otra_direccion_o_con_host_u_origin_ajenos(monkeypatch):
    _programa(monkeypatch)
    for cab in ({"Host": "evil.example"}, {"Origin": "http://evil.example"}, {"Sec-Fetch-Site": "cross-site"}):
        r = _iniciar("Caja", cab)
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "otra_computadora", (cab, r.text)
    assert not sinc._conexiones
    # con usuarios que ya pueden entrar hace falta sesión con «configurar»
    eid, tok = _admin_empresa("-cp2", "3101425602")
    monkeypatch.setattr(sinc, "_sin_estrenar", lambda sc: False)
    assert _iniciar("Caja").status_code == 401
    with Session(engine) as sc:
        u = auth.Usuario(correo="cajera-cp2@example.test", nombre="Cajera", password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol="Cajero")); sc.commit()
        tc = auth._respuesta(sc, u, eid)["token"]
    assert _iniciar("Caja", H(tc)).status_code == 403
    # en la web las rutas del programa no existen
    monkeypatch.setattr(sinc, "MODO_LOCAL", False)
    assert _iniciar("Caja", H(tok)).status_code == 404


def test_no_es_mi_empresa_no_crea_instalacion(monkeypatch):
    eid_n, ta = _admin_empresa("-cp3", "3101425603")
    _programa(monkeypatch)
    with Session(engine) as sc:
        empresas = len(sc.exec(select(Empresa)).all())
    antes = len(_vinc(eid_n).get("instalaciones", []))
    j = _iniciar().json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    assert _estado(j["intento"]).json()["estado"] == "confirmar"
    v = _confirmar(j["intento"], "", es_mia=False).json()
    assert v["estado"] == "cancelada" and "no recibió nada" in v["mensaje"]
    assert _pase(id=a["pase"]).estado == "cancelado"
    assert len(_vinc(eid_n).get("instalaciones", [])) == antes
    with Session(engine) as sc:
        assert len(sc.exec(select(Empresa)).all()) == empresas
    # un número de otro largo no se manda
    j = _iniciar().json()
    _aprobar(ta, j["codigo"], eid_n)
    _estado(j["intento"])
    assert _confirmar(j["intento"], "12").status_code == 400


def test_numero_errado_y_retencion(monkeypatch):
    eid_n, ta = _admin_empresa("-cp4", "3101425604")
    _programa(monkeypatch, retencion=300)
    j = _iniciar().json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    assert a["retenida"] is True
    v = _estado(j["intento"]).json()
    assert v["estado"] == "retenida" and v["aprobo"]["correo"] == "duena-sinc49-cp4@example.test"
    otro = "100" if a["numero"] != "100" else "101"
    v = _confirmar(j["intento"], otro).json()                              # 9b (U6): durante la retención la web lo revisa en el momento
    assert v["estado"] == "retenida" and v["numero_escrito"] is False and v["error"] and v["intentos_restantes"] == 2
    _poner_pase(a["pase"], retener_hasta=time.time() - 1)
    v = _estado(j["intento"]).json()
    assert v["estado"] == "confirmar" and v["intentos_restantes"] == 2
    v = _confirmar(j["intento"], a["numero"]).json()
    assert v["estado"] == "lista", v


def test_fallo_a_medias_y_reintento_sin_volver_a_la_web(monkeypatch):
    eid_n, ta = _admin_empresa("-cp5", "3101425605")
    shim = _programa(monkeypatch)
    real = sinc._aplicar_usuarios_recogida
    veces = []

    def falla(sc, eid, j):
        veces.append(eid)
        if len(veces) == 1:
            raise OSError("disco lleno")
        return real(sc, eid, j)
    monkeypatch.setattr(sinc, "_aplicar_usuarios_recogida", falla)
    antes = len(_vivas(eid_n))
    j = _iniciar().json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    _estado(j["intento"])
    v = _confirmar(j["intento"], a["numero"]).json()
    assert v["estado"] == "fallo" and "Reintentar" in v["mensaje"], v
    st = sinc._conexiones[j["intento"]]
    eid_l = st["eid_destino"]
    assert st["j"] is not None and eid_l
    recogidas = len(_llamadas(shim, "/api/sinc/conexion/recoger"))
    v = c.post("/api/sinc/local/conexion/reintentar", json={"intento": j["intento"]}).json()
    assert v["estado"] == "lista" and v["empresa_id"] == eid_l, v
    assert len(_llamadas(shim, "/api/sinc/conexion/recoger")) == recogidas      # sin volver a la web
    assert veces == [eid_l, eid_l]
    with Session(engine) as sc:
        assert len(sc.exec(select(Empresa).where(Empresa.numero_id == "3101425605", Empresa.id > _BASE[0], Empresa.id != eid_n)).all()) == 1
    assert len(_vivas(eid_n)) == antes + 1                                   # una sola instalación viva en la nube
    assert _cfg(eid_l)["primera"]["membresias"]
    with Session(engine) as sc:
        assert sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid_l, Auditoria.accion == "sinc_local_conexion_fallida")).first() is not None


def test_ciclo_con_el_token_viejo_no_marca_revocada_la_conexion_nueva(monkeypatch):
    eid_n, ta = _admin_empresa("-cp6n", "3101425606")
    eid_l, tl = _admin_empresa("-cp6l", "3101425606")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    viejo = _cfg(eid_l)["token"]
    with Session(engine) as sc:
        e = sc.get(Empresa, eid_l)
        nuevo = sinc.secretos.cifrar(e.clave_cifrada, "fcr_" + secrets.token_urlsafe(32))
    real = shim.post

    def post(url, headers=None, json=None, timeout=None):  # noqa: A002
        if url.endswith("/api/sinc/usuarios"):
            _poner_cfg(eid_l, token=nuevo)                                  # mientras tanto se aplicó otra conexión (otro token)
            return REVOCADA                                                 # y la web revocó el viejo
        return real(url, headers=headers, json=json, timeout=timeout)
    shim.post = post
    sinc.sincronizar(eid_l)
    cfg = _cfg(eid_l)
    assert cfg["token"] == nuevo and not cfg.get("revocada_en") and cfg["vinculado"]
    # sin otra conexión de por medio, la misma respuesta sí la marca revocada
    _poner_cfg(eid_l, token=viejo)
    shim.post = real
    shim.por_ruta["/api/sinc/usuarios"] = REVOCADA
    sinc.sincronizar(eid_l)
    assert _cfg(eid_l).get("revocada_en")


def test_reconexion_con_sesion_conserva_hash_y_pin_y_su_revocacion_no_borra_membresias(monkeypatch):
    eid_n, ta = _admin_empresa("-cp7n", "3101425607")
    eid_l, tl = _admin_empresa("-cp7l", "3101425617")
    shim = _programa(monkeypatch, sin_estrenar=False)
    # una cajera que ya entraba en esta computadora (hash y PIN utilizables) y es miembro de la empresa de la nube
    correo = "cajera-cp7@example.test"
    with Session(engine) as sc:
        u = auth.Usuario(correo=correo, nombre="Cajera", password_hash=auth.hash_password(PW), pin_hash=auth.hash_password("4827"), de_nube=True,
                         terminos_version=auth.TERMINOS_VERSION)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_n, rol="Cajero"))
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_l, rol="Cajero")); sc.commit()
    antes = _usuario(correo)
    miembros = sorted(m.id for m in _membresias(eid_l))
    v = _conectar(monkeypatch, shim, ta, eid_n, cab=H(tl))
    assert v["empresa_id"] == eid_l
    despues = _usuario(correo)
    assert despues.password_hash == antes.password_hash and despues.pin_hash == antes.pin_hash
    assert sorted(m.id for m in _membresias(eid_l)) == miembros               # en una reconexión no se aplican los usuarios de la recogida
    cfg = _cfg(eid_l)
    assert cfg["origen"] == "conexion" and "primera" not in cfg
    # otra persona (otra sesión) no ve el intento
    assert _estado(v["intento"], H(ta)).status_code in (403, 410)
    # la web la revoca antes de la primera bajada: camino de siempre (revocada y 3 días), sin borrar membresías
    shim.por_ruta["/api/sinc/usuarios"] = REVOCADA
    sinc.sincronizar(eid_l)
    cfg = _cfg(eid_l)
    assert cfg.get("revocada_en") and cfg["vinculado"] and sorted(m.id for m in _membresias(eid_l)) == miembros


def test_revocar_una_primera_conexion_la_deshace_y_deja_reintentar(monkeypatch):
    eid_n, ta = _admin_empresa("-cp8", "3101425608")
    shim = _programa(monkeypatch)
    v = _conectar(monkeypatch, shim, ta, eid_n)
    eid_l = v["empresa_id"]
    cfg = _cfg(eid_l)
    terminal, mids = cfg["terminal"], cfg["primera"]["membresias"]
    shim.por_ruta["/api/sinc/usuarios"] = REVOCADA
    sinc.sincronizar(eid_l)
    cfg = _cfg(eid_l)
    assert cfg["vinculado"] is False and cfg["token"] is None and cfg["terminal"] == terminal and "primera" not in cfg and not cfg.get("revocada_en")
    with Session(engine) as sc:
        assert all(sc.get(auth.UsuarioEmpresa, m) is None for m in mids)
        assert sc.exec(select(Auditoria).where(Auditoria.empresa_id == eid_l, Auditoria.accion == "sinc_local_conexion_deshecha")).first() is not None
    # se puede conectar de nuevo: manda su cédula y su terminal, y vuelve a la misma empresa local y a la misma terminal
    shim.por_ruta.clear()
    _soltar_programa()
    _limpiar_limitador()
    v2 = _conectar(monkeypatch, shim, ta, eid_n)
    ini = _llamadas(shim, "/api/sinc/conexion/iniciar")[-1][2]
    rec = [x[2] for x in _llamadas(shim, "/api/sinc/conexion/recoger") if x[2].get("confirmar")][-1]
    assert ini["cedula"] == "3101425608" and rec["terminal_anterior"] == terminal
    assert v2["empresa_id"] == eid_l and _cfg(eid_l)["terminal"] == terminal and _cfg(eid_l)["vinculado"]


def test_ingreso_con_el_hash_sin_bajar_dice_que_esta_bajando_y_no_suma_fallos(monkeypatch):
    eid_n, ta = _admin_empresa("-cp9", "3101425609")
    correo = "nuevo-cp9@example.test"
    with Session(engine) as sc:                                             # una persona de la web que todavía no entró en esta computadora
        u = auth.Usuario(correo=correo, nombre="Nuevo", password_hash=sinc.HASH_INSERVIBLE, terminos_version=auth.TERMINOS_VERSION)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_n, rol="Cajero")); sc.commit()
    shim = _programa(monkeypatch)
    v = _conectar(monkeypatch, shim, ta, eid_n)
    eid_l = v["empresa_id"]
    u = _usuario(correo)
    assert u.de_nube and u.password_hash == sinc.HASH_INSERVIBLE
    with Session(engine) as sc:
        assert sc.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.usuario_id == u.id, auth.UsuarioEmpresa.empresa_id == eid_l)).first()
    real = sinc._vinculadas
    monkeypatch.setattr(sinc, "_vinculadas", lambda: [x for x in real() if x[0] == eid_l])
    shim.por_ruta["/api/sinc/ingreso"] = httpx.ConnectError("sin red")
    for _ in range(6):
        r = c.post("/api/auth/login", json={"correo": correo, "password": "Cualquier-Clave-2026"})
        assert r.status_code == 503 and r.json()["detail"] == sinc.MENSAJE_BAJANDO, r.text
    with Session(engine) as sc:
        assert not sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave.in_(("login_fallo", "login_cuenta")), auth.IntentoIp.ip.endswith(correo))).all()
    # después de la primera bajada buena (sin la marca): 9b (D-R) sin internet dice el motivo (403 SIN_VALIDAR_AQUI), sin contar fallo
    _poner_cfg(eid_l, primera=None)
    assert c.post("/api/auth/login", json={"correo": correo, "password": "Cualquier-Clave-2026"}).json()["detail"] == sinc.SIN_VALIDAR_AQUI


# ----------------------------------------------------------------------------------------------------------------- cuentas
def _cuenta_local(eid: int, nombre: str, rol: str = "Cajero", **campos) -> tuple:
    correo = f"{nombre}@example.test"
    with Session(engine) as sc:
        u = auth.Usuario(correo=correo, nombre=nombre, password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION,
                         terminos_fecha=datetime.now(timezone.utc), **campos)
        sc.add(u); sc.commit(); sc.refresh(u)
        if eid:
            sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol=rol)); sc.commit()
        return u.id, correo


def _empresa_local(sufijo: str, cedula: str, vinculada: bool) -> int:
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "Local425 QA" + sufijo, f"local425{sufijo}@example.test", cedula)
        eid = e.id
    if vinculada:
        _poner_cfg(eid, terminal=7)
    return eid


def test_cuenta_local_con_la_empresa_vinculada_no_entra_y_en_modo_soporte_si(monkeypatch):
    vinc = _empresa_local("-c10a", "3101425610", True)
    libre = _empresa_local("-c10b", "3101425611", False)
    uid, correo = _cuenta_local(vinc, "cajera-local-c10")
    _, correo2 = _cuenta_local(libre, "cajera-libre-c10")
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "cuenta_local" and "token" not in r.json(), r.text
    with Session(engine) as sc:
        # 4.25 (6b, R6): acción propia en el Historial (antes «login_rechazado», que se lee «cuenta bloqueada»)
        fila = sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == "login_cuenta_local").order_by(Auditoria.id.desc())).first()
        assert fila is not None and "creada solo en esta computadora" in fila.detalle
    assert c.post("/api/auth/login", json={"correo": correo2, "password": PW}).status_code == 200   # su empresa nunca se vinculó
    monkeypatch.setenv("FE_LOCAL_ADMIN", "1")
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 200, r.text
    tok = r.json()["token"]
    assert c.get("/api/auth/yo", headers=H(tok)).status_code == 200
    monkeypatch.delenv("FE_LOCAL_ADMIN")
    assert c.get("/api/auth/yo", headers=H(tok)).status_code == 401         # la sesión que quedó abierta se cierra
    with Session(engine) as sc:
        assert not sc.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid, auth.Sesion.revocada == False)).all()  # noqa: E712
    # el administrador del sistema de esta computadora: no entra si alguna empresa se vinculó alguna vez
    _, adm = _cuenta_local(0, "admin-local-c10", es_superadmin=True, admin_principal=True)
    _BORRAR.append(adm)
    assert auth._cuenta_local_retirada(Session(engine), _usuario(adm)) is True
    monkeypatch.delenv("FE_MODO_LOCAL")                                     # en la web, nada cambia
    assert c.post("/api/auth/login", json={"correo": correo, "password": PW}).status_code == 200


def test_cierre_de_sesiones_al_vincular_y_al_arrancar(monkeypatch):
    vinc = _empresa_local("-c11", "3101425612", True)
    uid, correo = _cuenta_local(vinc, "cajera-c11")
    with Session(engine) as sc:
        tok = auth._respuesta(sc, sc.get(auth.Usuario, uid), vinc)["token"]
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    monkeypatch.setattr(sinc, "MODO_LOCAL", True)
    sinc._cuentas_al_arrancar()
    with Session(engine) as sc:
        assert not sc.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid, auth.Sesion.revocada == False)).all()  # noqa: E712
    assert c.get("/api/auth/yo", headers=H(tok)).status_code == 401
    # con FE_LOCAL_ADMIN=1 queda en la auditoría
    monkeypatch.setenv("FE_LOCAL_ADMIN", "1")
    sinc._cuentas_al_arrancar()
    with Session(engine) as sc:
        assert sc.exec(select(Auditoria).where(Auditoria.accion == "sinc_local_modo_soporte")).first() is not None


def test_token_de_persona_de_una_cuenta_local(monkeypatch):
    vinc = _empresa_local("-c12", "3101425613", True)
    uid, correo = _cuenta_local(vinc, "admin-c12", rol="Administrador")
    token = "fcr_" + secrets.token_urlsafe(32)
    with Session(engine) as sc:
        t = auth.TokenApi(empresa_id=vinc, usuario_id=uid, nombre="Integración QA", prefijo=token[:12], hash=auth._hash_token_api(token), permisos='["ver"]')
        sc.add(t); sc.commit(); sc.refresh(t); tid = t.id
    assert c.get("/api/auth/roles", headers=H(token)).status_code == 200    # en la web funciona
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    r = c.get("/api/auth/roles", headers=H(token))
    assert r.status_code in (401, 403), r.text
    with Session(engine) as sc:
        assert sc.get(auth.TokenApi, tid).revocado is True
    assert c.get("/api/auth/roles", headers=H(token)).status_code == 401    # quedó revocado
    r = c.post("/api/auth/tokens-api", json={"nombre": "Otro", "permisos": ["ver"]})
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "solo_web"


def test_admin_local_con_el_mismo_correo_que_manda_la_nube_se_convierte(monkeypatch):
    eid = _empresa_local("-c13", "3101425614", True)
    uid, correo = _cuenta_local(0, "admin-c13", es_superadmin=True, admin_principal=True, mfa_activo=True, mfa_secret="x")
    _BORRAR.append(correo)
    with Session(engine) as sc:
        sc.add(auth.Sesion(sid="sid-c13-" + secrets.token_hex(4), usuario_id=uid)); sc.commit()
    ficha = {"correo": correo, "nombre": "Admin C13", "password_hash": sinc.HASH_INSERVIBLE, "pin_hash": None, "bloqueado": False,
             "terminos_version": auth.TERMINOS_VERSION, "paleta": None, "rol": "Administrador", "sucursal_id": None, "modulos_ocultos": None,
             "mfa": "", "mfa_entrar": False, "mfa_rrhh": False, "temporal": False}
    # fuera del programa real (y en modo soporte) se sigue saltando
    for env in ({}, {"FE_MODO_LOCAL": "1", "FE_LOCAL_ADMIN": "1"}):
        with monkeypatch.context() as m:
            for k, v in env.items():
                m.setenv(k, v)
            with Session(engine) as sc:
                sinc._bajar_usuarios(sc, eid, {"usuarios": [ficha], "roles": []})
        u = _usuario(correo)
        assert u.es_superadmin and not u.de_nube
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    with Session(engine) as sc:
        sinc._bajar_usuarios(sc, eid, {"usuarios": [ficha], "roles": []})
    u = _usuario(correo)
    assert not u.es_superadmin and not u.admin_principal and u.de_nube and not u.mfa_activo and u.mfa_secret is None and u.empresas_ocultas == "[]"
    assert [m.rol for m in _membresias(eid) if m.usuario_id == uid] == ["Administrador"]
    with Session(engine) as sc:
        assert not sc.exec(select(auth.Sesion).where(auth.Sesion.usuario_id == uid, auth.Sesion.revocada == False)).all()  # noqa: E712
        assert sc.exec(select(Auditoria).where(Auditoria.usuario_id == uid, Auditoria.accion == "cuenta_local_convertida")).first() is not None


APAGADAS = [("post", "/api/auth/setup", {"correo": "x@example.test", "password": "x", "nombre": "x"}), ("post", "/api/auth/usuarios", {}),
            ("delete", "/api/auth/usuarios/1", None), ("put", "/api/auth/usuarios/1", {}), ("post", "/api/auth/roles", {}),
            ("put", "/api/auth/roles/1", {}), ("delete", "/api/auth/roles/1", None), ("put", "/api/auth/mfa/politica", {}),
            ("post", "/api/auth/recuperar", {}), ("post", "/api/auth/restablecer", {}), ("post", "/api/auth/tokens-api", {}),
            ("post", "/api/admin/cuentas", {}), ("delete", "/api/admin/cuentas/1", None), ("post", "/api/admin/cuentas/1/tipo", {}),
            ("put", "/api/admin/cuentas/1/funciones", {}), ("post", "/api/admin/cuentas/1/bloqueo", {}), ("post", "/api/admin/cuentas/1/plan", {}),
            ("post", "/api/admin/cuentas/1/pagos", {}), ("post", "/api/admin/cuentas/1/pagos/1/facturar", None),
            ("post", "/api/admin/usuarios/1/bloqueo", {}), ("post", "/api/admin/usuarios/1/password", {}), ("post", "/api/admin/cuentas/1/usuarios", {}),
            ("put", "/api/admin/cuentas/1/usuarios/1/rol", {}), ("delete", "/api/admin/cuentas/1/usuarios/1", None),
            ("post", "/api/admin/administradores", {}), ("delete", "/api/admin/administradores/1", None),
            ("put", "/api/admin/administradores/1/empresas", {}), ("put", "/api/admin/mfa-renuncia", {}),
            ("post", "/api/admin/pruebas", {}), ("post", "/api/admin/demo", {}), ("post", "/api/admin/pruebas/1", {}), ("delete", "/api/admin/pruebas/1", None),
            # 4.35: restablecer desde Usuarios, «Entrar como» del soporte y «Volver a mi cuenta» se hacen en la página web
            ("post", "/api/auth/usuarios/1/password", {}), ("post", "/api/admin/cuentas/1/usuarios/1/entrar-como", None), ("post", "/api/auth/volver", None)]


def _es_solo_web(r) -> bool:
    try:
        d = r.json().get("detail")
    except Exception:  # noqa: BLE001
        return False
    return r.status_code == 403 and isinstance(d, dict) and d.get("codigo") == "solo_web"


def test_rutas_apagadas_en_el_programa_y_iguales_en_la_web(monkeypatch):
    def llamar(metodo, ruta, cuerpo):
        return getattr(c, metodo)(ruta, **({"json": cuerpo} if cuerpo is not None else {}))
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    for metodo, ruta, cuerpo in APAGADAS:
        r = llamar(metodo, ruta, cuerpo)
        assert _es_solo_web(r), (metodo, ruta, r.status_code, r.text)
        assert "Not Found" not in r.text
    r = llamar(*APAGADAS[0])
    assert r.json()["detail"]["mensaje"] == auth.MENSAJE_SOLO_WEB_SETUP
    monkeypatch.setenv("FE_LOCAL_ADMIN", "1")                               # modo soporte: responden como antes
    for metodo, ruta, cuerpo in APAGADAS:
        assert not _es_solo_web(llamar(metodo, ruta, cuerpo)), ruta
    monkeypatch.delenv("FE_LOCAL_ADMIN")
    monkeypatch.delenv("FE_MODO_LOCAL")
    for metodo, ruta, cuerpo in APAGADAS:
        assert not _es_solo_web(llamar(metodo, ruta, cuerpo)), ruta
    # revisión de texto: cada decorador de la lista lleva la dependencia
    from pathlib import Path
    raiz = Path(sinc.__file__).parent
    fuentes = {"auth": (raiz / "auth.py").read_text(encoding="utf-8"), "demo": (raiz / "demo.py").read_text(encoding="utf-8")}
    for metodo, ruta, _ in APAGADAS:
        if ruta.startswith("/api/admin/pruebas") or ruta == "/api/admin/demo":
            d = f'@router.{metodo}("{ruta[len("/api/admin"):]}"'.replace("/1", "/{eid}")
            linea = next(x for x in fuentes["demo"].splitlines() if x.startswith(d + ",") or x.startswith(d + ")"))
            assert "Depends(_solo_web())" in linea, linea
            continue
        pref, r = ("@router", ruta[len("/api/auth"):]) if ruta.startswith("/api/auth") else ("@admin", ruta[len("/api/admin"):])
        r = r.replace("/usuarios/1", "/usuarios/{uid}").replace("/roles/1", "/roles/{rid}").replace("/cuentas/1", "/cuentas/{eid}")
        r = r.replace("/pagos/1", "/pagos/{pid}").replace("/administradores/1", "/administradores/{uid}")
        d = f'{pref}.{metodo}("{r}"'
        linea = next(x for x in fuentes["auth"].splitlines() if x.startswith(d + ",") or x.startswith(d + ")"))
        assert "Depends(solo_web)" in linea, linea
    s = (raiz / "sitio.py").read_text(encoding="utf-8")
    assert "and not auth._es_local()" in s


def test_estado_trae_el_bloque_local_solo_en_el_programa(monkeypatch):
    assert "local" not in c.get("/api/auth/estado").json()
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    monkeypatch.setattr(sinc, "URL_NUBE", NUBE)
    j = c.get("/api/auth/estado").json()["local"]
    assert set(j) == {"nueva", "vinculada", "admin_local", "web", "pagina", "equipo"} and j["web"] == "nube49" and j["admin_local"] is False and j["equipo"]
    monkeypatch.setenv("FE_LOCAL_ADMIN", "1")
    assert c.get("/api/auth/estado").json()["local"]["admin_local"] is True
    assert c.get("/api/auth/estado", headers={"Origin": "http://evil.example"}).json()["local"]["equipo"] is None


def test_vincular_con_codigo_ya_no_pide_direccion(monkeypatch):
    eid_n, ta = _admin_empresa("-c15n", "3101425615")
    eid_l, tl = _admin_empresa("-c15l", "3101425616")
    _programa(monkeypatch, sin_estrenar=False)
    codigo = c.post("/api/sinc/codigo", headers=H(ta), json={"nombre": "Caja"}).json()["codigo"]
    with monkeypatch.context() as m:
        m.setattr(sinc, "sincronizar", lambda eid: None)
        r = c.post("/api/sinc/local/vincular", headers=H(tl), json={"codigo": codigo, "nombre": "Caja"})
    assert r.status_code == 200, r.text
    assert _cfg(eid_l)["url"] == NUBE
    # en el programa real una dirección distinta se ignora: la llamada va a URL_NUBE (el simulador solo acepta NUBE). Nube y programa
    # comparten el proceso: con FE_MODO_LOCAL=1 la ruta del canje de la «nube» contestaría 404, así que su respuesta se fuerza.
    shim = sinc.httpx
    shim.por_ruta["/api/sinc/canje"] = _Respuesta(400, {"detail": "Código inválido o vencido: genere otro en la nube"})
    with monkeypatch.context() as m:
        m.setattr(sinc, "sincronizar", lambda eid: None)
        m.setenv("FE_MODO_LOCAL", "1")
        m.setenv("FE_LOCAL_ADMIN", "1")
        r = c.post("/api/sinc/local/vincular", headers=H(tl), json={"url": "https://otra.example", "codigo": "L1-AAAA", "nombre": "Caja"})
    assert r.status_code == 400 and "rechazó el código" in r.text, r.text
    assert shim.llamadas[-1][1] == "/api/sinc/canje"


def test_intento_perdido_y_cancelar(monkeypatch):
    eid_n, ta = _admin_empresa("-c16", "3101425618")
    _programa(monkeypatch)
    j = _iniciar().json()
    secreto_hash = sinc._hash(sinc._conexiones[j["intento"]]["secreto"])
    assert c.post("/api/sinc/local/conexion/cancelar", json={"intento": j["intento"]}).json() == {"ok": True}
    assert _pase(secreto_hash=secreto_hash).estado == "cancelado"
    r = _estado(j["intento"])
    assert r.status_code == 410 and r.json()["detail"]["codigo"] == "intento_perdido"
    # el programa se reinició a medias: la memoria se perdió; aprobar después no crea ninguna instalación
    j = _iniciar().json()
    sinc._conexiones.clear()
    antes = len(_vinc(eid_n).get("instalaciones", []))
    _aprobar(ta, j["codigo"], eid_n)
    assert _estado(j["intento"]).status_code == 410
    assert len(_vinc(eid_n).get("instalaciones", [])) == antes
