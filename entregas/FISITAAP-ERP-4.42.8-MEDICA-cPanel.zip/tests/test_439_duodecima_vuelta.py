# -*- coding: utf-8 -*-
"""4.39, duodécima vuelta de los arreglos (17 nov 2026): «Pedidos web» en la caja. Una prueba por cada cambio, con los métodos reales de
caja.js en Node: la ventana «Pedidos web» (abrirPanelWeb … soltarCuentaCanceladaWeb), el resumen (revisarOnline, avisarEntrados y
sonarPedido) y el sincronizar real, con su bandera (`sincronizando`: mientras uno está en curso, otro sale sin traer nada), contra un
servidor falso de pedidos y de la lista de cuentas en el que cada respuesta se puede retener («puertas»: lo que trae se calcula al
pedirlo, como en el servidor, y llega cuando la prueba suelta la puerta).

- W1 aceptarWeb (programa): si se sabe que no sale comanda (el botón dice «Aceptar pedido»: sin impresora de comanda, en una tienda o en
  una caja que no imprime comandas), el aviso es «Pedido #N aceptado: ya está en la caja.» en vez del mensaje del servidor, que dice que
  la comanda sale sola. Con impresora de cocina (o si no se pudo saber), el mensaje del servidor, como antes.
- W2 imprimirComandaWeb (programa y página web) y cancelarWeb: si la consulta del resumen llegó mientras se aceptaba o cancelaba (todavía
  contaba el pedido como nuevo), al terminar se vuelve a leer el resumen y el botón «Pedidos web» queda en 0 (antes quedaba en 1 hasta la
  consulta siguiente). Sin consulta en medio, baja en el acto y sin otra lectura.
- W3 avisarEntrados (programa): el piso sube cuando la cuenta del tope está en la lista traída (o a los 6 intentos), como en la 4.38. El
  #106 (pagado con tarjeta) entra y aquí se acepta el #107; el resumen con ultimo_entrado_id = 7 llega con un sincronizar en curso (el de
  aceptarWeb o el de cada 15 s): cuando la lista trae las dos cuentas, el #106 avisa una vez y el #107 nunca (antes el piso subía con el
  #107 marcado como avisado, con la lista atrasada, y el #106 se quedaba sin aviso). La primera respuesta del resumen conserva lo aceptado
  aquí (antes lo olvidaba y el pedido aceptado antes de la primera respuesta avisaba una vez). Los casos de tests/test_432_pantallas_caja.py
  siguen igual.
Cada caso que muestra el defecto corre también con los métodos de ANTES de esta vuelta: se sacan de caja.js con la duodécima vuelta deshecha
(DUODECIMA y _caja_sin_duodecima de tests/test_439_tercera_vuelta.py, comprobado byte a byte contra la copia de caja.js de antes de la vuelta).
4.39 (decimotercera vuelta): el contrato compara la duodécima vuelta contra caja.js sin la decimotercera (DECIMOTERCERA y _caja_sin_decimotercera de
tests/test_439_tercera_vuelta.py: la decimotercera metió una línea en aceptarWeb); la frase de Técnico de la duodécima y la lista de pruebas, que
reescribió la decimotercera, pasaron a su contrato, en tests/test_439_decimotercera_vuelta.py.
Nada va a una impresora, a la red ni a un servidor de verdad. Solo correos @example.test."""
import json

import pytest

from tests.test_431_misma_mesa_pantallas import RAIZ, _metodo
from tests.test_432_caja_pedidos_web import _computadas, _metodos, _node, _tramo
from tests.test_439_revision_arreglos import _caja
from tests.test_439_tercera_vuelta import DUODECIMA, _caja_sin_decimotercera, _caja_sin_duodecima

# los métodos que cambió la duodécima vuelta (cada tripleta de DUODECIMA está en uno de ellos)
CAMBIADOS = ("async aceptarWeb(p) {", "async imprimirComandaWeb(p) {", "async cancelarWeb(p) {", "async avisarEntrados(r) {")
# el método de cada tripleta de DUODECIMA, en orden
DE_CADA = ("async aceptarWeb(p) {", "async imprimirComandaWeb(p) {", "async imprimirComandaWeb(p) {", "async cancelarWeb(p) {",
           "async avisarEntrados(r) {", "async avisarEntrados(r) {")
SERVIDOR_41 = "Pedido #41 aceptado: ya está en la caja y su comanda sale sola en unos segundos."   # app/pedidos_programa.py, TEXTO_ACEPTADO
EN_LA_CAJA_41 = "Pedido #41 aceptado: ya está en la caja."
CANCELADO_41 = "Pedido #41 cancelado. El cliente ve el motivo."
NUEVO = "Entró un pedido en línea: tóquelo en «🌐 Pedidos web» para verlo."
ENTRO = "Entró a la caja el pedido en línea #{}."
PROG = {"es_local": True, "pedidos_programa": True}

ARNES = r"""
// ---- el servidor falso: los pedidos, las cuentas en espera (la lista de la caja) y ultimo_entrado_id; cada respuesta se calcula al pedirla y,
// si su puerta está cerrada, llega cuando la prueba la suelta (resumen, put: aceptar o cancelar, lista: la lista de cuentas de sincronizar)
const Q = { toasts: [], todos: [], sonidos: 0, local: [], llamadas: [], resumenes: 0, refrescos: 0, puerta: {}, s0: 0, r0: 0 };
const cerrar = n => { let abrir; Q.puerta[n] = new Promise(r => { abrir = r; }); return () => { Q.puerta[n] = null; abrir(); }; };
const S = { pedidos: [], espera: [], entrado: 0 };
const cta = (pid, num) => ({ id: 900 + pid, nombre: 'Pedido #' + num + ' · Cliente QA', canal: 'online', pedido_id: pid, pedido_numero: num, lineas: [] });
const entra = p => { if (!S.espera.some(v => v.pedido_id === p.id)) S.espera.push(cta(p.id, p.numero)); S.entrado = Math.max(S.entrado, p.id); };
const pedido = (id, numero, estado) => ({ id, numero, estado, nombre: 'Cliente QA', correo: 'cliente@example.test', lineas: [] });
const sesion = { empresaInfo: @INFO@, tipo: 'restaurante', tieneModulo: m => m === 'pedidos_online' };
const api = async (url, op) => {
  Q.llamadas.push(((op && op.method) || 'GET') + ' ' + url);
  if (url === '/api/pedidos/resumen') {
    Q.resumenes++;
    const r = { nuevos: S.pedidos.filter(p => p.estado === 'nuevo').length, ultimo_id: Math.max(0, ...S.pedidos.map(p => p.id)), ultimo_entrado_id: S.entrado };
    if (Q.puerta.resumen) await Q.puerta.resumen;
    return r;
  }
  if (url === '/api/pedidos') return S.pedidos.map(p => ({ ...p }));
  const e = /^\/api\/pedidos\/(\d+)\/estado$/.exec(url);
  if (e) {
    if (Q.puerta.put) await Q.puerta.put;
    const p = S.pedidos.find(x => x.id === +e[1]); p.estado = op.body.estado;
    if (p.estado === 'cancelado') { S.espera = S.espera.filter(v => v.pedido_id !== p.id); return { id: p.id, numero: p.numero, estado: p.estado }; }
    entra(p);   // aceptado: su cuenta entra a la caja (en el programa, app/pedidos_programa.py manda siempre TEXTO_ACEPTADO)
    return { id: p.id, numero: p.numero, estado: p.estado, ...(sesion.empresaInfo.pedidos_programa ? { mensaje: 'Pedido #' + p.numero + ' aceptado: ya está en la caja y su comanda sale sola en unos segundos.' } : {}) };
  }
  if (url === '/api/clientes') return [];
  throw new Error('ruta ' + url);
};
const toast = (m, t) => { Q.toasts.push(m); Q.todos.push(m); };
const win = { AudioContext: function () { Q.sonidos++; throw new Error('sin audio en la prueba'); } };
// mock.refrescar: la lista de cuentas tal como estaba en el servidor al pedirla; llega cuando se suelta la puerta «lista»
const mock = { cargado: true, pendientes: 0, async refrescar() { Q.refrescos++; const foto = JSON.parse(JSON.stringify(S.espera)); if (Q.puerta.lista) await Q.puerta.lista; Q.local = foto; return true; } };
// las impresoras y las cajas de esta computadora (imprimeProgWeb) y lo demás que toman de sus módulos los métodos de la prueba
let IMPS = [{ id: 1, nombre: 'Cocina', uso: 'comanda' }], TS = [{ id: 1, modo: 'restaurante' }];
Object.assign(globalThis, { impresoras: () => IMPS, terminales: () => TS, promos: () => [], store: { clientes: [] }, uuid: () => 'u', lidsDeBase: () => new Set(), cajaPorId: () => null, cajaAbierta: () => null });
const K = new Function('sesion', 'api', 'toast', 'enEspera', 'window', 'mock', 'return { computed: {' + @COMP@ + '}, methods: {' + @MET@ + '} };')(sesion, api, toast, () => Q.local, win, mock);
// en la página web, «Imprimir comanda» usa la lógica de Ventas en línea › Pedidos (aquí, una que acepta con el mismo PUT: la cuenta entra a la caja)
const acep = { menu: true, impresion: { cfg: {}, impresoras: [] }, conComanda: true, async preparar() {}, async aceptarComo(p) { await api('/api/pedidos/' + p.id + '/estado', { method: 'PUT', body: { estado: 'confirmado' } }); return true; } };
function caja() {
  const vm = { online: { nuevos: 0, ultimo: null, sinVer: 0 }, panelWeb: null, esperaCaja: [], espera: [], esperaId: null, lineas: [], pago: null, cobrando: false, cobroParcial: null,
    caja: null, cfg: null, promosLista: [], sync: 0, _est: null, sincronizando: false, esRestaurante: true, recuperar() {} };
  for (const [k, f] of Object.entries(K.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm), configurable: true });
  for (const [k, f] of Object.entries(K.methods)) vm[k] = f.bind(vm);
  vm.cargarAceptador = async () => { vm._acep = acep; return acep; };
  return vm;
}
const pasar = async () => { for (let i = 0; i < 40; i++) await new Promise(r => setImmediate(r)); };
const vuelta = async vm => { await vm.revisarOnline(); await pasar(); };   // una consulta del resumen (la de cada 10 s en el programa)
const abrir = async vm => { vm.abrirPanelWeb(); for (let i = 0; i < 100 && (vm.panelWeb.cargando || vm.panelWeb.listo === false); i++) await pasar(); };
// desde aquí: los avisos, cuántas veces sonó, el número del botón «Pedidos web» (avisoWeb) y cuántas consultas del resumen hubo
const marca = () => { Q.toasts = []; Q.s0 = Q.sonidos; Q.r0 = Q.resumenes; };
const ver = vm => ({ avisos: Q.toasts.slice(), sonidos: Q.sonidos - Q.s0, boton: vm.avisoWeb, resumenes: Q.resumenes - Q.r0 });
const entraron = () => Q.todos.filter(t => t.startsWith('Entró a la caja'));
const out = {};
"""


def _fuente(antes=False) -> str:
    """Los métodos de la prueba: la ventana «Pedidos web», el resumen y el sincronizar real; con `antes`, los que cambió esta vuelta como estaban
    antes de ella (van al final y pisan a los de ahora)."""
    k = _caja()
    met = _metodos() + _tramo(k, "    async revisarOnline() {", "\n    // 3.87:") + "\n    " + _metodo(k, "async sincronizar() {") + ",\n"
    if antes:
        k0 = _caja_sin_duodecima()
        for c in CAMBIADOS:
            met += "    " + _metodo(k0, c) + ",\n"
    return met


def _correr(tmp_path, escenario, antes=False, info=None):
    guion = (ARNES.replace("@INFO@", json.dumps(PROG if info is None else info)).replace("@COMP@", json.dumps(_computadas()))
             .replace("@MET@", json.dumps(_fuente(antes))) + escenario + "\nconsole.log(JSON.stringify(out));\nprocess.exit(0);\n")
    tmp_path.mkdir(parents=True, exist_ok=True)
    return _node(tmp_path, guion)


# ================================================================================================================ W1: «Aceptar pedido» en el programa
CASOS_W1 = r"""
// en el programa, el #41 (nuevo) se acepta con el botón de la ventana; `prep` pone las impresoras, las cajas y el tipo de negocio de esta computadora
async function w1(prep) {
  IMPS = [{ id: 1, nombre: 'Cocina', uso: 'comanda' }]; TS = [{ id: 1, modo: 'restaurante' }]; sesion.tipo = 'restaurante'; prep();
  S.pedidos = [pedido(41, 41, 'nuevo')]; S.espera = []; S.entrado = 40; Q.llamadas = [];
  const vm = caja(); await abrir(vm); const imprime = vm.panelWeb.imprime, boton = vm.textoImprimirWeb;
  marca(); await vm.imprimirComandaWeb(vm.panelWeb.lista[0]); await pasar();
  return { imprime, boton, avisos: Q.toasts.slice(), estado: S.pedidos[0].estado, cuentas: S.espera.map(v => v.pedido_id), llamadas: Q.llamadas.filter(x => x.startsWith('PUT')) };
}
out.sin_impresora = await w1(() => { IMPS = []; });
out.tienda = await w1(() => { sesion.tipo = 'comercio'; TS = [{ id: 1, modo: 'mostrador' }]; });
out.caja_sin_comanda = await w1(() => { TS = [{ id: 1, modo: 'restaurante', imprimir_comanda: false }]; });
out.cocina = await w1(() => {});
out.no_se_sabe = await w1(() => { TS = []; });
"""


def test_w1_aceptar_pedido_sin_comanda_no_dice_que_la_comanda_sale_sola_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W1)
    for k in ("sin_impresora", "tienda", "caja_sin_comanda"):
        x = r[k]
        # se sabe que no sale comanda: el botón dice «Aceptar pedido» y el aviso ya no dice que la comanda sale sola; el pedido queda aceptado y su
        # cuenta entra a la caja, con un solo PUT
        assert x["imprime"] is False and x["boton"] == "Aceptar pedido" and x["avisos"] == [EN_LA_CAJA_41], (k, x)
        assert x["estado"] == "confirmado" and x["cuentas"] == [41] and x["llamadas"] == ["PUT /api/pedidos/41/estado"], (k, x)
    # con la impresora de cocina activa (sale comanda) y cuando no se pudo saber (sin cajas guardadas), el mensaje del servidor, como antes
    assert r["cocina"]["imprime"] is True and r["cocina"]["boton"] == "Imprimir comanda" and r["cocina"]["avisos"] == [SERVIDOR_41], r["cocina"]
    assert r["no_se_sabe"]["imprime"] is None and r["no_se_sabe"]["boton"] == "Imprimir comanda" and r["no_se_sabe"]["avisos"] == [SERVIDOR_41], r["no_se_sabe"]
    for k in ("cocina", "no_se_sabe"):
        assert r[k]["estado"] == "confirmado" and r[k]["cuentas"] == [41] and r[k]["llamadas"] == ["PUT /api/pedidos/41/estado"], (k, r[k])

    # antes de esta vuelta: con «Aceptar pedido» el aviso decía que la comanda sale sola (no sale: no hay impresora de comanda, es una tienda o la caja
    # no imprime comandas); lo demás, igual
    v = _correr(tmp_path / "antes", CASOS_W1, antes=True)
    for k in ("sin_impresora", "tienda", "caja_sin_comanda"):
        assert v[k]["boton"] == "Aceptar pedido" and v[k]["avisos"] == [SERVIDOR_41] and v[k]["cuentas"] == [41], (k, v[k])
    assert v["cocina"] == r["cocina"] and v["no_se_sabe"] == r["no_se_sabe"], v


# ================================================================================================================ W2: el resumen llega mientras se acepta o cancela
CASOS_W2 = r"""
// el #41 entra (nuevo: el botón en 1); se abre «Pedidos web» y se acepta («Imprimir comanda» o «Aceptar pedido») o se cancela, con el PUT retenido.
// Con `medio`, mientras tanto llega una consulta del resumen (calculada antes del PUT: todavía con nuevos 1). Después se suelta el PUT
async function w2(accion, medio) {
  S.pedidos = [pedido(40, 40, 'entregado')]; S.espera = []; S.entrado = 40; Q.local = [];
  const vm = caja(); await vuelta(vm);
  S.pedidos.push(pedido(41, 41, 'nuevo'));
  marca(); await vuelta(vm); const alEntrar = ver(vm);
  await abrir(vm); const p = vm.panelWeb.lista.find(x => x.id === 41);
  marca(); const suelta = cerrar('put');
  let hecho;
  if (accion === 'aceptar') hecho = vm.imprimirComandaWeb(p);
  else { vm.verPedidoWeb(p); vm.abrirCancelarWeb(); vm.panelWeb.cancelar.motivo = 'El cliente llamó para cancelar'; hecho = vm.cancelarWeb(p); }
  await pasar();
  let durante = null;
  if (medio) { await vm.revisarOnline(); await pasar(); durante = vm.avisoWeb; }
  suelta(); await hecho; const alTerminar = vm.avisoWeb;
  await pasar();
  return { alEntrar, durante, alTerminar, ...ver(vm), estado: S.pedidos[1].estado, entraron: entraron() };
}
for (const lado of ['prog', 'web']) {
  sesion.empresaInfo = lado === 'prog' ? { es_local: true, pedidos_programa: true } : {};
  for (const accion of ['aceptar', 'cancelar']) for (const medio of [true, false]) { Q.todos = []; out[lado + '_' + accion + (medio ? '_medio' : '')] = await w2(accion, medio); }
}
"""
# lo que avisa cada caso al terminar (el programa: el mensaje del servidor, con impresora de cocina; la página web: la lógica de Ventas en línea, aquí
# sin avisos)
AVISO_W2 = {"prog_aceptar": [SERVIDOR_41], "web_aceptar": [], "prog_cancelar": [CANCELADO_41], "web_cancelar": [CANCELADO_41]}


def test_w2_el_resumen_que_llega_mientras_se_acepta_o_cancela_no_deja_el_numero_viejo_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W2)
    for lado in ("prog", "web"):
        for accion in ("aceptar", "cancelar"):
            k = lado + "_" + accion
            m, s = r[k + "_medio"], r[k]
            estado = "confirmado" if accion == "aceptar" else "cancelado"
            assert m["alEntrar"]["avisos"] == [NUEVO] and m["alEntrar"]["boton"] == 1 and m["alEntrar"]["sonidos"] == 1, (k, m)
            # el resumen llegó durante el PUT (todavía con nuevos 1): el botón sigue en 1; al terminar se vuelve a leer (una consulta más que la de en medio)
            # y queda en 0
            assert m["durante"] == 1 and m["boton"] == 0 and m["resumenes"] == 2 and m["estado"] == estado, (k, m)
            assert m["avisos"] == AVISO_W2[k] and m["sonidos"] == 0 and m["entraron"] == [], (k, m)
            # sin resumen en medio: baja en el acto, sin otra consulta
            assert s["alTerminar"] == 0 and s["boton"] == 0 and s["resumenes"] == 0 and s["estado"] == estado, (k, s)
            assert s["avisos"] == AVISO_W2[k] and s["sonidos"] == 0 and s["entraron"] == [], (k, s)

    # antes de esta vuelta: con el resumen en medio, el botón quedaba en 1 (rojo) hasta la consulta siguiente (10 s en el programa, 30 s en la página
    # web); sin resumen en medio, igual que ahora
    v = _correr(tmp_path / "antes", CASOS_W2, antes=True)
    for lado in ("prog", "web"):
        for accion in ("aceptar", "cancelar"):
            k = lado + "_" + accion
            assert v[k + "_medio"]["durante"] == 1 and v[k + "_medio"]["alTerminar"] == 1 and v[k + "_medio"]["boton"] == 1, (k, v[k + "_medio"])
            assert v[k + "_medio"]["resumenes"] == 1, (k, v[k + "_medio"])
            assert v[k] == r[k], (k, v[k])


# ================================================================================================================ W3: el piso de avisarEntrados
CASOS_W3 = r"""
// el programa: la primera respuesta (ultimo_entrado_id = 5); el #107 entra como nuevo; el #106 (pagado con tarjeta: nunca es «nuevo») entra a la caja
// y aquí todavía no se vio. Con la lista de cuentas retenida, aquí se acepta el #107 (`cual`: «aceptar», el sincronizar en curso es el de aceptarWeb; «15s»,
// el de cada 15 s, que empezó antes). El resumen llega con ultimo_entrado_id = 7 mientras ese sincronizar sigue en curso; después llega la lista y
// otras dos consultas
async function w3(cual) {
  S.pedidos = [pedido(5, 105, 'entregado')]; S.espera = []; S.entrado = 5; Q.local = []; Q.todos = [];
  const vm = caja(), pasos = {};
  marca(); await vuelta(vm); pasos.primera = ver(vm);
  S.pedidos.push(pedido(7, 107, 'nuevo'));
  marca(); await vuelta(vm); pasos.nuevo107 = ver(vm);
  S.pedidos.push(pedido(6, 106, 'confirmado')); entra(S.pedidos[2]);
  await abrir(vm);
  const suelta = cerrar('lista');
  if (cual === '15s') { vm.sincronizar(); await pasar(); }
  marca(); await vm.imprimirComandaWeb(vm.panelWeb.lista.find(p => p.id === 7)); await pasar();
  pasos.aceptado = { ...ver(vm), enCurso: vm.sincronizando, estado: S.pedidos[1].estado };
  vm.panelWeb = null;
  marca(); await vuelta(vm); pasos.llega7 = { ...ver(vm), enCurso: vm.sincronizando, lista: Q.local.map(v => v.pedido_id) };
  suelta(); await pasar();
  marca(); await vuelta(vm); pasos.despues = { ...ver(vm), lista: Q.local.map(v => v.pedido_id).sort() };
  marca(); await vuelta(vm); pasos.otra = ver(vm);
  pasos.entraron = entraron(); pasos.avisados = [...(vm._entAvisados || [])].sort();
  return pasos;
}
out.aceptar = await w3('aceptar');
out['15s'] = await w3('15s');
"""
ACEPTADO_107 = "Pedido #107 aceptado: ya está en la caja y su comanda sale sola en unos segundos."


@pytest.mark.parametrize("cual", ["aceptar", "15s"])
def test_w3_el_pedido_que_entro_mientras_se_aceptaba_otro_avisa_una_vez_en_node(tmp_path, cual):
    r = _correr(tmp_path / "ahora", CASOS_W3)[cual]
    assert r["primera"] == {"avisos": [], "sonidos": 0, "boton": 0, "resumenes": 1}, r
    assert r["nuevo107"] == {"avisos": [NUEVO], "sonidos": 1, "boton": 1, "resumenes": 1}, r
    # aceptado aquí: el aviso del servidor, el botón en 0, el sincronizar sigue en curso (la lista no llegó)
    assert r["aceptado"] == {"avisos": [ACEPTADO_107], "sonidos": 0, "boton": 0, "resumenes": 0, "enCurso": True, "estado": "confirmado"}, r
    # el resumen con ultimo_entrado_id = 7 llega con ese sincronizar en curso: el de avisarEntrados sale sin traer nada (la bandera) y la lista sigue
    # atrasada (sin las cuentas del #106 ni del #107): nada que avisar y el piso no sube
    assert r["llega7"] == {"avisos": [], "sonidos": 0, "boton": 0, "resumenes": 1, "enCurso": True, "lista": []}, r
    # llegada la lista, la consulta siguiente trae las dos cuentas: el #106 avisa una vez (suena y suma al botón); el #107, aceptado aquí, no
    assert r["despues"] == {"avisos": [ENTRO.format(106)], "sonidos": 1, "boton": 1, "resumenes": 1, "lista": [6, 7]}, r
    assert r["otra"] == {"avisos": [], "sonidos": 0, "boton": 1, "resumenes": 1}, r
    assert r["entraron"] == [ENTRO.format(106)] and r["avisados"] == [6, 7], r

    # antes de esta vuelta: el piso subía al ver el #107 marcado como avisado (Q5 lo marca al aceptarlo aquí), con la lista atrasada; cuando la lista
    # traía las dos cuentas el #106 ya quedaba debajo del piso: nunca avisaba, ni sonaba, ni sumaba al botón
    # (la lista que queda es la que trajo el sincronizar en curso: con el de cada 15 s, que empezó antes de aceptar, solo la cuenta del #106)
    v = _correr(tmp_path / "antes", CASOS_W3, antes=True)[cual]
    assert v["aceptado"] == r["aceptado"] and v["llega7"] == r["llega7"], v
    lista = [6, 7] if cual == "aceptar" else [6]
    assert v["despues"] == {"avisos": [], "sonidos": 0, "boton": 0, "resumenes": 1, "lista": lista} and v["entraron"] == [] and v["avisados"] == [7], v


CASOS_W3_PRIMERA = r"""
// el programa: la primera consulta del resumen tarda (se calculó con el #107 nuevo y ultimo_entrado_id = 5). Mientras tanto se abre «Pedidos web» y se
// acepta el #107 (su cuenta entra a la caja); después llega esa primera respuesta y dos consultas más (la cuenta del #107 ya está: ultimo_entrado_id = 7)
S.pedidos = [pedido(5, 105, 'entregado'), pedido(7, 107, 'nuevo')]; S.espera = []; S.entrado = 5; Q.local = []; Q.todos = [];
const vm = caja();
const suelta = cerrar('resumen'); const primera = vm.revisarOnline(); await pasar();
await abrir(vm);
marca(); await vm.imprimirComandaWeb(vm.panelWeb.lista.find(p => p.id === 7)); await pasar(); out.aceptado = { ...ver(vm), avisados: [...(vm._entAvisados || [])] };
vm.panelWeb = null;
marca(); suelta(); await primera; await pasar(); out.primera = { ...ver(vm), avisados: [...(vm._entAvisados || [])] };
marca(); await vuelta(vm); out.entro = ver(vm);
marca(); await vuelta(vm); out.otra = ver(vm);
out.entraron = entraron(); out.avisados = [...(vm._entAvisados || [])];
"""


def test_w3_la_primera_respuesta_no_olvida_el_pedido_aceptado_aqui_en_node(tmp_path):
    r = _correr(tmp_path / "ahora", CASOS_W3_PRIMERA)
    # aceptado antes de la primera respuesta: queda anotado como avisado (Q5) y el botón en 0
    assert r["aceptado"] == {"avisos": [ACEPTADO_107], "sonidos": 0, "boton": 0, "resumenes": 0, "avisados": [7]}, r
    # la primera respuesta (calculada antes de aceptar) solo marca desde dónde avisar y conserva lo aceptado aquí (su número, todavía con el #107 nuevo,
    # lo corrige la consulta siguiente: límite aceptado de las respuestas en desorden)
    assert r["primera"]["avisos"] == [] and r["primera"]["sonidos"] == 0 and r["primera"]["avisados"] == [7], r
    # la cuenta del #107 ya está en la caja: no avisa, no suena y el botón queda en 0
    assert r["entro"] == {"avisos": [], "sonidos": 0, "boton": 0, "resumenes": 1} and r["otra"] == {"avisos": [], "sonidos": 0, "boton": 0, "resumenes": 1}, r
    assert r["entraron"] == [] and r["avisados"] == [7], r

    # antes de esta vuelta: la primera respuesta vaciaba lo anotado; cuando la cuenta del #107 entraba a la caja sonaba, avisaba y el botón se volvía a
    # poner rojo (aunque se aceptó aquí)
    v = _correr(tmp_path / "antes", CASOS_W3_PRIMERA, antes=True)
    assert v["aceptado"] == r["aceptado"] and v["primera"]["avisados"] == [], v
    assert v["entro"] == {"avisos": [ENTRO.format(107)], "sonidos": 1, "boton": 1, "resumenes": 1} and v["entraron"] == [ENTRO.format(107)], v


# los casos de tests/test_432_pantallas_caja.py (test_caja_avisa_el_pedido_que_entro_una_vez_y_sin_bandera_como_antes), con su sincronizar falso que
# cuenta las veces: la regla nueva da lo mismo que la de antes de esta vuelta y que la 4.32
CASOS_432 = r"""
const Q = { resp: null, toasts: [], sincs: 0, sonidos: 0, espera: [], llamadas: 0 };
const sesion = { empresaInfo: { es_local: true, pedidos_programa: true }, tieneModulo: m => m === 'pedidos_online' };
const api = async url => { Q.llamadas++; if (url !== '/api/pedidos/resumen') throw new Error('ruta ' + url); return Q.resp; };
const toast = (m, t) => Q.toasts.push(m);
const win = { AudioContext: function () { Q.sonidos++; throw new Error('sin audio en la prueba'); } };
const M = new Function('api', 'toast', 'sesion', 'enEspera', 'window', 'return {' + @FUENTE@ + '};')(api, toast, sesion, () => Q.espera, win);
const vm = { online: { nuevos: 0, ultimo: null }, _est: null, sincronizar: async () => { Q.sincs++; } };
for (const [n, f] of Object.entries(M)) vm[n] = f.bind(vm);
const pasar = async () => { for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r)); };
const vuelta = async resp => { Q.resp = resp; Q.toasts = []; Q.sincs = 0; Q.sonidos = 0; await vm.revisarOnline(); await pasar(); return [Q.toasts.slice(), Q.sincs, Q.sonidos]; };
const cta = (pid, num, extra) => ({ id: 900 + pid, canal: 'online', pedido_id: pid, pedido_numero: num, ...(extra || {}) });
const out = {};
out.primera = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 5 });
Q.espera = [cta(4, 104), cta(5, 105), cta(6, 106), cta(7, 107), cta(7, 107, { id: 999 }), { id: 1, nombre: 'Mesa 1' }];
out.sube = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 7 });
out.igual = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 7 });
out.sin_cuenta = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 9 });
Q.espera.push(cta(9, 109));
out.llega = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 9 });
out.despues = await vuelta({ nuevos: 0, ultimo_id: 0, ultimo_entrado_id: 9 });
out.nuevo = await vuelta({ nuevos: 1, ultimo_id: 3, ultimo_entrado_id: 9 });
sesion.empresaInfo = { es_local: true };
Q.espera.push(cta(12, 112));
out.sin_bandera = await vuelta({ nuevos: 0, ultimo_id: 3, ultimo_entrado_id: 12 });
sesion.empresaInfo = { es_local: true, pedidos_programa: true };
out.sin_campo = await vuelta({ nuevos: 0, ultimo_id: 3 });
console.log(JSON.stringify(out));
process.exit(0);
"""


def test_w3_los_casos_de_la_4_32_siguen_igual_en_node(tmp_path):
    def correr(sub, k):
        fuente = _tramo(k, "    async revisarOnline() {", "\n    // 3.87:")
        (tmp_path / sub).mkdir(parents=True, exist_ok=True)
        return _node(tmp_path / sub, CASOS_432.replace("@FUENTE@", json.dumps(fuente)))
    r = correr("ahora", _caja())
    assert r["primera"] == [[], 0, 0], r
    assert r["sube"] == [[ENTRO.format(106), ENTRO.format(107)], 1, 1], r      # una vez por pedido, un sonido; la cuenta del tope (7) está: el piso sube
    assert r["igual"] == [[], 0, 0], r
    assert r["sin_cuenta"] == [[], 1, 0], r                                     # la cuenta del tope (9) todavía no llegó: el piso no sube, se busca otra vez
    assert r["llega"] == [[ENTRO.format(109)], 1, 1], r
    assert r["despues"] == [[], 0, 0], r
    assert r["nuevo"][0] == [NUEVO] and r["nuevo"][1] == 0, r
    assert r["sin_bandera"] == [[], 0, 0] and r["sin_campo"] == [[], 0, 0], r
    # control: con avisarEntrados de antes de esta vuelta, lo mismo
    assert correr("antes", _caja_sin_duodecima()) == r


# ================================================================================================================ contrato
def test_contrato_de_la_duodecima_vuelta():
    # 4.39 (decimotercera vuelta): la duodécima se compara contra caja.js sin la decimotercera (la decimotercera metió una línea en aceptarWeb, justo antes
    # del comentario de W1; su contrato está en tests/test_439_decimotercera_vuelta.py)
    k, k0 = _caja_sin_decimotercera(), _caja_sin_duodecima()
    metodos = {c: _metodo(k, c) for c in CAMBIADOS}
    antes = {c: _metodo(k0, c) for c in CAMBIADOS}
    # cada tripleta de DUODECIMA: «lo de ahora» está en caja.js las veces anotadas, en su método; «lo de antes» ya no está (salvo dentro de «lo de
    # ahora»); los cuatro métodos cambiaron
    assert len(DUODECIMA) == 6 and len(DE_CADA) == 6
    for (viejo, nuevo, veces), c in zip(DUODECIMA, DE_CADA):
        assert k.count(nuevo) == veces and k0.count(viejo) == veces and k0.count(nuevo) == 0, nuevo[:120]
        assert k.count(viejo) == (veces if viejo in nuevo else 0), nuevo[:120]
        assert metodos[c].count(nuevo) == veces, (c, nuevo[:120])
    for c in metodos:
        assert metodos[c] != antes[c], c
    # fuera de ellos, caja.js no cambió (ningún método nuevo: los arneses sacan los métodos por texto)
    resto, resto0 = k, k0
    for c in metodos:
        resto, resto0 = resto.replace(metodos[c], ""), resto0.replace(antes[c], "")
    assert resto == resto0
    # lo de la vuelta lleva su comentario (W1, W2 en el programa, W2 en cancelarWeb y W3)
    assert k.count("4.39 (duodécima vuelta)") == 4 and k0.count("4.39 (duodécima vuelta)") == 0
    aw, iw, cw, ae = (metodos[c] for c in CAMBIADOS)
    # W1: «Aceptar pedido» (pw.imprime === false) va antes del mensaje del servidor
    assert aw.count("toast(pw.imprime === false ? 'Pedido #' + ((r && r.numero) || p.numero) + ' aceptado: ya está en la caja.' : r && r.mensaje ? r.mensaje : ") == 1
    # W2: en los tres lugares, si `online` cambió mientras se esperaba, se vuelve a leer sin esperar; ya no queda el descuento condicionado de antes
    otra = "if (this.online === o0) this.online = { ...this.online, nuevos: Math.max(0, (+this.online.nuevos || 0) - 1) }; else this.revisarOnline(); }"
    assert iw.count("if (ok && eraNuevo) { " + otra) == 2 and cw.count("if (eraNuevo) { " + otra) == 1 and k.count(otra) == 3
    assert "eraNuevo && this.online === o0" not in k and "await this.revisarOnline()" not in k
    # Q5 sigue: lo aceptado aquí se anota antes de bajar el número o volver a leer
    assert iw.index("if (ok) (this._entAvisados || (this._entAvisados = new Set())).add(+p.id);") < iw.index("if (ok && eraNuevo) { ")
    # W3: el piso sube con la cuenta del tope en la lista traída (o a los 6 intentos); la primera respuesta conserva lo anotado; la regla de cada cuenta
    # (una vez por pedido) sigue igual
    assert ae.count("if (enEspera().some(v => v && v.canal === 'online' && +v.pedido_id === tope) || ++this._entIntentos >= 6) this._entPiso = tope;") == 1
    assert "this._entAvisados.has(tope)" not in ae and "this._entAvisados = new Set();" not in ae
    assert ae.count("this._entAvisados = this._entAvisados || new Set(); return; }") == 1 and "!this._entAvisados.has(id)" in ae
    assert ae.index("await this.sincronizar();") < ae.index("enEspera().some(v => v && v.canal === 'online' && +v.pedido_id === tope)")
    # las notas de la versión cuentan la vuelta: el límite de la red muy lenta (las partes iguales de una mesa, más de 1,5 s, como en el cobro), Técnico
    # (la duodécima vuelta y la lista de pruebas hasta este archivo); cada frase nueva una vez
    # 4.39 (decimotercera vuelta): la frase de Técnico de la duodécima (el piso de avisarEntrados ahora dice también «o a los 6 intentos, como en la 4.38») y la
    # lista de pruebas de Técnico (ahora hasta test_439_decimotercera_vuelta.py) cambiaron en la decimotercera: salen de aquí; lo que sigue igual de esa frase
    # se exige abajo y las frases nuevas, en el contrato de la decimotercera
    notas = (RAIZ / "notas" / "4.39.md").read_text(encoding="utf-8")
    for t in ("- Con la red muy lenta (la lista de cuentas tarda más de 3 segundos; en las partes iguales de una mesa, más de 1,5 segundos, como en el cobro), "
              "lo que otro equipo acaba de hacer en la cuenta puede no verse al dividir:",
              "y la primera respuesta conserva _entAvisados; si la consulta de pedidos llegó mientras se aceptaba o cancelaba, se vuelve a leer (revisarOnline) en "
              "vez de dejar el número viejo; en el programa, «Aceptar pedido» avisa sin decir que la comanda sale sola."):
        assert notas.count(t) == 1, t
    # y ya no dicen lo de antes
    for t in ("Con la red muy lenta (la lista de cuentas tarda más de 3 segundos), lo que otro equipo", "de test_439_segunda_vuelta.py a test_439_undecima_vuelta.py"):
        assert notas.count(t) == 0, t
