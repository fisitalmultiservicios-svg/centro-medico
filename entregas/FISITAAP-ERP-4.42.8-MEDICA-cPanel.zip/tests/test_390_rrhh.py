# -*- coding: utf-8 -*-
"""3.90: precio del extra de Recursos humanos (₡10.000 + IVA con 10 empleados, ₡1.000 + IVA por adicional) y avisos de embargo
(art. 172 del Código de Trabajo) y pensión alimentaria (50 %), que no cambian montos."""
from app import planes, rrhh

P = rrhh.parametros_efectivos(None)
EMP = {"id": 1, "nombre": "Ana", "fecha_ingreso": "2021-03-15", "jornada": "diurna", "modo_salario": "hora", "salario_hora": 2500, "categoria": "TOSC", "hijos": 0}


def test_precio_del_extra_de_recursos_humanos():
    assert planes.EXTRAS["rrhh"]["precio"] == 10000 and planes.EMPLEADOS_RRHH == 10 and planes.PRECIO_EMPLEADO_EXTRA == 1000
    assert "10 empleados" in planes.EXTRAS["rrhh"]["nota"]


def test_embargable_por_tramos():
    m = 300000
    assert rrhh.embargable_mensual(250000, m) == 0
    assert rrhh.embargable_mensual(500000, m) == 25000                    # (500 000 − 300 000) / 8
    assert rrhh.embargable_mensual(1100000, m) == 125000                  # 600 000 / 8 + 200 000 / 4


def test_aviso_de_embargo_y_pension_sin_cambiar_montos():
    base = rrhh.calcular_nomina(EMP, P, "mensual")
    assert base["embargo_maximo"] is None and not base["embargo_excede"] and not base["pension_excede"]
    grande = rrhh.calcular_nomina(EMP, P, "mensual", deducciones=[{"concepto": "Embargo", "categoria": "embargo", "monto": 300000}])
    assert grande["embargo_excede"] is True and grande["embargo_maximo"] is not None and grande["embargo_maximo"] < 300000
    assert grande["otras_deducciones"] == base["otras_deducciones"] or grande["neto"] < base["neto"]   # el monto del juzgado se respeta
    pen = rrhh.calcular_nomina(EMP, P, "mensual", deducciones=[{"concepto": "Pensión", "categoria": "pension", "monto": base["neto"] * 0.8}])
    assert pen["pension_excede"] is True
