# -*- coding: utf-8 -*-
"""4.26: descargar el programa de escritorio desde la página web (Configuración › Instalación local) y publicarlo sin que las
computadoras conectadas se actualicen solas (campo opcional `automatica` de version.json; G-1 a G-8 del encargo).

La carpeta de lo publicado se cambia por una temporal en cada prueba (monkeypatch): data/local/ queda como estaba."""
import hashlib
import json
import pathlib
import types

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import actualizacion_local, auth
from app.db import engine, init_db
from test_425_ultimos_pantallas import MONTAR, _node

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
CORREO = "sa-426@example.test"
DATOS = b"MZ" + b"programa de prueba 4.26 " * 200


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _tramo(txt: str, desde: str, hasta: str) -> str:
    i = txt.index(desde)
    return txt[i:txt.index(hasta, i + len(desde))]


@pytest.fixture(autouse=True)
def _limpio():
    """Sin administrador del sistema al terminar (test_api.py exige que no exista ninguno) y sin dependencias cambiadas."""
    yield
    from app.main import app
    app.dependency_overrides.clear()
    with Session(engine) as s:
        u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == CORREO)).first()
        if u:
            s.delete(u); s.commit()


@pytest.fixture
def nube(tmp_path, monkeypatch):
    carpeta = tmp_path / "local"
    monkeypatch.setattr(actualizacion_local, "CARPETA_NUBE", carpeta)
    return carpeta


def _cliente(admin=True):
    from app.main import app
    init_db()
    if admin:
        with Session(engine) as s:
            u = s.exec(select(auth.Usuario).where(auth.Usuario.correo == CORREO)).first()
            if not u:
                u = auth.Usuario(correo=CORREO, nombre="SA 426", password_hash=auth.hash_password("Clave-Segura-426-QA!"), es_superadmin=True)
                s.add(u); s.commit(); s.refresh(u)
            sa = types.SimpleNamespace(id=u.id, correo=u.correo, es_superadmin=True, nombre="SA", mfa_activo=True)
        app.dependency_overrides[auth.superadmin] = lambda: sa
    return TestClient(app)


def _publicar(c, version="4.26", **extra):
    return c.post("/api/admin/local/publicar", files={"archivo": ("FISITAAPLocal.exe", DATOS, "application/octet-stream")},
                  data={"version": version, **extra})


# --------------------------------------------------------------------------------------------------------------- servidor
def test_publicar_sin_actualizacion_automatica(nube):
    c = _cliente()
    r = _publicar(c, automatica="false")
    assert r.status_code == 200, r.text
    p = r.json()["publicado"]
    assert p["version"] == "4.26" and p["automatica"] is False and p["sha256"] == hashlib.sha256(DATOS).hexdigest()
    assert json.loads((nube / "version.json").read_text(encoding="utf-8"))["automatica"] is False
    # G-1: mismo lugar y mismos nombres, sin otra copia
    assert sorted(x.name for x in nube.iterdir()) == ["GrupoFacturaLocal.exe", "version.json"]
    # G-3: los programas instalados no ven nada
    assert c.get("/api/local/version").json() == {"version": None}
    # G-4: la página sí lo ve
    i = c.get("/api/local/instalador").json()
    assert i == {"version": "4.26", "bytes": len(DATOS), "fecha": p["fecha"], "automatica": False}
    # G-5: la descarga sigue, con el nombre del programa
    d = c.get("/api/local/descargar")
    assert d.status_code == 200 and d.content == DATOS and "FISITAAPLocal.exe" in d.headers["content-disposition"]
    assert c.get("/api/admin/local").json()["publicado"]["automatica"] is False
    # el programa instalado (revisar) no encuentra versión nueva
    assert actualizacion_local.version_publicada() == {"version": None}

    # G-6: activarla sin volver a subir el archivo
    r = c.post("/api/admin/local/automatica", json={"automatica": True})
    assert r.status_code == 200 and r.json()["publicado"]["automatica"] is True, r.text
    v = c.get("/api/local/version").json()
    assert v["version"] == "4.26" and v["sha256"] == hashlib.sha256(DATOS).hexdigest() and v["archivo"] == "GrupoFacturaLocal.exe"
    assert "automatica" not in v                                                # la misma respuesta de antes de la 4.26
    assert c.get("/api/local/instalador").json()["automatica"] is True
    assert (nube / "GrupoFacturaLocal.exe").read_bytes() == DATOS and not (nube / "version.json.cambiando").exists()
    # y desactivarla otra vez
    assert c.post("/api/admin/local/automatica", json={"automatica": False}).json()["publicado"]["automatica"] is False
    assert c.get("/api/local/version").json() == {"version": None}
    # un valor que no es verdadero o falso no se acepta
    assert c.post("/api/admin/local/automatica", json={"automatica": "si"}).status_code == 400
    assert c.post("/api/admin/local/automatica", json={}).status_code == 400

    # quitar lo publicado: todo vuelve a nulo
    assert c.delete("/api/admin/local").status_code == 200
    assert c.get("/api/local/version").json() == {"version": None}
    assert c.get("/api/local/instalador").json() == {"version": None}
    assert c.get("/api/local/descargar").status_code == 404
    assert c.post("/api/admin/local/automatica", json={"automatica": True}).status_code == 404


def test_publicar_sin_el_campo_es_como_hoy(nube):
    c = _cliente()
    assert c.get("/api/local/instalador").json() == {"version": None}
    r = _publicar(c)
    assert r.status_code == 200 and r.json()["publicado"]["automatica"] is True, r.text
    assert c.get("/api/local/version").json()["version"] == "4.26"
    assert c.get("/api/local/instalador").json()["automatica"] is True
    assert _publicar(c, version="4.27", automatica="true").json()["publicado"]["automatica"] is True


def test_version_json_a_mano(nube):
    c = _cliente(admin=False)
    nube.mkdir(parents=True)
    (nube / "GrupoFacturaLocal.exe").write_bytes(DATOS)
    meta = {"version": "4.25", "sha256": hashlib.sha256(DATOS).hexdigest(), "bytes": len(DATOS), "fecha": "2026-11-11T08:00:00"}
    (nube / "version.json").write_text(json.dumps(meta), encoding="utf-8")         # sin el campo: verdadero
    assert c.get("/api/local/version").json()["version"] == "4.25"
    assert c.get("/api/local/instalador").json() == {"version": "4.25", "bytes": len(DATOS), "fecha": "2026-11-11T08:00:00", "automatica": True}
    (nube / "version.json").write_text(json.dumps({**meta, "automatica": False}), encoding="utf-8")
    assert c.get("/api/local/version").json() == {"version": None} and c.get("/api/local/instalador").json()["version"] == "4.25"
    # ilegible, sin versión o que no es un objeto: nada publicado
    for texto in ("{no es json", json.dumps({**meta, "version": ""}), "[1, 2]"):
        (nube / "version.json").write_text(texto, encoding="utf-8")
        assert c.get("/api/local/version").json() == {"version": None}, texto
        assert c.get("/api/local/instalador").json() == {"version": None}, texto
        assert c.get("/api/local/descargar").status_code == 404, texto


def test_valor_de_automatica():
    f = actualizacion_local._automatica
    assert f({}) is True and f({"automatica": None}) is True and f({"automatica": True}) is True and f({"automatica": "true"}) is True
    assert f({"automatica": False}) is False and f({"automatica": 0}) is False
    for t in ("false", "False", "0", "no", "off"):
        assert f({"automatica": t}) is False, t


def test_cambiar_sin_administrador_del_sistema(nube):
    c = _cliente()
    assert _publicar(c, automatica="false").status_code == 200
    from app.main import app
    app.dependency_overrides.clear()
    r = c.post("/api/admin/local/automatica", json={"automatica": True})
    assert r.status_code in (401, 403), r.text
    assert c.get("/api/local/version").json() == {"version": None}           # no cambió nada
    assert c.get("/api/admin/local").status_code in (401, 403)
    # las públicas siguen sin sesión
    assert c.get("/api/local/instalador").json()["version"] == "4.26" and c.get("/api/local/descargar").status_code == 200


# --------------------------------------------------------------------------------------------------------------- pantallas
def test_texto_administracion():
    a = _js("pages/admin.js")
    assert "localForm: { version: '', archivo: null, automatica: true }" in a
    publicar = _tramo(a, "    async publicarLocal() {", "    async quitarLocal() {")
    assert "fd.append('automatica', f.automatica ? 'true' : 'false');" in publicar
    assert "quedó disponible para descargar desde Configuración › Instalación local" in publicar
    assert "las instalaciones lo descargan en su siguiente revisión" in publicar
    assert "api('/api/admin/local/automatica', { method: 'POST', body: { automatica: !!valor } })" in publicar
    tpl = _tramo(a, "<template v-if=\"tab==='local'\">", "</template>\n    <template")
    assert '<input type="checkbox" v-model="localForm.automatica"> Actualizar solas las computadoras conectadas</label>' in tpl
    for texto in ("Actualización automática desactivada.", "Actualización automática activada.", "Activar la actualización automática",
                  "Desactivar la actualización automática", "El programa queda solo para descargar desde Configuración › Instalación local."):
        assert texto in tpl, texto
    assert '@click="cambiarAutoLocal(local.publicado.automatica === false)"' in tpl


def test_los_textos_no_prometen_detener_a_quien_ya_descargo():
    """Corrección de la 4.26: desactivar la actualización automática no detiene a la computadora que YA descargó la versión (el
    programa instala lo descargado sin volver a preguntar a la nube, y por G-8 no se toca). Los textos ya no dicen que «las
    computadoras conectadas no cambian de versión»: dicen qué pasa con las que ya la descargaron."""
    a = _js("pages/admin.js")
    metodos = _tramo(a, "    async publicarLocal() {", "    async quitarLocal() {")
    tpl = _tramo(a, "<template v-if=\"tab==='local'\">", "</template>\n    <template")
    for tramo in (metodos, tpl):
        assert "no cambian" not in tramo                 # ninguna promesa de que «no cambian»: solo que no la descargan solas
    # al publicar con la casilla desmarcada
    assert "Instalación local; las computadoras conectadas no lo descargan solas' : 'Programa local '" in metodos
    # al tocar «Desactivar la actualización automática»
    assert "el programa queda solo para descargar'" not in metodos
    assert ("'Actualización automática desactivada: las computadoras conectadas ya no descargan esta versión solas; "
            "las que ya la descargaron la instalan al reiniciar el programa'") in metodos
    # el aviso amarillo y la ayuda de la casilla
    assert ("Las computadoras conectadas no descargan esta versión solas hasta que la active; "
            "las que ya la descargaron la instalan al reiniciar el programa.</span>") in tpl
    assert ("las computadoras conectadas no lo descargan solas hasta que active la actualización automática aquí. Una computadora "
            "que ya descargó una versión la instala al reiniciar el programa, aunque después se desactive.</p>") in tpl
    # el documento del programa (CRLF, sin mezclar)
    crudo = (RAIZ / "local" / "README.md").read_bytes()
    assert crudo.count(b"\r\n") == crudo.count(b"\n")
    r = crudo.decode("utf-8")
    llano = " ".join(r[r.index("## Publicar una versión"):].split())
    assert "nadie se actualiza solo" not in llano
    for texto in ("y ninguna instalación descarga esa versión sola;", "Desactivarla NO detiene a la computadora que ya descargó la versión",
                  "`FISITAAPLocal.nuevo.exe` y `actualizacion.json` en `%LOCALAPPDATA%\\GrupoFactura`",
                  "la instala al siguiente arranque o con «Reiniciar y actualizar», sin volver a preguntar a la nube",
                  "borrar esos dos archivos antes de reiniciar el programa"):
        assert texto in llano, texto


def test_desactivar_no_detiene_a_la_computadora_que_ya_descargo(nube, tmp_path, monkeypatch):
    """Lo que avisan esos textos, con el código del programa tal como está (no se toca en la 4.26): la computadora que ya
    descargó la versión la tiene lista para instalar aunque la nube deje de ofrecerla; la que no, no cambia."""
    import httpx

    c = _cliente()
    assert _publicar(c).status_code == 200                                      # con la actualización automática activada

    class _Resp:
        def __init__(self, r): self.r = r
        def raise_for_status(self): assert self.r.status_code == 200
        def json(self): return self.r.json()
        def iter_bytes(self, n): yield self.r.content
        def __enter__(self): return self
        def __exit__(self, *a): return False
    monkeypatch.setattr(httpx, "get", lambda url, timeout=None: _Resp(c.get(url.replace("http://nube.test", ""))))
    monkeypatch.setattr(httpx, "stream", lambda m, url, timeout=None: _Resp(c.get(url.replace("http://nube.test", ""))))
    monkeypatch.setattr(actualizacion_local, "_estado", {"revisado": None, "error": None})
    monkeypatch.setenv("FE_VERSION_LOCAL", "4.25")
    pc_a, pc_b = tmp_path / "pc-a", tmp_path / "pc-b"
    pc_a.mkdir(); pc_b.mkdir()
    nada = {"nueva": None, "descargada": False, "error": None}
    assert actualizacion_local.revisar("4.25", pc_a, "http://nube.test") == {"nueva": "4.26", "descargada": True, "error": None}
    assert c.post("/api/admin/local/automatica", json={"automatica": False}).status_code == 200
    # la computadora B todavía no la había descargado: no cambia
    assert actualizacion_local.revisar("4.25", pc_b, "http://nube.test") == nada
    assert actualizacion_local.pendiente(pc_b) is None and not (pc_b / actualizacion_local.NUEVO).exists()
    # la computadora A ya la tiene: sigue lista para instalarse al reiniciar, aunque la nube ya no la ofrezca
    assert actualizacion_local.revisar("4.25", pc_a, "http://nube.test") == nada
    assert actualizacion_local.pendiente(pc_a)["version"] == "4.26"
    # lo que dice local/README.md para evitarlo en esa computadora: sin los dos archivos no se instala ni se vuelve a bajar
    (pc_a / actualizacion_local.NUEVO).unlink(); (pc_a / "actualizacion.json").unlink()
    assert actualizacion_local.pendiente(pc_a) is None
    assert actualizacion_local.revisar("4.25", pc_a, "http://nube.test") == nada
    assert not (pc_a / actualizacion_local.NUEVO).exists()


def test_texto_instalacion_local_solo_en_la_web():
    i = _js("pages/configuracion/instalacion-local.js")
    programa, web = i.split('<template v-else-if="est">', 1)
    assert "Descargar el programa para Windows" not in programa and "/api/local/descargar" not in programa
    tarjeta = _tramo(web, "<h2>Conectar una computadora nueva</h2>", "</ol>")
    assert '<div v-if="instalador"' in tarjeta and '<a class="btn" href="/api/local/descargar"' in tarjeta
    assert ">Descargar el programa para Windows</a>" in tarjeta and "versión {{instalador.version}} · {{mb(instalador.bytes)}}" in tarjeta
    assert "Windows puede avisar que no conoce al editor: toque «Más información» y después «Ejecutar de todas formas»." in tarjeta
    assert "'Descargue el programa en esa computadora y ábralo.'" in tarjeta and "'Instale el programa en la computadora y ábralo.'" in tarjeta
    cargar = _tramo(i, "    async cargar() {", "    conexionLista(ev) {")
    assert "if (this.est && !this.est.modo_local) { try { const p = await api('/api/local/instalador');" in cargar
    assert "catch { this.instalador = null; }" in cargar
    assert "instalador: null," in i


FALSO_API = """
export const toast = (m, t) => globalThis.Q.toasts.push([m, t || '']);
export const fechaHora = x => x;
export const api = async (url) => { globalThis.Q.pedidos.push(url); return globalThis.Q.api(url); };
"""
FALSO_APP = "export const sesion = { puede: () => true, usuario: { de_nube: true }, cerrar() {}, async refrescarEmpresas() { return {}; } };\n"


def test_instalacion_local_en_node(tmp_path):
    r = _node(tmp_path, MONTAR + """
globalThis.Q = { toasts: [], pedidos: [] };
const C = (await import('./js/pages/configuracion/instalacion-local.js')).default;
const out = {};
async function correr(api) { Q.api = api; Q.pedidos = []; Q.toasts = []; const vm = montar(C); await vm.cargar(); return vm; }
// web con programa publicado
let vm = await correr(async u => u === '/api/sinc/local/estado' ? { modo_local: false } : u === '/api/sinc/instalaciones' ? { instalaciones: [] } : { version: '4.26', bytes: 52428800, fecha: 'x', automatica: false });
out.publicado = [vm.instalador && vm.instalador.version, vm.mb(vm.instalador.bytes), Q.pedidos, Q.toasts.length, vm.cargando];
// la consulta falla: sin botón y sin aviso de error
vm = await correr(async u => { if (u === '/api/local/instalador') throw new Error('caída'); return u === '/api/sinc/local/estado' ? { modo_local: false } : { instalaciones: [] }; });
out.falla = [vm.instalador, Q.toasts.length, vm.cargando];
// nada publicado
vm = await correr(async u => u === '/api/sinc/local/estado' ? { modo_local: false } : u === '/api/sinc/instalaciones' ? { instalaciones: [] } : { version: null });
out.nada = vm.instalador;
// en el programa no se consulta
vm = await correr(async u => u === '/api/sinc/local/estado' ? { modo_local: true } : {});
out.programa = [vm.instalador, Q.pedidos.includes('/api/local/instalador')];
console.log(JSON.stringify(out));
""", archivos=("pages/configuracion/instalacion-local.js",), falsos={"api.js": FALSO_API, "app.js": FALSO_APP, "conexion-local.js": "export default {};\n"})
    assert r["publicado"] == ["4.26", "50.0 MB", ["/api/sinc/local/estado", "/api/sinc/instalaciones", "/api/local/instalador"], 0, False], r
    assert r["falla"] == [None, 0, False], r
    assert r["nada"] is None and r["programa"] == [None, False], r


def test_sintaxis_y_plantillas(tmp_path):
    """node --check y el compilador de Vue del proyecto sobre las dos pantallas tocadas."""
    import subprocess
    from test_425_ultimos_pantallas import _nodo
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    tocados = ("pages/admin.js", "pages/configuracion/instalacion-local.js")
    for rel in tocados:
        copia = tmp_path / (rel.replace("/", "_")[:-3] + ".mjs")
        copia.write_text(_js(rel), encoding="utf-8")
        out = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
        assert out.returncode == 0, (rel, out.stderr)
    vue = (JS / "vendor" / "vue.esm-browser.prod.min.js").as_uri()
    rutas = json.dumps([str(JS / r) for r in tocados])
    guion = """
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
globalThis.document = { createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\\s\\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) };
const { compile } = await import(%s);
const fs = await import('node:fs');
const malos = [];
let n = 0;
for (const a of %s) {
  const txt = fs.readFileSync(a, 'utf8'); const re = /template:\\s*`([\\s\\S]*?)`/g; let m;
  while ((m = re.exec(txt))) {
    if (m[1].includes('${')) continue;
    n++;
    const err = []; try { compile(m[1], { onError: e => err.push(e.message), onWarn: () => {} }); } catch (e) { err.push(String(e)); }
    if (err.length) malos.push([a, err.slice(0, 2)]);
  }
}
console.log(JSON.stringify({ n, malos }));
""" % (json.dumps(vue), rutas)
    out = subprocess.run([node, "--input-type=module", "-e", guion], capture_output=True, text=True, timeout=120, encoding="utf-8")
    assert out.returncode == 0, out.stderr
    r = json.loads(out.stdout)
    assert r["n"] >= 2 and r["malos"] == [], r
