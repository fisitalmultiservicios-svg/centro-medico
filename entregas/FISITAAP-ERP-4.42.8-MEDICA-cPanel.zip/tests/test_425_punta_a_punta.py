# -*- coding: utf-8 -*-
"""4.25 (encargo 9b): correcciones que salieron de la primera prueba de punta a punta con servidores de verdad (U1 a U18).

Decisiones: D-P (un código o una aprobación de OTRA empresa nunca reemplaza a una empresa que ya tiene datos en la computadora),
D-Q (las sesiones se cierran por un cambio REAL de contraseña, no por el vaivén real → inservible → el mismo) y D-R (sin internet,
quien viene de la web y aquí solo tiene la contraseña inservible recibe el motivo, sin contar fallo).

Nube y computadora corren en el MISMO proceso y comparten la tabla de usuarios (ver tests/test_49_local_sinc.py y
tests/test_425_conexion_programa.py, de donde salen las ayudas y la limpieza)."""
import secrets
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx
import pytest
from sqlmodel import Session, select

from app import auth, sinc
from app.db import Auditoria, Empresa, engine, engine_empresa
from test_49_local_sinc import NUBE, PW, H, _admin_empresa, _cfg, _poner_cfg, _Respuesta, _soltar_limite_vinculacion, _vincular, c
from test_425_conexion_nube import _aprobar, _limpiar_limitador, _pase, _poner_pase, _recoger, _vinc
from test_425_conexion_programa import (_BASE, _BORRAR, _confirmar, _estado, _iniciar, _limpieza, _llamadas, _membresias,  # noqa: F401
                                        _programa, _soltar_programa, _usuario, _vivas)
from test_425_ingreso_programa import _ficha, _persona, _revocada, _sesion_vieja, _sobre, _solo_estas

INGRESO, FICHA = "/api/sinc/ingreso", "/api/sinc/usuario"
RAIZ = Path(sinc.__file__).parent
JS = RAIZ / "static" / "js"


def _leer(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


def _auditorias(accion: str, **filtro) -> list:
    with Session(engine) as sc:
        q = select(Auditoria).where(Auditoria.accion == accion)
        for k, v in filtro.items():
            q = q.where(getattr(Auditoria, k) == v)
        return sc.exec(q.order_by(Auditoria.id)).all()


def _fallos(correo: str) -> list:
    with Session(engine) as sc:
        return sc.exec(select(auth.IntentoIp).where(auth.IntentoIp.clave.in_(("login_fallo", "login_cuenta", "login_fallo_prog")),
                                                    auth.IntentoIp.ip.endswith(correo))).all()


def _tokens(eid: int) -> int:
    with Session(engine) as sc:
        return len(sc.exec(select(auth.TokenApi).where(auth.TokenApi.empresa_id == eid)).all())


# ------------------------------------------------------------------------------------------------------------------------ U1
def test_u1_codigo_de_otra_empresa_no_reemplaza_la_empresa_con_datos(monkeypatch):
    eid_a, ta = _admin_empresa("-u9b1a", "3101429101")
    eid_b, tb = _admin_empresa("-u9b1b", "3101429102")
    eid_l, tl = _admin_empresa("-u9b1l", "3101429101")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")                                  # la computadora ya trabaja con la empresa A (terminal anotada)
    antes = _cfg(eid_l)
    inst_b, tok_b = len(_vinc(eid_b).get("instalaciones", [])), _tokens(eid_b)
    _soltar_limite_vinculacion()
    codigo_b = c.post("/api/sinc/codigo", headers=H(tb), json={"nombre": "Caja"}).json()["codigo"]
    with monkeypatch.context() as m:
        m.setattr(sinc, "sincronizar", lambda eid: None)
        r = c.post("/api/sinc/local/vincular", headers=H(tl), json={"url": NUBE, "codigo": codigo_b, "nombre": "Caja"})
    assert r.status_code == 409, r.text
    texto = r.json()["detail"]
    assert "cédula 3101429102" in texto and "Sinc49 QA-u9b1a" in texto and "«Conectar otra empresa en esta computadora»" in texto
    assert shim.llamadas[-1][1] == "/api/sinc/canje" and shim.llamadas[-1][2]["cedula"] == "3101429101"
    # en la web no nació nada (el 409 sale antes de crear el token) y en la computadora no se aplicó nada
    assert len(_vinc(eid_b).get("instalaciones", [])) == inst_b and _tokens(eid_b) == tok_b
    despues = _cfg(eid_l)
    assert despues["token"] == antes["token"] and despues["terminal"] == antes["terminal"]
    with Session(engine) as sc:
        assert sc.get(Empresa, eid_l).numero_id == "3101429101"
    # una web anterior que no revisa la cédula: la respuesta trae otra empresa y el programa no la aplica
    shim.por_ruta["/api/sinc/canje"] = _Respuesta(200, {"token": "fcr_" + secrets.token_urlsafe(32), "terminal": 9, "nombre": "Caja",
                                                       "empresa": {"nombre": "Otra QA", "numero_id": "3-101-429102"}, "credenciales": {}})
    with monkeypatch.context() as m:
        m.setattr(sinc, "sincronizar", lambda eid: None)
        r = c.post("/api/sinc/local/vincular", headers=H(tl), json={"url": NUBE, "codigo": codigo_b, "nombre": "Caja"})
    assert r.status_code == 409 and "cédula 3101429102" in r.json()["detail"], r.text
    assert _cfg(eid_l)["token"] == antes["token"] and _cfg(eid_l)["terminal"] == antes["terminal"]
    assert _auditorias("sinc_local_codigo_otra", empresa_id=eid_l)
    shim.por_ruta.clear()
    # un programa anterior no manda la cédula: la web canjea como hoy (y el código seguía sirviendo)
    _soltar_limite_vinculacion()
    r = c.post("/api/sinc/canje", json={"codigo": codigo_b, "nombre": "Caja vieja"})
    assert r.status_code == 200 and r.json()["empresa"]["numero_id"] == "3101429102", r.text
    # la web, con la cédula de una empresa que sí es la del código, canjea como siempre; con otra, 409 sin crear el token
    codigo_b2 = c.post("/api/sinc/codigo", headers=H(tb), json={"nombre": "Caja"}).json()["codigo"]
    tok_b = _tokens(eid_b)
    r = c.post("/api/sinc/canje", json={"codigo": codigo_b2, "nombre": "Caja", "cedula": "3101429101"})
    assert r.status_code == 409 and r.json()["detail"]["codigo"] == "otra_empresa" and _tokens(eid_b) == tok_b
    r = c.post("/api/sinc/canje", json={"codigo": codigo_b2, "nombre": "Caja", "cedula": "3-101-429102"})
    assert r.status_code == 200 and _tokens(eid_b) == tok_b + 1


# ------------------------------------------------------------------------------------------------------------------------ U2
def test_u2_sesiones_se_cierran_solo_por_un_cambio_real_de_contrasena():
    with Session(engine) as sc:
        e = auth.crear_empresa(sc, "Local9b QA-u2", "local9b-u2@example.test", "3101429201")
        eid = e.id
    uid, correo = _persona(0, "cajera-u9b2", local=eid)
    _sesion_vieja(uid, "sid-u9b2-a")
    real_a = _usuario(correo).password_hash

    def aplicar(**cambios):
        with Session(engine) as sc:
            sinc._aplicar_usuario(sc, eid, _ficha(uid, **cambios)); sc.commit()
    aplicar(password_hash=sinc.HASH_INSERVIBLE)                             # la política se la quita: no es un cambio de contraseña
    u = _usuario(correo)
    assert u.password_hash == sinc.HASH_INSERVIBLE and u.huella_password and real_a not in u.huella_password and not _revocada("sid-u9b2-a")
    assert u.huella_password == sinc._huella_password(real_a)
    aplicar(password_hash=real_a)                                           # vuelve la MISMA: las sesiones siguen
    assert not _revocada("sid-u9b2-a") and _usuario(correo).password_hash == real_a and _usuario(correo).huella_password is None
    aplicar(password_hash=sinc.HASH_INSERVIBLE)
    aplicar(password_hash=auth.hash_password("Otra-Clave-u9b2-2026"))       # llega OTRA: se cierran
    assert _revocada("sid-u9b2-a")
    # inservible sin huella (nunca tuvo aquí la real) → llega una real: se cierran (lo más estricto)
    with Session(engine) as sc:
        u2 = auth.Usuario(correo="cajera-u9b2c@example.test", nombre="C", password_hash=sinc.HASH_INSERVIBLE, de_nube=True,
                          terminos_version=auth.TERMINOS_VERSION)
        sc.add(u2); sc.commit(); sc.refresh(u2); uid2 = u2.id
        sc.add(auth.UsuarioEmpresa(usuario_id=uid2, empresa_id=eid, rol="Cajero")); sc.commit()
    _sesion_vieja(uid2, "sid-u9b2-c")
    with Session(engine) as sc:
        sinc._aplicar_usuario(sc, eid, {**_ficha(uid2), "password_hash": real_a}); sc.commit()
    assert _revocada("sid-u9b2-c")


# ------------------------------------------------------------------------------------------------------------------------ U3
def test_u3_sin_internet_quien_no_entro_aqui_recibe_el_motivo_y_no_cuenta_fallo(monkeypatch):
    eid_a, ta = _admin_empresa("-u9b3n", "3101429301")
    eid_l, tl = _admin_empresa("-u9b3l", "3101429302")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    _solo_estas(monkeypatch, eid_l)
    _poner_cfg(eid_l, version_nube="4.25")
    with Session(engine) as sc:
        u = auth.Usuario(correo="cajera-u9b3@example.test", nombre="C", password_hash=sinc.HASH_INSERVIBLE, de_nube=True,
                         terminos_version=auth.TERMINOS_VERSION)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_l, rol="Cajero")); sc.commit()
    uid_r, correo_r = _persona(eid_a, "cajera-u9b3r", local=eid_l)
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    for _ in range(6):                                                      # cinco intentos no la dejan en espera
        r = c.post("/api/auth/login", json={"correo": "cajera-u9b3@example.test", "password": PW})
        assert r.status_code == 403 and r.json()["detail"] == sinc.SIN_VALIDAR_AQUI, r.text
    assert not _fallos("cajera-u9b3@example.test")
    assert not _auditorias("login_fallido", correo="cajera-u9b3@example.test")
    # un correo que no existe aquí: el 401 de siempre, con fallo
    r = c.post("/api/auth/login", json={"correo": "nadie-u9b3@example.test", "password": PW})
    assert r.status_code == 401 and _fallos("nadie-u9b3@example.test")
    # quien tiene aquí su contraseña real y escribe otra: 401 con fallo
    r = c.post("/api/auth/login", json={"correo": correo_r, "password": "Mala-Clave-u9b3-2026"})
    assert r.status_code == 401 and _fallos(correo_r)


# ------------------------------------------------------------------------------------------------------------------------ U4
def test_u4_admin_de_la_computadora_con_el_correo_de_la_web(monkeypatch):
    eid_a, ta = _admin_empresa("-u9b4n", "3101429401")
    eid_l, tl = _admin_empresa("-u9b4l", "3101429401")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    _solo_estas(monkeypatch, eid_l)
    _poner_cfg(eid_l, version_nube="4.25")
    correo, local_pw, web_pw = "admin-u9b4@example.test", "Clave-Local-u9b4-2026", "Clave-Web-u9b4-2026"
    _BORRAR.append(correo)
    with Session(engine) as sc:
        u = auth.Usuario(correo=correo, nombre="Admin U4", password_hash=auth.hash_password(local_pw), es_superadmin=True, admin_principal=True,
                         terminos_version=auth.TERMINOS_VERSION, terminos_fecha=datetime.now(timezone.utc))
        sc.add(u); sc.commit(); sc.refresh(u); uid = u.id
    ficha = {"correo": correo, "nombre": "Admin U4", "password_hash": auth.hash_password(web_pw), "pin_hash": None, "bloqueado": False,
             "terminos_version": auth.TERMINOS_VERSION, "paleta": None, "rol": "Administrador", "sucursal_id": None, "modulos_ocultos": None,
             "mfa": "", "mfa_entrar": False, "mfa_rrhh": False, "temporal": False}
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    _soltar_programa()
    # con la contraseña de la computadora: la web la rechaza por credenciales → camino local → 403 de cuenta retirada, sin fallo
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "credenciales"))
    r = c.post("/api/auth/login", json={"correo": correo, "password": local_pw})
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "cuenta_local", r.text
    assert not _fallos(correo) and _usuario(correo).es_superadmin and auth.verificar_password(local_pw, _usuario(correo).password_hash)
    # sin respuesta de la web, lo mismo
    shim.por_ruta[INGRESO] = httpx.ConnectError("sin red")
    r = c.post("/api/auth/login", json={"correo": correo, "password": local_pw})
    assert r.status_code == 403 and r.json()["detail"]["codigo"] == "cuenta_local", r.text
    # con la contraseña de la web: entra validada en la web y la cuenta queda convertida (sin haber corrido ninguna bajada)
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("ok", usuario=ficha))
    r = c.post("/api/auth/login", json={"correo": correo, "password": web_pw})
    assert r.status_code == 200 and r.json().get("token"), r.text
    u = _usuario(correo)
    assert not u.es_superadmin and u.de_nube and u.nube_validado and auth.verificar_password(web_pw, u.password_hash)
    assert any(m.usuario_id == uid for m in _membresias(eid_l))
    assert _auditorias("cuenta_local_convertida", usuario_id=uid)
    assert not _fallos(correo)


# ------------------------------------------------------------------------------------------------------------------------ U8
def test_u8_rechazo_por_cuenta_bloqueada_queda_en_la_auditoria_del_programa(monkeypatch):
    eid_a, ta = _admin_empresa("-u9b8n", "3101429801")
    eid_l, tl = _admin_empresa("-u9b8l", "3101429802")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    _solo_estas(monkeypatch, eid_l)
    uid, correo = _persona(eid_a, "cajera-u9b8", local=eid_l, pin_hash=auth.hash_password("4827"), nube_validado=datetime.now(timezone.utc))
    shim.por_ruta[INGRESO] = _Respuesta(200, _sobre("rechazado", "bloqueado"))
    r = c.post("/api/auth/login", json={"correo": correo, "password": PW})
    assert r.status_code == 403, r.text
    filas = _auditorias("login_rechazado", usuario_id=uid)
    assert filas and filas[-1].detalle == "Cuenta bloqueada por el administrador" and PW not in (filas[-1].detalle or "")
    n = len(filas)
    _poner_cfg(eid_l)
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    shim.por_ruta[FICHA] = _Respuesta(200, _sobre("ok", miembro=True, usuario=_ficha(uid, bloqueado=True, pin_hash=_usuario(correo).pin_hash)))
    r = c.post("/api/auth/pin/entrar", json={"correo": correo, "pin": "4827"})
    assert r.status_code == 403 and "bloqueada" in r.text, r.text
    filas = _auditorias("login_rechazado", usuario_id=uid)
    assert len(filas) == n + 1 and filas[-1].detalle == "Cuenta bloqueada por el administrador" and "4827" not in filas[-1].detalle


# ------------------------------------------------------------------------------------------------------------------------ U5
def _iniciar_otra(cab, nombre: str = "Caja 2"):
    return c.post("/api/sinc/local/conexion/iniciar", headers=cab, json={"nombre": nombre, "otra_empresa": True})


def test_u5_conectar_otra_empresa_en_una_computadora_ya_conectada(monkeypatch):
    eid_a, ta = _admin_empresa("-u9b5a", "3101429501")
    eid_b, tb = _admin_empresa("-u9b5b", "3101429502")
    eid_l, tl = _admin_empresa("-u9b5l", "3101429501")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    web = {eid_a, eid_b}                                                    # en las pruebas la web y la computadora comparten la tabla de empresas
    monkeypatch.setattr(sinc, "_empresa_con_cedula", lambda sc, ced: next((e.id for e in sc.exec(select(Empresa).order_by(Empresa.id)).all()
                                                                            if e.id > _BASE[0] and e.id not in web and sinc._digitos(e.numero_id) == ced), None))
    antes = _cfg(eid_l)
    with Session(engine) as sc:
        e = sc.get(Empresa, eid_l)
        antes_e = (e.nombre, e.numero_id, e.terminal)
    r = _iniciar_otra(H(tl))
    assert r.status_code == 200, r.text
    j = r.json()
    ini = _llamadas(shim, "/api/sinc/conexion/iniciar")[-1][2]
    assert ini["cedula"] is None                                            # no va atado a la empresa abierta
    a = _aprobar(tb, j["codigo"], eid_b).json()
    v = _estado(j["intento"], H(tl)).json()
    assert v["estado"] == "confirmar" and v["empresa"]["numero_id"] == "3101429502", v
    v = _confirmar(j["intento"], a["numero"], cab=H(tl)).json()
    assert v["estado"] == "lista" and v["otra_empresa"] is True and v["reconexion"] is False, v
    assert v["mensaje"] == "Listo. La empresa Sinc49 QA-u9b5b quedó en esta computadora. Para trabajar con ella, elíjala en el menú de su empresa, arriba."   # 9c (P9)
    nueva = v["empresa_id"]
    assert nueva not in (eid_l, eid_a, eid_b) and nueva > _BASE[0]
    cfg = _cfg(nueva)
    assert cfg["vinculado"] and cfg["origen"] == "conexion" and cfg["primera"]["membresias"]           # como una PRIMERA conexión de esa empresa
    with Session(engine) as sc:
        assert sc.get(Empresa, nueva).numero_id == "3101429502"
        e = sc.get(Empresa, eid_l)
        assert (e.nombre, e.numero_id, e.terminal) == antes_e                # la primera, intacta
    despues = _cfg(eid_l)
    assert all(despues.get(k) == antes.get(k) for k in ("vinculado", "token", "terminal", "url", "sucursal", "nombre"))
    assert c.get("/api/auth/yo", headers=H(tl)).status_code == 200          # la sesión de quien conecta sigue
    # esa misma cédula ya está en esta computadora: se cancela con su mensaje
    _soltar_programa()
    _limpiar_limitador()
    j = _iniciar_otra(H(tl)).json()
    a = _aprobar(ta, j["codigo"], eid_a).json()
    v = _estado(j["intento"], H(tl)).json()
    assert v["estado"] == "ya_esta" and v["mensaje"] == "Esa empresa ya está en esta computadora: ábrala y use «Conectar con mi cuenta».", v
    assert _pase(id=a["pase"]).estado == "cancelado"
    # sin «configurar» o con un token de API: 403; sin sesión: 401
    with Session(engine) as sc:
        u = auth.Usuario(correo="cajera-u9b5@example.test", nombre="Cajera", password_hash=auth.hash_password(PW), terminos_version=auth.TERMINOS_VERSION)
        sc.add(u); sc.commit(); sc.refresh(u)
        sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid_l, rol="Cajero")); sc.commit()
        tc = auth._respuesta(sc, u, eid_l)["token"]
        tok = "fcr_" + secrets.token_urlsafe(32)
        uid_admin = sc.exec(select(auth.Usuario).where(auth.Usuario.correo == "duena-sinc49-u9b5l@example.test")).first().id
        sc.add(auth.TokenApi(empresa_id=eid_l, usuario_id=uid_admin, nombre="QA u9b5", prefijo=tok[:12], hash=auth._hash_token_api(tok), permisos='["ver", "catalogos", "configurar"]'))   # 9c (P8): aun con «configurar»
        sc.commit()
    assert _iniciar_otra(H(tc)).status_code == 403
    assert _iniciar_otra(H(tok)).status_code == 403
    assert _iniciar_otra({}).status_code == 401


# ------------------------------------------------------------------- U5 (corrección): la empresa que dejó un intento que no terminó
RECOGER = "/api/sinc/conexion/recoger"


def _otra_simulada(cedula: str, aprobo: str, nombre: str) -> tuple:
    """Lo que contesta la web a «recoger» para una empresa que en la prueba NO está en la tabla compartida de empresas (así lo que busca
    esa cédula en la computadora corre de verdad, sin sustituir): la confirmación («aprobada») y la entrega («conectada»)."""
    emp, ap = {"nombre": nombre, "nombre_comercial": nombre, "numero_id": cedula}, {"correo": aprobo, "nombre": "Dueña"}
    aprobada = _Respuesta(200, sinc._sobre_conexion("aprobada", intervalo=3, segundos=600, empresa=emp, aprobo=ap))
    conectada = _Respuesta(200, sinc._sobre_conexion("conectada", token="fcr_" + secrets.token_urlsafe(32), terminal=7, nombre="Caja 2", revinculada=False,
                                                     empresa=emp, credenciales={}, roles=[], aprobo=ap,
                                                     usuarios=[{"correo": aprobo, "nombre": "Dueña", "rol": "Administrador"}]))
    return aprobada, conectada


def _con_cedula(ced: str) -> list:
    with Session(engine) as sc:
        return [e.id for e in sc.exec(select(Empresa).where(Empresa.id > _BASE[0]).order_by(Empresa.id)).all() if sinc._digitos(e.numero_id) == ced]


def test_u5_otra_empresa_vuelve_a_usar_la_que_dejo_un_intento_que_no_termino(monkeypatch):
    """«Conectar otra empresa» crea la empresa local antes de vincularla. Si la vinculación falla y el intento se cancela («Empezar de
    nuevo») o se pierde, esa empresa vacía no puede contar como «ya está en esta computadora» (nadie puede abrirla): el intento siguiente
    la vuelve a usar."""
    eid_a, ta = _admin_empresa("-u9bh1a", "3101429551")
    eid_l, tl = _admin_empresa("-u9bh1l", "3101429551")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    antes, ced = _cfg(eid_l), "3101429552"
    aprobada, conectada = _otra_simulada("3-101-429552", "duena-sinc49-u9bh1l@example.test", "Otra QA-u9bh1")
    # primer intento: aprobada y confirmada; la empresa local nace, pero la vinculación no se puede guardar (disco, antivirus…)
    j1 = _iniciar_otra(H(tl)).json()
    shim.por_ruta[RECOGER] = aprobada
    assert _estado(j1["intento"], H(tl)).json()["estado"] == "confirmar"
    shim.por_ruta[RECOGER] = conectada

    def sin_disco(*a, **k):
        raise OSError("disco lleno")
    with monkeypatch.context() as m:
        m.setattr(sinc, "_aplicar_vinculacion", sin_disco)
        v = _confirmar(j1["intento"], "123", cab=H(tl)).json()
    assert v["estado"] == "fallo", v
    huerfana = _con_cedula(ced)
    assert len(huerfana) == 1 and not _cfg(huerfana[0]) and not _membresias(huerfana[0])       # quedó creada, vacía y sin nadie
    # mientras ese intento siga vivo (puede reintentar solo), la empresa es suya: otro intento no la toma
    _limpiar_limitador()
    j2 = _iniciar_otra(H(tl)).json()
    shim.por_ruta[RECOGER] = aprobada
    assert _estado(j2["intento"], H(tl)).json()["estado"] == "ya_esta"
    # «Empezar de nuevo» suelta el intento que falló (la empresa creada sigue ahí)
    assert c.post("/api/sinc/local/conexion/cancelar", headers=H(tl), json={"intento": j1["intento"]}).status_code == 200
    assert j1["intento"] not in sinc._conexiones and _con_cedula(ced) == huerfana
    # el intento siguiente ya no termina en «ya está»: confirma y se aplica sobre ESA empresa (no nace otra)
    _limpiar_limitador()
    j3 = _iniciar_otra(H(tl)).json()
    shim.por_ruta[RECOGER] = aprobada
    v = _estado(j3["intento"], H(tl)).json()
    assert v["estado"] == "confirmar" and v["empresa"]["numero_id"] == "3-101-429552", v
    shim.por_ruta[RECOGER] = _otra_simulada("3-101-429552", "duena-sinc49-u9bh1l@example.test", "Otra QA-u9bh1")[1]
    v = _confirmar(j3["intento"], "123", cab=H(tl)).json()
    assert v["estado"] == "lista" and v["otra_empresa"] is True and v["empresa_id"] == huerfana[0], v
    assert _con_cedula(ced) == huerfana
    cfg = _cfg(huerfana[0])
    assert cfg["vinculado"] and cfg["terminal"] == 7 and cfg["origen"] == "conexion" and cfg["primera"]["membresias"]
    assert [m.rol for m in _membresias(huerfana[0])] == ["Administrador"]
    despues = _cfg(eid_l)
    assert all(despues.get(k) == antes.get(k) for k in ("vinculado", "token", "terminal", "url", "sucursal", "nombre"))     # la primera, intacta
    # ahora sí está en esta computadora (vinculada): otro «Conectar otra empresa» para ella termina en «ya está»
    _limpiar_limitador()
    j4 = _iniciar_otra(H(tl)).json()
    shim.por_ruta[RECOGER] = aprobada
    assert _estado(j4["intento"], H(tl)).json()["estado"] == "ya_esta"


def test_u5_cuales_empresas_cuentan_como_ya_esta_en_esta_computadora(monkeypatch):
    """Función real, con cédulas que solo usa esta prueba. No cuenta (y se vuelve a usar) la empresa con esa cédula que no tiene ninguna
    membresía, no está vinculada, no tiene comprobantes y no la tiene tomada un intento vivo; cualquier otra cuenta."""
    from app.db import Documento

    def nueva(ced: str) -> int:
        with Session(engine) as sc:
            return auth.crear_empresa(sc, "Local9b QA-h1 " + ced, "", ced).id

    def ya_esta(ced: str) -> bool:
        return sinc._ya_esta({"empresa": {"numero_id": ced[:1] + "-" + ced[1:4] + "-" + ced[4:]}})

    def miembro(eid: int, correo: str, clave: str) -> None:
        with Session(engine) as sc:
            u = auth.Usuario(correo=correo, nombre="QA", password_hash=clave, terminos_version=auth.TERMINOS_VERSION, de_nube=True)
            sc.add(u); sc.commit(); sc.refresh(u)
            sc.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=eid, rol="Cajero")); sc.commit()
    assert ya_esta("3101429560") is False                                   # no hay ninguna
    vacia = nueva("3101429561")                                             # la que dejó un intento que no terminó
    with Session(engine) as sc:
        assert sinc._empresa_con_cedula(sc, "3101429561") is None and sinc._huerfanas(sc, "3101429561") == [vacia]
    assert ya_esta("3101429561") is False
    deshecha = nueva("3101429562")                                          # E-10: conexión deshecha (sin membresías ni token, con la terminal anotada)
    _poner_cfg(deshecha, vinculado=False, terminal=5)
    assert ya_esta("3101429562") is False
    for tomada in ({"eid_destino": deshecha}, {"eid": deshecha}):           # un intento vivo se la está aplicando, o alguien la tiene abierta
        sinc._conexiones["qa-h1"] = {"estado": "fallo", **tomada}
        try:
            assert ya_esta("3101429562") is True
            sinc._conexiones["qa-h1"]["estado"] = "cancelada"
            assert ya_esta("3101429562") is False
        finally:
            sinc._conexiones.pop("qa-h1", None)
    miembro(deshecha, "sin-entrar-u9bh1@example.test", sinc.HASH_INSERVIBLE)   # con una membresía, aunque todavía no pueda entrar: ya está
    assert ya_esta("3101429562") is True
    vinculada = nueva("3101429563")
    _poner_cfg(vinculada, vinculado=True, terminal=5)
    assert ya_esta("3101429563") is True
    con_docs = nueva("3101429564")
    with Session(engine_empresa(con_docs)) as s:
        s.add(Documento(empresa_id=con_docs, tipo_documento="04", clave=f"506{9:047d}", consecutivo=f"00100002040{9:09d}",
                        fecha_emision="2026-11-10T08:00:00-06:00", estado="firmado", ambiente="sandbox", moneda="CRC", tipo_cambio=1, total=1000))
        s.commit()
    assert ya_esta("3101429564") is True
    con_gente = nueva("3101429565")
    miembro(con_gente, "entra-u9bh1@example.test", auth.hash_password(PW))
    assert ya_esta("3101429565") is True
    def sin_leer(eid):
        raise OSError("antivirus")
    monkeypatch.setattr(sinc, "_tiene_datos", sin_leer)                     # no se pudo leer la empresa: cuenta como que ya está
    assert ya_esta("3101429561") is True


def test_u1_u5_conectar_otra_empresa_tambien_en_la_tarjeta_de_tengo_un_codigo():
    """El 409 de «Tengo un código» (D-P) manda a «Conectar otra empresa en esta computadora»: el enlace tiene que estar en la tarjeta donde
    está ese formulario (empresa sin vincular o revocada), no solo en la de la empresa vinculada."""
    i = _leer("pages/configuracion/instalacion-local.js")
    assert "use «Conectar otra empresa en esta computadora»" in sinc.MENSAJE_CODIGO_OTRA
    tarjeta = i[i.index('<div class="card" v-if="!est.vinculado || est.revocada_en">'):i.index('<div class="card" v-if="cuentas && cuentas.cuentas')]
    assert '@click="vincular"' in tarjeta                                    # el formulario que contesta ese 409
    enlace = ('<a v-if="est.terminal && !enCurso" class="link small" style="display:block;margin-top:12px;cursor:pointer" @click="otra = true">'
              "Conectar otra empresa en esta computadora</a>")
    # fuera de las ramas «Conectar con mi cuenta» / «Tengo un código»: se ve también con el formulario del código abierto
    assert tarjeta.index("Conectar con el código") < tarjeta.index('<template v-if="puede && !(otra && est.terminal)">') < tarjeta.index(enlace)
    # un solo camino a la vez (los dos componentes comparten el intento guardado en la pestaña)
    panel = '<div v-else-if="otra && est.terminal" style="max-width:520px">'
    assert tarjeta.index('v-if="!puede"') < tarjeta.index(panel) < tarjeta.index('<template v-else-if="!conCodigo">')
    assert tarjeta.count("<ConexionLocal ") == 2
    assert ('con-sesion otra-empresa boton="Conectar otra empresa" @lista="otraLista" @retirada="retirada" @estado="otraEstado"></ConexionLocal>\n'
            '          <a class="link small" style="display:inline-block;margin-top:10px;cursor:pointer" @click="volverDeOtra">Volver</a>') in tarjeta   # 9c (J11): «Volver» cancela el intento
    # una empresa que nunca se conectó (las cuentas de la computadora todavía entran: E-13): no se ofrece; se explica el orden
    assert ('<p v-else-if="!est.terminal" class="small muted" style="margin:12px 0 0">Para agregar otra empresa a esta computadora, conecte primero esta '
            "empresa con «Conectar con mi cuenta». Después aparece aquí «Conectar otra empresa en esta computadora».</p>") in tarjeta
    # la tarjeta de la empresa vinculada sigue igual
    vinculada = i[i.index('<div class="card" v-if="est.vinculado && !est.revocada_en">'):i.index("<h2>Red local")]
    assert ('<a v-if="!otra" class="link small" style="display:inline-block;margin-top:12px;cursor:pointer" @click="otra = true">Conectar otra empresa en '
            "esta computadora</a>") in vinculada and vinculada.count("<ConexionLocal ") == 1


FALSO_API_INSTALACION = "export const toast = () => {};\nexport const fechaHora = x => x;\nexport const api = async () => ({});\n"
FALSO_APP_INSTALACION = "export const sesion = { puede: () => true, usuario: { de_nube: true }, cerrar() {} };\n"


def test_u5_la_pantalla_distingue_el_intento_de_otra_empresa_en_node(tmp_path):
    """La tarjeta de conectar de nuevo tiene los dos caminos («Conectar con mi cuenta» y «Conectar otra empresa») y el componente guarda
    UN intento por pestaña: la marca dice de cuál es, y mientras haya un intento a medias no se ofrece cambiar de camino."""
    from tests.test_424_etiquetas import _node
    r = _node(tmp_path, """
const mem = {};
globalThis.sessionStorage = { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } };
const C = (await import('./js/pages/configuracion/instalacion-local.js')).default;
function montar() { const vm = {}; Object.assign(vm, C.data.call(vm)); for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm); vm.cargar = () => {}; return vm; }
const out = {};
let vm = montar(); out.vacio = [vm.otra, vm.enCurso];
// «Conectar con mi cuenta» a medias (sin marca): al recargar NO se abre «Conectar otra empresa» ni se ofrece cambiar de camino
mem['conexion:intento'] = 'abc'; vm = montar(); out.principal = [vm.otra, vm.enCurso];
vm.estadoConexion('esperando'); out.principal.push(vm.enCurso, mem['conexion:otra'] === undefined);
// «Conectar otra empresa» empezado (el componente guardó su intento y avisa el estado): queda la marca y al recargar se vuelve a abrir
vm = montar(); vm.otra = true; mem['conexion:intento'] = 'xyz'; vm.otraEstado('esperando');
out.otra = [vm.otra, vm.enCurso, mem['conexion:otra']]; vm = montar(); out.otra.push(vm.otra, vm.enCurso);
// se canceló (el componente ya borró su intento): se cierra y se puede volver a elegir camino
delete mem['conexion:intento']; vm.otraEstado('cancelada'); out.cancelada = [vm.otra, vm.enCurso, mem['conexion:otra']];
vm = montar(); out.cancelada.push(vm.otra, vm.enCurso);
// una marca vieja no vale para un intento nuevo de «Conectar con mi cuenta»
mem['conexion:otra'] = 'xyz'; mem['conexion:intento'] = 'nuevo'; vm = montar(); out.vieja = [vm.otra, vm.enCurso];
delete mem['conexion:intento']; vm.estadoConexion('cancelada'); out.vieja.push(vm.enCurso);
console.log(JSON.stringify(out));
""", archivos=(("pages", "configuracion", "instalacion-local.js"),),
              falsos={"api.js": FALSO_API_INSTALACION, "app.js": FALSO_APP_INSTALACION, "conexion-local.js": "export default {};\n"})
    assert r["vacio"] == [False, False], r
    assert r["principal"] == [False, True, True, True], r
    assert r["otra"] == [True, True, "xyz", True, True], r
    assert r["cancelada"] == [False, False, "", False, False], r
    assert r["vieja"] == [False, True, False], r


# ------------------------------------------------------------------------------------------------------------------------ U6
def test_u6_numero_errado_durante_la_retencion_se_dice_en_el_momento(monkeypatch):
    eid_n, ta = _admin_empresa("-u9b6", "3101429601")
    _programa(monkeypatch, retencion=300)
    j = _iniciar().json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    assert a["retenida"] is True
    assert _estado(j["intento"]).json()["estado"] == "retenida"
    retener = _pase(id=a["pase"]).retener_hasta
    otro = "100" if a["numero"] != "100" else "101"
    v = _confirmar(j["intento"], otro).json()
    assert v["estado"] == "retenida" and v["error"] == sinc.MENSAJES_LOCAL["numero_errado"] and v["intentos_restantes"] == 2 and v["numero_escrito"] is False, v
    p = _pase(id=a["pase"])
    assert p.intentos == 1 and p.estado == "aprobado" and p.retener_hasta == retener and p.token_id is None      # nada se entregó ni se acortó
    v = _confirmar(j["intento"], a["numero"]).json()                       # el bueno: sigue retenida hasta que termine la espera
    assert v["estado"] == "retenida" and v["numero_escrito"] is True and not v.get("error"), v
    _poner_pase(a["pase"], retener_hasta=time.time() - 1)
    assert _estado(j["intento"]).json()["estado"] == "lista"
    # tres errados durante la retención: anulado
    _soltar_programa()
    _limpiar_limitador()
    j = _iniciar().json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    _estado(j["intento"])
    otro = "100" if a["numero"] != "100" else "101"
    for _ in range(3):
        v = _confirmar(j["intento"], otro).json()
    assert v["estado"] == "anulada" and "anuló" in v["mensaje"], v
    assert _pase(id=a["pase"]).estado == "anulado"


# ------------------------------------------------------------------------------------------------------------------------ U7
def test_u7_la_pagina_web_con_su_puerto(monkeypatch):
    monkeypatch.delenv("FE_SINC_HTTP", raising=False)                       # conftest la enciende para las nubes simuladas por http
    for url, web, pagina in (("http://127.0.0.1:8055", "127.0.0.1:8055", "http://127.0.0.1:8055"), ("https://fisitaap.com", "fisitaap.com", "https://fisitaap.com"),
                             ("https://[::1]:8443", "[::1]:8443", "https://[::1]:8443"), ("http://nube49", "nube49", None), ("", "la página web", None)):
        monkeypatch.setattr(sinc, "URL_NUBE", url)
        assert sinc._web() == web and sinc.pagina_web() == pagina, url
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    monkeypatch.setattr(sinc, "URL_NUBE", "http://127.0.0.1:8055")
    loc = c.get("/api/auth/estado").json()["local"]
    assert loc["web"] == "127.0.0.1:8055" and loc["pagina"] == "http://127.0.0.1:8055"
    lg = _leer("pages/login.js")
    assert "if (l && !l.admin_local && !j.pagina_web && l.pagina) j.pagina_web = l.pagina;" in lg and "'https://' + l.web" not in lg


# ------------------------------------------------------------------------------------------------------------------------ U9
def test_u9_textos_del_programa(monkeypatch):
    lg = _leer("pages/login.js")
    assert "if (l && l.vinculada && !l.admin_local) return 'Entre con el correo y la contraseña de su cuenta de ' + (l.web || 'la página web') + '.';" in lg
    assert "return 'Ingrese con el correo y la contraseña que le entregó el administrador.';" in lg       # la web, como siempre
    assert '<p class="muted small" style="margin:0 0 18px">{{subtitulo}}</p>' in lg
    a = _leer("app.js")
    franja = a[a.index('v-if="sesion.empresaInfo?.instalacion"><b>Esta instalación fue revocada en la nube.</b>'):]
    franja = franja[:franja.index("</div>")]
    assert ('Para seguir, un administrador la conecta de nuevo en <a href="#/configuracion/instalacion-local">Configuración › Instalación local</a> '
            "(«Conectar con mi cuenta»).") in franja
    assert "código" not in franja and ">Vincular de nuevo</a>" not in franja
    cx = _leer("conexion-local.js")
    assert ('<template v-if="v.reconexion"> Cada persona tiene que entrar una vez con su contraseña, con internet, para volver a usar su PIN y poder entrar '
            "sin internet en esta computadora.</template>") in cx
    # el servidor marca la reconexión (la empresa ya había estado conectada aquí)
    eid_n, ta = _admin_empresa("-u9b9n", "3101429901")
    eid_l, tl = _admin_empresa("-u9b9l", "3101429901")
    _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    j = _iniciar("Caja", H(tl)).json()
    a = _aprobar(ta, j["codigo"], eid_n).json()
    _estado(j["intento"], H(tl))
    v = _confirmar(j["intento"], a["numero"], cab=H(tl)).json()
    assert v["estado"] == "lista" and v["reconexion"] is True and v["otra_empresa"] is False, v


# ------------------------------------------------------------------------------------------------------------------------ U10
def test_u10_sin_palabras_tecnicas_en_instalacion_local_de_la_web():
    i = _leer("pages/configuracion/instalacion-local.js")
    web = i[i.index('<template v-else-if="est">'):]
    assert "Cada computadora trabaja con una llave propia de la empresa, que no depende de ninguna persona; se administra solo aquí." in web
    assert "token" not in web.split("<details", 1)[0].lower()
    assert '<div class="small muted">Identificador: <span class="mono">{{i.prefijo}}…</span></div>' in web


# ------------------------------------------------------------------------------------------------------------------------ U11
def test_u11_el_error_de_conexion_guardado_es_texto_llano(monkeypatch, caplog):
    eid_a, ta = _admin_empresa("-u9b11n", "3101429111")
    eid_l, tl = _admin_empresa("-u9b11l", "3101429112")
    shim = _programa(monkeypatch, sin_estrenar=False)
    _vincular(monkeypatch, ta, tl, "Caja")
    falla = httpx.ConnectError("[WinError 10061] No connection could be made because the target machine actively refused it")
    for ruta in ("/api/sinc/usuarios", "/api/sinc/novedades", "/api/sinc/catalogo", "/api/sinc/documentos", "/api/sinc/cambios", "/api/sinc/credenciales"):
        shim.por_ruta[ruta] = falla
    est = sinc.sincronizar(eid_l)
    assert est["ultimo_error"] == "Sin conexión con la página web: se vuelve a intentar sola.", est["ultimo_error"]
    assert _cfg(eid_l).get("sin_conexion_desde")
    assert "ConnectError" in caplog.text and "WinError" not in str(_cfg(eid_l))


# ------------------------------------------------------------------------------------------------------------------------ U12
def test_u12_tope_general_de_ingresos_en_el_programa(monkeypatch):
    llamadas = []
    real = auth.limitar_ip

    def anotar(request, clave="auth", maximo=None, ventana=None, mensaje=None, sujeto=None, registrar=True):
        if clave == "login":
            llamadas.append((maximo, ventana))
        return real(request, clave, maximo, ventana, mensaje, sujeto, registrar)
    monkeypatch.setattr(auth, "limitar_ip", anotar)
    assert c.post("/api/auth/login", json={"correo": "nadie-u9b12@example.test", "password": PW}).status_code == 401
    assert llamadas[-1] == auth.LIMITE_IP == (30, 300)                     # la web, como siempre
    monkeypatch.setenv("FE_MODO_LOCAL", "1")
    assert auth._tope_ingreso() == auth.LIMITE_IP_PROGRAMA == (150, 300)
    assert c.post("/api/auth/login", json={"correo": "nadie-u9b12@example.test", "password": PW}).status_code == 401
    assert llamadas[-1] == (150, 300)
    assert c.post("/api/auth/pin/entrar", json={"correo": "nadie-u9b12@example.test", "pin": "4827"}).status_code == 401
    assert llamadas[-1] == (150, 300)
    assert auth.MAX_INTENTOS == 5 and auth.MINUTOS_BLOQUEO == 15 and auth.PIN_MAX_FALLOS == 10   # la espera por cuenta y el PIN no cambian


# ------------------------------------------------------------------------------------------------------------------------ U13 y U17
def test_u13_u17_pantalla_conectar_de_la_web():
    cn = _leer("pages/conectar.js")
    assert "this.aprobada = { ...r, empresa_id: this.elegida.id };" in cn
    assert '@click="verComputadoras" v-if="!avisoOtra">Ver las computadoras conectadas</button>' in cn
    ver = cn[cn.index("    async verComputadoras() {"):cn.index("    async buscar() {")]
    assert ver.index("if (!sesion.empresa_id && eid) {") < ver.index("await sesion.cambiarEmpresa(eid);") < ver.index("location.hash = '/configuracion/instalacion-local'")
    assert "if (sesion.empresa_id && eid && eid !== sesion.empresa_id) {" in ver and "this.avisoOtra = 'La computadora quedó conectada a '" in ver
    # U17: un código nuevo del enlace manda sobre el pase guardado; «Salir» de un pase viejo no lo borra
    cr = cn[cn.index("  async created() {"):cn.index("  beforeUnmount()")]
    assert cr.index("if (this.escrito) { conexion.fijarPase(''); await this.buscar(); return; }") < cr.index("const pid = conexion.leerPase();")
    salir = cn[cn.index("    salir(destino) {"):cn.index("    olvidarCodigo() {")]
    assert salir.index("if (this.codigoNuevo()) { this.seguirConNuevo(); return; }") < salir.index("conexion.limpiar();")


FALSO_API_CONECTAR = """
export const toast = () => {};
export const api = async (url, opt) => {
  globalThis.Q.pedidos.push([url, opt && opt.body]);
  if (url === '/api/auth/estado') return {};
  if (url === '/api/sinc/conexion/seguimiento') return { estado: 'aprobada' };
  return { codigo: opt.body.codigo, nombre: 'Caja', empresas: [] };
};
"""
FALSO_APP_CONECTAR = """
export const sesion = { empresa_id: null, puede: () => false };
export const conexion = { codigo: '', limpiado: false, fijar(c) { this.codigo = c; }, limpiar() { this.limpiado = true; this.codigo = ''; },
  leerPase() { return globalThis.Q.pase; }, fijarPase(p) { globalThis.Q.pase = p || null; } };
"""


def test_u17_codigo_nuevo_y_salir_en_node(tmp_path):
    from tests.test_424_etiquetas import _node
    r = _node(tmp_path, """
globalThis.Q = { pedidos: [], pase: 9, hash: '' };
globalThis.location = { set hash(v) { Q.hash = v; }, get hash() { return Q.hash; } };
globalThis.history = { replaceState() {} };
const C = (await import('./js/pages/conectar.js')).default;
const { conexion } = await import('./js/app.js');
function montar() {
  const vm = { $nextTick: f => f && f() };
  Object.assign(vm, C.data.call(vm));
  for (const [k, f] of Object.entries(C.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm) });
  for (const [k, f] of Object.entries(C.methods)) vm[k] = f.bind(vm);
  return vm;
}
const out = {};
// llega un código nuevo en el enlace y la pestaña tenía un pase guardado: se busca el código y el pase se olvida
conexion.codigo = 'ABCD-EFGH'; Q.pase = 9;
let vm = montar(); await C.created.call(vm); clearInterval(vm._reloj);
out.creado = [vm.paso, Q.pedidos.map(x => x[0]), Q.pase];
// sin código nuevo: se retoma el pase guardado
conexion.codigo = ''; Q.pase = 9; Q.pedidos = [];
vm = montar(); await C.created.call(vm); clearInterval(vm._reloj); vm.parar();
out.retomado = [vm.paso, vm.retomado, Q.pedidos.map(x => x[0])];
// siguiendo un pase viejo llega otro código: «Salir» no lo borra, sigue con él
conexion.codigo = 'JKLM-NPQR'; Q.pedidos = [];
vm.salir();
await new Promise(r => setTimeout(r, 0));
out.salir = [conexion.codigo, conexion.limpiado, Q.pase, vm.paso, Q.pedidos.map(x => x[0])];
console.log(JSON.stringify(out));
process.exit(0);
""", archivos=(("pages", "conectar.js"),), falsos={"api.js": FALSO_API_CONECTAR, "app.js": FALSO_APP_CONECTAR})
    assert r["creado"] == ["revisar", ["/api/auth/estado", "/api/sinc/conexion/consultar"], None], r
    assert r["retomado"] == ["aprobada", True, ["/api/auth/estado", "/api/sinc/conexion/seguimiento"]], r
    assert r["salir"] == ["JKLM-NPQR", False, None, "revisar", ["/api/sinc/conexion/consultar"]], r


# ------------------------------------------------------------------------------------------------------------------------ U14 y U15
def test_u14_u15_ruta_de_items_de_la_web_audita_y_respeta_el_plan(monkeypatch):
    from app import planes
    from app.db import DocumentoLinea
    from test_425_items_web_desde_programa import RUTA, _item, _p
    from test_425_xml_lote import _canje
    eid_a, ta = _admin_empresa("-u9b14", "3101429141")
    tok, _terminal = _canje(ta)
    libre, vendido = _item(ta, "Libre U14"), _item(ta, "Vendido U14", "QA-U14-VEN")
    with Session(engine_empresa(eid_a)) as s:
        s.add(DocumentoLinea(documento_id=987914, numero=1, producto_id=vendido, cabys="8311000000000", detalle="QA", cantidad=1, unidad_medida="Sp", precio_unitario=1000))
        s.commit()
    r = c.post(RUTA, headers=H(tok), json={"operacion": "eliminar", "id": libre, "por": "Caja U14"})
    assert r.status_code == 200 and _p(eid_a, libre) is None, r.text
    r = c.post(RUTA, headers=H(tok), json={"operacion": "eliminar", "id": vendido})
    assert r.status_code == 200 and r.json()["resultado"]["desactivado"] is True, r.text
    filas = [a.detalle for a in _auditorias("producto_eliminado_programa", empresa_id=eid_a)]
    assert any(f"«Libre U14» (ítem {libre}) eliminado desde el programa" in d and "[en el programa: Caja U14]" in d for d in filas), filas
    assert any(f"«Vendido U14» (ítem {vendido}) desactivado desde el programa" in d for d in filas), filas
    assert "producto_eliminado_programa: ['" in _leer("pages/configuracion/seccion.js")
    # U15: plan vencido (modo lectura) o sin el catálogo de ítems: 409 con texto llano, sin cambiar nada
    otro = _item(ta, "Otro U14")
    with monkeypatch.context() as m:
        m.setattr(planes, "vencido", lambda e: True)
        r = c.post(RUTA, headers=H(tok), json={"operacion": "editar", "id": otro, "cambios": {"precio": 5}})
    assert r.status_code == 409 and r.json()["detail"] == "El plan de la empresa está vencido: los ítems de la página web no se pueden cambiar hasta renovarlo.", r.text
    real = planes.filtrar_permisos
    with monkeypatch.context() as m:
        m.setattr(planes, "filtrar_permisos", lambda e, p, o=(): (set(p) - {"catalogos"}) if set(p or ()) == {"catalogos"} else real(e, p, o))
        r = c.post(RUTA, headers=H(tok), json={"operacion": "eliminar", "id": otro})
    assert r.status_code == 409 and r.json()["detail"] == "El plan de la empresa no incluye el catálogo de ítems.", r.text
    assert _p(eid_a, otro) is not None and _p(eid_a, otro).precio == 1000


# ------------------------------------------------------------------------------------------------------------------------ U16
FALSO_API_MONTOS = """
export const money = v => String(v), fmt = v => String(v), fecha = v => String(v), hoy = () => '2026-11-11', toast = () => {}, abrirArchivo = async () => {};
export const monedas = { principal: () => ({ codigo: 'CRC' }) };
export const mock = { get: (k, d) => d };
"""
FALSO_AGENTE_MONTOS = """
export const porAgente = i => !!i && (i.conexion === 'usb' || i.conexion === 'red');
export const cargarEquipo = async () => { globalThis.Q.cargas++; };
export const impresoraAqui = i => (globalThis.Q.cargas ? { ...i, conexion: 'usb', direccion: 'AQUI' } : i);
export const imprimirAgente = async (i) => { globalThis.Q.impresos.push([i.conexion, i.direccion]); };
"""


def test_u16_el_reporte_carga_la_impresion_de_esta_computadora(tmp_path):
    from tests.test_424_etiquetas import _node
    r = _node(tmp_path, """
globalThis.Q = { cargas: 0, impresos: [] };
globalThis.window = { open() { throw new Error('no debe abrir el navegador'); } };
const M = await import('./js/pages/reportes/_montos.js');
const IMP = { id: 1, nombre: 'Caja', uso: 'comprobante', conexion: 'red', direccion: 'EMPRESA', ancho: 80 };
const via = await M.imprimirReporte({ titulo: 'Ventas', cols: [], rows: [] }, IMP, {});
console.log(JSON.stringify({ via, cargas: Q.cargas, impresos: Q.impresos }));
""", archivos=(("pages", "reportes", "_montos.js"),), falsos={"api.js": FALSO_API_MONTOS, "app.js": "export const sesion = {};\n",
                                                            "pages/pos/_datos.js": "export const impresoras = () => [];\n",
                                                            "pages/pos/_agente.js": FALSO_AGENTE_MONTOS})
    assert r == {"via": "agente", "cargas": 1, "impresos": [["usb", "AQUI"]]}, r
    m = _leer("pages/reportes/_montos.js")
    assert "if (A.cargarEquipo) await A.cargarEquipo().catch(() => {});" in m and "await import('../pos/_agente.js')" in m


# ------------------------------------------------------------------------------------------------------------------------ U18
def test_u18_generar_codigos_separa_lo_que_la_web_no_guardo(tmp_path):
    from tests.test_424_etiquetas import _node
    from tests.test_424_pulido import ARCHIVOS_CUADRO, FALSOS_CUADRO
    r = _node(tmp_path, """
globalThis.Q = { toasts: [], mock: {}, guardado: {}, permisos: ['catalogos'], estado: { ok: true, info: {} }, store: { cargar: async () => {} },
  api: async () => ({ cambiados: 1, sin_cambio: 0, codigos: {}, no_guardados: 1,
                      aviso: '1 producto creado en la página web no se cambió. No se pudo guardar: este ítem se creó en la página web.',
                      no_se_pudo: [{ id: 2, nombre: 'Choque', codigo: '2456', motivo: 'Ya existe otro producto con el código 2456: Otro' },
                                   { id: 3, nombre: 'De la web', codigo: '', motivo: 'No se pudo guardar', web: true }] }) };
globalThis.confirm = () => true;
globalThis.localStorage = { getItem: () => null, setItem() {} };
const { DialogoGenerarCodigos } = await import('./js/pages/inventario/_etiquetas-dialogos.js');
const vm = { productos: [{ id: 1, nombre: 'A' }, { id: 2, nombre: 'Choque' }, { id: 3, nombre: 'De la web' }], $emit() {} };
Object.assign(vm, DialogoGenerarCodigos.data.call(vm));
for (const [k, f] of Object.entries(DialogoGenerarCodigos.computed)) Object.defineProperty(vm, k, { get: () => f.call(vm) });
for (const [k, f] of Object.entries(DialogoGenerarCodigos.methods)) vm[k] = f.bind(vm);
await vm.generar();
console.log(JSON.stringify(vm.resultado));
""", archivos=ARCHIVOS_CUADRO, falsos=FALSOS_CUADRO)
    assert [x["id"] for x in r["no_se_pudo"]] == [2] and r["no_guardados"] == 1 and len(r["avisos"]) == 1 and "página web" in r["avisos"][0], r
    dlg = _leer("pages/inventario/_etiquetas-dialogos.js")
    assert '<div class="alert err small" style="margin:0 0 10px" v-for="a in (resultado.avisos || [])" :key="a">{{a}}</div>' in dlg
    assert "A estos no se les pudo generar porque su código ya lo tiene otro producto" in dlg
    assert '"web": True' in (RAIZ / "etiquetas.py").read_text(encoding="utf-8")


# ------------------------------------------------------------------------------------------------------------------------ finales de línea
def test_archivos_tocados_sin_finales_mezclados():
    tocados = ["sinc.py", "auth.py", "etiquetas.py"] + [f"static/js/{x}" for x in ("app.js", "conexion-local.js", "pages/login.js", "pages/conectar.js",
                                                                                   "pages/configuracion/instalacion-local.js", "pages/configuracion/seccion.js",
                                                                                   "pages/reportes/_montos.js", "pages/inventario/_etiquetas-dialogos.js")]
    for rel in tocados:
        b = (RAIZ / rel).read_bytes()
        assert b.count(b"\r\n") in (0, b.count(b"\n")), rel
