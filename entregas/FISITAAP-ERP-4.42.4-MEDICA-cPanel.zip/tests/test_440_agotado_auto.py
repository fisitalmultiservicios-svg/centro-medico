# -*- coding: utf-8 -*-
"""4.40: agotado automático por existencias en el catálogo en línea (pedido de una perfumería que vende solo en la web y no vende en
negativo). Con NegocioPublico.agotado_auto encendida, un ítem sale agotado cuando no le quedan unidades en la bodega de la caja que
recibe los pedidos, y el pedido no deja pedir más de lo que hay. Apagada (lo de siempre), solo cuenta la casilla manual «Agotado por
ahora». Nada se guarda: se calcula en cada lectura. Sin apartado de pedidos sin cobrar. Los servicios, los no inventariables sin
receta, los que venden en negativo y los inventariables sin fila de existencia no se agotan solos. Las recetas usan las porciones de
la bodega, pero un ingrediente sin fila cuenta como desconocido (solo en el catálogo: /recetas/porciones de la caja no cambia).
El JSON público no trae cantidades y el mensaje de «no alcanza» es uno solo y sin cifras.
4.40 (revisión adversaria): la revisión de existencias es la última validación del pedido (ningún otro error deja ver si la cantidad
alcanzaba) y con varios productos el mensaje no dice cuál; las porciones del catálogo toleran 1e-9; los ingredientes se leen en una
consulta; las existencias van en trozos de 500; el PUT del negocio sin la clave no apaga la opción."""
import contextlib
import inspect
import itertools
import pathlib
import re
import secrets
import sqlite3
import types

import pytest
from sqlalchemy import event
from sqlmodel import Session, select

from app import auth, inventario, modulos, pedidos
from app.db import Producto, engine_empresa
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)
from tests.test_pedidos import _eid, _publicar

_TEL = itertools.count(1)
CLAVES_ITEM = {"id", "nombre", "descripcion", "categoria", "precio", "foto", "destacado", "agotado", "unidad", "modificadores", "promo"}


@pytest.fixture(autouse=True)
def _sin_topes():
    """El tope de pedidos por IP (60 cada 10 min) vive en memoria del proceso: estas pruebas hacen muchos pedidos seguidos."""
    auth._intentos_ip.clear()
    yield
    auth._intentos_ip.clear()


# ------------------------------------------------------------------------------------------------- ayudantes
def _guardar(eid, clave, datos):
    """Registro de la empresa (pos_config, recetas, pos_modificadores) con su versión, para poder cambiarlo varias veces."""
    with Session(engine_empresa(eid)) as s:
        r = modulos._registro(s, eid, clave)
        modulos.reemplazar(s, eid, clave, datos, (r.version or 0) if r else None)


def _caja(eid, **t):
    """La caja 1 (la que recibe los pedidos) con su bodega o su sucursal."""
    _guardar(eid, "pos_config", {"terminales": [{"id": 1, "nombre": "Caja QA", "modo": "mostrador", **t}]})


def _abrir(c, slug, **extra):
    base = {"minimo_pedido": 0, "agotado_auto": True}
    base.update(extra)
    r = _publicar(c, slug=slug, **base); assert r.status_code == 200, r.text
    return r.json()


def _item(c, nombre, **kw):
    datos = {"nombre": nombre, "cabys": "2111100000000", "precio": 1000, "tarifa": 13, "codigo_tarifa": "08", "visible_catalogo": True, "categoria": "Perfumes"}
    datos.update(kw)
    r = c.post("/api/productos", json=datos); assert r.status_code == 200, r.text
    return r.json()


def _insumo(c, nombre):
    return _item(c, nombre, cabys="", es_venta=False, visible_catalogo=False, precio=0)


def _ajustar(c, pid, cantidad, bodega_id=None):
    r = c.post("/api/inventario/ajustes", json={"bodega_id": bodega_id, "lineas": [{"producto_id": pid, "tipo": "incremento" if cantidad > 0 else "disminucion",
                                                                                     "cantidad": abs(cantidad), "costo_unitario": 500}]})
    assert r.status_code == 200, r.text


def _en_cero(c, pid, bodega_id=None):
    """Fila de existencia en 0 (entró una unidad y salió): «agotado» de verdad, no «sin registro»."""
    _ajustar(c, pid, 1, bodega_id); _ajustar(c, pid, -1, bodega_id)


def _bodega_principal(c):
    return next(b for b in c.get("/api/inventario/bodegas").json() if b["principal"])


def _publico(c, slug, headers=None):
    r = c.get(f"/api/publico/{slug}", headers=headers or {}); assert r.status_code == 200, r.text
    return r.json()


def _agotados(c, slug, headers=None) -> dict:
    return {i["id"]: i["agotado"] for i in _publico(c, slug, headers)["items"]}


def _pedir(c, slug, lineas, headers=None, **extra):
    body = {"nombre": "Cliente QA", "telefono": "8%07d" % next(_TEL), "tipo": "recoger", "lineas": lineas}
    body.update(extra)
    return c.post(f"/api/publico/{slug}/pedido", json=body, headers=headers or {})


def _detalle(r) -> str:
    d = r.json().get("detail")
    return d if isinstance(d, str) else str(d)


def _n_bodegas(eid) -> int:
    with Session(engine_empresa(eid)) as s:
        return len(s.exec(select(inventario.Bodega).where(inventario.Bodega.empresa_id == eid)).all())


# ------------------------------------------------------------------------------------------------- opción apagada y encendida
def test_opcion_apagada_queda_como_hoy(api):  # noqa: F811
    c = api
    perfume = _item(c, "Perfume Ámbar")
    manual = _item(c, "Perfume Manual", agotado=True, cantidad_inicial=5)
    _en_cero(c, perfume["id"])
    r = _publicar(c, slug="agot-440-apagada", minimo_pedido=0); assert r.status_code == 200, r.text
    assert r.json()["agotado_auto"] is False                                  # por omisión, apagada
    ag = _agotados(c, "agot-440-apagada")
    assert ag[perfume["id"]] is False and ag[manual["id"]] is True             # en 0 sigue disponible; la casilla manual agota
    r = _pedir(c, "agot-440-apagada", [{"producto_id": perfume["id"], "cantidad": 3}]); assert r.status_code == 200, r.text
    r = _pedir(c, "agot-440-apagada", [{"producto_id": manual["id"], "cantidad": 1}]); assert r.status_code == 400 and "agotado por ahora" in _detalle(r)


def test_opcion_encendida_agota_y_vuelve_sola(api):  # noqa: F811
    c = api; eid = _eid()
    a = _item(c, "Perfume Cedro")
    b = _item(c, "Perfume Vainilla")
    neg = _item(c, "Perfume Negativo", cantidad_inicial=1)
    manual = _item(c, "Perfume Manual", agotado=True, cantidad_inicial=5)
    _en_cero(c, a["id"]); _en_cero(c, b["id"])
    _abrir(c, "agot-440-encendida")
    ag = _agotados(c, "agot-440-encendida")
    assert ag[a["id"]] is True and ag[b["id"]] is True and ag[neg["id"]] is False and ag[manual["id"]] is True
    r = _pedir(c, "agot-440-encendida", [{"producto_id": a["id"], "cantidad": 1}])
    assert r.status_code == 400 and "Perfume Cedro" in _detalle(r) and "unidades suficientes" in _detalle(r), r.text
    # una compra (a) y un ajuste (b) que suman unidades lo devuelven a disponible
    r = c.post("/api/inventario/compras", json={"lineas": [{"producto_id": a["id"], "cantidad": 4, "costo_unitario": 900}]}); assert r.status_code == 200, r.text
    _ajustar(c, b["id"], 2)
    ag = _agotados(c, "agot-440-encendida")
    assert ag[a["id"]] is False and ag[b["id"]] is False and ag[manual["id"]] is True   # la casilla manual sigue mandando con existencias
    r = _pedir(c, "agot-440-encendida", [{"producto_id": a["id"], "cantidad": 4}]); assert r.status_code == 200, r.text
    # sin apartado: el pedido sin cobrar no rebaja ni aparta (el inventario baja al cobrar en la caja)
    assert _agotados(c, "agot-440-encendida")[a["id"]] is False
    # una existencia negativa (ventas subidas con permitir_negativo) también cuenta como agotada
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, neg["id"])
        inventario.registrar_movimiento(s, producto=p, bodega_id=inventario.bodega_principal(s, eid).id, tipo="venta", cantidad=-3, fecha="2026-11-17",
                                        permitir_negativo=True)
        s.commit()
    assert _agotados(c, "agot-440-encendida")[neg["id"]] is True


def test_lo_que_no_se_agota_solo(api):  # noqa: F811
    c = api; eid = _eid()
    vn = _item(c, "Perfume a pedido", venta_negativo=True)
    serv = _item(c, "Envoltura de regalo", es_servicio=True, tipo="Servicio")
    no_inv = _item(c, "Muestra sin control", inventariable=False)
    combo = _item(c, "Combo Navidad", tipo="Combo", inventariable=False)                     # combo de Inventario › Ítems: sin receta
    sin_fila = _item(c, "Perfume nunca cargado")
    _en_cero(c, vn["id"])
    viejo = _item(c, "Perfume que dejó de controlarse")                                      # fila en 0 de cuando era inventariable
    _en_cero(c, viejo["id"])
    with Session(engine_empresa(eid)) as s:
        p = s.get(Producto, viejo["id"]); p.inventariable = False; s.add(p); s.commit()
    _abrir(c, "agot-440-no-solo")
    ag = _agotados(c, "agot-440-no-solo")
    for x in (vn, serv, no_inv, combo, sin_fila, viejo):
        assert ag[x["id"]] is False, x["nombre"]
    r = _pedir(c, "agot-440-no-solo", [{"producto_id": vn["id"], "cantidad": 50}]); assert r.status_code == 200, r.text      # vender en negativo: cualquier cantidad
    r = _pedir(c, "agot-440-no-solo", [{"producto_id": sin_fila["id"], "cantidad": 30}, {"producto_id": serv["id"], "cantidad": 2},
                                       {"producto_id": no_inv["id"], "cantidad": 9}, {"producto_id": combo["id"], "cantidad": 3}, {"producto_id": viejo["id"], "cantidad": 2}])
    assert r.status_code == 200, r.text


# ------------------------------------------------------------------------------------------------- recetas
def test_recetas_porciones_y_caja_sin_cambios(api):  # noqa: F811
    c = api; eid = _eid()
    harina, queso, carne = _insumo(c, "Harina"), _insumo(c, "Queso"), _insumo(c, "Carne")
    albahaca, sal = _insumo(c, "Albahaca"), _insumo(c, "Sal")                                # sin fila de existencia nunca
    _ajustar(c, harina["id"], 4); _ajustar(c, queso["id"], 1); _en_cero(c, carne["id"])
    platos = {n: _item(c, n, inventariable=False, categoria="Platos") for n in ("Pizza", "Calzone", "Focaccia", "Lasaña")}
    ing = {"Pizza": [(harina, 2), (queso, 0.5)], "Calzone": [(harina, 1), (albahaca, 1)], "Focaccia": [(sal, 1)], "Lasaña": [(carne, 1)]}
    _guardar(eid, "recetas", [{"id": platos[n]["id"], "producto_id": platos[n]["id"], "rendimiento": 1,
                               "ingredientes": [{"producto_id": x["id"], "cantidad": q} for x, q in ing[n]]} for n in platos])
    _abrir(c, "agot-440-recetas")
    ag = _agotados(c, "agot-440-recetas")
    assert ag[platos["Lasaña"]["id"]] is True                                  # un ingrediente en 0 agota el plato
    assert ag[platos["Pizza"]["id"]] is False                                  # alcanza para 2 porciones
    assert ag[platos["Calzone"]["id"]] is False and ag[platos["Focaccia"]["id"]] is False   # ingrediente sin fila: desconocido, NO agota
    r = _pedir(c, "agot-440-recetas", [{"producto_id": platos["Pizza"]["id"], "cantidad": 3}]); assert r.status_code == 400 and "Pizza" in _detalle(r), r.text
    r = _pedir(c, "agot-440-recetas", [{"producto_id": platos["Pizza"]["id"], "cantidad": 2}]); assert r.status_code == 200, r.text
    r = _pedir(c, "agot-440-recetas", [{"producto_id": platos["Focaccia"]["id"], "cantidad": 40}]); assert r.status_code == 200, r.text
    r = _pedir(c, "agot-440-recetas", [{"producto_id": platos["Calzone"]["id"], "cantidad": 5}]); assert r.status_code == 400, r.text   # la harina alcanza para 4
    # la caja (/recetas/porciones) sigue igual que antes de la 4.40: un ingrediente sin fila cuenta 0
    esperado = {str(platos["Pizza"]["id"]): 2, str(platos["Calzone"]["id"]): 0, str(platos["Focaccia"]["id"]): 0, str(platos["Lasaña"]["id"]): 0}
    r = c.get("/api/inventario/recetas/porciones"); assert r.status_code == 200 and r.json() == esperado, r.text
    bp = _bodega_principal(c)["id"]
    assert c.get(f"/api/inventario/recetas/porciones?bodega_id={bp}").json() == esperado
    otra = c.post("/api/inventario/bodegas", json={"nombre": "Bodega vacía"}).json()
    assert c.get(f"/api/inventario/recetas/porciones?bodega_id={otra['id']}").json() == {k: 0 for k in esperado}
    with Session(engine_empresa(eid)) as s:
        assert {str(k): v for k, v in inventario.porciones_bodega(s, eid, bp).items()} == esperado
        assert inventario.porciones_bodega(s, eid, bp, sin_fila_desconocido=True) == {platos["Pizza"]["id"]: 2, platos["Calzone"]["id"]: 4, platos["Lasaña"]["id"]: 0}


# ------------------------------------------------------------------------------------------------- pedir más de lo que hay
def test_pedir_mas_de_lo_que_hay_mensaje_unico_sin_cifras(api):  # noqa: F811
    c = api; eid = _eid()
    dos = _item(c, "Perfume Rosa", cantidad_inicial=2)
    cero = _item(c, "Perfume Lirio")
    _en_cero(c, cero["id"])
    _guardar(eid, "pos_modificadores", [{"id": 1, "nombre": "Presentación", "minimo": 0, "maximo": 1, "productos": [dos["id"]],
                                         "opciones": [{"id": 11, "nombre": "Con caja de regalo", "precio": 500}, {"id": 12, "nombre": "Sin caja", "precio": 0}]}])
    _abrir(c, "agot-440-mas")
    assert _agotados(c, "agot-440-mas")[dos["id"]] is False
    r_parcial = _pedir(c, "agot-440-mas", [{"producto_id": dos["id"], "cantidad": 3}]); assert r_parcial.status_code == 400, r_parcial.text
    # dos líneas del mismo perfume (los opcionales separan líneas) que suman 3: también 400
    r = _pedir(c, "agot-440-mas", [{"producto_id": dos["id"], "cantidad": 2, "opciones": [11]}, {"producto_id": dos["id"], "cantidad": 1, "opciones": [12]}])
    assert r.status_code == 400 and _detalle(r) == _detalle(r_parcial), r.text
    r_cero = _pedir(c, "agot-440-mas", [{"producto_id": cero["id"], "cantidad": 1}]); assert r_cero.status_code == 400, r_cero.text
    # el mismo mensaje si falta todo o solo una parte, y sin la cantidad que queda (no se deduce probando pedidos más chicos)
    m_parcial, m_cero = _detalle(r_parcial), _detalle(r_cero)
    assert m_parcial.replace("Perfume Rosa", "{}") == m_cero.replace("Perfume Lirio", "{}")
    assert m_parcial == "Ya no hay unidades suficientes de «Perfume Rosa» para entrega inmediata. Baja la cantidad o quítalo del carrito."
    assert not re.search(r"\d", m_parcial) and not re.search(r"\d", m_cero)
    # lo justo sí pasa (2 de 2, con o sin opcionales)
    r = _pedir(c, "agot-440-mas", [{"producto_id": dos["id"], "cantidad": 1, "opciones": [11]}, {"producto_id": dos["id"], "cantidad": 1}]); assert r.status_code == 200, r.text


# ------------------------------------------------------------------------------------------------- bodega
def test_bodega_de_la_caja_que_recibe_los_pedidos(api):  # noqa: F811
    c = api; eid = _eid()
    a = _bodega_principal(c)
    b = c.post("/api/inventario/bodegas", json={"nombre": "Bodega B"}).json()
    p = _item(c, "Perfume Sándalo")
    _ajustar(c, p["id"], 3, b["id"])
    r = c.post("/api/inventario/transferencias", json={"origen_id": b["id"], "destino_id": a["id"], "lineas": [{"producto_id": p["id"], "cantidad": 3}]})
    assert r.status_code == 200, r.text                                       # existencias solo en A; en B la fila queda en 0
    _caja(eid, bodega_id=b["id"])
    _abrir(c, "agot-440-bodega", terminal_id=1)
    assert _agotados(c, "agot-440-bodega")[p["id"]] is True                    # la caja de pedidos descuenta de B: agotado
    assert _pedir(c, "agot-440-bodega", [{"producto_id": p["id"], "cantidad": 1}]).status_code == 400
    _caja(eid, bodega_id=a["id"])
    assert _agotados(c, "agot-440-bodega")[p["id"]] is False
    # caja sin bodega: la de su sucursal, y si no tiene, la principal
    from app.sucursales import Sucursal
    with Session(engine_empresa(eid)) as s:
        suc = Sucursal(empresa_id=eid, codigo=2, nombre="Sucursal QA", bodega_id=b["id"]); s.add(suc); s.commit(); s.refresh(suc); sid = suc.id
    _caja(eid, sucursal_id=sid)
    assert _agotados(c, "agot-440-bodega")[p["id"]] is True                    # la de su sucursal (B)
    _caja(eid)
    assert _agotados(c, "agot-440-bodega")[p["id"]] is False                   # la principal (A)
    # una bodega inactiva no cuenta: la caja con B inactiva pasa a la de su sucursal (también B) y después a la principal
    r = c.put(f"/api/inventario/bodegas/{b['id']}", json={"nombre": "Bodega B", "activa": False}); assert r.status_code == 200, r.text
    _caja(eid, bodega_id=b["id"], sucursal_id=sid)
    assert _agotados(c, "agot-440-bodega")[p["id"]] is False
    v = c.get("/api/pedidos/catalogo/agotado-vista").json(); assert v["bodega"] == a["nombre"], v


def test_sin_bodega_activa_no_tiene_efecto_y_nada_crea_bodegas(api):  # noqa: F811
    c = api; eid = _eid()
    p = _item(c, "Perfume Nuevo")
    _caja(eid, bodega_id=999999)                                              # una bodega que no existe
    _abrir(c, "agot-440-sinbod", terminal_id=1)
    assert _n_bodegas(eid) == 0
    v = c.get("/api/pedidos/catalogo/agotado-vista"); assert v.status_code == 200, v.text
    assert v.json()["bodega"] is None and v.json()["agotarian"] == 0 and v.json()["total"] == 1
    assert _agotados(c, "agot-440-sinbod")[p["id"]] is False
    assert _pedir(c, "agot-440-sinbod", [{"producto_id": p["id"], "cantidad": 2}]).status_code == 200
    d = c.get("/api/pedidos/catalogo").json(); assert d["bodega"] is None and d["agotado_auto"] is True
    assert _n_bodegas(eid) == 0                                               # ni la vista previa, ni el catálogo, ni el pedido crean bodegas


# ------------------------------------------------------------------------------------------------- mayorista y mixto
def test_mayorista_y_mixto_ven_el_mismo_agotado(api):  # noqa: F811
    c = api; eid = _eid()
    p = _item(c, "Perfume Mayorista")
    hay = _item(c, "Perfume Con Unidades", cantidad_inicial=5)
    _en_cero(c, p["id"])
    cli = c.post("/api/clientes", json={"nombre": "Revendedora Perfumes", "tipo": "Cliente", "tipo_id": "01", "numero_id": "303330440", "celular": 87004401, "limite_credito": 50000}).json()
    assert cli.get("id"), cli
    cod_negocio = "QA" + secrets.token_hex(3).upper()                       # código del negocio generado al correr (no queda escrito)
    _abrir(c, "agot-440-mixto", mayorista=True, mayorista_codigo=cod_negocio, mayorista_credito=True, mayorista_mixto=True)
    assert _agotados(c, "agot-440-mixto")[p["id"]] is True                    # mixto, público sin sesión
    codigo = next(x for x in c.get("/api/pedidos/revendedoras").json() if x["contacto_id"] == cli["id"])["codigo"]
    clave = str(1000 + secrets.randbelow(9000))                               # clave de prueba generada al correr (no queda escrita)
    r = c.post("/api/publico/agot-440-mixto/cliente/acceso", json={"telefono": "87004401", "pin": clave, "codigo": codigo}); assert r.status_code == 200, r.text
    h = {"X-Cliente": r.json()["token"]}
    d = _publico(c, "agot-440-mixto", h); assert d["mayorista"] is True and d["cliente"]
    ag = {i["id"]: i["agotado"] for i in d["items"]}
    assert ag[p["id"]] is True and ag[hay["id"]] is False                     # mixto, con revendedora
    # mayorista privado (sin modo mixto) con la sesión de la revendedora: el mismo agotado; y el POST mayorista se rechaza igual
    _abrir(c, "agot-440-mixto", mayorista=True, mayorista_codigo=cod_negocio, mayorista_credito=True, mayorista_mixto=False)
    d = _publico(c, "agot-440-mixto", h); assert not d.get("privado") and d["mayorista"] is True
    ag = {i["id"]: i["agotado"] for i in d["items"]}
    assert ag[p["id"]] is True and ag[hay["id"]] is False
    r = _pedir(c, "agot-440-mixto", [{"producto_id": p["id"], "cantidad": 1}], headers=h, telefono="87004401", pago="credito")
    assert r.status_code == 400 and "unidades suficientes" in _detalle(r), r.text
    r = _pedir(c, "agot-440-mixto", [{"producto_id": hay["id"], "cantidad": 6}], headers=h, telefono="87004401")
    assert r.status_code == 400 and "unidades suficientes" in _detalle(r), r.text
    r = _pedir(c, "agot-440-mixto", [{"producto_id": hay["id"], "cantidad": 5}], headers=h, telefono="87004401"); assert r.status_code == 200, r.text


# ------------------------------------------------------------------------------------------------- JSON público
def test_json_publico_sin_cantidades(api):  # noqa: F811
    c = api
    ids = [_item(c, "Perfume %s" % n, cantidad_inicial=q)["id"] for n, q in (("Uno", 7), ("Dos", 13))]
    cero = _item(c, "Perfume Tres"); _en_cero(c, cero["id"])
    _item(c, "Perfume Cuatro", venta_negativo=True)
    _abrir(c, "agot-440-json")
    d = _publico(c, "agot-440-json")
    assert d["items"] and all(set(i) <= CLAVES_ITEM for i in d["items"]), [sorted(i) for i in d["items"]]
    assert not any(re.search(r"exist|cantidad|stock|porcion|disponib|bodega", k, re.I) for i in d["items"] for k in i)
    assert not any(re.search(r"exist|stock|porcion|disponib|bodega", k, re.I) for k in d)
    assert {i["id"]: i["agotado"] for i in d["items"]}[cero["id"]] is True and all(not i["agotado"] for i in d["items"] if i["id"] in ids)


# ------------------------------------------------------------------------------------------------- vista previa
def test_vista_previa_y_permiso(api):  # noqa: F811
    c = api; eid = _eid()
    from app.main import app
    _item(c, "Perfume Con Unidades", cantidad_inicial=5)
    _item(c, "Perfume Sin Registro")
    _item(c, "Perfume Negativo", venta_negativo=True)
    _item(c, "Envoltura", es_servicio=True, tipo="Servicio")
    _item(c, "Perfume Manual", agotado=True, cantidad_inicial=5)              # agotado a mano, con existencias: no lo agota la opción
    oculto = _item(c, "Perfume Oculto", visible_catalogo=False)                # fuera del catálogo: no cuenta
    en_cero = [_item(c, "Perfume %02d" % i) for i in range(22)]
    with Session(engine_empresa(eid)) as s:
        bp = inventario.bodega_principal(s, eid).id
        for x in en_cero + [oculto]:
            inventario.existencia(s, x["id"], bp)                             # fila en 0
        neg = s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.nombre == "Perfume Negativo")).one()
        inventario.existencia(s, neg.id, bp)
        s.commit()
    _publicar(c, slug="agot-440-vista", minimo_pedido=0)                       # todavía apagada: la vista previa es para antes de encender
    antes = _n_bodegas(eid)
    r = c.get("/api/pedidos/catalogo/agotado-vista"); assert r.status_code == 200, r.text
    v = r.json()
    assert set(v) == {"bodega", "total", "agotarian", "ejemplos", "sin_registro", "pruebas"}
    assert v["bodega"] == _bodega_principal(c)["nombre"] and v["total"] == 27 and v["agotarian"] == 22 and v["sin_registro"] == 1 and v["pruebas"] is True
    assert v["ejemplos"] == ["Perfume %02d" % i for i in range(20)]           # hasta 20 nombres
    assert _n_bodegas(eid) == antes
    assert all(not i["agotado"] for i in _publico(c, "agot-440-vista")["items"] if i["nombre"] != "Perfume Manual")   # la vista previa no enciende nada
    ctx = app.dependency_overrides[auth.contexto]()
    ctx.empresa.ambiente = "produccion"
    try:
        assert c.get("/api/pedidos/catalogo/agotado-vista").json()["pruebas"] is False
    finally:
        ctx.empresa.ambiente = "sandbox"
    # permiso «catalogos»: el Cajero no la ve
    cajero = auth.Contexto(types.SimpleNamespace(id=None, correo="cajero-440@example.test", es_superadmin=False, nombre="Cajero QA"), ctx.empresa, "Cajero")
    app.dependency_overrides[auth.contexto] = lambda: cajero
    try:
        assert c.get("/api/pedidos/catalogo/agotado-vista").status_code == 403
    finally:
        app.dependency_overrides[auth.contexto] = lambda: ctx


# ------------------------------------------------------------------------------------------------- ida y vuelta
def test_ida_y_vuelta_de_la_opcion_y_agotado_existencias(api):  # noqa: F811
    c = api
    p = _item(c, "Perfume Ida")
    q = _item(c, "Perfume Vuelta", cantidad_inicial=2)
    _en_cero(c, p["id"])
    r = _publicar(c, slug="agot-440-ida", minimo_pedido=0); assert r.status_code == 200 and r.json()["agotado_auto"] is False
    assert c.get("/api/pedidos/negocio").json()["agotado_auto"] is False
    d = c.get("/api/pedidos/catalogo").json(); por = {i["id"]: i for i in d["items"]}
    assert por[p["id"]]["agotado_existencias"] is False and d["agotado_auto"] is False and d["bodega"] is None      # apagada: nada
    neg = c.get("/api/pedidos/negocio").json()
    neg["agotado_auto"] = True
    for k in ("portada", "abierto", "nombre_publico", "url", "visibles", "id", "tilopay", "galeria", "dominio_verificado", "url_dominio", "url_subdominio", "url_publica", "host_base"):
        neg.pop(k, None)                                                      # lo que quita _negocio.js antes de guardar
    r = c.put("/api/pedidos/negocio", json=neg); assert r.status_code == 200 and r.json()["agotado_auto"] is True, r.text
    assert c.get("/api/pedidos/negocio").json()["agotado_auto"] is True
    d = c.get("/api/pedidos/catalogo").json(); por = {i["id"]: i for i in d["items"]}
    assert d["agotado_auto"] is True and d["bodega"] == _bodega_principal(c)["nombre"]
    assert por[p["id"]]["agotado_existencias"] is True and por[p["id"]]["agotado"] is False   # la casilla manual no se toca
    assert por[q["id"]]["agotado_existencias"] is False
    r = c.put(f"/api/pedidos/catalogo/{p['id']}", json={"destacado": True}); assert r.status_code == 200, r.text
    assert r.json()["agotado_existencias"] is True and r.json()["agotado"] is False
    r = c.put(f"/api/pedidos/catalogo/{p['id']}", json={"agotado": True}); assert r.json()["agotado"] is True and r.json()["agotado_existencias"] is True
    r = c.put(f"/api/pedidos/catalogo/{p['id']}", json={"agotado": False}); assert r.json()["agotado"] is False
    _ajustar(c, p["id"], 1)
    assert {i["id"]: i for i in c.get("/api/pedidos/catalogo").json()["items"]}[p["id"]]["agotado_existencias"] is False   # entraron unidades
    r = _publicar(c, slug="agot-440-ida", minimo_pedido=0, agotado_auto=False); assert r.json()["agotado_auto"] is False


# ------------------------------------------------------------------------------------------------- 4.40 (revisión): arreglos del servidor
RAIZ = pathlib.Path(__file__).resolve().parent.parent
INTERNAS = {"faltan", "productos"}                                            # claves de calcular() solo para revisar_existencias


def _claves(x, out=None) -> set:
    """Todas las claves de un JSON, a cualquier profundidad."""
    out = set() if out is None else out
    if isinstance(x, dict):
        for k, v in x.items():
            out.add(k); _claves(v, out)
    elif isinstance(x, list):
        for v in x:
            _claves(v, out)
    return out


def _sin_internas(*rs):
    for r in rs:
        assert not (_claves(r.json()) & INTERNAS), (r.status_code, r.text[:300])


def _n_pedidos(eid) -> int:
    with Session(engine_empresa(eid)) as s:
        return len(s.exec(select(pedidos.Pedido).where(pedidos.Pedido.empresa_id == eid)).all())


def _contar_consultas(eng, fn):
    n = [0]

    def cb(*a, **k):
        n[0] += 1
    event.listen(eng, "before_cursor_execute", cb)
    try:
        r = fn()
    finally:
        event.remove(eng, "before_cursor_execute", cb)
    return n[0], r


@contextlib.contextmanager
def _limite_variables(eid, n=999):
    """SQLite anterior a 3.32: 999 variables por consulta. Se simula con setlimit en cada conexión nueva del motor de la empresa."""
    eng = engine_empresa(eid)

    def _lim(con, _rec):
        if isinstance(con, sqlite3.Connection):
            con.setlimit(sqlite3.SQLITE_LIMIT_VARIABLE_NUMBER, n)
    event.listen(eng, "connect", _lim)
    eng.dispose()
    try:
        yield
    finally:
        event.remove(eng, "connect", _lim)
        eng.dispose()


def test_existencias_es_la_ultima_validacion_del_pedido(api):  # noqa: F811
    """Revisión de seguridad: con cualquier otro error la respuesta es la misma pida lo que pida, así que no se tantea la existencia
    sin crear pedidos (antes, con 7 unidades, q de 1 a 7 daba el otro error y de 8 en adelante «no hay unidades suficientes»)."""
    c = api; eid = _eid()
    a = _item(c, "Perfume Oráculo", cantidad_inicial=7)
    _abrir(c, "agot-440-ultima")
    casos = {"correo": ({"correo": "no-es-correo"}, "Revise el correo electrónico"),
             "pago": ({"pago": "zzz"}, "Forma de pago desconocida"),
             "puntos": ({"puntos": 1}, "Para usar puntos ingrese con su teléfono y clave"),
             "linea fantasma": ({}, "ya no está en el catálogo")}
    antes = _n_pedidos(eid)
    for nombre, (extra, esperado) in casos.items():
        textos = set()
        for q in range(1, 12):
            auth._intentos_ip.clear()
            lineas = [{"producto_id": a["id"], "cantidad": q}] + ([{"producto_id": 99999999, "cantidad": 1}] if nombre == "linea fantasma" else [])
            r = _pedir(c, "agot-440-ultima", lineas, **extra)
            assert r.status_code == 400, (nombre, q, r.text)
            _sin_internas(r); textos.add(_detalle(r))
        assert len(textos) == 1 and esperado in next(iter(textos)), (nombre, textos)
    # pedido mínimo no cumplido y cantidad de más: gana el error del mínimo
    _abrir(c, "agot-440-ultima", minimo_pedido=50000)
    textos = set()
    for q in range(1, 12):
        auth._intentos_ip.clear()
        r = _pedir(c, "agot-440-ultima", [{"producto_id": a["id"], "cantidad": q}]); assert r.status_code == 400, r.text
        textos.add(_detalle(r))
    assert textos == {"El pedido mínimo es ₡50.000"}, textos
    assert _n_pedidos(eid) == antes                                            # ninguno de esos intentos creó un pedido
    # con todo lo demás válido: 8 no alcanza (lo nombra: es un solo producto) y 7 sí
    _abrir(c, "agot-440-ultima")
    r = _pedir(c, "agot-440-ultima", [{"producto_id": a["id"], "cantidad": 8}])
    assert r.status_code == 400 and _detalle(r) == pedidos.MENSAJE_SIN_EXISTENCIAS.format(nombre="Perfume Oráculo"), r.text
    r = _pedir(c, "agot-440-ultima", [{"producto_id": a["id"], "cantidad": 7}]); assert r.status_code == 200, r.text
    _sin_internas(r)
    assert _n_pedidos(eid) == antes + 1


def test_varios_productos_mensaje_comun_sin_nombre(api):  # noqa: F811
    """Revisión de seguridad: con varios productos distintos el 400 no dice cuál falta (nombrar la primera línea que no alcanza dejaba
    tantear A con una línea B que seguro falla: [A 2, B 999] nombraba a B y [A 4, B 999] a A). Con uno solo, lo nombra."""
    c = api; eid = _eid()
    a = _item(c, "Perfume Igual A", cantidad_inicial=3)
    b = _item(c, "Perfume Igual B", cantidad_inicial=5)
    z = _item(c, "Perfume Igual Z"); _en_cero(c, z["id"])
    serv = _item(c, "Envoltura Igual", es_servicio=True, tipo="Servicio")
    _abrir(c, "agot-440-varios")
    antes = _n_pedidos(eid)
    m = pedidos.MENSAJE_SIN_EXISTENCIAS_VARIOS
    assert "unidades suficientes" in m and not re.search(r"\d", m) and "«" not in m        # tienda.js recarga con «unidades suficientes»
    textos = set()
    for qa in range(1, 7):
        for lineas in ([{"producto_id": a["id"], "cantidad": qa}, {"producto_id": b["id"], "cantidad": 999}],
                       [{"producto_id": b["id"], "cantidad": 999}, {"producto_id": a["id"], "cantidad": qa}]):
            r = _pedir(c, "agot-440-varios", lineas); assert r.status_code == 400, r.text
            _sin_internas(r); textos.add(_detalle(r))
    assert textos == {m}, textos                                              # 12 carritos, un solo texto exacto
    r = _pedir(c, "agot-440-varios", [{"producto_id": a["id"], "cantidad": 4}, {"producto_id": serv["id"], "cantidad": 1}])
    assert r.status_code == 400 and _detalle(r) == m, r.text                  # un servicio también es otro producto distinto
    # un solo producto distinto (en una o dos líneas): lo nombra, con el mensaje del diseño
    nombrado = pedidos.MENSAJE_SIN_EXISTENCIAS.format(nombre="Perfume Igual A")
    r = _pedir(c, "agot-440-varios", [{"producto_id": a["id"], "cantidad": 4}]); assert r.status_code == 400 and _detalle(r) == nombrado, r.text
    r = _pedir(c, "agot-440-varios", [{"producto_id": a["id"], "cantidad": 2}, {"producto_id": a["id"], "cantidad": 2}])
    assert r.status_code == 400 and _detalle(r) == nombrado, r.text
    # el que ya sale agotado en la página (a 0) se nombra de una vez en cualquier carrito: eso ya es público
    for qa in (3, 4):
        r = _pedir(c, "agot-440-varios", [{"producto_id": a["id"], "cantidad": qa}, {"producto_id": z["id"], "cantidad": 1}])
        assert r.status_code == 400 and _detalle(r) == pedidos.MENSAJE_SIN_EXISTENCIAS.format(nombre="Perfume Igual Z"), r.text
    assert _n_pedidos(eid) == antes
    r = _pedir(c, "agot-440-varios", [{"producto_id": a["id"], "cantidad": 3}, {"producto_id": b["id"], "cantidad": 5}]); assert r.status_code == 200, r.text
    seg = c.get(f"/api/publico/agot-440-varios/pedido/{r.json()['token']}"); assert seg.status_code == 200, seg.text
    _sin_internas(r, seg)                                                     # ni el pedido creado ni su seguimiento traen las claves internas


def test_cada_camino_que_crea_pedidos_revisa_existencias(api):  # noqa: F811
    """Todo pedido nace en crear_pedido (público, mixto, revendedora y mayorista privado, al contado o a crédito) y ahí revisar_existencias
    es lo último antes de guardar. Si aparece otro lugar que arme un Pedido o llame a pedidos.calcular, esta prueba avisa."""
    fuente = inspect.getsource(pedidos.crear_pedido)
    assert fuente.count("revisar_existencias(c)") == 1
    assert fuente.index("c = calcular(") < fuente.index("revisar_existencias(c)") < fuente.index("s.add(p)")
    armados, llamadas = [], []
    for f in sorted((RAIZ / "app").rglob("*.py")):
        t = f.read_text(encoding="utf-8")
        armados += [f.name for x in re.finditer(r"(?<!\w)Pedido\(", t) if not t[:x.start()].rsplit("\n", 1)[-1].lstrip().startswith("class ")]
        llamadas += [f.name for _ in re.finditer(r"(?<![\w])calcular\(s,|(?:pedidos|_ped)\.calcular\(", t)]
    assert sorted(armados) == ["demo_tipos.py", "pedidos.py"], armados       # demo_tipos: datos de demostración, no pedidos de clientes
    assert llamadas == ["pedidos.py"], llamadas
    # y en la práctica: cada camino rechaza la cantidad de más (sin cifras) y deja ganar a los otros errores
    c = api; eid = _eid()
    hay = _item(c, "Perfume Camino", cantidad_inicial=5)
    otro = _item(c, "Perfume Camino Dos", cantidad_inicial=5)
    cli = c.post("/api/clientes", json={"nombre": "Revendedora Caminos", "tipo": "Cliente", "tipo_id": "01", "numero_id": "303330442", "celular": 87004402, "limite_credito": 500000}).json()
    assert cli.get("id"), cli
    cod_negocio = "QA" + secrets.token_hex(3).upper()                       # código del negocio generado al correr (no queda escrito)
    slug = "agot-440-caminos"
    _abrir(c, slug, mayorista=True, mayorista_codigo=cod_negocio, mayorista_credito=True, mayorista_mixto=True)
    codigo = next(x for x in c.get("/api/pedidos/revendedoras").json() if x["contacto_id"] == cli["id"])["codigo"]
    clave = str(1000 + secrets.randbelow(9000))                               # clave de prueba generada al correr (no queda escrita)
    r = c.post(f"/api/publico/{slug}/cliente/acceso", json={"telefono": "87004402", "pin": clave, "codigo": codigo}); assert r.status_code == 200, r.text
    rev = {"headers": {"X-Cliente": r.json()["token"]}, "telefono": "87004402"}
    nombrado = pedidos.MENSAJE_SIN_EXISTENCIAS.format(nombre="Perfume Camino")

    def revisar(camino, extra):
        auth._intentos_ip.clear()
        r = _pedir(c, slug, [{"producto_id": hay["id"], "cantidad": 6}], **extra)
        assert r.status_code == 400 and _detalle(r) == nombrado, (camino, r.text)
        r = _pedir(c, slug, [{"producto_id": hay["id"], "cantidad": 6}, {"producto_id": otro["id"], "cantidad": 1}], **extra)
        assert r.status_code == 400 and _detalle(r) == pedidos.MENSAJE_SIN_EXISTENCIAS_VARIOS, (camino, r.text)
        r = _pedir(c, slug, [{"producto_id": hay["id"], "cantidad": 6}], **{**extra, "pago": "zzz"})
        assert r.status_code == 400 and _detalle(r) == "Forma de pago desconocida", (camino, r.text)
        r = _pedir(c, slug, [{"producto_id": hay["id"], "cantidad": 5}], **extra); assert r.status_code == 200, (camino, r.text)
        _sin_internas(r)

    revisar("mixto, público", {})
    revisar("mixto, revendedora", rev)
    revisar("mixto, revendedora a crédito", {**rev, "pago": "credito"})
    _abrir(c, slug, mayorista=True, mayorista_codigo=cod_negocio, mayorista_credito=True, mayorista_mixto=False)
    assert _pedir(c, slug, [{"producto_id": hay["id"], "cantidad": 1}]).status_code == 401   # mayorista privado sin sesión: ni llega a calcular
    revisar("mayorista privado, revendedora", rev)
    revisar("mayorista privado, a crédito", {**rev, "pago": "credito"})
    _abrir(c, slug, mayorista=False)
    revisar("público", {})


def test_porciones_del_catalogo_con_tolerancia_y_caja_igual(api):  # noqa: F811
    """Revisión (regla): 1.0 // 0.1 = 9 en coma flotante. El catálogo cuenta 10 decants de 0,1 sobre una existencia de 1,0 (y la
    última porción después de 0,3 − 0,1 − 0,1); /recetas/porciones de la caja responde lo mismo que antes de la 4.40 (9 y 0)."""
    c = api; eid = _eid()
    botella = _insumo(c, "Botella Unid")
    frasco = _insumo(c, "Frasco 100 ml")
    for x in (botella, frasco):
        r = c.post("/api/inventario/compras", json={"lineas": [{"producto_id": x["id"], "cantidad": 1, "costo_unitario": 900}]}); assert r.status_code == 200, r.text
    carne = _insumo(c, "Carne Justa")
    _ajustar(c, carne["id"], 0.3); _ajustar(c, carne["id"], -0.1); _ajustar(c, carne["id"], -0.1)    # queda 0,09999999999999998: una porción
    corta = _insumo(c, "Carne Corta"); _ajustar(c, corta["id"], 0.099999)                              # 0,1 − 1e-6: no alcanza
    decant = _item(c, "Decant 0,1", inventariable=False)
    decant_ml = _item(c, "Decant 10 ml", inventariable=False)
    plato = _item(c, "Plato Justo", inventariable=False, categoria="Platos")
    corto = _item(c, "Plato Corto", inventariable=False, categoria="Platos")
    _guardar(eid, "items_extra", {str(frasco["id"]): {"contenido": 100, "contenido_unidad": "ml"}})
    _guardar(eid, "recetas", [
        {"id": decant["id"], "producto_id": decant["id"], "rendimiento": 1, "ingredientes": [{"producto_id": botella["id"], "cantidad": 0.1}]},
        {"id": decant_ml["id"], "producto_id": decant_ml["id"], "rendimiento": 1, "ingredientes": [{"producto_id": frasco["id"], "cantidad": 10, "unidad": "ml"}]},
        {"id": plato["id"], "producto_id": plato["id"], "rendimiento": 1, "ingredientes": [{"producto_id": carne["id"], "cantidad": 0.1}]},
        {"id": corto["id"], "producto_id": corto["id"], "rendimiento": 1, "ingredientes": [{"producto_id": corta["id"], "cantidad": 0.1}]}])
    caja_esperada = {str(decant["id"]): 9, str(decant_ml["id"]): 9, str(plato["id"]): 0, str(corto["id"]): 0}   # la caja: sin tolerancia, como en la 4.39
    assert c.get("/api/inventario/recetas/porciones").json() == caja_esperada
    bp = _bodega_principal(c)["id"]
    with Session(engine_empresa(eid)) as s:
        assert {str(k): v for k, v in inventario.porciones_bodega(s, eid, bp).items()} == caja_esperada
        cat = inventario.existencias_catalogo(s, eid, [s.get(Producto, x["id"]) for x in (decant, decant_ml, plato, corto)], bp)
    assert cat == {decant["id"]: 10, decant_ml["id"]: 10, plato["id"]: 1, corto["id"]: 0}
    _abrir(c, "agot-440-tolera")
    ag = _agotados(c, "agot-440-tolera")
    assert ag[decant["id"]] is False and ag[decant_ml["id"]] is False and ag[plato["id"]] is False and ag[corto["id"]] is True
    for x, n in ((decant, 10), (decant_ml, 10), (plato, 1)):
        r = _pedir(c, "agot-440-tolera", [{"producto_id": x["id"], "cantidad": n}]); assert r.status_code == 200, (x["nombre"], r.text)
        r = _pedir(c, "agot-440-tolera", [{"producto_id": x["id"], "cantidad": n + 1}])
        assert r.status_code == 400 and _detalle(r) == pedidos.MENSAJE_SIN_EXISTENCIAS.format(nombre=x["nombre"]), r.text
    # después de 9 salidas de 0,1 de la botella queda un decant, y sigue disponible
    for _ in range(9):
        _ajustar(c, botella["id"], -0.1)
    assert _agotados(c, "agot-440-tolera")[decant["id"]] is False
    assert _pedir(c, "agot-440-tolera", [{"producto_id": decant["id"], "cantidad": 1}]).status_code == 200
    assert _pedir(c, "agot-440-tolera", [{"producto_id": decant["id"], "cantidad": 2}]).status_code == 400
    assert c.get("/api/inventario/recetas/porciones").json()[str(decant["id"])] == 1   # aquí quedó 0,10000000000000014: alcanza también sin tolerancia


def test_porciones_leen_los_ingredientes_en_una_consulta(api):  # noqa: F811
    """Revisión (seguridad): porciones_bodega hacía un s.get por cada aparición de un ingrediente, y ahora la llaman el JSON público y
    cada pedido. Las consultas ya no crecen con las recetas y el resultado es el mismo, con las dos reglas de «sin fila»."""
    c = api; eid = _eid(); eng = engine_empresa(eid)
    with Session(eng) as s:
        bp = inventario.bodega_principal(s, eid).id
        insumos = []
        for i in range(60):
            p = Producto(empresa_id=eid, nombre=f"Insumo N1 {i:02d}", cabys="", precio=0, es_venta=False, visible_catalogo=False, inventariable=True)
            s.add(p); s.commit(); s.refresh(p); insumos.append(p.id)
            if i % 2 == 0:                                                    # los pares con fila (i + 1 unidades); los impares sin fila
                s.add(inventario.Existencia(producto_id=p.id, bodega_id=bp, cantidad=float(i + 1))); s.commit()
        platos = []
        for i in range(40):
            p = Producto(empresa_id=eid, nombre=f"Plato N1 {i:02d}", cabys="2111100000000", precio=1000, visible_catalogo=True, inventariable=False, categoria="Platos")
            s.add(p); s.commit(); s.refresh(p); platos.append(p.id)
    # los 20 primeros con 3 insumos distintos; los demás comparten los mismos 3 (como el aceite o el arroz de un restaurante)
    idx = {i: ([(3 * i + j) % 60 for j in range(3)] if i < 20 else [0, 1, 2]) for i in range(40)}

    def recetas(n):
        return [{"id": platos[i], "producto_id": platos[i], "rendimiento": 1, "ingredientes": [{"producto_id": insumos[k], "cantidad": 1} for k in idx[i]]} for i in range(n)]
    medidas = {}
    for n in (5, 40):
        _guardar(eid, "recetas", recetas(n))
        with Session(eng) as s:
            medidas[n] = _contar_consultas(eng, lambda: inventario.porciones_bodega(s, eid, bp, sin_fila_desconocido=True))
    (q5, _r5), (q40, r40) = medidas[5], medidas[40]
    assert q5 == q40 and q40 <= 8, (q5, q40)                                  # fijo (antes 4 + 1 por cada aparición de un ingrediente: 124)
    assert r40 == {platos[i]: min(k + 1 for k in idx[i] if k % 2 == 0) for i in range(40)}
    with Session(eng) as s:
        q, caja = _contar_consultas(eng, lambda: inventario.porciones_bodega(s, eid, bp))
    assert q == q40 and caja == {pid: 0 for pid in platos}                    # la caja: un ingrediente sin fila cuenta 0 (todos tienen uno impar)


def test_mas_de_500_productos_en_trozos(api):  # noqa: F811
    """Revisión (regresiones): el IN de existencias_catalogo va de a 500 ids; con 1005 ítems y el límite viejo de 999 variables de
    SQLite, el catálogo, la tienda, la vista previa y el pedido responden, y el agotado es el correcto también después del 500."""
    c = api; eid = _eid(); total = 1005
    with Session(engine_empresa(eid)) as s:
        bid = inventario.bodega_principal(s, eid).id
        s.add_all([Producto(empresa_id=eid, nombre="Perfume %04d" % i, cabys="2111100000000", precio=1000, visible_catalogo=True, categoria="Perfumes") for i in range(total)])
        s.commit()
        ids = list(s.exec(select(Producto.id).where(Producto.empresa_id == eid).order_by(Producto.id)).all())
        for i, pid in enumerate(ids):                                         # i % 3: 0 = fila en 0, 1 = fila con 5, 2 = sin fila
            if i % 3 != 2:
                s.add(inventario.Existencia(producto_id=pid, bodega_id=bid, cantidad=0 if i % 3 == 0 else 5))
        s.commit()
    _abrir(c, "agot-440-mil")
    with _limite_variables(eid):
        with Session(engine_empresa(eid)) as s:
            prods = s.exec(select(Producto).where(Producto.empresa_id == eid).order_by(Producto.id)).all()
            assert inventario.existencias_catalogo(s, eid, prods, bid) == {pid: (0.0 if i % 3 == 0 else 5.0 if i % 3 == 1 else None) for i, pid in enumerate(ids)}
        r = c.get("/api/publico/agot-440-mil"); assert r.status_code == 200, r.text[:300]
        assert {i["id"]: i["agotado"] for i in r.json()["items"]} == {pid: i % 3 == 0 for i, pid in enumerate(ids)}
        assert c.get("/api/pedidos/catalogo").status_code == 200
        v = c.get("/api/pedidos/catalogo/agotado-vista"); assert v.status_code == 200, v.text[:300]
        assert v.json()["total"] == total and v.json()["agotarian"] == 335 and v.json()["sin_registro"] == 335
        r = _pedir(c, "agot-440-mil", [{"producto_id": ids[1003], "cantidad": 6}]); assert r.status_code == 400, r.text      # el 1004.º tiene 5
        r = _pedir(c, "agot-440-mil", [{"producto_id": ids[1003], "cantidad": 5}]); assert r.status_code == 200, r.text


def test_put_del_negocio_sin_la_clave_conserva_la_opcion(api):  # noqa: F811
    """Revisión (regresiones): una pestaña abierta antes de la 4.40 guarda el negocio sin agotado_auto; eso no la apaga (mismo patrón
    que atiende_terminal en test_432_pedidos). false la apaga y null no cambia nada."""
    c = api
    _abrir(c, "agot-440-put")
    assert c.get("/api/pedidos/negocio").json()["agotado_auto"] is True
    r = _publicar(c, slug="agot-440-put", minimo_pedido=0, bienvenida="Hola desde una pestaña vieja")      # sin la clave
    assert r.status_code == 200 and r.json()["agotado_auto"] is True, r.text
    neg = c.get("/api/pedidos/negocio").json(); assert neg["agotado_auto"] is True and neg["bienvenida"] == "Hola desde una pestaña vieja"
    r = _publicar(c, slug="agot-440-put", minimo_pedido=0, agotado_auto=None); assert r.status_code == 200 and r.json()["agotado_auto"] is True, r.text
    r = _publicar(c, slug="agot-440-put", minimo_pedido=0, agotado_auto=False); assert r.status_code == 200 and r.json()["agotado_auto"] is False, r.text
    r = _publicar(c, slug="agot-440-put", minimo_pedido=0); assert r.status_code == 200 and r.json()["agotado_auto"] is False, r.text   # sigue apagada
    r = _publicar(c, slug="agot-440-put", minimo_pedido=0, agotado_auto=True); assert r.json()["agotado_auto"] is True


def test_textos_de_pantalla_de_la_revision():
    """Pantallas: aviso «sin bodega» solo con la casilla marcada; la ayuda dice que los combos de Catálogo web › Combos se agotan (decisión
    de Norman, 17/11/2026); en el programa la casilla no sale; el carrito distingue «Ya no está en el catálogo»; nada de «vuelve»."""
    js = RAIZ / "app" / "static" / "js"
    for rel in ("fis/pages/configuracion.js", "pages/fisitaap/configuracion.js"):
        t = (js / rel).read_text(encoding="utf-8")
        assert 'v-if="n.agotado_auto && vista && !vista.bodega"' in t and 'v-if="vista && !vista.bodega"' not in t, rel
        ayuda = next(x for x in t.splitlines() if "ayudaAgotado()" in x)
        assert "Catálogo web › Combos se agota cuando las unidades de uno de sus componentes no alcanzan para armar uno" in ayuda and "combos, productos sin control" not in ayuda, rel
        assert "vuelve" not in ayuda.lower(), rel
        assert "enPrograma()" in t and "this.enPrograma ||" in t and "data-agotado-auto-programa" in t, rel
    t = (js / "tienda.js").read_text(encoding="utf-8")
    assert "lineaFuera(l) ? 'Ya no está en el catálogo' : 'Se agotó'" in t
    assert re.search(r"/unidades suficientes\|", t) and "unidades suficientes" in pedidos.MENSAJE_SIN_EXISTENCIAS_VARIOS   # también recarga con varios
    assert "vuelve" not in pedidos.MENSAJE_SIN_EXISTENCIAS_VARIOS.lower()


def test_tilopay_que_falla_deja_el_pedido_cancelado_a_la_vista(api, monkeypatch):  # noqa: F811
    """Segunda revisión (seguridad): si Tilopay no abre el pago, el pedido ya no se borra. Borrarlo dejaba tantear la existencia sin
    rastro mientras Tilopay fallaba (502 = alcanzaba, 400 = no). Ahora queda «Cancelado» a la vista del negocio, sin la clave de petición
    (reintentar crea otro pedido) y sin tocar el cupón, los puntos ni la tarjeta de regalo, que se registran después."""
    from fastapi import HTTPException

    from app import pagos_online
    c = api; eid = _eid()
    a = _item(c, "Perfume Tilopay", cantidad_inicial=3)
    _abrir(c, "agot-440-tilopay")
    monkeypatch.setattr(pagos_online, "credenciales", lambda e, n: {"key": "qa"})

    def falla(*_a, **_k):
        raise HTTPException(502, "No se pudo conectar con el procesador de pagos")
    monkeypatch.setattr(pagos_online, "iniciar_pago", falla)
    antes = _n_pedidos(eid)
    r = _pedir(c, "agot-440-tilopay", [{"producto_id": a["id"], "cantidad": 2}], pago="tarjeta", clave_peticion="qa-440-tilopay-1")
    assert r.status_code == 502, r.text
    assert _n_pedidos(eid) == antes + 1
    with Session(engine_empresa(eid)) as s:
        p = s.exec(select(pedidos.Pedido).where(pedidos.Pedido.empresa_id == eid).order_by(pedidos.Pedido.id.desc())).first()   # type: ignore[union-attr]
        assert (p.estado, p.motivo, p.clave_peticion, p.pago_medio) == ("cancelado", "No se pudo abrir el pago en línea", None, "tarjeta")
    lista = c.get("/api/pedidos?estado=cancelado"); assert lista.status_code == 200, lista.text
    assert any(x["id"] == p.id for x in (lista.json() if isinstance(lista.json(), list) else lista.json().get("pedidos", []))), lista.text[:300]
    # pedir de más falla antes de llegar a Tilopay (400, sin pedido); con Tilopay de vuelta, la misma clave crea un pedido nuevo
    r = _pedir(c, "agot-440-tilopay", [{"producto_id": a["id"], "cantidad": 4}], pago="tarjeta")
    assert r.status_code == 400 and _detalle(r) == pedidos.MENSAJE_SIN_EXISTENCIAS.format(nombre="Perfume Tilopay"), r.text
    assert _n_pedidos(eid) == antes + 1
    monkeypatch.setattr(pagos_online, "iniciar_pago", lambda *_a, **_k: "https://tilopay.example.test/qa-440")
    r = _pedir(c, "agot-440-tilopay", [{"producto_id": a["id"], "cantidad": 2}], pago="tarjeta", clave_peticion="qa-440-tilopay-1")
    assert r.status_code == 200 and r.json()["repetido"] is False and r.json()["pago_url"] and r.json()["id"] != p.id, r.text
    assert _n_pedidos(eid) == antes + 2


def test_receta_con_id_fuera_del_rango_de_sqlite(api):  # noqa: F811
    """Segunda revisión (regresiones): un ingrediente con un id que no cabe en un entero de SQLite (10**20) rompía la consulta IN de
    porciones_bodega: con la opción encendida tumbaba la página pública. Ahora ese ingrediente se salta, como un producto que no existe."""
    c = api; eid = _eid()
    harina = _insumo(c, "Harina Rango"); _ajustar(c, harina["id"], 3)
    plato = _item(c, "Pan Rango", inventariable=False, categoria="Platos")
    _guardar(eid, "recetas", [{"id": plato["id"], "producto_id": plato["id"], "rendimiento": 1,
                               "ingredientes": [{"producto_id": 10 ** 20, "cantidad": 1}, {"producto_id": -(10 ** 20), "cantidad": 1},
                                                {"producto_id": harina["id"], "cantidad": 1}]}])
    r = c.get("/api/inventario/recetas/porciones"); assert r.status_code == 200 and r.json() == {str(plato["id"]): 3}, r.text
    _abrir(c, "agot-440-rango")
    assert _agotados(c, "agot-440-rango")[plato["id"]] is False
    r = _pedir(c, "agot-440-rango", [{"producto_id": plato["id"], "cantidad": 4}]); assert r.status_code == 400, r.text
    r = _pedir(c, "agot-440-rango", [{"producto_id": plato["id"], "cantidad": 3}]); assert r.status_code == 200, r.text
    v = c.get("/api/pedidos/catalogo/agotado-vista"); assert v.status_code == 200, v.text


# ------------------------------------------------------------------------------------------------- tercera revisión
def test_recetas_mal_formadas_no_tumban_la_pagina(api):  # noqa: F811
    """Tercera revisión (regresiones): en la 4.39 la página pública y los pedidos no calculaban recetas. Con la opción encendida, una
    sola receta mal formada (de un plato que ni siquiera está en el catálogo) daba 500 o 400 a todos los clientes. Ahora cada receta se
    calcula por separado: la rota queda desconocida (su plato, disponible) y las demás siguen agotándose según sus existencias."""
    c = api; eid = _eid()
    harina = _insumo(c, "Harina Rota"); _ajustar(c, harina["id"], 2)
    carne = _insumo(c, "Carne Rota"); _en_cero(c, carne["id"])
    bueno = _item(c, "Pan Bueno", inventariable=False, categoria="Platos")
    agotado = _item(c, "Guiso Agotado", inventariable=False, categoria="Platos")
    rotos = {n: _item(c, n, inventariable=False, categoria="Platos") for n in ("Roto Id", "Roto NaN", "Roto Lista", "Roto Rinde", "Roto Equis")}

    def receta(p, ings, rinde=1):
        return {"id": p["id"], "producto_id": p["id"], "rendimiento": rinde, "ingredientes": ings}
    _guardar(eid, "recetas", [
        receta(bueno, [{"producto_id": harina["id"], "cantidad": 1}]),
        receta(agotado, [{"producto_id": carne["id"], "cantidad": 1}]),
        receta(rotos["Roto Id"], [{"producto_id": "abc", "cantidad": 1}, {"producto_id": carne["id"], "cantidad": 1}]),
        receta(rotos["Roto NaN"], [{"producto_id": harina["id"], "cantidad": "NaN"}]),
        receta(rotos["Roto Lista"], ["harina", 5, None]),
        receta(rotos["Roto Rinde"], [{"producto_id": harina["id"], "cantidad": 1}], rinde=1e308),
        receta(rotos["Roto Equis"], [{"producto_id": harina["id"], "cantidad": "x"}]),
    ])
    _abrir(c, "agot-440-rotas")
    ag = _agotados(c, "agot-440-rotas")
    assert ag[bueno["id"]] is False and ag[agotado["id"]] is True
    assert all(ag[p["id"]] is False for p in rotos.values()), ag              # rotas: desconocidas, siguen disponibles
    r = _pedir(c, "agot-440-rotas", [{"producto_id": bueno["id"], "cantidad": 3}]); assert r.status_code == 400 and "Pan Bueno" in _detalle(r), r.text
    r = _pedir(c, "agot-440-rotas", [{"producto_id": bueno["id"], "cantidad": 2}, {"producto_id": rotos["Roto NaN"]["id"], "cantidad": 1}]); assert r.status_code == 200, r.text
    for ruta in ("/api/pedidos/catalogo", "/api/pedidos/catalogo/agotado-vista", "/api/inventario/recetas/porciones"):
        assert c.get(ruta).status_code == 200, ruta
    assert c.get("/api/inventario/recetas/porciones").json()[str(bueno["id"])] == 2   # la caja también calcula las buenas
    # una receta cuyo propio producto_id es raro rompe recetas() (ya era así en la caja): la red de seguridad deja el catálogo en pie
    _guardar(eid, "recetas", [receta(bueno, [{"producto_id": harina["id"], "cantidad": 1}]), {"id": 9, "producto_id": "abc", "ingredientes": []}])
    assert _publico(c, "agot-440-rotas")["items"]
    r = _pedir(c, "agot-440-rotas", [{"producto_id": bueno["id"], "cantidad": 1}]); assert r.status_code == 200, r.text
    assert c.get("/api/pedidos/catalogo/agotado-vista").status_code == 200


def test_bodega_o_sucursal_fuera_de_rango_usa_la_principal(api):  # noqa: F811
    """Tercera revisión: un bodega_id o sucursal_id de la caja que no cabe en un entero de SQLite daba 400 a la página y a los pedidos
    con la opción encendida. Ahora cuenta como «sin bodega» y se usa la principal activa."""
    c = api; eid = _eid()
    p = _item(c, "Perfume Rango Bodega", cantidad_inicial=2)
    _abrir(c, "agot-440-bod-rango")
    principal = _bodega_principal(c)["nombre"]
    for t in ({"bodega_id": 10 ** 20}, {"bodega_id": 2 ** 63}, {"sucursal_id": 10 ** 20}, {"bodega_id": -(10 ** 20), "sucursal_id": 2 ** 64}, {"bodega_id": "1e400"}):
        _caja(eid, **t)
        assert _agotados(c, "agot-440-bod-rango")[p["id"]] is False, t
        v = c.get("/api/pedidos/catalogo/agotado-vista"); assert v.status_code == 200 and v.json()["bodega"] == principal, (t, v.text)
        auth._intentos_ip.clear()
        r = _pedir(c, "agot-440-bod-rango", [{"producto_id": p["id"], "cantidad": 3}]); assert r.status_code == 400 and "unidades suficientes" in _detalle(r), (t, r.text)


def test_tilopay_con_otra_falla_tambien_cancela(api, monkeypatch):  # noqa: F811
    """Tercera revisión: una respuesta rara de Tilopay (cuerpo que no es JSON, sin access_token) no es HTTPException. Antes el pedido
    quedaba «Esperando pago» con su clave y el reintento lo devolvía como «recibido» sin que el negocio lo viera. Ahora queda cancelado,
    sin clave, y la forma de pago dice que fue con tarjeta y no se pagó (no «Paga al recibir»)."""
    from app import pagos_online
    c = api; eid = _eid()
    a = _item(c, "Perfume Otra Falla", cantidad_inicial=3)
    _abrir(c, "agot-440-otra-falla")
    monkeypatch.setattr(pagos_online, "credenciales", lambda e, n: {"key": "qa"})

    def rara(*_a, **_k):
        raise KeyError("access_token")
    monkeypatch.setattr(pagos_online, "iniciar_pago", rara)
    antes = _n_pedidos(eid)
    try:
        r = _pedir(c, "agot-440-otra-falla", [{"producto_id": a["id"], "cantidad": 1}], pago="tarjeta", clave_peticion="qa-440-otra-1")
        assert r.status_code >= 500, r.text
    except KeyError:
        pass                                                                   # el cliente de pruebas relanza el error del servidor
    assert _n_pedidos(eid) == antes + 1
    with Session(engine_empresa(eid)) as s:
        p = s.exec(select(pedidos.Pedido).where(pedidos.Pedido.empresa_id == eid).order_by(pedidos.Pedido.id.desc())).first()   # type: ignore[union-attr]
        assert (p.estado, p.motivo, p.clave_peticion) == ("cancelado", "No se pudo abrir el pago en línea", None)
        assert pedidos.forma_pago(p) == "Tarjeta en línea · no se pagó"
        p.pago_estado = "reembolsado"
        assert pedidos.forma_pago(p) == "Pagado en línea"
        p.pago_medio = ""; p.pago_estado = ""
        assert pedidos.forma_pago(p) == "Paga al recibir"                    # un pedido sin tarjeta cancelado, como siempre
    monkeypatch.setattr(pagos_online, "iniciar_pago", lambda *_a, **_k: "https://tilopay.example.test/qa-440-otra")
    r = _pedir(c, "agot-440-otra-falla", [{"producto_id": a["id"], "cantidad": 1}], pago="tarjeta", clave_peticion="qa-440-otra-1")
    assert r.status_code == 200 and r.json()["repetido"] is False and r.json()["pago_url"], r.text


def test_textos_de_la_tercera_revision():
    """Solo Generales manda agotado_auto (Diseño de la página y Publicar abiertos desde antes ya no la apagan); si la vista previa falla,
    se avisa; el resumen con IA da el monto sin los cancelados; ui.js no dice «Paga al recibir» de una tarjeta que no se pagó."""
    js = RAIZ / "app" / "static" / "js"
    neg = (js / "pages" / "fisitaap" / "_negocio.js").read_text(encoding="utf-8")
    assert "if (!('agotado_auto' in extra)) delete body.agotado_auto;" in neg
    for rel, guarda in (("fis/pages/configuracion.js", "agotado_auto: !!n.agotado_auto }"), ("pages/fisitaap/configuracion.js", "agotado_auto: !!this.n.agotado_auto }")):
        t = (js / rel).read_text(encoding="utf-8")
        assert guarda in t and 'v-if="vistaError"' in t and "this.vistaError = true" in t, rel
        linea = next(x for x in t.splitlines() if "agotado_auto: !!" in x)            # el comentario no puede tapar el resto de la línea
        assert re.search(r"agotado_auto \}\); this\.tl = \{ key: null, user: null, password: null \};", linea) and linea.index("//") > linea.index("this.tl ="), rel
    for rel in ("fis/pages/contenido.js", "fis/pages/publicar.js", "pages/fisitaap/pagina.js"):
        t = (js / rel).read_text(encoding="utf-8")
        assert "agotado_auto" not in t and "guardarNegocio(n)" in t, rel        # mandan sin la clave: el servidor la deja como estaba
    assert "Tarjeta en línea · no se pagó" in (js / "fis" / "ui.js").read_text(encoding="utf-8")
    ia_src = (RAIZ / "app" / "ia.py").read_text(encoding="utf-8")
    assert 'vivos = [p for p in ps if p.estado != "cancelado"]' in ia_src and "monto sin los cancelados" in ia_src


# ------------------------------------------------------------------------------------------------- cuarta revisión
def test_combo_de_catalogo_web_se_agota_por_sus_componentes(api):  # noqa: F811
    """Decisión de Norman (17/11/2026): «Combos se agotan solos cuando uno de sus componentes llega a 0». Un combo de Ventas en línea ›
    Catálogo web › Combos se agota cuando un componente no alcanza para armar uno, no deja pedir de más y queda disponible al entrar unidades."""
    c = api
    a = _item(c, "Perfume Combo A"); b = _item(c, "Perfume Combo B")
    _ajustar(c, a["id"], 1); _ajustar(c, b["id"], 5)
    r = c.post("/api/fisitaap/combos", json={"nombre": "Combo Dúo", "precio": 3000, "tarifa": 13,
                                              "componentes": [{"producto_id": a["id"], "cantidad": 2}, {"producto_id": b["id"], "cantidad": 1}]})
    assert r.status_code == 200, r.text
    duo = r.json()["id"]
    r = c.post("/api/fisitaap/combos", json={"nombre": "Combo Uno", "precio": 2000, "tarifa": 13, "componentes": [{"producto_id": a["id"], "cantidad": 1}]})
    assert r.status_code == 200, r.text
    uno = r.json()["id"]
    _abrir(c, "agot-440-combo-web")
    ag = _agotados(c, "agot-440-combo-web")
    assert ag[duo] is True and ag[uno] is False                                # pide 2 de A y hay 1; el otro pide 1
    r = _pedir(c, "agot-440-combo-web", [{"producto_id": uno, "cantidad": 2}])
    assert r.status_code == 400 and _detalle(r) == pedidos.MENSAJE_SIN_EXISTENCIAS.format(nombre="Combo Uno"), r.text
    assert _pedir(c, "agot-440-combo-web", [{"producto_id": duo, "cantidad": 1}]).status_code == 400
    _ajustar(c, a["id"], 3)                                                    # A queda en 4: alcanza para 2 dúos
    assert _agotados(c, "agot-440-combo-web")[duo] is False
    r = _pedir(c, "agot-440-combo-web", [{"producto_id": duo, "cantidad": 2}]); assert r.status_code == 200, r.text
    r = _pedir(c, "agot-440-combo-web", [{"producto_id": duo, "cantidad": 3}]); assert r.status_code == 400, r.text


def test_forma_pago_de_lo_devuelto_y_orden_de_la_vista(api):  # noqa: F811
    """Cuarta revisión: un SINPE verificado que se devuelve no dice «Paga al recibir» (como ya no lo dice la tarjeta), y la vista previa
    ordena en orden alfabético de verdad: «Ámbar» y «Óleo» no quedan después de «Zafiro», la Ñ va después de la N."""
    c = api; eid = _eid()
    p = pedidos.Pedido(empresa_id=eid, numero=1, token="t", nombre="QA", telefono="88880000", tipo="recoger", lineas="[]", subtotal=0, impuestos=0, envio=0, total=0,
                       estado="cancelado", pago_medio="sinpe", pago_estado="reembolso_pendiente")
    assert pedidos.forma_pago(p) == "SINPE verificado"
    p.pago_estado = "reembolsado"; assert pedidos.forma_pago(p) == "SINPE verificado"
    p.pago_estado = "rechazado"; assert pedidos.forma_pago(p) == "SINPE rechazado · paga al recibir"
    ui = (RAIZ / "app" / "static" / "js" / "fis" / "ui.js").read_text(encoding="utf-8")
    assert "p.pago_medio === 'sinpe' && ['reembolsado', 'reembolso_pendiente'].includes(p.pago_estado) ? 'SINPE verificado'" in ui
    nombres = ["Zafiro", "Ñandú", "Óleo", "Bergamota", "Ámbar Noir", "Nube"]
    for n in nombres:
        x = _item(c, n); _en_cero(c, x["id"])
    _abrir(c, "agot-440-orden")
    v = c.get("/api/pedidos/catalogo/agotado-vista").json()
    assert v["ejemplos"] == ["Ámbar Noir", "Bergamota", "Nube", "Ñandú", "Óleo", "Zafiro"], v["ejemplos"]
