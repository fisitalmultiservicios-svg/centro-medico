# -*- coding: utf-8 -*-
"""4.42 · L6 (punto 69): los quioscos de marcas se desactivan UNO POR UNO.

Cada activación es una fila de QuioscoEquipo con su identificador (qid), que va dentro del enlace firmado de ese equipo. Lo que se prueba,
todo por la API (el quiosco con su encabezado X-Quiosco, sin sesión) y, la pantalla, montada en Node con el Vue del árbol:

- un equipo desactivado deja de marcar (las cuatro rutas del quiosco responden 401 con el aviso) y los demás siguen;
- activar otra vez el mismo nombre no revive el enlace viejo;
- los enlaces de antes de la 4.42 (sin identificador) valen hasta «Desactivar todos», que también apaga los de la lista;
- un identificador desconocido, vacío, de otra empresa o un enlace retocado o vencido no marcan;
- una empresa no desactiva ni ve los equipos de otra; sin Recursos humanos (o sin sesión) la respuesta es 403 (401) y nada cambia;
- queda en la bitácora, sin el enlace ni su identificador; tope de quioscos activos; la tabla nueva se crea sola en una base de la 4.41;
- la pantalla: lista con fecha y botón «Desactivar» por equipo, la nota de los equipos anteriores y lo que manda cada botón;
- (vuelta 1 de la revisión) esas líneas de la bitácora llevan «rrhh_»: en el historial solo las recibe quien tiene Recursos humanos;
- (vuelta 1) la pantalla manda UNA sola activación aunque se toque dos veces el botón, y con el enlace a la vista no genera otro.
Nada sale a la red. Solo correos @example.test."""
import base64
import json
import pathlib
import shutil
import subprocess
import types
from datetime import datetime, timedelta

import pytest
from sqlalchemy import text
from sqlmodel import Session, select

from app import asistencia, auth, db
from app.config import ahora_cr
from app.db import Empresa, engine, engine_empresa
from tests.test_asistencia import _preparar
from tests.test_exoneraciones import api  # noqa: F401  (fixture)

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")
DESACTIVADO = "Este quiosco fue desactivado. Actívelo de nuevo desde Recursos humanos › Marcas."
SIN_ACTIVAR = "Este equipo no está activado como quiosco de marcas. Actívelo desde Recursos humanos › Marcas."
QA = "qa-exo@example.test"                      # el usuario del fixture `api`
ANA, LUIS = {"codigo": "7", "clave": "2580"}, {"codigo": "12", "clave": "9753"}


# ------------------------------------------------------------------------------------------------ ayudas
def _claves(c):
    assert c.put("/api/asistencia/clave", json={"empleado_id": 1, "clave": "2580"}).status_code == 200
    assert c.put("/api/asistencia/clave", json={"empleado_id": 2, "clave": "9753"}).status_code == 200


def _activar(c, nombre):
    r = c.post("/api/asistencia/quiosco", json={"nombre": nombre})
    assert r.status_code == 200, r.text
    d = r.json()
    assert set(d) == {"token", "equipo", "id"}
    return d["id"], {"X-Quiosco": d["token"]}


def _estado(c, H):
    """(200, nombre del equipo) si ese enlace sigue sirviendo; si no, (código, aviso)."""
    r = c.get("/api/asistencia/quiosco/estado", headers=H)
    return r.status_code, (r.json()["equipo"] if r.status_code == 200 else r.json()["detail"])


def _cfg(c):
    r = c.get("/api/asistencia/config")
    assert r.status_code == 200, r.text
    return r.json()


def _filas(eid):
    with Session(engine_empresa(eid)) as s:
        return [q.model_dump() for q in s.exec(select(asistencia.QuioscoEquipo).order_by(asistencia.QuioscoEquipo.id)).all()]


def _marcas(c):
    ayer, hoy = (ahora_cr().date() - timedelta(days=1)).isoformat(), ahora_cr().date().isoformat()
    return [(m["empleado_id"], m["tipo"], m["equipo"]) for m in c.get(f"/api/asistencia/marcas?desde={ayer}&hasta={hoy}").json()]


def _enlace_de_antes(eid, nombres, equipo):
    """Una empresa que activó sus quioscos ANTES de la 4.42: los nombres en AsistenciaConfig.equipos y un enlace sin identificador
    (lo mismo que firmaba la 4.41: tipo, empresa, serie y nombre del equipo)."""
    with Session(engine_empresa(eid)) as s:
        cfg = asistencia._config(s, eid); cfg.equipos = "|".join(nombres); s.add(cfg); s.commit(); s.refresh(cfg)
        serie = cfg.serie
    return {"X-Quiosco": auth.firmar({"tipo": "quiosco", "eid": eid, "serie": serie, "equipo": equipo}, asistencia.DURACION_QUIOSCO)}


def _otra_empresa(nombre="Otra empresa QA", correo="rh-otra@example.test"):
    """Otra empresa con su propio usuario administrador (para cambiar de empresa en la misma prueba)."""
    with Session(engine) as s:
        b = Empresa(nombre=nombre, numero_id="3101888888", actividad="620100", otras_senas="Costado norte del parque", correo="otra@example.test", ambiente="sandbox")
        s.add(b); s.commit(); s.refresh(b)
    return auth.Contexto(types.SimpleNamespace(id=None, correo=correo, es_superadmin=False, nombre="RH otra"), b, "Administrador")


def _como(ctx):
    from app.main import app
    app.dependency_overrides[auth.contexto] = lambda: ctx


def _ctx():
    from app.main import app
    return app.dependency_overrides[auth.contexto]()


def _bitacora(eid):
    """Las líneas de quioscos del historial, se llamen como se llamen (el nombre exacto, con «rrhh_», lo exige la prueba 7)."""
    with Session(engine) as s:
        return [(a.accion, a.detalle, a.correo) for a in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid, auth.Auditoria.accion.like("%quiosco%")).order_by(auth.Auditoria.id)).all()]


# ================================================================================================ 1 · uno deja de marcar, los demás siguen
def test_un_equipo_desactivado_deja_de_marcar_y_los_demas_siguen(api):  # noqa: F811
    c = api
    eid, H0 = _preparar(c)                                         # «Caja principal»
    _claves(c)
    id1, H1 = _activar(c, "Caja 1")
    id2, H2 = _activar(c, "Tableta cocina")
    assert id1 != id2 and len({H0["X-Quiosco"], H1["X-Quiosco"], H2["X-Quiosco"]}) == 3
    for H, nombre in ((H0, "Caja principal"), (H1, "Caja 1"), (H2, "Tableta cocina")):
        assert _estado(c, H) == (200, nombre)
    m = c.post("/api/asistencia/marcar", json=ANA, headers=H1)
    assert m.status_code == 200 and m.json()["marca"]["tipo"] == "entrada" and m.json()["marca"]["equipo"] == "Caja 1"

    r = c.delete(f"/api/asistencia/quiosco/{id1}")
    assert r.status_code == 200 and r.json() == {"ok": True}

    # el equipo desactivado: las cuatro rutas del quiosco responden 401 con el aviso, antes de mirar el código o la clave
    for ruta, cuerpo in (("/api/asistencia/quiosco/estado", None), ("/api/asistencia/quien", ANA), ("/api/asistencia/marcar", ANA),
                         ("/api/asistencia/marcar", {"codigo": "7", "clave": "0001"}), ("/api/asistencia/marcar", {"codigo": "9999", "clave": "2580"}),
                         ("/api/asistencia/clave/propia", {**ANA, "nueva": "8642"})):
        r = c.get(ruta, headers=H1) if cuerpo is None else c.post(ruta, json=cuerpo, headers=H1)
        assert r.status_code == 401 and r.json()["detail"] == DESACTIVADO, (ruta, r.status_code, r.text)
    assert _marcas(c) == [(1, "entrada", "Caja 1")]                 # no entró ninguna marca más
    with Session(engine_empresa(eid)) as s:                        # la clave mala mandada desde ese equipo no contó como intento, y la clave no cambió
        k = s.exec(select(asistencia.ClaveMarca).where(asistencia.ClaveMarca.empleado_id == 1)).one()
        assert k.intentos == 0 and k.bloqueado_hasta is None and auth.verificar_password("2580", k.clave_hash)

    # los demás siguen marcando, cada uno con su nombre
    m2 = c.post("/api/asistencia/marcar", json=ANA, headers=H2)
    assert m2.status_code == 200 and m2.json()["marca"]["tipo"] == "pausa" and m2.json()["marca"]["equipo"] == "Tableta cocina"
    m3 = c.post("/api/asistencia/marcar", json=LUIS, headers=H0)
    assert m3.status_code == 200 and m3.json()["marca"]["tipo"] == "entrada" and m3.json()["marca"]["equipo"] == "Caja principal"
    assert c.post("/api/asistencia/quien", json=ANA, headers=H2).status_code == 200
    assert c.post("/api/asistencia/clave/propia", json={**LUIS, "nueva": "8642"}, headers=H2).status_code == 200
    assert _marcas(c) == [(1, "entrada", "Caja 1"), (1, "pausa", "Tableta cocina"), (2, "entrada", "Caja principal")]

    # la configuración: los activos con su fecha y quién los activó; «equipos» sigue siendo la lista de nombres
    cfg = _cfg(c)
    assert [(q["nombre"], q["vencido"], q["activado_por"]) for q in cfg["quioscos"]] == [("Caja principal", False, QA), ("Tableta cocina", False, QA)]
    assert [q["id"] for q in cfg["quioscos"]][1] == id2 and cfg["equipos"] == ["Caja principal", "Tableta cocina"] and cfg["anteriores"] == []
    ahora = ahora_cr()
    for q in cfg["quioscos"]:
        d = datetime.fromisoformat(q["activado"])
        assert d.tzinfo is not None and timedelta(0) <= ahora - d < timedelta(minutes=5)
        assert datetime.fromisoformat(q["vence"]) - d == timedelta(days=365)
        assert set(q) == {"id", "nombre", "activado", "activado_por", "vence", "vencido"}       # ni el enlace ni su identificador salen en la lista
    assert H1["X-Quiosco"] not in json.dumps(cfg) and auth.abrir(H2["X-Quiosco"])["qid"] not in json.dumps(cfg)

    # la fila del desactivado queda como constancia (fecha y quién); las otras, intactas
    filas = {f["id"]: f for f in _filas(eid)}
    assert len(filas) == 3 and filas[id1]["nombre"] == "Caja 1" and filas[id1]["desactivado_por"] == QA
    assert timedelta(0) <= ahora_cr() - datetime.fromisoformat(filas[id1]["desactivado"]) < timedelta(minutes=5)
    assert all(f["desactivado"] is None and f["desactivado_por"] is None for i, f in filas.items() if i != id1)

    # repetirlo no da error ni cambia la fecha; uno que no existe da 404 y no toca nada
    with Session(engine_empresa(eid)) as s:
        q = s.get(asistencia.QuioscoEquipo, id1); q.desactivado = "2026-01-05T10:00:00-06:00"; s.add(q); s.commit()
    r = c.delete(f"/api/asistencia/quiosco/{id1}")
    assert r.status_code == 200 and r.json() == {"ok": True, "ya_estaba": True}
    assert {f["id"]: f for f in _filas(eid)}[id1]["desactivado"] == "2026-01-05T10:00:00-06:00"
    r = c.delete("/api/asistencia/quiosco/999999")
    assert r.status_code == 404 and r.json()["detail"] == "Ese quiosco no existe"
    assert c.delete("/api/asistencia/quiosco/abc").status_code == 422
    assert _estado(c, H1) == (401, DESACTIVADO) and _estado(c, H0) == (200, "Caja principal") and _estado(c, H2) == (200, "Tableta cocina")


# ================================================================================================ 2 · reactivar el mismo nombre
def test_reactivar_el_mismo_nombre_no_revive_el_enlace_viejo(api):  # noqa: F811
    c = api
    eid, H0 = _preparar(c)
    _claves(c)
    id0 = _cfg(c)["quioscos"][0]["id"]
    id_v, Hv = _activar(c, "Caja 1")
    assert c.delete(f"/api/asistencia/quiosco/{id_v}").status_code == 200
    assert _estado(c, Hv) == (401, DESACTIVADO)

    id_n, Hn = _activar(c, "Caja 1")                               # el mismo nombre, otra activación
    dv, dn = auth.abrir(Hv["X-Quiosco"]), auth.abrir(Hn["X-Quiosco"])
    assert id_n != id_v and dv["qid"] != dn["qid"] and dv["equipo"] == dn["equipo"] == "Caja 1" and dv["serie"] == dn["serie"] and dv["eid"] == dn["eid"] == eid
    assert _estado(c, Hn) == (200, "Caja 1") and _estado(c, Hv) == (401, DESACTIVADO)        # el viejo sigue muerto
    assert c.post("/api/asistencia/marcar", json=ANA, headers=Hv).status_code == 401
    m = c.post("/api/asistencia/marcar", json=ANA, headers=Hn)
    assert m.status_code == 200 and m.json()["marca"]["equipo"] == "Caja 1" and _marcas(c) == [(1, "entrada", "Caja 1")]
    cfg = _cfg(c)
    assert [(q["id"], q["nombre"]) for q in cfg["quioscos"]] == [(id0, "Caja principal"), (id_n, "Caja 1")] and cfg["equipos"] == ["Caja principal", "Caja 1"]

    # dos equipos con el mismo nombre a la vez: cada uno con su fila; quitar uno no apaga al otro
    id_o, Ho = _activar(c, "Caja 1")
    cfg = _cfg(c)
    assert [(q["id"], q["nombre"]) for q in cfg["quioscos"]] == [(id0, "Caja principal"), (id_n, "Caja 1"), (id_o, "Caja 1")] and cfg["equipos"] == ["Caja principal", "Caja 1"]
    assert c.delete(f"/api/asistencia/quiosco/{id_n}").status_code == 200
    assert _estado(c, Hn) == (401, DESACTIVADO) and _estado(c, Ho) == (200, "Caja 1") and _estado(c, Hv) == (401, DESACTIVADO) and _estado(c, H0)[0] == 200
    assert [(f["id"], bool(f["desactivado"])) for f in _filas(eid)] == [(id0, False), (id_v, True), (id_n, True), (id_o, False)]
    # y desactivar el último «Caja 1» no revive ninguno de los anteriores
    assert c.delete(f"/api/asistencia/quiosco/{id_o}").status_code == 200
    assert [_estado(c, H) for H in (Hv, Hn, Ho)] == [(401, DESACTIVADO)] * 3 and _cfg(c)["equipos"] == ["Caja principal"]


# ================================================================================================ 3 · los enlaces de antes de la 4.42
def test_los_enlaces_de_antes_valen_hasta_desactivar_todos(api):  # noqa: F811
    c = api
    eid, H0 = _preparar(c)
    _claves(c)
    Hv = _enlace_de_antes(eid, ["Vieja", "Bodega"], "Vieja")
    assert "qid" not in auth.abrir(Hv["X-Quiosco"])
    assert _estado(c, Hv) == (200, "Vieja")
    m = c.post("/api/asistencia/marcar", json=ANA, headers=Hv)
    assert m.status_code == 200 and m.json()["marca"]["equipo"] == "Vieja"
    cfg = _cfg(c)
    assert cfg["anteriores"] == ["Vieja", "Bodega"] and cfg["equipos"] == ["Vieja", "Bodega", "Caja principal"] and [q["nombre"] for q in cfg["quioscos"]] == ["Caja principal"]

    # activar y quitar equipos de la lista no toca a los de antes (ni sus nombres)
    id1, H1 = _activar(c, "Caja 1")
    assert c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 200
    assert _estado(c, Hv) == (200, "Vieja") and _estado(c, H0) == (200, "Caja principal") and _estado(c, H1) == (401, DESACTIVADO)
    assert _cfg(c)["anteriores"] == ["Vieja", "Bodega"]
    with Session(engine_empresa(eid)) as s:                        # la fecha del que se quitó uno por uno, para ver que «Desactivar todos» no la cambia
        q = s.get(asistencia.QuioscoEquipo, id1); q.desactivado = "2026-01-05T10:00:00-06:00"; q.desactivado_por = "otra-persona@example.test"; s.add(q); s.commit()

    # «Desactivar todos»: se apagan los de antes y los de la lista
    assert c.delete("/api/asistencia/quiosco").status_code == 200
    assert [_estado(c, H) for H in (Hv, H0, H1)] == [(401, DESACTIVADO)] * 3
    r = c.post("/api/asistencia/marcar", json=ANA, headers=Hv)
    assert r.status_code == 401 and r.json()["detail"] == DESACTIVADO and _marcas(c) == [(1, "entrada", "Vieja")]
    cfg = _cfg(c)
    assert cfg["equipos"] == [] and cfg["quioscos"] == [] and cfg["anteriores"] == []
    filas = _filas(eid)
    assert [(f["nombre"], f["desactivado_por"]) for f in filas] == [("Caja principal", QA), ("Caja 1", "otra-persona@example.test")]
    assert filas[1]["desactivado"] == "2026-01-05T10:00:00-06:00" and timedelta(0) <= ahora_cr() - datetime.fromisoformat(filas[0]["desactivado"]) < timedelta(minutes=5)
    assert c.delete("/api/asistencia/quiosco").status_code == 200       # repetirlo tampoco da error

    # después se activa de nuevo: solo marca el nuevo, ya con fecha y botón propio
    id2, H2 = _activar(c, "Vieja")
    assert _estado(c, H2) == (200, "Vieja") and _estado(c, Hv) == (401, DESACTIVADO) and _estado(c, H0) == (401, DESACTIVADO)
    cfg = _cfg(c)
    assert cfg["equipos"] == ["Vieja"] and cfg["anteriores"] == [] and [(q["id"], q["nombre"]) for q in cfg["quioscos"]] == [(id2, "Vieja")]


# ================================================================================================ 4 · identificadores que no valen
def test_identificador_desconocido_vacio_ajeno_retocado_o_vencido_no_marca(api):  # noqa: F811
    c = api
    eid, H0 = _preparar(c)
    _claves(c)
    datos = auth.abrir(H0["X-Quiosco"])
    assert set(datos) == {"tipo", "eid", "serie", "equipo", "qid", "exp"} and datos["tipo"] == "quiosco" and datos["eid"] == eid and len(datos["qid"]) >= 12
    base = {"tipo": "quiosco", "eid": eid, "serie": datos["serie"], "equipo": "Caja principal"}

    def enlace(extra, segundos=3600):
        return {"X-Quiosco": auth.firmar({**base, **extra}, segundos)}

    assert _estado(c, enlace({"qid": datos["qid"]})) == (200, "Caja principal")          # control: el mismo armado, con el identificador vigente, sí entra
    # con la serie correcta y bien firmado, pero con un identificador que no está en la lista (o vacío, o de otro tipo): no entra
    for qid in ("no-existe-0001", "", None, 0, 1, [datos["qid"]], datos["qid"] + " ", datos["qid"][:-1]):
        assert _estado(c, enlace({"qid": qid})) == (401, DESACTIVADO), repr(qid)
        r = c.post("/api/asistencia/marcar", json=ANA, headers=enlace({"qid": qid}))
        assert r.status_code == 401 and r.json()["detail"] == DESACTIVADO, repr(qid)
    assert _marcas(c) == []

    # el identificador de un quiosco de OTRA empresa no abre esta, y el de esta no abre la otra
    admin = _ctx()
    otra = _otra_empresa()
    _como(otra)
    _, Hb = _activar(c, "Caja de la otra")
    db_ = auth.abrir(Hb["X-Quiosco"])
    assert db_["eid"] == otra.empresa.id != eid and _estado(c, Hb) == (200, "Caja de la otra")
    _como(admin)
    assert _estado(c, enlace({"qid": db_["qid"]})) == (401, DESACTIVADO)
    assert _estado(c, {"X-Quiosco": auth.firmar({"tipo": "quiosco", "eid": otra.empresa.id, "serie": db_["serie"], "equipo": "x", "qid": datos["qid"]}, 3600)}) == (401, DESACTIVADO)
    assert _estado(c, {"X-Quiosco": auth.firmar({"tipo": "quiosco", "eid": otra.empresa.id, "serie": datos["serie"], "equipo": "x", "qid": db_["qid"]}, 3600)}) == (401, DESACTIVADO)

    # un enlace retocado (se le quita el identificador para que parezca de los de antes, con la firma original) no pasa la firma
    cuerpo, firma = H0["X-Quiosco"].split(".")
    sin = json.loads(base64.urlsafe_b64decode(cuerpo + "=" * (-len(cuerpo) % 4))); sin.pop("qid")
    retocado = base64.urlsafe_b64encode(json.dumps(sin).encode()).rstrip(b"=").decode() + "." + firma
    assert _estado(c, {"X-Quiosco": retocado}) == (401, SIN_ACTIVAR)
    # vencido (pasó el año): no entra aunque su fila siga activa
    assert _estado(c, enlace({"qid": datos["qid"]}, -5)) == (401, SIN_ACTIVAR)
    # y si la fila ya no está en la base (p. ej. se restauró un respaldo anterior a la activación): tampoco entra
    assert _estado(c, H0) == (200, "Caja principal")
    with Session(engine_empresa(eid)) as s:
        s.delete(s.exec(select(asistencia.QuioscoEquipo).where(asistencia.QuioscoEquipo.qid == datos["qid"])).one()); s.commit()
    assert _estado(c, H0) == (401, DESACTIVADO)
    assert c.post("/api/asistencia/marcar", json=ANA, headers=H0).status_code == 401 and _marcas(c) == []


# ================================================================================================ 5 · una empresa no toca los equipos de otra
def test_una_empresa_no_desactiva_ni_ve_los_equipos_de_otra(api):  # noqa: F811
    c = api
    eid_a, Ha0 = _preparar(c)
    _claves(c)
    admin_a = _ctx()
    ida1, Ha1 = _activar(c, "Caja A1")
    ida2, Ha2 = _activar(c, "Caja A2")
    ida0 = _cfg(c)["quioscos"][0]["id"]

    otra = _otra_empresa()
    eid_b = otra.empresa.id
    _como(otra)
    idb1, Hb1 = _activar(c, "Caja B1")
    idb2, Hb2 = _activar(c, "Caja B2")
    assert idb1 == ida0 and eid_b != eid_a                          # cada empresa numera los suyos: el mismo número existe en las dos
    cfg_b = _cfg(c)
    assert [q["nombre"] for q in cfg_b["quioscos"]] == ["Caja B1", "Caja B2"] and cfg_b["equipos"] == ["Caja B1", "Caja B2"]     # no ve los de A

    # desde B: un número que solo existe en A da 404; el número que existe en las dos apaga SOLO el de B
    r = c.delete(f"/api/asistencia/quiosco/{ida2}")
    assert r.status_code == 404 and r.json()["detail"] == "Ese quiosco no existe"
    assert c.delete(f"/api/asistencia/quiosco/{idb1}").status_code == 200
    assert _estado(c, Hb1) == (401, DESACTIVADO) and _estado(c, Hb2) == (200, "Caja B2")
    assert [_estado(c, H) for H in (Ha0, Ha1, Ha2)] == [(200, "Caja principal"), (200, "Caja A1"), (200, "Caja A2")]
    assert all(f["desactivado"] is None for f in _filas(eid_a))

    # una fila de otra empresa metida en la base de B (no pasa con una base por empresa: es la segunda cerradura): 404, no se ve, no se toca y no abre
    with Session(engine_empresa(eid_b)) as s:
        ajena = asistencia.QuioscoEquipo(empresa_id=eid_a, qid="qid-ajeno-0001", nombre="De otra empresa", activado=ahora_cr().isoformat(timespec="seconds"))
        s.add(ajena); s.commit(); s.refresh(ajena)
        id_ajena = ajena.id
    r = c.delete(f"/api/asistencia/quiosco/{id_ajena}")
    assert r.status_code == 404 and r.json()["detail"] == "Ese quiosco no existe"
    assert "De otra empresa" not in json.dumps(_cfg(c), ensure_ascii=False)
    serie_b = auth.abrir(Hb2["X-Quiosco"])["serie"]
    assert _estado(c, {"X-Quiosco": auth.firmar({"tipo": "quiosco", "eid": eid_b, "serie": serie_b, "equipo": "x", "qid": "qid-ajeno-0001"}, 3600)}) == (401, DESACTIVADO)

    # «Desactivar todos» en B: apaga los de B y nada más
    assert c.delete("/api/asistencia/quiosco").status_code == 200
    assert _estado(c, Hb2) == (401, DESACTIVADO) and _cfg(c)["equipos"] == []
    fb = {f["id"]: f for f in _filas(eid_b)}
    assert fb[id_ajena]["desactivado"] is None and fb[idb1]["desactivado"] and fb[idb2]["desactivado"]
    assert [_estado(c, H) for H in (Ha0, Ha1, Ha2)] == [(200, "Caja principal"), (200, "Caja A1"), (200, "Caja A2")]

    # de vuelta en A: todo sigue activo y A sigue marcando; A quita uno suyo y B no se entera
    _como(admin_a)
    cfg_a = _cfg(c)
    assert [(q["id"], q["nombre"]) for q in cfg_a["quioscos"]] == [(ida0, "Caja principal"), (ida1, "Caja A1"), (ida2, "Caja A2")]
    m = c.post("/api/asistencia/marcar", json=ANA, headers=Ha2)
    assert m.status_code == 200 and m.json()["marca"]["equipo"] == "Caja A2"
    _como(otra)
    _, Hb3 = _activar(c, "Caja B3")
    _como(admin_a)
    assert c.delete(f"/api/asistencia/quiosco/{ida1}").status_code == 200
    assert _estado(c, Ha1) == (401, DESACTIVADO) and _estado(c, Hb3) == (200, "Caja B3") and _estado(c, Ha2) == (200, "Caja A2")


# ================================================================================================ 6 · permisos
def test_sin_recursos_humanos_no_se_desactiva_ni_se_activa(api):  # noqa: F811
    from app.main import app
    c = api
    eid, H0 = _preparar(c)
    id1, H1 = _activar(c, "Caja 1")
    Hv = _enlace_de_antes(eid, ["Vieja"], "Vieja")
    admin = _ctx()
    antes = (_cfg(c), _filas(eid), _bitacora(eid))
    sin_rrhh = (auth.Contexto(admin.usuario, admin.empresa, "Contador", permisos={"gastos", "contabilidad"}),
                auth.Contexto(admin.usuario, admin.empresa, "Contador"), auth.Contexto(admin.usuario, admin.empresa, "Vendedor"),
                auth.Contexto(admin.usuario, admin.empresa, "Cajero"), auth.Contexto(admin.usuario, admin.empresa, "Solo lectura"))
    try:
        for ctx in sin_rrhh:
            _como(ctx)
            assert c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 403, ctx.rol
            assert c.delete("/api/asistencia/quiosco/999999").status_code == 403, ctx.rol      # ni siquiera se entera de si existe
            assert c.delete("/api/asistencia/quiosco").status_code == 403, ctx.rol
            assert c.post("/api/asistencia/quiosco", json={"nombre": "Caja del cajero"}).status_code == 403, ctx.rol
            assert c.get("/api/asistencia/config").status_code == 403, ctx.rol
        # sin sesión (aunque mande el enlace de un quiosco): 401
        del app.dependency_overrides[auth.contexto]
        assert c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 401
        assert c.delete(f"/api/asistencia/quiosco/{id1}", headers=H1).status_code == 401
        assert c.delete("/api/asistencia/quiosco", headers=H0).status_code == 401
        assert c.post("/api/asistencia/quiosco", json={"nombre": "Sin sesión"}, headers=H0).status_code == 401
    finally:
        _como(admin)
    # nada cambió: los tres enlaces siguen sirviendo, las filas igual y ni una línea nueva en la bitácora
    assert [_estado(c, H) for H in (H0, H1, Hv)] == [(200, "Caja principal"), (200, "Caja 1"), (200, "Vieja")]
    assert (_cfg(c), _filas(eid), _bitacora(eid)) == antes
    # con Recursos humanos (Administrador o Avanzado) sí
    _como(auth.Contexto(admin.usuario, admin.empresa, "Avanzado"))
    try:
        assert c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 200
    finally:
        _como(admin)
    assert _estado(c, H1) == (401, DESACTIVADO) and _estado(c, H0) == (200, "Caja principal")


# ================================================================================================ 7 · bitácora
def test_queda_en_la_bitacora_sin_el_enlace(api):  # noqa: F811
    c = api
    eid, H0 = _preparar(c)
    Hv = _enlace_de_antes(eid, ["Vieja", "Bodega"], "Vieja")
    id1, H1 = _activar(c, "Caja 1")
    with Session(engine_empresa(eid)) as s:
        q = s.get(asistencia.QuioscoEquipo, id1); q.activado = "2026-11-02T07:45:10-06:00"; s.add(q); s.commit()
    assert c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 200
    assert c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 200           # repetido: sin otra línea
    assert c.delete("/api/asistencia/quiosco/999999").status_code == 404           # no existe: sin línea
    assert c.delete("/api/asistencia/quiosco").status_code == 200
    assert c.delete("/api/asistencia/quiosco").status_code == 200                   # ya no queda ninguno
    assert _bitacora(eid) == [
        ("rrhh_quiosco_activar", "Quiosco de marcas «Caja principal» activado", QA),
        ("rrhh_quiosco_activar", "Quiosco de marcas «Caja 1» activado", QA),
        ("rrhh_quiosco_desactivar", "Quiosco de marcas «Caja 1» (activado el 2026-11-02 07:45) desactivado", QA),
        ("rrhh_quiosco_desactivar_todos", "Todos los quioscos de marcas desactivados (1 de la lista y 2 de antes)", QA),
        ("rrhh_quiosco_desactivar_todos", "Todos los quioscos de marcas desactivados (0 de la lista)", QA)]
    # nada de lo que abre un quiosco queda escrito: ni el enlace, ni su firma, ni el identificador, ni la serie
    secretos = set()
    for H in (H0, H1, Hv):
        d = auth.abrir(H["X-Quiosco"]) or {}
        secretos |= {H["X-Quiosco"], *H["X-Quiosco"].split("."), *(str(d[k]) for k in ("serie", "qid") if d.get(k))}
    secretos |= {f["qid"] for f in _filas(eid)}
    assert all(len(x) >= 12 for x in secretos)
    with Session(engine) as s:
        escrito = " ".join(f"{a.accion} {a.detalle}" for a in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid)).all())
    assert len(secretos) >= 8 and not [x for x in secretos if x in escrito]


def test_el_historial_de_los_quioscos_solo_lo_ve_quien_tiene_recursos_humanos(api):  # noqa: F811
    """Vuelta 1 de la revisión: el historial de operaciones lo reciben todos los roles y solo esconde, a quien no tiene Recursos
    humanos, las acciones que empiezan con «rrhh_». Las tres de los quioscos llevan ese prefijo: sin él, un Contador o un Solo lectura
    leían qué equipos marcan, cuándo se activaron y quién lo hizo, aunque la pantalla de Marcas les responde 403."""
    c = api
    eid, H0 = _preparar(c)                                         # «Caja principal»
    id1, H1 = _activar(c, "Tableta cocina")
    assert c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 200
    assert c.delete("/api/asistencia/quiosco").status_code == 200
    with Session(engine) as s:                                     # una línea que NO es de Recursos humanos: esa la reciben todos (control)
        s.add(auth.Auditoria(accion="prueba_l6_control", detalle="Línea de control de la prueba", correo=QA, empresa_id=eid)); s.commit()
    admin = _ctx()

    def historial():
        r = c.get("/api/auth/auditoria?limite=500")
        assert r.status_code == 200, r.text
        return r.json()

    def de_quioscos(filas):
        return [(a["accion"], a["detalle"]) for a in reversed(filas) if "quiosco" in f'{a["accion"]} {a["detalle"]}'.lower()]

    # con Recursos humanos (Administrador, Avanzado): las tres clases de línea, con el nombre del equipo, y también la de control
    todas = de_quioscos(historial())
    assert [a for a, _ in todas] == ["rrhh_quiosco_activar", "rrhh_quiosco_activar", "rrhh_quiosco_desactivar", "rrhh_quiosco_desactivar_todos"]
    assert [d for _, d in todas][:2] == ["Quiosco de marcas «Caja principal» activado", "Quiosco de marcas «Tableta cocina» activado"]
    assert todas[2][1].startswith("Quiosco de marcas «Tableta cocina» (activado el ") and todas[2][1].endswith(") desactivado")
    assert todas[3][1] == "Todos los quioscos de marcas desactivados (1 de la lista)"
    for ctx in (admin, auth.Contexto(admin.usuario, admin.empresa, "Avanzado")):
        _como(ctx)
        try:
            filas = historial()
        finally:
            _como(admin)
        assert de_quioscos(filas) == todas and "prueba_l6_control" in [a["accion"] for a in filas], ctx.rol
    # sin Recursos humanos: reciben el historial (la línea de control sí), pero ninguna de quioscos: ni la acción ni el nombre del equipo
    sin_rrhh = (auth.Contexto(admin.usuario, admin.empresa, "Contador"), auth.Contexto(admin.usuario, admin.empresa, "Solo lectura"),
                auth.Contexto(admin.usuario, admin.empresa, "Vendedor"), auth.Contexto(admin.usuario, admin.empresa, "Cajero"),
                auth.Contexto(admin.usuario, admin.empresa, "Supervisor", permisos={"ver", "ver_todo", "configurar", "usuarios", "gastos", "contabilidad"}))
    try:
        for ctx in sin_rrhh:
            _como(ctx)
            assert c.get("/api/asistencia/config").status_code == 403, ctx.rol
            filas = historial()
            escrito = json.dumps(filas, ensure_ascii=False)
            assert "prueba_l6_control" in [a["accion"] for a in filas], ctx.rol
            assert de_quioscos(filas) == [] and not [a["accion"] for a in filas if a["accion"].startswith("rrhh_")], (ctx.rol, de_quioscos(filas))
            assert "Tableta cocina" not in escrito and "Caja principal" not in escrito and "quiosco" not in escrito.lower(), ctx.rol
    finally:
        _como(admin)


# ================================================================================================ 8 · tope y vencidos
def test_tope_de_quioscos_activos_y_vencidos(api, monkeypatch):  # noqa: F811
    c = api
    eid, H0 = _preparar(c)                                         # 1 activo
    monkeypatch.setattr(asistencia, "MAX_QUIOSCOS", 3)
    id1, H1 = _activar(c, "Caja 1")
    id2, H2 = _activar(c, "Caja 2")                                # 3 activos: el tope
    r = c.post("/api/asistencia/quiosco", json={"nombre": "Caja 3"})
    assert r.status_code == 400 and r.json()["detail"] == "Ya hay 3 quioscos activos. Desactive en la lista los que ya no use y vuelva a intentarlo."
    assert len(_filas(eid)) == 3 and _cfg(c)["equipos"] == ["Caja principal", "Caja 1", "Caja 2"]          # el rechazado no dejó fila
    # al quitar uno, cabe otro
    assert c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 200
    id3, H3 = _activar(c, "Caja 3")
    assert c.post("/api/asistencia/quiosco", json={"nombre": "Caja 4"}).status_code == 400
    # uno activado hace más de un año ya no marca (su enlace venció): sale como vencido y no cuenta para el tope
    with Session(engine_empresa(eid)) as s:
        q = s.get(asistencia.QuioscoEquipo, id2); q.activado = (ahora_cr() - timedelta(days=366)).isoformat(timespec="seconds"); s.add(q); s.commit()
    cfg = _cfg(c)
    assert [(q["nombre"], q["vencido"]) for q in cfg["quioscos"]] == [("Caja 2", True), ("Caja principal", False), ("Caja 3", False)]
    id4, H4 = _activar(c, "Caja 4")
    assert _estado(c, H4) == (200, "Caja 4") and c.post("/api/asistencia/quiosco", json={"nombre": "Caja 5"}).status_code == 400
    # el vencido también se puede quitar de la lista
    assert c.delete(f"/api/asistencia/quiosco/{id2}").status_code == 200
    assert [q["nombre"] for q in _cfg(c)["quioscos"]] == ["Caja principal", "Caja 3", "Caja 4"]


# ================================================================================================ 9 · la tabla nueva y los nombres
def test_la_tabla_nueva_se_crea_sola_en_una_base_de_antes(api):  # noqa: F811
    c = api
    eid, H0 = _preparar(c)
    tabla = asistencia.QuioscoEquipo.__table__
    assert tabla.name == "quioscoequipo" and any(t is tabla for t in db.TABLAS_EMPRESA)
    assert {"empresa_id", "qid"} <= {col.name for i in tabla.indexes for col in i.columns}
    # la configuración de siempre no cambió de forma (los enlaces de antes dependen de su serie)
    assert set(asistencia.AsistenciaConfig.__table__.columns.keys()) == {"id", "empresa_id", "serie", "equipos", "tolerancia_min", "max_turno_horas", "descanso_min_horas"}
    # una base como la dejó la 4.41: sin la tabla y con otra huella de esquema; con sus quioscos de antes
    Hv = _enlace_de_antes(eid, ["Vieja"], "Vieja")
    eng = engine_empresa(eid)
    with eng.begin() as conn:
        conn.execute(text("DROP TABLE quioscoequipo")); conn.exec_driver_sql("PRAGMA user_version = 4410")
    eng.dispose(); db._engines.pop(eid, None)
    assert db.huella_esquema() != 4410
    # al abrirla la versión nueva, la tabla aparece sola: el enlace de antes sigue marcando y ya se puede activar y quitar uno
    assert _estado(c, Hv) == (200, "Vieja")
    with engine_empresa(eid).connect() as conn:
        assert conn.execute(text("SELECT COUNT(*) FROM quioscoequipo")).scalar() == 0
    cfg = _cfg(c)
    assert cfg["quioscos"] == [] and cfg["anteriores"] == ["Vieja"] and cfg["equipos"] == ["Vieja"]
    assert _estado(c, H0) == (401, DESACTIVADO)                    # el de la fila que se fue con la tabla no entra
    id1, H1 = _activar(c, "Caja 1")
    assert _estado(c, H1) == (200, "Caja 1") and c.delete(f"/api/asistencia/quiosco/{id1}").status_code == 200 and _estado(c, H1) == (401, DESACTIVADO)
    assert _estado(c, Hv) == (200, "Vieja")


def test_el_nombre_del_equipo(api):  # noqa: F811
    c = api
    eid, H0 = _preparar(c)
    # los espacios de más se quitan; el nombre va en el enlace y en la lista
    i, H = _activar(c, "  Tableta    cocina  ")
    assert auth.abrir(H["X-Quiosco"])["equipo"] == "Tableta cocina" and _estado(c, H) == (200, "Tableta cocina")
    # solo espacios: no se activa nada (antes quedaba un quiosco sin nombre)
    r = c.post("/api/asistencia/quiosco", json={"nombre": "     "})
    assert r.status_code == 400 and r.json()["detail"] == "Póngale nombre al equipo (Caja 1, Tableta cocina…)"
    assert c.post("/api/asistencia/quiosco", json={"nombre": "a"}).status_code == 422
    assert c.post("/api/asistencia/quiosco", json={"nombre": "x" * 41}).status_code == 422
    assert [f["nombre"] for f in _filas(eid)] == ["Caja principal", "Tableta cocina"]
    # un nombre con la barra que separaba la lista vieja ya no parte nada
    i2, H2 = _activar(c, "Caja|2")
    assert _cfg(c)["equipos"] == ["Caja principal", "Tableta cocina", "Caja|2"] and _estado(c, H2) == (200, "Caja|2")


# ================================================================================================ 10 · la pantalla (Node)
def _nodo():
    return shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)


def _marcas_js():
    return (JS / "pages" / "rrhh" / "marcas.js").read_text(encoding="utf-8")


API_FALSA = r"""
const T = () => globalThis.__t;
export const toast = (m, t) => { T().toasts.push([m, t]); };
export const fecha = v => 'F(' + v + ')', fechaHora = v => 'FH(' + v + ')', hoy = () => '2026-11-20', fmt = v => String(v);
export async function api(ruta, op) {
  const t = T(), metodo = (op && op.method) || 'GET', llave = metodo + ' ' + ruta;
  t.llamadas.push(llave);
  if (t.falla && t.falla.llave === llave) throw new Error(t.falla.mensaje);
  if (llave === 'GET /api/asistencia/config') return JSON.parse(JSON.stringify(t.cfg));
  const nombres = () => [...new Set([...t.cfg.anteriores, ...t.cfg.quioscos.map(q => q.nombre)])];
  const uno = /^DELETE \/api\/asistencia\/quiosco\/(\d+)$/.exec(llave);
  if (uno) { t.cfg.quioscos = t.cfg.quioscos.filter(q => q.id !== +uno[1]); t.cfg.equipos = nombres(); return { ok: true }; }
  if (llave === 'DELETE /api/asistencia/quiosco') { t.cfg.quioscos = []; t.cfg.anteriores = []; t.cfg.equipos = []; return { ok: true }; }
  if (llave === 'POST /api/asistencia/quiosco') {      // como el servidor: cada pedido crea OTRO equipo, con su número y su enlace
    if (t.retener) await new Promise(r => t.retenidos.push(r));     // el pedido se queda «en camino» hasta que la prueba lo suelta
    const id = t.siguiente++;
    t.cfg.quioscos.push({ id, nombre: op.body.nombre, activado: '2026-11-20T10:15:00-06:00', activado_por: 'rh@example.test', vencido: false }); t.cfg.equipos = nombres(); return { token: 'cuerpo.firma-' + id, equipo: op.body.nombre, id };
  }
  if (ruta.startsWith('/api/asistencia/marcas')) return [];
  throw new Error('ruta no esperada: ' + llave);
}
"""

PANTALLA = r"""
import * as Vue from './js/vendor/vue.esm-browser.prod.min.js';
const errores = [];
console.warn = (...a) => errores.push('warn: ' + a.map(String).join(' '));
console.error = (...a) => errores.push('error: ' + a.map(x => x && x.stack ? x.stack : String(x)).join(' '));
const des = s => String(s).replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
const poner = (k, v) => Object.defineProperty(globalThis, k, { value: v, configurable: true, writable: true });
poner('document', { activeElement: null, createElement: () => ({ set innerHTML(v) { this._v = v; }, get textContent() { return des(this._v); },
  get children() { const m = /^<div foo="([\s\S]*)">/.exec(this._v); return [{ getAttribute: () => des(m ? m[1] : '') }]; } }) });
const T = { llamadas: [], toasts: [], preguntas: [], confirma: true, falla: null, guardado: { 'asistencia:quiosco': 'el-enlace-de-este-navegador' }, cfg: @CFG@,
  siguiente: 10, retener: false, retenidos: [], abiertas: [] };
poner('__t', T);
poner('window', { open: (url, destino) => { T.abiertas.push([url, destino]); } });
poner('confirm', m => { T.preguntas.push(m); return T.confirma; });
poner('localStorage', { getItem: k => (k in T.guardado ? T.guardado[k] : null), setItem: (k, v) => { T.guardado[k] = String(v); }, removeItem: k => { delete T.guardado[k]; } });
poner('location', { origin: 'https://pruebas.example.test' });
// un DOM mínimo para el renderizador de Vue: elementos con hijos, props y oyentes
const elemento = tag => ({ tag, children: [], parent: null, props: {}, oyentes: {}, value: '', type: undefined,
  addEventListener(t, f) { (this.oyentes[t] || (this.oyentes[t] = [])).push(f); }, removeEventListener(t, f) { this.oyentes[t] = (this.oyentes[t] || []).filter(x => x !== f); } });
const ops = {
  insert(c, p, a) { if (c.parent) ops.remove(c); const i = a ? p.children.indexOf(a) : -1; if (i >= 0) p.children.splice(i, 0, c); else p.children.push(c); c.parent = p; },
  remove(c) { const p = c.parent; if (p) { p.children.splice(p.children.indexOf(c), 1); c.parent = null; } },
  createElement: elemento,
  createText: text => ({ tag: '#text', text, parent: null }),
  createComment: text => ({ tag: '#comment', text, parent: null }),
  setText(nd, text) { nd.text = text; },
  setElementText(el, text) { for (const c of el.children) c.parent = null; el.children = text === '' ? [] : [{ tag: '#text', text, parent: el }]; },
  parentNode: nd => nd.parent,
  nextSibling(nd) { const p = nd.parent; return p ? p.children[p.children.indexOf(nd) + 1] || null : null; },
  querySelector: () => null,
  setScopeId() {},
  patchProp(el, key, prev, next) { el.props[key] = next; if (key === 'type') el.type = next; if (key === 'value') el.value = next; },
};
const C = (await import('./js/pages/rrhh/marcas.js')).default;
const raiz = elemento('#raiz');
const app = Vue.createRenderer(ops).createApp(C, { params: { tab: 'quiosco' } });
app.config.errorHandler = e => errores.push('vue: ' + (e && e.stack ? e.stack : String(e)));
for (const n of ['PageHead', 'Field', 'Modal', 'Empty']) app.component(n, { template: '<div><slot></slot></div>' });
const vm = app.mount(raiz);
const espera = async () => { for (let i = 0; i < 6; i++) { await new Promise(r => setTimeout(r, 0)); await Vue.nextTick(); } };
await espera();
const clases = el => String((el.props && el.props.class) || '').split(/\s+/).filter(Boolean);
const texto = nd => nd.tag === '#text' ? nd.text : nd.tag === '#comment' ? '' : (nd.children || []).map(texto).join('');
const limpio = nd => texto(nd).replace(/\s+/g, ' ').trim();
const todos = (nd, f, out = []) => { if (f(nd)) out.push(nd); for (const c of nd.children || []) todos(c, f, out); return out; };
const tarjeta = () => todos(raiz, x => x.tag === 'div' && clases(x).includes('card') && (x.children || []).some(h => h.tag === 'h2' && limpio(h) === 'Quioscos para marcar'))[0];
const filas = () => { const t = todos(tarjeta(), x => x.tag === 'tbody')[0]; return t ? t.children.filter(x => x.tag === 'tr') : []; };
const boton = (nd, t) => todos(nd, x => x.tag === 'button' && limpio(x) === t)[0] || null;
const foto = () => ({
  encabezados: todos(tarjeta(), x => x.tag === 'th').map(limpio),
  filas: filas().map(tr => tr.children.filter(x => x.tag === 'td').map(limpio)),
  insignias: filas().map(tr => todos(tr, x => x.tag === 'span' && clases(x).includes('badge')).map(b => [limpio(b), b.props.title || ''])),
  botones: filas().map(tr => todos(tr, x => x.tag === 'button').map(limpio)),
  parrafos: todos(tarjeta(), x => x.tag === 'p').map(limpio),
  botonTodos: !!boton(tarjeta(), 'Desactivar todos'),
});
const clic = async b => { await b.props.onClick({ target: b }); await espera(); };
const corte = () => { const r = { llamadas: T.llamadas.splice(0), toasts: T.toasts.splice(0), preguntas: T.preguntas.splice(0), guardado: T.guardado['asistencia:quiosco'] || null }; return r; };
const out = {};
out.alCargar = { ...corte(), ...foto() };
// 1) «Desactivar» en la segunda fila (id 8) y se contesta que no
T.confirma = false; await clic(boton(filas()[1], 'Desactivar'));
out.no = { ...corte(), ...foto() };
// 2) lo mismo y se contesta que sí
T.confirma = true; await clic(boton(filas()[1], 'Desactivar'));
out.si = { ...corte(), ...foto() };
// 3) el servidor falla al quitar el otro «Caja 1» (id 9, ahora en la segunda fila)
T.falla = { llave: 'DELETE /api/asistencia/quiosco/9', mensaje: 'No se pudo conectar con el servidor' }; await clic(boton(filas()[1], 'Desactivar'));
out.falla = { ...corte(), ...foto() }; T.falla = null;
// 4) enlace para otro equipo: el texto que acompaña al enlace y la fila nueva
await clic(boton(tarjeta(), 'Enlace para otro equipo')); vm.quiosco.nombre = 'Entrada'; await espera(); await clic(boton(tarjeta(), 'Generar enlace'));
out.enlace = { ...corte(), ...foto(), valor: (todos(tarjeta(), x => x.tag === 'input' && x.props.readonly !== undefined)[0] || {}).value || null };
// 5) «Desactivar todos»
await clic(boton(tarjeta(), 'Desactivar todos'));
out.todos = { ...corte(), ...foto() };
out.errores = errores;
console.log(JSON.stringify(out));
process.exit(0);
"""

CFG_PANTALLA = {
    "equipos": ["Bodega vieja", "Recepción", "Caja 1", "Tableta cocina"], "anteriores": ["Bodega vieja", "Recepción"],
    "quioscos": [{"id": 7, "nombre": "Caja 1", "activado": "2025-11-01T08:00:00-06:00", "activado_por": "rh@example.test", "vence": "2026-11-01T08:00:00-06:00", "vencido": True},
                 {"id": 8, "nombre": "Tableta cocina", "activado": "2026-11-19T15:30:00-06:00", "activado_por": None, "vence": "2027-11-19T15:30:00-06:00", "vencido": False},
                 {"id": 9, "nombre": "Caja 1", "activado": "2026-11-20T09:00:00-06:00", "activado_por": "rh@example.test", "vence": "2027-11-20T09:00:00-06:00", "vencido": False}],
    "tolerancia_min": 10, "max_turno_horas": 16, "descanso_min_horas": 13, "empleados": [], "tipos": {}}
NOTA_ANTERIORES = ("Activados antes de esta versión (sin fecha): Bodega vieja, Recepción. Estos no se pueden desactivar uno por uno: use «Desactivar todos» "
                   "y active de nuevo los que sigan en uso.")
FILA_7 = ["🖥 Caja 1 Vencido", "FH(2025-11-01T08:00:00-06:00) · rh@example.test", "Desactivar"]
FILA_8 = ["🖥 Tableta cocina", "FH(2026-11-19T15:30:00-06:00)", "Desactivar"]
FILA_9 = ["🖥 Caja 1", "FH(2026-11-20T09:00:00-06:00) · rh@example.test", "Desactivar"]


def _pantalla(tmp_path, cfg, guion=PANTALLA):
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    raiz = tmp_path / "js"
    falsos = {"api.js": API_FALSA, "app.js": "export const sesion = { puede: () => true };\n", "pages/reportes/_montos.js": "export const exportarTabla = () => {};\n"}
    for ruta, texto in falsos.items():
        (raiz / ruta).parent.mkdir(parents=True, exist_ok=True)
        (raiz / ruta).write_text(texto, encoding="utf-8")
    for rel in ("pages/rrhh/marcas.js", "vendor/vue.esm-browser.prod.min.js"):
        (raiz / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(JS / rel, raiz / rel)
    (tmp_path / "package.json").write_text('{"type": "module"}', encoding="utf-8")
    (tmp_path / "prueba.mjs").write_text(guion.replace("@CFG@", json.dumps(cfg)), encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=120, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-3000:]
    return json.loads(r.stdout.strip().splitlines()[-1])


def test_pantalla_lista_con_fecha_y_boton_por_equipo(tmp_path):
    """La pestaña «Quiosco y claves» de marcas.js, montada con el Vue del árbol sobre un DOM mínimo: lo que se ve y lo que manda cada botón."""
    o = _pantalla(tmp_path, CFG_PANTALLA)
    assert o["errores"] == [], o["errores"]
    # al cargar: una fila por equipo con su fecha de activación (y quién), su botón, la marca de vencido y la nota de los de antes
    a = o["alCargar"]
    assert a["llamadas"][0] == "GET /api/asistencia/config" and a["encabezados"][:3] == ["Equipo", "Activado", ""]
    assert a["filas"] == [FILA_7, FILA_8, FILA_9] and a["botones"] == [["Desactivar"]] * 3
    assert [[x[0] for x in f] for f in a["insignias"]] == [["Vencido"], [], []] and "ya no marca" in a["insignias"][0][0][1]
    assert NOTA_ANTERIORES in a["parrafos"] and "Ningún quiosco activado todavía." not in a["parrafos"] and a["botonTodos"] is True
    # se contesta que no: no se manda nada y la lista queda igual
    n = o["no"]
    assert n["preguntas"] == ["¿Desactivar el quiosco «Tableta cocina»? Ese equipo ya no podrá marcar; los demás siguen igual."]
    assert n["llamadas"] == [] and n["toasts"] == [] and n["filas"] == [FILA_7, FILA_8, FILA_9]
    # se contesta que sí: se manda quitar ESE equipo (por su número), se avisa y la lista se vuelve a pedir; los demás siguen
    s = o["si"]
    assert s["preguntas"] == n["preguntas"] and s["llamadas"] == ["DELETE /api/asistencia/quiosco/8", "GET /api/asistencia/config"]
    assert s["toasts"] == [["Quiosco «Tableta cocina» desactivado", "ok"]] and s["filas"] == [FILA_7, FILA_9]
    assert s["guardado"] == "el-enlace-de-este-navegador"          # quitar un equipo no borra el enlace guardado en este navegador
    assert NOTA_ANTERIORES in s["parrafos"]
    # el servidor falla: sale el error y la fila sigue en la lista
    f = o["falla"]
    assert f["preguntas"] == ["¿Desactivar el quiosco «Caja 1»? Ese equipo ya no podrá marcar; los demás siguen igual."]
    assert f["llamadas"] == ["DELETE /api/asistencia/quiosco/9"] and f["toasts"] == [["No se pudo conectar con el servidor", "err"]] and f["filas"] == [FILA_7, FILA_9]
    # enlace para otro equipo: dice cómo deja de servir y el equipo nuevo entra a la lista con su fecha
    e = o["enlace"]
    assert e["llamadas"] == ["POST /api/asistencia/quiosco", "GET /api/asistencia/config"] and e["valor"] == "https://pruebas.example.test/marcar.html#q=cuerpo.firma-10"
    assert any("(vale un año; deja de servir si lo desactiva en la lista o con «Desactivar todos»)" in p for p in e["parrafos"])
    assert e["filas"] == [FILA_7, FILA_9, ["🖥 Entrada", "FH(2026-11-20T10:15:00-06:00) · rh@example.test", "Desactivar"]]
    # «Desactivar todos» sigue mandando lo de siempre (sin número) y borra el enlace de este navegador; la lista y la nota desaparecen
    t = o["todos"]
    assert t["preguntas"] == ["¿Desactivar todos los quioscos? Cada equipo tendrá que activarse de nuevo."]
    assert t["llamadas"] == ["DELETE /api/asistencia/quiosco", "GET /api/asistencia/config"] and t["toasts"] == [["Quioscos desactivados", "ok"]] and t["guardado"] is None
    assert t["filas"] == [] and t["encabezados"] == [] and NOTA_ANTERIORES not in t["parrafos"] and "Ningún quiosco activado todavía." in t["parrafos"] and t["botonTodos"] is False


SOLO_CARGAR = PANTALLA[:PANTALLA.index("// 1) «Desactivar» en la segunda fila")] + "out.errores = errores;\nconsole.log(JSON.stringify(out));\nprocess.exit(0);\n"


def test_pantalla_solo_con_equipos_de_antes_o_sin_ninguno(tmp_path):
    base = {"tolerancia_min": 10, "max_turno_horas": 16, "descanso_min_horas": 13, "empleados": [], "tipos": {}}
    # una empresa que todavía no ha activado nada con la 4.42: solo la nota de los de antes y «Desactivar todos» (sin tabla)
    o = _pantalla(tmp_path / "antes", {**base, "equipos": ["Bodega vieja", "Recepción"], "anteriores": ["Bodega vieja", "Recepción"], "quioscos": []}, SOLO_CARGAR)
    a = o["alCargar"]
    assert o["errores"] == [] and a["filas"] == [] and a["encabezados"] == [] and NOTA_ANTERIORES in a["parrafos"] and a["botonTodos"] is True
    assert "Ningún quiosco activado todavía." not in a["parrafos"]
    # sin ningún quiosco: el aviso de siempre, sin tabla, sin nota y sin «Desactivar todos»
    o = _pantalla(tmp_path / "nada", {**base, "equipos": [], "anteriores": [], "quioscos": []}, SOLO_CARGAR)
    a = o["alCargar"]
    assert o["errores"] == [] and a["filas"] == [] and a["botonTodos"] is False and "Ningún quiosco activado todavía." in a["parrafos"]
    assert not [p for p in a["parrafos"] if p.startswith("Activados antes de esta versión")]


# ---- vuelta 1 de la revisión: el doble envío al activar un quiosco
DOBLE_ENVIO = PANTALLA[:PANTALLA.index("// 1) «Desactivar» en la segunda fila")] + r"""
const pulsar = b => b.props.onClick({ target: b });                // sin esperar la respuesta: devuelve la promesa del método
const soltar = () => { for (const f of T.retenidos.splice(0)) f(); };
const campo = () => todos(tarjeta(), x => x.tag === 'input' && x.props.maxlength === '40')[0];
const enter = () => campo().props.onKeyup({ key: 'Enter', target: campo() });
const BOTONES = ['Generar enlace', 'Activar y abrir el quiosco', 'Cancelar', 'Cerrar', 'Activar este equipo', 'Enlace para otro equipo'];
const cuadro = () => ({ abierto: vm.quiosco !== null, botones: BOTONES.filter(t => boton(tarjeta(), t)),
  apagados: BOTONES.filter(t => { const b = boton(tarjeta(), t); return !!b && b.props.disabled === true; }),
  enlaces: todos(tarjeta(), x => x.tag === 'input' && x.props.readonly !== undefined).map(x => x.value) });
const paso = () => ({ ...corte(), filas: foto().filas, ...cuadro(), abiertas: T.abiertas.splice(0) });
let b, p;
// a) «Enlace para otro equipo»: dos clics seguidos en «Generar enlace» y un Enter en el nombre, con el pedido todavía en camino
T.retener = true;
await clic(boton(tarjeta(), 'Enlace para otro equipo')); vm.quiosco.nombre = 'Entrada'; await espera();
out.antes = paso();
b = boton(tarjeta(), 'Generar enlace');
p = [pulsar(b), pulsar(b)]; await espera(); p.push(enter()); await espera();
out.enCamino = paso();
soltar(); await Promise.all(p); await espera();
out.dosClics = paso();
// b) con el enlace ya a la vista: ni Enter ni otra llamada al método generan otro; el cuadro se cierra con «Cerrar»
T.retener = false;
await enter(); await vm.activarQuiosco(); await espera();
out.conEnlace = paso();
await clic(boton(tarjeta(), 'Cerrar'));
out.cerrado = paso();
// para otro enlace se toca otra vez «Enlace para otro equipo»: el cuadro vuelve a empezar y genera uno más (a propósito)
await clic(boton(tarjeta(), 'Enlace para otro equipo'));
out.otraVez = paso();
vm.quiosco.nombre = 'Bodega'; await espera(); await clic(boton(tarjeta(), 'Generar enlace'));
out.otro = paso();
// c) «Activar este equipo»: dos clics seguidos en «Activar y abrir el quiosco»
T.retener = true;
await clic(boton(tarjeta(), 'Activar este equipo')); vm.quiosco.nombre = 'Caja 9'; await espera();
b = boton(tarjeta(), 'Activar y abrir el quiosco');
p = [pulsar(b), pulsar(b)]; await espera();
out.aquiEnCamino = paso();
soltar(); await Promise.all(p); await espera();
out.aqui = paso();
// d) el cuadro deja de estar abierto con el pedido en camino: el equipo queda activado y no sale ningún aviso de error
await clic(boton(tarjeta(), 'Activar este equipo')); vm.quiosco.nombre = 'Caja 10'; await espera();
p = [pulsar(boton(tarjeta(), 'Activar y abrir el quiosco'))]; await espera(); vm.quiosco = null; await espera();
soltar(); await Promise.all(p); await espera();
out.cerradoEnCamino = paso();
// e) un nombre muy corto y un fallo del servidor no dejan el botón apagado: se puede intentar de nuevo
T.retener = false;
await clic(boton(tarjeta(), 'Enlace para otro equipo')); vm.quiosco.nombre = ' a '; await espera(); await clic(boton(tarjeta(), 'Generar enlace'));
out.corto = paso();
vm.quiosco.nombre = 'Portón'; await espera();
T.falla = { llave: 'POST /api/asistencia/quiosco', mensaje: 'No se pudo conectar con el servidor' }; await clic(boton(tarjeta(), 'Generar enlace'));
out.fallo = paso(); T.falla = null;
await clic(boton(tarjeta(), 'Generar enlace'));
out.reintento = paso();
out.errores = errores;
console.log(JSON.stringify(out));
process.exit(0);
"""


def test_pantalla_doble_clic_al_activar_no_crea_dos_equipos(tmp_path):
    """Cada POST crea un equipo con su propio enlace, así que la pantalla manda UNO solo aunque se toque dos veces el botón (o Enter)
    antes de la respuesta, y con el enlace ya a la vista no genera otro desde el mismo cuadro. La API falsa deja el pedido «en camino»
    hasta que la prueba lo suelta y da un número distinto por cada POST, como el servidor."""
    cfg = {"equipos": ["Caja 1"], "anteriores": [], "quioscos": [CFG_PANTALLA["quioscos"][2]], "tolerancia_min": 10, "max_turno_horas": 16,
           "descanso_min_horas": 13, "empleados": [], "tipos": {}}
    o = _pantalla(tmp_path, cfg, DOBLE_ENVIO)
    assert o["errores"] == [], o["errores"]
    POST, GET = "POST /api/asistencia/quiosco", "GET /api/asistencia/config"
    nueva = lambda nombre: [f"🖥 {nombre}", "FH(2026-11-20T10:15:00-06:00) · rh@example.test", "Desactivar"]   # noqa: E731
    enlace = lambda n: [f"https://pruebas.example.test/marcar.html#q=cuerpo.firma-{n}"]                         # noqa: E731
    abrir, cerrar = ["Activar este equipo", "Enlace para otro equipo"], ["Cerrar", "Activar este equipo", "Enlace para otro equipo"]
    generar, activar = ["Generar enlace", "Cancelar"] + abrir, ["Activar y abrir el quiosco", "Cancelar"] + abrir
    assert o["alCargar"]["filas"] == [FILA_9]

    # a) dos clics seguidos y un Enter con el pedido en camino: UN solo pedido; mientras viaja, los botones quedan apagados
    x = o["antes"]
    assert x["llamadas"] == [] and x["botones"] == generar and x["apagados"] == [] and x["enlaces"] == []
    x = o["enCamino"]
    assert x["llamadas"] == [POST] and x["botones"] == generar and x["apagados"] == generar and x["filas"] == [FILA_9]
    x = o["dosClics"]
    assert x["llamadas"] == [GET] and x["toasts"] == [] and x["filas"] == [FILA_9, nueva("Entrada")]            # una sola fila nueva
    assert x["enlaces"] == enlace(10) and x["botones"] == cerrar and x["apagados"] == []                         # ya no hay «Generar enlace»
    # b) con el enlace a la vista no se genera otro (ni con Enter ni llamando al método); «Cerrar» cierra el cuadro
    x = o["conEnlace"]
    assert x["llamadas"] == [] and x["toasts"] == [] and x["filas"] == [FILA_9, nueva("Entrada")] and x["enlaces"] == enlace(10) and x["botones"] == cerrar
    x = o["cerrado"]
    assert x["abierto"] is False and x["botones"] == abrir and x["enlaces"] == [] and x["llamadas"] == []
    # para otro enlace: «Enlace para otro equipo» otra vez; ese sí crea otro equipo, con otro enlace
    x = o["otraVez"]
    assert x["abierto"] is True and x["botones"] == generar and x["apagados"] == [] and x["enlaces"] == [] and x["llamadas"] == []
    x = o["otro"]
    assert x["llamadas"] == [POST, GET] and x["filas"] == [FILA_9, nueva("Entrada"), nueva("Bodega")] and x["enlaces"] == enlace(11) and x["botones"] == cerrar
    # c) «Activar y abrir el quiosco» dos veces seguidas: un pedido, una fila, el enlace de ESA fila en el navegador y ningún aviso de error
    x = o["aquiEnCamino"]
    assert x["llamadas"] == [POST] and x["botones"] == activar and x["apagados"] == activar and x["guardado"] == "el-enlace-de-este-navegador"
    x = o["aqui"]
    assert x["llamadas"] == [GET] and x["toasts"] == [["Este equipo quedó activado como quiosco «Caja 9»", "ok"]] and x["guardado"] == "cuerpo.firma-12"
    assert x["filas"] == [FILA_9, nueva("Entrada"), nueva("Bodega"), nueva("Caja 9")] and x["abierto"] is False and x["apagados"] == []
    assert x["abiertas"] == [["/marcar.html", "_blank"]] and x["botones"] == abrir
    # d) si el cuadro ya no está cuando llega la respuesta: termina igual, sin el aviso crudo «Cannot read properties of null»
    x = o["cerradoEnCamino"]
    assert x["llamadas"] == [POST, GET] and x["toasts"] == [["Este equipo quedó activado como quiosco «Caja 10»", "ok"]] and x["guardado"] == "cuerpo.firma-13"
    assert x["filas"][-1] == nueva("Caja 10") and len(x["filas"]) == 5 and x["abierto"] is False and x["abiertas"] == [["/marcar.html", "_blank"]]
    # e) el nombre muy corto no manda nada; un fallo del servidor avisa y deja el botón libre; el segundo intento sí genera el enlace
    x = o["corto"]
    assert x["llamadas"] == [] and x["toasts"] == [["Póngale nombre al equipo (Caja 1, Tableta cocina…)", "err"]] and x["apagados"] == [] and x["botones"] == generar
    x = o["fallo"]
    assert x["llamadas"] == [POST] and x["toasts"] == [["No se pudo conectar con el servidor", "err"]] and x["botones"] == generar and x["apagados"] == []
    assert x["enlaces"] == [] and len(x["filas"]) == 5
    x = o["reintento"]
    assert x["llamadas"] == [POST, GET] and x["toasts"] == [] and x["enlaces"] == enlace(14) and x["filas"][-1] == nueva("Portón") and len(x["filas"]) == 6


def test_marcas_js_sintaxis_y_comentarios(tmp_path):
    js = _marcas_js()
    assert "\r" not in js                                           # conserva sus finales de línea (LF)
    for n, linea in enumerate(js.splitlines(), 1):                 # la regla de siempre: un // a mitad de línea con llaves rompió el sistema dos veces
        if "//" in linea and "://" not in linea:
            resto = linea.split("//", 1)[1]
            assert "{" not in resto and "}" not in resto and "', " not in resto, (n, linea)
    plantilla = js[js.index("template: `") + len("template: `"):js.rindex("`,\n  setup()")]
    assert "`" not in plantilla and "${" not in plantilla           # la plantilla es una cadena entre comillas invertidas
    node = _nodo()
    if not node:
        pytest.skip("sin Node.js en este equipo")
    copia = tmp_path / "marcas.mjs"
    copia.write_text(js, encoding="utf-8")
    r = subprocess.run([node, "--check", str(copia)], capture_output=True, text=True, timeout=60)
    assert r.returncode == 0, r.stderr
