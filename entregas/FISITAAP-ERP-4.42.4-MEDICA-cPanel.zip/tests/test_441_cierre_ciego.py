# -*- coding: utf-8 -*-
"""4.41: cierre de caja ciego completo, con opciones por caja (pedido de Norman: «Ciego completo, todo esto deberían ser opciones que
se encienden o se apagan»), y la colilla térmica sin «?» en lugar de «₡».

Opciones de la caja (Punto de venta › Configuración › Caja y comprobante), con valores por omisión = ciego completo:
  cierre_ciego (ya existía, encendido)      el cajero cuenta sin ver lo esperado
  cierre_corte_cajero (apagado)             al cerrar o entregar el turno ve lo del sistema y el faltante o excedente
  colilla_completa (apagado)                su colilla lleva lo del sistema y el faltante; apagado = solo lo que declaró
  colilla_auto (encendido)                  la colilla sale sola al cerrar
Sin cierre a ciegas el cajero ya vio todo al contar; quien ve todo o configura (Administrador y Avanzado en el punto de venta) ve siempre el
corte completo."""
import pathlib
import re

from test_425_ultimos_pantallas import MONTAR, _node

from app import escpos

RAIZ = pathlib.Path(__file__).resolve().parents[1]
JS = RAIZ / "app" / "static" / "js"


def _js(rel: str) -> str:
    return (JS / rel).read_text(encoding="utf-8")


FALSO_API = """
const datos = {};
export const mock = { get: (k, d) => (k in datos ? datos[k] : d), set: (k, v) => { datos[k] = v; return v; }, actualizar() {}, nextId: () => 1, _datos: datos };
export const hoy = () => '2026-11-19', precioCliente = () => 0, otroImpLinea = () => ({ monto: 0, base: 0 });
export const TZ_CR = 'America/Costa_Rica';
export function fmt(n, d = 2) { return (+n || 0).toFixed(d); }
export function money(v, m) { return (m === 'USD' ? '$' : '₡') + (+v || 0).toFixed(2); }
export function fecha(x) { return String(x || '').slice(0, 10); }
export async function api() { return {}; }
"""
FALSO_APP = "export const sesion = { empresa_id: 1, sucursal_id: null, usuario: { correo: 'cajera-441@example.test' }, puede: p => !!(globalThis.__puede || {})[p] };\n"


# ------------------------------------------------------------------------------------------------ 1) qué ve el cajero según la caja
def test_opciones_del_cierre_por_caja(tmp_path):
    r = _node(tmp_path, """
const D = await import('./js/pages/pos/_datos.js');
const { mock } = await import('./js/api.js');
const out = {};
const S = (id, caja) => ({ id: 9, terminal_id: id, caja });
out.base = ['cierre_ciego', 'cierre_corte_cajero', 'colilla_completa', 'colilla_auto'].map(k => D.TERMINAL_BASE[k]);
// sin configuración: la caja 1 por omisión
out.sin_cfg = D.opcionesCierre(S(1, 'Caja 1'));
// configuración de una versión anterior (sin los campos nuevos): ciego completo
mock.set('pos_config', { terminales: [{ id: 1, nombre: 'Caja 1' }, { id: 2, nombre: 'Barra', cierre_ciego: false },
  { id: 3, nombre: 'Corte', cierre_corte_cajero: true }, { id: 4, nombre: 'Colilla', colilla_completa: true }, { id: 5, nombre: 'Sin colilla', colilla_auto: false },
  { id: 6, nombre: 'Todo', cierre_corte_cajero: true, colilla_completa: true }, { id: 7, nombre: 'Abierta', cierre_ciego: false, cierre_corte_cajero: false, colilla_completa: false }] });
out.cajero = Object.fromEntries([1, 2, 3, 4, 5, 6, 7].map(i => [i, D.opcionesCierre(S(i))]));
out.por_nombre = D.opcionesCierre({ id: 3, caja: 'Corte' });        // sesión vieja sin terminal_id
out.borrada = D.opcionesCierre(S(99, 'No existe'));                  // la caja ya no está: ciego completo
out.borrada_sin_ciego = D.opcionesCierre({ ...S(99, 'No existe'), cierre_ciego: false });   // ...salvo que se cerró sin cierre a ciegas
// la caja se borró y otra quedó con su nombre: la sesión (con terminal_id) no toma las opciones de la otra
out.borrada_mismo_nombre = [D.opcionesCierre({ ...S(98, 'Barra'), cierre_ciego: true }), D.opcionesCierre({ ...S(97, 'Todo'), cierre_ciego: true })];
out.nula = D.opcionesCierre(null);
out.ciego = [D.cierreCiego(S(1)), D.cierreCiego(S(2)), D.cierreCiego(S(99, 'x')), D.cierreCiego({ ...S(99, 'x'), cierre_ciego: false }), D.cierreCiego({ ...S(1), cierre_ciego: false })];
const deLaCaja = () => [1, 2, 3, 4, 5, 6, 7].map(i => D.corteDeLaCaja(S(i))).concat([D.corteDeLaCaja(S(99, 'x')), D.corteDeLaCaja({ ...S(99, 'x'), cierre_ciego: false })]);
out.de_la_caja = deLaCaja();
const colillaDeLaCaja = () => [1, 2, 3, 4, 5, 6, 7].map(i => D.colillaDeLaCaja(S(i))).concat([D.colillaDeLaCaja(S(99, 'x')), D.colillaDeLaCaja({ ...S(99, 'x'), cierre_ciego: false })]);
out.colilla_de_la_caja = colillaDeLaCaja();
globalThis.__puede = { ver_todo: true };                              // quien ve todo (Administrador, Avanzado)
out.admin = Object.fromEntries([1, 5].map(i => [i, D.opcionesCierre(S(i))]));
out.de_la_caja_admin = deLaCaja();                                    // lo compartido no depende de quién lo genera
out.colilla_de_la_caja_admin = colillaDeLaCaja();
globalThis.__puede = { configurar: true };
out.configura = D.opcionesCierre(S(1));
globalThis.__puede = {};
// guardar la configuración conserva lo elegido
D.guardarConfig({ terminales: [{ id: 1, nombre: 'Caja 1', cierre_corte_cajero: true, colilla_completa: false, colilla_auto: false }] });
const g = mock._datos.pos_config.terminales[0];
out.guardada = [g.cierre_ciego, g.cierre_corte_cajero, g.colilla_completa, g.colilla_auto];
console.log(JSON.stringify(out));
""", archivos=("pages/pos/_datos.js",), falsos={"api.js": FALSO_API, "app.js": FALSO_APP})
    ciego_completo = {"ciego": True, "todo": False, "corte": False, "colilla": False, "auto": True}
    todo = {"ciego": True, "todo": True, "corte": True, "colilla": True, "auto": True}
    sin_ciego = {"ciego": False, "todo": True, "corte": True, "colilla": True, "auto": True}
    assert r["base"] == [True, False, False, True], r
    assert r["sin_cfg"] == ciego_completo, r
    c = r["cajero"]
    assert c["1"] == ciego_completo, r                                                        # caja de antes, sin las opciones nuevas
    assert c["2"] == sin_ciego, r                                                            # sin cierre a ciegas: ya vio todo al contar
    assert c["3"] == {**ciego_completo, "corte": True}, r                                    # ve el corte; la colilla, solo lo declarado
    assert c["4"] == ciego_completo, r                    # «colilla completa» sin «ve el corte» no cuenta: la colilla tampoco lleva el corte
    assert c["5"] == {**ciego_completo, "auto": False}, r
    assert c["6"] == {**ciego_completo, "corte": True, "colilla": True}, r
    assert c["7"] == sin_ciego, r
    assert r["por_nombre"] == {**ciego_completo, "corte": True}, r
    assert r["borrada"] == ciego_completo and r["nula"] == ciego_completo and r["borrada_sin_ciego"] == sin_ciego, r
    assert r["borrada_mismo_nombre"] == [ciego_completo, ciego_completo], r
    assert r["ciego"] == [True, False, True, False, True], r          # la caja que existe manda sobre lo guardado en la sesión
    assert r["de_la_caja"] == [False, True, True, False, False, True, True, False, True] == r["de_la_caja_admin"], r
    assert r["colilla_de_la_caja"] == [False, True, False, False, False, True, True, False, True] == r["colilla_de_la_caja_admin"], r
    assert r["admin"]["1"] == todo and r["admin"]["5"] == {**todo, "auto": False} and r["configura"] == todo, r
    assert r["guardada"] == [True, True, False, False], r


# ------------------------------------------------------------------------------------------------ 2) la colilla térmica
COLILLA = """
process.env.TZ = 'Asia/Tokyo';                                     // la computadora en otra zona: la colilla igual sale con la hora de Costa Rica
const A = await import('./js/pages/pos/_agente.js');
const M = (v, m) => (m === 'USD' ? '$' : '₡') + (+v || 0).toFixed(2);
const caja = { caja: 'Caja 1', cerrada_por: 'cajera-441@example.test', cerrada_en: '2026-11-18T18:02:41-06:00', monto_inicial: 50000, notas_cierre: 'Billete roto' };
const corte = { filas: [
  { medio: '01', nombre: 'Efectivo en la gaveta', sistema: 81250, declarado: 78750, diferencia: -2500 },
  { medio: '02', nombre: 'Tarjeta (cierre del datáfono)', sistema: 121400, declarado: 121400, diferencia: 0 },
  { medio: '04', nombre: 'Transferencias', sistema: 32000, declarado: null, diferencia: null },
  { medio: 'USD', nombre: 'Dólares en la gaveta', usd: true, sistema: 40, declarado: 40, diferencia: 0 }], faltante: -2500, sobrante: 0 };
const resumen = { ventas: 12, total: 252150, porMedio: { '01': 71250, '02': 121400, '04': 32000 }, salidas: 40000, nombreMedio: m => ({ '01': 'Efectivo', '02': 'Tarjeta', '04': 'Transferencia' }[m] || m) };
const empresa = { nombre_comercial: 'Tienda de Ejemplo' };
const texto = d => d.bloques.map(b => [b.x, b.i, b.d].filter(v => v !== undefined).join(' | '));
const solo = A.docColilla({ empresa, caja, corte, resumen, cajero: caja.cerrada_por, M, completa: false });
const completa = A.docColilla({ empresa, caja, corte, resumen, cajero: caja.cerrada_por, M });
const termica = A.paraTermica({ bloques: [{ t: 'texto', x: 'Total — ₡1.000' }, { t: 'par', i: 'A – b', d: '−₡5' }, { t: 'item', cant: '1', x: '“Café”…', d: '₡2', notas: ['sin azúcar — tibio'] },
  { t: 'qr', x: '₡ clave — 506' }, { t: 'linea' }, { x: 'sin tipo ₡' }], otra: 1 });
const entrada = { bloques: [{ t: 'texto', x: '₡1' }] }; A.paraTermica(entrada);
console.log(JSON.stringify({ solo: texto(solo), completa: texto(completa), termica, sin_cambio: entrada.bloques[0].x,
  nada: [A.paraTermica(null), A.paraTermica({ a: 1 })], txt: [A.textoTermica(5), A.textoTermica('a\\u00a0b\\u202fc')],
  control: new Date(caja.cerrada_en).toLocaleString('es-CR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) }));
"""


def test_colilla_solo_lo_declarado_y_la_completa(tmp_path):
    r = _node(tmp_path, COLILLA, archivos=("pages/pos/_agente.js",), falsos={"api.js": FALSO_API})
    solo, completa = "\n".join(r["solo"]), "\n".join(r["completa"])
    # ciego completo: lo que declaró (los medios que anotó), notas y firmas; nada del sistema
    assert "LO DECLARADO POR EL CAJERO" in solo and "Efectivo en la gaveta | ₡78750.00" in solo and "Tarjeta (cierre del datáfono) | ₡121400.00" in solo, solo
    assert "Dólares en la gaveta | $40.00" in solo and "Transferencias" not in solo, solo          # lo no declarado no se nombra
    for prohibido in ("B sistema", "81250", "32000", "FALTANTE", "EXCEDENTE", "Cuadra", "RESUMEN", "Ventas (", "252150", "Fondo inicial", "A = declarado"):
        assert prohibido not in solo, (prohibido, solo)
    assert "Notas: Billete roto" in solo and "El corte lo revisa la administración" in solo and "Entrega (cajero)" in solo and "Recibe (administración)" in solo, solo
    # la completa, como antes: A contra B, faltante, resumen y firmas
    for esta in ("A = declarado por el cajero · B = según el sistema", "  B sistema | ₡81250.00", "  FALTANTE | ₡-2500.00", "FALTANTE TOTAL | ₡2500.00",
                 "RESUMEN DEL TURNO", "Ventas (12) | ₡252150.00", "Notas: Billete roto", "Recibe (administración)"):
        assert esta in completa, (esta, completa)
    # la hora es la de Costa Rica, sin importar la de la computadora
    assert any("18/11/2026" in x and "06:02" in x for x in r["solo"][:4]), r["solo"][:4]
    assert "06:02" not in r["control"] and "19/11/2026" in r["control"], r["control"]       # control: sin la zona fija saldría la hora de Tokio


def test_texto_para_la_termica(tmp_path):
    r = _node(tmp_path, COLILLA, archivos=("pages/pos/_agente.js",), falsos={"api.js": FALSO_API})
    b = r["termica"]["bloques"]
    assert b[0]["x"] == "Total - ¢1.000" and b[1] == {"t": "par", "i": "A - b", "d": "-¢5"}, b
    assert b[2]["x"] == '"Café"...' and b[2]["d"] == "¢2" and b[2]["notas"] == ["sin azúcar - tibio"] and b[2]["cant"] == "1", b
    assert b[3] == {"t": "qr", "x": "₡ clave — 506"} and b[4] == {"t": "linea"} and b[5]["x"] == "sin tipo ¢", b   # el QR no se toca
    assert r["termica"]["otra"] == 1 and r["sin_cambio"] == "₡1", r                                                      # no cambia el original
    assert r["nada"] == [None, {"a": 1}] and r["txt"] == [5, "a b c"], r


def test_escpos_sin_signos_de_pregunta():
    doc = {"ancho": 80, "bloques": [{"t": "texto", "x": "CIERRE — Caja 1"}, {"t": "par", "i": "Efectivo", "d": "₡78.750,00"},
                                    {"t": "par", "i": "Retiros", "d": "−₡40.000,00"}, {"t": "item", "cant": "2", "x": "Café “grande”…", "d": "₡3.000", "notas": ["sin azúcar — tibio"]},
                                    {"t": "texto", "x": "6:02 p. m."}]}
    datos = escpos.escpos(doc)
    assert b"?" not in datos, datos
    assert b"\xbd78.750,00" in datos and b"-\xbd40.000,00" in datos and b"CIERRE - Caja 1" in datos and b'"grande"...' in datos, datos
    assert b"sin az\xa3car - tibio" in datos and b"6:02 p. m." in datos, datos
    # el ancho cuadra: ninguna línea de texto pasa de 48 columnas (los «…» se cambian antes de partir las líneas)
    largo = {"ancho": 80, "bloques": [{"t": "texto", "x": ("palabra… " * 20).strip()}]}
    lineas = [re.sub(rb"\x1b@|\x1b[taEp].|\x1d!.|\x1dV..", b"", ln) for ln in escpos.escpos(largo).split(b"\n")]
    assert sum(ln.count(b"palabra...") for ln in lineas) == 20 and all(len(ln) <= 48 for ln in lineas), lineas
    # el documento que llega no se modifica
    assert doc["bloques"][1]["d"] == "₡78.750,00"


# ------------------------------------------------------------------------------------------------ 3) las pantallas usan las opciones
def test_pantallas_usan_las_opciones():
    z = _js("pages/pos/cierres.js")
    assert "opcionesCierre, colillaDeLaCaja, terminalDeCaja } from './_datos.js'" in z and "completa = deLaCaja ? propia : opcionesCierre(c).colilla" in z and "M: money, completa }" in z
    assert "if (cerrada && o.auto) this.imprimirColilla(cerrada, { deLaCaja: true });" in z and "if (cerrada && !o.corte) toast('Caja cerrada. El corte lo revisa la administración.', 'ok');" in z
    assert '<template v-if="!opc(resultado).corte">' in z and "Lo declarado al cerrar" in z and "declaradoDe(resultado)" in z
    assert "{{opc(ver).corte ? 'Ver el corte' : 'Ver lo declarado'}}" in z and "quedó en la colilla" not in z
    # la colilla del navegador (sin impresora térmica) tampoco lleva lo del sistema con ciego completo
    i = z.index("if (!completa) {")
    j = z.index("} else {", i)
    assert "Lo declarado por el cajero" in z[i:j] and "B sistema" not in z[i:j] and "FALTANTE" not in z[i:j] and "Resumen" not in z[i:j], z[i:j]
    k = _js("pages/pos/caja.js")
    assert "if (!this.verMontosCaja && !opcionesCierre(this.caja).corte) return toast('Turno entregado con '" in k
    assert "{{caja && opcionesCierre(caja).corte ? 'Al entregar el turno verá la diferencia.' : 'La diferencia la revisa la administración.'}}" in k
    assert "money, fmt, fmtCant, nombreMedio, fecha, opcionesCierre," in k                      # la plantilla del turno la usa
    c = _js("pages/pos/configuracion.js")
    i = c.index('<Toggle v-model="t.cierre_ciego"')
    tramo = c[i:c.index("</div>", c.index('<div v-if="t.cierre_ciego"', i)) + 6]
    assert 'v-model="t.cierre_corte_cajero"' in tramo and '<Toggle v-if="t.cierre_corte_cajero" v-model="t.colilla_completa"' in tramo, tramo
    assert '<Toggle v-model="t.colilla_auto"' in c
    assert "Contador" not in tramo and "Ven siempre el corte completo" in tramo and "El Vendedor cierra como el cajero" in tramo, tramo   # el Contador no tiene el punto de venta
    assert "«Ver gastos, bancos, contabilidad y reportes» o «Configuración de la empresa»" in tramo and "al entregar el turno, la diferencia" in tramo, tramo   # los permisos, no solo roles
    # una caja nueva no toma el id de una borrada (sus cierres viejos tomarían las opciones de la nueva)
    assert "...(mock.get('pos_cajas', []) || []).map(c => +(c && c.terminal_id) || 0)) + 1;" in c


# ------------------------------------------------------------------------------------------------ 4) otras pantallas que mostraban el corte
def test_inicio_y_cierre_del_hotel_sin_el_corte_de_una_caja_ciega():
    i = _js("pages/inicio.js")
    assert "opcionesCierre } from './pos/_datos.js'" in i
    assert "diferencia: opcionesCierre(c).corte ? (+c.diferencia || 0) : null" in i and "efectivo: r.efectivo_esperado" not in i
    assert '<b class="small muted" v-if="c.diferencia === null">cerrada</b>' in i                  # ni monto ni «cuadró»
    h = _js("pages/hotel/cierre.js")
    assert "corteDeLaCaja } from '../pos/_datos.js'" in h and "opcionesCierre" not in h        # el paquete lo bajan otros: no depende de quién lo genera
    fila = h[h.index("const filas = cs.map(c => { const r = resumenCaja(c), k = corteDeLaCaja(c);"):]
    fila = fila[:fila.index("\n")]
    for campo in ("medios: k ?", "esperado: k ?", "contado: !k ? '—'", "diferencia: !k ? '—'"):
        assert campo in fila, (campo, fila)
    assert "Las cajas con cierre a ciegas en las que el cajero no ve el corte salen sin su corte" in h


def test_cierre_del_hotel_en_node(tmp_path):
    """La regla que usa el paquete del cierre del día del hotel: una caja ciega no lleva su corte aunque lo genere la administración."""
    r = _node(tmp_path, """
const D = await import('./js/pages/pos/_datos.js');
const { mock } = await import('./js/api.js');
mock.set('pos_config', { terminales: [{ id: 1, nombre: 'Ciega' }, { id: 2, nombre: 'Abierta', cierre_ciego: false }] });
globalThis.__puede = { ver_todo: true, pos: true };          // lo genera la administración: igual no lleva el corte de la ciega
const ses = [{ id: 1, terminal_id: 1, caja: 'Ciega', estado: 'Cerrada', fecha: '2026-11-19', monto_inicial: 0, conteo: 900, diferencia: -100 },
             { id: 2, terminal_id: 2, caja: 'Abierta', estado: 'Cerrada', fecha: '2026-11-19', monto_inicial: 0, conteo: 500, diferencia: 0 }];
const out = ses.map(c => ({ caja: c.caja, deLaCaja: D.corteDeLaCaja(c), admin: D.opcionesCierre(c).corte }));
console.log(JSON.stringify(out));
""", archivos=("pages/pos/_datos.js",), falsos={"api.js": FALSO_API, "app.js": FALSO_APP})
    assert r == [{"caja": "Ciega", "deLaCaja": False, "admin": True}, {"caja": "Abierta", "deLaCaja": True, "admin": True}], r


def test_escpos_qr_tal_cual():
    datos = escpos.escpos({"ancho": 80, "bloques": [{"t": "qr", "x": "clave—506"}]})
    assert "clave—506".encode("cp858", errors="replace") in datos and b"clave-506" not in datos


# ------------------------------------------------------------------------------------------------ 5) dónde sale la colilla
FALSO_API_COLILLA = FALSO_API.replace("export function fecha(x)", "export const fechaHora = x => String(x || ''), toast = () => {}, red = { enLinea: true };\nexport function fecha(x)")
FALSO_AGENTE = """
export const porAgente = imp => !!imp && (imp.conexion === 'usb' || imp.conexion === 'red');
export const docColilla = a => ({ completa: a.completa });
export const cargarEquipo = async () => {}, avisoImpresion = (p, e) => p + e;
// como en la web (sin lo de esta computadora): la de la caja tal cual; sin ella, ninguna (se abre el navegador)
export function impresoraTiqueteAqui(deCaja) { return deCaja || null; }
export async function imprimirAgente(imp, doc) { globalThis.Q.salidas.push(['agente', imp.nombre, doc.completa]); }
"""


def test_la_colilla_completa_no_sale_en_la_impresora_de_la_caja(tmp_path):
    """4.41: quien ve resultados imprime la colilla completa; si la caja no se la da a su cajero, no va a la impresora de la caja (saldría
    delante del cajero): en la web se abre en el navegador. La que sale sola al cerrar es la de la caja, cierre quien cierre."""
    r = _node(tmp_path, MONTAR + """
globalThis.Q = { salidas: [] };
globalThis.window = { open: () => ({ document: { write: h => Q.salidas.push(['navegador', null, h.includes('B sistema')]), close() {} }, print() {} }) };
const { mock } = await import('./js/api.js');
const IMP = { id: 7, nombre: 'Termica caja', uso: 'comprobante', conexion: 'red', direccion: '127.0.0.1:9100', activa: true };
mock.set('pos_impresoras', [IMP]);
mock.set('pos_config', { terminales: [{ id: 1, nombre: 'Ciega', impresora_comprobante_id: 7 }, { id: 2, nombre: 'Abierta', cierre_ciego: false, impresora_comprobante_id: 7 },
  { id: 3, nombre: 'Todo', cierre_corte_cajero: true, colilla_completa: true, impresora_comprobante_id: 7 }, { id: 4, nombre: 'Corte', cierre_corte_cajero: true, impresora_comprobante_id: 7 }] });
const S = (id, caja) => ({ id: 10 + id, terminal_id: id, caja, estado: 'Cerrada', cerrada_en: '2026-11-19T18:00:00-06:00', monto_inicial: 0, conteo: 900, declarado: { '01': 900 }, ventas: [] });
const C = (await import('./js/pages/pos/cierres.js')).default;
const vm = montar(C);
const out = {};
const prueba = async (puede, c, op) => { globalThis.__puede = puede; Q.salidas = []; await vm.imprimirColilla(c, op); return Q.salidas; };
out.cajero = await prueba({}, S(1, 'Ciega'));
out.admin = await prueba({ ver_todo: true }, S(1, 'Ciega'));
out.admin_al_cerrar = await prueba({ ver_todo: true }, S(1, 'Ciega'), { deLaCaja: true });
out.configura = await prueba({ configurar: true }, S(1, 'Ciega'));
out.admin_abierta = await prueba({ ver_todo: true }, S(2, 'Abierta'));
out.admin_todo = await prueba({ ver_todo: true }, S(3, 'Todo'));
out.cajero_todo = await prueba({}, S(3, 'Todo'));
out.cajero_abierta_al_cerrar = await prueba({}, S(2, 'Abierta'), { deLaCaja: true });
out.admin_corte = await prueba({ ver_todo: true }, S(4, 'Corte'));
out.cajero_corte = await prueba({}, S(4, 'Corte'));
console.log(JSON.stringify(out));
""", archivos=("pages/pos/_datos.js", "pages/pos/cierres.js"),
        falsos={"api.js": FALSO_API_COLILLA, "app.js": FALSO_APP.replace("puede:", "empresaInfo: { es_local: false }, puede:") + "export const store = { empresa: { nombre: 'Tienda de Ejemplo' } };\n",
                "pages/pos/_agente.js": FALSO_AGENTE,
                "pages/reportes/_montos.js": "export const descargarReporte = () => {}, imprimirReporte = () => {}, impresorasReporte = () => [], cargarImpresorasReporte = async () => false;\n",
                "pages/bancos/cuentas.js": "export const cuentasActivas = () => [];\n"})
    caja_solo, caja_completa, navegador = [["agente", "Termica caja", False]], [["agente", "Termica caja", True]], [["navegador", None, True]]
    assert r["cajero"] == caja_solo, r                                  # el cajero: solo lo declarado, en la impresora de su caja
    assert r["admin"] == navegador and r["configura"] == navegador, r     # la completa de una caja ciega: no en la de la caja
    assert r["admin_al_cerrar"] == caja_solo, r                         # la que sale sola al cerrar: la de la caja, cierre quien cierre
    assert r["admin_abierta"] == caja_completa and r["admin_todo"] == caja_completa and r["cajero_todo"] == caja_completa, r
    assert r["cajero_abierta_al_cerrar"] == caja_completa, r
    assert r["admin_corte"] == navegador and r["cajero_corte"] == caja_solo, r   # «ve el corte» sin «colilla completa»: la de la caja, solo lo declarado


def test_lo_que_llega_al_agente_ya_va_para_la_termica(tmp_path):
    """imprimirAgente pasa el documento por paraTermica: al agente (aunque sea uno viejo, sin el arreglo de escpos) le llega «¢» y «-»."""
    r = _node(tmp_path, """
globalThis.__pedidos = [];
globalThis.fetch = async (url, op) => { __pedidos.push([String(url), op && op.body ? JSON.parse(op.body) : null]);
  return { ok: true, json: async () => (String(url).endsWith('/estado') ? { agente: 'prueba' } : { ok: true }) }; };
const A = await import('./js/pages/pos/_agente.js');
const imp = { nombre: 'Termica QA', conexion: 'red', direccion: '127.0.0.1:9', ancho: 58 };
const doc = { bloques: [{ t: 'texto', x: 'CIERRE — Caja 1' }, { t: 'par', i: 'Efectivo', d: '₡78.750,00' }, { t: 'qr', x: '₡ clave — 506' }] };
await A.imprimirAgente(imp, doc);
const p = __pedidos.find(x => x[0].endsWith('/imprimir'));
console.log(JSON.stringify({ url: p && p[0], cuerpo: p && p[1], original: doc.bloques[1].d }));
""", archivos=("pages/pos/_agente.js",), falsos={"api.js": FALSO_API})
    assert r["url"] == "http://127.0.0.1:9800/imprimir", r
    d = r["cuerpo"]["documento"]
    assert d["ancho"] == 58 and d["bloques"][0]["x"] == "CIERRE - Caja 1" and d["bloques"][1]["d"] == "¢78.750,00", d
    assert d["bloques"][2] == {"t": "qr", "x": "₡ clave — 506"}, d          # el QR va tal cual
    assert r["original"] == "₡78.750,00" and r["cuerpo"]["impresora"]["nombre"] == "Termica QA", r
