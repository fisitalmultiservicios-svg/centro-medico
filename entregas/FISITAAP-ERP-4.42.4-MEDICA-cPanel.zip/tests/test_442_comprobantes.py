# -*- coding: utf-8 -*-
"""4.42 (arreglo de seguridad): los comprobantes de pago por correo los arma el servidor con lo GUARDADO. Hasta la 4.41,
POST /api/rrhh/comprobantes-pago recibía del navegador el correo y los montos de cada fila: quien tenía Recursos humanos podía
mandar, desde el correo de la empresa, un «comprobante» con cualquier monto a cualquier dirección. Ahora la ruta es
POST /api/rrhh/comprobantes-pago/{concepto}/{doc_id} con {"empleados": [ids] | null}: el correo sale SOLO de la ficha guardada y los
montos SOLO del documento guardado y pagado (404 si no existe o el empleado no está en él, 409 si no está pagado); la ruta de antes
responde 409 «recargue la página» y no envía nada. El correo se simula como en las pruebas viejas (nada sale a la red). Las
pantallas se corren en Node con sustitutos de lo que usan: guardan lo pendiente ANTES de pedir el envío y solo dicen cuál documento."""
import json
import pathlib
import shutil
import subprocess
import types

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth, main
from app.db import engine
from app.main import app
from tests.test_47_seguridad import H, _borrar, _nueva_empresa, _sembrar, _usuarios
from tests.test_exoneraciones import api  # noqa: F401  (fixture: empresa propia con contexto Administrador)

RAIZ = pathlib.Path(__file__).resolve().parents[1]
ANA = {"id": 1, "nombre": "Ana", "apellidos": "Mora QA", "tipo_id": "01", "numero_id": "1-0999-0442", "puesto": "Recepcionista", "correo": "ana.qa@example.test",
       "fecha_ingreso": "2021-03-15", "modo_salario": "hora", "salario_hora": 2500}
BETO = {"id": 2, "nombre": "Beto", "apellidos": "Solís QA", "tipo_id": "01", "numero_id": "209990442", "puesto": "Cocinero", "fecha_ingreso": "2022-01-10"}   # sin correo
CARO = {"id": 3, "nombre": "Caro", "apellidos": "Vega QA", "tipo_id": "01", "numero_id": "309990442", "puesto": "Cajera", "correo": "caro.qa@example.test",
        "fecha_ingreso": "2023-05-02"}
F_ANA = {"empleado_id": 1, "nombre": "Ana Mora QA", "horas": 104, "ordinario": 260000, "otros_ingresos": 40000, "bruto": 300000, "obrero": {"sem": 16500, "ivm": 12990},
         "total_obrero": 29490, "renta": 2500, "otras_deducciones": 13200, "total_deducciones": 45190, "neto": 254810}
F_BETO = {"empleado_id": 2, "nombre": "Beto Solís QA", "horas": 96, "ordinario": 200000, "bruto": 200000, "obrero": {"sem": 11000, "ivm": 8660}, "total_obrero": 19660,
          "renta": 1000, "otras_deducciones": 5000, "total_deducciones": 25660, "neto": 174340}
F_CARO = {"empleado_id": 3, "nombre": "Caro Vega QA", "horas": 48, "ordinario": 120000, "bruto": 120000, "obrero": {"sem": 6600, "ivm": 5196}, "total_obrero": 11796,
          "total_deducciones": 11796, "neto": 108204}
M = main._fm_colones                           # el monto como sale en el comprobante y en el correo (colones, 1.234,56)
ACCIONES_ENVIO = ("planilla_correo", "aguinaldo_correo", "liquidacion_correo")
NO_PAGADA = "La planilla todavía no está pagada: los comprobantes se envían cuando esté pagada"


def _js(*partes):
    return (RAIZ / "app" / "static" / "js" / pathlib.Path(*partes)).read_text(encoding="utf-8")


def _cambios(c, clave, upserts=(), deletes=(), nuevos=()):
    return c.post(f"/api/registros/{clave}/cambios", json={"upserts": list(upserts), "deletes": list(deletes), "nuevos": list(nuevos)})


def _planilla(pid, filas, estado="Pagada", **extra):
    p = {"id": pid, "numero": f"PL-{pid:04d}", "periodo": "quincenal", "desde": "2026-11-01", "hasta": "2026-11-15", "fecha": "2026-11-15", "empleados": len(filas),
         "filas": filas, "totales": {"bruto": sum(f.get("bruto", 0) for f in filas), "neto": sum(f.get("neto", 0) for f in filas)},
         "estado": estado, "cuenta": "Banco QA" if estado == "Pagada" else "", "pagada_en": "2026-11-16" if estado == "Pagada" else None}
    p.update(extra)
    return p


def _capturar(monkeypatch, pdf_real=False, smtp=True):
    """Sustituye el envío (nada sale a la red) y guarda lo que el servidor iba a mandar: cap.correos (a quién, asunto, cuerpo, adjuntos)
    y cap.reps (el reporte de cada comprobante). `falla`: direcciones que el servidor de correo «rechaza»."""
    cap = types.SimpleNamespace(reps=[], correos=[], cfgs=[], falla=set())
    if not pdf_real:
        monkeypatch.setattr(main.reportes, "_pdf", lambda rep, e, logo: cap.reps.append(rep) or b"%PDF-1.4 QA")
    if smtp:
        monkeypatch.setattr(main, "_cfg_smtp_rrhh", lambda e: cap.cfgs.append(e.id) or "SMTP-QA")

    def enviar(cfg, para, asunto, html, texto, adjuntos, cc=None):
        if cap.falla & set(para):
            raise main.correo.ErrorCorreo("El servidor rechazó los destinatarios: QA")
        cap.correos.append({"cfg": cfg, "para": list(para), "asunto": asunto, "html": str(html), "texto": texto, "adjuntos": list(adjuntos), "cc": cc})
    monkeypatch.setattr(main.correo, "enviar", enviar)
    return cap


def _auditoria(eid, *acciones):
    with Session(engine) as s:
        return [a.detalle for a in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == eid, auth.Auditoria.accion.in_(acciones or ACCIONES_ENVIO))
                                          .order_by(auth.Auditoria.id)).all()]


def _ctx():
    return app.dependency_overrides[auth.contexto]()


def _eid():
    return _ctx().empresa.id


def _todo(m):
    """Todo el texto de un correo capturado (para buscar lo que NO debe ir)."""
    return " ".join([" ".join(m["para"]), m["asunto"], m["html"], m["texto"], " ".join(a[0] for a in m["adjuntos"])])


# ----------------------------------------------------------------------------- planilla: lo guardado manda
def test_planilla_pagada_envia_a_la_ficha_el_mismo_comprobante_de_la_descarga(api, monkeypatch):  # noqa: F811
    c, cap = api, _capturar(monkeypatch)
    assert _cambios(c, "empleados", [ANA, BETO, CARO], nuevos=[1, 2, 3]).status_code == 200
    assert _cambios(c, "planillas", [_planilla(5, [F_ANA, F_BETO, F_CARO])], nuevos=[5]).status_code == 200
    # la descarga de cada comprobante (4.21, no cambió): contra ella se compara lo que sale por correo
    descargas = {i: c.get(f"/api/rrhh/comprobante-pago/planilla/5/{i}") for i in (1, 3)}
    assert all(r.status_code == 200 for r in descargas.values())
    de_ana, de_caro = cap.reps[0], cap.reps[1]
    cap.reps.clear()
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json={})
    assert r.status_code == 200, r.text
    assert r.json() == {"enviados": 2, "sin_correo": ["Beto Solís QA"], "fallidos": []}             # la misma forma de respuesta de antes
    assert [m["para"] for m in cap.correos] == [["ana.qa@example.test"], ["caro.qa@example.test"]]   # el correo de cada FICHA, uno por empleado
    assert all(m["cfg"] == "SMTP-QA" and m["cc"] is None for m in cap.correos)                        # desde el correo de Recursos humanos
    assert [x.model_dump() for x in cap.reps] == [de_ana.model_dump(), de_caro.model_dump()]         # el mismo comprobante de la descarga
    a = cap.correos[0]
    assert a["asunto"] == "Comprobante de pago · Planilla PL-0005 · Empresa Exoneraciones QA"
    assert f"Total pagado: CRC {M(254810)}" in a["texto"] and M(254810) in a["html"] and "del 01/11/2026 al 15/11/2026" in a["texto"]
    assert M(254810).endswith("254.810,00") and "Estimado(a) Ana Mora QA:" in a["html"]
    # el adjunto se llama igual que la descarga y es el PDF de ese reporte
    assert [(x[0], x[1], x[2], x[3]) for x in a["adjuntos"]] == [("comprobante_pago_PL0005_109990442.pdf", b"%PDF-1.4 QA", "application", "pdf")]
    assert descargas[1].headers["content-disposition"] == 'attachment; filename="comprobante_pago_PL0005_109990442.pdf"'
    assert cap.correos[1]["adjuntos"][0][0] == "comprobante_pago_PL0005_309990442.pdf" and f"CRC {M(108204)}" in cap.correos[1]["texto"]
    assert M(174340) not in _todo(a) + _todo(cap.correos[1])                                       # lo de Beto no va en el correo de nadie
    # el historial: una fila por envío, sin nombres, montos, cédulas ni direcciones
    aud = _auditoria(_eid())
    assert aud == ["Planilla PL-0005: 2 comprobantes enviados, 1 sin correo, 0 fallidos"]
    assert not any(x in aud[0] for x in ("254", "108", "0999", "@", "Ana", "Beto", "Caro"))
    # solo a algunos: en el orden pedido y sin repetir; el que no tiene correo en su ficha sale en «sin correo»
    cap.correos.clear()
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json={"empleados": [3, 2, 3]})
    assert r.json() == {"enviados": 1, "sin_correo": ["Beto Solís QA"], "fallidos": []} and [m["para"] for m in cap.correos] == [["caro.qa@example.test"]]
    # sin cuerpo (o con null) es «a todos»
    cap.correos.clear()
    assert c.post("/api/rrhh/comprobantes-pago/planilla/5").json()["enviados"] == 2
    assert c.post("/api/rrhh/comprobantes-pago/planilla/5", json={"empleados": None}).json()["enviados"] == 2 and len(cap.correos) == 4


def test_el_navegador_no_decide_el_correo_ni_los_montos(api, monkeypatch):  # noqa: F811
    """El ataque que se cierra: el cuerpo de antes (correo y montos por fila) ya no cuenta, ni por la ruta nueva ni por la de antes."""
    c, cap = api, _capturar(monkeypatch)
    assert _cambios(c, "empleados", [ANA, BETO], nuevos=[1, 2]).status_code == 200
    assert _cambios(c, "planillas", [_planilla(5, [F_ANA, F_BETO])], nuevos=[5]).status_code == 200
    assert c.get("/api/rrhh/comprobante-pago/planilla/5/1").status_code == 200
    guardado = cap.reps.pop()
    falsa = {"empleado_id": 1, "nombre": "Ana Mora QA", "correo": "otro.qa@example.test", "numero_id": "1-0999-0442", "neto": 9999999, "bruto": 9999999, "ordinario": 9999999,
             "detalle": [{"c": "Bono inventado", "m": 9999999}]}
    viejo = {"concepto": "planilla", "numero": "PL-9999", "periodo": "Periodo-Falso-QA", "desde": "2026-01-01", "hasta": "2026-01-31", "pagada_en": "2026-02-01", "cuenta": "Cuenta-Falsa-QA",
             "filas": [falsa, {**falsa, "nombre": "Beto Solís QA", "correo": "beto.inventado@example.test"}]}
    intento = {**viejo, "empleados": [1, 2], "correo": "otro.qa@example.test", "para": ["otro.qa@example.test"], "correos": {"1": "otro.qa@example.test"}}
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json=intento, params={"correo": "otro.qa@example.test", "neto": "9999999"})
    assert r.status_code == 200 and r.json() == {"enviados": 1, "sin_correo": ["Beto Solís QA"], "fallidos": []}, r.text
    assert len(cap.correos) == 1 and cap.correos[0]["para"] == ["ana.qa@example.test"]             # el de la ficha; Beto sigue sin correo
    todo = _todo(cap.correos[0]) + json.dumps(cap.reps[0].model_dump(), ensure_ascii=False)
    for no in ("otro.qa@example.test", "inventado", "9999999", "9.999.999", "PL-9999", "Periodo-Falso-QA", "Cuenta-Falsa-QA", "31/01/2026"):
        assert no not in todo, no
    assert cap.reps[0].model_dump() == guardado.model_dump() and f"CRC {M(254810)}" in cap.correos[0]["texto"]
    # el correo cambia en la ficha guardada → cambia el destinatario (no hay otra forma de decidirlo)
    assert _cambios(c, "empleados", [{**ANA, "correo": "ana.nueva@example.test; segunda.qa@example.test"}]).status_code == 200
    cap.correos.clear()
    assert c.post("/api/rrhh/comprobantes-pago/planilla/5", json={"empleados": [1]}).json()["enviados"] == 1
    assert [m["para"] for m in cap.correos] == [["ana.nueva@example.test"]]                         # solo la primera dirección del campo, como antes
    # la ruta de antes, con el cuerpo de antes: no envía nada (ni a la ficha ni a la dirección inventada) y pide recargar
    cap.correos.clear(); cap.reps.clear()
    antes = _auditoria(_eid())
    for cuerpo in (viejo, intento, {}, None, [1, 2], "texto"):
        r = c.post("/api/rrhh/comprobantes-pago", json=cuerpo)
        assert r.status_code == 409 and "recargue la página" in r.json()["detail"] and "no se envió ningún correo" in r.json()["detail"], (cuerpo, r.text)
    assert c.post("/api/rrhh/comprobantes-pago").status_code == 409
    assert cap.correos == [] and cap.reps == [] and cap.cfgs.count(_eid()) == 2 and _auditoria(_eid()) == antes
    assert not hasattr(main, "ComprobantesPagoIn")                                                  # ya no existe el modelo que recibía montos y correos


def test_solo_de_lo_pagado_de_lo_que_existe_y_de_quien_esta_en_el_documento(api, monkeypatch):  # noqa: F811
    c, cap = api, _capturar(monkeypatch)
    assert _cambios(c, "empleados", [ANA, BETO, CARO], nuevos=[1, 2, 3]).status_code == 200
    # directo a la base: el guardado normal no deja repetir empleados y fechas de una planilla ya pagada (regla de la 4.7, no es de esta prueba)
    _sembrar(_eid(), {"planillas": [_planilla(1, [F_ANA], estado="Generada"), _planilla(2, [F_ANA], estado="Aprobada"), _planilla(5, [F_ANA, F_BETO])]})
    ruta = "/api/rrhh/comprobantes-pago/planilla/"
    for pid in (1, 2):                                                             # generada o aprobada: todavía no está pagada
        r = c.post(ruta + str(pid), json={})
        assert r.status_code == 409 and r.json()["detail"] == NO_PAGADA, r.text
        assert c.post(ruta + str(pid), json={"empleados": [1]}).status_code == 409
    for inexistente in ("77", "0", "-5", "99999999999999999999999999"):
        r = c.post(ruta + inexistente, json={})
        assert r.status_code == 404 and r.json()["detail"] == "La planilla ya no existe: recargue la página", (inexistente, r.text)
    # un empleado que no está en la planilla (Caro existe, pero no está en la 5): 404 y no se le envía a NADIE, tampoco a los que sí están
    for pedidos in ([3], [1, 3], [1, 999], [999, 1], [-1]):
        r = c.post(ruta + "5", json={"empleados": pedidos})
        assert r.status_code == 404 and r.json()["detail"] == "Ese empleado no está en la planilla", (pedidos, r.text)
    r = c.post(ruta + "5", json={"empleados": []})
    assert r.status_code == 400 and r.json()["detail"] == "Indique al menos un empleado"
    for mala, cuerpo in (("/api/rrhh/comprobantes-pago/vacaciones/5", {}), (ruta + "x", {}), (ruta + "5", {"empleados": ["x"]}), (ruta + "5", {"empleados": [1.5]}),
                         (ruta + "5", {"empleados": "1"}), (ruta + "5", {"empleados": list(range(1, 502))}), (ruta + "5", [1, 2])):
        assert c.post(mala, json=cuerpo).status_code == 422, (mala, str(cuerpo)[:40])
    assert c.get(ruta + "5").status_code in (404, 405)                             # enviar es siempre un POST
    # nada de eso armó un PDF, tocó el correo ni quedó como envío en el historial
    assert cap.reps == [] and cap.correos == [] and cap.cfgs == [] and _auditoria(_eid()) == []
    # y la pagada sí sale
    assert c.post(ruta + "5", json={"empleados": [1]}).json() == {"enviados": 1, "sin_correo": [], "fallidos": []}


def test_sin_correo_configurado_avisa_despues_de_revisar_el_documento(api, monkeypatch):  # noqa: F811
    c, cap = api, _capturar(monkeypatch, smtp=False)                               # _cfg_smtp_rrhh de verdad: la empresa de la prueba no tiene correo
    assert _cambios(c, "empleados", [ANA], nuevos=[1]).status_code == 200
    _sembrar(_eid(), {"planillas": [_planilla(1, [F_ANA], estado="Generada"), _planilla(5, [F_ANA])]})
    assert c.post("/api/rrhh/comprobantes-pago/planilla/1", json={}).status_code == 409        # primero el documento
    assert c.post("/api/rrhh/comprobantes-pago/planilla/77", json={}).status_code == 404
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json={})
    assert r.status_code == 400 and r.json()["detail"].startswith("Configure el correo de Recursos humanos"), r.text
    assert cap.correos == [] and cap.reps == [] and _auditoria(_eid()) == []


def test_un_correo_que_falla_no_detiene_a_los_demas(api, monkeypatch):  # noqa: F811
    c, cap = api, _capturar(monkeypatch)
    assert _cambios(c, "empleados", [ANA, BETO, CARO], nuevos=[1, 2, 3]).status_code == 200
    suelta = {"nombre": "Fila Suelta QA", "ordinario": 5000, "bruto": 5000, "neto": 5000}            # una fila vieja sin empleado: no hay ficha de dónde sacar el correo
    _sembrar(_eid(), {"planillas": [_planilla(5, [F_CARO, suelta, F_ANA, F_BETO])]})
    cap.falla = {"caro.qa@example.test"}
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json={})
    assert r.status_code == 200, r.text
    assert r.json() == {"enviados": 1, "sin_correo": ["Fila Suelta QA", "Beto Solís QA"],
                        "fallidos": [{"nombre": "Caro Vega QA", "error": "El servidor rechazó los destinatarios: QA"}]}
    assert [m["para"] for m in cap.correos] == [["ana.qa@example.test"]]                           # Ana va después de Caro y le llega igual
    aud = _auditoria(_eid())
    assert aud == ["Planilla PL-0005: 1 comprobantes enviados, 2 sin correo, 1 fallidos"] and "254" not in aud[0] and "@" not in aud[0]
    # un comprobante que no se puede armar tampoco tumba el envío de los demás
    cap.falla, cap.correos[:] = set(), []

    def pdf_roto(rep, e, logo):
        if "Ana Mora QA" in rep.titulo:
            raise RuntimeError("PDF roto QA")
        return b"%PDF-1.4 QA"
    monkeypatch.setattr(main.reportes, "_pdf", pdf_roto)
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json={"empleados": [1, 3]})
    assert r.json() == {"enviados": 1, "sin_correo": [], "fallidos": [{"nombre": "Ana Mora QA", "error": "RuntimeError: PDF roto QA"}]}
    assert [m["para"] for m in cap.correos] == [["caro.qa@example.test"]]


def test_una_fila_que_no_se_puede_armar_no_detiene_a_los_demas(api, monkeypatch):  # noqa: F811
    """Vuelta 1 de la revisión: la cabecera y la fila de cada comprobante se arman DENTRO del `try` del envío. Una fila guardada con un
    dato que no se puede convertir va a «fallidos» con su nombre; a los demás les llega su correo y el envío queda en el historial.
    Con el armado fuera del `try`, la petición se cortaría a media planilla (error 400 o 500) después de haber mandado correos y
    sin dejar fila en el historial."""
    c, cap = api, _capturar(monkeypatch)
    assert _cambios(c, "empleados", [ANA, {**BETO, "correo": "beto.qa@example.test"}, CARO], nuevos=[1, 2, 3]).status_code == 200
    # un dato guardado de verdad: un entero tan grande que no cabe en un número con decimales (directo a la base; el guardado normal no lo deja pasar)
    _sembrar(_eid(), {"planillas": [_planilla(5, [F_CARO, F_ANA, F_BETO]), _planilla(6, [F_CARO, {**F_ANA, "renta": 10 ** 400}, F_BETO])]})
    r = c.post("/api/rrhh/comprobantes-pago/planilla/6", json={})
    assert r.status_code == 200, r.text
    d = r.json()
    assert (d["enviados"], d["sin_correo"], [x["nombre"] for x in d["fallidos"]]) == (2, [], ["Ana Mora QA"]), d
    assert d["fallidos"][0]["error"].startswith("OverflowError")
    assert [m["para"] for m in cap.correos] == [["caro.qa@example.test"], ["beto.qa@example.test"]]   # Beto va después de la fila rota y le llega igual
    assert len(cap.reps) == 2 and not any("Ana Mora QA" in _todo(m) for m in cap.correos)
    assert _auditoria(_eid()) == ["Planilla PL-0006: 2 comprobantes enviados, 0 sin correo, 1 fallidos"]
    # pedida sola, la fila rota responde igual (200 con el fallo), no un error de la petición
    assert c.post("/api/rrhh/comprobantes-pago/planilla/6", json={"empleados": [1]}).json()["enviados"] == 0
    # cualquier otra falla al armar la fila (aquí, provocada): lo mismo
    cap.correos.clear(); cap.reps.clear()
    de_verdad = main._fila_comprobante

    def fila_rota(concepto, doc, fila, emp):
        if fila.get("empleado_id") == 1:
            raise RuntimeError("Fila rota QA")
        return de_verdad(concepto, doc, fila, emp)
    monkeypatch.setattr(main, "_fila_comprobante", fila_rota)
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json={})
    assert r.status_code == 200, r.text
    assert r.json() == {"enviados": 2, "sin_correo": [], "fallidos": [{"nombre": "Ana Mora QA", "error": "RuntimeError: Fila rota QA"}]}
    assert [m["para"] for m in cap.correos] == [["caro.qa@example.test"], ["beto.qa@example.test"]] and len(cap.reps) == 2
    assert _auditoria(_eid())[-1] == "Planilla PL-0005: 2 comprobantes enviados, 0 sin correo, 1 fallidos"
    # la cabecera también se arma dentro: si falla para un empleado, los demás siguen
    cap.correos.clear()
    monkeypatch.setattr(main, "_fila_comprobante", de_verdad)
    cabecera = main._cabecera_comprobante

    def cabecera_rota(concepto, doc, emp):
        if emp and emp.get("id") == 3:
            raise RuntimeError("Cabecera rota QA")
        return cabecera(concepto, doc, emp)
    monkeypatch.setattr(main, "_cabecera_comprobante", cabecera_rota)
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json={})
    assert r.status_code == 200 and r.json() == {"enviados": 2, "sin_correo": [], "fallidos": [{"nombre": "Caro Vega QA", "error": "RuntimeError: Cabecera rota QA"}]}, r.text
    assert [m["para"] for m in cap.correos] == [["ana.qa@example.test"], ["beto.qa@example.test"]]


def test_un_empleado_repetido_recibe_un_solo_comprobante(api, monkeypatch):  # noqa: F811
    """Datos viejos o mal guardados: el mismo empleado dos veces en el documento. Recibe UN correo, con su primera fila (la misma que
    da la descarga y la que se envía al pedirlo por su id); las filas sin empleado salen todas en «sin correo»."""
    c, cap = api, _capturar(monkeypatch)
    assert _cambios(c, "empleados", [ANA, BETO], nuevos=[1, 2]).status_code == 200
    repetida, suelta = {**F_ANA, "neto": 777777, "bruto": 777777}, {"nombre": "Fila Suelta QA", "neto": 5000}
    _sembrar(_eid(), {"planillas": [_planilla(5, [F_ANA, F_BETO, repetida, {**F_BETO, "neto": 1}, suelta, {**suelta, "nombre": "Otra Suelta QA"}] + [repetida] * 20)]})
    r = c.post("/api/rrhh/comprobantes-pago/planilla/5", json={})
    assert r.json() == {"enviados": 1, "sin_correo": ["Beto Solís QA", "Fila Suelta QA", "Otra Suelta QA"], "fallidos": []}, r.text
    assert [m["para"] for m in cap.correos] == [["ana.qa@example.test"]] and f"CRC {M(254810)}" in cap.correos[0]["texto"]
    assert M(777777) not in _todo(cap.correos[0]) and len(cap.reps) == 1
    assert c.get("/api/rrhh/comprobante-pago/planilla/5/1").status_code == 200 and cap.reps[0].model_dump() == cap.reps[1].model_dump()   # el de la descarga
    assert c.post("/api/rrhh/comprobantes-pago/planilla/5", json={"empleados": [1]}).json()["enviados"] == 1 and cap.reps[2].model_dump() == cap.reps[0].model_dump()


# ----------------------------------------------------------------------------- aguinaldo y liquidación
def test_aguinaldo_va_al_correo_de_la_ficha_y_no_a_la_copia_de_la_fila(api, monkeypatch):  # noqa: F811
    c, cap = api, _capturar(monkeypatch)
    assert _cambios(c, "empleados", [ANA, BETO], nuevos=[1, 2]).status_code == 200                 # Caro ya no tiene ficha
    ag = {"id": 1, "anio": 2026, "desde": "2025-12-01", "hasta": "2026-11-30", "fecha": "2026-12-15", "cuenta": "Banco QA", "total": 800000, "ref_mov": "aguinaldo:qa1",
          "estado": "Pagado",
          "filas": [{"empleado_id": 1, "nombre": "Ana Mora QA", "correo": "copia.vieja@example.test", "numero_id": "1-0999-0442", "devengado": 6000000, "monto": 500000},
                    {"empleado_id": 2, "nombre": "Beto Solís QA", "correo": "beto.copia@example.test", "devengado": 2400000, "monto": 200000},
                    {"empleado_id": 3, "nombre": "Caro Vega QA", "correo": "caro.copia@example.test", "devengado": 1200000, "monto": 100000}]}
    adicional = {**ag, "id": 7, "fecha": "2026-12-20", "total": 25000, "ref_mov": "aguinaldo:qa7", "adicional": True, "referencia_id": 1,
                 "filas": [{"empleado_id": 1, "nombre": "Ana Mora QA", "devengado": 6300000, "ya_pagado": 500000, "monto": 25000}]}
    viejo = {k: v for k, v in {**ag, "id": 3, "anio": 2025, "ref_mov": "aguinaldo:qa3"}.items() if k != "estado"}   # de una versión anterior, sin estado: es un pago
    pendiente = {**ag, "id": 4, "anio": 2024, "ref_mov": "aguinaldo:qa4", "estado": "Pendiente"}
    assert _cambios(c, "rrhh_aguinaldos", [ag, adicional, viejo, pendiente], nuevos=[1, 7, 3, 4]).status_code == 200
    r = c.post("/api/rrhh/comprobantes-pago/aguinaldo/1", json={})
    # Beto tiene una copia de correo en la fila pero no en su ficha, y Caro ya no tiene ficha: los dos quedan «sin correo»
    assert r.status_code == 200 and r.json() == {"enviados": 1, "sin_correo": ["Beto Solís QA", "Caro Vega QA"], "fallidos": []}, r.text
    assert [m["para"] for m in cap.correos] == [["ana.qa@example.test"]] and "copia" not in " ".join(_todo(m) for m in cap.correos)
    m = cap.correos[0]
    assert m["asunto"] == "Comprobante de aguinaldo · Aguinaldo AG-2026 · Empresa Exoneraciones QA"
    assert m["adjuntos"][0][0] == "comprobante_aguinaldo_AG2026_109990442.pdf" and f"Total pagado: CRC {M(500000)}" in m["texto"]
    assert [x["c"] for x in cap.reps[0].secciones[1].filas] == ["Salarios devengados del 1/12/2025 al 30/11/2026", "Aguinaldo (devengado entre 12, Ley 2412)"]
    assert _auditoria(_eid()) == ["Aguinaldo AG-2026: 1 comprobantes enviados, 2 sin correo, 0 fallidos"]
    # el pago adicional lleva su número y sus tres líneas (antes los armaba la pantalla); el de una versión anterior, sin estado, es un pago
    cap.correos.clear(); cap.reps.clear()
    assert c.post("/api/rrhh/comprobantes-pago/aguinaldo/7", json={}).json()["enviados"] == 1
    assert cap.correos[0]["asunto"].startswith("Comprobante de aguinaldo · Aguinaldo AG-2026-A7 · ") and f"CRC {M(25000)}" in cap.correos[0]["texto"]
    assert [x["c"] for x in cap.reps[0].secciones[1].filas][1:] == ["Aguinaldo ya pagado", "Diferencia de aguinaldo (pago adicional)"]
    assert c.post("/api/rrhh/comprobantes-pago/aguinaldo/3", json={"empleados": [1]}).json()["enviados"] == 1
    # uno que no esté pagado no se envía; ni a quien no está en el pago
    n = len(cap.correos)
    r = c.post("/api/rrhh/comprobantes-pago/aguinaldo/4", json={})
    assert r.status_code == 409 and r.json()["detail"] == "El aguinaldo todavía no está pagado: los comprobantes se envían cuando esté pagado"
    r = c.post("/api/rrhh/comprobantes-pago/aguinaldo/7", json={"empleados": [2]})
    assert r.status_code == 404 and r.json()["detail"] == "Ese empleado no está en el aguinaldo"
    assert c.post("/api/rrhh/comprobantes-pago/aguinaldo/99", json={}).status_code == 404 and len(cap.correos) == n


def test_liquidacion_pagada_va_al_correo_de_la_ficha(api, monkeypatch):  # noqa: F811
    c, cap = api, _capturar(monkeypatch)
    assert _cambios(c, "empleados", [ANA, BETO], nuevos=[1, 2]).status_code == 200
    rubros = [{"rubro": "Vacaciones no disfrutadas", "dias": 3.5, "monto": 58333.33}, {"rubro": "Aguinaldo proporcional", "dias": 0, "monto": 100000},
              {"rubro": "Cesantía", "dias": 20, "monto": 341666.67}]
    lq = {"id": 1, "numero": "LQ-0001", "empleado_id": 1, "nombre": "Ana Mora QA", "fecha": "2026-10-31", "fecha_salida": "2026-10-31", "motivo": "renuncia",
          "rubros": rubros, "total": 500000, "estado": "Pagada", "cuenta": "Banco QA", "pagada_en": "2026-11-02", "ref_mov": "liquidacion:qa1"}
    pendiente = {**lq, "id": 2, "numero": "LQ-0002", "estado": "Pendiente de pago", "cuenta": "", "pagada_en": None, "ref_mov": None}
    de_beto = {**lq, "id": 3, "numero": "LQ-0003", "empleado_id": 2, "nombre": "Beto Solís QA", "ref_mov": "liquidacion:qa3"}
    assert _cambios(c, "liquidaciones", [lq, pendiente, de_beto], nuevos=[1, 2, 3]).status_code == 200
    r = c.post("/api/rrhh/comprobantes-pago/liquidacion/1", json={})
    assert r.status_code == 200 and r.json() == {"enviados": 1, "sin_correo": [], "fallidos": []}, r.text
    m = cap.correos[0]
    assert m["para"] == ["ana.qa@example.test"] and m["asunto"] == "Liquidación laboral · Liquidación LQ-0001 · Empresa Exoneraciones QA"
    assert f"Total pagado: CRC {M(500000)}" in m["texto"] and "del 15/03/2021 al 31/10/2026" in m["texto"]     # desde el ingreso de la FICHA
    assert m["adjuntos"][0][0] == "liquidacion_LQ0001_109990442.pdf"
    assert [x["c"] for x in cap.reps[0].secciones[1].filas] == ["Vacaciones no disfrutadas (3,50 d)", "Aguinaldo proporcional", "Cesantía (20,00 d)"]
    assert _auditoria(_eid()) == ["Liquidación LQ-0001: 1 comprobantes enviados, 0 sin correo, 0 fallidos"]
    # la que no está pagada ya no sale por correo (antes salía como «Total pagado» sin fecha de pago)
    cap.correos.clear()
    r = c.post("/api/rrhh/comprobantes-pago/liquidacion/2", json={})
    assert r.status_code == 409 and r.json()["detail"] == "La liquidación todavía no está pagada: los comprobantes se envían cuando esté pagada"
    r = c.post("/api/rrhh/comprobantes-pago/liquidacion/1", json={"empleados": [2]})               # la liquidación es de otra persona
    assert r.status_code == 404 and r.json()["detail"] == "Ese empleado no está en la liquidación"
    # sin correo en la ficha: no se envía a ningún lado y se dice de quién
    assert c.post("/api/rrhh/comprobantes-pago/liquidacion/3", json={}).json() == {"enviados": 0, "sin_correo": ["Beto Solís QA"], "fallidos": []}
    assert cap.correos == []


# ----------------------------------------------------------------------------- ayudas compartidas (las usan la lista de pago y el PDF único)
def test_ayudas_del_documento_guardado(api):  # noqa: F811
    c, eid = api, _eid()
    assert _cambios(c, "empleados", [ANA, BETO], nuevos=[1, 2]).status_code == 200
    suelta, repetida = {"nombre": "Fila Suelta QA", "neto": 5000}, {**F_ANA, "nombre": "Ana repetida QA", "neto": 1}
    lq = {"id": 4, "numero": "LQ-0004", "empleado_id": 2, "nombre": "Beto Solís QA", "fecha_salida": "2026-10-31", "motivo": "renuncia", "rubros": [], "total": 1000,
          "estado": "Pendiente de pago"}
    _sembrar(eid, {"planillas": [_planilla(1, [F_BETO, suelta, F_ANA, repetida, F_CARO], estado="Generada"), _planilla(5, [F_ANA])], "liquidaciones": [lq]})

    def error(fn, *a):
        with pytest.raises(HTTPException) as ex:
            fn(*a)
        return ex.value.status_code, ex.value.detail

    with _ctx().sesion() as s:
        doc = main._doc_rrhh(s, eid, "planilla", 1)                                # sin pagar: la lista de pago se revisa antes de pagar
        assert doc["numero"] == "PL-0001" and doc["estado"] == "Generada"
        assert main._doc_rrhh(s, eid, "liquidacion", 4)["numero"] == "LQ-0004"
        assert error(main._doc_rrhh, s, eid, "planilla", 77) == (404, "La planilla ya no existe: recargue la página")
        assert error(main._doc_rrhh, s, eid, "aguinaldo", 1) == (404, "El aguinaldo ya no existe: recargue la página")
        assert error(main._doc_rrhh, s, eid + 100000, "planilla", 1)[0] == 404   # con el id de otra empresa no hay nada
        assert error(main._doc_rrhh_pagado, s, eid, "planilla", 1, "la lista de pago se descarga") == (
            409, "La planilla todavía no está pagada: la lista de pago se descarga cuando esté pagada")
        assert error(main._doc_rrhh_pagado, s, eid, "liquidacion", 4, "los comprobantes se descargan")[0] == 409
        assert error(main._doc_rrhh_pagado, s, eid, "planilla", 77, "x")[0] == 404
        assert main._doc_rrhh_pagado(s, eid, "planilla", 5, "x")["numero"] == "PL-0005"
        # todas las filas, en el orden guardado: también la repetida y la que no tiene empleado; con la ficha guardada de cada uno
        filas = main._filas_guardadas(s, eid, "planilla", doc)
        assert [(i, f["nombre"], (emp or {}).get("correo"), emp is None) for i, f, emp in filas] == [
            (2, "Beto Solís QA", None, False), (None, "Fila Suelta QA", None, True), (1, "Ana Mora QA", "ana.qa@example.test", False),
            (1, "Ana repetida QA", "ana.qa@example.test", False), (3, "Caro Vega QA", None, True)]
        # solo algunos: en el orden pedido, sin repetir y con la primera fila de un empleado repetido
        filas = main._filas_guardadas(s, eid, "planilla", doc, [1, 2, 1])
        assert [(i, f["nombre"]) for i, f, _emp in filas] == [(1, "Ana Mora QA"), (2, "Beto Solís QA")]
        assert error(main._filas_guardadas, s, eid, "planilla", doc, [1, 4]) == (404, "Ese empleado no está en la planilla")
        assert error(main._filas_guardadas, s, eid, "planilla", doc, []) == (400, "Indique al menos un empleado")
        # en una liquidación la fila es la liquidación misma
        liq = main._doc_rrhh(s, eid, "liquidacion", 4)
        (i, f, emp), = main._filas_guardadas(s, eid, "liquidacion", liq)
        assert (i, f is liq, emp["nombre"]) == (2, True, "Beto")
        assert error(main._filas_guardadas, s, eid, "liquidacion", liq, [1]) == (404, "Ese empleado no está en la liquidación")
    # la dirección de un empleado: solo la primera del campo «correo» de su ficha
    assert main._correo_de_ficha({"correo": "  a.qa@example.test ; b.qa@example.test"}) == "a.qa@example.test"
    for sin in (None, {}, {"correo": ""}, {"correo": None}, {"correo": "sin arroba"}, {"correo": 5}, {"correo": ["x.qa@example.test"]}, "a.qa@example.test"):
        assert main._correo_de_ficha(sin) is None, sin


# ----------------------------------------------------------------------------- permisos y empresas (sesiones reales)
def test_envio_exige_recursos_humanos_con_la_verificacion_en_dos_pasos(monkeypatch):
    e = _nueva_empresa("Comprobantes 442 QA")
    try:
        r = _usuarios(e, {"admin": ("Administrador", True), "av": ("Avanzado", False), "av_mfa": ("Avanzado", True), "conta": ("Contador", True),
                          "caja": ("Cajero", True), "lee": ("Solo lectura", True)})
        _sembrar(e.id, {"empleados": [ANA], "planillas": [_planilla(5, [F_ANA])]})
        cap = _capturar(monkeypatch, pdf_real=True)
        c, t, ruta = TestClient(app), {k: v["token"] for k, v in r.items()}, "/api/rrhh/comprobantes-pago/planilla/5"
        x = c.post(ruta, json={}, headers=H(t["av"]))                           # el rol trae Recursos humanos, pero falta la verificación
        assert x.status_code == 403 and x.json()["detail"]["codigo"] == "rrhh_mfa", x.text
        for k in ("conta", "caja", "lee"):                                      # sin Recursos humanos
            assert c.post(ruta, json={}, headers=H(t[k])).status_code == 403, k
            assert c.post("/api/rrhh/comprobantes-pago", json={}, headers=H(t[k])).status_code == 403, k    # la ruta de antes tampoco les dice nada
        assert c.post(ruta, json={}).status_code == 401 and c.post("/api/rrhh/comprobantes-pago", json={}).status_code == 401
        assert cap.correos == [] and cap.cfgs == [] and _auditoria(e.id) == []
        for k in ("av_mfa", "admin"):                                           # con el PDF de verdad (encabezado de la empresa)
            x = c.post(ruta, json={}, headers=H(t[k]))
            assert x.status_code == 200 and x.json() == {"enviados": 1, "sin_correo": [], "fallidos": []}, (k, x.text[:200])
        assert [m["para"] for m in cap.correos] == [["ana.qa@example.test"]] * 2
        assert all(m["adjuntos"][0][1].startswith(b"%PDF-") and m["adjuntos"][0][0] == "comprobante_pago_PL0005_109990442.pdf" for m in cap.correos)
        assert _auditoria(e.id) == ["Planilla PL-0005: 1 comprobantes enviados, 0 sin correo, 0 fallidos"] * 2
        with Session(engine) as s:                                              # el historial dice QUIÉN pidió cada envío
            quien = [a.correo for a in s.exec(select(auth.Auditoria).where(auth.Auditoria.empresa_id == e.id, auth.Auditoria.accion == "planilla_correo")
                                              .order_by(auth.Auditoria.id)).all()]
        assert quien == [f"av_mfa.{e.id}.seg47@example.test", f"admin.{e.id}.seg47@example.test"]
    finally:
        _borrar(e)


def test_cada_empresa_envia_solo_lo_suyo(monkeypatch):
    a, b = _nueva_empresa("Comprobantes 442 A QA"), _nueva_empresa("Comprobantes 442 B QA")
    try:
        ta = _usuarios(a, {"admin": ("Administrador", True)})["admin"]["token"]
        tb = _usuarios(b, {"admin": ("Administrador", True)})["admin"]["token"]
        zoe = {**ANA, "nombre": "Zoe", "apellidos": "Otra QA", "numero_id": "409990442", "correo": "zoe.qa@example.test"}       # en B, el empleado 1 es otra persona
        _sembrar(a.id, {"empleados": [ANA], "planillas": [_planilla(5, [F_ANA])],
                        "liquidaciones": [{"id": 1, "numero": "LQ-0001", "empleado_id": 1, "nombre": "Ana Mora QA", "fecha_salida": "2026-10-31", "motivo": "renuncia",
                                           "rubros": [], "total": 500000, "estado": "Pagada", "cuenta": "Banco QA", "pagada_en": "2026-11-02"}]})
        _sembrar(b.id, {"empleados": [zoe]})
        cap, c, ruta = _capturar(monkeypatch), TestClient(app), "/api/rrhh/comprobantes-pago/planilla/5"
        # B no tiene esa planilla ni esa liquidación: las de A no existen para B, con o sin el empleado
        for r in (c.post(ruta, json={}, headers=H(tb)), c.post(ruta, json={"empleados": [1]}, headers=H(tb)),
                  c.post("/api/rrhh/comprobantes-pago/liquidacion/1", json={}, headers=H(tb))):
            assert r.status_code == 404 and "ya no existe" in r.json()["detail"], r.text
        assert c.get("/api/rrhh/comprobante-pago/planilla/5/1", headers=H(tb)).status_code == 404
        assert cap.correos == [] and cap.reps == [] and _auditoria(a.id) == [] and _auditoria(b.id) == []
        # B con su propia planilla 5 (otra persona, otro monto): cada administrador envía la de su empresa, a la ficha de su empresa
        _sembrar(b.id, {"planillas": [_planilla(5, [{**F_ANA, "nombre": "Zoe Otra QA", "neto": 111111}])]})
        assert c.post(ruta, json={}, headers=H(tb)).json() == {"enviados": 1, "sin_correo": [], "fallidos": []}
        assert c.post(ruta, json={}, headers=H(ta)).json() == {"enviados": 1, "sin_correo": [], "fallidos": []}
        de_b, de_a = cap.correos
        assert de_b["para"] == ["zoe.qa@example.test"] and f"CRC {M(111111)}" in de_b["texto"] and a.nombre not in _todo(de_b)
        assert M(254810) not in _todo(de_b) and "Ana Mora QA" not in _todo(de_b) and "ana.qa@example.test" not in _todo(de_b)
        assert de_a["para"] == ["ana.qa@example.test"] and f"CRC {M(254810)}" in de_a["texto"] and b.nombre not in _todo(de_a)
        assert M(111111) not in _todo(de_a) and "Zoe Otra QA" not in _todo(de_a) and "zoe.qa@example.test" not in _todo(de_a)
        assert cap.cfgs == [b.id, a.id]                                           # cada una con SU correo de Recursos humanos
        assert len(_auditoria(a.id)) == 1 and len(_auditoria(b.id)) == 1
    finally:
        _borrar(a); _borrar(b)


# ----------------------------------------------------------------------------- pantallas
NODOS = (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files\Adobe\Adobe Creative Cloud Experience\libs\node.exe")
# enviarComprobantes (planilla.js y aguinaldo.js) y enviar (liquidaciones.js) tal como están, con sustitutos de lo que usan. El
# guardado de la prueba tarda (un temporizador): si la pantalla pidiera el envío sin esperarlo, «pedido» quedaría antes de «guardado»
PRUEBA_PANTALLAS = r"""
const copia = v => JSON.parse(JSON.stringify(v));
const S = {};
const caso = (extra = {}) => Object.assign(S, { log: [], avisos: [], pedidos: [], respuesta: { enviados: 1, sin_correo: [], fallidos: [] }, error: null,
  guardado: true, alGuardar: null, datos: {}, confirmados: {} }, extra);
const toast = (t, k) => { S.avisos.push([k || '', t]); };
// S.datos es la copia de la pestaña (con las altas que todavía no subieron); S.confirmados, lo último que se sabe guardado en el servidor
const mock = {
  get(k, d) { return k in S.datos ? copia(S.datos[k]) : d; },
  confirmadoDe(k, id) { const x = (S.confirmados[k] || []).find(y => String(y.id) === String(id)); return x ? copia(x) : null; },
  async guardarTodo() { await new Promise(r => setTimeout(r, 20)); if (S.alGuardar) S.alGuardar(); S.log.push('guardado'); return S.guardado; },
};
const api = async (url, opt = {}) => { S.log.push('pedido'); S.pedidos.push([url, opt.method, JSON.stringify(opt.body)]); if (S.error) throw new Error(S.error); return copia(S.respuesta); };
const planilla = {
/*PLANILLA*/
};
const aguinaldo = {
/*AGUINALDO*/
};
const liquidaciones = {
/*LIQUIDACIONES*/
};
const foto = c => ({ log: copia(S.log), avisos: copia(S.avisos), pedidos: copia(S.pedidos), enviando: c.enviando });
const NO_PAGADA = 'La planilla todavía no está pagada: los comprobantes se envían cuando esté pagada';
const PL = { id: 5, numero: 'PL-0005', periodo: 'quincenal', desde: '2026-11-01', hasta: '2026-11-15', estado: 'Pagada', cuenta: 'Banco QA', pagada_en: '2026-11-16',
  filas: [{ empleado_id: 1, nombre: 'Ana Mora QA', correo: 'otro.qa@example.test', neto: 254810 }, { empleado_id: 2, nombre: 'Beto Solís QA', neto: 174340 }] };
const out = {};
let c;
// planilla: guarda lo pendiente, después pide el envío de ESA planilla y avisa como siempre
caso({ respuesta: { enviados: 1, sin_correo: ['Beto Solís QA'], fallidos: [] } });
c = { ...planilla, enviando: null }; await c.enviarComprobantes(copia(PL)); out.planilla = foto(c);
caso(); c = { ...planilla, enviando: null }; await c.enviarComprobantes({ ...copia(PL), filas: [] }); out.planillaVacia = foto(c);
// el guardado falló (la marca «Pagada» no subió): se pide igual y el servidor responde que no está pagada
caso({ guardado: false, error: NO_PAGADA }); c = { ...planilla, enviando: null }; await c.enviarComprobantes(copia(PL)); out.planillaSinGuardar = foto(c);
caso({ respuesta: { enviados: 2, sin_correo: [], fallidos: [{ nombre: 'Caro Vega QA', error: 'rechazado' }] } });
c = { ...planilla, enviando: null }; await c.enviarComprobantes(copia(PL)); out.planillaFallo = foto(c);
// aguinaldo recién registrado: al guardarlo, el servidor le dio otro id (otra persona registró uno a la vez); se busca por su referencia
const AG = { id: 3, anio: 2026, desde: '2025-12-01', hasta: '2026-11-30', fecha: '2026-12-15', ref_mov: 'aguinaldo:r1', filas: [{ empleado_id: 1, nombre: 'Ana Mora QA', monto: 500000 }] };
const VIEJOS = [{ id: 2, anio: 2025, ref_mov: 'aguinaldo:viejo' }, { id: 3, anio: 2026, ref_mov: 'aguinaldo:ajeno' }];
const conOtroId = () => { S.datos.rrhh_aguinaldos = [...copia(VIEJOS), { ...copia(AG), id: 9 }]; S.confirmados.rrhh_aguinaldos = copia(S.datos.rrhh_aguinaldos); };
caso({ datos: { rrhh_aguinaldos: [copia(AG)] }, respuesta: { enviados: 2, sin_correo: [], fallidos: [] }, alGuardar: conOtroId });
c = { ...aguinaldo, enviando: null }; await c.enviarComprobantes(copia(AG)); out.aguinaldoOtroId = foto(c);
// uno de una versión anterior, sin referencia: con su id (ya venía del servidor). Se pulsa el SEGUNDO de los dos sin referencia: buscar
// «el primero sin referencia» pediría el 4 (los comprobantes del aguinaldo 2020)
caso({ datos: { rrhh_aguinaldos: [{ id: 4, anio: 2020 }, { id: 5, anio: 2021 }] } }); c = { ...aguinaldo, enviando: null }; await c.enviarComprobantes({ id: 5, anio: 2021, filas: [] }); out.aguinaldoViejo = foto(c);
// recién registrado y el guardado falló (el servidor no respondió o respondió con error): el pago sigue en la pestaña, pendiente de subir,
// pero el servidor no lo tiene. No se pide el envío (respondería «ya no existe: recargue la página», y recargar perdería el pago)
caso({ guardado: false, datos: { rrhh_aguinaldos: [{ id: 2, anio: 2025, ref_mov: 'aguinaldo:viejo' }, copia(AG)] }, confirmados: { rrhh_aguinaldos: [{ id: 2, anio: 2025, ref_mov: 'aguinaldo:viejo' }] } });
c = { ...aguinaldo, enviando: null }; await c.enviarComprobantes(copia(AG)); out.aguinaldoSinConfirmar = foto(c);
// ...y al pulsar otra vez «✉ Comprobantes» el guardado sí llega (con otro id): ahora se envía, con el id que quedó guardado
Object.assign(S, { guardado: true, alGuardar: conOtroId, respuesta: { enviados: 2, sin_correo: [], fallidos: [] } });
await c.enviarComprobantes(copia(AG)); out.aguinaldoReintento = foto(c);
// el guardado quedó en duda y el id de la pestaña (3) es, en el servidor, el pago que registró otra persona: no se envían los de ese pago
caso({ guardado: false, datos: { rrhh_aguinaldos: [copia(AG)] }, confirmados: { rrhh_aguinaldos: copia(VIEJOS) } });
c = { ...aguinaldo, enviando: null }; await c.enviarComprobantes(copia(AG)); out.aguinaldoIdAjeno = foto(c);
// el servidor rechazó el alta y la pestaña la descartó: la referencia no aparece en lo guardado. Tampoco se pide con el id de la pantalla
caso({ datos: { rrhh_aguinaldos: [{ id: 4, anio: 2020, ref_mov: 'aguinaldo:otro' }] }, confirmados: { rrhh_aguinaldos: [{ id: 4, anio: 2020, ref_mov: 'aguinaldo:otro' }, { id: 6, anio: 2019, ref_mov: 'aguinaldo:ajeno6' }] } });
c = { ...aguinaldo, enviando: null }; await c.enviarComprobantes({ id: 6, anio: 2022, ref_mov: 'aguinaldo:r6' }); out.aguinaldoSinLista = foto(c);
caso({ error: 'El aguinaldo ya no existe: recargue la página', datos: { rrhh_aguinaldos: [copia(AG)] }, confirmados: { rrhh_aguinaldos: [copia(AG)] } });
c = { ...aguinaldo, enviando: null }; await c.enviarComprobantes(copia(AG)); out.aguinaldoError = foto(c);
// liquidación
const LQ = { id: 4, numero: 'LQ-0004', empleado_id: 1, nombre: 'Ana Mora QA', total: 500000, estado: 'Pagada', rubros: [{ rubro: 'Cesantía', dias: 20, monto: 500000 }] };
const conLista = lista => ({ ...liquidaciones, enviando: null, lista });
caso(); c = conLista([{ id: 1, correo: 'ana.qa@example.test' }]); await c.enviar(copia(LQ)); out.liquidacion = foto(c);
caso(); c = conLista([{ id: 1 }]); await c.enviar(copia(LQ)); out.liquidacionSinCorreoEnPantalla = foto(c);
caso({ respuesta: { enviados: 0, sin_correo: ['Ana Mora QA'], fallidos: [] } }); c = conLista([{ id: 1, correo: 'ana.qa@example.test' }]); await c.enviar(copia(LQ)); out.liquidacionSinCorreoGuardado = foto(c);
caso({ respuesta: { enviados: 0, sin_correo: [], fallidos: [{ nombre: 'Ana Mora QA', error: 'rechazado' }] } }); c = conLista([{ id: 1, correo: 'ana.qa@example.test' }]); await c.enviar(copia(LQ)); out.liquidacionFallo = foto(c);
caso({ guardado: false, error: 'La liquidación todavía no está pagada: los comprobantes se envían cuando esté pagada' }); c = conLista([{ id: 1, correo: 'ana.qa@example.test' }]); await c.enviar(copia(LQ)); out.liquidacionSinGuardar = foto(c);
console.log(JSON.stringify(out));
"""


def _metodo(js, firma):
    """Un método del componente tal como está: desde su firma hasta la línea que lo cierra («    },»), una sola vez en el archivo."""
    assert js.count(firma) == 1, firma
    i = js.index(firma)
    return js[i:js.index("\n    },\n", i) + len("\n    },\n")]


def _metodos_de_envio():
    pl, ag, lq = _js("pages", "rrhh", "planilla.js"), _js("pages", "rrhh", "aguinaldo.js"), _js("pages", "rrhh", "liquidaciones.js")
    return (_metodo(pl, "    async enviarComprobantes(p) {"), _metodo(ag, "    async enviarComprobantes(a) {"), _metodo(lq, "    async enviar(l) {"))


def test_pantallas_guardan_antes_y_solo_dicen_cual_documento(tmp_path):
    """Corre en Node los tres métodos de envío de las pantallas. El servidor arma el comprobante con lo guardado: la pantalla tiene
    que haber guardado la marca «Pagada» (o el aguinaldo recién registrado) ANTES de pedir el envío, y no manda montos ni correos."""
    node = shutil.which("node") or next((x for x in NODOS if pathlib.Path(x).exists()), None)
    if not node:
        pytest.skip("sin Node.js en este equipo")
    pl, ag, lq = _metodos_de_envio()
    (tmp_path / "prueba.mjs").write_text(PRUEBA_PANTALLAS.replace("/*PLANILLA*/", pl).replace("/*AGUINALDO*/", ag).replace("/*LIQUIDACIONES*/", lq), encoding="utf-8")
    r = subprocess.run([node, str(tmp_path / "prueba.mjs")], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(tmp_path))
    assert r.returncode == 0, r.stderr[-2000:]
    o = json.loads(r.stdout)
    orden = ["guardado", "pedido"]
    # planilla
    assert o["planilla"] == {"log": orden, "pedidos": [["/api/rrhh/comprobantes-pago/planilla/5", "POST", "{}"]], "enviando": None,
                             "avisos": [["ok", "1 comprobante enviado · 1 sin correo (Beto Solís QA)"]]}
    assert o["planillaVacia"] == {"log": [], "pedidos": [], "enviando": None, "avisos": [["err", "La planilla no tiene empleados"]]}
    assert o["planillaSinGuardar"]["log"] == orden and o["planillaSinGuardar"]["enviando"] is None
    assert o["planillaSinGuardar"]["avisos"] == [["err", "No se enviaron los comprobantes: " + NO_PAGADA]]
    assert o["planillaFallo"]["avisos"] == [["err", "2 comprobantes enviados · 1 con error: Caro Vega QA (rechazado)"]]
    # aguinaldo: el id que quedó guardado (9), no el que tenía la pantalla (3, que ahora es el pago de otra persona)
    assert o["aguinaldoOtroId"] == {"log": orden, "pedidos": [["/api/rrhh/comprobantes-pago/aguinaldo/9", "POST", "{}"]], "enviando": None,
                                    "avisos": [["ok", "2 comprobantes enviados"]]}
    assert o["aguinaldoViejo"]["pedidos"] == [["/api/rrhh/comprobantes-pago/aguinaldo/5", "POST", "{}"]] and o["aguinaldoViejo"]["log"] == orden
    # vuelta 1 de la revisión: el pago recién registrado se envía solo si quedó guardado en el servidor. Si el guardado falló o quedó en
    # duda no se le pide nada al servidor (ni con el id de la pestaña ni con el de la pantalla), el aviso no manda a recargar (recargar
    # perdería el pago) y el botón queda libre para pulsarlo otra vez
    sin_guardar = [["err", "El pago del aguinaldo todavía no se guardó en el servidor y no se enviaron los comprobantes. "
                           "No recargue la página: cuando se guarde, pulse ✉ Comprobantes"]]
    for k in ("aguinaldoSinConfirmar", "aguinaldoIdAjeno"):
        assert o[k] == {"log": ["guardado"], "pedidos": [], "enviando": None, "avisos": sin_guardar}, k
    assert o["aguinaldoReintento"] == {"log": ["guardado"] + orden, "pedidos": [["/api/rrhh/comprobantes-pago/aguinaldo/9", "POST", "{}"]], "enviando": None,
                                       "avisos": sin_guardar + [["ok", "2 comprobantes enviados"]]}
    assert o["aguinaldoSinLista"] == {"log": ["guardado"], "pedidos": [], "enviando": None,
                                      "avisos": [["err", "El pago del aguinaldo no quedó guardado en el servidor y no se enviaron los comprobantes"]]}
    assert o["aguinaldoError"]["pedidos"] == [["/api/rrhh/comprobantes-pago/aguinaldo/3", "POST", "{}"]]
    assert o["aguinaldoError"]["avisos"] == [["err", "No se enviaron los comprobantes: El aguinaldo ya no existe: recargue la página"]]
    assert o["aguinaldoError"]["enviando"] is None
    # liquidación
    assert o["liquidacion"] == {"log": orden, "pedidos": [["/api/rrhh/comprobantes-pago/liquidacion/4", "POST", "{}"]], "enviando": None,
                                "avisos": [["ok", "Liquidación enviada a ana.qa@example.test"]]}
    assert o["liquidacionSinCorreoEnPantalla"] == {"log": [], "pedidos": [], "enviando": None, "avisos": [["err", "Ana Mora QA no tiene correo registrado en su ficha"]]}
    assert o["liquidacionSinCorreoGuardado"]["avisos"] == [["err", "No se envió: Ana Mora QA no tiene correo registrado en su ficha"]]
    assert o["liquidacionFallo"]["avisos"] == [["err", "No se envió: rechazado"]]
    assert o["liquidacionSinGuardar"]["log"] == orden and o["liquidacionSinGuardar"]["enviando"] is None
    assert o["liquidacionSinGuardar"]["avisos"] == [["err", "No se envió la liquidación: La liquidación todavía no está pagada: los comprobantes se envían cuando esté pagada"]]
    # en ningún caso viaja otra cosa que el documento: el cuerpo es siempre {}
    assert {p[2] for caso in o.values() for p in caso["pedidos"]} == {"{}"}


def test_pantallas_texto_del_envio():
    pl, ag, lq = _js("pages", "rrhh", "planilla.js"), _js("pages", "rrhh", "aguinaldo.js"), _js("pages", "rrhh", "liquidaciones.js")
    m_pl, m_ag, m_lq = _metodos_de_envio()
    for nombre, js, metodo, ruta in (("planilla.js", pl, m_pl, "await api('/api/rrhh/comprobantes-pago/planilla/' + p.id, { method: 'POST', body: {} });"),
                                     ("aguinaldo.js", ag, m_ag, "await api('/api/rrhh/comprobantes-pago/aguinaldo/' + g.id, { method: 'POST', body: {} });"),
                                     ("liquidaciones.js", lq, m_lq, "await api('/api/rrhh/comprobantes-pago/liquidacion/' + l.id, { method: 'POST', body: {} });")):
        assert ruta in metodo and js.count(ruta) == 1, nombre                                         # a la ruta que lleva el documento
        assert metodo.count("await mock.guardarTodo();") == 1 and metodo.index("await mock.guardarTodo();") < metodo.index("await api("), nombre
        for no in ("filas:", "correo:", "neto:", "numero:", "detalle", "concepto:"):                    # nada de lo que antes viajaba
            assert no not in metodo, (nombre, no)
        for n, linea in enumerate(metodo.splitlines(), 1):                                             # lección del proyecto: sin // a media línea
            assert "//" not in linea, (nombre, n)
    assert "const g = a.ref_mov ? " in m_ag                                                         # vuelta 2: sin referencia, el mismo pago
    assert "x.ref_mov === a.ref_mov" in m_ag and m_ag.index("await mock.guardarTodo();") < m_ag.index("x.ref_mov === a.ref_mov") < m_ag.index("await api(")
    # vuelta 1: entre buscar el pago y pedir el envío se exige que esté CONFIRMADO en el servidor con su misma referencia; ya no hay
    # «si no aparece, con el id de la pantalla» (solo los pagos sin referencia, de versiones anteriores, van con su id)
    assert m_ag.index("x.ref_mov === a.ref_mov") < m_ag.index("mock.confirmadoDe('rrhh_aguinaldos', g.id)") < m_ag.index("c.ref_mov === a.ref_mov") < m_ag.index("await api(")
    assert "|| a;" not in m_ag and "|| a)" not in m_ag and m_ag.count("mock.confirmadoDe(") == 1 and "this.enviando = null;\n          return toast(" in m_ag
    assert "confirmadoDe(key, id) {" in _js("api.js")                                                # la función de api.js que usa (4.31)
    # ninguna pantalla del sistema llama ya a la ruta de antes (la que recibía los montos)
    for f in (RAIZ / "app" / "static").rglob("*.js"):
        assert "/api/rrhh/comprobantes-pago'" not in f.read_text(encoding="utf-8", errors="replace"), f.name
    # el guardado va DENTRO del envío, no en «Marcar pagada»: confirmarPago, terminarPago y terminarPendientes siguen como estaban
    pago = pl[pl.index("    async confirmarPago() {"):pl.index("    // 4.7: una planilla PAGADA no se elimina")]
    assert "guardarTodo" not in pago and pago.count("await this.enviarComprobantes(p);") == 2
    cp = lq[lq.index("    async confirmarPago() {"):lq.index("    async enviar(l) {")]
    assert "guardarTodo" not in cp and "if (enviar) await this.enviar(l);" in cp
    reg = ag[ag.index("    async registrar() {"):ag.index("    async enviarComprobantes(a) {")]
    assert "guardarTodo" not in reg and "if (this.enviar && this.correoListo) await this.enviarComprobantes(nuevo);" in reg
    # los botones de la lista: solo en lo pagado (una liquidación sin pagar ya no se envía por correo)
    assert """<button class="btn sm sec" v-if="row.estado==='Pagada' && correoListo" :disabled="enviando===row.id" @click.stop="enviar(row)" """ in lq
    assert 'v-if="correoListo" :disabled="enviando===row.id" @click.stop="enviar(row)"' not in lq
    assert """<button class="btn sm sec" v-if="correoListo && pagado(a)" :disabled="enviando===a.id" """ in ag and """@click.stop="enviarComprobantes(a)">""" in ag
    assert """<button class="btn sm sec" v-if="row.estado==='Pagada' && correoListo" :disabled="enviando===row.id" """ in pl and """@click.stop="enviarComprobantes(row)">""" in pl
    # el servidor: la ruta nueva lee la base de la empresa y pide Recursos humanos; la de antes no recibe cuerpo
    py = (RAIZ / "app" / "main.py").read_text(encoding="utf-8")
    i = py.index('@app.post("/api/rrhh/comprobantes-pago/{concepto}/{doc_id}")')
    nueva = py[i:py.index("\n\n\n", i)]
    assert "def enviar_comprobantes_pago(concepto: Literal[\"planilla\", \"aguinaldo\", \"liquidacion\"], doc_id: int, data: Optional[EnvioComprobantesIn] = None," in nueva
    assert 'ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)' in nueva
    assert nueva.index("_doc_rrhh_pagado(") < nueva.index("_filas_guardadas(") < nueva.index("_cfg_smtp_rrhh(e)") < nueva.index("correo.enviar(")
    assert "nombre, para = f.nombre, _correo_de_ficha(emp)" in nueva and "correo.enviar(cfg, [para], asunto, html, texto," in nueva
    assert "f.correo" not in nueva and "data.filas" not in nueva and nueva.count("data.") == 1          # del cuerpo solo se lee data.empleados
    j = py.index('@app.post("/api/rrhh/comprobantes-pago")\n')
    vieja = py[j:py.index("\n\n\n", j)]
    assert 'def comprobantes_pago_pantalla_anterior(ctx: Contexto = Depends(requiere("rrhh"))):' in vieja and "correo.enviar" not in vieja and "raise HTTPException(409," in vieja
