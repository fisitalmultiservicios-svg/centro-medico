"""Agenda web compartida y acceso de pacientes con invitación verificada."""
import hashlib
import secrets as aleatorio
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Annotated, Literal
from urllib.parse import urlsplit

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy import DateTime, or_, text
from sqlmodel import Field as Col, SQLModel, select

from . import auth
from .db import Empresa, por_empresa, sesion_de
from .medica import (Base, Central, Cita, CitaIn, Clinica, Nombre, Paciente, Recepcion, _ahora,
                     _buscar, _cita_clinica, _evento, _privada, _profesionales, _sede, nueva_cita, router)
from .medica_config import habilitada
from .medica_operacion import Bloqueo, cifrar, leer
from .medica_servicios import Adjunto, Cargo, Orden, _documento, descarga_adjunto

portal = APIRouter(dependencies=[Depends(_privada)])
SIN_CACHE = {"Cache-Control": "private, no-store", "Referrer-Policy": "no-referrer"}


class Acceso(SQLModel, table=True):
    __tablename__ = "medica_portal_acceso"
    paciente_id: int = Col(primary_key=True)
    invitacion_hash: str | None = None
    vence: datetime | None = Col(default=None, sa_type=DateTime)
    password_hash: str | None = None
    version: str
    ultimo_ingreso: datetime | None = Col(default=None, sa_type=DateTime)


class Horario(SQLModel, table=True):
    __tablename__ = "medica_portal_horario"
    __table_args__ = {"sqlite_autoincrement": True}
    id: int | None = Col(default=None, primary_key=True)
    sede: int = Col(index=True)
    profesional_id: int
    profesional: str
    especialidad: str
    servicio: str
    consultorio: str
    inicio: datetime = Col(sa_type=DateTime)
    fin: datetime = Col(sa_type=DateTime)
    modalidad: str
    cita_id: int | None = None
    activo: bool = True


class Videocita(SQLModel, table=True):
    __tablename__ = "medica_videocita"
    cita_id: int = Col(primary_key=True)
    datos: str


class EventoPortal(SQLModel, table=True):
    __tablename__ = "medica_portal_evento"
    id: int | None = Col(default=None, primary_key=True)
    paciente_id: int
    accion: str
    recurso_id: int
    fecha: datetime = Col(sa_type=DateTime)


por_empresa(Acceso, Horario, Videocita, EventoPortal)


def _registro_portal(s, paciente_id, accion, recurso_id):
    s.add(EventoPortal(paciente_id=paciente_id, accion=accion, recurso_id=recurso_id, fecha=_ahora()))


def _empresa(sc, eid):
    e = sc.get(Empresa, eid)
    if not habilitada(e) or e.bloqueada or auth.prueba_vencida(e):
        raise HTTPException(404, "Portal no disponible")
    return e


@router.post("/pacientes/{pid}/portal/invitacion")
def invitar(pid: int, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    _buscar(s, Paciente, pid, ctx)
    secreto = aleatorio.token_urlsafe(32)
    acceso = s.get(Acceso, pid)
    if acceso:
        acceso.version = aleatorio.token_hex(16)
        acceso.password_hash = None
    else:
        acceso = Acceso(paciente_id=pid, version=aleatorio.token_hex(16))
        s.add(acceso)
    acceso.invitacion_hash = hashlib.sha256(secreto.encode()).hexdigest()
    acceso.vence = _ahora() + timedelta(minutes=30)
    _evento(s, ctx, "portal.invitado", pid)
    s.commit()
    return {"portal": f"/medica/portal/{ctx.empresa.id}", "expediente": pid, "codigo": secreto, "minutos": 30}


@router.delete("/pacientes/{pid}/portal")
def revocar(pid: int, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    _buscar(s, Paciente, pid, ctx)
    acceso = s.get(Acceso, pid)
    if acceso:
        s.delete(acceso)
        _evento(s, ctx, "portal.revocado", pid)
        s.commit()
    return {"ok": True}


class Credenciales(BaseModel):
    expediente: int = Field(gt=0)
    password: str = Field(min_length=1, max_length=128)


class RegistroIn(Credenciales):
    codigo: str = Field(min_length=20, max_length=100)


def _limite(request, eid, expediente):
    aviso = "Demasiados intentos de acceso. Intente más tarde."
    auth.limitar_ip(request, "medica-portal-ip", 40, 600, aviso)
    auth.limitar_ip(request, "medica-portal", 12, 600, aviso, sujeto=f"{eid}:{expediente}")


@portal.get("/medica/portal/{eid}", include_in_schema=False)
def pagina(eid: int, sc: Central):
    _empresa(sc, eid)
    archivo = Path(__file__).parent / "static" / "medica-portal.html"
    return FileResponse(archivo, media_type="text/html", headers={
        **SIN_CACHE, "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
    })


@portal.get("/api/medica/portal/{eid}/info")
def info(eid: int, sc: Central):
    e = _empresa(sc, eid)
    return {"nombre": e.nombre_comercial or e.nombre}


@portal.post("/api/medica/portal/{eid}/registro")
def registro(eid: int, data: RegistroIn, request: Request, sc: Central):
    _empresa(sc, eid)
    _limite(request, eid, data.expediente)
    auth.validar_password(data.password)
    marca = hashlib.sha256(data.codigo.encode()).hexdigest()
    clave = auth.hash_password(data.password)
    with sesion_de(eid) as s:
        s.exec(text("BEGIN IMMEDIATE"))
        acceso = s.get(Acceso, data.expediente)
        if not acceso or not acceso.vence or acceso.vence <= _ahora() or not aleatorio.compare_digest(acceso.invitacion_hash or "", marca):
            raise HTTPException(403, "Invitación inválida o vencida")
        acceso.invitacion_hash = None
        acceso.vence = None
        acceso.password_hash = clave
        _registro_portal(s, acceso.paciente_id, "portal.registrado", acceso.paciente_id)
        s.commit()
    return {"ok": True}


@portal.post("/api/medica/portal/{eid}/sesion")
def ingresar(eid: int, data: Credenciales, request: Request, sc: Central):
    _empresa(sc, eid)
    _limite(request, eid, data.expediente)
    with sesion_de(eid) as s:
        acceso = s.get(Acceso, data.expediente)
        if not auth._verificar_lento(data.password, acceso.password_hash if acceso else None):
            raise HTTPException(401, "Expediente o contraseña incorrectos")
        acceso.ultimo_ingreso = _ahora()
        token = auth.firmar({"tipo": "medica", "eid": eid, "pid": acceso.paciente_id, "v": acceso.version}, 1200)
        _registro_portal(s, acceso.paciente_id, "portal.ingreso", acceso.paciente_id)
        s.commit()
    return {"token": token}


def _paciente(s, eid, token):
    d = auth.abrir(token or "")
    if not d or d.get("tipo") != "medica" or d.get("eid") != eid:
        raise HTTPException(401, "Inicie sesión en el portal")
    titular = d.get("titular")
    acceso = s.get(Acceso, titular or d["pid"])
    paciente = s.get(Paciente, d["pid"])
    if not acceso or not paciente or not acceso.password_hash or acceso.version != d.get("v"):
        raise HTTPException(401, "La sesión del portal ya no está activa")
    if titular:
        persona = s.get(Paciente, titular)
        if not persona or persona.sede != paciente.sede or not _representacion_vigente(s, titular, paciente.id):
            raise HTTPException(401, "Ya no tiene acceso a este expediente")
    return paciente


class HorarioIn(BaseModel):
    especialidad: Nombre
    servicio: Nombre
    consultorio: Nombre
    profesional_id: int
    inicio: datetime
    fin: datetime
    modalidad: Literal["presencial", "telemedicina"] = "presencial"


@router.get("/agenda/web")
def publicados(ctx: Recepcion, s: Base):
    return s.exec(select(Horario).where(Horario.sede == _sede(ctx), Horario.fin >= _ahora())
                  .order_by(Horario.inicio).limit(200)).all()


@router.post("/agenda/web", status_code=201)
def publicar_horario(data: HorarioIn, ctx: Recepcion, s: Base, sc: Central):
    if data.inicio.tzinfo or data.fin.tzinfo or not _ahora() < data.inicio < data.fin:
        raise HTTPException(422, "El horario debe ser futuro y estar en hora local")
    profesional = next((p for p in _profesionales(ctx, sc) if p["id"] == data.profesional_id), None)
    if not profesional:
        raise HTTPException(422, "Profesional no disponible")
    s.exec(text("BEGIN IMMEDIATE"))
    consulta = select(Horario.id).where(
        Horario.activo == True, Horario.sede == _sede(ctx),  # noqa: E712
        Horario.profesional_id == data.profesional_id, Horario.inicio == data.inicio,
    )
    if s.exec(consulta).first():
        raise HTTPException(409, "Ya hay un horario web con ese inicio")
    fila = Horario(sede=_sede(ctx), profesional=profesional["nombre"], **data.model_dump())
    s.add(fila)
    s.flush()
    _evento(s, ctx, "portal.horario_publicado", fila.id)
    s.commit()
    s.refresh(fila)
    return fila


@router.delete("/agenda/web/{horario_id}")
def retirar_horario(horario_id: int, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    fila = _buscar(s, Horario, horario_id, ctx)
    fila.activo = False
    _evento(s, ctx, "portal.horario_retirado", fila.id)
    s.commit()
    return {"ok": True}


def _espacio(s, h):
    sala = h.consultorio.casefold()
    filtros = (Cita.profesional_id == h.profesional_id) | ((Cita.sede == h.sede) & (Cita.consultorio == sala))
    ocupado = s.exec(select(Cita.id).where(
        Cita.estado.not_in(("cancelada", "no se presentó")), filtros, Cita.inicio < h.fin, Cita.fin > h.inicio,
    )).first()
    bloqueado = s.exec(select(Bloqueo.id).where(
        or_(Bloqueo.profesional_id == h.profesional_id, (Bloqueo.sede == h.sede) & (Bloqueo.consultorio == sala)),
        Bloqueo.inicio < h.fin, Bloqueo.fin > h.inicio,
    )).first()
    return not ocupado and not bloqueado


@portal.get("/api/medica/portal/{eid}/horarios")
def horarios(eid: int, sc: Central, sede: int | None = None):
    _empresa(sc, eid)
    with sesion_de(eid) as s:
        q = select(Horario).where(Horario.activo == True, Horario.inicio > _ahora(),  # noqa: E712
                                 Horario.inicio <= _ahora() + timedelta(days=90))
        if sede is not None:
            q = q.where(Horario.sede == sede)
        return [
            h.model_dump(exclude={"cita_id", "consultorio", "profesional_id", "activo"})
            for h in s.exec(q.order_by(Horario.inicio).limit(250)) if _espacio(s, h)
        ]


class ReservaWebIn(BaseModel):
    reemplaza: int | None = Field(default=None, gt=0)


@portal.post("/api/medica/portal/{eid}/horarios/{horario_id}/reservar", status_code=201)
def reservar_portal(eid: int, horario_id: int, sc: Central, data: ReservaWebIn | None = None,
                    x_medica_portal: Annotated[str | None, Header()] = None):
    e = _empresa(sc, eid)
    with sesion_de(eid) as s:
        s.exec(text("BEGIN IMMEDIATE"))
        p = _paciente(s, eid, x_medica_portal)
        h = s.get(Horario, horario_id)
        if not h or not h.activo or h.sede != p.sede or h.inicio <= _ahora():
            raise HTTPException(404, "Horario no disponible para su expediente")
        u = sc.get(auth.Usuario, h.profesional_id)
        membresia = sc.exec(select(auth.UsuarioEmpresa).where(
            auth.UsuarioEmpresa.empresa_id == e.id, auth.UsuarioEmpresa.usuario_id == h.profesional_id
        )).first()
        if (not u or u.bloqueado or not u.mfa_activo or not membresia
                or (membresia.sucursal_id is not None and membresia.sucursal_id != h.sede)
                or "medica_clinica" not in auth.permisos_de_rol(sc, e.id, membresia.rol)):
            raise HTTPException(409, "El profesional ya no está disponible")
        if h.cita_id:
            anterior = s.get(Cita, h.cita_id)
            if anterior and anterior.paciente_id == p.id and anterior.estado not in {"cancelada", "no se presentó"}:
                return {"id": anterior.id, "estado": anterior.estado}
        reemplaza = data.reemplaza if data else None
        if reemplaza:
            anterior = _cita_paciente(s, p, reemplaza)
            if anterior.estado not in {"programada", "confirmada"} or anterior.inicio < _ahora() + timedelta(hours=24):
                raise HTTPException(409, "Contacte a recepción para reprogramar esta cita")
            anterior.estado = "cancelada"
            _registro_portal(s, p.id, "portal.cita_reprogramada", anterior.id)
            s.flush()
        c = nueva_cita(s, h.sede, CitaIn(paciente_id=p.id, profesional_id=h.profesional_id, consultorio=h.consultorio,
                                        inicio=h.inicio, fin=h.fin, modalidad=h.modalidad))
        c.estado = "confirmada"
        h.cita_id = c.id
        if reemplaza and (ficha := s.get(Preadmision, reemplaza)):
            s.add(Preadmision(cita_id=c.id, datos=ficha.datos, fecha=ficha.fecha))
        _registro_portal(s, p.id, "portal.cita_reservada", c.id)
        salida = {"id": c.id, "estado": c.estado}
        s.commit()
        return salida


@portal.post("/api/medica/portal/{eid}/citas/{cita_id}/cancelar")
def cancelar(eid: int, cita_id: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    _empresa(sc, eid)
    with sesion_de(eid) as s:
        s.exec(text("BEGIN IMMEDIATE"))
        p = _paciente(s, eid, x_medica_portal)
        c = s.get(Cita, cita_id)
        if not c or c.paciente_id != p.id or c.sede != p.sede:
            raise HTTPException(404, "Cita no disponible")
        if c.estado == "cancelada":
            return {"ok": True}
        if c.estado not in {"programada", "confirmada"} or c.inicio < _ahora() + timedelta(hours=24):
            raise HTTPException(409, "Contacte a recepción para cancelar esta cita")
        c.estado = "cancelada"
        _registro_portal(s, p.id, "portal.cita_cancelada", c.id)
        s.commit()
        return {"ok": True}


class VideoIn(BaseModel):
    enlace: str = Field(default="", max_length=900)
    consentida: bool = False


@router.put("/agenda/{cita_id}/video")
def enlace_video(cita_id: int, data: VideoIn, ctx: Recepcion, s: Base):
    c = _buscar(s, Cita, cita_id, ctx)
    if c.modalidad != "telemedicina":
        raise HTTPException(409, "La cita no es de telemedicina")
    if data.enlace:
        try:
            url = urlsplit(data.enlace)
            valido = url.scheme == "https" and url.hostname and not url.username and not url.password
        except ValueError:
            valido = False
        if not valido or not data.consentida:
            raise HTTPException(422, "Ingrese un enlace HTTPS individual y registre el consentimiento")
    payload = cifrar(ctx.empresa, data.model_dump())
    enlace = s.get(Videocita, cita_id)
    if enlace:
        enlace.datos = payload
    else:
        s.add(Videocita(cita_id=cita_id, datos=payload))
    _evento(s, ctx, "cita.video_configurado", cita_id)
    s.commit()
    return {"ok": True}


@portal.get("/api/medica/portal/{eid}/cuenta")
def cuenta(eid: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    e = _empresa(sc, eid)
    with sesion_de(eid) as s:
        p = _paciente(s, eid, x_medica_portal)
        citas = []
        for c in s.exec(select(Cita).where(Cita.paciente_id == p.id, Cita.sede == p.sede)
                        .order_by(Cita.inicio.desc()).limit(100)):
            v = None
            if (c.modalidad == "telemedicina" and c.estado in {"programada", "confirmada", "llegó", "en espera", "en consulta"}
                    and c.inicio - timedelta(minutes=30) <= _ahora() <= c.fin + timedelta(minutes=30)):
                video = s.get(Videocita, c.id)
                if video:
                    v = leer(e, video.datos).get("enlace")
            citas.append({"id": c.id, "inicio": c.inicio, "fin": c.fin, "estado": c.estado, "modalidad": c.modalidad, "video": v})
        ordenes = []
        q = select(Orden).join(Cita, Cita.id == Orden.cita_id).where(
            Cita.paciente_id == p.id, Cita.sede == p.sede, Orden.publicada.is_not(None)
        ).order_by(Orden.publicada.desc()).limit(100)
        for orden in s.exec(q):
            ordenes.append({"id": orden.id, "tipo": orden.tipo, "publicada": orden.publicada,
                            **leer(e, orden.datos), "resultado": leer(e, orden.resultado).get("texto"),
                            "adjunto": s.exec(select(Adjunto.orden_id).where(Adjunto.orden_id == orden.id)).first() is not None})
            _registro_portal(s, p.id, "portal.orden_leida", orden.id)
        facturas = []
        q = select(Cargo).join(Cita, Cita.id == Cargo.cita_id).where(
            Cita.paciente_id == p.id, Cita.sede == p.sede, Cargo.privado_portal == False  # noqa: E712
        ).order_by(Cargo.id.desc()).limit(100)
        for cargo in s.exec(q):
            doc = _documento(s, eid, cargo)
            if doc and doc.cliente_id == p.cliente_id:
                facturas.append({"id": cargo.id, "consecutivo": doc.consecutivo, "total": doc.total,
                                 "saldo": max(0, doc.total - doc.pagado - doc.acreditado), "estado": doc.estado,
                                 "pagable": doc.estado in {"aceptado", "interno"} and doc.condicion_venta == "02"
                                 and round(doc.total - doc.pagado - doc.acreditado, 2) > 0})
        s.commit()
        return {"nombre": p.nombre, "sede": p.sede, "citas": citas, "documentos": ordenes, "facturas": facturas}


@portal.get("/api/medica/portal/{eid}/documentos/{orden_id}/pdf")
def pdf_orden(eid: int, orden_id: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    e = _empresa(sc, eid)
    with sesion_de(eid) as s:
        p = _paciente(s, eid, x_medica_portal)
        orden = s.get(Orden, orden_id)
        c = s.get(Cita, orden.cita_id) if orden and orden.publicada else None
        if not c or c.paciente_id != p.id or c.sede != p.sede:
            raise HTTPException(404, "Documento no disponible")
        respuesta = descarga_adjunto(s, e, orden_id)
        _registro_portal(s, p.id, "portal.orden_descargada", orden.id)
        s.commit()
        return respuesta


@portal.get("/api/medica/portal/{eid}/facturas/{cargo_id}/pdf")
def pdf_factura(eid: int, cargo_id: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    from .main import _pdf_de

    e = _empresa(sc, eid)
    with sesion_de(eid) as s:
        p = _paciente(s, eid, x_medica_portal)
        cargo = s.get(Cargo, cargo_id)
        c = s.get(Cita, cargo.cita_id) if cargo and not cargo.privado_portal else None
        doc = _documento(s, eid, cargo) if c and c.paciente_id == p.id and c.sede == p.sede else None
        if not doc or doc.cliente_id != p.cliente_id or not doc.xml_nombre:
            raise HTTPException(404, "Factura no disponible")
        try:
            datos = _pdf_de(doc, e)
        except FileNotFoundError:
            raise HTTPException(404, "Factura no disponible") from None
        _registro_portal(s, p.id, "portal.factura_descargada", cargo.id)
        s.commit()
        return Response(datos, media_type="application/pdf", headers={
            **SIN_CACHE, "Content-Disposition": f'attachment; filename="{doc.consecutivo}.pdf"',
        })


class Preadmision(SQLModel, table=True):
    __tablename__ = "medica_preadmision"
    cita_id: int = Col(primary_key=True)
    datos: str
    fecha: datetime = Col(sa_type=DateTime)


class Mensaje(SQLModel, table=True):
    __tablename__ = "medica_portal_mensaje"
    id: int | None = Col(default=None, primary_key=True)
    paciente_id: int = Col(index=True)
    texto: str
    direccion: str
    fecha: datetime = Col(sa_type=DateTime)
    autor_id: int | None = None


por_empresa(Preadmision, Mensaje)


class PreadmisionIn(BaseModel):
    motivo: str = Field(min_length=1, max_length=4000)
    preparacion: bool


class MensajeIn(BaseModel):
    texto: str = Field(min_length=2, max_length=2000)


def _cita_paciente(s, p, id):
    c = s.get(Cita, id)
    if not c or c.paciente_id != p.id or c.sede != p.sede:
        raise HTTPException(404, "Cita no disponible")
    return c


@portal.post("/api/medica/portal/{eid}/citas/{cita_id}/preadmision")
def preadmision(eid: int, cita_id: int, data: PreadmisionIn, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    e = _empresa(sc, eid)
    with sesion_de(eid) as s:
        s.exec(text("BEGIN IMMEDIATE"))
        p = _paciente(s, eid, x_medica_portal)
        c = _cita_paciente(s, p, cita_id)
        if c.estado not in {"programada", "confirmada"}:
            raise HTTPException(409, "La preadmisión requiere una cita previa a la llegada")
        contenido = cifrar(e, data.model_dump())
        anterior = s.get(Preadmision, c.id)
        if anterior:
            anterior.datos, anterior.fecha = contenido, _ahora()
        else:
            s.add(Preadmision(cita_id=c.id, datos=contenido, fecha=_ahora()))
        _registro_portal(s, p.id, "portal.preadmision", c.id)
        s.commit()
    return {"ok": True}


@router.get("/agenda/{cita_id}/preadmision")
def ver_preadmision(cita_id: int, ctx: Clinica, s: Base):
    c = _cita_clinica(s, cita_id, ctx)
    if c.estado in {"programada", "confirmada", "cancelada", "no se presentó"}:
        raise HTTPException(409, "Registre la llegada antes de consultar la preadmisión")
    fila = s.get(Preadmision, cita_id)
    if not fila:
        return None
    _evento(s, ctx, "cita.preadmision_leida", cita_id)
    valores = leer(ctx.empresa, fila.datos)
    s.commit()
    return valores


def _mensajes(s, e, paciente_id):
    q = select(Mensaje).where(Mensaje.paciente_id == paciente_id).order_by(Mensaje.id.desc()).limit(50)
    return [
        {**r.model_dump(exclude={"texto", "autor_id"}), **leer(e, r.texto)}
        for r in reversed(s.exec(q).all())
    ]


def _guardar_mensaje(s, e, paciente_id, data, direccion, autor_id=None):
    if not data.texto.strip():
        raise HTTPException(422, "Escriba un mensaje")
    r = Mensaje(paciente_id=paciente_id, direccion=direccion, autor_id=autor_id, fecha=_ahora(),
                texto=cifrar(e, {"texto": data.texto.strip()}))
    s.add(r)
    s.flush()
    return r


@portal.get("/api/medica/portal/{eid}/mensajes")
def mensajes_web(eid: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    e = _empresa(sc, eid)
    with sesion_de(eid) as s:
        p = _paciente(s, eid, x_medica_portal)
        return _mensajes(s, e, p.id)


@portal.post("/api/medica/portal/{eid}/mensajes", status_code=201)
def enviar_web(eid: int, data: MensajeIn, sc: Central, request: Request,
               x_medica_portal: Annotated[str | None, Header()] = None):
    e = _empresa(sc, eid)
    with sesion_de(eid) as s:
        p = _paciente(s, eid, x_medica_portal)
        auth.limitar_ip(request, "medica-mensaje", 15, 600, "Espere antes de enviar otro mensaje", sujeto=f"{eid}:{p.id}")
        r = _guardar_mensaje(s, e, p.id, data, "paciente")
        _registro_portal(s, p.id, "portal.mensaje_enviado", r.id)
        s.commit()
    return {"ok": True}


@router.get("/pacientes/{pid}/mensajes")
def mensajes_recepcion(pid: int, ctx: Recepcion, s: Base):
    _buscar(s, Paciente, pid, ctx)
    salida = _mensajes(s, ctx.empresa, pid)
    _evento(s, ctx, "portal.mensajes_leidos", pid)
    s.commit()
    return salida


@router.post("/pacientes/{pid}/mensajes", status_code=201)
def responder(pid: int, data: MensajeIn, ctx: Recepcion, s: Base):
    _buscar(s, Paciente, pid, ctx)
    r = _guardar_mensaje(s, ctx.empresa, pid, data, "recepción", ctx.usuario.id)
    _evento(s, ctx, "portal.mensaje_respondido", r.id)
    s.commit()
    return {"ok": True}


class LlegadaWeb(SQLModel, table=True):
    __tablename__ = "medica_portal_llegada"
    cita_id: int = Col(primary_key=True)
    codigo_hash: str = Col(index=True, unique=True)
    vence: datetime = Col(sa_type=DateTime)


por_empresa(LlegadaWeb)


@portal.post("/api/medica/portal/{eid}/citas/{cita_id}/check-in")
def codigo_llegada(eid: int, cita_id: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    import base64
    import io
    import qrcode

    _empresa(sc, eid)
    with sesion_de(eid) as s:
        s.exec(text("BEGIN IMMEDIATE"))
        p = _paciente(s, eid, x_medica_portal)
        c = _cita_paciente(s, p, cita_id)
        ahora = _ahora()
        if (c.estado not in {"programada", "confirmada"} or c.modalidad == "telemedicina"
                or not c.inicio - timedelta(hours=3) <= ahora <= c.fin + timedelta(hours=1)):
            raise HTTPException(409, "El código está disponible cerca de la hora de llegada a la sede")
        codigo = aleatorio.token_hex(6).upper()
        marca = hashlib.sha256(codigo.encode()).hexdigest()
        valores = {"codigo_hash": marca, "vence": ahora + timedelta(minutes=20)}
        existente = s.get(LlegadaWeb, cita_id)
        if existente:
            existente.sqlmodel_update(valores)
        else:
            s.add(LlegadaWeb(cita_id=cita_id, **valores))
        _registro_portal(s, p.id, "portal.checkin_creado", cita_id)
        s.commit()
    imagen = io.BytesIO()
    qrcode.make(codigo, box_size=5, border=3).save(imagen, format="PNG")
    return {"codigo": codigo, "qr": base64.b64encode(imagen.getvalue()).decode(), "minutos": 20}


class LlegadaIn(BaseModel):
    codigo: str = Field(min_length=12, max_length=24)


@router.post("/check-in")
def confirmar_llegada(data: LlegadaIn, ctx: Recepcion, s: Base):
    candidato = data.codigo.strip().upper()
    marca = hashlib.sha256(candidato.encode()).hexdigest()
    s.exec(text("BEGIN IMMEDIATE"))
    codigo = s.exec(select(LlegadaWeb).where(LlegadaWeb.codigo_hash == marca)).first()
    if not codigo or codigo.vence <= _ahora():
        raise HTTPException(404, "Código de llegada no disponible")
    c = _buscar(s, Cita, codigo.cita_id, ctx)
    if c.estado not in {"programada", "confirmada"}:
        raise HTTPException(409, "La cita ya no admite el registro de llegada")
    c.llegada, c.estado = _ahora(), "llegó"
    s.delete(codigo)
    _evento(s, ctx, "cita.checkin_confirmado", c.id)
    s.commit()
    return {"id": c.id, "estado": "llegó"}


class Representacion(SQLModel, table=True):
    __tablename__ = "medica_portal_representacion"
    titular_id: int = Col(primary_key=True)
    representado_id: int = Col(primary_key=True)
    vence: date
    referencia: str
    activa: bool = True


por_empresa(Representacion)


class RepresentacionIn(BaseModel):
    representado_id: int
    vence: date
    referencia: str = Field(min_length=3, max_length=300)


def _representacion_vigente(s, titular_id, representado_id):
    r = s.get(Representacion, (titular_id, representado_id))
    return bool(r and r.activa and r.vence >= _ahora().date())


@router.get("/pacientes/{pid}/representaciones")
def listar_representaciones(pid: int, ctx: Recepcion, s: Base):
    _buscar(s, Paciente, pid, ctx)
    q = select(Representacion, Paciente.nombre).join(Paciente, Paciente.id == Representacion.representado_id)
    q = q.where(Representacion.titular_id == pid, Paciente.sede == _sede(ctx))
    return [
        {**r.model_dump(exclude={"referencia"}), "nombre": nombre}
        for r, nombre in s.exec(q.limit(100))
    ]


@router.post("/pacientes/{pid}/representaciones")
def autorizar_representacion(pid: int, data: RepresentacionIn, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    _buscar(s, Paciente, pid, ctx)
    _buscar(s, Paciente, data.representado_id, ctx)
    if pid == data.representado_id or data.vence < _ahora().date():
        raise HTTPException(422, "Indique otro expediente de la sede y una vigencia válida")
    actual = s.get(Representacion, (pid, data.representado_id))
    referencia = cifrar(ctx.empresa, {"referencia": data.referencia})
    if actual:
        actual.activa, actual.vence, actual.referencia = True, data.vence, referencia
    else:
        s.add(Representacion(titular_id=pid, representado_id=data.representado_id, vence=data.vence,
                             referencia=referencia))
    _evento(s, ctx, "portal.representacion_autorizada", data.representado_id)
    s.commit()
    return {"ok": True}


@router.delete("/pacientes/{pid}/representaciones/{representado_id}")
def revocar_representacion(pid: int, representado_id: int, ctx: Recepcion, s: Base):
    s.exec(text("BEGIN IMMEDIATE"))
    _buscar(s, Paciente, pid, ctx)
    _buscar(s, Paciente, representado_id, ctx)
    actual = s.get(Representacion, (pid, representado_id))
    if actual:
        actual.activa = False
        _evento(s, ctx, "portal.representacion_revocada", representado_id)
        s.commit()
    return {"ok": True}


@portal.get("/api/medica/portal/{eid}/representaciones")
def mis_representaciones(eid: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    _empresa(sc, eid)
    with sesion_de(eid) as s:
        p = _paciente(s, eid, x_medica_portal)
        d = auth.abrir(x_medica_portal or "")
        if d.get("titular"):
            return []
        q = select(Paciente.id, Paciente.nombre).join(Representacion, Representacion.representado_id == Paciente.id)
        q = q.where(Representacion.titular_id == p.id, Representacion.activa == True,  # noqa: E712
                    Representacion.vence >= _ahora().date(), Paciente.sede == p.sede)
        return [{"id": pid, "nombre": nombre} for pid, nombre in s.exec(q.limit(100))]


@portal.post("/api/medica/portal/{eid}/representaciones/{representado_id}/sesion")
def representar(eid: int, representado_id: int, sc: Central, x_medica_portal: Annotated[str | None, Header()] = None):
    import time as reloj

    _empresa(sc, eid)
    with sesion_de(eid) as s:
        p = _paciente(s, eid, x_medica_portal)
        d = auth.abrir(x_medica_portal or "")
        if d.get("titular") or not _representacion_vigente(s, p.id, representado_id):
            raise HTTPException(404, "Representación no disponible")
        destino = s.get(Paciente, representado_id)
        if not destino or destino.sede != p.sede:
            raise HTTPException(404, "Representación no disponible")
        ttl = min(1200, d["exp"] - int(reloj.time()))
        if ttl <= 0:
            raise HTTPException(401, "La sesión del portal ya no está activa")
        _registro_portal(s, p.id, "portal.representacion_iniciada", representado_id)
        s.commit()
        return {"token": auth.firmar({"tipo": "medica", "eid": eid, "pid": representado_id,
                                      "titular": p.id, "v": d["v"]}, ttl)}
