import { campo, citaRuta, clientes, enviar, fechaHora, Formulario, leer, lista, operaciones, opciones, productos } from './_comun.js';
import { toast } from '../../api.js';
import { sesion } from '../../app.js';

const periodo = [
  campo('inicio','Inicio (Costa Rica)','datetime-local',{req:true}),
  campo('fin','Fin (Costa Rica)','datetime-local',{req:true}),
];
const modalidades = opciones(['presencial','telemedicina','en sitio','en calle']);

export default {
  components: { Formulario },
  mixins: [operaciones],
  data() {
    return {
      pacientes: [], citas: [], profesionales: [], convenios: [], espera: [], horarios: [], bloqueos: [],
      paciente: null, ficha: null, coberturas: [], mensajes: [], representaciones: [], cita: null, validacion: null, cargos: [],
      invitacion: null, q: '', dia: '', pestaña: 'agenda', lineasCargo: null,
    };
  },
  computed: {
    puedeFacturar() { return sesion.puede('facturar'); },
    puedeCobrar() { return sesion.puede('cobros'); },
    portal() { return '/medica/portal/' + sesion.empresa_id; },
  },
  methods: {
    fechaHora,
    async iniciar() {
      [this.citas, this.profesionales, this.convenios] = await Promise.all([
        leer('/agenda', {dia:this.dia}), leer('/profesionales'), leer('/catalogo-convenios'),
      ]);
    },
    async cambiar(tab) {
      this.pestaña = tab;
      await this.ejecutar(async () => {
        if (tab === 'pacientes') await this.buscar();
        if (tab === 'disponibilidad') [this.horarios,this.bloqueos] = await Promise.all([leer('/agenda/web'),leer('/bloqueos')]);
        if (tab === 'espera') this.espera = await leer('/espera');
        if (tab === 'agenda') await this.iniciar();
      });
    },
    async buscar() { this.pacientes = await leer('/pacientes', {q:this.q}); },
    alta(p = null) {
      this.pedir(p ? 'Actualizar paciente' : 'Nuevo paciente', [
        campo('nombre','Nombre completo','text',{req:true}), campo('documento','Documento','text',{req:true,max:32}),
        campo('nacimiento','Fecha de nacimiento','date',{req:true}), campo('telefono','Teléfono','tel'),
        campo('correo','Correo','email'),
      ], p || {}, async d => {
        await enviar(p ? '/pacientes/' + p.id : '/pacientes', d, p ? 'PUT' : 'POST');
        await this.buscar();
        if (p) this.paciente = null;
      });
    },
    async abrirPaciente(p) {
      this.paciente = p;
      this.invitacion = null;
      [this.ficha, this.coberturas, this.mensajes, this.representaciones] = await Promise.all([
        leer('/pacientes/' + p.id + '/ficha'), leer('/pacientes/' + p.id + '/coberturas'), leer('/pacientes/' + p.id + '/mensajes'),
        leer('/pacientes/' + p.id + '/representaciones'),
      ]);
    },
    representar() {
      const ruta='/pacientes/'+this.paciente.id+'/representaciones';
      this.pedir('Autorizar acceso como representante',[
        campo('representado_id','Expediente de la persona representada','number',{req:true,min:1}),
        campo('vence','Vence','date',{req:true}),
        campo('referencia','Referencia de la autorización verificada','textarea',{req:true,max:300}),
      ],{},async d=>{await enviar(ruta,d);this.representaciones=await leer(ruta);},'Autorizar');
    },
    async quitarRepresentacion(r) {
      const ruta='/pacientes/'+this.paciente.id+'/representaciones';
      await enviar(ruta+'/'+r.representado_id,undefined,'DELETE');
      this.representaciones=await leer(ruta);
    },
    responder() {
      const ruta='/pacientes/'+this.paciente.id+'/mensajes';
      this.pedir('Mensaje administrativo',[campo('texto','Mensaje','textarea',{req:true,max:2000})],{},
        async d=>{await enviar(ruta,d);this.mensajes=await leer(ruta);},'Enviar');
    },
    editarFicha() {
      this.pedir('Ficha administrativa', [
        campo('tipo','Tipo de paciente','select',{req:true,opciones:opciones(['particular','asegurado','corporativo'])}),
        campo('cliente_id','Contacto fiscal del ERP','select',{opciones:clientes()}),
        campo('direccion','Dirección'), campo('emergencia','Contacto de emergencia'), campo('idioma','Idioma'),
        campo('observacion_administrativa','Alerta administrativa'),
        campo('consentimiento_datos','Consentimiento de datos registrado','checkbox'),
        campo('consentimiento_contacto','Autorizó avisos por correo','checkbox'),
      ], {tipo:'particular',...this.ficha}, async d => {
        await enviar('/pacientes/' + this.paciente.id + '/ficha', d, 'PUT');
        this.ficha = await leer('/pacientes/' + this.paciente.id + '/ficha');
      });
    },
    cobertura() {
      this.pedir('Agregar póliza o cobertura', [
        campo('tipo','Tipo','select',{req:true,opciones:opciones(['asegurado','corporativo'])}),
        campo('convenio_id','Aseguradora o convenio','select',{req:true,opciones:lista(this.convenios)}),
        campo('vigencia_desde','Desde','date',{req:true}), campo('vigencia_hasta','Hasta','date',{req:true}),
        campo('poliza','Número de póliza'), campo('autorizacion','Autorización'), campo('numero_empleado','Número de empleado'),
        campo('copago','Copago (CRC)','number',{min:0,paso:.01}), campo('deducible','Deducible (CRC)','number',{min:0,paso:.01}),
        campo('max_atenciones','Límite de atenciones (0 = sin límite)','number',{min:0}), campo('servicios','Servicios'), campo('exclusiones','Exclusiones'),
      ], {tipo:'asegurado',copago:0,deducible:0,max_atenciones:0}, async d => {
        const ruta = '/pacientes/' + this.paciente.id + '/coberturas';
        await enviar(ruta,d);
        this.coberturas = await leer(ruta);
      });
    },
    async emitirInvitacion() {
      this.invitacion = await enviar('/pacientes/' + this.paciente.id + '/portal/invitacion');
    },
    async revocarPortal() {
      await enviar('/pacientes/' + this.paciente.id + '/portal', undefined, 'DELETE');
      this.invitacion = null;
      toast('Acceso al portal revocado','ok');
    },
    facultativo(req = true) {
      return campo('profesional_id','Profesional','select',{req,opciones:lista(this.profesionales)});
    },
    programar(paciente, cita = null) {
      const campos = [
        this.facultativo(), campo('consultorio','Consultorio','text',{req:true}), ...periodo,
        campo('modalidad','Modalidad','select',{req:true,opciones:modalidades}),
        campo('tipo_atencion','Tipo de atención','select',{req:true,opciones:opciones(['consulta','pre-empleo','periódico','reintegro','egreso','campaña'])}),
        campo('ubicacion','Ubicación de atención en sitio o calle'),
      ];
      if (cita) campos.push(campo('motivo','Motivo del cambio','text',{req:true}));
      this.pedir(cita ? 'Reprogramar cita' : 'Programar cita', campos,
        cita ? {...cita,inicio:cita.inicio.slice(0,16),fin:cita.fin.slice(0,16)} : {paciente_id:paciente.id,modalidad:'presencial',tipo_atencion:'consulta'},
        async d => {
          await enviar(cita ? citaRuta(cita.id) + '/reprogramar' : '/agenda',d,cita ? 'PUT' : 'POST');
          this.cita = null;
          await this.iniciar();
          this.pestaña = 'agenda';
        });
    },
    codigoLlegada() {
      this.pedir('Registrar llegada con código',[campo('codigo','Código de llegada','text',{req:true,max:24})],{},
        async d=>{await enviar('/check-in',d);await this.iniciar();},'Registrar llegada');
    },
    async estado(c, estado) {
      await enviar(citaRuta(c.id) + '/estado',{estado},'PUT');
      await this.iniciar();
    },
    async verCita(c) {
      this.cita = c;
      [this.validacion,this.coberturas,this.cargos] = await Promise.all([
        leer(citaRuta(c.id)+'/cobertura'), leer('/pacientes/'+c.paciente_id+'/coberturas'),
        this.puedeFacturar ? leer(citaRuta(c.id)+'/cargos') : [],
      ]);
    },
    validar() {
      this.pedir('Validar cobertura', [
        campo('cobertura_id','Cobertura','select',{req:true,opciones:this.coberturas.map(x=>[x.id,x.tipo+' · '+(x.poliza || x.numero_empleado || x.id)])}),
        campo('estado','Resultado de la verificación','select',{req:true,opciones:opciones(['cubierta','parcial','rechazada'])}),
        campo('producto_id','Servicio del ERP','select',{opciones:productos()}),
      ], this.validacion || {estado:'cubierta'}, async d => {
        await enviar(citaRuta(this.cita.id)+'/cobertura',d,'PUT');
        await this.verCita(this.cita);
      });
    },
    editarVideo() {
      this.pedir('Telemedicina', [
        campo('enlace','Enlace HTTPS individual','url',{max:900}),
        campo('consentida','Consentimiento de telemedicina registrado','checkbox'),
      ], {}, d => enviar(citaRuta(this.cita.id)+'/video',d,'PUT'));
    },
    async recordar() {
      await enviar(citaRuta(this.cita.id)+'/recordar');
      toast('Recordatorio enviado','ok');
    },
    cargo() {
      this.pedir('Preparar cargo', [
        campo('pagador','Responsable de pago','select',{req:true,opciones:opciones(['paciente','tercero','aseguradora','empresa'])}),
        campo('cliente_id','Contacto fiscal','select',{opciones:clientes()}),
        campo('tipo','Tipo de comprobante','select',{req:true,opciones:[['01','Factura'],['04','Tiquete']]}),
        campo('mostrar_portal','Mostrar comprobante al paciente','checkbox'),
      ], {pagador:'paciente',tipo:'01'}, async d => {
        this.lineasCargo = { datos:d, productos:productos(), lineas:[{cantidad:1}] };
      }, 'Agregar ítems');
    },
    async prepararCargo() {
      const f = this.lineasCargo;
      await enviar(citaRuta(this.cita.id)+'/cargos',{...f.datos,lineas:f.lineas.map(l=>({
        ...l,precio_unitario:l.precio_unitario === '' ? null : l.precio_unitario,
        orden_id:l.orden_id || null,
      }))});
      this.lineasCargo = null;
      await this.verCita(this.cita);
    },
    emitir(c) {
      this.pedir('Emitir comprobante', [
        campo('medio_pago','Medio de pago','select',{req:true,opciones:[['01','Efectivo'],['02','Tarjeta'],['03','Cheque'],['04','Transferencia'],['06','SINPE Móvil']]}),
        campo('condicion_venta','Condición','select',{req:true,opciones:[['01','Contado'],['02','Crédito']]}),
        campo('plazo_credito','Plazo en días','number',{min:1,limite:365}),
      ], {medio_pago:'01',condicion_venta:'01'}, async d => {
        await enviar('/cargos/'+c.id+'/emitir',d);
        await this.verCita(this.cita);
      }, 'Emitir');
    },
    async cancelarCargo(c) {
      await enviar('/cargos/'+c.id+'/cancelar');
      await this.verCita(this.cita);
    },
    conciliar(c) {
      this.pedir('Conciliar pago web',[
        campo('cuenta','Cuenta de Bancos (opcional)'),
      ],{},async d=>{
        const r=await enviar('/cargos/'+c.id+'/conciliar',d);
        toast('Pago web · '+r.estado,r.estado==='conciliado'?'ok':'');
        await this.verCita(this.cita);
      },'Consultar y conciliar');
    },
    nuevoHorario() {
      this.pedir('Publicar horario web',[
        this.facultativo(), campo('consultorio','Consultorio','text',{req:true}),
        campo('especialidad','Especialidad','text',{req:true}), campo('servicio','Servicio','text',{req:true}), ...periodo,
        campo('modalidad','Modalidad','select',{req:true,opciones:opciones(['presencial','telemedicina'])}),
      ],{modalidad:'presencial'},async d=>{await enviar('/agenda/web',d);this.horarios=await leer('/agenda/web');});
    },
    nuevoBloqueo() {
      this.pedir('Bloquear horario',[
        this.facultativo(false),campo('consultorio','Consultorio'),...periodo,campo('motivo','Motivo','text',{req:true}),
      ],{},async d=>{await enviar('/bloqueos',d);this.bloqueos=await leer('/bloqueos');});
    },
    async retirar(ruta) {
      await enviar(ruta,undefined,'DELETE');
      [this.horarios,this.bloqueos] = await Promise.all([leer('/agenda/web'),leer('/bloqueos')]);
    },
    registrarEspera() {
      this.pedir('Lista de espera',[campo('servicio','Servicio','text',{req:true}),campo('preferencia','Preferencia de horario')],
        {paciente_id:this.paciente.id},async d=>{await enviar('/espera',d);toast('Paciente en lista de espera','ok');});
    },
    async cerrarEspera(r) { await enviar('/espera/'+r.id+'/cerrar'); this.espera=await leer('/espera'); },
  },
  created() { this.ejecutar(this.iniciar); },
  template: `
  <div class="page">
    <PageHead title="Recepción" :crumbs="[{label:'Médica'}]"><a class="btn sec" :href="portal" target="_blank" rel="noopener noreferrer">Portal del paciente</a></PageHead>
    <div class="acts">
      <button class="btn sec" v-for="[id,titulo] in [['agenda','Agenda'],['pacientes','Pacientes'],['disponibilidad','Disponibilidad web'],['espera','Lista de espera']]" :key="id"
        :aria-pressed="pestaña===id" @click="cambiar(id)">{{titulo}}</button>
    </div>
    <section v-if="pestaña==='agenda'" class="card">
      <h2>Agenda de la sede</h2>
      <button class="btn sec" @click="codigoLlegada">Check-in con código</button>
      <label>Fecha <input v-model="dia" type="date" @change="ejecutar(iniciar)"></label>
      <p v-if="!citas.length">Sin citas para mostrar. Para programar, abre la ficha de un paciente.</p>
      <div v-else class="tablewrap"><table class="tabla"><thead><tr><th>Hora</th><th>Paciente</th><th>Consultorio</th><th>Estado</th><th></th></tr></thead>
      <tbody><tr v-for="c in citas" :key="c.id">
        <td>{{fechaHora(c.inicio)}}</td><td>{{c.paciente}}</td><td>{{c.consultorio}} · {{c.modalidad}}</td><td>{{c.estado}}</td>
        <td><button class="btn sm sec" @click="ejecutar(()=>verCita(c))">Abrir cita</button>
        <button v-if="c.estado==='programada'" class="btn sm sec" @click="ejecutar(()=>estado(c,'confirmada'))">Confirmar</button>
        <button v-if="['programada','confirmada'].includes(c.estado)" class="btn sm" @click="ejecutar(()=>estado(c,'llegó'))">Registrar llegada</button>
        <button v-if="c.estado==='llegó'" class="btn sm sec" @click="ejecutar(()=>estado(c,'en espera'))">Poner en espera</button></td>
      </tr></tbody></table></div>
    </section>
    <section v-if="pestaña==='pacientes'" class="card">
      <h2>Pacientes de la sede</h2>
      <form class="acts" @submit.prevent="ejecutar(buscar)">
        <input v-model="q" aria-label="Buscar pacientes" placeholder="Expediente, nombre, documento o teléfono">
        <button class="btn sec" :disabled="ocupado">Buscar</button><button type="button" class="btn" @click="alta()">Nuevo paciente</button>
      </form>
      <p v-if="!pacientes.length">Sin pacientes para mostrar.</p>
      <ul v-else><li v-for="p in pacientes" :key="p.id">{{p.nombre}} · #{{p.id}}
        <button class="btn sm sec" @click="ejecutar(()=>abrirPaciente(p))">Abrir ficha</button>
        <button class="btn sm sec" @click="programar(p)">Programar</button>
      </li></ul>
    </section>
    <section v-if="pestaña==='disponibilidad'" class="card">
      <div class="acts"><button class="btn" @click="nuevoHorario">Publicar horario</button><button class="btn sec" @click="nuevoBloqueo">Bloquear horario</button></div>
      <h2>Horarios publicados</h2>
      <ul><li v-for="h in horarios" :key="h.id">{{fechaHora(h.inicio)}} · {{h.profesional}} · {{h.servicio}} · {{h.activo?'Publicado':'Retirado'}}
        <button v-if="h.activo" class="btn sm sec" @click="ejecutar(()=>retirar('/agenda/web/'+h.id))">Retirar</button></li></ul>
      <h2>Bloqueos</h2>
      <ul><li v-for="b in bloqueos" :key="b.id">{{fechaHora(b.inicio)}} · {{b.consultorio||'Profesional'}} · {{b.motivo}}
        <button class="btn sm sec" @click="ejecutar(()=>retirar('/bloqueos/'+b.id))">Desbloquear</button></li></ul>
    </section>
    <section v-if="pestaña==='espera'" class="card">
      <h2>Solicitudes en espera</h2>
      <p v-if="!espera.length">Sin solicitudes. Puedes agregar un paciente desde su ficha.</p>
      <ul><li v-for="e in espera" :key="e.id">{{e.paciente}} · {{e.servicio}} · {{e.preferencia}} · {{e.atendida?'Cerrada':'Pendiente'}}
        <button v-if="!e.atendida" class="btn sm" @click="ejecutar(()=>cerrarEspera(e))">Cerrar solicitud</button></li></ul>
    </section>
    <Modal v-if="paciente && !formulario" :title="paciente.nombre" @close="paciente=null" size="lg">
      <p>Expediente #{{paciente.id}} · {{paciente.documento}} · {{paciente.telefono}} · {{paciente.correo}}</p>
      <div class="acts">
        <button class="btn sec" @click="alta(paciente)">Editar datos</button><button class="btn sec" @click="editarFicha">Datos y consentimientos</button>
        <button class="btn sec" @click="cobertura">Agregar cobertura</button><button class="btn sec" @click="registrarEspera">Lista de espera</button>
      </div>
      <ul><li v-for="c in coberturas" :key="c.id">{{c.tipo}} · {{c.poliza || c.numero_empleado || c.id}} · Hasta {{c.vigencia_hasta}} · Copago ₡{{c.copago}}</li></ul>
      <h3>Mensajes administrativos</h3>
      <ul><li v-for="m in mensajes" :key="m.id">{{fechaHora(m.fecha)}} · {{m.direccion}} · {{m.texto}}</li></ul>
      <button class="btn sec" @click="responder">Enviar mensaje</button>
      <h3>Representación de familiares</h3>
      <ul><li v-for="r in representaciones" :key="r.representado_id">{{r.nombre}} · Vence {{r.vence}} · {{r.activa?'Autorizada':'Revocada'}}
        <button v-if="r.activa" class="btn sm sec" @click="ejecutar(()=>quitarRepresentacion(r))">Revocar</button></li></ul>
      <button class="btn sec" @click="representar">Autorizar representación</button>
      <h3>Portal del paciente</h3>
      <p>Verifica la identidad antes de entregar la invitación. Generar otra invitación revoca el acceso anterior.</p>
      <div class="acts"><button class="btn sec" @click="ejecutar(emitirInvitacion)">Generar invitación</button><button class="btn sec" @click="ejecutar(revocarPortal)">Revocar acceso</button></div>
      <p v-if="invitacion">Expediente {{invitacion.expediente}} · Código <code>{{invitacion.codigo}}</code> · Vence en {{invitacion.minutos}} minutos.</p>
    </Modal>
    <Modal v-if="cita && !formulario && !lineasCargo" :title="'Cita · '+cita.paciente" @close="cita=null" size="lg">
      <p>{{fechaHora(cita.inicio)}} · {{cita.estado}} · {{cita.tipo_atencion}}</p>
      <div class="acts">
        <template v-if="['programada','confirmada'].includes(cita.estado)">
          <button class="btn sec" @click="programar(null,cita)">Reprogramar</button><button class="btn sec" @click="ejecutar(recordar)">Enviar recordatorio</button>
          <button class="btn sec" @click="ejecutar(async()=>{await estado(cita,'no se presentó');cita=null})">Registrar ausencia</button>
          <button class="btn sec" @click="ejecutar(async()=>{await estado(cita,'cancelada');cita=null})">Cancelar cita</button>
        </template>
        <button v-if="cita.modalidad==='telemedicina'" class="btn sec" @click="editarVideo">Enlace de video</button>
        <button class="btn sec" @click="validar">Validar cobertura</button>
        <button v-if="puedeFacturar" class="btn" @click="cargo">Preparar cargo</button>
      </div>
      <p v-if="validacion">Cobertura: {{validacion.estado}}</p>
      <h3 v-if="cargos.length">Cargos y comprobantes</h3>
      <ul><li v-for="c in cargos" :key="c.id">Cargo #{{c.id}} · {{c.pagador}} · {{c.cancelado?'Cancelado':(c.documento?.estado || 'Pendiente')}}
        <template v-if="c.documento">
          <a :href="'#/ventas/facturas/'+c.documento.id">{{c.documento.consecutivo}}</a>
          <span> · ₡{{c.documento.total}} · Saldo ₡{{c.documento.saldo}}</span>
          <a v-if="c.cliente_id && c.documento.saldo>0 && puedeCobrar && !c.pago_web && !c.cancelado"
            class="btn sm sec" :href="'#/ventas/pagos/nuevo?factura='+c.documento.id">Registrar cobro</a>
          <button v-if="c.pago_web && puedeCobrar" class="btn sm sec" @click="conciliar(c)">Conciliar Tilopay</button>
          <button v-if="c.reabrible && !c.cancelado" class="btn sm sec" @click="ejecutar(()=>cancelarCargo(c))">Liberar cargo corregido</button>
        </template>
        <template v-else-if="!c.cancelado"><button class="btn sm" @click="emitir(c)">Emitir</button><button class="btn sm sec" @click="ejecutar(()=>cancelarCargo(c))">Cancelar cargo</button></template>
      </li></ul>
    </Modal>
    <Modal v-if="lineasCargo" title="Ítems del cargo" @close="lineasCargo=null" size="lg">
      <form @submit.prevent="ejecutar(prepararCargo)">
        <div v-for="(l,i) in lineasCargo.lineas" :key="i" class="grid cols-2">
          <Field label="Ítem del catálogo"><select v-model="l.producto_id" required><option :value="null">Seleccionar</option>
            <option v-for="[id,nombre] in lineasCargo.productos" :key="id" :value="id">{{nombre}}</option></select></Field>
          <Field label="Cantidad"><input v-model.number="l.cantidad" type="number" min="0.001" step="0.001" required></Field>
          <Field label="Precio pactado (opcional)"><input v-model.number="l.precio_unitario" type="number" min="0" step="0.01"></Field>
          <Field label="Número de orden (si aplica)"><input v-model.number="l.orden_id" type="number" min="1"></Field>
          <button v-if="lineasCargo.lineas.length>1" type="button" class="btn sec" @click="lineasCargo.lineas.splice(i,1)">Quitar línea</button>
        </div>
        <div class="acts"><button type="button" class="btn sec" @click="lineasCargo.lineas.push({cantidad:1})">Agregar línea</button>
          <button class="btn" :disabled="ocupado">Guardar cargo</button></div>
      </form>
    </Modal>
    <Formulario :f="formulario" :ocupado="ocupado" @confirmar="confirmar" @cerrar="formulario=null"></Formulario>
  </div>`,
};
