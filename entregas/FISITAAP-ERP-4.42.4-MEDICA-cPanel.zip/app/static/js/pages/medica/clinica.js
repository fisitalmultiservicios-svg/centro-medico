import { campo, citaRuta, enviar, fechaHora, Formulario, leer, operaciones, opciones, permiso, productos, tiposOrden } from './_comun.js';
import { sesion } from '../../app.js';

export default {
  components: { Formulario },
  mixins: [operaciones],
  data() { return { citas:[], dia:'', actual:null, notas:[], consulta:null, historia:null, preadmision:null }; },
  computed: {
    enfermeria() { return permiso('medica_enfermeria'); },
    profesional() { return permiso('medica_clinica'); },
  },
  methods: {
    fechaHora,
    asignada(c) { return this.profesional && c.profesional_id === sesion.usuario?.id; },
    async cargar() { this.citas = await leer('/agenda',{dia:this.dia}); },
    async abrir(c) {
      this.actual = c;
      this.notas = await leer(citaRuta(c.id)+'/notas');
      this.consulta = null;
      this.historia = null;
      this.preadmision = this.asignada(c) ? await leer(citaRuta(c.id)+'/preadmision') : null;
      if (this.asignada(c) && c.estado==='atendida') this.consulta = await leer(citaRuta(c.id)+'/consulta');
    },
    async actualizar() {
      await this.cargar();
      const c = this.citas.find(c=>c.id===this.actual?.id);
      if (c) await this.abrir(c);
    },
    async iniciar() { await enviar(citaRuta(this.actual.id)+'/iniciar'); await this.actualizar(); },
    cerrar() {
      this.pedir('Cerrar consulta',[
        campo('motivo','Motivo de consulta','textarea',{req:true,max:4000}),
        campo('diagnostico','Diagnóstico','textarea',{req:true,max:4000}),
        campo('cie','Código CIE','text',{max:20}),
        campo('plan','Plan, examen y seguimiento','textarea',{req:true}),
      ],{},async d=>{await enviar(citaRuta(this.actual.id)+'/consulta',d);await this.actualizar();},'Cerrar consulta');
    },
    signos() {
      this.pedir('Registrar signos y observaciones',[
        campo('presion','Presión arterial'), campo('pulso','Pulso','number',{min:1,limite:300}),
        campo('temperatura','Temperatura °C','number',{min:20,limite:50,paso:.1}),
        campo('peso','Peso (kg)','number',{min:.1,limite:500,paso:.1}),
        campo('talla','Talla (cm)','number',{min:.1,limite:250,paso:.1}),
        campo('texto','Observaciones','textarea'),
      ],{},async d=>{await enviar(citaRuta(this.actual.id)+'/enfermeria',d);await this.actualizar();});
    },
    async verHistoria() { this.historia=await leer(citaRuta(this.actual.id)+'/historia'); },
    editarHistoria() {
      this.pedir('Actualizar historia clínica',[
        campo('antecedentes','Antecedentes y hábitos','textarea',{max:6000}),
        campo('alergias','Alergias','textarea',{max:2000}),
        campo('medicamentos','Medicamentos actuales','textarea',{max:4000}),
        campo('vacunas','Vacunas','textarea',{max:3000}),
        campo('alertas','Alertas clínicas','textarea',{max:2000}),
      ],this.historia?.perfil || {},async d=>{await enviar(citaRuta(this.actual.id)+'/historia',d);await this.verHistoria();});
    },
    adenda() {
      this.pedir('Agregar adenda',[campo('texto','Texto de la adenda','textarea',{req:true})],{},
        async d=>{await enviar(citaRuta(this.actual.id)+'/adendas',d);await this.actualizar();});
    },
    orden() {
      this.pedir('Emitir orden o documento',[
        campo('tipo','Tipo','select',{req:true,opciones:opciones(tiposOrden)}),
        campo('titulo','Título','text',{req:true}), campo('indicaciones','Indicaciones','textarea'),
        campo('producto_id','Ítem del ERP','select',{opciones:productos()}), campo('cantidad','Cantidad','number',{min:.001,paso:.001}),
      ],{tipo:'laboratorio',cantidad:1},d=>enviar(citaRuta(this.actual.id)+'/ordenes',d),'Emitir orden');
    },
  },
  created() { this.ejecutar(this.cargar); },
  template: `
  <div class="page">
    <PageHead title="Enfermería y consulta" :crumbs="[{label:'Médica'}]"></PageHead>
    <section class="card">
      <label>Fecha <input v-model="dia" type="date" @change="ejecutar(cargar)"></label>
      <p v-if="!citas.length">Sin citas para mostrar.</p>
      <ul><li v-for="c in citas" :key="c.id">{{fechaHora(c.inicio)}} · {{c.paciente}} · {{c.estado}}
        <button v-if="['llegó','en espera','en consulta','atendida'].includes(c.estado) && (enfermeria || asignada(c))" class="btn sm" @click="ejecutar(()=>abrir(c))">Abrir atención</button>
      </li></ul>
    </section>
    <Modal v-if="actual && !formulario" :title="'Atención · '+actual.paciente" @close="actual=null" size="lg">
      <p>{{actual.modalidad}} · {{actual.ubicacion || actual.consultorio}} · {{actual.estado}}</p>
      <div class="acts">
        <button v-if="enfermeria && actual.estado!=='atendida'" class="btn sec" @click="signos">Registrar signos</button>
        <template v-if="asignada(actual)">
          <button v-if="['llegó','en espera'].includes(actual.estado)" class="btn" @click="ejecutar(iniciar)">Iniciar consulta</button>
          <button v-if="actual.estado==='en consulta'" class="btn" @click="cerrar">Cerrar consulta</button>
          <button v-if="['en consulta','atendida'].includes(actual.estado)" class="btn sec" @click="orden">Emitir orden</button>
          <button v-if="actual.estado==='atendida'" class="btn sec" @click="adenda">Agregar adenda</button>
          <button class="btn sec" @click="ejecutar(verHistoria)">Historia clínica</button>
        </template>
      </div>
      <div v-if="preadmision"><h3>Motivo enviado por el paciente</h3><p>{{preadmision.motivo}}</p></div>
      <div v-if="consulta"><h3>Consulta cerrada</h3><p>{{consulta.motivo}}</p><p>{{consulta.cie}} {{consulta.diagnostico}}</p><p>{{consulta.plan}}</p></div>
      <div v-if="historia"><h3>Historia</h3><button class="btn sm sec" @click="editarHistoria">Actualizar perfil clínico</button>
        <dl><template v-for="(valor,k) in historia.perfil" :key="k"><dt>{{k}}</dt><dd>{{valor}}</dd></template></dl>
        <details v-for="c in historia.consultas" :key="c.cita_id"><summary>{{fechaHora(c.inicio)}} · {{c.motivo}}</summary><p>{{c.cie}} {{c.diagnostico}}</p><p>{{c.plan}}</p></details>
      </div>
      <h3 v-if="notas.length">Notas de atención</h3>
      <div v-for="n in notas" :key="n.id"><b>{{n.tipo}} · {{fechaHora(n.fecha)}}</b>
        <p>{{n.texto}} <span v-if="n.presion">· PA {{n.presion}}</span><span v-if="n.pulso"> · Pulso {{n.pulso}}</span>
        <span v-if="n.temperatura"> · {{n.temperatura}} °C</span><span v-if="n.peso"> · {{n.peso}} kg</span><span v-if="n.talla"> · {{n.talla}} cm</span></p>
      </div>
    </Modal>
    <Formulario :f="formulario" :ocupado="ocupado" @confirmar="confirmar" @cerrar="formulario=null"></Formulario>
  </div>`,
};
