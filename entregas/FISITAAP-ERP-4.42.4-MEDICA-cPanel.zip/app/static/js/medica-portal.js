const el = id => document.getElementById(id);
const empresa = location.pathname.split('/').filter(Boolean).at(-1);
const base = '/api/medica/portal/' + empresa;
let token = '';
let tokenTitular = '';
let horarios = [];
let sede = null;
let reemplaza = null;
const fecha = s => s?.replace('T',' ').slice(0,16) || '';
const dinero = n => new Intl.NumberFormat('es-CR',{style:'currency',currency:'CRC'}).format(n);

function estado(texto, error = false) {
  el('mensaje').textContent = texto;
  el('mensaje').className = error ? 'error' : '';
}

function cerrar() {
  token = '';
  tokenTitular = '';
  el('representaciones').replaceChildren();
  sede = null;
  reemplaza = null;
  el('cambio-cita').hidden = true;
  el('cuenta').hidden = true;
  el('acceso').hidden = false;
  for (const id of ['citas','documentos','facturas','mensajes']) el(id).replaceChildren();
  el('paciente').textContent = 'Mi cuenta';
  el('form-preadmision').reset();
  if (el('preadmision').open) el('preadmision').close();
  if (el('llegada').open) el('llegada').close();
  el('qr-llegada').replaceChildren();
  el('codigo-llegada').textContent='';
  pintarHorarios();
}

async function pedir(ruta, datos, archivo = false) {
  const headers = token ? {'X-Medica-Portal':token} : {};
  if (datos !== undefined) headers['Content-Type'] = 'application/json';
  const res = await fetch(base + ruta,{
    method:datos === undefined ? 'GET' : 'POST', headers, credentials:'omit', cache:'no-store',
    body:datos === undefined ? undefined : JSON.stringify(datos),
  });
  if (!res.ok) {
    if (res.status === 401 && token) cerrar();
    const j = await res.json().catch(()=>null);
    throw new Error(typeof j?.detail === 'string' ? j.detail : 'No se pudo completar la operación.');
  }
  return archivo ? res.blob() : res.json();
}

function boton(texto, fn) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'sec';
  b.textContent = texto;
  b.addEventListener('click', () => ejecutar(fn,b));
  return b;
}

async function ejecutar(fn, botonActual) {
  if (botonActual) botonActual.disabled = true;
  estado('');
  try { await fn(); }
  catch (e) { estado(e.message,true); }
  finally { if (botonActual) botonActual.disabled = false; }
}

function renglon(texto) {
  const li = document.createElement('li');
  li.textContent = texto;
  return li;
}

function parrafo(li,texto) {
  if (!texto) return;
  const p = document.createElement('p');
  p.textContent = texto;
  li.append(p);
}

async function descargar(ruta, nombre) {
  const blob = await pedir(ruta,undefined,true);
  const u = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = u;
  a.download = nombre;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(u),1000);
}

function render(id, filas, mensaje) {
  el(id).replaceChildren(...(filas.length ? filas : [renglon(mensaje)]));
}

async function actualizarCuenta() {
  const c = await pedir('/cuenta');
  sede = c.sede;
  el('cuenta').hidden = false;
  el('acceso').hidden = true;
  el('paciente').textContent = c.nombre;
  await mostrarRepresentaciones();
  render('citas',c.citas.map(x=>{
    const li = renglon(fecha(x.inicio) + ' · ' + x.modalidad + ' · ' + x.estado);
    if (x.video) {
      const video = document.createElement('a');
      video.href = x.video;
      video.target = '_blank';
      video.rel = 'noopener noreferrer';
      video.textContent = 'Entrar a la videollamada';
      li.append(' ', video);
    }
    if (['programada','confirmada'].includes(x.estado)) {
      if (x.modalidad !== 'telemedicina') li.append(boton('Código de llegada',async()=>{
        const d=await pedir('/citas/'+x.id+'/check-in',{});
        el('qr-llegada').replaceChildren();
        const qr=document.createElement('img');
        qr.alt='Código QR de llegada';
        qr.src='data:image/png;base64,'+d.qr;
        el('qr-llegada').append(qr);
        el('codigo-llegada').textContent=d.codigo+' · vence en '+d.minutos+' min';
        el('llegada').showModal();
      }));
      li.append(boton('Preadmisión',()=>{
        el('form-preadmision').reset();
        el('form-preadmision').dataset.cita = x.id;
        el('preadmision').showModal();
      }));
      li.append(boton('Reprogramar',()=>{
        reemplaza=x.id;
        el('cambio-cita').hidden=false;
        pintarHorarios();
        el('buscar').focus();
      }));
      li.append(boton('Cancelar cita',async()=>{
        if (!confirm('¿Cancelar esta cita?')) return;
        await pedir('/citas/'+x.id+'/cancelar',{});
        await Promise.all([actualizarCuenta(),cargarHorarios()]);
        estado('Cita cancelada.');
      }));
    }
    return li;
  }),'Aún no hay citas en el expediente.');
  render('documentos',c.documentos.map(x=>{
    const li = renglon(x.titulo + ' · ' + x.tipo);
    parrafo(li,x.indicaciones);
    parrafo(li,x.resultado);
    if (x.adjunto) li.append(boton('Descargar PDF',()=>descargar('/documentos/'+x.id+'/pdf','documento-'+x.id+'.pdf')));
    return li;
  }),'Aún no hay documentos publicados.');
  render('facturas',c.facturas.map(x=>{
    const li = renglon(x.consecutivo + ' · ' + dinero(x.total) + ' · Saldo ' + dinero(x.saldo));
    li.append(boton('Descargar comprobante',()=>descargar('/facturas/'+x.id+'/pdf',x.consecutivo+'.pdf')));
    if (x.pagable) {
      li.append(boton('Pagar con tarjeta',async()=>{
        const pago = await pedir('/facturas/'+x.id+'/pagar',{});
        location.assign(pago.url);
      }));
      li.append(boton('Consultar pago',async()=>{
        const pago = await pedir('/facturas/'+x.id+'/pago');
        estado('Estado del pago: '+pago.estado+'.');
      }));
    }
    return li;
  }),'Aún no hay comprobantes disponibles.');
  pintarHorarios();
  await cargarMensajes();
}

async function mostrarRepresentaciones() {
  const caja=el('representaciones');
  caja.replaceChildren();
  if (token!==tokenTitular) {
    caja.append(boton('Volver a mi expediente',async()=>{token=tokenTitular;reemplaza=null;el('cambio-cita').hidden=true;await actualizarCuenta();}));
    return;
  }
  const r=await pedir('/representaciones');
  for (const persona of r) caja.append(boton('Ver expediente de '+persona.nombre,async()=>{
    ({token}=await pedir('/representaciones/'+persona.id+'/sesion',{}));
    reemplaza=null;
    el('cambio-cita').hidden=true;
    await actualizarCuenta();
  }));
}

async function cargarMensajes() {
  const filas = await pedir('/mensajes');
  render('mensajes',filas.map(x=>renglon(fecha(x.fecha)+' · '+x.direccion+' · '+x.texto)),'Aún no hay mensajes.');
}

el('enviar-mensaje').addEventListener('submit',e=>{
  e.preventDefault();
  const f=e.currentTarget;
  const texto=new FormData(f).get('texto');
  ejecutar(async()=>{await pedir('/mensajes',{texto});f.reset();await cargarMensajes();},e.submitter);
});
el('form-preadmision').addEventListener('submit',e=>{
  e.preventDefault();
  const f=e.currentTarget;
  const datos=new FormData(f);
  ejecutar(async()=>{
    await pedir('/citas/'+f.dataset.cita+'/preadmision',{motivo:datos.get('motivo'),preparacion:datos.has('preparacion')});
    f.reset();
    el('preadmision').close();
    estado('Preadmisión guardada.');
  },e.submitter);
});
el('cerrar-preadmision').addEventListener('click',()=>el('preadmision').close());

function pintarHorarios() {
  const busca = el('buscar').value.trim().toLocaleLowerCase('es');
  const dia = el('dia').value;
  const filas = horarios.filter(h=>(!token || h.sede===sede) && (!dia || h.inicio.startsWith(dia))
    && [h.profesional,h.especialidad,h.servicio].join(' ').toLocaleLowerCase('es').includes(busca));
  render('horarios',filas.map(h=>{
    const li = renglon(fecha(h.inicio) + ' · ' + h.servicio + ' · ' + h.profesional + ' · ' + h.modalidad);
    if (token) li.append(boton(reemplaza?'Cambiar a este horario':'Reservar',async()=>{
      const anterior=reemplaza;
      if (!confirm((anterior?'¿Cambiar la cita al ':'¿Reservar la cita del ')+fecha(h.inicio)+'?')) return;
      await pedir('/horarios/'+h.id+'/reservar',{reemplaza:anterior});
      reemplaza=null;
      el('cambio-cita').hidden=true;
      await Promise.all([actualizarCuenta(),cargarHorarios()]);
      estado(anterior?'Cita reprogramada.':'Cita confirmada.');
    }));
    return li;
  }),'Sin horarios disponibles con esos filtros.');
}

async function cargarHorarios() {
  horarios = await pedir('/horarios');
  pintarHorarios();
}

for (const id of ['ingreso','registro']) {
  el(id).addEventListener('submit',evento=>{
    evento.preventDefault();
    const f = evento.currentTarget;
    const datos = Object.fromEntries(new FormData(f));
    datos.expediente = Number(datos.expediente);
    ejecutar(async()=>{
      if (id === 'registro') {
        await pedir('/registro',datos);
        estado('Cuenta activada. Ya puedes ingresar.');
      } else {
        ({token} = await pedir('/sesion',datos));
        tokenTitular = token;
        await actualizarCuenta();
        estado('Sesión iniciada.');
      }
      f.reset();
    },evento.submitter);
  });
}

el('salir').addEventListener('click',()=>{ cerrar(); estado('Sesión cerrada.'); });
el('cancelar-cambio').addEventListener('click',()=>{
  reemplaza=null;
  el('cambio-cita').hidden=true;
  pintarHorarios();
});
el('refrescar').addEventListener('click',()=>ejecutar(cargarHorarios,el('refrescar')));
for (const id of ['buscar','dia']) el(id).addEventListener('input',pintarHorarios);
ejecutar(async()=>{
  const info = await pedir('/info');
  el('clinica').textContent = info.nombre;
  await cargarHorarios();
});
