"""Activación y permisos de FISITAAP Médica."""
import os


def habilitada(empresa) -> bool:
    if empresa is None or os.getenv("FE_MODO_LOCAL") == "1":
        return False
    activa = getattr(empresa, "medica_activa", None)
    if activa is not None:
        return activa
    empresas = os.getenv("FE_MEDICA_EMPRESAS", "").split(",")
    return str(empresa.id) in {valor.strip() for valor in empresas}


RECEPCION = "medica_recepcion"
CLINICA = "medica_clinica"
ENFERMERIA = "medica_enfermeria"
LABORATORIO = "medica_laboratorio"
FARMACIA = "medica_farmacia"
GESTION = "medica_gestion"
PERMISOS = {
    RECEPCION: "Médica · Recepción y agenda",
    CLINICA: "Médica · Consultas asignadas",
    ENFERMERIA: "Médica · Enfermería",
    LABORATORIO: "Médica · Laboratorio e imágenes",
    FARMACIA: "Médica · Farmacia",
    GESTION: "Médica · Operación y convenios",
}
